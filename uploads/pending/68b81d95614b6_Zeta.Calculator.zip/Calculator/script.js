function appendToResult(value) {
    document.getElementById('result').value += value;
}

function clearResult() {
    document.getElementById('result').value = '';
}

function calculateResult() {
    const resultElement = document.getElementById('result');
    try {
        let expression = resultElement.value;
        expression = expression.replace(/√/g, 'Math.sqrt');
        
        const result = eval(expression);
        resultElement.value = result;
        addToHistory(expression, result);
    } catch (error) {
        resultElement.value = 'خطا';
        addToHistory(resultElement.value, 'خطا در محاسبه');
    }
}

function addToHistory(expression, result) {
    const historyElement = document.getElementById('history');
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item';
    historyItem.textContent = `${expression} = ${result}`;
    historyElement.appendChild(historyItem);
    
    const calculationHistory = JSON.parse(localStorage.getItem('calculationHistory')) || [];
    calculationHistory.push({
        expression: expression,
        result: result,
        date: new Date().toLocaleDateString('fa-IR'),
        time: new Date().toLocaleTimeString('fa-IR')
    });
    localStorage.setItem('calculationHistory', JSON.stringify(calculationHistory));
}

if (window.location.pathname.includes("index.html") || 
    window.location.pathname === "/" || 
    window.location.pathname === "") {
    document.addEventListener('DOMContentLoaded', function() {
        let visitCount = parseInt(localStorage.getItem('visitCount') || 0);
        if (!sessionStorage.getItem('visited')) {
            visitCount++;
            localStorage.setItem('visitCount', visitCount);
            sessionStorage.setItem('visited', 'true');
        }
    });
}