const adminCredentials = {
    username: "Arta",
    password: "1234"
};

const txtDatabase = {
    save: function(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    },
    load: function(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
};

function trackVisit() {
    if (!sessionStorage.getItem('visited')) {
        let visitCount = parseInt(txtDatabase.load('visitCount') || 0);
        visitCount++;
        txtDatabase.save('visitCount', visitCount);
        sessionStorage.setItem('visited', 'true');
    }
}

function checkLogin() {
    if (window.location.pathname.includes("ad_panel.html")) {
        const isLoggedIn = sessionStorage.getItem('adminLoggedIn');
        if (!isLoggedIn) {
            window.location.href = 'ad_login.html';
        } else {
            loadAdminData();
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes("index.html") || 
        window.location.pathname === "/" || 
        window.location.pathname === "") {
        trackVisit();
    }
    
    if (document.getElementById('loginForm')) {
        const loginForm = document.getElementById('loginForm');
        const errorMessage = document.getElementById('errorMessage');
        
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            if (username === adminCredentials.username && password === adminCredentials.password) {
                sessionStorage.setItem('adminLoggedIn', 'true');
                window.location.href = 'ad_panel.html';
            } else {
                errorMessage.textContent = 'نام کاربری یا رمز عبور اشتباه است';
                errorMessage.style.display = 'block';
            }
        });
    }
    
    if (document.getElementById('logoutBtn')) {
        document.getElementById('logoutBtn').addEventListener('click', function() {
            sessionStorage.removeItem('adminLoggedIn');
            window.location.href = 'ad_login.html';
        });
    }
    
    checkLogin();
});

function loadAdminData() {
    const calculationHistory = JSON.parse(localStorage.getItem('calculationHistory')) || [];
    const visitCount = parseInt(txtDatabase.load('visitCount') || 0);
    
    const historyContainer = document.getElementById('adminHistory');
    if (historyContainer) {
        historyContainer.innerHTML = '';
        
        if (calculationHistory.length === 0) {
            historyContainer.innerHTML = '<p class="no-data">هیچ تاریخچه‌ای موجود نیست</p>';
        } else {
            calculationHistory.forEach(item => {
                const historyItem = document.createElement('div');
                historyItem.className = 'history-item';
                
                if (typeof item === 'object') {
                    historyItem.innerHTML = `
                        <strong>عبارت:</strong> ${item.expression || 'نامشخص'} 
                        <strong>نتیجه:</strong> ${item.result || 'نامشخص'}
                        <br><small>تاریخ: ${item.date || 'نامشخص'} - زمان: ${item.time || 'نامشخص'}</small>
                    `;
                } else {
                    historyItem.textContent = item;
                }
                
                historyContainer.appendChild(historyItem);
            });
        }
    }
    
    updateStats(calculationHistory, visitCount);
}

function updateStats(history, visitCount) {
    const today = new Date().toLocaleDateString('fa-IR');
    
    const todayCalculations = history.filter(item => {
        if (typeof item === 'object') {
            return item.date === today;
        }
        return false;
    }).length;
    
    const errorCalculations = history.filter(item => {
        if (typeof item === 'object') {
            return item.result && item.result.toString().includes('خطا');
        }
        return item && item.toString().includes('خطا');
    }).length;
    
    if (document.getElementById('todayCalculations')) {
        document.getElementById('todayCalculations').textContent = todayCalculations;
    }
    
    if (document.getElementById('totalCalculations')) {
        document.getElementById('totalCalculations').textContent = history.length;
    }
    
    if (document.getElementById('errorCalculations')) {
        document.getElementById('errorCalculations').textContent = errorCalculations;
    }
    
    if (!document.getElementById('visitStats')) {
        const statsGrid = document.querySelector('.stats-grid');
        if (statsGrid) {
            const visitCard = document.createElement('div');
            visitCard.className = 'stat-card';
            visitCard.id = 'visitStats';
            visitCard.innerHTML = `
                <h3>تعداد بازدیدکنندگان</h3>
                <p id="totalVisits">${visitCount}</p>
            `;
            statsGrid.appendChild(visitCard);
        }
    } else {
        document.getElementById('totalVisits').textContent = visitCount;
    }
}