


my_group = 'g0D3auy06256869b490357278a6f1e43'
group_admins = ['u0FvTQC00cb37e1352836ef8a90a9973']


from rubpy import Client, handlers, models, methods
from aiohttp import ClientSession, ClientTimeout
from random import choice
from asyncio import run, sleep
from colorama import Fore
from os import system, name
import aiofiles
import pyfiglet
import random


red = Fore.RED
blue = Fore.BLUE
green = Fore.GREEN
white =Fore.WHITE
yellow = Fore.YELLOW
lblue =Fore.LIGHTCYAN_EX
p =Fore.MAGENTA






my_filters = ('@', 'join', 'rubika.ir' , 'https')
silence_list = []
no_gifs = False
zedFosh = False
statuslock = False
ZedLink = True







texts_bot = [
    "بنال",
    "چیه بدبخت",
    "باز اومد",
    "هعی",
    "هن",
    "بگیر بخواب",
    "بله",
    "بلههه",
    "جانم",
    "جونم",
    "بگو",
    "خستم کردی",
    "بسه دیگه",
]


texts_bot_hi= [
'سلام',
'علیک',
'کارتو بگو'
]
    
texts_bot_ch= [
'salomati',
'سلامتی',
'بتوچه'
]

texts_bot_th= [
'چاکرم',
"فدای تو",
"💓"
]

texts_bot_pv= [
'بدو بیا پی',
'پیوی در خدمتیم',
'ایجااااااان جگر بیوپی'
]





my_insults = (
    'کیر',
    'کص',
    'کون',
    'کس ننت',
    'کوس',
    'کوص',
    'ممه',
    'ننت',
    'بی ناموس',
    'بیناموس',
    'بیناموص',
    'بی ناموص',
    'گایید',
    'جنده',
    'جندع',
    'جیندا',
    'پستون',
    'کسکش',
    'ننه کس',
    'اوبی',
    'هرزه',
    'قحبه',
    'عنتر',
    'فاک',
    'کسعمت',
    'کصخل',
    'کسخل',
    'تخمی',
    'سکس',
    'صکص',
    'کسخول',
    'کسشر',
    'کسشعر',
)

texthelpAdmin = """


─────────Admin Help─────────


👑 `/status` 
- مشاهده وضعیت گروه

💥 `/ban` 
- با ریپلای زدن روی پیام فرد او را بن کنید 

💥 `/ban @id`
- بن کردن فرد با id

🧹 `/cleanList`
- پاکسازی لیست سکوت

🔇 `/mute` 
- سکوت قرار دادن کاربر با ریپلای روی پیام 

🔇 `/mute id` 
- سکوت قرار دادن کاربر با نام کاربری 

🔃 `/AdminUp`
- اپدیت مدیران

🔒 `/lockGif`
- حذف گیف در گروه

🔓 `/openGif`
- پاک نشدن گیف در گروه توسط ربات

🔑 `/open`
- بازکردن گروه

🔒 `/lock`
- قفل گروه

🙊 `/AntiFosh`
- حذف فوش  های کاربران برای جلوگیری از فیلتر شدن گروه

🔄️ `/AntiLink`
- خاموش روشن کردن سیستم ضد لینک 

-Creator : 
@Rezabkg
-team :
@city__team

"""

texthelpuser = f"""

──────────User Help────────

💥 `دانستنی` 
- ارسال مطالب در موضوع دانستنی 

💥 `جوک`
- ارسال جوک

🧹 `تاریخ`
- ارسال تاریخ

🔃 `ذکر امروز`
- ذکر روز ها

🔃 `حدیث`
- گفتن حدیث

🗞️ `لینک`
- ارسال لینک گروه

🗞️ `قوانین`
- نمایش قوانین گروه




-Creator : 
@Rezabkg

"""

texthelp = '''

─────── Bot Help ────────

برای استفاده از راهنمای ربات میتونید از دستورات زیر استفاده کنید ⚙️


👤 `helpUser`
- راهنمای ربات برای کاربران عادی


🎟️ `helpAdmin`
- راهنمای ربات برای  ادمین ها

'''

#Source



print (f"{p}Darhale Barsi Admin Azafe Shode.......")
sleep(5000)




def getAds(string: str) -> bool:
    string = string.lower()
    for filter in my_filters:
        if filter in string:
            return True
        else:
            continue
    return False

def getInsults(string: str) -> bool:
    for filter in my_insults:
        if filter in string:
            return True
        else:
            continue
    return False

async def updateAdmins(client: Client) -> None:
    global group_admins
    results = await client(methods.groups.GetGroupAdminMembers(my_group))
    results = results.to_dict().get('in_chat_members')
    for result in results:
        GUID = result.get('member_guid')
        if not GUID in group_admins:
            group_admins.append(GUID)
        else:
            continue

async def main():
   
    async with ClientSession(timeout=ClientTimeout(5)) as CS:
        async with Client(session='MyBot') as client:
            system('clear' if name == 'posix' else 'cls')
            print(f'\033[31m'+pyfiglet.figlet_format("BOT STARTRD",font='slant')+f"        {p}Developer : AlirezaPNG"+ "\n "+f"{yellow}_"*40+white)
            await updateAdmins(client)
            @client.on(handlers.MessageUpdates(models.is_group()))
            async def updates(update):
                if update.object_guid == my_group:
                    if not update.author_guid in group_admins and 'forwarded_from' in update.to_dict().get('message').keys():
                        await update.delete_messages()
                        print('Delete A Forward.')

                    if update.raw_text != None:
                        if not update.author_guid in group_admins and getAds(update.raw_text):
                            global ZedLink
                            if ZedLink :
                                await update.delete_messages()
                                print('Delete A Link.')
    
                        elif getInsults(update.raw_text):
                            global zedFosh
                            if zedFosh :
                                await update.delete_messages()
                                print('Delete A Insult.')

                        elif update.author_guid in group_admins and update.raw_text == '/open':
                            global statuslock 
                            statuslock = True
                            result = await client(methods.groups.SetGroupDefaultAccess(my_group, ['SendMessages']))
                            await update.reply('گروه باز شد.')

                        elif update.author_guid in group_admins and update.raw_text == '/lock':
                            statuslock = False
                            result = await client(methods.groups.SetGroupDefaultAccess(my_group, []))
                            await update.reply('گروه بسته شد.')

                        elif update.author_guid in group_admins and update.raw_text == '/lockGif':
                            global no_gifs
                            no_gifs = True
                            await update.reply('گیف قفل شد.')
                        elif update.author_guid in group_admins and update.raw_text == '/AntiFosh':
         
                            if zedFosh:
                                await update.reply('سطح سخت گیری گروه کاهش یافت \n آنتی فوش خاموش شد 🚫')
                                zedFosh = False
                            else:
                                await update.reply('سطح سخت گیری گروه افزایش یافت \n آنتی فوش  فعال شد ✅')
                                zedFosh = True

                        elif update.author_guid in group_admins and update.raw_text == '/AntiLink':
                            if ZedLink == True:
                                ZedLink = False
                                await update.reply('سطح سخت گیری گروه کاهش یافت \n آنتی لینک خاموش شد 🚫')
                   
                            else:
                                ZedLink = True       
                                await update.reply('سطح سخت گیری گروه افزایش یافت \n آنتی لینک  فعال شد ✅')
                             
                        elif update.author_guid in group_admins and update.raw_text == '/status':
                            try:
                                textLock = 'N/A'
                                if statuslock :
                                    textLock = "✅" 
                                else:
                                    textLock = "🚫"

                            except:
                                print('err To give Link')

                            try:
                                textZedL = 'N/A'
                                if ZedLink :
                                    textZedL = "✅" 
                                else:
                                    textZedL = "🚫"

                            except:
                                print('err To give Link')

                            
                            try:
                                textZedF = 'N/A'
                                if zedFosh :
                                    textZedF = "✅" 
                                else:
                                    textZedF = "🚫"

                            except:
                                print('err To give Link')


                            try:
                                textGif = 'N/A'
                                if no_gifs :
                                    textGif = "✅" 
                                else:
                                    textGif = "🚫"

                            except:
                                print('err To give Link')

    
                            await update.reply(f"""

                                ضدلینک : {textZedL}

                                ضد فوش : {textZedF}

                                وضعیت گروه: {textLock}

                                قفل گیف : {textGif}

                        
                            """)
                            


                        elif  update.raw_text == "قوانین" : 
                            await update.reply(f"🌀 قوانین گروه  :\n\n⛔️ ارسال لینک ممنوع!\n⛔️ ارسال فحش ممنوع!\n⛔️ توهین به کسی ممنوع!\n⛔️ارسال از کانال (فروارد) ممنوع!")
                        
                        elif  update.raw_text == "help" or update.raw_text == 'راهنما' : 
                            await update.reply(texthelp)
                        
                        elif  update.raw_text == "سلام" or update.raw_text == 'hello' : 
                                 await update.reply(texts_bot_hi[random.randint(0, len(texts_bot_hi))])
                        
                        elif  update.raw_text == "چه خبر" or update.raw_text == 'چخبر' : 
                                 await update.reply(texts_bot_ch[random.randint(0, len(texts_bot_ch))])
                        
                        elif  update.raw_text == "ممنون" or update.raw_text == 'چاکرم' or update.raw_text == 'دوست دارم' or update.raw_text == 'عاشقتم' : 
                                 await update.reply(texts_bot_th[random.randint(0, len(texts_bot_th))])
                        
                        elif  update.raw_text == "پیوی" or update.raw_text == 'میدی' or update.raw_text == 'میدی؟' : 
                                 await update.reply(texts_bot[random.randint(0, len(texts_bot_th))])

                        elif update.raw_text == "ربات" or update.raw_text == "bot" or update.raw_text =="بات" or update.raw_text =="robot":
                            await update.reply(texts_bot[random.randint(0, len(texts_bot))])
                        elif  update.raw_text == "helpAdmin" : 
                            await update.reply(texthelpAdmin)
                        
                        elif  update.raw_text == "helpUser": 
                            await update.reply(texthelpuser)

                        elif update.raw_text == 'قیمت ارز':
                            string = ''
                            async with CS.get('https://api.codebazan.ir/arz/?type=arz') as response:
                                response = await response.json()
                                if response.get('Ok'):
                                    results = response.get('Result')
                                    for result in results:
                                        try:
                                            string += ''.join(['● ', result.get('name'), '\n', '• قیمت: ', result.get('price'), ' ریال','\n', '• به روزرسانی: ', result.get('update'), '\n\n'])
                                        except TypeError:
                                            continue
                                    await update.reply(string)

                        elif update.raw_text == 'دانستنی':
                            async with CS.post('http://api.codebazan.ir/danestani/') as response:
                                await update.reply(await response.text())

                        elif update.raw_text == 'جوک':
                            path = choice(['jok', 'jok/khatere', 'jok/pa-na-pa', 'jok/alaki-masalan'])
                            async with CS.post(f'http://api.codebazan.ir/{path}/') as response:
                                await update.reply(await response.text())

                        elif update.raw_text == 'ذکر امروز':
                            async with CS.post('http://api.codebazan.ir/zekr/') as response:
                                await update.reply(await response.text())

                        elif update.raw_text == 'حدیث':
                            async with CS.post('http://api.codebazan.ir/hadis/') as response:
                                await update.reply(await response.text())

                        elif update.author_guid in group_admins and update.raw_text == '/openGif':
                            no_gifs = False
                            await update.reply('قفل گیف رفع شد.')

                        elif update.author_guid in group_admins and update.raw_text.startswith('/mute'):
                            if update.reply_message_id != None:
                                try:
                                    result = await client(methods.messages.GetMessagesByID(my_group, [update.reply_message_id]))
                                    result = result.to_dict().get('messages')[0]
                                    if not result.get('author_object_guid') in group_admins:
                                        global silence_list
                                        silence_list.append(result.get('author_object_guid'))
                                        await update.reply('کاربر مورد نظر در حالت سکوت قرار گرفت.')
                                    else:
                                        await update.reply('کاربر مورد نظر در گروه ادمین است.')
                                except IndexError:
                                    await update.reply('ظاهرا پیامی که روی آن ریپلای کرده اید پاک شده است.')
                            elif update.text.startswith('سکوت @'):
                                username = update.text.split('@')[-1]
                                if username != '':
                                    result = await client(methods.extras.GetObjectByUsername(username.lower()))
                                    result = result.to_dict()
                                    if result.get('exist'):
                                        if result.get('type') == 'User':
                                            user_guid = result.get('user').get('user_guid')
                                            if not user_guid in group_admins:
                                                #global silence_list
                                                silence_list.append(user_guid)
                                                await update.reply('کاربر مورد نظر در حالت سکوت قرار گرفت.')
                                            else:
                                                await update.reply('کاربر مورد نظر در گروه ادمین است.')
                                        else:
                                            await update.reply('کاربر مورد نظر کاربر عادی نیست.')
                                    else:
                                        await update.reply('آیدی مورد نظر اشتباه است.')
                                else:
                                    await update.reply('آیدی مورد نظر اشتباه است.')
                            else:
                                await update.reply('روی یک کاربر ریپلای بزنید.')

                        elif update.author_guid in group_admins and update.raw_text.startswith('/cleanList'):
                            if silence_list == []:
                                await update.reply('لیست سکوت خالی است.')
                            else:
                                silence_list = []
                                await update.reply('لیست سکوت خالی شد.')

                        elif update.raw_text == 'لینک':
                            result = await client(methods.groups.GetGroupLink(my_group))
                            result = result.to_dict().get('join_link')
                            await update.reply(f'لینک گروه:\n{result}')
                        
                        elif update.raw_text == '':
                            result = await client(methods.groups.GetGroupLink(my_group))
                            result = result.to_dict().get('join_link')
                            await update.reply(f'لینک گروه:\n{result}')

                        elif update.author_guid in group_admins and update.text == '/AdminUp':
                            reply = await update.reply('در حال به روزرسانی لیست ادمین ها...')
                            await updateAdmins(client)
                            await sleep(2)
                            await reply.edit('به روزرسانی لیست ادمین ها انجام شد.')

                        elif update.author_guid in group_admins and update.text.startswith('/ban'):
                            if update.reply_message_id != None:
                                try:
                                    result = await client(methods.messages.GetMessagesByID(my_group, [update.reply_message_id]))
                                    result = result.to_dict().get('messages')[0]
                                    if not result.get('author_object_guid') in group_admins:
                                        result = await client(methods.groups.BanGroupMember(my_group, result.get('author_object_guid')))
                                        await update.reply('کاربر مورد نظر از گروه حذف شد.')
                                    else:
                                        await update.reply('کاربر مورد نظر در گروه ادمین است.')
                                except IndexError:
                                    await update.reply('ظاهرا پیامی که روی آن ریپلای کرده اید پاک شده است.')  
                            elif update.text.startswith(' /ban @'):
                                username = update.text.split('@')[-1]
                                if username != '':
                                    result = await client(methods.extras.GetObjectByUsername(username.lower()))
                                    result = result.to_dict()
                                    if result.get('exist'):
                                        if result.get('type') == 'User':
                                            user_guid = result.get('user').get('user_guid')
                                            if not user_guid in group_admins:
                                                result = await client(methods.groups.BanGroupMember(my_group, user_guid))
                                                await update.reply('کاربر مورد نظر از گروه حذف شد.')
                                            else:
                                                await update.reply('کاربر مورد نظر در گروه ادمین است.')
                                        else:
                                            await update.reply('کاربر مورد نظر کاربر عادی نیست.')
                                    else:
                                        await update.reply('آیدی مورد نظر اشتباه است.')
                                else:
                                    await update.reply('آیدی مورد نظر اشتباه است.')
                            else:
                                await update.reply('روی یک کاربر ریپلای بزنید.')  

            @client.on(handlers.MessageUpdates(models.is_group()))
            async def updates(update):
                if update.object_guid == my_group:
                    if update.author_guid in silence_list:
                        await update.delete_messages()
                    else:
                        if no_gifs:
                            if not update.author_guid in group_admins:
                                result = await client(methods.messages.GetMessagesByID(my_group, [update.message_id]))
                                result = result.to_dict().get('messages')[0]
                                if result.get('type') == 'FileInline' and result.get('file_inline').get('type') == 'Gif':
                                    await update.delete_messages()  
                                    print('Delete A Gif.')

            await client.run_until_disconnected()

run(main())