<?php

//  Version : V1.5
// پژواک سورس
// This Source Updated By @PejvakSource

$Dev = 1921063333; //1153161363
$Token = "2135831634:AAFxRl9tjtm53gyaJnOuno1wKCRnlYbBl5Y";

//  Version : V1.5
// پژواک سورس
// This Source Updated By @PejvakSource

?>