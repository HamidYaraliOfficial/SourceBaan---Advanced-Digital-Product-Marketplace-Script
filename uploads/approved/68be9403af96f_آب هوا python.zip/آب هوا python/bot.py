import requests
import json
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes


TELEGRAM_TOKEN = "BOT_TOKEN" #توکن ربات 


def get_weather(latitude, longitude):
    url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true"
    
    try:
        response = requests.get(url)
        data = response.json()
        
        if 'current_weather' in data:
            weather = data['current_weather']
            temperature = weather['temperature']
            windspeed = weather['windspeed']
            winddirection = weather['winddirection']
            weathercode = weather['weathercode']
            
           
            weather_descriptions = {
                0: "آسمان صاف",
                1: "عمدتاً صاف",
                2: "نیمه ابری",
                3: "ابری",
                45: "مه",
                48: "مه رسانا",
                51: "نمنم باران",
                53: "باران ملایم",
                55: "باران شدید",
                56: "باران یخ‌زده",
                57: "باران یخ‌زده شدید",
                61: "باران ملایم",
                63: "باران",
                65: "باران شدید",
                66: "باران یخ‌زده",
                67: "باران یخ‌زده شدید",
                71: "بارش برف ملایم",
                73: "بارش برف",
                75: "بارش برف شدید",
                77: "دانه‌های برف",
                80: "رگبار باران ملایم",
                81: "رگبار باران",
                82: "رگبار باران شدید",
                85: "رگبار برف",
                86: "رگبار برف شدید",
                95: "رعد و برق",
                96: "رعد و برق با بارش تگرگ",
                99: "رعد و برق با بارش تگرگ شدید"
            }
            
            description = weather_descriptions.get(weathercode, "نامشخص")
            
            return (f"دمای فعلی: {temperature}°C\n"
                   f"سرعت باد: {windspeed} km/h\n"
                   f"جهت باد: {winddirection}°\n"
                   f"وضعیت: {description}")
        else:
            return "مشکلی در دریافت اطلاعات آب و هوا پیش آمد."
    
    except Exception as e:
        return f"خطا در دریافت اطلاعات: {str(e)}"

# دستور start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [['تهران', 'مشهد'], ['اصفهان', 'شیراز'], ['موقعیت من']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    await update.message.reply_text(
        "به ربات آب و هوا خوش آمدید!\n"
        "لطفاً یک شهر را انتخاب کنید یا موقعیت خود را ارسال کنید.",
        reply_markup=reply_markup
    )


async def handle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    latitude = update.message.location.latitude
    longitude = update.message.location.longitude
    
    weather_info = get_weather(latitude, longitude)
    await update.message.reply_text(weather_info)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    city = update.message.text
    
   
    cities = {
        'تهران': (35.6892, 51.3890),
        'مشهد': (36.2605, 59.6168),
        'اصفهان': (32.6546, 51.6680),
        'شیراز': (29.5918, 52.5837),
        'تبریز': (38.0962, 46.2738),
        'کرج': (35.8400, 50.9391),
        'اهواز': (31.3183, 48.6706),
        'قم': (34.6400, 50.8764),
        'کرمان': (30.2839, 57.0834),
        'ارومیه': (37.5527, 45.0761)
    }
    
    if city in cities:
        latitude, longitude = cities[city]
        weather_info = get_weather(latitude, longitude)
        await update.message.reply_text(f"آب و هوای {city}:\n{weather_info}")
    elif city == 'موقعیت من':
        await update.message.reply_text("لطفاً موقعیت خود را از طریق گزینه اشتراک‌گذاری موقعیت ارسال کنید.")
    else:
        await update.message.reply_text("شهر مورد نظر یافت نشد. لطفاً از بین گزینه‌ها انتخاب کنید.")


def main():
    
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.LOCATION, handle_location))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    
    application.run_polling()
    print("ربات در حال اجراست...")

if __name__ == "__main__":
    main()