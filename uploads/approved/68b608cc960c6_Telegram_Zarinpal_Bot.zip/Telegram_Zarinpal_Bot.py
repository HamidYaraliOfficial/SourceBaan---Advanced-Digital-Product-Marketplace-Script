"""
Telegram Bot + ZarinPal v4 Payment (Python)

One-file example with:
- python-telegram-bot (v20+) for the Telegram bot (long polling)
- Flask for the ZarinPal callback/verify webhook
- SQLite for order tracking


 Developed by **سایمون تیم @boootsaz**
Usage
-----
1) Install deps:
   pip install python-telegram-bot==20.* Flask==3.* requests==2.* python-dotenv==1.*

2) Set environment variables (or create a .env next to this file):
   TELEGRAM_BOT_TOKEN=123456:ABC...
   ZARINPAL_MERCHANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   PUBLIC_BASE_URL=https://<your-domain-or-ngrok>
   ZARINPAL_USE_SANDBOX=true   # or false
   PORT=8000                   # optional (Flask port)

3) Run:
   python telegram_zarinpal_bot.py

4) In Telegram, send /buy 50000   (amount in Tomans)

Notes
-----
- ZarinPal v4 endpoints are used. If sandbox is enabled, sandbox endpoints & StartPay url are used.
- Callback URL will be {PUBLIC_BASE_URL}/zarinpal/callback . Expose your local server with e.g. ngrok.
- This example stores orders in SQLite (payments.db) with minimal fields. Adjust to your needs.
- For production, add proper error handling, persistence, and HTTPS.
"""
from __future__ import annotations
import os
import sqlite3
import threading
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple

import requests
from flask import Flask, request, jsonify, abort
from dotenv import load_dotenv

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

# ----------------------- Config & Setup -----------------------
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
ZARINPAL_MERCHANT_ID = os.getenv("ZARINPAL_MERCHANT_ID", "")
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")
ZARINPAL_USE_SANDBOX = os.getenv("ZARINPAL_USE_SANDBOX", "true").lower() in ("1","true","yes","y")
PORT = int(os.getenv("PORT", "8000"))

if not TELEGRAM_BOT_TOKEN:
    raise SystemExit("Missing TELEGRAM_BOT_TOKEN")
if not ZARINPAL_MERCHANT_ID:
    raise SystemExit("Missing ZARINPAL_MERCHANT_ID")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("zarinpal-bot")

# ----------------------- ZarinPal API -----------------------
@dataclass
class ZarinPalEndpoints:
    request_url: str
    verify_url: str
    startpay_base: str


def get_endpoints() -> ZarinPalEndpoints:
    if ZARINPAL_USE_SANDBOX:
        return ZarinPalEndpoints(
            request_url="https://sandbox.zarinpal.com/pg/v4/payment/request.json",
            verify_url="https://sandbox.zarinpal.com/pg/v4/payment/verify.json",
            startpay_base="https://sandbox.zarinpal.com/pg/StartPay/",
        )
    else:
        return ZarinPalEndpoints(
            request_url="https://api.zarinpal.com/pg/v4/payment/request.json",
            verify_url="https://api.zarinpal.com/pg/v4/payment/verify.json",
            startpay_base="https://www.zarinpal.com/pg/StartPay/",
        )


class ZarinPalClient:
    def __init__(self, merchant_id: str):
        self.merchant_id = merchant_id
        self.endpoints = get_endpoints()

    def request_payment(self, amount: int, description: str, callback_url: str, *, email: Optional[str]=None, mobile: Optional[str]=None) -> Tuple[str, str]:
        """Return (authority, gateway_url) on success; raise on error."""
        payload = {
            "merchant_id": self.merchant_id,
            "amount": int(amount),
            "description": description,
            "callback_url": callback_url,
            "metadata": {k: v for k, v in {"email": email, "mobile": mobile}.items() if v}
        }
        r = requests.post(self.endpoints.request_url, json=payload, timeout=15)
        js = r.json()
        # Expected: {"data":{"code":100, "authority":"XXXXXXXXX", ...}} or {"errors":{...}}
        data = js.get("data") or {}
        errors = js.get("errors")
        if errors:
            raise RuntimeError(f"ZarinPal request error: {errors}")
        authority = data.get("authority")
        code = data.get("code")
        if authority and code in (100, 101):
            return authority, f"{self.endpoints.startpay_base}{authority}"
        raise RuntimeError(f"Unexpected response: {js}")

    def verify_payment(self, authority: str, amount: int) -> Tuple[bool, Optional[int], Optional[int], Optional[str]]:
        """Return (ok, code, ref_id, card_pan_mask). code=100 success, 101 already verified."""
        payload = {
            "merchant_id": self.merchant_id,
            "amount": int(amount),
            "authority": authority,
        }
        r = requests.post(self.endpoints.verify_url, json=payload, timeout=15)
        js = r.json()
        data = js.get("data") or {}
        errors = js.get("errors")
        if errors:
            logger.error("ZarinPal verify errors: %s", errors)
            return False, None, None, None
        code = data.get("code")
        ref_id = data.get("ref_id")
        card_pan = data.get("card_pan_masked") or data.get("card_pan")
        ok = code in (100, 101)
        return ok, code, ref_id, card_pan


zp_client = ZarinPalClient(ZARINPAL_MERCHANT_ID)

# ----------------------- Database -----------------------
DB_PATH = os.path.join(os.path.dirname(__file__), "payments.db")

def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def init_db() -> None:
    con = db()
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS payments (
            authority TEXT PRIMARY KEY,
            chat_id   INTEGER NOT NULL,
            amount    INTEGER NOT NULL,
            description TEXT,
            status    TEXT NOT NULL,
            ref_id    INTEGER,
            created_at TEXT NOT NULL
        )
        """
    )
    con.commit()
    con.close()


init_db()

# ----------------------- Flask app (callback) -----------------------
app = Flask(__name__)

@app.get("/healthz")
def healthz():
    return {"ok": True}

@app.get("/zarinpal/callback")
def zarinpal_callback():
    authority = request.args.get("Authority") or request.args.get("authority")
    status = request.args.get("Status") or request.args.get("status")
    if not authority:
        abort(400, "Missing Authority")

    con = db()
    row = con.execute("SELECT * FROM payments WHERE authority=?", (authority,)).fetchone()
    if not row:
        con.close()
        abort(404, "Unknown Authority")

    chat_id = row["chat_id"]
    amount = int(row["amount"])

    if (status or "").upper() != "OK":
        con.execute("UPDATE payments SET status=? WHERE authority=?", ("failed", authority))
        con.commit()
        con.close()
        # Notify user (fire and forget)
        try:
            from telegram import Bot
            Bot(TELEGRAM_BOT_TOKEN).send_message(chat_id, text="❌ پرداخت لغو شد یا ناموفق بود.")
        except Exception as e:
            logger.exception("Failed to notify user on failed payment: %s", e)
        return jsonify({"ok": True, "message": "Payment not OK"})

    # Verify with ZarinPal
    ok, code, ref_id, card_pan = zp_client.verify_payment(authority, amount)

    if ok:
        con.execute("UPDATE payments SET status=?, ref_id=? WHERE authority=?", ("paid", ref_id, authority))
        con.commit()
        con.close()
        text = (
            "✅ پرداخت موفق بود!\n"
            f"مبلغ: {amount:,} تومان\n"
            f"کد پیگیری (RefID): {ref_id}\n"
        )
        if card_pan:
            text += f"کارت: {card_pan}\n"
        try:
            from telegram import Bot
            Bot(TELEGRAM_BOT_TOKEN).send_message(chat_id, text=text)
        except Exception as e:
            logger.exception("Failed to notify user on success: %s", e)
        return jsonify({"ok": True, "code": code, "ref_id": ref_id})
    else:
        con.execute("UPDATE payments SET status=? WHERE authority=?", ("failed", authority))
        con.commit()
        con.close()
        try:
            from telegram import Bot
            Bot(TELEGRAM_BOT_TOKEN).send_message(chat_id, text="❌ پرداخت ناموفق بود. در صورت کسر وجه، ظرف چند دقیقه برگشت می‌خورد.")
        except Exception as e:
            logger.exception("Failed to notify user on verify failure: %s", e)
        return jsonify({"ok": False}), 400


# ----------------------- Telegram bot handlers -----------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.effective_user.full_name if update.effective_user else ""
    text = (
        "سلام " + (name or "") + "!\n"
        "برای تست پرداخت، از دستور زیر استفاده کن:\n"
        "`/buy 50000` — پرداخت ۵۰٬۰۰۰ تومان\n\n"
        "پس از کلیک روی لینک پرداخت و انجام تراکنش، نتیجه به همین چت ارسال می‌شود."
    )
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)


async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Parse amount (Tomans)
    amount = 50000
    if context.args:
        try:
            amount = max(1000, int(context.args[0]))  # minimum 1000 Toman as a sanity check
        except Exception:
            pass

    chat_id = update.effective_chat.id
    description = f"Bot test payment for chat {chat_id}"

    callback_url = f"{PUBLIC_BASE_URL}/zarinpal/callback"

    try:
        authority, gateway_url = zp_client.request_payment(
            amount=amount,
            description=description,
            callback_url=callback_url,
        )
    except Exception as e:
        logger.exception("Payment request failed: %s", e)
        await update.message.reply_text("⚠️ خطا در ارتباط با درگاه. لطفاً بعداً تلاش کنید.")
        return

    # Save pending order
    con = db()
    con.execute(
        "INSERT OR REPLACE INTO payments(authority, chat_id, amount, description, status, created_at) VALUES (?,?,?,?,?,?)",
        (authority, chat_id, amount, description, "pending", datetime.utcnow().isoformat()+"Z"),
    )
    con.commit()
    con.close()

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("پرداخت با زرین‌پال", url=gateway_url)]
    ])
    msg = (
        "🔗 برای پرداخت روی دکمه زیر بزنید.\n"
        f"مبلغ: {amount:,} تومان\n"
        f"(حالت {'Sandbox' if ZARINPAL_USE_SANDBOX else 'Production'})"
    )
    await update.message.reply_text(msg, reply_markup=kb)


# ----------------------- Run everything -----------------------

def run_flask():
    # Disable Flask's default noisy logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.WARNING)
    app.run(host="0.0.0.0", port=PORT, debug=False)


def main():
    # Start Flask (callback server) in a background thread
    t = threading.Thread(target=run_flask, daemon=True)
    t.start()

    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("buy", buy))

    logger.info("Bot is running. Callback URL: %s/zarinpal/callback | Sandbox: %s", PUBLIC_BASE_URL, ZARINPAL_USE_SANDBOX)
    application.run_polling(allowed_updates=["message", "edited_message"])


if __name__ == "__main__":
    main()
