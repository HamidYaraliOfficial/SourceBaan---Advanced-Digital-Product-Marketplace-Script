<?php

define('API_KEY', '**TOKEN**');

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>"MarkDown"
 ]);
 } 
function sendphoto($chat_id, $photo, $caption){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
//-//////
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$text = $message->text;
$from_id = $update->message->from->id;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->callback_query->message->message_id;
$date = file_get_contents("https://provps.ir/td?td=date");
$time = file_get_contents("https://provps.ir/td?td=time");
//---------------//
$inch = file_get_contents("https://api.telegram.org/bot344333867:AAFQ_06SPoyQr-a44iJpccm-oYc6xmXVCSI/getChatMember?chat_id=@StarsTM&user_id=".$from_id); 
if(strpos($inch , '"status":"left"') == true ) { 

bot('sendMessage',[ 
        'chat_id'=>$update->message->chat->id, 
        'text'=>"🌀شما در کانال ما عضو نیستید🌀
🖇تا زمانی که در کانال ما عضو نشوید، ربات بای شما کار نمیکند🖇
⚡️بعد از ورود به کانال، ربات برای شما فعال می شود⚡️
⚜اگر بعد از ورود به کانال، خارج شوید، این پیام دوباره به شما ارسال خواهد شد⚜", 
 'parse_mode'=>'MarkDown', 
        'reply_markup'=>json_encode([ 
            'inline_keyboard'=>[ 
                [ 
                    ['text'=>"🔱ورود به کانال🔱",'url'=>"https://telegram.me/StarsTM"] 
                ] 
            ] 
        ]) 
    ]); 
}
elseif($text == '/start'){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>" 😍میخوام بهت تاریخ و ساعت رو بگم😍
😘روی هر کدوم از دکمه های زیر کلیک کنی من بهت میگم😊
😎اگه روی تاریخ بزنی برات تاریخ رو میگم😎
😜اگرم روی ساعت بزنی برات ساعت رو میگم😜",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>" 🗓تاریخ🗓 ",'callback_data'=>"a"],['text'=>" ⏰ساعت⏰ ",'callback_data'=>"b"]
              ],
              [
              ['text'=>"💠هردو با هم💠",'callback_data'=>"g"]
              ]
              ] 
        ])
 ]);
}
elseif($data == "a"){
bot('editMessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>" امروز $date هستش😄
😃اگه می خوایی تاریخ بروز بشه کافیه بزنی روی 🆙بروزش کن🆙 تا برات بروزش کنم😍",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🆙بروزش کن🆙",'callback_data'=>"c"]
              ],
              [
              ['text'=>"↪برگردیم↪",'callback_data'=>"back"]
              ]
              ] 
        ])
 ]);
}
elseif($data == "c"){
bot('editMessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"🆙تاریخ بروز شد
🆕امروز $date هستش
🔁اگه بازم خواستی بروز بشه کافیه بازم بزنی روی دکمه ی زیر تا برات بروزش بکنم😎",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🆙بروزش کن🆙",'callback_data'=>"c"]
              ],
              [
              ['text'=>"↪برگردیم↪",'callback_data'=>"back"]
              ]
              ] 
        ])
 ]);
}
elseif($data == "b"){
bot('editMessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>" 😎ساعت $time هستش😎
😃اگه می خوایی ساعت بروز بشه کافیه بزنی روی 🆙بروزش کن🆙 تا برات بروزش کنم😍",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🆙بروزش کن🆙",'callback_data'=>"b"]
              ],
              [
              ['text'=>"↪برگردیم↪",'callback_data'=>"back"]
              ]
              ] 
        ])
 ]);
}
elseif($data == "back"){
bot('editMessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>" 😍میخوام بهت تاریخ و ساعت رو بگم😍
😘روی هر کدوم از دکمه های زیر کلیک کنی من بهت میگم😊
😎اگه روی تاریخ بزنی برات تاریخ رو میگم😎
😜اگرم روی ساعت بزنی برات ساعت رو میگم😜 ",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>" 🗓تاریخ🗓 ",'callback_data'=>"a"],['text'=>" ⏰ساعت⏰ ",'callback_data'=>"b"]
              ],
              [
              ['text'=>"💠هردو با هم💠",'callback_data'=>"g"]
              ]
              ] 
        ])
 ]);
}
elseif($data == "g"){
bot('editMessagetext',[
 'chat_id'=>$chatid,
  'message_id'=>$message_id,
 'text'=>"😃 الان ساعت $time هستش
😊تاریخ امروز هم $date هستش
😘اگه بخوایی بروز بشه کافیه بزنی رو بروزش کن تا برات بروزش کنم😉",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
              ['text'=>"🆙بروزش کن🆙",'callback_data'=>"g"]
              ],
              [
              ['text'=>"↪برگردیم↪",'callback_data'=>"back"]
              ]
              ] 
        ])
 ]);
}
else {
sendmessage($chat_id , "⚠لطفا فقط از دکمه ها استفاده کنید⚠");
}

?>
