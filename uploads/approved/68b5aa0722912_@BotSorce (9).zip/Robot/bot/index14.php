
application/x-httpd-php index14.php ( PHP script text )

<?php
ob_start();
define('API_KEY','**TOKEN**');
$token = API_KEY;
$admin =  "**ADMIN**";
$GetINFObot = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getMe"));
$UserNameBot = $GetINFObot->result->username;
$NameBot = $GetINFObot->result->first_name;
function save($filename,$TXTdata){
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
mkdir("admin");
mkdir("ads");
mkdir("data");
mkdir("user");
mkdir("admin/code");
mkdir("ads/ads");
mkdir("ads/ads admin");
mkdir("ads/ads time");
mkdir("ads/ads username");
mkdir("ads/ads data");
mkdir("ads/ads msg id");
mkdir("ads/ads tedad");
function SendMessage($chatid,$text,$parsmde,$disable_web_page_preview,$keyboard){
	bot('sendMessage',[
	'chat_id'=>$chatid,
	'text'=>$text,
	'parse_mode'=>$parsmde,
	'disable_web_page_preview'=>$disable_web_page_preview,
	'reply_markup'=>$keyboard
	]);
	}
function ForwardMessage($chatid,$from_chat,$message_id){
	bot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	}
function SendPhoto($chatid,$photo,$keyboard,$caption){
	bot('SendPhoto',[
	'chat_id'=>$chatid,
	'photo'=>$photo,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendAudio($chatid,$audio,$keyboard,$caption,$sazande,$title){
	bot('SendAudio',[
	'chat_id'=>$chatid,
	'audio'=>$audio,
	'caption'=>$caption,
	'performer'=>$sazande,
	'title'=>$title,
	'reply_markup'=>$keyboard
	]);
	}
function SendDocument($chatid,$document,$keyboard,$caption){
	bot('SendDocument',[
	'chat_id'=>$chatid,
	'document'=>$document,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendSticker($chatid,$sticker,$keyboard){
	bot('SendSticker',[
	'chat_id'=>$chatid,
	'sticker'=>$sticker,
	'reply_markup'=>$keyboard
	]);
	}
function SendVideo($chatid,$video,$keyboard,$duration){
	bot('SendVideo',[
	'chat_id'=>$chatid,
	'video'=>$video,
	'duration'=>$duration,
	'reply_markup'=>$keyboard
	]);
	}
function SendVoice($chatid,$voice,$keyboard,$caption){
	bot('SendVoice',[
	'chat_id'=>$chatid,
	'voice'=>$voice,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendContact($chatid,$first_name,$phone_number,$keyboard){
	bot('SendContact',[
	'chat_id'=>$chatid,
	'first_name'=>$first_name,
	'phone_number'=>$phone_number,
	'reply_markup'=>$keyboard
	]);
	}
function SendChatAction($chatid,$action){
	bot('sendChatAction',[
	'chat_id'=>$chatid,
	'action'=>$action
	]);
	}
function KickChatMember($chatid,$user_id){
	bot('kickChatMember',[
	'chat_id'=>$chatid,
	'user_id'=>$user_id
	]);
	}
function LeaveChat($chatid){
	bot('LeaveChat',[
	'chat_id'=>$chatid
	]);
	}
function GetChat($chatid){
	bot('GetChat',[
	'chat_id'=>$chatid
	]);
	}
function GetChatMembersCount($chatid){
	bot('getChatMembersCount',[
	'chat_id'=>$chatid
	]);
	}
function GetChatMember($chatid,$userid){
	$truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=".$chatid."&user_id=".$userid));
	$tch = $truechannel->result->status;
	return $tch;
	}
function AnswerCallbackQuery($callback_query_id,$text,$show_alert){
	bot('answerCallbackQuery',[
        'callback_query_id'=>$callback_query_id,
        'text'=>$text,
		'show_alert'=>$show_alert
    ]);
	}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 bot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
function EditMessageCaption($chat_id,$message_id,$caption,$keyboard,$inline_message_id){
	 bot('editMessageCaption',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'caption'=>$caption,
    'reply_markup'=>$keyboard,
	'inline_message_id'=>$inline_message_id
	]);
	}

$button_manage = json_encode(['keyboard'=>[
    [['text'=>'↩️منوی اصلی']],
    [['text'=>'پیام همگانی'],['text'=>'فوروارد همگانی']],
    [['text'=>'آمار'],['text'=>'تعیین کد رایگان']],
    [['text'=>'اهدای سکه'],['text'=>'کم کردن سکه']],
    [['text'=>'تنظیم سکه عضو گیری'],['text'=>'تنظيم متن راهنما']],
    [['text'=>'تنظيم متن دعوت'],['text'=>'تنظيم متن استارت']],
    [['text'=>'تنظيم کانال'],['text'=>'تعداد تبلیغات ثبت شده']],
    [['text'=>'تنظیم سکه دیدن تبلیغات']],
 /*[['text'=>'آمار ربات به صورت پیشرفته']],*/
    [['text'=>'تنظیم متن فروشگاه']]
],'resize_keyboard'=>true]);
$button_peygiri = json_encode(['inline_keyboard'=>[
    [['text'=>"بنرشما📃",'url'=>"https://telegram.me/$idchannel/$idpayam"]],
    [['text'=>"تعداد سفارش شده 🔢 : $sefareshtedad",'callback_data'=>"s"]],
    [['text'=>"دیده شده ها 👁",'callback_data'=>"s"],['text'=>"باقیمانده⬇️",'callback_data'=>"s"]],
    [['text'=>$dide,'callback_data'=>"s"],['text'=>$baghi,'callback_data'=>"s"]],
    [['text'=>"تاریخ ثبت بنر📅",'callback_data'=>"s"],['text'=>"ساعت ثبت بنر🕰",'callback_data'=>"s"]],
    [['text'=>$timesabt,'callback_data'=>"s"],['text'=>$datesabt,'callback_data'=>"s"]]
]]);
$button_admin = json_encode(['keyboard'=>[
    [['text'=>'💎جمع آوری سکه رایگان💎']],
    [['text'=>'فروشگاه💌'],['text'=>'💸 انتقال سکه'],['text'=>'🎯 ثبت تبلیغ']],
    [['text'=>'👤زیرمجموعه گیری'],['text'=>'👤 حساب کاربری من'],['text'=>"وضعیت اکانت"]],
    [['text'=>"ویژه کردن اکانت"],['text'=>'نظرات کاربران به ربات📧']],
    [['text'=>'📨ارسال نظر📨'],['text'=>'راهنما📕']],
    [['text'=>'🎁 کد رایگان 🎉'],['text'=>"📊 پیگیری سفارش"],['text'=>"مدیریت"]],
],'resize_keyboard'=>true]);
$button_official = json_encode(['keyboard'=>[
    [['text'=>'💎جمع آوری سکه رایگان💎']],
    [['text'=>'فروشگاه💌'],['text'=>'💸 انتقال سکه'],['text'=>'🎯 ثبت تبلیغ']],
    [['text'=>'👤زیرمجموعه گیری'],['text'=>'👤 حساب کاربری من']],
    [['text'=>'نظرات کاربران به ربات📧']],
    [['text'=>'📨ارسال نظر📨'],['text'=>'راهنما📕']],
    [['text'=>'🎁 کد رایگان 🎉'],['text'=>"📊 پیگیری سفارش"]],
],'resize_keyboard'=>true]);
$button_back = json_encode(['keyboard'=>[
    [['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
$button_nz = json_encode(['inline_keyboard'=>[
    [['text'=>'نظر بعدی','callback_data'=>'nzr']],
],'resize_keyboard'=>true]);
$button_nza = json_encode(['inline_keyboard'=>[
    [['text'=>'تایید نظر','callback_data'=>'taiid nzr'],['text'=>'رد نظر','callback_data'=>'rad nzr']],
],'resize_keyboard'=>true]);
$update = json_decode(file_get_contents('php://input'));
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->message->from->id;
$messageid = $update->callback_query->message->message_id;
$data_id = $update->callback_query->id;
$txt = $update->callback_query->message->text;
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$from_username = $update->message->from->username;
$from_first = $update->message->from->first_name;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$text = $update->message->text;
$message_id = $update->message->message_id;
$stickerid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$voiceid = $update->message->voice->file_id;
$fileid = $update->message->document->file_id;
$photo = $update->message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$caption = $update->message->caption;
$cde = time();
$code = md5("$cde$from_id");
$date = file_get_contents("https://provps.ir/td?td=date");
$time = file_get_contents("https://provps.ir/td?td=time");
$command = file_get_contents('user/'.$from_id."/command.txt");
$gold = file_get_contents('user/'.$from_id."/gold.txt");
$coin = file_get_contents('user/'.$from_id."/coin.txt");
$username = $update->message->from->username;
$name = $update->message->from->first_name;
$wait = file_get_contents('user/'.$from_id."/wait.txt");
$coin_wait = file_get_contents('user/'.$wait."/coin.txt");
$number = file_get_contents('user/'.$from_id."/number.txt");
$code_taiid = file_get_contents('user/'.$from_id."/code taiid.txt");
$Member = file_get_contents('admin/Member.txt');
$NZR = file_get_contents('admin/NZR.txt');
$data = $update->callback_query->data;
$Tedad_Nazar = file_get_contents('admin/Tedad Nazar.txt');
$ads = file_get_contents('ads/Ads.txt');
$txtstart = file_get_contents("data/start.txt");
$txthelp = file_get_contents("data/help.txt");
$channel = file_get_contents("data/channel.txt");
$txtshop = file_get_contents("data/shop.txt");
$txtzir = file_get_contents("data/zir.txt");
$txtseen = file_get_contents("data/seen.txt");
$txtcoinlink = file_get_contents("data/coinlink.txt");
$peygiri = file_get_contents("user/$from_id/peygiri.txt");
$idchannel = file_get_contents("ads/ads username/$peygiri.txt");
$idpayam = file_get_contents("ads/ads msg id/$peygiri.txt");
$sefareshtedad = file_get_contents("ads/ads tedad/$peygiri.txt");
$dide = count("ads/ads tally/$peygiri.txt");
$timesabt = file_get_contents("ads/ads time/$peygiri.txt");
$datesabt = file_get_contents("ads/ads date/$peygiri.txt");
$baghi = $sefareshtedad-$dide;
$type = file_get_contents("data/bottype.txt");

// start source
if (strpos($block , "$from_id") !== false) {
 return false;
}
elseif ($from_id != $chat_id and $chat_id != $feed) {
 LeaveChat($chat_id);
}
//===============
elseif($data == 'taiid nzr'){
 AnswerCallbackQuery($data_id,'نظر تایید شد');
 EditMessageText($chatid,$messageid,"نظر تایید شد",'html','true');
 file_put_contents("admin/NZR.txt","$NZR\n(**##**)\n$txt");
}
elseif($data == 'rad nzr'){
 AnswerCallbackQuery($data_id,'نظر رد شد');
 EditMessageText($chatid,$messageid,"نظر رد شد",'html','true');
}
//===============
elseif($data == 'nzr'){
 $exp = explode("(**##**)",$NZR);
 $rand = $exp[rand(0,count($exp)-1)];
 $txtt = file_get_contents('admin/Tedad Nazar.txt');
 $member_id = explode("\n",$txtt);
 $mmemcount = count($member_id) -1;
 if($rand == null || $rand == '' || $rand == "\n"){
  EditMessageText($chatid,$messageid,"⛔️نظر موجود نیست⛔️",'html','true');
 }else{
  AnswerCallbackQuery($data_id,'نظر بعدی');
  EditMessageText($chatid,$messageid,"نظرات: $mmemcount
  $from_id
  $name
  ---
  
  $rand",'html','true',$button_nz);
 }
}
//===============
elseif(preg_match('/^\/([Ss]tart)(.*)/',$text)){
 preg_match('/^\/([Ss]tart)(.*)/',$text,$match);
 $match[2] = str_replace(" ","",$match[2]);
 $match[2] = str_replace("\n","",$match[2]);
 if($match[2] != null){
  if (strpos($Member , "$from_id") == false){
   if($match[2] != $from_id){
    if (strpos($coin , "$from_id") == false){
     $txxt = file_get_contents('user/'.$match[2]."/coin.txt");
     $pmembersid= explode("\n",$txxt);
     if (!in_array($from_id,$pmembersid)){
      $aaddd = file_get_contents('user/'.$match[2]."/coin.txt");
      save('user/'.$match[2]."/coin.txt",$aaddd+$txtcoinlink);
     }
     SendMessage($match[2],"🆕 یک نفر با لینک اختصاصی شما وارد ربات شد","html","true",$button_official_fa);
    }
   }
  }
 }
 if($from_id == $admin ){
  SendMessage($chat_id,"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @Robot_make_bot");
  SendMessage($chat_id,"🌺به ربات خودتون در ساعت $time و در تاریخ $date خوش آمدید😃

برای رفتن به پنل مدیریت روی دکمه ((مدیریت)) بزنید.","html","true",$button_admin);
  SendMessage($chat_id,$txtstart,"html","true",$button_admin);
 }else{
  SendMessage($chat_id,$txtstart,"html","true",$button_official);
 }
}
//==============
//===============
elseif($text == '↩️منوی اصلی'){
 if($from_id == $admin){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_admin);
 }else{
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official);
 }
}
//===============
elseif(preg_match('/^\/([Cc]reator)/',$text)){
 SendMessage($chat_id,"✅ این ربات توسط ( بات ساز @robot_make_bot ) ساخته شده","html","true",$button_official);
}
//===============
elseif($text == 'فروشگاه💌'){
 SendMessage($chat_id,"$txtshop 
  @$channel","html","true",$button_official);
}
//===============
elseif($text == '👤زیرمجموعه گیری'){
 $member_id = explode("\n",$gold);
 $mmemcount = count($member_id) -1;
 SendMessage($chat_id,"$txtzir

 http://telegram.me/$UserNameBot?start=$from_id
  
  تعداد زیرمجموعه های شما: $mmemcount","html","true",$button_official);
}
//===============
elseif($text == 'راهنما📕'){
 SendMessage($chat_id,"$txthelp","html","true",$button_official);
}
//===============
elseif($text == '👤 حساب کاربری من'){
 bot('sendMessage',[
     'chat_id'=>$update->message->chat->id,
     'text'=>"اطلاعات شما👇",
     'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'inline_keyboard'=>[
             [
                 ['text'=>"👇نام شما👇",'url'=>"https://telegram.me/$UserNameBot"]
             ],
             [
                 ['text'=>$name,'url'=>"https://telegram.me/$UserNameBot"]
             ],
             [
                 ['text'=>"👇ایدی عددی شما👇",'url'=>"https://telegram.me/$UserNameBot"]
             ],
             [
                 ['text'=>"🆔 $from_id",'url'=>"https://telegram.me/$UserNameBot"]
             ],
             [
                 ['text'=>"💰تعداد سکه ها👇",'url'=>"https://telegram.me/$UserNameBot"]
             ],
             [
                 ['text'=>"💰 $coin 💰",'url'=>"https://telegram.me/$UserNameBot"]
             ]
         ]
     ])
 ]);
}
//===============
elseif($text == 'نظرات کاربران به ربات📧'){
 $exp = explode("(**##**)",$NZR);
 $rand = $exp[rand(0,count($exp)-1)];
 if($rand == null || $rand == '' || $rand == "\n"){
  SendMessage($chat_id,"⛔️نظر موجود نیست⛔️","html","true");
 }else{
  $txtt = file_get_contents('admin/Tedad Nazar.txt');
  $member_id = explode("\n",$txtt);
  $mmemcount = count($member_id) -1;
  SendMessage($chat_id,"نظرات: $mmemcount
  
  $rand","html","true",$button_nz);
 }
}
//===============
elseif($text == '💸 انتقال سکه'){
 file_put_contents('user/'.$from_id."/command.txt","send coin");
 SendMessage($chat_id,"🔻لطفا پیامی از کاربر مورد نظر فوروارد کنید","html","true",$button_back);
}
elseif($command == 'send coin'){
 $explode = explode("\n",$Member);
 if($forward_id != $from_id && in_array($forward_id,$explode)){
  file_put_contents('user/'.$from_id."/command.txt","send coin2");
  file_put_contents('user/'.$from_id."/wait.txt",$forward_id);
  SendMessage($chat_id,"مقدار سکه شما: $coin
  چه تعداد سکه میخوای انتقال بدی","html","true",$button_back);
 }else{
  SendMessage($chat_id,"شناسه کاربری نا معتبره یا شناسه کاربری خودتون رو وارد کردین","html","true",$button_back);
 }
}
elseif($command == 'send coin2'){
 if(preg_match('/^([0-9])/',$text)){
  if($text > $coin){
   SendMessage($chat_id,"مقدار سکه شما $coin میباشد
  شما مقدار کافی را برای انتقال ندارید","html","true",$button_back);
  }else{
   file_put_contents("user/$wait/coin.txt",($coin_wait+$text) );
   file_put_contents("user/$from_id/coin.txt",($coin-$text) );
   file_put_contents('user/'.$from_id."/command.txt","none");
   SendMessage($chat_id,"انتقال داده شد","html","true",$button_official);
   sendMessage($wait,"💰شما به تعداد $text از طرف $from_id سکه دریافت کردید😀","html","true",$button_official);
  }
 }else{
  SendMessage($chat_id,"فقط باید عدد وارد کنید","html","true",$button_back);
 }
}
//===============
elseif($text == '📨ارسال نظر📨'){
 file_put_contents('user/'.$from_id."/command.txt","contact");
 SendMessage($chat_id,"خوشحالیم که میخواهید نظر بدهید. نظر خود را ارسال کنید به سرعت به دست ادمین ربات میرسد","html","true",$button_back);
}
elseif($command == 'contact'){
 if($text){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"ثبت شد","html","true",$button_official);
  if($from_username == null){
   $from_username = '---';
  }else{
   $from_username = "@$from_username";
  }
  SendMessage($admin,"$from_id
  $from_first
  $from_username
  
  $text","html","true",$button_nza);
  file_put_contents("admin/Tedad Nazar.txt","$Tedad_Nazar\n$from_id");
 }else{
  SendMessage($chat_id,"خطا⚠️
فقط متن مورد قبول برای ارسال میباشد","html","true",$button_back);
 }
}
//===============
elseif($text == '🎯 ثبت تبلیغ'){
 if($coin < 30){
  SendMessage($chat_id,"حداقل سکه باید 30 باشد","html","true");
 }else{
  file_put_contents('user/'.$from_id."/command.txt","set ads");
  if( ($coin%2) == 0){
   $coin = $coin;
  }else{
   $coin = $coin-1;
  }
  $cn = $coin / 2;
  SendMessage($chat_id,"شما میتونید $cn بازدید برای پست بزنید
تعداد بازدیدی که میخواهید را ارسال کنید. توجه داشته باشید که باید کمتر و یا مساوی $cn باشد","html","true",$button_back);
 }
}
elseif($command == 'set ads'){
 if(preg_match('/^([0-9])/',$text)){
  if($coin%2 == 0){
   $coin = $coin;
  }else{
   $coin = $coin-1;
  }
  $cn = $coin / 2;
  if ($cn < $text){
   SendMessage($chat_id,"شما میتونید $cn بازدید برای پست بزنید
تعداد بازدیدی که میخواهید را ارسال کنید. توجه داشته باشید که باید کمتر و یا مساوی $cn باشد","html","true",$button_back);
  }else{
   file_put_contents('user/'.$from_id."/wait.txt",$text);
   file_put_contents('user/'.$from_id."/command.txt","set ads2");
   SendMessage($chat_id,"🔻لطفا بنر خود را از یک کانال عمومی یا خصوصی فوروارد کنید","html","true",$button_back);
  }
 }else{
  SendMessage($chat_id,"فقط باید عدد وارد کنید","html","true",$button_back);
 }
}
elseif ($data == "s") {
 roonx('editMessagetext',[
     'chat_id'=>$chatid,
     'message_id'=>$message_id,
     'text'=>"اطلاعات بنر شما",
     'parse_mode'=>'html',
 ]);
}
elseif($command == 'set ads2'){
 $cd = $code;
 if(isset($update->message->forward_from_chat) && $update->message->forward_from_chat->type = "channel"){
  file_put_contents('user/'.$from_id."/command.txt","none");
  file_put_contents("ads/ads msg id/$cd.txt",$forward_chat_msg_id);
  file_put_contents("ads/ads tedad/$cd.txt",$wait);
  file_put_contents("ads/ads username/$cd.txt",$update->message->forward_from_chat->id);
  file_put_contents("ads/ads tally/$cd.txt",'');
  file_put_contents("ads/Ads.txt","$cd\n$ads");
  file_put_contents("ads/ads admin/$cd.txt",$from_id);
  file_put_contents("user/$from_id/coin.txt",($coin - ($wait*2)) );
  SendMessage($chat_id,"تبلیغ شما در ربات ثبت شد

وضعیت : درحال دریافت ...♻️

کد پیگیری شما 
 $cd","html","true",$button_official);
  $new = file_get_contents("data/ads.txt");
  save("data/ads.txt",$new+1);
 }else{
  SendMessage($chat_id,"خطا⚠️
🔻لطفا بنر خود را از یک کانال عمومی فوروارد کنید","html","true");
 }
}
//==============
elseif($data == "whytabnotsend") {
 EditMessageText($chatid,$messageid,"زیرا👇
♦️متن از کانال حذف شده و یا تعداد سفارش به پایان رسیده است♦️",'html','true');
}
elseif ($data == "s") {
 roonx('editMessagetext',[
     'chat_id'=>$chatid,
     'message_id'=>$message_id,
     'text'=>$fal,
     'parse_mode'=>'html',
     'reply_markup'=>json_encode([
         'inline_keyboard'=>[
             [
                 ['text'=>'دوباره','callback_data'=>'fall']
             ],
             [
                 ['text'=>'برگردیم اول ◀️','callback_data'=>'menu']
             ]
         ]
     ])
 ]);
}
//

elseif($text == '💎جمع آوری سکه رایگان💎'){
 $exp = explode("\n",$ads);
 $rnd = $exp[rand(0,count($exp)-1)];
 $rand = $rnd;
 $adn = file_get_contents("ads/ads admin/$rand.txt");
 if(!is_file("ads/ads msg id/$rand.txt")){
  bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"🌹لطفا صبر کنید...✅

اگر تبلیغ برای شما بعد از 2 ثانیه ارسال نشد مجدد روی دکمه مشاهده تبلیغ بزنید 🙏",
      'parse_mode'=>'html',
      'reply_markup'=>json_encode([
          'inline_keyboard'=>[
              [
                  ['text'=>'چرا تبلیغ ارسال نشد؟🤔','callback_data'=>'whytabnotsend']
              ]]
      ])
  ]);
 }else{
  $msg_id = file_get_contents("ads/ads msg id/$rand.txt");
  $msg_user = file_get_contents("ads/ads username/$rand.txt");
//  bot('sendMessage',[
//      'chat_id'=>$chat_id,
//      'text'=>"🌹لطفا صبر کنید...✅
//
//اگر تبلیغ برای شما بعد از 2 ثانیه ارسال نشد مجدد روی دکمه مشاهده تبلیغ بزنید 🙏",
//      'parse_mode'=>'html',
//      'reply_markup'=>json_encode([
//          'inline_keyboard'=>[
//              [
//                  ['text'=>'چرا تبلیغ ارسال نشد؟🤔','callback_data'=>'whytabnotsend']
//              ]]
//      ])
//  ]);
  ForwardMessage($chat_id,$msg_user,$msg_id);
  $newcoinesh = $coin+$txtseen;
  save("user/$from_id/coin.txt",$newcoinesh);
  $usr = file_get_contents("ads/ads tally/$rand.txt");
  $pmembersid = explode("\n",$usr);
  if (!in_array($from_id,$pmembersid)){
   $aaddd = file_get_contents("ads/ads tally/$rand.txt");
   $aaddd .= $from_id."\n";
   file_put_contents("ads/ads tally/$rand.txt",$aaddd);
  }

  $member_id = explode("\n",$usr);
  $mmemcount = count($member_id);
  $tdd = file_get_contents("ads/ads tedad/$rand.txt");

  if($mmemcount >= $tdd){
   SendMessage($adn,"سفارش تبلیغ با کد پیگیری $rand تمام شد.","html","true");
   $str = str_replace("\n$rand",'',$ads);
   $str = str_replace("$rand",'',$ads);
   file_put_contents("ads/Ads.txt",$str);
   unlink("ads/ads msg id/$rand.txt");
   unlink("ads/ads tedad/$rand.txt");
   unlink("ads/ads username/$rand.txt");
   unlink("ads/ads tally/$rand.txt");
   unlink("ads/ads admin/$rand.txt");
  }
 }
}
//===============
elseif (strpos($text,"🎁 کد رایگان 🎉") !== false) {
 save('user/'.$from_id."/command.txt","useCode");
 var_dump(bot('sendMessage',[
     'chat_id'=>$update->message->chat->id,
     'text'=>"کد هدیه را ارسال کنید 💰 :",
     'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
             [
                 ['text'=>"↩️منوی اصلی"]
             ]
         ],
         'resize_keyboard'=>true
     ])
 ]));
}

elseif ($command == "useCode") {
 if (file_exists("admin/code/$text.txt")) {
  $price = file_get_contents("admin/code/$text.txt");
  $coin = file_get_contents('user/'.$from_id."/coin.txt");
  settype($coin,"integer");
  $newcoin = $coin + $price;
  save("user/".$from_id."/coin.txt",$newcoin);
  unlink("admin/code/$text.txt");
  save('user/'.$from_id."/command.txt","none");
  var_dump(bot('sendMessage',[
      'chat_id'=>$update->message->chat->id,
      'text'=>"به تعداد $price سکه به شما اضافه شد.",
      'parse_mode'=>'MarkDown',
      'reply_markup'=>json_encode([
          'keyboard'=>[
              [['text'=>'💎جمع آوری سکه رایگان💎']],
              [['text'=>'فروشگاه💌'],['text'=>'💸 انتقال سکه'],['text'=>'🎯 ثبت تبلیغ']],
              [['text'=>'👤زیرمجموعه گیری'],['text'=>'👤 حساب کاربری من']],
              [['text'=>'نظرات کاربران به ربات📧']],
              [['text'=>'📨ارسال نظر📨'],['text'=>'راهنما📕']],
              [['text'=>'🎁 کد رایگان 🎉'],['text'=>"📊 پیگیری سفارش"]]
          ]
      ])
  ]));
  sendMessage($channel,"➖➖➖➖➖➖➖➖➖
کد با موفقیت استفاده شد✅
⏰ ساعت ↙️
⏰$time
📆تاریخ↙️
📆$date
🔶🔷🔶🔷🔶🔷🔶🔷🔶

👤 توسط 
👤Name: 
$name
💠
🆔Username: 
@$username
💠

🌐UserID: 
$from_id
💠
💰سکه های دریافت شده↙️
🔆$price
➖➖➖➖➖➖➖➖➖");
 }
 else {
  SendMessage($chat_id,"این کد استفاده شده و یا حذف شده است و شما نمیتونید مجدد استفاده کنید.");
 }
}
//===============
elseif($text == 'مدیریت' and $from_id == $admin){
 SendMessage($chat_id,"به پنل مدیریت خوش اومدید","html","true",$button_manage);
}
elseif($text == 'آمار' and $from_id == $admin){
 $txtt = file_get_contents('admin/Member.txt');
 $member_id = explode("\n",$txtt);
 $mmemcount = count($member_id) -1;
 SendMessage($chat_id,"کل کاربران: $mmemcount نفر","html","true");
}
elseif($text == 'فوروارد همگانی' and $from_id == $admin){
 file_put_contents("user/".$from_id."/command.txt","s2a fwd");
 SendMessage($chat_id,"پیام مورد نظر را فوروارد کنید","html","true",$button_back);
}
elseif($command == 's2a fwd' and $from_id == $admin){
 file_put_contents("user/".$from_id."/command.txt","none");
 SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
 $all_member = fopen( "admin/Member.txt", 'r');
 while( !feof( $all_member)) {
  $user = fgets( $all_member);
  ForwardMessage($user,$admin,$message_id);
 }
}
elseif($text == 'پیام همگانی' and $from_id == $admin){
 file_put_contents("user/".$from_id."/command.txt","s2a");
 SendMessage($chat_id,"پیامتون رو وارد کنید","html","true",$button_back);
}
elseif($command == 's2a' and $from_id == $admin){
 file_put_contents("user/".$from_id."/command.txt","none");
 SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
 $all_member = fopen( "admin/Member.txt", 'r');
 while( !feof( $all_member)) {
  $user = fgets( $all_member);
  if($sticker_id != null){
   SendSticker($user,$stickerid);
  }
  elseif($videoid != null){
   SendVideo($user,$videoid,$caption);
  }
  elseif($voiceid != null){
   SendVoice($user,$voiceid,'',$caption);
  }
  elseif($fileid != null){
   SendDocument($user,$fileid,'',$caption);
  }
  elseif($musicid != null){
   SendAudio($user,$musicid,'',$caption);
  }
  elseif($photoid != null){
   SendPhoto($user,$photoid,'',$caption);
  }
  elseif($text != null){
   SendMessage($user,$text,"html","true");
  }
 }
}
elseif($text == 'تعیین کد رایگان' and $from_id == $admin){
 SendMessage($chat_id,"لطفا جهت ساخت کد هدیه از دستور زیر استفاده کنید:
  /createcode Name Coin","html");
}
elseif (strpos($text,"/createcode") !== false && $from_id == $admin) {
 $text = explode(" ",$text);
 $code = $text['1'];
 $value = $text['2'];
 save("admin/code/$code.txt",$value);
 bot('sendMessage',[
     'chat_id'=>$channel,
     'text'=>"➖➖➖➖➖➖➖➖➖➖➖➖
🔶کد جدید ساخته شد✔️


🏷کد⬅️: 
<code>$code</code>

🎈تعداد سکه: 
💰 <code>$value</code>
➖➖➖➖➖➖➖➖➖➖➖➖
هرکی زود کد بالا رو دا


خل ربات 
<code>$NameBot</code>
در بخش کد هدیه 🏆بزنه برندست🌀😍

🎈ساعت◀️ $time

🎈تاریخ◀️ $date",
     'parse_mode'=>'html',
     'reply_markup'=>json_encode([
         'inline_keyboard'=>[
             [
                 ['text'=>$NameBot,'url'=>"https://telegram.me/$UserNameBot"]
             ]]
     ])
 ]);
}
elseif ($text == "📊 پیگیری سفارش"){
 save("user/$from_id/command.txt","peygiri");
 sendmessage($chat_id,"🔻لطفا کد پیگیری تبلیغ خود را ارسال کنید.","html","true",$button_back);
}
elseif($command == "peygiri"){
 save("user/$from_id/command.txt","none");
 save("user/$from_id/peygiri.txt",$text);
 sendMessage($chat_id,"😄توضیحات بنر شما تا الان👇
 بنرشما: https://telegram.me/$idchannel/$idpayam
 تعداد سفارش : $sefareshtedad
 دیده شده: $dide
 باقی مانده: $baghi
 تاریخ ثبت بنر: $datesabt
 ساعت ثبت بنر: $timesabt","html","true",$button_official);
}
//
elseif($text == "تنظيم متن راهنما" && $from_id == $admin){
 save("user/$from_id/command.txt","sethelptxt");
 sendMessage($chat_id,"لطفا متن راهنما را ارسال کنيد","html","true",$button_back);
}elseif($command == "sethelptxt"){
 save("user/$from_id/command.txt","none");
 save("data/help.txt",$text);
 sendmessage($chat_id,"راهنما ثبت شد.","html","true",$button_manage);
}elseif($text == "تنظيم متن دعوت" && $from_id == $admin){
 save("user/$from_id/command.txt","setzirtxt");
 sendMessage($chat_id,"متني که ميخوايد به عنوان متن دعوت باشد را ارسال کنيد
  
  توجه : لينک دعوت اتوماتيک زير متن قرار ميگيرد","html","true",$button_back);
}elseif($command == "setzirtxt"){
 save("user/$from_id/command.txt","none");
 save("data/zir.txt",$text);
 sendmessage($chat_id," تنظیم شد.","html","true",$button_manage);
}elseif($text == "تنظيم متن استارت" && $from_id == $admin){
 save("user/$from_id/command.txt","setsttxt");
 sendMessage($chat_id,"متن جديد استارت خود را وارد کنيد","html","true",$button_back);
}elseif($command == "setsttxt"){
 save("user/$from_id/command.txt","none");
 save("data/start.txt",$text);
 sendmessage($chat_id," تنظیم شد.","html","true",$button_manage);
}elseif($text == "تنظيم کانال" && $from_id == $admin ){
  save("user/$from_id/command.txt","setch");
  sendMessage($chat_id,"لطفا ایدی کانال خورا بدون @ وارد کنید","html","true",$button_back);
 }
elseif($command == "setch"){
 save("user/$from_id/command.txt","none");
 save("data/channel.txt",$text);
 sendmessage($chat_id," تنظیم شد.","html","true",$button_manage);
}elseif($text == "تنظیم متن فروشگاه" && $from_id == $admin){
 save("user/$from_id/command.txt","setshoptxt");
 sendMessage($chat_id,"لطفا متن قسمت فروشگاه خود را برای
تنظیم ارسال کنید","html","true",$button_back);
}elseif($command == "setshoptxt"){
 save("user/$from_id/command.txt","none");
 save("data/shop.txt",$text);
 sendmessage($chat_id," ثبت شد.","html","true",$button_manage);
}elseif($text == "تنظیم سکه دیدن تبلیغات" && $from_id == $admin){
  save("user/$from_id/command.txt","setseencoin");
  sendMessage($chat_id,"لطفا مقدار سکه ای که میخواهید کاربر با دیدن تبلیغات بدست اورد را به صورتت عدد ارسال کنید","html","true",$button_back);
 }
elseif($command == "setseencoin"){
 save("user/$from_id/command.txt","none");
 save("data/seen.txt",$text);
 sendmessage($chat_id," ثبت شد.","html","true",$button_manage);
}elseif ($text == "کم کردن سکه" && $from_id == $admin){
 sendMessage($chat_id,"ادمین عزیز جهت کم کردن سکه کاربری از دستور زیر استفاده کنید
/getcoin USERID COIN");
}elseif ($text== "اهدای سکه" && $from_id == $admin){
 sendMessage($chat_id,"ادمین عزیز جهت اهدای سکه به کاربری از دستور زیر استفاده کنید
/addcoin USERID COIN");
}elseif (strpos($text,"/getcoin") !== false && $from_id == $admin) {
 $text = explode(" ",$text);
 if ($text['2'] != "" && $text['1'] != "") {
  $coin = file_get_contents("user/".$text['1']."/coin.txt");
  settype($coin,"integer");
  $newcoin = $coin - $text['2'];
  save("user/".$text['1']."/coin.txt",$newcoin);
  SendMessage($chat_id,"عملیات فوق با موفقیت انجام شد");
  SendMessage($text['1'],"ادمین از شما ".$text['2']." سکه کم کرد");
 }
 else {
  SendMessage($chat_id,"Syntax Error!");
 }
}elseif (strpos($text,"/addcoin") !== false && $from_id == $admin) {
 $text = explode(" ",$text);
 if ($text['2'] != "" && $text['1'] != "") {
  $coin = file_get_contents("user/".$text['1']."/coin.txt");
  settype($coin,"integer");
  $newcoin = $coin + $text['2'];
  save("user/".$text['1']."/coin.txt",$newcoin);
  SendMessage($chat_id,"عملیات فوق با موفقیت انجام شد");
  SendMessage($text['1'],"تعداد ".$text['2']." سکه به شما اضافه شد");
 }
 else {
  SendMessage($chat_id,"Syntax Error!");
 }
}elseif($text == "تنظیم سکه عضو گیری" && $from_id == $admin ){
  save("user/$from_id/command.txt","setcoinlink");
  sendMessage($chat_id,"لطفا مقدار سکه موردنظر برای زیرمجموعه گیری را
	 به صورت عدد ارسال کنید","html","true",$button_back);
 }elseif($command == "setcoinlink"){
 save("user/$from_id/command.txt","none");
 save("data/coinlink.txt",$text);
 sendmessage($chat_id," تنظیم شد.","html","true",$button_manage);
}elseif($text == "ویژه کردن اکانت" && $from_id == $admin){
 sendmessage($chat_id,"♨️اکانت شما ویژه می باشد♨️");
}elseif($text == "وضعیت اکانت" && $from_id == $admin){
  sendMessage($chat_id,"اکانت شما ویژه است!");
}
// End Source
if(!file_exists('user/'.$from_id)){
 mkdir('user/'.$from_id);
}
if(!file_exists('user/'.$from_id."/coin.txt")){
 file_put_contents('user/'.$from_id."/coin.txt","1");
}
$txxt = file_get_contents('admin/Member.txt');
$pmembersid= explode("\n",$txxt);
if (!in_array($chat_id,$pmembersid)){
 $aaddd = file_get_contents('admin/Member.txt');
 $aaddd .= $chat_id."\n";
 file_put_contents('admin/Member.txt',$aaddd);
}unlink('error_log');
?>