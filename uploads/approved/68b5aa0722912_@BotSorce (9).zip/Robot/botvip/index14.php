<?php
define('BOT_TOKEN','**TOKEN**');
$admin = "**ADMIN**";
$channel = file_get_contents('channel.txt');
$update = json_decode(urldecode(file_get_contents('php://input')));
$user_id = $update->message->from->id;
$chat_id = $update->message->chat->id;
$name = $update->message->from->first_name;
$text = $update->message->text;
$msg_id = $update->message->message_id;
define('API_TELEGRAM','https://api.telegram.org/bot'.BOT_TOKEN.'/');
function save($filename,$TXTdata) {$myfile = fopen($filename, "w") or die("Unable to open file!");fwrite($myfile, "$TXTdata");fclose($myfile);}
if ($text == '/start') {file_get_contents(API_TELEGRAM.'sendChatAction?chat_id='.$chat_id.'&action=typing'); file_get_contents(API_TELEGRAM.'sendMessage?chat_id='.$chat_id.'&text= 😊سلام '.$name.'\n☺به ربات سین ساز ساخته شده توسط ربات ساز رایگان خوش آمدید😉\n😘این ربات فقط میتونه به ادمین جواب بده😍\n😊خوب شما اول باید کد زیر رو بنویسی بفرستی به من😊\n😀بعد من کانالتو ذخیره میکنم و وقتی چیزی برام بفرستی اونو فروارد میکنم تو کانالت😊\n⚠البته باید منو اول تو کانالت ادمین کنی⚠\n/setchannel ایدی کانالت\n🔰اگه فهمیده باشید بهت گفتم باید اول /setchannel رو بنویسی و با یه فاصله ایدی کانالت رو بنویسی(ایدی عمومیت)🔰');}
elseif (strpos($text, "/setchannel ") !== false && $user_id == $admin) 
{$ch = str_replace("/setchannel ", "" ,$text); save("channel.txt", $ch);
file_get_contents(API_TELEGRAM.'sendMessage?chat_id='.$chat_id.'&text= 😘👍\n😁آفرین \n😊حالا کافیه منو ادمین کانالت '.$channel.' کنی تا هر چی برام بفرستی اونجا و اینجا برات فروارد کنم😊\n😀اونم با اسم تو😀یعنی '.$name.' ' &parse_mode=markdown');}
else {$to_channel = json_decode(urldecode(file_get_contents(API_TELEGRAM.'forwardMessage?chat_id='.$channel.'&from_chat_id='.$chat_id.'&message_id='.$msg_id)))->result->message_id; file_get_contents(API_TELEGRAM.'forwardMessage?chat_id='.$chat_id.'&from_chat_id='.$channel.'&message_id='.$to_channel);}
?>
