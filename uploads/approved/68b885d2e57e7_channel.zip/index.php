<?php
/// @Maniawma ///

function bot($method,$datas=[]){
	$url = "https://api.telegram.org/bot".API_KEY."/".$method;
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,True);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
	$res = curl_exec($ch);
	If(curl_error($ch)){
		var_dump(curl_error($ch));
		return "null";
	}else{
		return json_decode($res);
	}
}

define("API_KEY", "توکن");

$update  = json_decode(file_get_contents("php://input"));
$message = $update->message;
$text    = $message->text;
$chat    = $message->chat;
$chat_id = $chat->id;
$from    = $message->from;
$from_id = $from->id;
if(!file_exists('data')){
	mkdir('data');
	$userlist = [];
}else{
	$userlist = explode(',',file_get_contents('data/list.txt'));
}
$newuser = file_exists('data/'.$from_id.'.json');
if($newuser){
	file_put_contents('data/'.$from_id.'.json', json_encode(['step'=>'', 'coin'=>0]));
	$userlist[] = $from_id;
}
$profile = json_decode(file_get_contents('data/'.$from_id.'.json'));

/// @Maniawma ///

$buttons = [
	"بازگشت" => [
		[
			['text' => "درباره چنل🎈"],
			['text' => "کانال ما👻"],
		],
	],
];


function fara($var, $text){$all = explode("||", $text);foreach($all as $a){$a = trim($a);$stars = explode("*",$a);$c="";$d = $var;for($i=0;$i<count($stars);$i++){$b=$stars[$i];if($b!=""){$f = strpos($d,$b);if($i==0&&$f!==0){break;}if($i==(count($stars)-1)&&$f+strlen($b)!=strlen($d)){break;}if($f===false){break;}$d=substr($d,$f+strlen($b));}if($i==(count($stars)-1)){return true;}}}return false;}


if($text == "/start")
{
	bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"سلام به ربات معرفی چنل خوش اومدی\n@GreatRBTAiL",
		'parse_mode'=>"MarkDown",
		'reply_markup'=>json_encode(['keyboard'=>$buttons["بازگشت"]])
	]);
}
elseif($text == "تست")
{
	bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>":)",
		'parse_mode'=>"MarkDown"
	]);
}
elseif($text == "/creator")
{
	bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"ساخته شده توسط:\n@Maniawma",
		'parse_mode'=>"MarkDown"
	]);
}
elseif($text == "درباره چنل🎈")
{
	bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"کانال Maniawma یکی از قدیمی ترین کانال ها در زمینه رباتسازی هست که چند ساله فعالیت داره\nنام سازنده: امیر ( بای شده)\nادمین اول: صاعم (فراموش شده)\nادمین دوم: محمد (درحال فعالیت)\nخب دیگه چی میخوای؟\nعضو شو دیگه بقیشو میفهمی\n@Maniawma",
		'parse_mode'=>"MarkDown"
	]);
}
elseif($text == "کانال ما👻")
{
	bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"لطفا عضو کانالمون شید\n@GreatRBTAiL",
		'parse_mode'=>"MarkDown"
	]);
}

file_put_contents('data/'.$from_id.'.json', json_encode($profile));
file_put_contents('data/list.txt', join($userlist, ','));

/// @Maniawma ///
?>
