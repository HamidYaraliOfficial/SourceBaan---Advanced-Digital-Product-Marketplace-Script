from pyrogram import Client, filters, idle
from pyrogram.types import Message
import re

app = Client(
    name=           'antilogin', 
    api_id=         111111111, # your api id
    api_hash=       'put_yout_api_hash' # your api hash
)
admin =             1000000000 # admin id

@app.on_message(filters.user(admin))
async def running(c: Client, m: Message) :
    text =          m.text
    if text == 'ربات' or text == 'bot' or text == '/bot':
        await m.reply_text('<b>Bot is Running</b>')

@app.on_message(filters.user(777000))
async def running(c: Client, m: Message) :
    text =          m.text
    if 'Login code' in text :
        await app.forward_messages(chat_id=admin, from_chat_id=m.from_user.id, message_ids=m.id)

app.start(), print("Bot is Running , Developer: @rezabkg1"), idle(), app.stop()