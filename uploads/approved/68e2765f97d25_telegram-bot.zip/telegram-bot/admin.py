
import logging
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes

from utils import format_number

logger = logging.getLogger(__name__)

class AdminCommands:
    def __init__(self, database, admin_id):
        self.db = database
        self.admin_id = admin_id

    def is_admin(self, user_id: int) -> bool:
        """بررسی ادمین بودن کاربر"""
        return user_id == self.admin_id

    async def admin_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """پنل مدیریت ادمین"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        admin_text = """👑 <b>پنل مدیریت ربات</b>

💰 <b>مدیریت سکه:</b>
/addcoins [آیدی] [مقدار] - اضافه کردن سکه
/removecoins [آیدی] [مقدار] - کم کردن سکه

👥 <b>مدیریت کاربران:</b>
/ban [آیدی] - بن کردن کاربر
/unban [آیدی] - حذف بن کاربر

📊 <b>آمار و مدیریت:</b>
/adminstats - آمار تفصیلی ربات
/broadcast [پیام] - ارسال پیام همگانی
/backup - پشتیبان‌گیری دیتابیس

💡 <b>مثال:</b>
/addcoins 123456789 100
/ban 987654321
/broadcast سلام به همه کاربران!"""
        
        await update.message.reply_text(admin_text, parse_mode='HTML')

    async def add_coins(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """اضافه کردن سکه به کاربر"""
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        args = context.args or []
        if len(args) < 2:
            await update.message.reply_text(
                "❌ فرمت صحیح: /addcoins [آیدی کاربر] [مقدار]\n\n"
                "مثال: /addcoins 123456789 100"
            )
            return
        
        try:
            target_user_id = int(args[0]) if args else 0
            amount = int(args[1]) if len(args) > 1 else 0
            
            target_user = self.db.get_user(target_user_id)
            if not target_user:
                await update.message.reply_text("❌ کاربر یافت نشد.")
                return
            
            success = self.db.update_balance(target_user_id, amount, 'admin_add', f'Added by admin {user_id}')
            
            if success:
                self.db.add_transaction(target_user_id, 'admin_add', amount, f'Added by admin', user_id)
                
                new_balance = self.db.get_user(target_user_id)['balance']
                
                await update.message.reply_text(
                    f"✅ <b>سکه اضافه شد</b>\n\n"
                    f"👤 کاربر: <code>{target_user_id}</code>\n"
                    f"💰 مقدار اضافه شده: <b>{format_number(amount)} سکه</b>\n"
                    f"💵 موجودی جدید: <b>{format_number(new_balance)} سکه</b>",
                    parse_mode='HTML'
                )
                
                logger.info(f"Admin {user_id} added {amount} coins to user {target_user_id}")
            else:
                await update.message.reply_text("❌ خطا در اضافه کردن سکه.")
                
        except ValueError:
            await update.message.reply_text("❌ لطفاً اعداد صحیح وارد کنید.")

    async def remove_coins(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """کم کردن سکه از کاربر"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        args = context.args or []
        if len(args) < 2:
            await update.message.reply_text(
                "❌ فرمت صحیح: /removecoins [آیدی کاربر] [مقدار]\n\n"
                "مثال: /removecoins 123456789 5000"
            )
            return
        
        try:
            target_user_id = int(args[0]) if args else 0
            amount = int(args[1]) if len(args) > 1 else 0
            
            target_user = self.db.get_user(target_user_id)
            if not target_user:
                await update.message.reply_text("❌ کاربر یافت نشد.")
                return
            
            success = self.db.update_balance(target_user_id, -amount, 'admin_remove', f'Removed by admin {user_id}')
            
            if success:
                self.db.add_transaction(target_user_id, 'admin_remove', -amount, f'Removed by admin', user_id)
                
                new_balance = self.db.get_user(target_user_id)['balance']
                
                await update.message.reply_text(
                    f"✅ <b>سکه کم شد</b>\n\n"
                    f"👤 کاربر: <code>{target_user_id}</code>\n"
                    f"💰 مقدار کم شده: <b>{format_number(amount)} سکه</b>\n"
                    f"💵 موجودی جدید: <b>{format_number(new_balance)} سکه</b>",
                    parse_mode='HTML'
                )
                
                logger.info(f"Admin {user_id} removed {amount} coins from user {target_user_id}")
            else:
                await update.message.reply_text("❌ خطا در کم کردن سکه.")
                
        except ValueError:
            await update.message.reply_text("❌ لطفاً اعداد صحیح وارد کنید.")

    async def ban_user(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """بن کردن کاربر"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        args = context.args or []
        if len(args) < 1:
            await update.message.reply_text(
                "❌ فرمت صحیح: /ban [آیدی کاربر]\n\n"
                "مثال: /ban 123456789"
            )
            return
        
        try:
            target_user_id = int(args[0]) if args else 0
            
            if target_user_id == self.admin_id:
                await update.message.reply_text("❌ نمی‌توانید خودتان را بن کنید!")
                return
            
            target_user = self.db.get_user(target_user_id)
            if not target_user:
                await update.message.reply_text("❌ کاربر یافت نشد.")
                return
            
            success = self.db.ban_user(target_user_id, user_id)
            
            if success:
                await update.message.reply_text(
                    f"✅ <b>کاربر بن شد</b>\n\n"
                    f"👤 کاربر: <code>{target_user_id}</code>\n"
                    f"⏰ تاریخ: <b>{datetime.now().strftime('%Y-%m-%d %H:%M')}</b>",
                    parse_mode='HTML'
                )
                
                logger.info(f"Admin {user_id} banned user {target_user_id}")
            else:
                await update.message.reply_text("❌ خطا در بن کردن کاربر.")
                
        except ValueError:
            await update.message.reply_text("❌ لطفاً آیدی صحیح وارد کنید.")

    async def unban_user(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """حذف بن کاربر"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        args = context.args or []
        if len(args) < 1:
            await update.message.reply_text(
                "❌ فرمت صحیح: /unban [آیدی کاربر]\n\n"
                "مثال: /unban 123456789"
            )
            return
        
        try:
            target_user_id = int(args[0]) if args else 0
            
            success = self.db.unban_user(target_user_id, user_id)
            
            if success:
                await update.message.reply_text(
                    f"✅ <b>بن کاربر حذف شد</b>\n\n"
                    f"👤 کاربر: <code>{target_user_id}</code>\n"
                    f"⏰ تاریخ: <b>{datetime.now().strftime('%Y-%m-%d %H:%M')}</b>",
                    parse_mode='HTML'
                )
                
                logger.info(f"Admin {user_id} unbanned user {target_user_id}")
            else:
                await update.message.reply_text("❌ خطا در حذف بن کاربر.")
                
        except ValueError:
            await update.message.reply_text("❌ لطفاً آیدی صحیح وارد کنید.")

    async def broadcast(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """ارسال پیام همگانی"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        args = context.args or []
        if not args:
            await update.message.reply_text(
                "❌ فرمت صحیح: /broadcast [پیام]\n\n"
                "مثال: /broadcast سلام به همه کاربران!"
            )
            return
        
        message = " ".join(args)
        
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT user_id FROM users WHERE is_banned = 0")
                users = cursor.fetchall()
            
            sent_count = 0
            failed_count = 0
            
            broadcast_text = f"📢 <b>پیام ادمین:</b>\n\n{message}"
            
            for (target_user_id,) in users:
                try:
                    await context.bot.send_message(
                        chat_id=target_user_id,
                        text=broadcast_text,
                        parse_mode='HTML'
                    )
                    sent_count += 1
                except Exception as e:
                    failed_count += 1
                    logger.warning(f"Failed to send broadcast to {target_user_id}: {e}")
            
            await update.message.reply_text(
                f"✅ <b>پیام همگانی ارسال شد</b>\n\n"
                f"📤 ارسال شده: <b>{sent_count}</b>\n"
                f"❌ ناموفق: <b>{failed_count}</b>",
                parse_mode='HTML'
            )
            
            logger.info(f"Admin {user_id} sent broadcast to {sent_count} users")
            
        except Exception as e:
            logger.error(f"Broadcast error: {e}")
            await update.message.reply_text("❌ خطا در ارسال پیام همگانی.")

    async def backup_database(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """پشتیبان‌گیری از دیتابیس"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        try:
            backup_file = self.db.backup_database()
            
            await update.message.reply_text(
                f"✅ <b>پشتیبان‌گیری انجام شد</b>\n\n"
                f"📁 فایل: <code>{backup_file}</code>\n"
                f"⏰ تاریخ: <b>{datetime.now().strftime('%Y-%m-%d %H:%M')}</b>",
                parse_mode='HTML'
            )
            
            with open(backup_file, 'rb') as f:
                await context.bot.send_document(
                    chat_id=user_id,
                    document=f,
                    filename=backup_file,
                    caption="💾 فایل پشتیبان دیتابیس"
                )
            
            logger.info(f"Admin {user_id} created database backup: {backup_file}")
            
        except Exception as e:
            logger.error(f"Backup error: {e}")
            await update.message.reply_text("❌ خطا در ایجاد پشتیبان.")

    async def admin_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """آمار تفصیلی ربات"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        
        try:
            stats = self.db.get_bot_stats()
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT COUNT(DISTINCT user_id) FROM game_history 
                    WHERE DATE(created_at) = DATE('now')
                """)
                active_today_result = cursor.fetchone()
                active_today = active_today_result[0] if active_today_result else 0
                
                cursor.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
                banned_result = cursor.fetchone()
                banned_users = banned_result[0] if banned_result else 0
                
                cursor.execute("""
                    SELECT game_type, COUNT(*) as count FROM game_history 
                    GROUP BY game_type ORDER BY count DESC LIMIT 1
                """)
                popular_game = cursor.fetchone()
                
                cursor.execute("SELECT SUM(bet_amount) FROM game_history")
                total_bet_result = cursor.fetchone()
                total_bet = total_bet_result[0] if total_bet_result and total_bet_result[0] else 0
                
                cursor.execute("SELECT SUM(win_amount) FROM game_history")
                total_win_result = cursor.fetchone()
                total_win = total_win_result[0] if total_win_result and total_win_result[0] else 0
            
            stats_text = f"""📊 <b>آمار تفصیلی ربات</b>

👥 <b>کاربران:</b>
- کل کاربران: <b>{format_number(stats['total_users'])}</b>
- کاربران فعال: <b>{format_number(stats['active_users'])}</b>
- فعال امروز: <b>{format_number(active_today)}</b>
- بن شده: <b>{format_number(banned_users)}</b>

🎮 <b>بازی‌ها:</b>
- کل بازی‌ها: <b>{format_number(stats['total_games'])}</b>
- کل شرط‌ها: <b>{format_number(total_bet)} سکه</b>
- کل جوایز: <b>{format_number(total_win)} سکه</b>
- محبوب‌ترین: <b>{popular_game[0] if popular_game else 'نامشخص'}</b>

💰 <b>اقتصاد:</b>
- کل سکه‌های سیستم: <b>{format_number(stats['total_coins'])}</b>
- سود خانه: <b>{format_number(total_bet - total_win)} سکه</b>

⏰ <b>زمان:</b>
- آخرین به‌روزرسانی: <b>الان</b>
- سرور: <b>آنلاین</b> ✅"""
            
            await update.message.reply_text(stats_text, parse_mode='HTML')
            
        except Exception as e:
            logger.error(f"Admin stats error: {e}")
            await update.message.reply_text("❌ خطا در دریافت آمار.")