
import os
import logging
import schedule
import time
import threading
from datetime import datetime, timedelta
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, PreCheckoutQueryHandler, filters
from telegram import Update
from telegram.ext import ContextTypes

from database import Database
from handlers import BotHandlers
from admin import AdminCommands
from config import Config
from utils import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

class TelegramBot:
    def __init__(self):
        self.token = Config.BOT_TOKEN
        self.admin_id = Config.ADMIN_ID
        
        self.db = Database()
        
        self.handlers = BotHandlers(self.db, self.admin_id)
        self.admin = AdminCommands(self.db, self.admin_id)
        
        self.application = Application.builder().token(self.token).build()
        
        self.setup_handlers()
        
        logger.info("ربات با موفقیت راه‌اندازی شد")

    def setup_handlers(self):
        """تنظیم هندلرهای ربات با سیستم کلمات کلیدی"""
        self.application.add_handler(CommandHandler("start", self.handlers.start))
        self.application.add_handler(CommandHandler("help", self.handlers.help_command))
        
        self.application.add_handler(CommandHandler("buy", self.handlers.payment_handler.show_buy_menu))
        
        self.application.add_handler(CommandHandler("admin", self.admin.admin_panel))
        self.application.add_handler(CommandHandler("addcoins", self.admin.add_coins))
        self.application.add_handler(CommandHandler("removecoins", self.admin.remove_coins))
        self.application.add_handler(CommandHandler("ban", self.admin.ban_user))
        self.application.add_handler(CommandHandler("unban", self.admin.unban_user))
        self.application.add_handler(CommandHandler("broadcast", self.admin.broadcast))
        self.application.add_handler(CommandHandler("backup", self.admin.backup_database))
        self.application.add_handler(CommandHandler("adminstats", self.admin.admin_stats))
        
        self.application.add_handler(CallbackQueryHandler(self.handlers.payment_handler.handle_package_selection))
        self.application.add_handler(PreCheckoutQueryHandler(self.handlers.payment_handler.handle_pre_checkout))
        self.application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, self.handlers.payment_handler.handle_successful_payment))
        
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handlers.handle_text))
        
        self.application.add_error_handler(self.error_handler)

    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت خطاها"""
        logger.error(f"خطا در به‌روزرسانی {update}: {context.error}")
        
        if hasattr(update, 'message') and update.message:
            try:
                await update.message.reply_text("⚠️ خطایی رخ داده است. لطفاً دوباره تلاش کنید.")
            except Exception:
                pass

    def run_scheduled_tasks(self):
        """اجرای تسک‌های زمان‌بندی شده"""
        schedule.every().day.at("00:00").do(self.db.reset_daily_bonuses)
        schedule.every().hour.do(self.db.backup_database)
        schedule.every(10).minutes.do(self.db.clean_old_logs)
        
        while True:
            schedule.run_pending()
            time.sleep(60)

    def start_bot(self):
        """شروع ربات"""
        try:
            scheduler_thread = threading.Thread(target=self.run_scheduled_tasks, daemon=True)
            scheduler_thread.start()
            
            logger.info("ربات در حال شروع...")
            
            self.application.run_polling(
                poll_interval=2,
                timeout=20,
                bootstrap_retries=5
            )
            
        except Exception as e:
            logger.error(f"خطا در شروع ربات: {e}")
            raise

if __name__ == "__main__":
    try:
        bot = TelegramBot()
        bot.start_bot()
    except KeyboardInterrupt:
        logger.info("ربات توسط کاربر متوقف شد")
    except Exception as e:
        logger.error(f"خطای کلی: {e}")
