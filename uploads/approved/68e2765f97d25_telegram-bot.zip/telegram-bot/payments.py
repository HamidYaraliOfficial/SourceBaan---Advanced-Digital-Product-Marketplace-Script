
import logging
from typing import Dict, Optional, Tuple
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice
from telegram.ext import ContextTypes
from config import Config

logger = logging.getLogger(__name__)

class PaymentHandler:
    def __init__(self, database):
        self.db = database
        self.init_payment_tables()
    
    def init_payment_tables(self):
        """ایجاد جداول پرداخت"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    package_id TEXT NOT NULL,
                    stars_amount INTEGER NOT NULL,
                    coins_amount INTEGER NOT NULL,
                    payment_charge_id TEXT,
                    telegram_payment_charge_id TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    completed_at TIMESTAMP
                )
            ''')
            
            conn.commit()
    
    async def show_buy_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش منوی خرید سکه با Stars"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        if not Config.ENABLE_STARS_PAYMENT:
            await update.message.reply_text(
                "❌ سیستم پرداخت در حال حاضر غیرفعال است.",
                parse_mode='HTML'
            )
            return
        
        keyboard = []
        
        for package_id, package_data in Config.STARS_PACKAGES.items():
            if package_id == 'basic':
                button_text = f"🥉 برنز استارتر\n💰 {package_data['coins']} طلا ← ⭐ {package_data['stars']:,}"
            elif package_id == 'standard':
                button_text = f"🥈 نقره پروفشنال\n💰 {package_data['coins']} طلا ← ⭐ {package_data['stars']:,}"
            else:
                button_text = f"🥇 طلای میلیونری\n💰 {package_data['coins']} طلا ← ⭐ {package_data['stars']:,}"
            
            keyboard.append([
                InlineKeyboardButton(
                    button_text,
                    callback_data=f"buy_{package_id}"
                )
            ])
        
        keyboard.append([
            InlineKeyboardButton("❌ بستن", callback_data="close_buy_menu")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        buy_text = f"""<b>🎰 CASINO ROYAL SHOP 🎰</b>

<tg-spoiler>💎 EXCLUSIVE VIP STORE 💎</tg-spoiler>

<blockquote>💰 Your Balance: <code>{self.db.get_user(user_id)['balance']:,}</code> Gold Coins</blockquote>

<u><b>🔥 HOT DEALS 🔥</b></u>

<pre>🥉 BRONZE STARTER
   → 20 Gold | 25,000 ⭐</pre>

<pre>🥈 SILVER PRO  
   → 50 Gold | 50,000 ⭐</pre>

<pre>🥇 GOLD PREMIUM
   → 200 Gold | 100,000 ⭐</pre>

<blockquote expandable>🎯 <b>VIP BENEFITS</b>
⚡ Instant delivery
🔒 Secure payment
💎 Premium support
🎰 Exclusive games
🎁 Special bonuses</blockquote>

<tg-spoiler>🚀 More gold = More power = More wins!</tg-spoiler>

<i>⭐ Pay with Telegram Stars for instant coins!</i>"""
        
        await update.message.reply_text(
            buy_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    
    async def handle_package_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت انتخاب بسته خرید"""
        if not update.callback_query:
            return
            
        query = update.callback_query
        await query.answer()
        
        data = query.data or ""
        
        if data == "close_buy_menu":
            await query.edit_message_text("منوی خرید بسته شد.")
            return
        
        if not data.startswith("buy_"):
            return
        
        package_id = data.replace("buy_", "")
        
        if package_id not in Config.STARS_PACKAGES:
            await query.edit_message_text("❌ بسته انتخابی معتبر نیست.")
            return
        
        package = Config.STARS_PACKAGES[package_id]
        if not query.from_user:
            await query.edit_message_text("❌ خطا در شناسایی کاربر.")
            return
            
        user_id = query.from_user.id
        
        await self.create_payment_invoice(query, user_id, package_id, package)
    
    async def create_payment_invoice(self, query, user_id: int, package_id: str, package: Dict):
        """ایجاد فاکتور پرداخت Stars"""
        try:
            payment_id = self.record_pending_payment(user_id, package_id, package)
            
            title = package['title']
            description = f"خرید {package['coins']} سکه طلایی از فروشگاه کازینو رویال"
            payload = f"coins_{package_id}_{payment_id}"
            
            stars_amount = int(package['stars'])
            prices = [LabeledPrice(label=f"{package['coins']} سکه طلایی", amount=stars_amount)]
            
            await query.edit_message_text(
                f"🎯 <b>آماده‌سازی فاکتور خرید...</b>\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"🎁 <b>بسته انتخابی:</b> {title}\n"
                f"⭐ <b>مبلغ پرداختی:</b> {stars_amount:,} Stars\n"
                f"🪙 <b>سکه دریافتی:</b> {package['coins']} طلا\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"⏳ <i>فاکتور پرداخت در حال ارسال...</i>\n"
                f"🔒 <i>پرداخت کاملاً امن و مطمئن</i>",
                parse_mode='HTML'
            )
            
            await query.message.reply_invoice(
                title=title,
                description=description,
                payload=payload,
                provider_token="",
                currency="XTR",
                prices=prices,
                start_parameter=f"buy_{package_id}"
            )
            
        except Exception as e:
            logger.error(f"خطا در ایجاد فاکتور: {e}")
            await query.edit_message_text(
                "❌ خطا در ایجاد فاکتور پرداخت. لطفاً دوباره تلاش کنید.",
                parse_mode='HTML'
            )
    
    def record_pending_payment(self, user_id: int, package_id: str, package: Dict) -> int:
        """ثبت تراکنش در انتظار"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO payments (user_id, package_id, stars_amount, coins_amount, status)
                VALUES (?, ?, ?, ?, 'pending')
            ''', (user_id, package_id, package['stars'], package['coins']))
            
            payment_id = cursor.lastrowid
            conn.commit()
            return payment_id
    
    async def handle_pre_checkout(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت پیش‌بررسی پرداخت"""
        query = update.pre_checkout_query
        
        try:
            payload_parts = query.invoice_payload.split('_')
            if len(payload_parts) != 3 or payload_parts[0] != 'coins':
                await query.answer(ok=False, error_message="فاکتور نامعتبر است.")
                return
            
            package_id = payload_parts[1]
            payment_id = int(payload_parts[2])
            
            if package_id not in Config.STARS_PACKAGES:
                await query.answer(ok=False, error_message="بسته انتخابی معتبر نیست.")
                return
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    'SELECT * FROM payments WHERE id = ? AND status = "pending"',
                    (payment_id,)
                )
                payment = cursor.fetchone()
                
                if not payment:
                    await query.answer(ok=False, error_message="تراکنش یافت نشد.")
                    return
            
            await query.answer(ok=True)
            
        except Exception as e:
            logger.error(f"خطا در پیش‌بررسی: {e}")
            await query.answer(ok=False, error_message="خطا در پردازش پرداخت.")
    
    async def handle_successful_payment(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت پرداخت موفق"""
        payment = update.message.successful_payment
        user_id = update.effective_user.id
        
        try:
            payload_parts = payment.invoice_payload.split('_')
            package_id = payload_parts[1]
            payment_id = int(payload_parts[2])
            
            package = Config.STARS_PACKAGES[package_id]
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE payments 
                    SET status = 'completed',
                        payment_charge_id = ?,
                        telegram_payment_charge_id = ?,
                        completed_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (
                    payment.provider_payment_charge_id,
                    payment.telegram_payment_charge_id,
                    payment_id
                ))
                conn.commit()
            
            self.db.update_balance(
                user_id, 
                package['coins'], 
                'purchase', 
                f'خرید بسته {package["title"]} با {package["stars"]} Stars'
            )
            
            self.db.add_transaction(
                user_id,
                'purchase',
                package['coins'],
                f'خرید بسته {package["title"]} با Stars',
                None
            )
            
            user_data = self.db.get_user(user_id)
            
            confirmation_text = f"""🎉 <b>پرداخت با موفقیت انجام شد!</b> 🎉

━━━━━━━━━━━━━━━━━━━━━

💎 <b>خرید شما تکمیل شد:</b>
🎁 <b>بسته:</b> {package['title']}
⭐ <b>پرداخت:</b> {package['stars']:,} Stars
🪙 <b>سکه دریافتی:</b> +{package['coins']} طلا

━━━━━━━━━━━━━━━━━━━━━

💰 <b>موجودی جدید:</b> <code>{user_data['balance']:,}</code> سکه طلا

━━━━━━━━━━━━━━━━━━━━━

🎯 <b>حالا آماده بازی هستید!</b>

🎰 <b>بازی‌های محبوب:</b>
🎲 <code>رولت 10 25</code> - شرط روی شماره 25
🎰 <code>اسلات 5</code> - چرخاندن اسلات
🎯 <code>حدس 15 متوسط 35</code> - حدس عدد
🎲 <code>تاس 8 4</code> - پیش‌بینی تاس

🏆 <i>هر چه بیشتر بازی کنید، شانس برد بیشتری دارید!</i>

🌟 از اعتماد شما سپاسگزاریم! 🌟"""
            
            await update.message.reply_text(
                confirmation_text,
                parse_mode='HTML'
            )
            
            self.db.add_log(
                user_id,
                'stars_payment',
                f'خرید موفق بسته {package_id}: {package["coins"]} سکه با {package["stars"]} Stars'
            )
            
            logger.info(f"پرداخت موفق: کاربر {user_id} - بسته {package_id} - {package['stars']} Stars")
            
        except Exception as e:
            logger.error(f"خطا در پردازش پرداخت موفق: {e}")
            await update.message.reply_text(
                "❌ خطا در پردازش پرداخت. لطفاً با پشتیبانی تماس بگیرید.",
                parse_mode='HTML'
            )
    
    def get_payment_stats(self, user_id: int = None) -> Dict:
        """دریافت آمار پرداخت‌ها"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            
            if user_id:
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total_payments,
                        SUM(stars_amount) as total_stars,
                        SUM(coins_amount) as total_coins
                    FROM payments 
                    WHERE user_id = ? AND status = 'completed'
                ''', (user_id,))
            else:
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total_payments,
                        SUM(stars_amount) as total_stars,
                        SUM(coins_amount) as total_coins
                    FROM payments 
                    WHERE status = 'completed'
                ''')
            
            result = cursor.fetchone()
            return {
                'total_payments': result[0] or 0,
                'total_stars': result[1] or 0,
                'total_coins': result[2] or 0
            }