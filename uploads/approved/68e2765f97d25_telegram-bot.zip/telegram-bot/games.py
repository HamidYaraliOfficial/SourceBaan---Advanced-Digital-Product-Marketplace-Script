
import random
import logging
import json
import time
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Tuple, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
from utils import format_number

logger = logging.getLogger(__name__)

class GameType(Enum):
    """انواع بازی‌ها"""
    ROULETTE = "roulette"
    DICE = "dice"
    GUESS = "guess"
    SLOTS = "slots"
    POKER = "poker"
    BLACKJACK = "blackjack"
    CRASH = "crash"
    WHEEL = "wheel"

class Difficulty(Enum):
    """سطوح سختی"""
    EASY = 1
    MEDIUM = 2
    HARD = 3
    EXPERT = 4
    LEGENDARY = 5

class AchievementType(Enum):
    """انواع دستاوردها"""
    FIRST_WIN = "first_win"
    WIN_STREAK = "win_streak"
    TOTAL_WINS = "total_wins"
    JACKPOT = "jackpot"
    LEVEL_UP = "level_up"
    COINS_EARNED = "coins_earned"
    GAMES_PLAYED = "games_played"
    DAILY_STREAK = "daily_streak"

@dataclass
class GameResult:
    """نتیجه بازی"""
    success: bool
    won: bool
    amount_bet: int
    amount_won: int
    game_data: Dict
    message: str
    achievement_unlocked: Optional[str] = None
    level_up: bool = False
    streak_bonus: int = 0

@dataclass
class Tournament:
    """تورنمنت"""
    id: str
    name: str
    game_type: GameType
    start_time: datetime
    end_time: datetime
    entry_fee: int
    max_participants: int
    prize_pool: int
    participants: List[int]
    status: str

@dataclass
class Achievement:
    """دستاورد"""
    id: str
    name: str
    description: str
    type: AchievementType
    requirement: int
    reward: int
    icon: str

class Games:
    def __init__(self, database):
        self.db = database
        
        from config import Config as config
        self.min_bet = config.MIN_BET
        self.max_bet = config.MAX_BET
        self.vip_max_bet = config.MAX_BET * 10
        
        self.roulette_multipliers = {
            'single': 35,
            'red_black': 2,
            'odd_even': 2,
            'high_low': 2,
            'dozen': 3,
            'column': 3
        }
        
        self.dice_multipliers = {
            'single': config.DICE_MULTIPLIER,
            'pair': 8,
            'triple': 150,
            'sum': {
                7: 5, 8: 6, 9: 7, 10: 8, 11: 10, 12: 12,
                6: 6, 5: 8, 4: 10, 3: 15
            }
        }
        
        self.guess_multipliers = {
            1: config.GUESS_MULTIPLIERS.get(1, 8),
            2: config.GUESS_MULTIPLIERS.get(2, 40),
            3: config.GUESS_MULTIPLIERS.get(3, 80),
            4: 200,
            5: 1000
        }
        
        self.slot_symbols = config.SLOT_SYMBOLS
        self.slot_multipliers = config.SLOT_MULTIPLIERS.copy()
        
        self.vip_levels = {
            0: {'name': 'عادی', 'bonus': 0, 'max_bet_multiplier': 1},
            1: {'name': 'برنز', 'bonus': 5, 'max_bet_multiplier': 2},
            2: {'name': 'نقره', 'bonus': 10, 'max_bet_multiplier': 3},
            3: {'name': 'طلا', 'bonus': 15, 'max_bet_multiplier': 5},
            4: {'name': 'پلاتین', 'bonus': 20, 'max_bet_multiplier': 8},
            5: {'name': 'الماس', 'bonus': 30, 'max_bet_multiplier': 10}
        }
        
        self.achievements = self._init_achievements()
        
        self.active_tournaments = {}
        
        self.global_stats = {
            'total_games': 0,
            'total_bet': 0,
            'total_won': 0,
            'biggest_win': 0,
            'most_active_game': 'roulette'
        }
        
        self.progressive_jackpots = {
            'mini': 100000,
            'minor': 500000,
            'major': 2000000,
            'grand': 10000000
        }
        
        self.game_cooldowns = {
            'roulette': 1,
            'dice': 1,
            'guess': 2,
            'slots': 1,
            'poker': 5,
            'blackjack': 3
        }
        
        self.daily_limits = {
            'max_games': 1000,
            'max_bet_total': 100000000,
            'max_loss_total': 50000000
        }
        
        self.streak_bonuses = {
            3: 0.1,
            5: 0.2,
            10: 0.5,
            20: 1.0,
            50: 2.0
        }
        
        self.roulette_colors = {
            0: 'green',
            **{i: 'red' if i % 2 == 1 else 'black' for i in range(1, 37)}
        }
        
        self.wheel_segments = {
            '🎁': {'probability': 40, 'multiplier': 1.5, 'name': 'هدیه'},
            '💰': {'probability': 25, 'multiplier': 2, 'name': 'سکه'},
            '💎': {'probability': 15, 'multiplier': 3, 'name': 'الماس'},
            '🔥': {'probability': 10, 'multiplier': 5, 'name': 'آتش'},
            '⚡': {'probability': 7, 'multiplier': 10, 'name': 'برق'},
            '🌟': {'probability': 2.5, 'multiplier': 20, 'name': 'ستاره'},
            '👑': {'probability': 0.5, 'multiplier': 100, 'name': 'جک‌پات'}
        }
        
        self.poker_deck = self._create_poker_deck()
        
        self.recent_games = []
        
        self.ranking_system = {
            'bronze': {'min_level': 1, 'max_level': 10},
            'silver': {'min_level': 11, 'max_level': 25},
            'gold': {'min_level': 26, 'max_level': 50},
            'platinum': {'min_level': 51, 'max_level': 100},
            'diamond': {'min_level': 101, 'max_level': 200},
            'master': {'min_level': 201, 'max_level': 500},
            'grandmaster': {'min_level': 501, 'max_level': 1000},
            'legend': {'min_level': 1001, 'max_level': float('inf')}
        }
        
        self.vip_games = {
            'high_roller_roulette': {'min_vip': 3, 'min_bet': 100},
            'platinum_slots': {'min_vip': 4, 'min_bet': 200},
            'diamond_poker': {'min_vip': 5, 'min_bet': 500}
        }
        
        self.time_bonuses = {
            'happy_hour': {
                'start': 20,
                'end': 22,
                'multiplier': 1.5
            },
            'midnight_bonus': {
                'start': 0,
                'end': 2,
                'multiplier': 2.0
            }
        }
        
        self._initialize_systems()

    def _initialize_systems(self):
        """آماده‌سازی سیستم‌های مختلف"""
        try:
            self._setup_advanced_tables()
            
            self._load_global_stats()
            
            self._load_active_tournaments()
            
            logger.info("سیستم بازی‌ها با موفقیت آماده شد")
            
        except Exception as e:
            logger.error(f"خطا در آماده‌سازی سیستم: {e}")

    def _setup_advanced_tables(self):
        """ایجاد جداول پیشرفته"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS achievements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        achievement_id TEXT,
                        unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS tournaments (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        game_type TEXT NOT NULL,
                        start_time TEXT NOT NULL,
                        end_time TEXT NOT NULL,
                        entry_fee INTEGER NOT NULL,
                        max_participants INTEGER NOT NULL,
                        prize_pool INTEGER NOT NULL,
                        status TEXT DEFAULT 'upcoming',
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS tournament_participants (
                        tournament_id TEXT,
                        user_id INTEGER,
                        score INTEGER DEFAULT 0,
                        rank INTEGER DEFAULT 0,
                        joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (tournament_id) REFERENCES tournaments (id),
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS progressive_jackpots (
                        type TEXT PRIMARY KEY,
                        amount INTEGER NOT NULL,
                        last_winner INTEGER,
                        last_win_date TEXT,
                        total_contributions INTEGER DEFAULT 0
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS vip_status (
                        user_id INTEGER PRIMARY KEY,
                        level INTEGER DEFAULT 0,
                        expires_at TEXT,
                        total_spent INTEGER DEFAULT 0,
                        benefits_used TEXT DEFAULT '{}',
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS win_streaks (
                        user_id INTEGER PRIMARY KEY,
                        current_streak INTEGER DEFAULT 0,
                        longest_streak INTEGER DEFAULT 0,
                        last_game_result BOOLEAN,
                        last_game_time TEXT,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS daily_limits (
                        user_id INTEGER,
                        date TEXT,
                        games_played INTEGER DEFAULT 0,
                        total_bet INTEGER DEFAULT 0,
                        total_loss INTEGER DEFAULT 0,
                        PRIMARY KEY (user_id, date),
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS detailed_game_stats (
                        user_id INTEGER,
                        game_type TEXT,
                        total_games INTEGER DEFAULT 0,
                        total_wins INTEGER DEFAULT 0,
                        total_bet INTEGER DEFAULT 0,
                        total_won INTEGER DEFAULT 0,
                        biggest_win INTEGER DEFAULT 0,
                        longest_streak INTEGER DEFAULT 0,
                        last_played TEXT,
                        PRIMARY KEY (user_id, game_type),
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS active_poker_games (
                        user_id INTEGER PRIMARY KEY,
                        cards TEXT NOT NULL,
                        bet_amount INTEGER NOT NULL,
                        stage TEXT DEFAULT 'initial',
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS active_blackjack_games (
                        user_id INTEGER PRIMARY KEY,
                        player_cards TEXT NOT NULL,
                        dealer_cards TEXT NOT NULL,
                        bet_amount INTEGER NOT NULL,
                        stage TEXT DEFAULT 'playing',
                        insurance BOOLEAN DEFAULT FALSE,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_achievements_user ON achievements(user_id)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_tournament_participants ON tournament_participants(tournament_id, user_id)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_detailed_stats ON detailed_game_stats(user_id, game_type)')
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در ایجاد جداول پیشرفته: {e}")

    def _init_achievements(self) -> Dict[str, Achievement]:
        """تعریف تمام دستاوردها"""
        achievements = {
            'first_roulette_win': Achievement(
                'first_roulette_win', 'اولین برد رولت', 'اولین بار در رولت برنده شوید',
                AchievementType.FIRST_WIN, 1, 5, '🎰'
            ),
            'first_dice_win': Achievement(
                'first_dice_win', 'اولین برد تاس', 'اولین بار در تاس برنده شوید',
                AchievementType.FIRST_WIN, 1, 3, '🎲'
            ),
            'first_guess_win': Achievement(
                'first_guess_win', 'اولین برد حدس', 'اولین بار در حدس عدد برنده شوید',
                AchievementType.FIRST_WIN, 1, 8, '🔢'
            ),
            'first_slots_win': Achievement(
                'first_slots_win', 'اولین جک‌پات', 'اولین بار در اسلات برنده شوید',
                AchievementType.FIRST_WIN, 1, 10, '🎰'
            ),
            
            'win_streak_5': Achievement(
                'win_streak_5', 'استریک ۵', '۵ بار پشت سر هم ببرید',
                AchievementType.WIN_STREAK, 5, 25, '🔥'
            ),
            'win_streak_10': Achievement(
                'win_streak_10', 'استریک ۱۰', '۱۰ بار پشت سر هم ببرید',
                AchievementType.WIN_STREAK, 10, 100, '⚡'
            ),
            'win_streak_20': Achievement(
                'win_streak_20', 'استریک ۲۰', '۲۰ بار پشت سر هم ببرید',
                AchievementType.WIN_STREAK, 20, 500, '💫'
            ),
            
            'total_wins_100': Achievement(
                'total_wins_100', 'صد پیروزی', '۱۰۰ بار ببرید',
                AchievementType.TOTAL_WINS, 100, 50, '🏆'
            ),
            'total_wins_500': Achievement(
                'total_wins_500', 'پانصد پیروزی', '۵۰۰ بار ببرید',
                AchievementType.TOTAL_WINS, 500, 250, '👑'
            ),
            'total_wins_1000': Achievement(
                'total_wins_1000', 'هزار پیروزی', '۱۰۰۰ بار ببرید',
                AchievementType.TOTAL_WINS, 1000, 1000, '💎'
            ),
            
            'small_jackpot': Achievement(
                'small_jackpot', 'جک‌پات کوچک', 'حداقل ۱۰۰ سکه در یک بازی ببرید',
                AchievementType.JACKPOT, 100, 20, '💰'
            ),
            'big_jackpot': Achievement(
                'big_jackpot', 'جک‌پات بزرگ', 'حداقل ۱۰۰۰ سکه در یک بازی ببرید',
                AchievementType.JACKPOT, 1000, 200, '💎'
            ),
            'mega_jackpot': Achievement(
                'mega_jackpot', 'مگا جک‌پات', 'حداقل ۱۰۰۰۰ سکه در یک بازی ببرید',
                AchievementType.JACKPOT, 10000, 2000, '🌟'
            ),
            
            'level_10': Achievement(
                'level_10', 'سطح ۱۰', 'به سطح ۱۰ برسید',
                AchievementType.LEVEL_UP, 10, 15, '⭐'
            ),
            'level_50': Achievement(
                'level_50', 'سطح ۵۰', 'به سطح ۵۰ برسید',
                AchievementType.LEVEL_UP, 50, 100, '🔆'
            ),
            'level_100': Achievement(
                'level_100', 'سطح ۱۰۰', 'به سطح ۱۰۰ برسید',
                AchievementType.LEVEL_UP, 100, 500, '💫'
            ),
            
            'coins_earned_1m': Achievement(
                'coins_earned_1m', 'میلیونر', '۱۰۰۰ سکه کسب کنید',
                AchievementType.COINS_EARNED, 1000, 50, '💰'
            ),
            'coins_earned_10m': Achievement(
                'coins_earned_10m', 'ده میلیونر', '۱۰۰۰۰ سکه کسب کنید',
                AchievementType.COINS_EARNED, 10000, 500, '💎'
            ),
            
            'games_played_1000': Achievement(
                'games_played_1000', 'هزار بازی', '۱۰۰۰ بازی انجام دهید',
                AchievementType.GAMES_PLAYED, 1000, 75, '🎮'
            ),
            'games_played_5000': Achievement(
                'games_played_5000', 'پنج هزار بازی', '۵۰۰۰ بازی انجام دهید',
                AchievementType.GAMES_PLAYED, 5000, 500, '🏅'
            ),
            
            'daily_streak_7': Achievement(
                'daily_streak_7', 'یک هفته فعال', '۷ روز پشت سر هم پاداش بگیرید',
                AchievementType.DAILY_STREAK, 7, 30, '📅'
            ),
            'daily_streak_30': Achievement(
                'daily_streak_30', 'یک ماه فعال', '۳۰ روز پشت سر هم پاداش بگیرید',
                AchievementType.DAILY_STREAK, 30, 200, '🗓️'
            )
        }
        
        return achievements

    def _create_poker_deck(self) -> List[Dict]:
        """ایجاد دسته کارت پوکر"""
        suits = ['♠', '♥', '♦', '♣']
        ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
        values = {'A': 14, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                 '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13}
        
        deck = []
        for suit in suits:
            for rank in ranks:
                deck.append({
                    'suit': suit,
                    'rank': rank,
                    'value': values[rank],
                    'display': f'{rank}{suit}'
                })
        
        return deck

    def _load_global_stats(self):
        """بارگذاری آمار جهانی از دیتابیس"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT COUNT(*) as total FROM game_history')
                result = cursor.fetchone()
                if result:
                    self.global_stats['total_games'] = result['total']
                
                cursor.execute('SELECT SUM(bet_amount) as total_bet, SUM(win_amount) as total_won FROM game_history')
                result = cursor.fetchone()
                if result:
                    self.global_stats['total_bet'] = result['total_bet'] or 0
                    self.global_stats['total_won'] = result['total_won'] or 0
                
                cursor.execute('SELECT MAX(win_amount) as biggest FROM game_history WHERE is_win = 1')
                result = cursor.fetchone()
                if result:
                    self.global_stats['biggest_win'] = result['biggest'] or 0
                
                cursor.execute('''
                    SELECT game_type, COUNT(*) as count 
                    FROM game_history 
                    GROUP BY game_type 
                    ORDER BY count DESC 
                    LIMIT 1
                ''')
                result = cursor.fetchone()
                if result:
                    self.global_stats['most_active_game'] = result['game_type']
                    
        except Exception as e:
            logger.error(f"خطا در بارگذاری آمار جهانی: {e}")

    def _load_active_tournaments(self):
        """بارگذاری تورنمنت‌های فعال"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM tournaments 
                    WHERE status IN ('upcoming', 'active')
                ''')
                
                for row in cursor.fetchall():
                    tournament_data = dict(row)
                    
                    cursor.execute('''
                        SELECT user_id FROM tournament_participants 
                        WHERE tournament_id = ?
                    ''', (tournament_data['id'],))
                    
                    participants = [p['user_id'] for p in cursor.fetchall()]
                    
                    tournament = Tournament(
                        id=tournament_data['id'],
                        name=tournament_data['name'],
                        game_type=GameType(tournament_data['game_type']),
                        start_time=datetime.fromisoformat(tournament_data['start_time']),
                        end_time=datetime.fromisoformat(tournament_data['end_time']),
                        entry_fee=tournament_data['entry_fee'],
                        max_participants=tournament_data['max_participants'],
                        prize_pool=tournament_data['prize_pool'],
                        participants=participants,
                        status=tournament_data['status']
                    )
                    
                    self.active_tournaments[tournament.id] = tournament
                    
        except Exception as e:
            logger.error(f"خطا در بارگذاری تورنمنت‌ها: {e}")

    def validate_bet(self, user_id: int, bet_amount: int, game_type: Optional[str] = None) -> Tuple[bool, str]:
        """اعتبارسنجی جامع مبلغ شرط‌بندی"""
        try:
            if bet_amount <= 0:
                return False, "❌ مبلغ شرط‌بندی باید مثبت باشد!"
            
            user_data = self.db.get_user(user_id)
            if not user_data:
                return False, "❌ کاربر یافت نشد!"
            
            if user_data['balance'] < bet_amount:
                return False, f"❌ موجودی کافی نیست! موجودی شما: {format_number(user_data['balance'])} سکه"
            
            vip_level = self._get_vip_level(user_id)
            max_bet = self.max_bet
            if vip_level > 0:
                max_bet = self.vip_max_bet
            
            if bet_amount < self.min_bet:
                return False, f"❌ حداقل مبلغ شرط‌بندی {format_number(self.min_bet)} سکه است!"
            
            if bet_amount > max_bet:
                return False, f"❌ حداکثر مبلغ شرط‌بندی {format_number(max_bet)} سکه است!"
            
            daily_check = self._check_daily_limits(user_id, bet_amount)
            if not daily_check[0]:
                return False, daily_check[1]
            
            if game_type and not self._check_game_cooldown(user_id, game_type):
                cooldown = self.game_cooldowns.get(game_type, 1)
                return False, f"❌ لطفاً {cooldown} ثانیه صبر کنید!"
            
            return True, "موفق"
            
        except Exception as e:
            logger.error(f"خطا در اعتبارسنجی شرط‌بندی: {e}")
            return False, "❌ خطا در بررسی شرط‌بندی!"

    def _get_vip_level(self, user_id: int) -> int:
        """دریافت سطح VIP کاربر"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT level, expires_at FROM vip_status 
                    WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)
                ''', (user_id, datetime.now().isoformat()))
                
                result = cursor.fetchone()
                return result['level'] if result else 0
                
        except Exception as e:
            logger.error(f"خطا در دریافت سطح VIP: {e}")
            return 0

    def _check_daily_limits(self, user_id: int, bet_amount: int) -> Tuple[bool, str]:
        """بررسی محدودیت‌های روزانه"""
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT games_played, total_bet, total_loss 
                    FROM daily_limits 
                    WHERE user_id = ? AND date = ?
                ''', (user_id, today))
                
                result = cursor.fetchone()
                if not result:
                    cursor.execute('''
                        INSERT INTO daily_limits (user_id, date, games_played, total_bet, total_loss)
                        VALUES (?, ?, 0, 0, 0)
                    ''', (user_id, today))
                    conn.commit()
                    return True, "موفق"
                
                if result['games_played'] >= self.daily_limits['max_games']:
                    return False, f"❌ حداکثر {self.daily_limits['max_games']} بازی در روز!"
                
                if result['total_bet'] + bet_amount > self.daily_limits['max_bet_total']:
                    remaining = self.daily_limits['max_bet_total'] - result['total_bet']
                    return False, f"❌ حداکثر {format_number(remaining)} سکه شرط‌بندی امروز باقی مانده!"
                
                return True, "موفق"
                
        except Exception as e:
            logger.error(f"خطا در بررسی محدودیت‌های روزانه: {e}")
            return True, "موفق"

    def _check_game_cooldown(self, user_id: int, game_type: str) -> bool:
        """بررسی کولداون بازی"""
        try:
            cooldown_key = f"cooldown_{user_id}_{game_type}"
            current_time = time.time()
            
            if not hasattr(self, '_cooldowns'):
                self._cooldowns = {}
            
            last_play_time = self._cooldowns.get(cooldown_key, 0)
            cooldown_duration = self.game_cooldowns.get(game_type, 1)
            
            if current_time - last_play_time < cooldown_duration:
                return False
            
            self._cooldowns[cooldown_key] = current_time
            return True
            
        except Exception as e:
            logger.error(f"خطا در بررسی کولداون: {e}")
            return True

    def _update_daily_limits(self, user_id: int, bet_amount: int, loss_amount: int = 0):
        """به‌روزرسانی محدودیت‌های روزانه"""
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO daily_limits 
                    (user_id, date, games_played, total_bet, total_loss)
                    VALUES (
                        ?, ?, 
                        COALESCE((SELECT games_played FROM daily_limits WHERE user_id = ? AND date = ?), 0) + 1,
                        COALESCE((SELECT total_bet FROM daily_limits WHERE user_id = ? AND date = ?), 0) + ?,
                        COALESCE((SELECT total_loss FROM daily_limits WHERE user_id = ? AND date = ?), 0) + ?
                    )
                ''', (user_id, today, user_id, today, user_id, today, bet_amount, user_id, today, loss_amount))
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در به‌روزرسانی محدودیت‌های روزانه: {e}")

    def _check_and_update_streak(self, user_id: int, won: bool) -> int:
        """بررسی و به‌روزرسانی استریک برد"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT current_streak, longest_streak FROM win_streaks 
                    WHERE user_id = ?
                ''', (user_id,))
                
                result = cursor.fetchone()
                if not result:
                    new_streak = 1 if won else 0
                    cursor.execute('''
                        INSERT INTO win_streaks 
                        (user_id, current_streak, longest_streak, last_game_result, last_game_time)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (user_id, new_streak, new_streak, won, datetime.now().isoformat()))
                    conn.commit()
                    return new_streak
                
                current_streak = result['current_streak']
                longest_streak = result['longest_streak']
                
                if won:
                    new_streak = current_streak + 1
                    new_longest = max(longest_streak, new_streak)
                else:
                    new_streak = 0
                    new_longest = longest_streak
                
                cursor.execute('''
                    UPDATE win_streaks 
                    SET current_streak = ?, longest_streak = ?, 
                        last_game_result = ?, last_game_time = ?
                    WHERE user_id = ?
                ''', (new_streak, new_longest, won, datetime.now().isoformat(), user_id))
                
                conn.commit()
                return new_streak
                
        except Exception as e:
            logger.error(f"خطا در به‌روزرسانی استریک: {e}")
            return 0

    def _calculate_streak_bonus(self, user_id: int, base_amount: int) -> int:
        """محاسبه بونوس استریک"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT current_streak FROM win_streaks WHERE user_id = ?
                ''', (user_id,))
                
                result = cursor.fetchone()
                if not result:
                    return 0
                
                streak = result['current_streak']
                
                bonus_multiplier = 0
                for min_streak, multiplier in sorted(self.streak_bonuses.items()):
                    if streak >= min_streak:
                        bonus_multiplier = multiplier
                    else:
                        break
                
                return int(base_amount * bonus_multiplier)
                
        except Exception as e:
            logger.error(f"خطا در محاسبه بونوس استریک: {e}")
            return 0

    def _apply_time_bonus(self, amount: int) -> int:
        """اعمال بونوس زمانی"""
        try:
            current_hour = datetime.now().hour
            
            for bonus_name, bonus_info in self.time_bonuses.items():
                start_hour = bonus_info['start']
                end_hour = bonus_info['end']
                
                if start_hour <= end_hour:
                    if start_hour <= current_hour <= end_hour:
                        return int(amount * bonus_info['multiplier'])
                else:
                    if current_hour >= start_hour or current_hour <= end_hour:
                        return int(amount * bonus_info['multiplier'])
            
            return amount
            
        except Exception as e:
            logger.error(f"خطا در اعمال بونوس زمانی: {e}")
            return amount

    def _check_achievements(self, user_id: int, game_type: str, won: bool, amount_won: int) -> Optional[str]:
        """بررسی و باز کردن دستاوردها"""
        try:
            unlocked_achievements = []
            
            user_stats = self._get_user_detailed_stats(user_id)
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                for achievement_id, achievement in self.achievements.items():
                    cursor.execute('''
                        SELECT 1 FROM achievements 
                        WHERE user_id = ? AND achievement_id = ?
                    ''', (user_id, achievement_id))
                    
                    if cursor.fetchone():
                        continue
                    
                    should_unlock = False
                    
                    if achievement.type == AchievementType.FIRST_WIN and won:
                        if achievement_id == f'first_{game_type}_win':
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.WIN_STREAK:
                        current_streak = self._get_current_streak(user_id)
                        if current_streak >= achievement.requirement:
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.TOTAL_WINS:
                        total_wins = user_stats.get('total_wins', 0)
                        if total_wins >= achievement.requirement:
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.JACKPOT and won:
                        if amount_won >= achievement.requirement:
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.LEVEL_UP:
                        user_data = self.db.get_user(user_id)
                        if user_data and user_data['level'] >= achievement.requirement:
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.COINS_EARNED:
                        total_earned = user_stats.get('total_won', 0)
                        if total_earned >= achievement.requirement:
                            should_unlock = True
                    
                    elif achievement.type == AchievementType.GAMES_PLAYED:
                        total_games = user_stats.get('total_games', 0)
                        if total_games >= achievement.requirement:
                            should_unlock = True
                    
                    if should_unlock:
                        cursor.execute('''
                            INSERT INTO achievements (user_id, achievement_id)
                            VALUES (?, ?)
                        ''', (user_id, achievement_id))
                        
                        self.db.update_balance(
                            user_id, achievement.reward, 'achievement', 
                            f'دستاورد: {achievement.name}'
                        )
                        
                        unlocked_achievements.append(achievement.name)
                
                conn.commit()
                
                if unlocked_achievements:
                    return f"🏆 دستاورد جدید: {', '.join(unlocked_achievements)}"
                
                return None
                
        except Exception as e:
            logger.error(f"خطا در بررسی دستاوردها: {e}")
            return None

    def _get_current_streak(self, user_id: int) -> int:
        """دریافت استریک فعلی کاربر"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT current_streak FROM win_streaks WHERE user_id = ?
                ''', (user_id,))
                
                result = cursor.fetchone()
                return result['current_streak'] if result else 0
                
        except Exception as e:
            logger.error(f"خطا در دریافت استریک: {e}")
            return 0

    def _get_user_detailed_stats(self, user_id: int) -> Dict:
        """دریافت آمار تفصیلی کاربر"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT 
                        SUM(total_games) as total_games,
                        SUM(total_wins) as total_wins,
                        SUM(total_bet) as total_bet,
                        SUM(total_won) as total_won,
                        MAX(biggest_win) as biggest_win
                    FROM detailed_game_stats 
                    WHERE user_id = ?
                ''', (user_id,))
                
                result = cursor.fetchone()
                if result:
                    return {
                        'total_games': result['total_games'] or 0,
                        'total_wins': result['total_wins'] or 0,
                        'total_bet': result['total_bet'] or 0,
                        'total_won': result['total_won'] or 0,
                        'biggest_win': result['biggest_win'] or 0
                    }
                
                return {}
                
        except Exception as e:
            logger.error(f"خطا در دریافت آمار تفصیلی: {e}")
            return {}

    def _update_detailed_stats(self, user_id: int, game_type: str, bet_amount: int, 
                              won: bool, win_amount: int):
        """به‌روزرسانی آمار تفصیلی"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM detailed_game_stats 
                    WHERE user_id = ? AND game_type = ?
                ''', (user_id, game_type))
                
                current_stats = cursor.fetchone()
                now = datetime.now().isoformat()
                
                if current_stats:
                    new_total_games = current_stats['total_games'] + 1
                    new_total_wins = current_stats['total_wins'] + (1 if won else 0)
                    new_total_bet = current_stats['total_bet'] + bet_amount
                    new_total_won = current_stats['total_won'] + win_amount
                    new_biggest_win = max(current_stats['biggest_win'], win_amount)
                    
                    current_streak = self._get_current_streak(user_id)
                    new_longest_streak = max(current_stats['longest_streak'], current_streak)
                    
                    cursor.execute('''
                        UPDATE detailed_game_stats 
                        SET total_games = ?, total_wins = ?, total_bet = ?, 
                            total_won = ?, biggest_win = ?, longest_streak = ?, 
                            last_played = ?
                        WHERE user_id = ? AND game_type = ?
                    ''', (new_total_games, new_total_wins, new_total_bet, 
                          new_total_won, new_biggest_win, new_longest_streak, 
                          now, user_id, game_type))
                else:
                    cursor.execute('''
                        INSERT INTO detailed_game_stats 
                        (user_id, game_type, total_games, total_wins, total_bet, 
                         total_won, biggest_win, longest_streak, last_played)
                        VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?)
                    ''', (user_id, game_type, 1 if won else 0, bet_amount, 
                          win_amount, win_amount, 1 if won else 0, now))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در به‌روزرسانی آمار تفصیلی: {e}")

    async def play_roulette(self, user_id: int, bet_amount: int, chosen_number: int) -> str:
        """بازی رولت پیشرفته"""
        try:
            is_valid, message = self.validate_bet(user_id, bet_amount, 'roulette')
            if not is_valid:
                return message
            
            if chosen_number < 0 or chosen_number > 36:
                return "❌ شماره باید بین 0 تا 36 باشد!"
            
            self.db.update_balance(user_id, -bet_amount, 'game_bet', f'شرط‌بندی رولت - شماره {chosen_number}')
            
            winning_number = random.randint(0, 36)
            
            color_data = self._get_roulette_number_info(winning_number)
            chosen_color_data = self._get_roulette_number_info(chosen_number)
            
            is_win = chosen_number == winning_number
            win_amount = 0
            
            if is_win:
                win_amount = bet_amount * self.roulette_multipliers['single']
                
                streak_bonus = self._calculate_streak_bonus(user_id, win_amount)
                win_amount += streak_bonus
                
                win_amount = self._apply_time_bonus(win_amount)
                
                vip_level = self._get_vip_level(user_id)
                if vip_level > 0:
                    vip_bonus = int(win_amount * self.vip_levels[vip_level]['bonus'] / 100)
                    win_amount += vip_bonus
                
                self.db.update_balance(user_id, win_amount, 'game_win', f'برد رولت - شماره {winning_number}')
            
            new_streak = self._check_and_update_streak(user_id, is_win)
            self._update_detailed_stats(user_id, 'roulette', bet_amount, is_win, win_amount)
            self._update_daily_limits(user_id, bet_amount, 0 if is_win else bet_amount)
            
            achievement_msg = self._check_achievements(user_id, 'roulette', is_win, win_amount)
            
            user_data = self.db.get_user(user_id)
            
            if is_win:
                result_text = f"""
🎰 <b>نتیجه رولت</b>

🎯 شماره شما: {chosen_number} {chosen_color_data['emoji']}
🎲 شماره برنده: {winning_number} {color_data['emoji']}

🎉 <b>تبریک! شما بردید!</b>
💰 برد شما: {format_number(win_amount)} سکه
💳 موجودی جدید: {format_number(user_data['balance'])} سکه
            
            if achievement_msg:
                result_text += f"\n{achievement_msg}"
            
            game_data = {
                'chosen_number': chosen_number,
                'winning_number': winning_number,
                'color': color_data['color']
            }
            
            self.db.add_game_history(
                user_id, 'roulette', bet_amount, 
                f"شماره {chosen_number} vs {winning_number}",
                win_amount, is_win, game_data
            )
            
            return result_text
            
        except Exception as e:
            logger.error(f"خطا در بازی رولت: {e}")
            return "❌ خطا در اجرای بازی! لطفاً دوباره تلاش کنید."

    def _get_roulette_number_info(self, number: int) -> Dict:
        """دریافت اطلاعات شماره رولت"""
        if number == 0:
            return {'color': 'green', 'name': 'سبز', 'emoji': '🟢'}
        elif number % 2 == 1:
            return {'color': 'red', 'name': 'قرمز', 'emoji': '🔴'}
        else:
            return {'color': 'black', 'name': 'سیاه', 'emoji': '⚫'}

    async def play_dice(self, user_id: int, bet_amount: int, prediction: int) -> str:
        """بازی تاس پیشرفته"""
        try:
            is_valid, message = self.validate_bet(user_id, bet_amount, 'dice')
            if not is_valid:
                return message
            
            if prediction < 1 or prediction > 6:
                return "❌ پیش‌بینی باید بین 1 تا 6 باشد!"
            
            self.db.update_balance(user_id, -bet_amount, 'game_bet', f'شرط‌بندی تاس - پیش‌بینی {prediction}')
            
            dice_results = [random.randint(1, 6) for _ in range(3)]
            dice_sum = sum(dice_results)
            
            win_amount = 0
            win_type = ""
            
            if prediction in dice_results:
                count = dice_results.count(prediction)
                if count == 1:
                    win_amount = bet_amount * self.dice_multipliers['single']
                    win_type = f"یک تاس {prediction}"
                elif count == 2:
                    win_amount = bet_amount * self.dice_multipliers['pair']
                    win_type = f"دو تاس {prediction}"
                elif count == 3:
                    win_amount = bet_amount * self.dice_multipliers['triple']
                    win_type = f"سه تاس {prediction} - جک‌پات!"
            
            is_win = win_amount > 0
            
            if is_win:
                streak_bonus = self._calculate_streak_bonus(user_id, win_amount)
                win_amount += streak_bonus
                
                win_amount = self._apply_time_bonus(win_amount)
                
                self.db.update_balance(user_id, win_amount, 'game_win', f'برد تاس - {win_type}')
            
            new_streak = self._check_and_update_streak(user_id, is_win)
            self._update_detailed_stats(user_id, 'dice', bet_amount, is_win, win_amount)
            self._update_daily_limits(user_id, bet_amount, 0 if is_win else bet_amount)
            
            achievement_msg = self._check_achievements(user_id, 'dice', is_win, win_amount)
            
            user_data = self.db.get_user(user_id)
            dice_emojis = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
            dice_display = ' '.join([dice_emojis[d-1] for d in dice_results])
            
            if is_win:
                result_text = f"""
🎲 <b>نتیجه تاس</b>

🎯 پیش‌بینی شما: {prediction}
🎲 نتیجه تاس‌ها: {dice_display}
🔢 اعداد: {' - '.join(map(str, dice_results))} (مجموع: {dice_sum})

🎉 <b>تبریک! {win_type}</b>
💰 برد شما: {format_number(win_amount)} سکه
💳 موجودی جدید: {format_number(user_data['balance'])} سکه
            
            if achievement_msg:
                result_text += f"\n{achievement_msg}"
            
            game_data = {
                'prediction': prediction,
                'dice_results': dice_results,
                'dice_sum': dice_sum,
                'win_type': win_type
            }
            
            self.db.add_game_history(
                user_id, 'dice', bet_amount,
                f"پیش‌بینی {prediction} vs {dice_results}",
                win_amount, is_win, game_data
            )
            
            return result_text
            
        except Exception as e:
            logger.error(f"خطا در بازی تاس: {e}")
            return "❌ خطا در اجرای بازی! لطفاً دوباره تلاش کنید."

    async def play_guess(self, user_id: int, bet_amount: int, level: int, guess: int) -> str:
        """بازی حدس عدد پیشرفته با 5 سطح"""
        try:
            is_valid, message = self.validate_bet(user_id, bet_amount, 'guess')
            if not is_valid:
                return message
            
            if level not in [1, 2, 3, 4, 5]:
                return "❌ سطح باید بین 1 تا 5 باشد!"
            
            level_ranges = {
                1: (1, 10),
                2: (1, 50), 
                3: (1, 100),
                4: (1, 500),
                5: (1, 1000)
            }
            
            min_num, max_num = level_ranges[level]
            multiplier = self.guess_multipliers[level]
            
            if guess < min_num or guess > max_num:
                return f"❌ حدس باید بین {min_num} تا {max_num} باشد!"
            
            self.db.update_balance(user_id, -bet_amount, 'game_bet', f'شرط‌بندی حدس عدد - سطح {level}')
            
            winning_number = random.randint(min_num, max_num)
            
            distance = abs(guess - winning_number)
            max_distance = max_num - min_num
            accuracy_percentage = ((max_distance - distance) / max_distance) * 100
            
            win_amount = 0
            win_type = ""
            
            if guess == winning_number:
                win_amount = bet_amount * multiplier
                win_type = "حدس دقیق!"
                
                if level >= 4:
                    bonus = int(win_amount * 0.5)
                    win_amount += bonus
                    win_type += " + بونوس سطح بالا"
                    
            elif distance <= 3:
                close_multiplier = max(1, multiplier // 10)
                win_amount = bet_amount * close_multiplier
                win_type = f"حدس نزدیک (فاصله {distance})"
                
            elif distance <= 10 and level <= 2:
                medium_multiplier = max(1, multiplier // 20)
                win_amount = bet_amount * medium_multiplier
                win_type = f"حدس متوسط (فاصله {distance})"
            
            is_win = win_amount > 0
            
            if is_win:
                if accuracy_percentage > 95:
                    accuracy_bonus = int(win_amount * 0.2)
                    win_amount += accuracy_bonus
                
                streak_bonus = self._calculate_streak_bonus(user_id, win_amount)
                win_amount += streak_bonus
                
                win_amount = self._apply_time_bonus(win_amount)
                
                self.db.update_balance(user_id, win_amount, 'game_win', f'برد حدس عدد - سطح {level}')
            
            new_streak = self._check_and_update_streak(user_id, is_win)
            self._update_detailed_stats(user_id, 'guess', bet_amount, is_win, win_amount)
            self._update_daily_limits(user_id, bet_amount, 0 if is_win else bet_amount)
            
            achievement_msg = self._check_achievements(user_id, 'guess', is_win, win_amount)
            
            level_names = {1: "آسان", 2: "متوسط", 3: "سخت", 4: "خیلی سخت", 5: "افسانه‌ای"}
            
            user_data = self.db.get_user(user_id)
            
            if is_win:
                result_text = f"""
🔢 <b>نتیجه حدس عدد</b>

📊 سطح: {level_names[level]} ({min_num}-{max_num})
🎯 حدس شما: {guess}
🎲 عدد برنده: {winning_number}
📏 فاصله: {distance}
🎯 دقت: {accuracy_percentage:.1f}%

🎉 <b>{win_type}!</b>
💰 برد شما: {format_number(win_amount)} سکه (ضریب {multiplier}x)
💳 موجودی جدید: {format_number(user_data['balance'])} سکه
            
            if achievement_msg:
                result_text += f"\n{achievement_msg}"
            
            game_data = {
                'level': level,
                'guess': guess,
                'winning_number': winning_number,
                'distance': distance,
                'accuracy': accuracy_percentage,
                'win_type': win_type
            }
            
            self.db.add_game_history(
                user_id, 'guess', bet_amount,
                f"سطح {level}: حدس {guess} vs {winning_number}",
                win_amount, is_win, game_data
            )
            
            return result_text
            
        except Exception as e:
            logger.error(f"خطا در بازی حدس عدد: {e}")
            return "❌ خطا در اجرای بازی! لطفاً دوباره تلاش کنید."

    async def play_slots(self, user_id: int, bet_amount: int) -> str:
        """بازی اسلات ماشین پیشرفته"""
        try:
            is_valid, message = self.validate_bet(user_id, bet_amount, 'slots')
            if not is_valid:
                return message
            
            self.db.update_balance(user_id, -bet_amount, 'game_bet', 'شرط‌بندی اسلات ماشین')
            
            slot_weights = [30, 25, 20, 15, 7, 2, 1]
            reels = []
            for _ in range(5):
                symbol = random.choices(self.slot_symbols, weights=slot_weights, k=1)[0]
                reels.append(symbol)
            
            win_analysis = self._analyze_slot_result(reels, bet_amount)
            
            total_win = win_analysis['total_win']
            is_win = total_win > 0
            
            if self._check_progressive_jackpot(reels):
                jackpot_win = self._win_progressive_jackpot(user_id, 'mini')
                total_win += jackpot_win
                win_analysis['jackpot'] = jackpot_win
            
            if is_win:
                streak_bonus = self._calculate_streak_bonus(user_id, total_win)
                total_win += streak_bonus
                
                total_win = self._apply_time_bonus(total_win)
                
                self.db.update_balance(user_id, total_win, 'game_win', f'برد اسلات - {win_analysis["win_type"]}')
            
            new_streak = self._check_and_update_streak(user_id, is_win)
            self._update_detailed_stats(user_id, 'slots', bet_amount, is_win, total_win)
            self._update_daily_limits(user_id, bet_amount, 0 if is_win else bet_amount)
            
            self._contribute_to_jackpot(bet_amount)
            
            achievement_msg = self._check_achievements(user_id, 'slots', is_win, total_win)
            
            user_data = self.db.get_user(user_id)
            reel_display = ' | '.join(reels)
            
            if is_win:
                result_text = f"""
🎰 <b>اسلات ماشین</b>

🎲 [ {reel_display} ]

🎉 <b>{win_analysis['win_type']}!</b>
💰 برد شما: {format_number(total_win)} سکه
💳 موجودی جدید: {format_number(user_data['balance'])} سکه

📊 <b>جزئیات برد:</b>
            
            if achievement_msg:
                result_text += f"\n{achievement_msg}"
            
            game_data = {
                'reels': reels,
                'win_analysis': win_analysis
            }
            
            self.db.add_game_history(
                user_id, 'slots', bet_amount,
                f"اسلات: {' | '.join(reels)}",
                total_win, is_win, game_data
            )
            
            return result_text
            
        except Exception as e:
            logger.error(f"خطا در بازی اسلات: {e}")
            return "❌ خطا در اجرای بازی! لطفاً دوباره تلاش کنید."

    def _analyze_slot_result(self, reels: List[str], bet_amount: int) -> Dict:
        """تحلیل نتیجه اسلات"""
        analysis = {
            'total_win': 0,
            'win_type': '',
            'details': []
        }
        
        symbol_counts = {}
        for symbol in reels:
            symbol_counts[symbol] = symbol_counts.get(symbol, 0) + 1
        
        max_count = max(symbol_counts.values())
        
        if max_count >= 5:
            symbol = [s for s, c in symbol_counts.items() if c == 5][0]
            multiplier = self.slot_multipliers[symbol] * 5
            win_amount = bet_amount * multiplier
            analysis['total_win'] = win_amount
            analysis['win_type'] = f"پنج {symbol} - مگا جک‌پات"
            analysis['details'].append(f"پنج {symbol}: {format_number(win_amount)} سکه")
            
        elif max_count >= 4:
            symbol = [s for s, c in symbol_counts.items() if c == 4][0]
            multiplier = self.slot_multipliers[symbol] * 3
            win_amount = bet_amount * multiplier
            analysis['total_win'] = win_amount
            analysis['win_type'] = f"چهار {symbol} - سوپر جک‌پات"
            analysis['details'].append(f"چهار {symbol}: {format_number(win_amount)} سکه")
            
        elif max_count >= 3:
            symbol = [s for s, c in symbol_counts.items() if c == 3][0]
            multiplier = self.slot_multipliers[symbol]
            win_amount = bet_amount * multiplier
            analysis['total_win'] = win_amount
            analysis['win_type'] = f"سه {symbol} - جک‌پات"
            analysis['details'].append(f"سه {symbol}: {format_number(win_amount)} سکه")
            
            for sym, count in symbol_counts.items():
                if sym != symbol and count >= 2:
                    additional_win = bet_amount * (self.slot_multipliers[sym] // 5)
                    analysis['total_win'] += additional_win
                    analysis['details'].append(f"دو {sym}: {format_number(additional_win)} سکه")
        
        return analysis

    def _check_progressive_jackpot(self, reels: List[str]) -> bool:
        """بررسی برنده شدن جک‌پات پیشرونده"""
        return reels.count('💎') >= 3

    def _win_progressive_jackpot(self, user_id: int, jackpot_type: str) -> int:
        """برنده شدن جک‌پات پیشرونده"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT amount FROM progressive_jackpots WHERE type = ?
                ''', (jackpot_type,))
                
                result = cursor.fetchone()
                if not result:
                    return 0
                
                jackpot_amount = result['amount']
                
                new_amount = self.progressive_jackpots[jackpot_type]
                cursor.execute('''
                    UPDATE progressive_jackpots 
                    SET amount = ?, last_winner = ?, last_win_date = ?
                    WHERE type = ?
                ''', (new_amount, user_id, datetime.now().isoformat(), jackpot_type))
                
                conn.commit()
                return jackpot_amount
                
        except Exception as e:
            logger.error(f"خطا در جک‌پات پیشرونده: {e}")
            return 0

    def _contribute_to_jackpot(self, bet_amount: int):
        """کمک به جک‌پات پیشرونده"""
        try:
            contribution = max(1, bet_amount // 100)
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                contributions = {
                    'mini': contribution // 2,
                    'minor': contribution // 4,
                    'major': contribution // 8,
                    'grand': contribution // 16
                }
                
                for jackpot_type, amount in contributions.items():
                    if amount > 0:
                        cursor.execute('''
                            INSERT OR REPLACE INTO progressive_jackpots 
                            (type, amount, total_contributions)
                            VALUES (
                                ?, 
                                COALESCE((SELECT amount FROM progressive_jackpots WHERE type = ?), ?) + ?,
                                COALESCE((SELECT total_contributions FROM progressive_jackpots WHERE type = ?), 0) + ?
                            )
                        ''', (jackpot_type, jackpot_type, self.progressive_jackpots[jackpot_type], 
                              amount, jackpot_type, amount))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در کمک به جک‌پات: {e}")

    def get_game_stats(self, user_id: int) -> Dict:
        """دریافت آمار بازی‌های کاربر"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 
                        game_type,
                        COUNT(*) as total_games,
                        SUM(CASE WHEN is_win = 1 THEN 1 ELSE 0 END) as wins,
                        SUM(bet_amount) as total_bet,
                        SUM(win_amount) as total_win
                    FROM game_history 
                    WHERE user_id = ? 
                    GROUP BY game_type
                ''', (user_id,))
                
                stats = {}
                for row in cursor.fetchall():
                    game_type = row['game_type']
                    win_rate = (row['wins'] / row['total_games']) * 100 if row['total_games'] > 0 else 0
                    net_profit = row['total_win'] - row['total_bet']
                    
                    stats[game_type] = {
                        'total_games': row['total_games'],
                        'wins': row['wins'],
                        'win_rate': round(win_rate, 2),
                        'total_bet': row['total_bet'],
                        'total_win': row['total_win'],
                        'net_profit': net_profit
                    }
                
                return stats
                
        except Exception as e:
            logger.error(f"خطا در دریافت آمار بازی: {e}")
            return {}

    def parse_text_command(self, message_text: str) -> Dict:
        """تجزیه دستورات متنی بازی"""
        try:
            parts = message_text.strip().split()
            if len(parts) < 2:
                return {'error': 'دستور نامعتبر'}
            
            game_command = parts[0].lower()
            
            game_mapping = {
                'رولت': 'roulette',
                'roulette': 'roulette',
                'تاس': 'dice', 
                'dice': 'dice',
                'حدس': 'guess',
                'guess': 'guess',
                'اسلات': 'slots',
                'slots': 'slots'
            }
            
            if game_command not in game_mapping:
                return {'error': 'نوع بازی نامعتبر'}
            
            game_type = game_mapping[game_command]
            
            try:
                bet_amount = int(parts[1])
            except ValueError:
                return {'error': 'مبلغ شرط‌بندی نامعتبر'}
            
            result = {
                'game_type': game_type,
                'bet_amount': bet_amount
            }
            
            if game_type == 'roulette':
                if len(parts) >= 3:
                    try:
                        chosen_numbers = [int(x) for x in parts[2:] if x.isdigit()]
                        if chosen_numbers:
                            result['chosen_number'] = chosen_numbers[0]
                        else:
                            result['chosen_number'] = random.randint(0, 36)
                    except ValueError:
                        result['chosen_number'] = random.randint(0, 36)
                else:
                    result['chosen_number'] = random.randint(0, 36)
                    
            elif game_type == 'dice':
                if len(parts) >= 3:
                    try:
                        predictions = [int(x) for x in parts[2:] if x.isdigit() and 1 <= int(x) <= 6]
                        if predictions:
                            result['prediction'] = predictions[0]
                        else:
                            result['prediction'] = random.randint(1, 6)
                    except ValueError:
                        result['prediction'] = random.randint(1, 6)
                else:
                    result['prediction'] = random.randint(1, 6)
                    
            elif game_type == 'guess':
                if len(parts) >= 4:
                    try:
                        level = int(parts[2])
                        guess = int(parts[3])
                        if level not in [1, 2, 3, 4, 5]:
                            level = 1
                        result['level'] = level
                        result['guess'] = guess
                    except ValueError:
                        result['level'] = 1
                        result['guess'] = random.randint(1, 10)
                else:
                    result['level'] = 1
                    result['guess'] = random.randint(1, 10)
            
            return result
            
        except Exception as e:
            logger.error(f"خطا در تجزیه دستور متنی: {e}")
            return {'error': 'خطا در تجزیه دستور'}

    async def process_text_game(self, user_id: int, message_text: str) -> str:
        """پردازش بازی از طریق دستور متنی"""
        try:
            parsed = self.parse_text_command(message_text)
            
            if 'error' in parsed:
                return f"❌ {parsed['error']}\n\n💡 مثال: رولت 5000 15"
            
            game_type = parsed['game_type']
            bet_amount = parsed['bet_amount']
            
            if game_type == 'roulette':
                return await self.play_roulette(user_id, bet_amount, parsed['chosen_number'])
            elif game_type == 'dice':
                return await self.play_dice(user_id, bet_amount, parsed['prediction'])
            elif game_type == 'guess':
                return await self.play_guess(user_id, bet_amount, parsed['level'], parsed['guess'])
            elif game_type == 'slots':
                return await self.play_slots(user_id, bet_amount)
            else:
                return "❌ نوع بازی پشتیبانی نمی‌شود"
                
        except Exception as e:
            logger.error(f"خطا در پردازش بازی متنی: {e}")
            return "❌ خطا در اجرای بازی"

    def get_advanced_stats(self, user_id: int) -> str:
        """دریافت آمار پیشرفته کاربر"""
        try:
            stats = self.get_game_stats(user_id)
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT current_streak, longest_streak FROM win_streaks 
                    WHERE user_id = ?
                ''', (user_id,))
                
                streak_data = cursor.fetchone()
                current_streak = streak_data['current_streak'] if streak_data else 0
                longest_streak = streak_data['longest_streak'] if streak_data else 0
                
                vip_level = self._get_vip_level(user_id)
                vip_name = self.vip_levels[vip_level]['name']
                
                cursor.execute('''
                    SELECT COUNT(*) as total FROM achievements WHERE user_id = ?
                ''', (user_id,))
                
                achievements_count = cursor.fetchone()['total']
                total_achievements = len(self.achievements)
                
                today = datetime.now().strftime('%Y-%m-%d')
                cursor.execute('''
                    SELECT games_played, total_bet, total_loss FROM daily_limits 
                    WHERE user_id = ? AND date = ?
                ''', (user_id, today))
                
                daily_data = cursor.fetchone()
                games_today = daily_data['games_played'] if daily_data else 0
                bet_today = daily_data['total_bet'] if daily_data else 0
                
                stats_text = f"""
📊 <b>آمار پیشرفته</b>

👤 <b>وضعیت کلی:</b>
🏆 سطح VIP: {vip_name}
🎖️ دستاوردها: {achievements_count}/{total_achievements}
🔥 استریک فعلی: {current_streak}
⚡ طولانی‌ترین استریک: {longest_streak}

📈 <b>آمار امروز:</b>
🎮 بازی‌های انجام شده: {games_today}
💰 کل شرط‌بندی: {format_number(bet_today)} سکه

🎯 <b>آمار بازی‌ها:</b>
                
                return stats_text
                
        except Exception as e:
            logger.error(f"خطا در دریافت آمار پیشرفته: {e}")
            return "❌ خطا در دریافت آمار"

    def get_jackpot_info(self) -> str:
        """دریافت اطلاعات جک‌پات‌های پیشرونده"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                jackpot_text = """
🎰 <b>جک‌پات‌های پیشرونده</b>

💰 تمام شرط‌بندی‌ها به جک‌پات کمک می‌کنند!
🎯 برای برنده شدن، ۳ نماد 💎 در اسلات کافی است

            
            return stats_text
            
        except Exception as e:
            logger.error(f"خطا در دریافت آمار جهانی: {e}")
            return "❌ خطا در دریافت آمار جهانی"

    def get_achievements_list(self, user_id: int) -> str:
        """دریافت لیست دستاوردها"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT achievement_id FROM achievements WHERE user_id = ?
                ''', (user_id,))
                
                unlocked = {row['achievement_id'] for row in cursor.fetchall()}
                
                achievements_text = """
🏆 <b>دستاوردها</b>

                
                medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
                
                for i, row in enumerate(results):
                    medal = medals[i] if i < len(medals) else f"{i+1}."
                    username = row['username'] or row['first_name'] or "ناشناس"
                    
                    if game_type:
                        wins = row['total_wins']
                        earnings = row['total_won']
                        biggest = row['biggest_win']
                        
                        leaderboard_text += f"""
{medal} <b>{username}</b>
   💰 کل برد: {format_number(earnings)} سکه
   🏆 تعداد برد: {wins}
   💎 بزرگترین برد: {format_number(biggest)} سکه
                
                return leaderboard_text
                
        except Exception as e:
            logger.error(f"خطا در دریافت جدول امتیازات: {e}")
            return "❌ خطا در دریافت جدول امتیازات"

    def get_game_help(self) -> str:
        """راهنمای کامل بازی‌ها"""
        help_text = """
🎮 <b>راهنمای بازی‌ها</b>

🎰 <b>رولت:</b>
• شماره‌ای از 0 تا 36 انتخاب کنید
• ضریب برد: 35x
• دستور متنی: رولت مبلغ شماره
• مثال: رولت 5000 15

🎲 <b>تاس:</b>
• عددی از 1 تا 6 پیش‌بینی کنید
• 3 تاس انداخته می‌شود
• ضرایب: یک تاس 5x، دو تاس 8x، سه تاس 150x
• دستور متنی: تاس مبلغ عدد
• مثال: تاس 3000 4

🔢 <b>حدس عدد:</b>
• 5 سطح مختلف:
  - سطح 1: 1-10 (ضریب 8x)
  - سطح 2: 1-50 (ضریب 40x)
  - سطح 3: 1-100 (ضریب 80x)
  - سطح 4: 1-500 (ضریب 200x)
  - سطح 5: 1-1000 (ضریب 1000x)
• دستور متنی: حدس مبلغ سطح عدد
• مثال: حدس 10000 3 45

🎰 <b>اسلات ماشین:</b>
• 5 ریل با نمادهای مختلف
• برد برای 3+ نماد یکسان
• ضرایب مختلف برای هر نماد
• شانس جک‌پات پیشرونده
• دستور متنی: اسلات مبلغ
• مثال: اسلات 8000

🌟 <b>ویژگی‌های خاص:</b>
• 🔥 سیستم استریک برد (بونوس تا 200%)
• ⏰ بونوس زمانی (8-10 شب و 12-2 شب)
• 👑 سیستم VIP (بونوس تا 30%)
• 🏆 دستاوردها و جوایز
• 💎 جک‌پات‌های پیشرونده
• 📊 آمار تفصیلی

💡 <b>نکات:</b>
• حداقل شرط‌بندی: {format_number(self.min_bet)} سکه
• حداکثر شرط‌بندی: {format_number(self.max_bet)} سکه
• VIP: حداکثر {format_number(self.vip_max_bet)} سکه
• کولداون بازی‌ها: 1-5 ثانیه
• محدودیت روزانه: 1000 بازی
