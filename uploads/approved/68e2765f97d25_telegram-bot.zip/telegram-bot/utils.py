
import logging
import sys
from logging.handlers import RotatingFileHandler

def format_number(num):
    """فرمت‌دهی عدد بدون کاما"""
    if num is None:
        return "0"
    return str(int(num))

def escape_html(text):
    """فرار کاراکترهای HTML"""
    if text is None:
        return ""
    text = str(text)
    text = text.replace("&", "&amp;")
    text = text.replace("<", "&lt;")
    text = text.replace(">", "&gt;")
    return text

def safe_int(value, default=0):
    """تبدیل امن به عدد صحیح"""
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def truncate_text(text, max_length=100):
    """کوتاه کردن متن"""
    if text is None:
        return ""
    text = str(text)
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def setup_logging(log_level='INFO', log_file='bot.log'):
    """تنظیم سیستم لاگ‌گیری"""
    
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    level = getattr(logging, log_level.upper(), logging.INFO)
    
    logger = logging.getLogger()
    logger.setLevel(level)
    
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_formatter = logging.Formatter(log_format)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    try:
        file_handler = RotatingFileHandler(
            log_file, 
            maxBytes=10*1024*1024,
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(level)
        file_formatter = logging.Formatter(log_format)
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"نمی‌توان فایل لاگ ایجاد کرد: {e}")
    
    return logger