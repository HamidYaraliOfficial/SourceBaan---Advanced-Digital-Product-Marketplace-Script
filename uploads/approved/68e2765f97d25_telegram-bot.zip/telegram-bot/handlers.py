
import re
import random
import logging
from datetime import datetime, timedelta
from telegram import Update
from telegram.ext import ContextTypes

from games import Games
from utils import format_number
from payments import PaymentHandler
from message_utils import (
    format_game_result, 
    format_multi_roulette_result, 
    format_profile_text, 
    format_daily_bonus_text,
    format_leaderboard_text
)

logger = logging.getLogger(__name__)

class BotHandlers:
    def __init__(self, database, admin_id):
        self.db = database
        self.admin_id = admin_id
        self.games = Games(database)
        self.payment_handler = PaymentHandler(database)

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """صفحه اصلی ربات با طراحی زیبا"""
        if not update.message or not update.effective_user:
            return
            
        user = update.effective_user
        user_id = user.id
        username = user.username or "کاربر"
        
        if self.db.is_user_banned(user_id):
            await update.message.reply_text(
                "🚫 <b>دسترسی محدود!</b>\n\n"
                "متاسفانه شما از استفاده از ربات محروم شده‌اید.",
                parse_mode='HTML'
            )
            return
        
        self.db.register_user(user_id, username, user.first_name or "")
        user_data = self.db.get_user(user_id)
        
        welcome_text = f"""✨ <b>به باشگاه طلایی VIP خوش آمدید!</b> ✨

🌟 سلام <strong>{user.first_name or 'اعضای گرانقدر'}</strong>، به دنیای شگفت‌انگیز بازی‌های آنلاین خوش آمدید!

╭─────────── 💎 PROFILE 💎 ───────────╮
│ 💰 موجودی طلایی: <code>{format_number(user_data['balance'])}</code> سکه نایاب    │
│ 🏅 رتبه: <em>سطح {user_data['level']}</em> | ⭐ امتیاز: <code>{user_data.get('experience', 0)}</code>     │
╰─────────────────────────────────────╯

🎭 <strong>مجموعه‌ای از هیجان‌انگیزترین بازی‌ها:</strong>

🎰 <b>رولت مخملی</b> ─ تجربه شگفت‌انگیز شانس
🎲 <b>تاس جادویی</b> ─ پیش‌بینی اعجاب‌انگیز
🔮 <b>اوراکل اعداد</b> ─ رمزگشایی ذهن
🎪 <b>اسلات شاهانه</b> ─ چرخش‌های طلایی
🌙 <b>سکه تقدیر</b> ─ انتخاب سرنوشت
🎡 <b>چرخ رنگین‌کمان</b> ─ طیف‌های رنگارنگ
🎫 <b>لاتاری میلیونی</b> ─ رویای بزرگ
🃏 <b>بلک‌جک شاهانه</b> ─ استراتژی هوشمندانه
🎟️ <b>کارت رویایی</b> ─ خراش شگفتی
💣 <b>ماین اسرارآمیز</b> ─ کاوش در ناشناخته‌ها

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🗝️ <strong>کلیدهای جادویی:</strong>
🔸 <em>راهنما</em> ← درهای دانش را بگشایید
🔸 <em>آمار</em> ← قدرت خود را بسنجید  
🔸 <em>موجودی</em> ← گنجینه خود را ببینید
🔸 <em>هدیه</em> ← جعبه شگفتی روزانه
🔸 <em>پروفایل</em> ← هویت شاهانه خود

<span class="tg-spoiler">🎭 راز کهن: هر سکه در اینجا گنجی گرانبها است... آنها را دریافت کنید و تبدیل به افسانه شوید!</span>"""
        
        await update.message.reply_text(
            welcome_text, 
            parse_mode='HTML'
        )

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """راهنمای کامل و زیبا"""
        if not update.message or not update.effective_user:
            return
            
        help_text = """✨ <strong>راهنمای جامع باشگاه طلایی</strong> ✨

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎰 <strong>رولت مخملی</strong>

<blockquote><code>رولت [سکه] [شماره‌ها...]</code></blockquote>

✨ <em>نمونه‌های کاربرد:</em>
• <code>رولت 5 7</code> - شرط تکی بر شماره 7
• <code>رولت 2 1 2 3 4 5</code> - شرط چندگانه

🎯 طیف شماره‌ها: 0 تا 36 | 💎 ضریب جایزه: 35 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎲 <strong>تاس جادویی</strong>

<blockquote><code>تاس [سکه] [پیش‌بینی]</code></blockquote>

✨ <em>نمونه:</em> <code>تاس 3 4</code>
🔮 پیش‌بینی: 1 تا 6 | 💎 ضریب جایزه: 5 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔮 <strong>اوراکل اعداد</strong>

<blockquote><code>حدس [سکه] [عدد] [سطح]</code></blockquote>

✨ <em>نمونه:</em> <code>حدس 1 25 2</code>

🌟 <u>سطوح چالش:</u>
• سطح 1: 1-10 (ضریب 9) • سطح 2: 1-50 (ضریب 45) • سطح 3: 1-100 (ضریب 90)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎪 <strong>اسلات شاهانه</strong>

<blockquote><code>اسلات [سکه]</code></blockquote>

✨ <em>نمونه:</em> <code>اسلات 5</code>
🎰 سه چرخ طلایی با نمادهای نایاب | 💎 ضرایب 2-50 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌙 <strong>سکه تقدیر</strong>

<blockquote><code>کوین [سکه] [شیر/خط]</code></blockquote>

✨ <em>نمونه:</em> <code>کوین 2 شیر</code>
⚖️ انتخاب سرنوشت: شیر یا خط | 💎 ضریب جایزه: 2 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎡 <strong>چرخ رنگین‌کمان</strong>

<blockquote><code>چرخ [سکه] [رنگ]</code></blockquote>

✨ <em>نمونه:</em> <code>چرخ 1 قرمز</code>
🌈 طیف رنگی: قرمز، آبی، سبز، زرد | 💎 ضرایب جایزه: 2-5 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎫 <strong>لاتاری میلیونی</strong>

<blockquote><code>لاتاری [سکه]</code></blockquote>

✨ <em>نمونه:</em> <code>لاتاری 3</code>
🏆 شانس طلایی جک‌پات | 💎 ضرایب جایزه: 2-50 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🃏 <strong>بلک‌جک شاهانه</strong>

<blockquote><code>بلک جک [سکه]</code></blockquote>

✨ <em>نمونه:</em> <code>بلک جک 2</code>
🎯 هنر رسیدن به 21 | 💎 ضریب جایزه: 2.5 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎟️ <strong>کارت رویایی</strong>

<blockquote><code>خراش [سکه]</code></blockquote>

✨ <em>نمونه:</em> <code>خراش 1</code>
🔮 شانس خالص | 💎 ضرایب جایزه: 2-10 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💣 <strong>ماین اسرارآمیز</strong>

<blockquote><code>ماین [سکه] [تعداد_خانه]</code></blockquote>

✨ <em>نمونه:</em> <code>ماین 1 3</code>
🗝️ کاوش در خانه‌های امن | 💎 ضریب جایزه: 1.5-3 برابر

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 <strong>قوانین طلایی</strong>

🌟 حداقل شرط: <code>10</code> سکه نایاب | ⭐ حداکثر شرط: <code>1000</code> سکه طلایی

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🗝️ <strong>کلیدهای جادویی</strong>

✨ <em>موجودی</em> ← مشاهده گنجینه شخصی
✨ <em>آمار</em> ← بررسی عملکرد و قدرت  
✨ <em>هدیه</em> ← جعبه شگفتی روزانه
✨ <em>پروفایل</em> ← هویت شاهانه خود

<span class="tg-spoiler">🎭 راز کهن: تمام دستورات به زبان فارسی هستند و بدون نیاز به علامت / فعال می‌شوند!</span>"""
        
        await update.message.reply_text(
            help_text, 
            parse_mode='HTML'
        )

    async def handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """مدیریت پیام‌های متنی با کلمات کلیدی فارسی"""
        if not update.message or not update.effective_user:
            return
            
        user_id = update.effective_user.id
        text = update.message.text.strip() if update.message.text else ""
        
        if self.db.is_user_banned(user_id):
            return
            
        if text in ['راهنما', 'کمک', 'help', 'راهنمای', 'کمک کن', 'راهنمایی']:
            await self.help_command(update, context)
        elif text in ['موجودی', 'موجودي', 'balance']:
            await self.show_balance(update)
        elif text in ['آمار', 'امار', 'stats']:
            await self.show_stats(update)
        elif text in ['هدیه', 'هديه', 'daily', 'پاداش']:
            await self.daily_bonus(update)
        elif text in ['پروفایل', 'پروفايل', 'profile']:
            await self.show_profile(update)
        elif text in ['لیدربورد', 'ليدربورد', 'رنکینگ', 'رنكينگ', 'برترین', 'برترين']:
            await self.show_leaderboard(update)
        elif text in ['سکه روزانه', 'سكه روزانه', 'daily coin', 'روزانه']:
            await self.daily_bonus(update)
        elif text in ['خرید', 'خريد', 'buy', 'shop', 'فروشگاه']:
            await self.payment_handler.show_buy_menu(update, context)
        elif text in ['آیدی', 'ایدی', 'id', 'آي دي', 'اي دي']:
            await self.show_user_info(update)
        elif text.startswith('رولت ') or text.startswith('roulette '):
            await self.play_roulette(update, text)
        elif text.startswith('تاس ') or text.startswith('dice '):
            await self.play_dice(update, text)
        elif text.startswith('حدس ') or text.startswith('guess '):
            await self.play_guess(update, text)
        elif text.startswith('اسلات ') or text.startswith('slots '):
            await self.play_slots(update, text)
        elif text.startswith('کوین ') or text.startswith('coin '):
            await self.play_coinflip(update, text)
        elif text.startswith('چرخ ') or text.startswith('wheel '):
            await self.play_wheel(update, text)
        elif text.startswith('لاتاری ') or text.startswith('lottery '):
            await self.play_lottery(update, text)
        elif text.startswith('بلک جک ') or text.startswith('blackjack ') or text.startswith('بلکجک '):
            await self.play_blackjack(update, text)
        elif text.startswith('خراش ') or text.startswith('scratch '):
            await self.play_scratch(update, text)
        elif text.startswith('ماین ') or text.startswith('mines '):
            await self.play_mines(update, text)
        else:
            await update.message.reply_text(
                "❓ <b>دستور نامعتبر!</b>\n\n"
                "💡 برای راهنما: <code>/help</code>\n"
                "📋 دستورات: موجودی، آمار، هدیه، پروفایل",
                parse_mode='HTML'
            )

    async def show_balance(self, update: Update):
        """نمایش موجودی با طراحی زیبا"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        user_data = self.db.get_user(user_id)
        
        balance_text = f"""💰 <strong>کیف پول شما</strong>

💎 <blockquote>موجودی فعلی: <code>{format_number(user_data['balance'])}</code> سکه</blockquote>

📊 <u>جزئیات حساب:</u>
🏆 سطح: <em>{user_data['level']}</em>
⚡ تجربه: <code>{user_data.get('experience', 0)}</code>
🎮 تعداد بازی‌ها: <code>{format_number(user_data['total_bets'])}</code>
🏅 تعداد برد: <code>{format_number(user_data['total_wins'])}</code>

┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈
💡 <em>برای شارژ حساب، بازی کنید و برنده شوید!</em>"""
        
        await update.message.reply_text(balance_text, parse_mode='HTML')

    async def show_profile(self, update: Update):
        """نمایش پروفایل کامل"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        user = update.effective_user
        user_data = self.db.get_user(user_id)
        
        win_rate = (user_data['total_wins'] / max(user_data['total_bets'], 1)) * 100
        
        profile_text = f"""👤 <strong>پروفایل کاربری</strong>

🆔 <u>اطلاعات کاربر:</u>
👋 نام: <em>{user.first_name or 'ناشناس'}</em>
📱 نام کاربری: <code>@{user.username or 'ندارد'}</code>
🔢 شناسه: <code>{user_id}</code>

💎 <u>اطلاعات مالی:</u>
💰 موجودی: <blockquote><code>{format_number(user_data['balance'])}</code> سکه</blockquote>
📈 کل برداشت: <code>{format_number(user_data.get('total_winnings', 0))}</code>
📉 کل واریز: <code>{format_number(user_data.get('total_losses', 0))}</code>

🎮 <u>آمار بازی:</u>
🏆 سطح: <strong>{user_data['level']}</strong>
⚡ تجربه: <code>{user_data.get('experience', 0)}</code>
🎯 کل بازی‌ها: <code>{format_number(user_data['total_bets'])}</code>
🏅 تعداد برد: <code>{format_number(user_data['total_wins'])}</code>
📊 درصد برد: <em>{win_rate:.1f}%</em>

📅 <u>تاریخچه:</u>
📝 عضویت: <code>{user_data.get('created_at', 'نامشخص')}</code>
🎁 آخرین هدیه: <code>{user_data.get('last_daily_bonus', 'هرگز')}</code>

<span class="tg-spoiler">🌟 شما یکی از اعضای ویژه ما هستید!</span>"""
        
        await update.message.reply_text(profile_text, parse_mode='HTML')

    async def daily_bonus(self, update: Update):
        """پاداش روزانه با طراحی جذاب"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        result = self.db.claim_daily_bonus(user_id)
        
        if result['success']:
            bonus_text = f"""🎁 <strong>هدیه روزانه دریافت شد!</strong>

💰 <blockquote>مبلغ هدیه: <code>{format_number(result['bonus_amount'])}</code> سکه</blockquote>

💎 موجودی جدید: <code>{format_number(result['new_balance'])}</code> سکه
🔥 روزهای پیاپی: <em>{result.get('day_streak', 1)}</em> روز

┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈
🌟 <em>فردا برای هدیه بیشتر برگردید!</em>
<span class="tg-spoiler">💡 هر چه بیشتر پیاپی بیایید، هدیه بیشتری دریافت می‌کنید!</span>"""
        else:
            hours_left = result.get('hours_until_next', 0)
            minutes_left = result.get('minutes_until_next', 0)
            seconds_left = result.get('seconds_until_next', 0)
            
            time_text = ""
            if hours_left > 0:
                time_text += f"{hours_left} ساعت "
            if minutes_left > 0:
                time_text += f"{minutes_left} دقیقه "
            if seconds_left > 0:
                time_text += f"{seconds_left} ثانیه"
            
            if not time_text.strip():
                time_text = "کمتر از یک ثانیه"
                
            bonus_text = f"""⏰ <strong>هدیه روزانه در انتظار!</strong>

🕐 زمان باقیمانده: <em>{time_text}</em>

💡 <u>راهنمایی:</u>
هر 24 ساعت یک بار می‌توانید هدیه دریافت کنید

🎯 <em>صبر کنید، ارزشش را دارد!</em>"""
            
        await update.message.reply_text(bonus_text, parse_mode='HTML')

    async def show_stats(self, update: Update):
        """آمار کلی ربات"""
        if not update.message:
            return
            
        stats = self.db.get_bot_stats()
        
        stats_text = f"""📊 <strong>آمار کلی کازینو</strong>

👥 <u>کاربران:</u>
🆔 کل اعضا: <code>{format_number(stats['total_users'])}</code>
🟢 فعال امروز: <code>{format_number(stats.get('active_today', 0))}</code>
🆕 عضو جدید: <code>{format_number(stats.get('new_today', 0))}</code>

🎮 <u>بازی‌ها:</u>
🎯 کل بازی‌ها: <code>{format_number(stats['total_games'])}</code>
💰 کل شرط‌ها: <code>{format_number(stats.get('total_bet_amount', 0))}</code>
🏆 کل جوایز: <code>{format_number(stats.get('total_win_amount', 0))}</code>

📈 <u>محبوب‌ترین بازی‌ها:</u>
🎰 رولت: <em>{stats.get('roulette_games', 0)} بازی</em>
🎲 تاس: <em>{stats.get('dice_games', 0)} بازی</em>
🔢 حدس: <em>{stats.get('guess_games', 0)} بازی</em>
🎪 اسلات: <em>{stats.get('slots_games', 0)} بازی</em>

┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈
🌟 <em>شما بخشی از این آمار فوق‌العاده هستید!</em>"""
        
        await update.message.reply_text(stats_text, parse_mode='HTML')

    async def show_leaderboard(self, update: Update):
        """نمایش لیدربورد"""
        if not update.message:
            return
            
        leaderboard = self.db.get_leaderboard(10)
        
        leaderboard_text = """🏆 <strong>برترین بازیکنان</strong>

┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈"""
        
        for i, player in enumerate(leaderboard, 1):
            if i == 1:
                emoji = "👑"
            elif i == 2:
                emoji = "🥈"
            elif i == 3:
                emoji = "🥉"
            else:
                emoji = f"{i}️⃣"
                
            leaderboard_text += f"\n{emoji} <em>{player.get('first_name', 'ناشناس')}</em>"
            leaderboard_text += f"\n💰 <code>{format_number(player['balance'])}</code> سکه"
            leaderboard_text += f"\n🏆 سطح {player['level']}\n"
        
        leaderboard_text += "\n┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈"
        leaderboard_text += "\n<span class=\"tg-spoiler\">💡 بازی کنید تا به جمع برترین‌ها بپیوندید!</span>"
        
        await update.message.reply_text(leaderboard_text, parse_mode='HTML')

    async def play_roulette(self, update: Update, text: str):
        """بازی رولت ساده و سریع"""
        user_id = update.effective_user.id
        
        parts = text.split()[1:]
        
        if len(parts) < 2:
            await update.message.reply_text(
                "❌ <b>دستور نامعتبر!</b>\n\n"
                "💡 <u>روش صحیح:</u>\n"
                "<code>رولت [مبلغ] [شماره‌ها...]</code>\n\n"
                "📝 <em>مثال:</em> <code>رولت 10 7</code>\n"
                "📝 <em>چندگانه:</em> <code>رولت 5 1 2 3 4 5</code>",
                parse_mode='HTML'
            )
            return
            
        try:
            bet_amount = int(parts[0])
            numbers = [int(num) for num in parts[1:]]
            
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(
                    "💰 <b>مبلغ نامعتبر!</b>\n\n"
                    f"🔸 حداقل: <code>{format_number(self.games.min_bet)}</code> سکه\n"
                    f"🔹 حداکثر: <code>{format_number(self.games.max_bet)}</code> سکه",
                    parse_mode='HTML'
                )
                return
                
            if len(numbers) > 15:
                await update.message.reply_text(
                    "🚫 <b>تعداد شماره‌ها زیاد!</b>\n\n"
                    "حداکثر 15 شماره می‌توانید انتخاب کنید.",
                    parse_mode='HTML'
                )
                return
                
            if any(num < 0 or num > 36 for num in numbers):
                await update.message.reply_text(
                    "🎯 <b>شماره نامعتبر!</b>\n\n"
                    "شماره‌ها باید بین 0 تا 36 باشند.",
                    parse_mode='HTML'
                )
                return
                
            user_data = self.db.get_user(user_id)
            total_bet = bet_amount * len(numbers)
            
            if user_data['balance'] < total_bet:
                await update.message.reply_text(
                    "💸 <b>موجودی ناکافی!</b>\n\n"
                    f"💰 موجودی شما: <code>{format_number(user_data['balance'])}</code>\n"
                    f"💵 مبلغ مورد نیاز: <code>{format_number(total_bet)}</code>",
                    parse_mode='HTML'
                )
                return
                
            winning_number = random.randint(0, 36)
            is_winner = winning_number in numbers
            win_amount = bet_amount * 36 if is_winner else 0
            net_amount = win_amount - total_bet
            
            self.db.update_balance(user_id, net_amount, 'roulette', 
                                 f'رولت - شماره برنده: {winning_number}')
            
            if is_winner:
                result_text = f"""🎉 <strong>تبریک! برنده شدید!</strong>

🎰 <blockquote>شماره برنده: <code>{winning_number}</code></blockquote>

💰 <u>جزئیات برد:</u>
🎯 شماره‌های شما: <em>{', '.join(map(str, numbers))}</em>
💵 مبلغ شرط: <code>{format_number(total_bet)}</code> سکه
🏆 جایزه: <code>{format_number(win_amount)}</code> سکه
💎 سود خالص: <code>+{format_number(net_amount)}</code> سکه

💰 موجودی جدید: <code>{format_number(user_data['balance'] + net_amount)}</code>

<span class="tg-spoiler">🌟 شانس با شما بود!</span>"""
            else:
                result_text = f"""😔 <strong>متاسفانه باختید!</strong>

🎰 <blockquote>شماره برنده: <code>{winning_number}</code></blockquote>

💔 <u>جزئیات بازی:</u>
🎯 شماره‌های شما: <em>{', '.join(map(str, numbers))}</em>
💸 مبلغ از دست رفته: <code>{format_number(total_bet)}</code> سکه

💰 موجودی باقیمانده: <code>{format_number(user_data['balance'] - total_bet)}</code>

💡 <em>دفعه بعد شانس بیشتری خواهید داشت!</em>"""
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text(
                "🔢 <b>خطا در اعداد!</b>\n\n"
                "لطفاً فقط عدد وارد کنید.",
                parse_mode='HTML'
            )

    async def play_dice(self, update: Update, text: str):
        """بازی تاس"""
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 2:
            await update.message.reply_text(
                "❌ <b>دستور نامعتبر!</b>\n\n"
                "💡 <u>روش صحیح:</u>\n"
                "<code>تاس [مبلغ] [پیش‌بینی]</code>\n\n"
                "📝 <em>مثال:</em> <code>تاس 5000 3</code>",
                parse_mode='HTML'
            )
            return
            
        try:
            bet_amount = int(parts[0])
            prediction = int(parts[1])
            
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(
                    "💰 <b>مبلغ نامعتبر!</b>\n\n"
                    f"🔸 حداقل: <code>{format_number(self.games.min_bet)}</code> سکه\n"
                    f"🔹 حداکثر: <code>{format_number(self.games.max_bet)}</code> سکه",
                    parse_mode='HTML'
                )
                return
                
            if not (1 <= prediction <= 6):
                await update.message.reply_text(
                    "🎲 <b>پیش‌بینی نامعتبر!</b>\n\n"
                    "عدد باید بین 1 تا 6 باشد.",
                    parse_mode='HTML'
                )
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text(
                    f"💸 <b>موجودی ناکافی!</b>\n\n"
                    f"💰 موجودی شما: <code>{format_number(user_data['balance'])}</code>",
                    parse_mode='HTML'
                )
                return
                
            dice_result = random.randint(1, 6)
            is_winner = dice_result == prediction
            win_amount = bet_amount * 3 if is_winner else 0
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'dice', 
                                 f'تاس - نتیجه: {dice_result}')
            
            dice_emoji = ['🎲', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][dice_result]
            
            if is_winner:
                result_text = f"""🎉 <strong>عالی! درست حدس زدید!</strong>

{dice_emoji} <blockquote>نتیجه تاس: <code>{dice_result}</code></blockquote>

💰 <u>جزئیات برد:</u>
🎯 پیش‌بینی شما: <em>{prediction}</em>
💵 مبلغ شرط: <code>{format_number(bet_amount)}</code> سکه
🏆 جایزه: <code>{format_number(win_amount)}</code> سکه
💎 سود خالص: <code>+{format_number(net_amount)}</code> سکه

💰 موجودی جدید: <code>{format_number(user_data['balance'] + net_amount)}</code>"""
            else:
                result_text = f"""😔 <strong>نزدیک بود!</strong>

{dice_emoji} <blockquote>نتیجه تاس: <code>{dice_result}</code></blockquote>

💔 <u>جزئیات بازی:</u>
🎯 پیش‌بینی شما: <em>{prediction}</em>
💸 مبلغ از دست رفته: <code>{format_number(bet_amount)}</code> سکه

💰 موجودی باقیمانده: <code>{format_number(user_data['balance'] - bet_amount)}</code>"""
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text(
                "🔢 <b>خطا در اعداد!</b>\n\n"
                "لطفاً فقط عدد وارد کنید.",
                parse_mode='HTML'
            )

    async def play_guess(self, update: Update, text: str):
        """بازی حدس عدد"""
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 3:
            await update.message.reply_text(
                "❌ <b>دستور نامعتبر!</b>\n\n"
                "💡 <u>روش صحیح:</u>\n"
                "<code>حدس [مبلغ] [عدد] [سطح]</code>\n\n"
                "📝 <em>مثال:</em> <code>حدس 2000 25 2</code>",
                parse_mode='HTML'
            )
            return
            
        try:
            bet_amount = int(parts[0])
            guess = int(parts[1])
            level = int(parts[2])
            
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(
                    "💰 <b>مبلغ نامعتبر!</b>\n\n"
                    f"🔸 حداقل: <code>{format_number(self.games.min_bet)}</code> سکه\n"
                    f"🔹 حداکثر: <code>{format_number(self.games.max_bet)}</code> سکه",
                    parse_mode='HTML'
                )
                return
                
            levels = {
                1: {'min': 1, 'max': 10, 'multiplier': 6},
                2: {'min': 1, 'max': 50, 'multiplier': 25},
                3: {'min': 1, 'max': 100, 'multiplier': 45}
            }
            
            if level not in levels:
                await update.message.reply_text(
                    "🎯 <b>سطح نامعتبر!</b>\n\n"
                    "🔸 سطح 1: 1-10 (ضریب 6)\n"
                    "🔹 سطح 2: 1-50 (ضریب 25)\n"
                    "🔻 سطح 3: 1-100 (ضریب 45)",
                    parse_mode='HTML'
                )
                return
                
            level_info = levels[level]
            if not (level_info['min'] <= guess <= level_info['max']):
                await update.message.reply_text(
                    f"🔢 <b>عدد خارج از محدوده!</b>\n\n"
                    f"سطح {level}: {level_info['min']} تا {level_info['max']}",
                    parse_mode='HTML'
                )
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text(
                    f"💸 <b>موجودی ناکافی!</b>\n\n"
                    f"💰 موجودی شما: <code>{format_number(user_data['balance'])}</code>",
                    parse_mode='HTML'
                )
                return
                
            random_number = random.randint(level_info['min'], level_info['max'])
            is_winner = random_number == guess
            win_amount = bet_amount * level_info['multiplier'] if is_winner else 0
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'guess', 
                                 f'حدس سطح {level} - عدد: {random_number}')
            
            if is_winner:
                result_text = f"""🎊 <strong>فوق‌العاده! درست حدس زدید!</strong>

🎯 <blockquote>عدد مخفی: <code>{random_number}</code></blockquote>

💰 <u>جزئیات برد:</u>
🔢 حدس شما: <em>{guess}</em>
📊 سطح بازی: <em>{level}</em> (محدوده {level_info['min']}-{level_info['max']})
💵 مبلغ شرط: <code>{format_number(bet_amount)}</code> سکه
🏆 جایزه: <code>{format_number(win_amount)}</code> سکه
💎 سود خالص: <code>+{format_number(net_amount)}</code> سکه

💰 موجودی جدید: <code>{format_number(user_data['balance'] + net_amount)}</code>

<span class="tg-spoiler">🧠 ذهن تیزبینی دارید!</span>"""
            else:
                result_text = f"""😔 <strong>خیلی نزدیک بودید!</strong>

🎯 <blockquote>عدد مخفی: <code>{random_number}</code></blockquote>

💔 <u>جزئیات بازی:</u>
🔢 حدس شما: <em>{guess}</em>
📊 سطح بازی: <em>{level}</em>
💸 مبلغ از دست رفته: <code>{format_number(bet_amount)}</code> سکه

💰 موجودی باقیمانده: <code>{format_number(user_data['balance'] - bet_amount)}</code>

💡 <em>دوباره امتحان کنید!</em>"""
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text(
                "🔢 <b>خطا در اعداد!</b>\n\n"
                "لطفاً فقط عدد وارد کنید.",
                parse_mode='HTML'
            )

    async def play_slots(self, update: Update, text: str):
        """بازی اسلات ماشین"""
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 1:
            await update.message.reply_text(
                "❌ <b>دستور نامعتبر!</b>\n\n"
                "💡 <u>روش صحیح:</u>\n"
                "<code>اسلات [مبلغ]</code>\n\n"
                "📝 <em>مثال:</em> <code>اسلات 10000</code>",
                parse_mode='HTML'
            )
            return
            
        try:
            bet_amount = int(parts[0])
            
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(
                    "💰 <b>مبلغ نامعتبر!</b>\n\n"
                    f"🔸 حداقل: <code>{format_number(self.games.min_bet)}</code> سکه\n"
                    f"🔹 حداکثر: <code>{format_number(self.games.max_bet)}</code> سکه",
                    parse_mode='HTML'
                )
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text(
                    f"💸 <b>موجودی ناکافی!</b>\n\n"
                    f"💰 موجودی شما: <code>{format_number(user_data['balance'])}</code>",
                    parse_mode='HTML'
                )
                return
                
            symbols = ['🍒', '🍋', '🍊', '🍇', '🔔', '💎', '7️⃣']
            weights = [30, 25, 20, 15, 7, 2, 1]
            
            reels = [random.choices(symbols, weights=weights, k=1)[0] for _ in range(3)]
            
            win_amount = 0
            multipliers = {'🍒': 2, '🍋': 3, '🍊': 4, '🍇': 5, '🔔': 8, '💎': 15, '7️⃣': 50}
            
            if len(set(reels)) == 1:
                win_amount = bet_amount * multipliers[reels[0]]
            elif len(set(reels)) == 2:
                win_amount = bet_amount // 2
                
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'slots', 
                                 f'اسلات - نتیجه: {" ".join(reels)}')
            
            slots_display = f"🎰 {reels[0]} | {reels[1]} | {reels[2]} 🎰"
            
            if win_amount > 0:
                result_text = f"""🎉 <strong>جک‌پات!</strong>

{slots_display}

💰 <u>جزئیات برد:</u>
🎪 نتیجه: <blockquote>{" | ".join(reels)}</blockquote>
💵 مبلغ شرط: <code>{format_number(bet_amount)}</code> سکه
🏆 جایزه: <code>{format_number(win_amount)}</code> سکه
💎 سود خالص: <code>+{format_number(net_amount)}</code> سکه

💰 موجودی جدید: <code>{format_number(user_data['balance'] + net_amount)}</code>

<span class="tg-spoiler">🎰 ماشین خوش‌شانسی!</span>"""
            else:
                result_text = f"""😔 <strong>این بار نشد!</strong>

{slots_display}

💔 <u>جزئیات بازی:</u>
🎪 نتیجه: <blockquote>{" | ".join(reels)}</blockquote>
💸 مبلغ از دست رفته: <code>{format_number(bet_amount)}</code> سکه

💰 موجودی باقیمانده: <code>{format_number(user_data['balance'] - bet_amount)}</code>

💡 <em>دفعه بعد حتماً برنده می‌شوید!</em>"""
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text(
                "🔢 <b>خطا در اعداد!</b>\n\n"
                "لطفاً فقط عدد وارد کنید.",
                parse_mode='HTML'
            )

    async def play_coinflip(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 2:
            await update.message.reply_text("❌ <code>کوین [مبلغ] [شیر/خط]</code>", parse_mode='HTML')
            return
            
        try:
            bet_amount = int(parts[0])
            choice = parts[1].lower()
            
            if choice not in ['شیر', 'خط']:
                await update.message.reply_text("🪙 انتخاب‌های معتبر: شیر، خط", parse_mode='HTML')
                return
                
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            result = random.choice(['شیر', 'خط'])
            is_winner = result == choice
            win_amount = bet_amount * 2 if is_winner else 0
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'coinflip')
            
            if is_winner:
                result_text = f"🎉 برنده! سکه: {result}\n💰 جایزه: {format_number(win_amount)} سکه"
            else:
                result_text = f"😔 باخت! سکه: {result}"
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def play_wheel(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 2:
            await update.message.reply_text("❌ <code>چرخ [مبلغ] [رنگ]</code>", parse_mode='HTML')
            return
            
        try:
            bet_amount = int(parts[0])
            color_choice = parts[1].lower()
            
            colors = {'قرمز': 2, 'آبی': 3, 'سبز': 4, 'زرد': 5}
            if color_choice not in colors:
                await update.message.reply_text("🎡 رنگ‌های معتبر: قرمز، آبی، سبز، زرد", parse_mode='HTML')
                return
                
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            result_color = random.choice(list(colors.keys()))
            is_winner = result_color == color_choice
            win_amount = bet_amount * colors[result_color] if is_winner else 0
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'wheel')
            
            color_emojis = {'قرمز': '🔴', 'آبی': '🔵', 'سبز': '🟢', 'زرد': '🟡'}
            
            if is_winner:
                result_text = f"🎉 برنده! {color_emojis[result_color]} {result_color}\n💰 جایزه: {format_number(win_amount)} سکه"
            else:
                result_text = f"😔 رنگ برنده: {color_emojis[result_color]} {result_color}"
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def play_lottery(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 1:
            await update.message.reply_text("❌ <code>لاتاری [مبلغ]</code>", parse_mode='HTML')
            return
            
        try:
            bet_amount = int(parts[0])
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            luck = random.randint(1, 100)
            
            if luck == 1:
                multiplier, emoji = 50, "🏆"
            elif luck <= 5:
                multiplier, emoji = 20, "💎"
            elif luck <= 15:
                multiplier, emoji = 5, "🎯"
            elif luck <= 30:
                multiplier, emoji = 2, "🎊"
            else:
                multiplier, emoji = 0, "😔"
                
            win_amount = int(bet_amount * multiplier)
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'lottery')
            
            if multiplier > 0:
                result_text = f"{emoji} برنده! شانس: {luck}/100\n💰 جایزه: {format_number(win_amount)} سکه"
            else:
                result_text = f"😔 شانس: {luck}/100"
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def play_blackjack(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()
        
        if text.startswith('بلک جک '):
            if len(parts) != 3:
                await update.message.reply_text("❌ <code>بلک جک [مبلغ]</code>", parse_mode='HTML')
                return
            bet_amount_str = parts[2]
        else:
            if len(parts) != 2:
                await update.message.reply_text("❌ <code>بلک جک [مبلغ]</code>", parse_mode='HTML')
                return
            bet_amount_str = parts[1]
            
        try:
            bet_amount = int(bet_amount_str)
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            player_total = random.randint(15, 21)
            dealer_total = random.randint(15, 21)
            
            if player_total == 21:
                multiplier = 2.5
            elif player_total > dealer_total and player_total <= 21:
                multiplier = 2
            elif player_total == dealer_total:
                multiplier = 1
            else:
                multiplier = 0
                
            win_amount = int(bet_amount * multiplier)
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'blackjack')
            
            if multiplier > 1:
                title = "🎉 شما برنده!" if player_total != 21 else "🏆 بلک جک!"
            elif multiplier == 1:
                title = "🤝 مساوی!"
            else:
                title = "😔 دیلر برنده!"
                
            result_text = f"{title}\n🃏 شما: {player_total} | دیلر: {dealer_total}"
            if multiplier > 1:
                result_text += f"\n💰 جایزه: {format_number(win_amount)} سکه"
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def play_scratch(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 1:
            await update.message.reply_text("❌ <code>خراش [مبلغ]</code>", parse_mode='HTML')
            return
            
        try:
            bet_amount = int(parts[0])
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            symbols = ['💎', '🎯', '⭐', '🍀', '🎊']
            card = [random.choice(symbols) for _ in range(9)]
            
            lines = [[card[0], card[1], card[2]], [card[3], card[4], card[5]], [card[6], card[7], card[8]]]
            multipliers = {'💎': 10, '🎯': 8, '⭐': 6, '🍀': 4, '🎊': 2}
            max_multiplier = 0
            
            for line in lines:
                if len(set(line)) == 1:
                    max_multiplier = max(max_multiplier, multipliers[line[0]])
                    
            win_amount = bet_amount * max_multiplier
            net_amount = win_amount - bet_amount
            
            self.db.update_balance(user_id, net_amount, 'scratch')
            
            card_display = f"{card[0]} {card[1]} {card[2]}\n{card[3]} {card[4]} {card[5]}\n{card[6]} {card[7]} {card[8]}"
            
            if max_multiplier > 0:
                result_text = f"🎉 برنده!\n🎟️ کارت:\n<pre>{card_display}</pre>\n💰 جایزه: {format_number(win_amount)} سکه"
            else:
                result_text = f"😔 این بار نشد!\n🎟️ کارت:\n<pre>{card_display}</pre>"
                
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def play_mines(self, update: Update, text: str):
        user_id = update.effective_user.id
        parts = text.split()[1:]
        
        if len(parts) != 2:
            await update.message.reply_text("❌ <code>ماین [مبلغ] [تعداد_خانه]</code>", parse_mode='HTML')
            return
            
        try:
            bet_amount = int(parts[0])
            picks = int(parts[1])
            
            if not (1 <= picks <= 6):
                await update.message.reply_text("💣 می‌توانید بین 1 تا 6 خانه انتخاب کنید", parse_mode='HTML')
                return
                
            if not (self.games.min_bet <= bet_amount <= self.games.max_bet):
                await update.message.reply_text(f"💰 مبلغ باید بین {format_number(self.games.min_bet)} تا {format_number(self.games.max_bet)} سکه باشد", parse_mode='HTML')
                return
                
            user_data = self.db.get_user(user_id)
            if user_data['balance'] < bet_amount:
                await update.message.reply_text("💸 موجودی ناکافی!", parse_mode='HTML')
                return
                
            safe_count = 12
            win_chance = max(0, (safe_count - picks + 1) / safe_count)
            is_winner = random.random() < win_chance
            
            if is_winner:
                multiplier = 1.2 + (picks * 0.3)
                win_amount = int(bet_amount * multiplier)
                net_amount = win_amount - bet_amount
                
                result_text = f"🎉 همه خانه‌ها امن بود!\n💣 انتخاب شما: {picks} خانه\n💰 جایزه: {format_number(win_amount)} سکه"
            else:
                net_amount = -bet_amount
                result_text = f"💥 به ماین برخورد کردید!\n💣 انتخاب شما: {picks} خانه"
                
            self.db.update_balance(user_id, net_amount, 'mines')
            await update.message.reply_text(result_text, parse_mode='HTML')
            
        except ValueError:
            await update.message.reply_text("🔢 خطا در اعداد!", parse_mode='HTML')

    async def show_user_info(self, update: Update):
        """نمایش اطلاعات کاربر - با ریپلای یا خود کاربر"""
        user_id = update.effective_user.id
        target_user_id = user_id
        target_username = update.effective_user.username or "ندارد"
        target_first_name = update.effective_user.first_name or "ناشناس"
        
        if update.message.reply_to_message and update.message.reply_to_message.from_user:
            replied_user = update.message.reply_to_message.from_user
            target_user_id = replied_user.id
            target_username = replied_user.username or "ندارد"
            target_first_name = replied_user.first_name or "ناشناس"
        
        user_info = self.db.get_user_detailed_info(target_user_id)
        
        if not user_info:
            await update.message.reply_text(
                "❌ <b>کاربر یافت نشد!</b>\n\n"
                "💡 این کاربر در ربات ثبت‌نام نکرده است.",
                parse_mode='HTML'
            )
            return
        
        total_games = user_info.get('total_games', 0) or 0
        total_wins = user_info.get('total_wins', 0) or 0
        win_rate = (total_wins / max(total_games, 1)) * 100
        
        total_bet = user_info.get('total_bet', 0) or 0
        total_winnings = user_info.get('total_winnings', 0) or 0
        net_profit = total_winnings - total_bet
        
        status = "🚫 بن شده" if user_info.get('is_banned', False) else "✅ فعال"
        
        last_activity = user_info.get('last_activity', 'هرگز')
        if last_activity != 'هرگز':
            try:
                from datetime import datetime
                activity_date = datetime.fromisoformat(last_activity.replace('Z', '+00:00'))
                last_activity = activity_date.strftime('%Y/%m/%d - %H:%M')
            except:
                pass
        
        info_text = f"""🆔 <strong>اطلاعات کاربر</strong>

👤 <u>مشخصات:</u>
📝 نام: <em>{target_first_name}</em>
📱 نام کاربری: <code>@{target_username}</code>
🔢 شناسه: <code>{target_user_id}</code>
🟢 وضعیت: {status}

💰 <u>اطلاعات مالی:</u>
💎 موجودی فعلی: <blockquote><code>{format_number(user_info.get('balance', 0))}</code> سکه</blockquote>
📊 سطح: <em>{user_info.get('level', 1)}</em>
⚡ امتیاز تجربه: <code>{format_number(user_info.get('experience', 0))}</code>

🎮 <u>آمار بازی:</u>
🎯 کل بازی‌ها: <code>{format_number(total_games)}</code>
🏆 تعداد برد: <code>{format_number(total_wins)}</code>
📈 درصد برد: <em>{win_rate:.1f}%</em>
💵 کل شرط‌بندی: <code>{format_number(total_bet)}</code> سکه
🎁 کل برد: <code>{format_number(total_winnings)}</code> سکه"""

        if net_profit > 0:
            info_text += f"\n💚 سود کلی: <code>+{format_number(net_profit)}</code> سکه"
        elif net_profit < 0:
            info_text += f"\n💔 زیان کلی: <code>{format_number(net_profit)}</code> سکه"
        else:
            info_text += f"\n⚖️ سود/زیان: <code>0</code> سکه"

        info_text += f"""

🕐 <u>فعالیت:</u>
📅 عضویت: <em>{user_info.get('created_at', 'نامشخص')[:10]}</em>
🎮 آخرین بازی: <em>{last_activity}</em>

┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈┅┈
💡 <em>برای دیدن آیدی کسی، روی پیامش ریپلای کنید و "آیدی" بنویسید</em>"""
        
        await update.message.reply_text(info_text, parse_mode='HTML')