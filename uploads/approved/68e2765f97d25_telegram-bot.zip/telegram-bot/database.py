
import sqlite3
import logging
import json
import shutil
import time
from datetime import datetime, timedelta
from contextlib import contextmanager
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str = "bot_database.db"):
        self.db_path = db_path
        self.init_database()
        logger.info("دیتابیس با موفقیت راه‌اندازی شد")

    @contextmanager
    def get_connection(self):
        """Context manager برای اتصال به دیتابیس با حل کامل مشکل lock"""
        conn = None
        max_retries = 5
        retry_delay = 0.1
        
        for attempt in range(max_retries):
            try:
                conn = sqlite3.connect(
                    self.db_path,
                    timeout=30.0,
                    check_same_thread=False
                )
                
                conn.row_factory = sqlite3.Row
                
                conn.execute('PRAGMA busy_timeout=30000')
                conn.execute('PRAGMA journal_mode=WAL')
                conn.execute('PRAGMA synchronous=NORMAL')
                conn.execute('PRAGMA wal_autocheckpoint=1000')
                conn.execute('PRAGMA cache_size=10000')
                conn.execute('PRAGMA temp_store=MEMORY')
                
                conn.execute('SELECT 1').fetchone()
                
                yield conn
                conn.commit()
                return
                
            except sqlite3.OperationalError as e:
                if conn:
                    try:
                        conn.rollback()
                        conn.close()
                    except:
                        pass
                    conn = None
                
                if "database is locked" in str(e).lower():
                    if attempt < max_retries - 1:
                        import time
                        time.sleep(retry_delay * (attempt + 1))
                        continue
                    else:
                        logger.error(f"دیتابیس قفل است بعد از {max_retries} تلاش: {e}")
                        self._create_temp_database()
                        conn = sqlite3.connect(
                            self.db_path,
                            timeout=10.0,
                            check_same_thread=False
                        )
                        conn.row_factory = sqlite3.Row
                        yield conn
                        conn.commit()
                        return
                        
                elif "readonly" in str(e).lower():
                    logger.error(f"دیتابیس read-only است: {e}")
                    self._handle_readonly_database()
                    raise
                else:
                    logger.error(f"خطا در دیتابیس: {e}")
                    raise
                    
            except Exception as e:
                if conn:
                    try:
                        conn.rollback()
                        conn.close()
                    except:
                        pass
                logger.error(f"خطا غیرمنتظره در دیتابیس: {e}")
                raise
            finally:
                if conn:
                    try:
                        conn.close()
                    except:
                        pass
    
    def _create_temp_database(self):
        """ایجاد دیتابیس موقت در صورت قفل بودن"""
        import os
        import tempfile
        import shutil
        
        try:
            temp_dir = tempfile.gettempdir()
            temp_db_path = os.path.join(temp_dir, f'bot_database_temp_{os.getpid()}.db')
            
            if os.path.exists(self.db_path):
                shutil.copy2(self.db_path, temp_db_path)
            
            old_path = self.db_path
            self.db_path = temp_db_path
            
            logger.info(f"دیتابیس موقت ایجاد شد: {temp_db_path}")
            
            if not os.path.exists(temp_db_path):
                self.init_database()
                
        except Exception as e:
            logger.error(f"خطا در ایجاد دیتابیس موقت: {e}")
            raise

    def _handle_readonly_database(self):
        """مدیریت دیتابیس read-only و ایجاد دیتابیس جدید"""
        import os
        import tempfile
        
        try:
            writable_dir = os.getenv('WRITABLE_DIR', tempfile.gettempdir())
            new_db_path = os.path.join(writable_dir, 'bot_database.db')
            
            logger.info(f"ایجاد دیتابیس جدید در مسیر قابل نوشتن: {new_db_path}")
            
            if os.path.exists(self.db_path) and os.path.exists(new_db_path):
                try:
                    shutil.copy2(self.db_path, new_db_path)
                    logger.info("دیتابیس موجود کپی شد")
                except Exception as copy_error:
                    logger.warning(f"خطا در کپی دیتابیس: {copy_error}")
            
            self.db_path = new_db_path
            
            self.init_database()
            
        except Exception as e:
            logger.error(f"خطا در مدیریت دیتابیس read-only: {e}")
            raise

    def init_database(self):
        """ایجاد جداول دیتابیس"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    first_name TEXT,
                    balance INTEGER DEFAULT 10000,
                    level INTEGER DEFAULT 1,
                    experience INTEGER DEFAULT 0,
                    total_bets INTEGER DEFAULT 0,
                    total_wins INTEGER DEFAULT 0,
                    last_daily_bonus TEXT,
                    is_banned BOOLEAN DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS game_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    game_type TEXT NOT NULL,
                    bet_amount INTEGER NOT NULL,
                    result TEXT NOT NULL,
                    win_amount INTEGER DEFAULT 0,
                    is_win BOOLEAN DEFAULT 0,
                    game_data TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    transaction_type TEXT NOT NULL,
                    amount INTEGER NOT NULL,
                    description TEXT,
                    admin_id INTEGER,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    action TEXT NOT NULL,
                    details TEXT,
                    ip_address TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_balance ON users(balance DESC)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_game_history_user ON game_history(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id)')
            
            conn.commit()

    def register_user(self, user_id: int, username: str, first_name: str) -> bool:
        """ثبت کاربر جدید یا به‌روزرسانی اطلاعات"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT user_id FROM users WHERE user_id = ?', (user_id,))
                exists = cursor.fetchone()
                
                if exists:
                    cursor.execute('''
                        UPDATE users SET username = ?, first_name = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE user_id = ?
                    ''', (username, first_name, user_id))
                else:
                    from config import config
                    initial_balance = config.INITIAL_BALANCE
                    cursor.execute('''
                        INSERT INTO users (user_id, username, first_name, balance)
                        VALUES (?, ?, ?, ?)
                    ''', (user_id, username, first_name, initial_balance))
                    
                    self.add_transaction(user_id, 'welcome_bonus', initial_balance, 'پاداش ثبت‌نام')
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"خطا در ثبت کاربر {user_id}: {e}")
            return False

    def get_user(self, user_id: int) -> Optional[Dict]:
        """دریافت اطلاعات کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
                row = cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"خطا در دریافت کاربر {user_id}: {e}")
            return None

    def update_balance(self, user_id: int, amount: int, transaction_type: str = 'game', description: str = '') -> bool:
        """به‌روزرسانی موجودی کاربر با عملکرد بهینه"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('BEGIN IMMEDIATE')
                
                try:
                    cursor.execute('''
                        UPDATE users SET balance = balance + ?, updated_at = CURRENT_TIMESTAMP
                        WHERE user_id = ?
                    ''', (amount, user_id))
                    
                    cursor.execute('''
                        INSERT INTO transactions (user_id, transaction_type, amount, description, created_at)
                        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ''', (user_id, transaction_type, amount, description))
                    
                    cursor.execute('COMMIT')
                    return True
                    
                except Exception as e:
                    cursor.execute('ROLLBACK')
                    raise e
                
        except Exception as e:
            logger.error(f"خطا در به‌روزرسانی موجودی {user_id}: {e}")
            return False

    def add_transaction(self, user_id: int, transaction_type: str, amount: int, description: str = '', admin_id: Optional[int] = None):
        """اضافه کردن تراکنش"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO transactions (user_id, transaction_type, amount, description, admin_id)
                    VALUES (?, ?, ?, ?, ?)
                ''', (user_id, transaction_type, amount, description, admin_id))
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در اضافه کردن تراکنش: {e}")

    def add_game_history(self, user_id: int, game_type: str, bet_amount: int, result: str, 
                        win_amount: int = 0, is_win: bool = False, game_data: Optional[Dict] = None) -> bool:
        """اضافه کردن تاریخچه بازی"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                game_data_json = json.dumps(game_data) if game_data else None
                
                cursor.execute('''
                    INSERT INTO game_history (user_id, game_type, bet_amount, result, win_amount, is_win, game_data)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (user_id, game_type, bet_amount, result, win_amount, is_win, game_data_json))
                
                cursor.execute('''
                    UPDATE users SET 
                        total_bets = total_bets + 1,
                        total_wins = total_wins + ?,
                        experience = experience + ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                ''', (1 if is_win else 0, bet_amount // 100, user_id))
                
                self.check_level_up(user_id)
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"خطا در اضافه کردن تاریخچه بازی: {e}")
            return False

    def check_level_up(self, user_id: int):
        """بررسی و ارتقاء سطح کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT level, experience FROM users WHERE user_id = ?', (user_id,))
                row = cursor.fetchone()
                
                if row:
                    current_level = row['level']
                    experience = row['experience']
                    
                    new_level = experience // 1000 + 1
                    
                    if new_level > current_level:
                        cursor.execute('''
                            UPDATE users SET level = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE user_id = ?
                        ''', (new_level, user_id))
                        
                        bonus = new_level * 1000
                        cursor.execute('''
                            UPDATE users SET balance = balance + ?
                            WHERE user_id = ?
                        ''', (bonus, user_id))
                        
                        self.add_transaction(user_id, 'level_bonus', bonus, f'پاداش ارتقاء به سطح {new_level}')
                        
                        conn.commit()
                        
        except Exception as e:
            logger.error(f"خطا در بررسی ارتقاء سطح: {e}")

    def claim_daily_bonus(self, user_id: int) -> Dict:
        """دریافت پاداش روزانه"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT last_daily_bonus, level FROM users WHERE user_id = ?', (user_id,))
                row = cursor.fetchone()
                
                if not row:
                    return {'success': False, 'message': 'کاربر یافت نشد'}
                
                last_bonus = row['last_daily_bonus']
                level = row['level']
                
                now = datetime.now()
                
                if last_bonus:
                    last_bonus_date = datetime.fromisoformat(last_bonus)
                    time_diff = (now - last_bonus_date).total_seconds()
                    if time_diff < 86400:
                        remaining_seconds = 86400 - time_diff
                        hours = int(remaining_seconds // 3600)
                        minutes = int((remaining_seconds % 3600) // 60)
                        seconds = int(remaining_seconds % 60)
                        
                        return {
                            'success': False, 
                            'hours_until_next': hours,
                            'minutes_until_next': minutes,
                            'seconds_until_next': seconds,
                            'total_seconds_left': int(remaining_seconds)
                        }
                
                from config import Config
                bonus_amount = Config.DAILY_BONUS_BASE + (level * Config.DAILY_BONUS_MULTIPLIER)
                
                cursor.execute('''
                    UPDATE users SET 
                        balance = balance + ?,
                        last_daily_bonus = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                ''', (bonus_amount, now.isoformat(), user_id))
                
                cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
                new_balance = cursor.fetchone()['balance']
                
                self.add_transaction(user_id, 'daily_bonus', bonus_amount, 'پاداش روزانه')
                
                conn.commit()
                
                return {
                    'success': True,
                    'bonus_amount': bonus_amount,
                    'new_balance': new_balance
                }
                
        except Exception as e:
            logger.error(f"خطا در دریافت پاداش روزانه: {e}")
            return {'success': False, 'message': 'خطا در دریافت پاداش'}

    def get_leaderboard(self, limit: int = 10) -> List[Dict]:
        """دریافت جدول امتیازات"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT username, first_name, balance, level FROM users 
                    WHERE is_banned = 0
                    ORDER BY balance DESC 
                    LIMIT ?
                ''', (limit,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            logger.error(f"خطا در دریافت جدول امتیازات: {e}")
            return []

    def get_bot_stats(self) -> Dict:
        """دریافت آمار کلی ربات"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT COUNT(*) as total FROM users')
                total_users = cursor.fetchone()['total']
                
                cursor.execute('SELECT COUNT(DISTINCT user_id) as active FROM game_history')
                active_users = cursor.fetchone()['active']
                
                cursor.execute('SELECT COUNT(*) as total FROM game_history')
                total_games = cursor.fetchone()['total']
                
                cursor.execute('SELECT SUM(balance) as total FROM users WHERE is_banned = 0')
                total_coins = cursor.fetchone()['total'] or 0
                
                return {
                    'total_users': total_users,
                    'active_users': active_users,
                    'total_games': total_games,
                    'total_coins': total_coins
                }
                
        except Exception as e:
            logger.error(f"خطا در دریافت آمار: {e}")
            return {'total_users': 0, 'active_users': 0, 'total_games': 0, 'total_coins': 0}

    def is_user_banned(self, user_id: int) -> bool:
        """بررسی بن بودن کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT is_banned FROM users WHERE user_id = ?', (user_id,))
                row = cursor.fetchone()
                
                return row['is_banned'] if row else False
                
        except Exception as e:
            logger.error(f"خطا در بررسی بن کاربر: {e}")
            return False

    def ban_user(self, user_id: int, admin_id: int) -> bool:
        """بن کردن کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE users SET is_banned = 1, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                ''', (user_id,))
                
                self.add_log(admin_id, 'ban_user', f'کاربر {user_id} بن شد')
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"خطا در بن کردن کاربر: {e}")
            return False

    def unban_user(self, user_id: int, admin_id: int) -> bool:
        """حذف بن کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE users SET is_banned = 0, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?
                ''', (user_id,))
                
                self.add_log(admin_id, 'unban_user', f'بن کاربر {user_id} برداشته شد')
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"خطا در حذف بن کاربر: {e}")
            return False

    def add_log(self, user_id: int, action: str, details: str = '', ip_address: Optional[str] = None):
        """اضافه کردن لاگ"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO logs (user_id, action, details, ip_address)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, action, details, ip_address))
                conn.commit()
                
        except Exception as e:
            logger.error(f"خطا در اضافه کردن لاگ: {e}")

    def backup_database(self):
        """پشتیبان‌گیری از دیتابیس"""
        try:
            backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            shutil.copy2(self.db_path, backup_name)
            logger.info(f"پشتیبان‌گیری انجام شد: {backup_name}")
            
        except Exception as e:
            logger.error(f"خطا در پشتیبان‌گیری: {e}")

    def reset_daily_bonuses(self):
        """ریست پاداش‌های روزانه"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                yesterday = (datetime.now() - timedelta(days=1)).isoformat()
                cursor.execute('''
                    UPDATE users SET last_daily_bonus = NULL
                    WHERE last_daily_bonus < ?
                ''', (yesterday,))
                conn.commit()
                logger.info("پاداش‌های روزانه ریست شدند")
                
        except Exception as e:
            logger.error(f"خطا در ریست پاداش‌های روزانه: {e}")

    def clean_old_logs(self, days: int = 30):
        """پاک‌سازی لاگ‌های قدیمی"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
                cursor.execute('DELETE FROM logs WHERE created_at < ?', (cutoff_date,))
                conn.commit()
                logger.info(f"لاگ‌های قدیمی‌تر از {days} روز پاک شدند")
                
        except Exception as e:
            logger.error(f"خطا در پاک‌سازی لاگ‌ها: {e}")

    def get_user_transactions(self, user_id: int, limit: int = 20) -> List[Dict]:
        """دریافت تاریخچه تراکنش‌های کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM transactions 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ''', (user_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            logger.error(f"خطا در دریافت تراکنش‌ها: {e}")
            return []

    def get_user_detailed_info(self, user_id: int) -> Optional[Dict]:
        """دریافت اطلاعات کامل کاربر"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
                user_data = cursor.fetchone()
                
                if not user_data:
                    return None
                
                user_info = dict(user_data)
                
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total_games,
                        SUM(bet_amount) as total_bet,
                        SUM(CASE WHEN is_win = 1 THEN win_amount ELSE 0 END) as total_winnings,
                        COUNT(CASE WHEN is_win = 1 THEN 1 END) as total_wins
                    FROM game_history 
                    WHERE user_id = ?
                ''', (user_id,))
                
                stats = cursor.fetchone()
                if stats:
                    user_info.update(dict(stats))
                
                cursor.execute('''
                    SELECT created_at FROM game_history 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 1
                ''', (user_id,))
                
                last_activity = cursor.fetchone()
                user_info['last_activity'] = last_activity[0] if last_activity else 'هرگز'
                
                return user_info
                
        except Exception as e:
            logger.error(f"خطا در دریافت اطلاعات کاربر {user_id}: {e}")
            return None
