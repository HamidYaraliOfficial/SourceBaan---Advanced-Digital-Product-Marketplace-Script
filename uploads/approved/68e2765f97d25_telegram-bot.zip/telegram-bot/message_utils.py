from typing import Optional

def format_game_result(game_type: str, bet_amount: int, win_amount: int, won: bool, game_data: Optional[dict] = None) -> str:
    """فرمت‌دهی نتیجه بازی با قابلیت‌های بصری"""
    
    if won:
        result_icon = "🎉"
        status = "برنده شدید!"
        amount_text = f"<tg-spoiler>+{win_amount:,}</tg-spoiler> سکه"
    else:
        result_icon = "😔"
        status = "باختید!"
        amount_text = f"<tg-spoiler>-{bet_amount:,}</tg-spoiler> سکه"
    
    base_text = f"""{result_icon} <b>{status}</b>

🎮 بازی: <b>{game_type}</b>
💰 شرط: <code>{bet_amount:,}</code> سکه
💵 نتیجه: {amount_text}"""
    
    if game_data:
        if game_type == "رولت" and "winning_number" in game_data:
            base_text += f"\n🎯 شماره برنده: <code>{game_data['winning_number']}</code>"
            if "user_numbers" in game_data:
                base_text += f"\n🎲 شماره‌های شما: <code>{', '.join(map(str, game_data['user_numbers']))}</code>"
        
        elif game_type == "تاس" and "dice_result" in game_data:
            base_text += f"\n🎲 نتیجه تاس: <code>{game_data['dice_result']}</code>"
            if "prediction" in game_data:
                base_text += f"\n🔮 پیش‌بینی شما: <code>{game_data['prediction']}</code>"
        
        elif game_type == "حدس عدد" and "target_number" in game_data:
            base_text += f"\n🎯 عدد هدف: <code>{game_data['target_number']}</code>"
            if "user_guess" in game_data:
                base_text += f"\n🤔 حدس شما: <code>{game_data['user_guess']}</code>"
        
        elif game_type == "اسلات" and "symbols" in game_data:
            symbols_text = " | ".join(game_data['symbols'])
            base_text += f"\n🎰 نتیجه: <code>{symbols_text}</code>"
    
    return base_text

def format_multi_roulette_result(bets: list, winning_number: int, total_bet: int, total_win: int) -> str:
    """فرمت‌دهی نتیجه رولت چندگانه"""
    
    won = total_win > 0
    result_icon = "🎉" if won else "😔"
    status = "برنده شدید!" if won else "باختید!"
    
    result_text = f"""{result_icon} <b>{status}</b>

🎮 بازی: <b>رولت چندگانه</b>
🎯 شماره برنده: <code>{winning_number}</code>
💰 کل شرط: <code>{total_bet:,}</code> سکه"""
    
    if won:
        result_text += f"\n💵 برد: <tg-spoiler>+{total_win:,}</tg-spoiler> سکه"
    else:
        result_text += f"\n💵 باخت: <tg-spoiler>-{total_bet:,}</tg-spoiler> سکه"
    
    result_text += "\n\n📋 <b>جزئیات شرط‌ها:</b>"
    
    for bet in bets:
        number = bet['number']
        amount = bet['amount']
        win_amount = bet.get('win_amount', 0)
        
        if win_amount > 0:
            result_text += f"\n✅ شماره <code>{number}</code>: <code>{amount:,}</code> → <tg-spoiler>+{win_amount:,}</tg-spoiler>"
        else:
            result_text += f"\n❌ شماره <code>{number}</code>: <code>{amount:,}</code> → باخت"
    
    return result_text

def format_profile_text(user_data: dict, username: str) -> str:
    """فرمت‌دهی پروفایل کاربر"""
    
    win_rate = (user_data['total_wins'] / max(user_data['total_bets'], 1)) * 100
    win_emoji = "🏆" if win_rate >= 50 else "📊" if win_rate >= 30 else "📉"
    
    profile_text = f"""👤 <b>پروفایل {username}</b>

💰 موجودی: <code>{user_data['balance']:,}</code> سکه
🎮 سطح: <b>{user_data['level']}</b>
⭐ امتیاز: <code>{user_data['experience']:,}</code>

📊 <b>آمار بازی:</b>
🎯 کل بازی‌ها: <code>{user_data['total_bets']:,}</code>
🏆 برد: <code>{user_data['total_wins']:,}</code>
📉 باخت: <code>{user_data['total_bets'] - user_data['total_wins']:,}</code>
{win_emoji} درصد برد: <b>{win_rate:.1f}%</b>

💵 <b>آمار مالی:</b>
💰 کل شرط‌ها: <code>{user_data.get('total_bet_amount', 0):,}</code> سکه
💎 کل برد: <code>{user_data.get('total_win_amount', 0):,}</code> سکه"""
    
    return profile_text

def format_daily_bonus_text(bonus_amount: int, new_balance: int, day_streak: int = 1) -> str:
    """فرمت‌دهی پاداش روزانه"""
    
    streak_emoji = "🔥" if day_streak >= 7 else "⭐" if day_streak >= 3 else "🎁"
    
    bonus_text = f"""{streak_emoji} <b>پاداش روزانه دریافت شد!</b>

🎁 پاداش: <tg-spoiler>+{bonus_amount:,}</tg-spoiler> سکه
💰 موجودی جدید: <code>{new_balance:,}</code> سکه"""
    
    if day_streak > 1:
        bonus_text += f"\n🔥 پیاپی: <b>{day_streak}</b> روز"
    
    bonus_text += f"\n\n💡 <i>فردا برای پاداش بیشتر برگردید!</i>"
    
    return bonus_text

def format_leaderboard_text(leaderboard_data: list) -> str:
    """فرمت‌دهی جدول امتیازات"""
    
    leaderboard_text = "🏆 <b>جدول امتیازات برترین بازیکنان</b>\n\n"
    
    medals = ["🥇", "🥈", "🥉"]
    
    for i, player in enumerate(leaderboard_data):
        rank = i + 1
        medal = medals[i] if i < 3 else f"{rank}."
        
        leaderboard_text += f"{medal} <b>{player['username']}</b>\n"
        leaderboard_text += f"   💰 <code>{player['balance']:,}</code> سکه | "
        leaderboard_text += f"🎮 سطح {player['level']}\n\n"
    
    return leaderboard_text

def create_copy_command_text(command: str, description: str) -> str:
    """ایجاد متن دستور قابل کپی"""
    return f"<pre>{command}</pre> - {description}"

def format_help_section(title: str, commands: list) -> str:
    """فرمت‌دهی بخش راهنما"""
    section_text = f"📋 <b>{title}:</b>\n"
    
    for cmd in commands:
        if isinstance(cmd, dict):
            section_text += f"<code>/{cmd['name']}</code> - {cmd['desc']}\n"
        else:
            section_text += f"{cmd}\n"
    
    return section_text + "\n"