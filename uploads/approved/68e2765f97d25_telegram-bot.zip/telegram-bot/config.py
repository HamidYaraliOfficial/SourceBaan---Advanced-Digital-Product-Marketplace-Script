
import os
from typing import Dict, Any

class Config:
    """کلاس تنظیمات ربات"""
    
    BOT_TOKEN = os.getenv('BOT_TOKEN', '8273124957:AAExjqnGYd66wcJrLO7XFkVp3WgfxymsgdM')
    ADMIN_ID = int(os.getenv('ADMIN_ID', '7722740433'))
    
    DATABASE_PATH = os.getenv('DATABASE_PATH', 'bot_database.db')
    BACKUP_INTERVAL_HOURS = int(os.getenv('BACKUP_INTERVAL_HOURS', '6'))
    
    MIN_BET = int(os.getenv('MIN_BET', '10'))
    MAX_BET = int(os.getenv('MAX_BET', '1000'))
    INITIAL_BALANCE = int(os.getenv('INITIAL_BALANCE', '50'))
    
    DAILY_BONUS_BASE = int(os.getenv('DAILY_BONUS_BASE', '2'))
    DAILY_BONUS_MULTIPLIER = int(os.getenv('DAILY_BONUS_MULTIPLIER', '2'))
    LEVEL_UP_BONUS_MULTIPLIER = int(os.getenv('LEVEL_UP_BONUS_MULTIPLIER', '5'))
    
    ROULETTE_MULTIPLIER = int(os.getenv('ROULETTE_MULTIPLIER', '35'))
    DICE_MULTIPLIER = int(os.getenv('DICE_MULTIPLIER', '5'))
    
    GUESS_MULTIPLIERS = {
        1: int(os.getenv('GUESS_EASY_MULTIPLIER', '9')),
        2: int(os.getenv('GUESS_MEDIUM_MULTIPLIER', '45')),
        3: int(os.getenv('GUESS_HARD_MULTIPLIER', '90'))
    }
    
    SLOT_SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '🔔', '💎', '7️⃣']
    SLOT_WEIGHTS = [30, 25, 20, 15, 7, 2, 1]
    
    SLOT_MULTIPLIERS = {
        '🍒': float(os.getenv('SLOT_CHERRY_MULTIPLIER', '2')),
        '🍋': float(os.getenv('SLOT_LEMON_MULTIPLIER', '3')),
        '🍊': float(os.getenv('SLOT_ORANGE_MULTIPLIER', '4')),
        '🍇': float(os.getenv('SLOT_GRAPE_MULTIPLIER', '5')),
        '🔔': float(os.getenv('SLOT_BELL_MULTIPLIER', '8')),
        '💎': float(os.getenv('SLOT_DIAMOND_MULTIPLIER', '15')),
        '7️⃣': float(os.getenv('SLOT_SEVEN_MULTIPLIER', '50'))
    }
    
    MAX_DAILY_GAMES = int(os.getenv('MAX_DAILY_GAMES', '1000'))
    MAX_HOURLY_GAMES = int(os.getenv('MAX_HOURLY_GAMES', '100'))
    COOLDOWN_SECONDS = int(os.getenv('COOLDOWN_SECONDS', '1'))
    
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'bot.log')
    MAX_LOG_SIZE_MB = int(os.getenv('MAX_LOG_SIZE_MB', '10'))
    
    POLL_INTERVAL = int(os.getenv('POLL_INTERVAL', '2'))
    POLL_TIMEOUT = int(os.getenv('POLL_TIMEOUT', '20'))
    BOOTSTRAP_RETRIES = int(os.getenv('BOOTSTRAP_RETRIES', '5'))
    
    CUSTOM_WELCOME_MESSAGE = os.getenv('CUSTOM_WELCOME_MESSAGE', '')
    CUSTOM_HELP_MESSAGE = os.getenv('CUSTOM_HELP_MESSAGE', '')
    
    ENABLE_VIP_SYSTEM = os.getenv('ENABLE_VIP_SYSTEM', 'false').lower() == 'true'
    ENABLE_REFERRAL_SYSTEM = os.getenv('ENABLE_REFERRAL_SYSTEM', 'false').lower() == 'true'
    ENABLE_TOURNAMENTS = os.getenv('ENABLE_TOURNAMENTS', 'false').lower() == 'true'
    
    ENABLE_STARS_PAYMENT = os.getenv('ENABLE_STARS_PAYMENT', 'true').lower() == 'true'
    
    STARS_PACKAGES = {
        'basic': {
            'stars': 25000,
            'coins': 20,
            'title': '🔸 بسته پایه',
            'description': '20 سکه طلایی'
        },
        'standard': {
            'stars': 50000,
            'coins': 50,
            'title': '🔹 بسته معمولی', 
            'description': '50 سکه طلایی'
        },
        'premium': {
            'stars': 100000,
            'coins': 200,
            'title': '💎 بسته ممتاز',
            'description': '200 سکه طلایی'
        }
    }
    
    @classmethod
    def get_all_settings(cls) -> Dict[str, Any]:
        """دریافت تمام تنظیمات"""
        return {
            attr: getattr(cls, attr)
            for attr in dir(cls)
            if not attr.startswith('_') and not callable(getattr(cls, attr))
        }
    
    @classmethod
    def validate_config(cls) -> bool:
        """اعتبارسنجی تنظیمات"""
        try:
            if cls.BOT_TOKEN == 'YOUR_BOT_TOKEN_HERE' or not cls.BOT_TOKEN:
                print("❌ توکن ربات تنظیم نشده است!")
                return False
            
            if cls.ADMIN_ID == 123456789:
                print("⚠️ آیدی ادمین پیش‌فرض است، لطفاً تغییر دهید!")
            
            if cls.MIN_BET >= cls.MAX_BET:
                print("❌ حداقل شرط‌بندی نمی‌تواند بیشتر از حداکثر باشد!")
                return False
            
            if cls.INITIAL_BALANCE < cls.MIN_BET:
                print("❌ موجودی اولیه نمی‌تواند کمتر از حداقل شرط‌بندی باشد!")
                return False
            
            print("✅ تنظیمات معتبر است!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در اعتبارسنجی تنظیمات: {e}")
            return False

class DevelopmentConfig(Config):
    """تنظیمات محیط توسعه"""
    LOG_LEVEL = 'DEBUG'
    POLL_INTERVAL = 1
    BACKUP_INTERVAL_HOURS = 1

class ProductionConfig(Config):
    """تنظیمات محیط تولید"""
    LOG_LEVEL = 'WARNING'
    ENABLE_VIP_SYSTEM = True
    ENABLE_REFERRAL_SYSTEM = True
    ENABLE_TOURNAMENTS = True

class TestingConfig(Config):
    """تنظیمات محیط تست"""
    DATABASE_PATH = 'test_database.db'
    MIN_BET = 1
    MAX_BET = 100
    INITIAL_BALANCE = 50

ENV = os.getenv('ENVIRONMENT', 'production').lower()

if ENV == 'development':
    config = DevelopmentConfig()
elif ENV == 'testing':
    config = TestingConfig()
else:
    config = ProductionConfig()

if __name__ == "__main__":
    config.validate_config()
