<?php

/*
 * Updated by: @SpiderM9n
 * Telegram Channel: @ZetaB0t
 */
 
if($text == "/on"){
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' => "✅ جستجوی همسن برای شما فعال شد.\n".
            "- برای غیر فعال سازی /off را بزنید\n\n".
            "با قابلیت جستجوی همسن ، فقط افرادی که سن نزدیک به شما دارند جستجو خواهند شد.\n\n".
            "<code>⚠️ جستجوی همسن باعث افزوده شدن فیلتر سن در جستجو می شود و می تواند باعث دیر پیدا شدن (و یا گاهی پیدا نشدن) مخاطب شما شود.</code>",
        'parse_mode' => 'HTML',
        'reply_to_message_id' => $message_id,
    ]);
    $conn->query("UPDATE ".users." SET same_age=1 WHERE user_id='$user_id'");
    exit;
}
if($text == "/off"){
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' => "📴 جستجوی همسن برای شما غیرفعال شد.\n".
            "- برای فعال سازی /on را بزنید\n\n".
            "با قابلیت جستجوی همسن ، فقط افرادی که سن نزدیک به شما دارند جستجو خواهند شد.\n\n".
            "<code>⚠️ جستجوی همسن باعث افزوده شدن فیلتر سن در جستجو می شود و می تواند باعث دیر پیدا شدن (و یا گاهی پیدا نشدن) مخاطب شما شود.</code>",
        'parse_mode' => 'HTML',
        'reply_to_message_id' => $message_id,
    ]);
    $conn->query("UPDATE ".users." SET same_age=0 WHERE user_id='$user_id'");
    exit;
}
if($text == '/deleteAllContacts'){
    $conn->query("DELETE FROM ".friends." WHERE user_id='$user_id'");
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' => "✅ تمامی مخاطبان شما با موفقیت حذف شدند.",
        'reply_to_message_id' => $message_id,
    ]);
    exit;
}
if($text == '/deleteAllBlocks'){
    $conn->query("DELETE FROM ".blocked." WHERE user_id='$user_id'");
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' => "✅ تمامی بلاک شده ها آزاد شدند.",
        'reply_to_message_id' => $message_id,
    ]);
    exit; 
}

$sqlseclink = $conn->query("SELECT * FROM secLink WHERE user='$user_id'")->fetch();
$idseclink = $sqlseclink['id'];
$userseclink = $sqlseclink['user'];
$stepsec = $sqlseclink['step'];

$text_admin = explode(",", $stepsec);
$user_idaaa = $text_admin[0];
$messageaaa = $text_admin[1];

if ($user_idaaa == "sendsec" && $text != "/sahand") {
    $sqlseclink2 = $conn->query("SELECT * FROM secLink WHERE id='$messageaaa'")->fetch();
    $idseclink2 = $sqlseclink2['id'];
    $userseclink2 = $sqlseclink2['user'];
    $stepsec2 = $sqlseclink2['step'];

  if (isset($message['sticker'])) {
        send_reply("sendSticker", [
            'chat_id' => $userseclink2,
            'sticker' => $message['sticker']['file_id'],
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    elseif (isset($message['animation'])) {
        send_reply("sendAnimation", [
            'chat_id' => $userseclink2,
            'animation' => $message['animation']['file_id'],
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    elseif (isset($message['audio'])) {
        send_reply("sendAudio", [
            'chat_id' => $userseclink2,
            'audio' => $message['audio']['file_id'],
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    elseif (isset($message['document'])) {
        send_reply("sendDocument", [
            'chat_id' => $userseclink2,
            'document' => $message['document']['file_id'],
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    if (isset($message['photo'])) {
        $photo = end($message['photo']);
        $file_id = $photo['file_id'];
        send_reply("sendPhoto", [
            'chat_id' => $userseclink2,
            'photo' => $file_id,
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    } 
    elseif (isset($message['voice'])) {
        $file_id = $message['voice']['file_id'];
        send_reply("sendVoice", [
            'chat_id' => $userseclink2,
            'voice' => $file_id,
            'caption' => "️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    elseif (isset($message['video'])) {
        $file_id = $message['video']['file_id'];
        send_reply("sendVideo", [
            'chat_id' => $userseclink2,
            'video' => $file_id,
            'caption' => "️️",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }
    else {
        send_reply("sendMessage", [
            'chat_id' => $userseclink2,
            'parse_mode' => 'HTML',
            'text' => "<blockquote><strong>شما پیام ناشناس جدیدی دارید : </strong></blockquote>\n\n<span class='tg-spoiler'><strong>$text</strong></span>\n〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => 'ارسال پاسخ', 'callback_data' => "gib;directMessage;{$row_users['uniq_id']};none"]]
                ]
            ])
        ]);
    }

    send_reply("sendMessage", [
        'chat_id' => $user_id,
        'text' => "پیام ارسال شد.\n\n".
        "برای برگشت روی گزینه /start کلیک کنید .",
        'reply_to_message_id' => $message_id,
    ]);

    $stmt = $conn->prepare("UPDATE secLink SET step='none' WHERE user = :chat_id LIMIT 1");
    $stmt->execute([':chat_id' => $user_id]);
    exit;
}
if ($text == "لینک ناشناس من 📬" || $text == "/mylink") {
    if ($idseclink != NULL) {
        send_reply("sendMessage", [
            'disable_web_page_preview' => 'true',
            'chat_id' => $user_id,
            'text' => "سلام {$row_users['name']} هستم ✋\n\nلینک زیر رو لمس کن و هر حرفی که تو دلت هست یا هر انتقادی که نسبت به من داری رو با خیال راحت بنویس و بفرست. بدون اینکه از اسمت باخبر بشم پیامت به من میرسه. خودتم میتونی امتحان کنی و از بقیه بخوای راحت و ناشناس بهت پیام بفرستن، حرفای خیلی جالبی میشنوی! 😉\n\n👇👇\nt.me/{$settings['bot_username']}?start=" . htmlspecialchars($idseclink),
            'reply_to_message_id' => $message_id,
        ]);
        
        send_reply('sendMessage', [
            'chat_id' => $user_id,
            'text' => "☝️ پیام بالا رو به دوستات و گروه هایی که میشناسی فـوروارد کن یا لـینک داخلش رو تو شبکه های اجتماعی بذار و توئیت کن، تا بقیه بتونن بهت پیام ناشناس بفرستن. پیام ها از طریق همین برنامه بهت میرسه.\n\nاینستاگرام داری و میخوای دنبال کننده های اینستاگرامت برات پیام ناشناس بفرستن؟\nپس روی دستور 👈🏻 /Instagram کلیک کن!",
            'parse_mode' => "HTML",
        ]);
    } else {
        $uid = uniqid();
        $stmt = $conn->prepare("INSERT INTO secLink (id, user, step) VALUES (:chat_id, '$user_id', 'none')");
        $stmt->execute(['chat_id' => $uid]);

        send_reply("sendMessage", [
            'chat_id' => $user_id,
            'text' => "سلام {$row_users['name']} هستم ✋\n\nلینک زیر رو لمس کن و هر حرفی که تو دلت هست یا هر انتقادی که نسبت به من داری رو با خیال راحت بنویس و بفرست. بدون اینکه از اسمت باخبر بشم پیامت به من میرسه. خودتم میتونی امتحان کنی و از بقیه بخوای راحت و ناشناس بهت پیام بفرستن، حرفای خیلی جالبی میشنوی! 😉\n\n👇👇\nt.me/{$settings['bot_username']}?start=" . htmlspecialchars($uid),
            'reply_to_message_id' => $message_id,
        ]);
        
        send_reply('sendMessage', [
            'chat_id' => $user_id,
            'text' => "☝️ پیام بالا رو به دوستات و گروه هایی که میشناسی فـوروارد کن یا لـینک داخلش رو تو شبکه های اجتماعی بذار و توئیت کن، تا بقیه بتونن بهت پیام ناشناس بفرستن. پیام ها از طریق همین برنامه بهت میرسه.\n\nاینستاگرام داری و میخوای دنبال کننده های اینستاگرامت برات پیام ناشناس بفرستن؟\nپس روی دستور 👈🏻 /Instagram کلیک کن!",
            'parse_mode' => "HTML",
        ]);
    }
    exit;
}

if (strpos($text, "/start") !== false) {
    $id = str_replace("/start ", "", $text);
    $sqlseclink = $conn->query("SELECT * FROM secLink WHERE id='$id'")->fetch();
    $idseclink = $sqlseclink['id'];
    $userseclink = $sqlseclink['user'];
    $row_user_select['name'] = !empty($row_user_select['name']) ? $row_user_select['name'] : "❓";
    $esm = $row['name'];
    $message_sender_id = $sqlseclink['user'];
    
    if ($user_id == $userseclink) {
        send_reply('sendMessage', [
            'chat_id' => $user_id,
            'text' => "اینکه آدم گاهی با خودش حرف بزنه خوبه ، ولی اینجا نمیتونی به خودت پیام ناشناس بفرستی ! :)\n\nچه کاری برات انجام بدم؟",
        ]);
        exit;
    }
    if ($idseclink != NULL) {
        send_reply('sendMessage', [
            'chat_id' => $user_id,
            'text' => "در حال ارسال پیام ناشناس به $esm هستی\n\nمیتونی هر حرف یا انتقادی که تو دلت هست رو بگی چون پیامت به صورت کاملا ناشناس ارسال میشه!",
            'parse_mode' => "HTML",
        ]);

        $stmt = $conn->prepare("UPDATE secLink SET step='sendsec,$id' WHERE user = :chat_id LIMIT 1");
        $stmt->execute([':chat_id' => $user_id]);
    }
}
if($text == "💰سکه" or $text == "/credit"){
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' =>
            "💰سکه فعلی شما : {$row_users['balance']}\n".
            "ـــــــــــــــــــــــــــــــ\n".
            "❓روش های بدست آوردن سکه چیست؟\n\n".
            "برای افزایش سکه به صورت رایگان بنر لینک⚡️ مخصوص خودت (/link) رو برای دوستات  بفرست و {$row_admin['coin_per_invite']} سکه دریافت کن\n\n".
            "- برای اطلاعات بیشتر راهنمای سکه رو بخون (/help_credit)\n\n".
            "2️⃣خرید سکه بصورت آنلاین :\n\n".
            "<code>برای خرید سکه یکی از تعرفه های زیر را انتخاب نمایید👇</code>",
        'reply_to_message_id' => $message_id,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode(['inline_keyboard' => keboards('coin')])
    ]);
    exit;
}
if($ex_data[0] == 'buy_coin'){
    $row_amount = $conn->query("SELECT * FROM ".amounts." WHERE id='{$ex_data[1]}'")->fetch();
    if(!$row_amount){
        send_reply("deleteMessage",['chat_id' => $user_id,'message_id' => $message_id]);
        exit;
    }
    $row_payment = $conn->query("SELECT * FROM ".payments." WHERE user_id='$user_id' AND coins='{$row_amount['coin']}' AND ($time-updated_at)<750 AND (status='first_level' OR status='move_gateway')")->fetch();
    if(!$row_payment){
        $uniq_id = randomNumber(10,payments);
        $conn->query("INSERT INTO ".payments." (user_id,coins,amount,status,created_at,updated_at,uniq_id) VALUES ('$user_id','{$row_amount['coin']}','{$row_amount['amount']}','first_level','$time','$time','$uniq_id')");
        $row_payment = $conn->query("SELECT * FROM ".payments." WHERE uniq_id='{$uniq_id}'")->fetch();
    }
    send_reply("sendPhoto",[
        'chat_id' => $user_id,
        'photo' => "$link/files/gateway.jpg",
        'caption' =>
            "⚠️ دقت کنید !\n".
            "حتما پس از پرداخت گزینه «تکمیل فراید پرداخت» را لمس کنید تا سکه را دریافت کنید.\n\n\n".
            "درصورت عدم ورود به درگاه پرداخت ، فیلترشکن خود را خاموش کنید.",
    ]);
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' =>
            "▪️ پرداخت از طریق درگاه بانکی شتابی بصورت کاملا امن انجام میگیرد.\n\n".
            "⚠️ هنگام پرداخت حتما باید فیلترشکن خود را خاموش کنید ❗️\n\n".
            "لینک خرید {$row_amount['coin']} سکه به مبلغ ".number_format($row_amount['amount'])." تومان برای شما ساخته شد 👇",
        'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "ورود به درگاه پرداخت",'url' => substr($link,0,-4)."/pay/request.php?id={$row_payment['id']}"]]]])
    ]);
    exit;
}
if($text == "🤔راهنما" or $text == "/help"){
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' =>
            "🔹راهنمای استفاده از ربات:\n\n".
            "<code>من اینجام که کمکت کنم! برای دریافت راهنمایی در مورد هر موضوع، کافیه دستور آبی رنگی که مقابل اون سوال هست رو لمس کنی:</code>\n\n".
            "⁉️ چگونه بصورت ناشناس چت کنم؟ /help_chat\n\n".
            "⁉️ سکه یا امتیاز چیست؟ /help_credit\n\n".
            "⁉️ چگونه افراد نزدیکمو پیدا کنم؟ /help_gps\n\n".
            "⁉️ پروفایل چیست؟ /help_profile\n\n".
            "⁉️ چگونه درخواست چت بفرستم؟ /help_sendchat\n\n".
            "⁉️ پیام دایرکت چیست؟ /help_direct\n\n".
            "⁉️ چگونه با 'میان بر' ها کار کنم؟ /help_shortcuts\n\n".
            "⁉️ اطلاع رسانی آنلاین شدن مخاطب /help_onw\n\n".
            "⁉️ اطلاع رسانی اتمام چت مخاطب /help_chw\n\n".
            "⁉️ لیست مخاطبین چیست ؟ /help_contacts\n\n".
            "⁉️ چگونه بصورت پیشرفته بین کاربران جستجو کنم ؟ /help_search\n\n".
            "⁉️ آموزش حذف پیام در چت /help_deleteMessage\n\n".
            "⚖️ قوانین استفاده از ربات /ghavanin\n\n\n".
            "👨‍💻 ارتباط با پشتیبانی ربات: @{$row_admin['support']}",
        'reply_to_message_id' => $message_id,
        'parse_mode' => 'HTML',
    ]);
    exit;
}
if($ex_text[0] == "/help"){
    if($ex_text[1] == "chat"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹برای چت میتونی یکی از راه های زیر رو انتخاب کنی:\n\n".
                "<code>⚜️ جستجوی تصادفی رو از بخش شروع چت انتخاب کنی و به صورت تصادفی به یکی وصل بشی! (بدون نیاز به سکه)</code>\n\n".
                "<code>⚜️ جستجو بر اساس جنسیت مورد نظر رو از بخش شروع چت انتخاب کنی و به یکی وصل بشی (نیاز به 2 سکه)</code>\n\n".
                "<code>⚜️ جستجو براساس شهر مورد نظر رو از بخش شروع چت انتخاب کنی و به انتخاب خودت به یکی وصل بشی</code>\n\n".
                "<code>⚜️ جستجو براساس موضوع مورد نظر ، از بخش شروع چت گزینه چت روم اختصاصی رو انتخاب کنی و براساس موضوع موردنظر و به انتخاب خودت به یکی وصل بشی</code>\n\n".
                "⚠️ اطلاعات شخصی شما مثل موقعیت GPS یا اسم شما در تلگرام یا عکس پروفایل و.. کاملا مخفی هست و فقط اطلاعاتی که تو ربات ثبت میکنید مانند شهر و عکس(توی ربات) برای کاربرای ربات قابل مشاهده هست.\n\n".
                "🔸 - <a href='$link/files/help_chat.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "credit"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹سکه یا امتیاز چیست؟\n\n".
                "شما با داشتن سکه میتوانید :\n\n".
                "<code>- پیام دایرکت بفرستید (1سکه)</code>\n".
                "<code>- درخواست چت بفرستید(2سکه)</code>\n".
                "<code>- از جستجوی پسر  یا جستجوی دختر  استفاده کنید(2سکه)</code>\n".
                "<code>- از ـ«به محض آنلاین شدن اطلاع بده» استفاده کنید(1سکه)</code>\n".
                "<code>- از ـ«به محض اتمام چت به من اطلاع بده» استفاده کنید(1سکه)</code>\n\n".
                "📢 توجه: سکه فقط در صورتی کسر می شود که درخواست موفق باشد ( مثلا درخواست چت شما توسط کاربر مقابل پذیرفته شود )\n\n".
                "❓روش بدست آوردن سکه چیست؟\n\n".
                "1️⃣ معرفی دوستان (رایگان) :\n\n".
                "برای افزایش سکه به صورت رایگان بنر لینک⚡️ مخصوص خودت (/link) رو برای دوستات  بفرست و 20 سکه دریافت کن\n\n".
                "2️⃣ خرید سکه بصورت آنلاین\n\n".
                "3️⃣ معرفی کاربران متخلف :\n".
                "با معرفی کردن افرادی که قوانین ربات رو رعایت نمیکنند  5 سکه هدیه بگیر 😍\n\n".
                "<i>⚠️  5 سکه بابت گزارش تخلف پس از بررسی گزارش و صحیح بودن آن اضافه خواهد شد و گزارش تخلف حتما باید توضیحات داشته باشد.</i>\n\n".
                "<i>💡 برای گزارش تخلف کاربر گزینه ی «🚫 گزارش کاربر» رو روی پروفایلش لمس کن.</i>\n\n".
                "<code>- به ازای هرنفری که با لینک⚡️ شما وارد ربات میشه به محض ورود  7 تا سکه رایگان دریافت میکنی و بعد از اینکه اطلاعات پروفایــــــلش رو کامل کرد 8 تا سکه دیگه و به محض اینکه کاربر ربات رو به دیگران معرفی کرد 5 تا سکه رایگان دیگه هم دریافت میکنی😎 (20=5+8+7)</code>\n\n".
                "🔸 - <a href='$link/files/help_credit.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "gps"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹چگونه افراد نزدیکمو پیدا کنم؟\n\n".
                "برای دیدن لیست افراد نزدیکت فقط کافیه 《📍پیدا کردن افراد نزدیک با GPS》 رو لمس کنی.\n\n".
                "<code>- جستجوی افراد نزدیک کاملا رایگان هست (بدون نیاز به سکه)</code>\n\n\n".
                "برای مشاهده کردن و یا چت کردن با افراد نزدیکت کافیه توی لیست روی آیدی شون بزنی تا پروفایلشونو ببینی.\n\n\n".
                "📢 توجه: امکان مشاهده موقعیت کاربران وجود ندارد و فقط فاصله آنها نمایش داده می شود.\n\n".
                "🔸 - <a href='$link/files/help_gps.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "📍 ثبت موقعیت GPS",'callback_data' => "profile;gps"]]]])
        ]);
        exit;
    }
    if($ex_text[1] == "profile"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹پروفایل چیست؟\n\n".
                "⚜️برای دیدن پروفایل خودت کافیه 《👤 پروفایل》 رو لمس کنی.\n".
                "⚜️برای دیدن پروفایل کسی که باهاش چت میکنی کافیه ایدی کاربری که باهاش چت میکنی رو لمس کنی.\n\n".
                "⚜️برای دیدن پروفایل هرکاربر کافیه روی آیدیش تو ربات بزنی.\n\n\n".
                "<code>📢  آیدی چیست؟ کد اختصاصی هر کاربر که با زدن آن پروفایل کاربر نمایش داده میشود و به صورت /user_ است.</code>\n\n".
                "- پروفایل هر کاربر شامل اطلاعاتی که تو ربات ثبت کرده (نام،سن،جنسیت،شهر،عکس) و تاریخ حضورش تو ربات و فاصلش با شمامیشه.\n\n".
                "برای ارسال پیام دایرکت یا درخواست چت برای هر کاربر ابتدا باید پروفایلش رو مشاهده کنی و سپس دکمه ارسال پیام دایرکت یا درخواست چت رو بزنی.\n\n".
                "🔸 - <a href='$link/files/help_profile.jpg'>‏</a> راهنما : /help\n\n‌",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "sendchat"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹چگونه درخواست چت بفرستم؟\n\n".
                "برای ارسال درخواست چت به کاربران باید گزینه 《💬 درخواست چت》 رو در پروفایل کاربر لمس کنی.\n\n\n".
                "<code>- با ارسال درخواست چت تا وقتی که تایید نشده ازتون سکه ای کم نمیشه،درخواست چت وصل شد 2 سکه ازتون کم میشه. </code>\n\n".
                " 📢 توجه: امکان ارسال درخواست چت فقط برای کاربرانی که در 15 دقیقه اخیر آنلاین بوده اند وجود دارد.\n\n".
                "🔸 - <a href='$link/files//help_sendchat.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "direct"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹پیام دایرکت چیست؟\n\n".
                "با پیام دایرکت میتونی بصورت آنی به کاربر پیام متنی ارسال بکنی حتی اگه درحال چت کردن باشه !\n\n".
                "فقط کافیه وقتی پروفایل کاربر رو مشاهده میکنی روی گزینه 《📨 پیام دایرکت》 بزنی و متن پیامتو بفرستی.\n\n".
                "- درصورت ارسال پیام دایرکت 1 سکه ازت کم میشه\n".
                "- این پیام همون لحظه ارسال میشه و بعدا تو ربات آرشیو نمیشه.\n\n".
                "📢 توجه: متن پیام حداکثر میتونه 200 حرف باشه و اگه متنی که ارسال میکنی بیشتر از 200 حرف بود فقط 200 حرف اولش ارسال میشه.\n\n".
                "💥 قابلیت ویژه پیام دایرکت : درصورتی که کاربر دریافت کننده ، ربات را بلاک کرده باشد پیام دایرکت به محض آنبلاک شدن کاربر به او ارسال میگردد تا حتما پیام دایرکت را مشاهده کند.\n\n".
                "🔸 - <a href='$link/files//help_direct.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "shortcuts"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹 چگونه با \"میان بر\" ها کار کنم؟\n\n".
                "میانبر به شما امکان استفاده آسان و سریع از ربات رو میده !\n\n".
                "فقط کافیه وقتی توی ربات حرف 《 / 》 رو تایپ کنی تا لیست اصلی ترین میانبر ها رو ببینی.\n\n".
                "لیست میانبر های ربات 👇\n\n".
                "/start - ♻️ شروع از اول\n".
                "/sr - 🎲جستجوی شانسی\n".
                "/sg - 🙎‍♀️جستجوی دختر\n".
                "/sb - 🙎‍♂️جستجوی پسر\n".
                "/link - 💯ساخت لینک اختصاصی من\n".
                "/profile - 👤 پروفاـــــــیل من\n".
                "/credit -💰سکه های من\n".
                "/help - 🤔راهنما\n".
                "/id- مشاهده آیدی من\n\n".
                "💥 تو عکس پایین میتونی ببینی که با تایپ کردن حرف \"/\" توی ربات لیست اصلی ترین میانبر هارو ببینی 👇\n\n".
                "🔸 - <a href='$link/files//help_shortcuts.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "onw"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹 اطلاع رسانی آنلاین شدن مخاطب\n\n".
                "با این قابلیت وقتی که کاربر مورد نظرت آنلاین شد ، بهت اطلاع رسانی میشه.\n\n".
                "- درصورت فعال کردن این قابلیت برای هر کاربر 1 💰سکه ازت کم میشه\n".
                "- این قابلیت یکبار فعال میشه و برای اطلاع رسانی دوباره باید یکبار دیگه فعالش کنی.\n".
                "- اگه بعد از 10 روز کاربر مورد نظرت آنلاین نشد این قابلیت غیر فعال میشه.\n\n".
                "🔴 برای فعال کردن این قابلیت گزینه «🔔 به محض آنلاین شدن  اطلاع بده » توی پروفایل کاربر مورد نظرت رو بزن .\n".
                "(در صورتی که این گزینه وجود نداره یا کاربر آنلاینه و یا این قابلیت رو قبلا براش فعال کردی)\n\n".
                "🔸 - <a href='$link/files//help_onw.jpg'>‏</a> راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "chw"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹 اطلاع رسانی اتمام چت مخاطب\n\n".
                "با این قابلیت وقتی که کاربر مورد نظرت چتش با مخاطبش تموم بشه ، بهت اطلاع رسانی میشه.\n\n".
                "- درصورت فعال کردن این قابلیت برای هر کاربر 1 💰سکه ازت کم میشه\n".
                "- این قابلیت یکبار فعال میشه و برای اطلاع رسانی دوباره باید یکبار دیگه فعالش کنی.\n".
                "- اگه بعد از 10 روز چت کاربر مورد نظرت تموم نشد این قابلیت غیر فعال میشه.\n\n".
                "🔴 برای فعال کردن این قابلیت گزینه «🔔 به محض اتمام چت اطلاع بده » توی پروفایل کاربر مورد نظرت رو بزن .\n".
                "(در صورتی که این گزینه وجود نداره یا کاربر درجال چت نیست و یا این قابلیت رو قبلا براش فعال کردی)\n\n".
                "🔸 -  راهنما : /help\n‌",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "contacts"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹   لیست مخاطبین چیست ؟\n\n\n".
                "با قابلیت لیست مخاطبین می تونی مخاطب هاتو تو ربات داشته باشی و گمشون نکنی !\n\n".
                "- برای دیدن لیست مخاطبین خودت کافیه 《👤 پروفایل》 رو از منوی ربات انتخاب کنی و «🙎‍♂️🙎‍♀️ لیست مخاطبین» رو لمس کنی.\n".
                "و یا « /contacts » رو از منوی میانبر ها انتخاب کنی.\n\n".
                "برای اضافه کردن کاربر به لیست مخاطبین گزینه «➕افزودن به مخاطبین » رو تو پروفایلش بزن.\n\n".
                "🔸 -  راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "search"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹  چگونه بصورت پیشرفته بین کاربران جستجو کنم ؟\n\n".
                "کافیه گزینه «🔍 جستجوی کاربران 🔎» رو تو منوی ربات لمس کنی و یکی از این گزینه ها رو انتخاب کنی 👇\n\n".
                "🎌 هم استانی ها\n".
                " - لیست کاربرانی که تو استان شما هستند.\n\n".
                " 👥 هم سن ها\n".
                " - لیست کاربرانی که در رده سنی نزدیک شما هستند.\n\n".
                "🚶‍♂️ بدون چت ها 🚶‍♀️\n".
                " - لیست کاربرانی آنلاینی که در حال چت نیستند.\n\n".
                "🙋‍♂️ کاربران جدید 🙋‍♀️\n".
                " - لیست کاربراننی که تازه عضو ربات شده اند.\n\n".
                " 🔍 جستجوی پیشرفته 🔎\n".
                " - جستجوی کاربران بصورت پیشرفته با فیلتر جنسیت ، رده سنی ، استان ها و افراد نزدیک ، تاریخ آخرین فعالیت در ربات و با قابلیت مرتب سازی بر اساس نزدیک بودن فاصله ، تاریخ آخرین فعالیت در ربات ، سن و نمایش کاربران بدون چ آنلاین !\n\n".
                "<code>استفاده از این امکانات بصورت کاملا رایگان و بدون نیاز به سکه است.</code>\n\n".
                "🔸 -  راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
    if($ex_text[1] == "deleteMessage"){
        send_reply("sendMessage",[
            'chat_id' => $user_id,
            'text' =>
                "🔹  آموزش حذف پیام در چت\n\n".
                "هر پیامی که تو چت فرستادی و میخوای حذفش کنی کافیه ریپلایش کنی و کلمه «del» یا «حذف» رو تایپ کنی تا از چت مخاطبت حذف بشه.\n\n".
                "🔸 -  راهنما : /help",
            'reply_to_message_id' => $message_id,
            'parse_mode' => 'HTML',
        ]);
        exit;
    }
}
if($text == '/ghavanin'){
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' =>
            "🚦🚧 قوانين استفاده از ربات {$settings['bot_name']} 🚧🚦\n\n".
            "موارد زیر باعث مسدود شدن دائمی کاربر خواهد شد.\n\n".
            "1️⃣ تبلیغات سایت ها ربات ها و کانال ها\n\n".
            "2️⃣ ارسال هرگونه محتوای غیر اخلاقی\n\n".
            "3️⃣ ایجاد مزاحمت برای کاربران\n\n".
            "4️⃣ پخش شماره موبایل یا اطلاعات شخصی دیگران\n\n".
            "5️⃣ محتوای غیر اخلاقی و یا توهین آمیز در پروفایل {$settings['bot_name']}\n\n".
            "6️⃣ ثبت جنسیت اشتباه در پروفایل\n\n".
            "7️⃣ تهدید و جا زدن خود بعنوان مدیر ربات یا پلیس فتا !\n\n".
            "برای گزارش عدم رعایت قوانین می توانید با لمس 《 🚫 گزارش کاربر 》 در پروفایل، کاربر را گزارش کنید.\n\n".
            "👈درصورت گزارش صحیح کاربر متخلف 💰 5 سکه بعنوان هدیه دریافت میکنید.\n\n".
            "🔸 - <a href='$link/files/ghavanin.jpg'>‏</a> راهنما : /help",
        'reply_to_message_id' => $message_id,
        'parse_mode' => 'HTML',
    ]);
    exit;
}
if($text == '🚸 معرفی به دوستان (سکه رایگان)' or $text == '/link' or $data == 'invite'){
    $info_msg = send_reply("sendPhoto",[
        'chat_id' => $user_id,
        'photo' => "$link/files/invite.jpg",
        'caption' =>
            "《{$settings['bot_name']} 🤖》 هستم،بامن میتونی\n\n".
            "📡 افراد #نزدیک ، #هم‌سنی ، #هم‌استانی خودتو پیداکنی و باهاشون #ناشناس چت کنی و آشنا شی😍\n\n".
            "پس منتظر چی هستی؟🤔 بدووو بیا که منتظرتم!🏃‍♂️\n\n".
            "همین الان روی لینک بزن  👇\n".
            "t.me/{$settings['bot_username']}?start=r_{$row_users['uniq_id']}\n\n".
            "✅ #رایگان و #واقعی 😎",
        'parse_mode' => 'HTML',
    ]);
    $count_refferal = $conn->query("SELECT * FROM ".users." WHERE referral='$user_id'")->rowCount();
    send_reply("sendMessage",[
        'chat_id' => $user_id,
        'text' =>
            "لینک⚡️ دعوت شما با موفقیت ساخته شد 👆\n\n".
            "<code>شما میتوانید بنر حاوی لینک⚡️ خود را به گـــروه ها و دوستان خود ارسال کنید</code>\n\n".
            "با معرفی هر نفر ".($row_admin['coin_per_invite']+$row_admin['coin_per_invite_profile']+$row_admin['coin_per_invite_invite'])." سکه بگیرید! برای اطلاعات بیشتر راهنمای سکه رو بخون (/help_credit)\n\n".
            "👈 شما تاکنون $count_refferal نفر را به این ربات دعوت کرده اید.",
        'reply_to_message_id' => $info_msg['result']['message_id'],
        'parse_mode' => 'HTML',
    ]);
    exit;
}

?>