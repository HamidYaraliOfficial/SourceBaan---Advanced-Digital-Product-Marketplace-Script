import requests
import feedparser
from telegram.ext import Application, ContextTypes
import asyncio
import time
import logging
import pickle
import os
from urllib3.util import Retry
from requests.adapters import HTTPAdapter
import warnings
import certifi
import random

warnings.filterwarnings("ignore", category=UserWarning, module='urllib3')

TOKEN = "BOT_TOKEN"#توکن ربات 
CHANNEL_ID = -1001234567890 #آیدی چنل 
CHECK_INTERVAL = 300 #اینجا مقدار زمانی که میخواین بین هر بار چک کردن منابع باشه رو وارد کنید (ثانیه)

NEWS_SOURCES = {
    "ایرنا": "https://www.irna.ir/rss",
    "خبرگزاری مهر": "https://www.mehrnews.com/rss",
    "خبرگزاری فارس": "https://www.farsnews.ir/rss",
    "خبرگزاری تسنیم": "https://www.tasnimnews.com/fa/rss",
    "خبرگزاری ایسنا": "https://www.isna.ir/rss",
    "خبرآنلاین": "https://www.khabaronline.ir/rss",
    "عصر ایران": "https://www.asriran.com/fa/rss/all",
    "فرارو": "https://fararu.com/fa/rss",
    "اقتصاد آنلاین": "https://www.eghtesadonline.com/rss-feed",
    "بی‌بی‌سی فارسی": "https://www.bbc.com/persian/index.xml",
    "رادیو فردا": "https://www.radiofarda.com/rss",
    "ورزش سه": "https://www.varzesh3.com/rss",
    "زومیت": "https://www.zoomit.ir/rss",
    "دیجیاتو": "https://digiato.com/rss",
    "بورس نیوز": "https://boursenews.ir/rss",
}

STATE_FILE = "last_news_state.pkl"

session = requests.Session()
retry = Retry(total=2, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retry)
session.mount('http://', adapter)
session.mount('https://', adapter)

def load_last_news():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'rb') as f:
                return pickle.load(f)
    except Exception as e:
        logging.error(f"Error loading state file: {e}")
    return {source: None for source in NEWS_SOURCES.keys()}

def save_last_news(last_news_dict):
    try:
        with open(STATE_FILE, 'wb') as f:
            pickle.dump(last_news_dict, f)
    except Exception as e:
        logging.error(f"Error saving state file: {e}")

last_news = load_last_news()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

def fetch_feed_sync(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/rss+xml, application/xml, text/xml, */*',
            'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        
        verify_ssl = certifi.where() if not any(domain in url for domain in ['.ir', 'fararu.com']) else False
        response = session.get(url, timeout=15, verify=verify_ssl, headers=headers)
        response.encoding = 'utf-8'
        return feedparser.parse(response.text)
    except requests.Timeout:
        logging.error(f"Timeout error fetching {url}")
        return None
    except requests.ConnectionError:
        logging.error(f"Connection error fetching {url}")
        return None
    except Exception as e:
        logging.error(f"Error fetching {url}: {e}")
        return None

async def check_news_task(app):
    await asyncio.sleep(15)
    logging.info(f"🚀 شروع به کار با {len(NEWS_SOURCES)} منبع خبری معتبر")
    while True:
        try:
            new_news_count = 0
            for source_name, rss_url in NEWS_SOURCES.items():
                try:
                    feed = fetch_feed_sync(rss_url)
                    if feed and feed.entries:
                        latest_news = feed.entries[0]
                        news_id = latest_news.get('id') or latest_news.link
                        if last_news[source_name] != news_id:
                            message = f"📰 <b>{latest_news.title}</b>\n\n"
                            message += f"🔗 {latest_news.link}\n\n"
                            message += f"🏷 منبع: {source_name}"
                            if hasattr(latest_news, 'published') and latest_news.published:
                                message += f"\n📅 {latest_news.published}"
                            if len(message) > 4096:
                                message = message[:4000] + "..."
                            try:
                                await app.bot.send_message(
                                    chat_id=CHANNEL_ID, 
                                    text=message, 
                                    parse_mode='HTML'
                                )
                                new_news_count += 1
                                logging.info(f"📨 خبر جدید از {source_name}")
                                last_news[source_name] = news_id
                                await asyncio.sleep(random.uniform(1, 3))
                            except Exception as e:
                                logging.error(f"خطای ارسال برای {source_name}: {e}")
                        else:
                            logging.info(f"بدون خبر جدید از {source_name}")
                    else:
                        logging.warning(f"هیچ خبری از {source_name} دریافت نشد")
                    await asyncio.sleep(random.uniform(1, 3))
                except Exception as e:
                    logging.error(f"خطا در پردازش {source_name}: {e}")
                    await asyncio.sleep(2)
            save_last_news(last_news)
            logging.info(f"✅ پردازش کامل. {new_news_count} خبر جدید")
        except Exception as e:
            logging.error(f"❌ خطای کلی: {e}")
        await asyncio.sleep(CHECK_INTERVAL)

def main():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    application = Application.builder().token(TOKEN).build()
    loop.create_task(check_news_task(application))
    logging.info(f"🤖 ربات راه‌اندازی شد با {len(NEWS_SOURCES)} منبع معتبر")
    try:
        application.run_polling()
    except KeyboardInterrupt:
        logging.info("🛑 توقف ربات")
        application.stop_running()
    finally:
        save_last_news(last_news)
        loop.close()

if __name__ == "__main__":
    main()