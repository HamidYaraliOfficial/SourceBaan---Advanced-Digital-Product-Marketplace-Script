import logging
import os
import asyncio
import tempfile
import random
import string
import json
import sqlite3
from datetime import datetime
from telegram import Update, InputSticker, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters, CallbackQueryHandler
from PIL import Image, ImageDraw, ImageFont
import textwrap
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)
TOKEN = "00000"
DB_NAME = "sticker_bot.db"
REQUIRED_CHANNEL = None 
BROADCAST_LOCK = False 
#ایدی ادمین بزارید
ADMINS = [0000, 0000]
user_data = {}
def generate_random_pack_name(bot_username):
    first_char = random.choice(string.ascii_lowercase)
    rest_chars = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    return f"{first_char}{rest_chars}_by_{bot_username}"
def create_glass_inline_keyboard():
    keyboard = [
        [InlineKeyboardButton("🎨 ساخت پک استیکر جدید", callback_data="create_pack")],
        [InlineKeyboardButton("📚 راهنمایی", callback_data="help"),
         InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
    ]
    return InlineKeyboardMarkup(keyboard)
def init_database():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        join_date TIMESTAMP,
        is_banned INTEGER DEFAULT 0,
        usage_count INTEGER DEFAULT 0
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS usage_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT,
        timestamp TIMESTAMP,
        details TEXT
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        added_date TIMESTAMP
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS bot_settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS broadcast_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER,
        message_type TEXT,
        message_text TEXT,
        sent_count INTEGER,
        failed_count INTEGER,
        timestamp TIMESTAMP
    )
    ''')
    for admin_id in ADMINS:
        cursor.execute('''
        INSERT OR IGNORE INTO admins (user_id, added_date) 
        VALUES (?, ?)
        ''', (admin_id, datetime.now()))
    
    cursor.execute('''
    INSERT OR IGNORE INTO bot_settings (key, value) 
    VALUES ('required_channel', ?)
    ''', (REQUIRED_CHANNEL,))
    
    conn.commit()
    conn.close()
def get_required_channel():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('SELECT value FROM bot_settings WHERE key = ?', ('required_channel',))
    result = cursor.fetchone()
    
    conn.close()
    
    if result and result[0] and result[0] != "None":
        return result[0]
    return None

def set_required_channel(channel_username):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    if channel_username == "0":
        cursor.execute('''
        INSERT OR REPLACE INTO bot_settings (key, value) 
        VALUES ('required_channel', NULL)
        ''')
    else:
        cursor.execute('''
        INSERT OR REPLACE INTO bot_settings (key, value) 
        VALUES ('required_channel', ?)
        ''', (channel_username,))
    
    conn.commit()
    conn.close()
    return True
def add_user(user_id, username, first_name, last_name):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    INSERT OR REPLACE INTO users (user_id, username, first_name, last_name, join_date, is_banned)
    VALUES (?, ?, ?, ?, ?, 0)
    ''', (user_id, username, first_name, last_name, datetime.now()))

    conn.commit()
    conn.close()

def log_usage(user_id, action, details=""):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    INSERT INTO usage_log (user_id, action, timestamp, details)
    VALUES (?, ?, ?, ?)
    ''', (user_id, action, datetime.now(), details))

    conn.commit()
    conn.close()

def increment_usage(user_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    UPDATE users SET usage_count = usage_count + 1
    WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()

def is_banned(user_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('SELECT is_banned FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()

    conn.close()

    if result and result[0] == 1:
        return True
    return False

def ban_user(user_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('UPDATE users SET is_banned = 1 WHERE user_id = ?', (user_id,))

    conn.commit()
    conn.close()

def unban_user(user_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('UPDATE users SET is_banned = 0 WHERE user_id = ?', (user_id,))

    conn.commit()
    conn.close()

def is_admin(user_id):
    return user_id in ADMINS or user_id in get_all_admins()

def get_all_admins():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('SELECT user_id FROM admins')
    results = cursor.fetchall()

    conn.close()

    return [result[0] for result in results]

def add_admin(user_id, username):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    INSERT OR REPLACE INTO admins (user_id, username, added_date)
    VALUES (?, ?, ?)
    ''', (user_id, username, datetime.now()))

    conn.commit()
    conn.close()

def remove_admin(user_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('DELETE FROM admins WHERE user_id = ?', (user_id,))

    conn.commit()
    conn.close()

def get_user_stats():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]

    cursor.execute('''
    SELECT COUNT(DISTINCT user_id) FROM usage_log
    WHERE date(timestamp) = date('now')
    ''')
    active_today = cursor.fetchone()[0]
    cursor.execute('SELECT COUNT(*) FROM users WHERE is_banned = 1')
    banned_users = cursor.fetchone()[0]

    conn.close()

    return {
        'total_users': total_users,
        'active_today': active_today,
        'banned_users': banned_users
    }

def get_all_users():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    SELECT user_id, username, first_name, last_name, join_date, is_banned, usage_count
    FROM users ORDER BY join_date DESC
    ''')

    users = cursor.fetchall()
    conn.close()

    return users
async def check_channel_membership(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    required_channel = get_required_channel()
    
    if not required_channel:
        return True 
    
    try:
        member = await context.bot.get_chat_member(required_channel, user_id)
        if member.status in ['left', 'kicked']:
            keyboard = [
                [InlineKeyboardButton("✅ عضو شدم", callback_data="check_membership"),
                 InlineKeyboardButton("🔗 عضویت در کانال", url=f"https://t.me/{required_channel[1:]}")]
            ]
            
            await update.message.reply_text(
                f"⚠️ برای استفاده از ربات، باید در کانال ما عضو شوید:\n{required_channel}\n\n"
                "پس از عضویت، دکمه '✅ عضو شدم' را بزنید.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return False
        return True
    except Exception as e:
        logger.error(f"Error checking channel membership: {e}")
        return True
async def panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return
    
    panel_text = """
🛠 *پنل مدیریت ربات*

لطفاً یکی از دستورات زیر را انتخاب کنید:

📢 *پیام همگانی*
دستور: `/broadcast متن پیام`
کاربرد: ارسال پیام متنی به تمام کاربران

🔄 *فوروارد همگانی*  
دستور: `/fbroadcast`
کاربرد: فوروارد پیام مورد نظر به تمام کاربران (در پاسخ به پیام)

⚙️ *تنظیم کانال*
دستور: `/setchannel @آیدی_کانال`
کاربرد: تنظیم کانال اجباری برای جوین کاربران

👁️ *مشاهده کانال*
دستور: `/getchannel`
کاربرد: مشاهده کانال اجباری فعلی

🗑️ *حذف کانال*
دستور: `/setchannel 0`
کاربرد: حذف کانال اجباری

📊 *آمار ربات*
دستور: `/stats`
کاربرد: مشاهده آمار کاربران ربات

👥 *مدیریت کاربران*
دستور: `/ban آیدی_کاربر` - مسدود کردن کاربر
دستور: `/unban آیدی_کاربر` - آزاد کردن کاربر

🛠 *مدیریت ادمین‌ها*
دستور: `/addadmin آیدی_کاربر` - افزودن ادمین
دستور: `/removeadmin آیدی_کاربر` - حذف ادمین

💡 برای استفاده از هر دستور، آن را به همراه پارامترهای لازم در چت تایپ کنید.
    """
    
    await update.message.reply_text(panel_text, parse_mode='Markdown')
async def setchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return
    
    if not context.args:
        await update.message.reply_text("⚠️ لطفاً آیدی کانال را وارد کنید: `/setchannel @channel_username` یا `/setchannel 0` برای حذف")
        return
    
    channel_username = context.args[0]
    
    if channel_username == "0":
        set_required_channel("0")
        await update.message.reply_text("✅ جوین اجباری حذف شد. کاربران دیگر نیازی به عضویت در کانال ندارند.")
        log_usage(user_id, "remove_channel", "channel requirement removed")
        return
    
    if not channel_username.startswith('@'):
        await update.message.reply_text("⚠️ آیدی کانال باید با @ شروع شود.")
        return
    
    set_required_channel(channel_username)
    await update.message.reply_text(f"✅ کانال اجباری تنظیم شد: {channel_username}")
    log_usage(user_id, "set_channel", f"set to {channel_username}")

async def getchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return
    
    channel = get_required_channel()
    if channel and channel != "None":
        await update.message.reply_text(f"📢 کانال اجباری فعلی: {channel}")
    else:
        await update.message.reply_text("ℹ️ هیچ کانال اجباری تنظیم نشده است. کاربران آزادانه می‌توانند از ربات استفاده کنند.")
async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return
    
    if not context.args:
        await update.message.reply_text("⚠️ لطفاً پیام خود را بعد از دستور وارد کنید: `/broadcast متن پیام`")
        return
    
    if BROADCAST_LOCK:
        await update.message.reply_text("⏳ یک عملیات ارسال همگانی در حال انجام است. لطفاً صبر کنید.")
        return
    
    message_text = ' '.join(context.args)
    await send_broadcast(update, context, message_text)

async def fbroadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return
    
    if not update.message.reply_to_message:
        await update.message.reply_text("⚠️ لطفاً این دستور را در پاسخ به یک پیام فوروارد شده استفاده کنید.")
        return
    
    if BROADCAST_LOCK:
        await update.message.reply_text("⏳ یک عملیات ارسال همگانی در حال انجام است. لطفاً صبر کنید.")
        return
    
    await forward_broadcast(update, context)

async def send_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE, message_text):
    global BROADCAST_LOCK
    BROADCAST_LOCK = True
    
    try:
        users = get_all_users()
        total = len(users)
        success = 0
        failed = 0
        
        progress_msg = await update.message.reply_text(f"📤 ارسال پیام همگانی...\n0/{total}")
        
        for i, user in enumerate(users, 1):
            user_id = user[0]
            
            if i % 10 == 0:
                await progress_msg.edit_text(f"📤 ارسال پیام همگانی...\n{i}/{total}")
            
            try:
                await context.bot.send_message(user_id, message_text)
                success += 1
            except Exception as e:
                logger.error(f"Error sending broadcast to {user_id}: {e}")
                failed += 1
            
            await asyncio.sleep(0.1) 
        
        await progress_msg.edit_text(
            f"✅ ارسال همگانی تکمیل شد!\n\n"
            f"✅ موفق: {success}\n"
            f"❌ ناموفق: {failed}\n"
            f"📊 کل: {total}"
        )
        
    except Exception as e:
        logger.error(f"Error in broadcast: {e}")
        await update.message.reply_text(f"❌ خطا در ارسال همگانی: {e}")
    
    finally:
        BROADCAST_LOCK = False

async def forward_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global BROADCAST_LOCK
    BROADCAST_LOCK = True
    
    try:
        users = get_all_users()
        total = len(users)
        success = 0
        failed = 0
        
        progress_msg = await update.message.reply_text(f"📤 ارسال فوروارد همگانی...\n0/{total}")
        
        for i, user in enumerate(users, 1):
            user_id = user[0]
            
            if i % 10 == 0:
                await progress_msg.edit_text(f"📤 ارسال فوروارد همگانی...\n{i}/{total}")
            
            try:
                await update.message.reply_to_message.forward(user_id)
                success += 1
            except Exception as e:
                logger.error(f"Error forwarding to {user_id}: {e}")
                failed += 1
            
            await asyncio.sleep(0.1) 
        
        await progress_msg.edit_text(
            f"✅ فوروارد همگانی تکمیل شد!\n\n"
            f"✅ موفق: {success}\n"
            f"❌ ناموفق: {failed}\n"
            f"📊 کل: {total}"
        )
        
    except Exception as e:
        logger.error(f"Error in forward broadcast: {e}")
        await update.message.reply_text(f"❌ خطا در فوروارد همگانی: {e}")
    
    finally:
        BROADCAST_LOCK = False

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این بخش را ندارید.")
        return

    stats = get_user_stats()

    keyboard = [
        [InlineKeyboardButton("📊 آمار ربات", callback_data="admin_stats")],
        [InlineKeyboardButton("👥 مدیریت کاربران", callback_data="admin_users")],
        [InlineKeyboardButton("🛠 مدیریت ادمین ها", callback_data="admin_admins")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="cancel")]
    ]

    await update.message.reply_text(
        f"🛠 پنل مدیریت\n\n"
        f"👥 کاربران کل: {stats['total_users']}\n"
        f"📈 فعال امروز: {stats['active_today']}\n"
        f"🚫 کاربران بن: {stats['banned_users']}\n\n"
        f"لطفاً گزینه مورد نظر را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.answer("❌ شما دسترسی به این بخش را ندارید.", show_alert=True)
        return

    stats = get_user_stats()

    await query.edit_message_text(
        f"📊 آمار ربات\n\n"
        f"👥 کاربران کل: {stats['total_users']}\n"
        f"📈 فعال امروز: {stats['active_today']}\n"
        f"🚫 کاربران بن: {stats['banned_users']}\n\n"
        f"برای بازگشت به پنل مدیریت از دکمه زیر استفاده کنید:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت به پنل", callback_data="admin_back")]
        ])
    )

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.answer("❌ شما دسترسی به این بخش را ندارید.", show_alert=True)
        return

    users = get_all_users()[:90]

    users_text = "👥 آخرین کاربران:\n\n"
    for i, user in enumerate(users, 1):
        user_id, username, first_name, last_name, join_date, is_banned, usage_count = user
        display_username = f"@{username}" if username else "بدون یوزرنیم"
        status = "🚫" if is_banned else "✅"
        users_text += f"{i}. {status} {first_name} {last_name} ({display_username}) - آیدی: {user_id} - استفاده: {usage_count}\n"

    users_text += "\nبرای مدیریت یک کاربر، آیدی عددی آن را به صورت `/ban 123456` یا `/unban 123456` ارسال کنید."

    await query.edit_message_text(
        users_text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت به پنل", callback_data="admin_back")]
        ])
    )

async def admin_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.answer("❌ شما دسترسی به این بخش را ندارید.", show_alert=True)
        return

    admins = get_all_admins()

    admins_text = "🛠 لیست ادمین ها:\n\n"
    for admin_id in admins:
        try:
            user = await context.bot.get_chat(admin_id)
            admins_text += f"• {user.first_name} (@{user.username}) - آیدی: {admin_id}\n"
        except:
            admins_text += f"• آیدی: {admin_id} (دسترسی ندارم)\n"

    admins_text += "\nبرای افزودن ادمین: `/addadmin 123456`\nبرای حذف ادمین: `/removeadmin 123456`"

    await query.edit_message_text(
        admins_text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت به پنل", callback_data="admin_back")]
        ])
    )

async def admin_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.answer("❌ شما دسترسی به این بخش را ندارید.", show_alert=True)
        return

    stats = get_user_stats()

    keyboard = [
        [InlineKeyboardButton("📊 آمار ربات", callback_data="admin_stats")],
        [InlineKeyboardButton("👥 مدیریت کاربران", callback_data="admin_users")],
        [InlineKeyboardButton("🛠 مدیریت ادمین ها", callback_data="admin_admins")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="cancel")]
    ]

    await query.edit_message_text(
        f"🛠 پنل مدیریت\n\n"
        f"👥 کاربران کل: {stats['total_users']}\n"
        f"📈 فعال امروز: {stats['active_today']}\n"
        f"🚫 کاربران بن: {stats['banned_users']}\n\n"
        f"لطفاً گزینه مورد نظر را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return

    if not context.args:
        await update.message.reply_text("⚠️ لطفاً آیدی کاربر را وارد کنید: `/ban 123456`")
        return

    try:
        target_id = int(context.args[0])
        ban_user(target_id)
        await update.message.reply_text(f"✅ کاربر با آیدی {target_id} بن شد.")
        log_usage(user_id, "ban_user", f"banned {target_id}")
    except ValueError:
        await update.message.reply_text("⚠️ آیدی کاربر باید عددی باشد.")

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return

    if not context.args:
        await update.message.reply_text("⚠️ لطفاً آیدی کاربر را وارد کنید: `/unban 123456`")
        return

    try:
        target_id = int(context.args[0])
        unban_user(target_id)
        await update.message.reply_text(f"✅ کاربر با آیدی {target_id} آنبن شد.")
        log_usage(user_id, "unban_user", f"unbanned {target_id}")
    except ValueError:
        await update.message.reply_text("⚠️ آیدی کاربر باید عددی باشد.")

async def addadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return

    if not context.args:
        await update.message.reply_text("⚠️ لطفاً آیدی کاربر را وارد کنید: `/addadmin 123456`")
        return

    try:
        target_id = int(context.args[0])
        username = update.effective_user.username or ""
        add_admin(target_id, username)
        ADMINS.append(target_id)
        await update.message.reply_text(f"✅ کاربر با آیدی {target_id} به لیست ادمین ها افزوده شد.")
        log_usage(user_id, "add_admin", f"added {target_id}")
    except ValueError:
        await update.message.reply_text("⚠️ آیدی کاربر باید عددی باشد.")

async def removeadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return

    if not context.args:
        await update.message.reply_text("⚠️ لطفاً آیدی کاربر را وارد کنید: `/removeadmin 123456`")
        return

    try:
        target_id = int(context.args[0])
        if target_id in ADMINS:
            ADMINS.remove(target_id)
        remove_admin(target_id)
        await update.message.reply_text(f"✅ کاربر با آیدی {target_id} از لیست ادمین ها حذف شد.")
        log_usage(user_id, "remove_admin", f"removed {target_id}")
    except ValueError:
        await update.message.reply_text("⚠️ آیدی کاربر باید عددی باشد.")
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    
    if is_banned(user_id):
        await update.message.reply_text("❌ حساب شما مسدود شده است.")
        return
    if not await check_channel_membership(update, context):
        return
    add_user(user_id, user.username, user.first_name, user.last_name)
    log_usage(user_id, "start")

    await update.message.reply_text(
        f"👋 سلام {user.first_name}! به ربات ساخت استیکر خوش آمدید!\n\n"
        f"🛠 از دکمه‌های زیر برای استفاده از ربات استفاده کنید:",
        reply_markup=create_glass_inline_keyboard()
    )
    if is_admin(user_id):
        await update.message.reply_text(
            "👮‍♂️ شما به عنوان ادمین شناسایی شدید. برای دسترسی به پنل مدیریت از /admin استفاده کنید."
        )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    log_usage(user_id, "help")

    await update.message.reply_text(
        "📖 راهنمای استفاده:\n\n"
        "1. ساخت پک استیکر:\n"
        "   دکمه 'ساخت پک استیکر جدید' را بزنید و مراحل را دنبال کنید\n\n"
        "2. برای هر استیکر یک ایموجی انتخاب کنید\n"
        "3. می‌توانید عکس‌ها را ارسال کنید تا به استیکر تبدیل شوند\n"
        "4. در پایان پک شما ساخته می‌شود\n\n"
        "📝 می‌توانید هر متنی (فارسی یا انگلیسی) به عنوان عنوان پک انتخاب کنید!",
        reply_markup=create_glass_inline_keyboard()
    )

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ شما دسترسی به این دستور را ندارید.")
        return

    stats = get_user_stats()

    await update.message.reply_text(
        f"📊 آمار ربات:\n\n"
        f"👥 کاربران کل: {stats['total_users']}\n"
        f"📈 فعال امروز: {stats['active_today']}\n"
        f"🚫 کاربران بن: {stats['banned_users']}"
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    if is_banned(user_id):
        await query.edit_message_text("❌ حساب شما مسدود شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.")
        return
        
    log_usage(user_id, f"button_{data}")

    if data == "create_pack":
        await create_pack_callback(update, context)
    elif data == "check_membership":
        await check_membership_callback(update, context)
    elif data == "help":
        await help_callback(update, context)
    elif data == "cancel":
        await cancel_callback(update, context)
    elif data == "done_stickers":
        await done_callback(update, context)
    elif data == "create_final":
        await create_pack_final_callback(update, context)
    elif data.startswith("admin_"):
        if data == "admin_stats":
            await admin_stats(update, context)
        elif data == "admin_users":
            await admin_users(update, context)
        elif data == "admin_admins":
            await admin_admins(update, context)
        elif data == "admin_back":
            await admin_back(update, context)
async def check_membership_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    
    required_channel = get_required_channel()
    if not required_channel:
        await query.edit_message_text("❌ خطا در سیستم کانال اجباری.")
        return
    
    try:
        member = await context.bot.get_chat_member(required_channel, user_id)
        if member.status in ['left', 'kicked']:
            await query.answer("❌ هنوز در کانال عضو نشده‌اید!", show_alert=True)
        else:
            await query.edit_message_text(
                "✅ عضویت شما تأیید شد! حالا می‌توانید از ربات استفاده کنید.",
                reply_markup=create_glass_inline_keyboard()
            )
    except Exception as e:
        logger.error(f"Error checking membership in callback: {e}")
        await query.answer("❌ خطا در بررسی عضویت!", show_alert=True)
async def create_pack_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    bot_username = context.bot.username
    if is_banned(user_id):
        await query.edit_message_text("❌ حساب شما مسدود شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.")
        return
    random_pack_name = generate_random_pack_name(bot_username)

    user_data[user_id] = {
        'step': 'awaiting_pack_title',
        'stickers': [],
        'pack_name': random_pack_name
    }

    await query.edit_message_text(
        f"🎨 ساخت پک استیکر جدید\n\n"
        f"مرحله ۱: لطفاً یک عنوان برای پک انتخاب کنید\n"
        f"📝 می‌توانید هر عنوانی (فارسی یا انگلیسی) انتخاب کنید\n\n"
        f"مثال: استیکرهای من 😊\n\n"
        "برای انصراف از عملیات از دکمه ❌ انصراف استفاده کنید",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
        ])
    )

async def help_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.edit_message_text(
        "📖 راهنمای استفاده:\n\n"
        "1. ساخت پک استیکر:\n"
        "   دکمه 'ساخت پک استیکر جدید' را بزنید و مراحل را دنبال کنید\n\n"
        "2. برای هر استیکر یک ایموجی انتخاب کنید\n"
        "3. می‌توانید عکس‌ها را ارسال کنید تا به استیکر تبدیل شوند\n"
        "4. در پایان پک شما ساخته می‌شود\n\n"
        "📝 می‌توانید هر متنی (فارسی یا انگلیسی) به عنوان عنوان پک انتخاب کنید!",
        reply_markup=create_glass_inline_keyboard()
    )

async def cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    if user_id in user_data:
        del user_data[user_id]

    await query.edit_message_text(
        "❌ عملیات کنسل شد.",
        reply_markup=create_glass_inline_keyboard()
    )

async def done_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in user_data:
        await query.answer("❌ لطفاً اول دکمه 'ساخت پک استیکر جدید' را بزنید.", show_alert=True)
        return

    user_state = user_data[user_id]

    if user_state.get('step') != 'awaiting_stickers' or len(user_state['stickers']) < 1:
        await query.answer("❌ حداقل یک استیکر نیاز است", show_alert=True)
        return

    user_state['step'] = 'ready_to_create'
    await query.edit_message_text(
        f"✅ آماده ایجاد پک استیکر!\n"
        f"📝 عنوان پک: {user_state.get('pack_title', 'بدون عنوان')}\n"
        f"🚀 برای ایجاد، از دکمه 'ایجاد پک' استفاده کنید",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🚀 ایجاد پک", callback_data="create_final")],
            [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
        ])
    )

async def create_pack_final_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in user_data or user_data[user_id].get('step') != 'ready_to_create':
        await query.answer("❌ لطفاً اول مراحل را کامل کنید", show_alert=True)
        return

    user_state = user_data[user_id]

    try:
        await query.edit_message_text("⏳ در حال ایجاد پک استیکر...")

        sticker_list = []
        for st in user_state['stickers']:
            file = await context.bot.get_file(st['file_id'])

            if st.get('is_photo'):
                with tempfile.NamedTemporaryFile(delete=False, suffix='.webp') as temp_output:
                    await file.download_to_drive(temp_output.name)
                    convert_to_webp(temp_output.name, temp_output.name)
                    input_sticker = InputSticker(
                        sticker=open(temp_output.name, 'rb'),
                        emoji_list=[st['emoji']],
                        format="static"
                    )
                    sticker_list.append(input_sticker)
                    os.unlink(temp_output.name)

            else:
                if st['format'] == 'animated':
                    sticker_format = "animated"
                elif st['format'] == 'video':
                    sticker_format = "video"
                else:
                    sticker_format = "static"
                with tempfile.NamedTemporaryFile(delete=False) as temp_input:
                    await file.download_to_drive(temp_input.name)

                    input_sticker = InputSticker(
                        sticker=open(temp_input.name, 'rb'),
                        emoji_list=[st['emoji']],
                        format=sticker_format
                    )
                    sticker_list.append(input_sticker)

                    os.unlink(temp_input.name)
        first_sticker_format = user_state['stickers'][0].get('format', 'static')
        if first_sticker_format == 'animated':
            pack_type = "animated"
        elif first_sticker_format == 'video':
            pack_type = "video"
        else:
            pack_type = "regular"
        await context.bot.create_new_sticker_set(
            user_id=user_id,
            name=user_state['pack_name'],
            title=user_state.get('pack_title', 'My Stickers'),
            stickers=sticker_list,
            sticker_type=pack_type
        )
        increment_usage(user_id)
        log_usage(user_id, "create_pack", f"pack: {user_state['pack_name']}")
        pack_link = f"https://t.me/addstickers/{user_state['pack_name']}"
        await query.edit_message_text(
            f"🎉 پک استیکر شما با موفقیت ایجاد شد!\n\n"
            f"🔗 لینک پک: {pack_link}\n\n"
            f"📝 عنوان پک: {user_state.get('pack_title', 'بدون عنوان')}\n"
            f"📊 تعداد استیکرها: {len(user_state['stickers'])}\n",
            reply_markup=create_glass_inline_keyboard()
        )
        del user_data[user_id]

    except Exception as e:
        logger.error(f"Error creating sticker pack: {e}")
        error_message = str(e)

        if "sticker set name is already occupied" in error_message.lower():
            bot_username = context.bot.username
            new_pack_name = generate_random_pack_name(bot_username)
            user_data[user_id]['pack_name'] = new_pack_name

            await query.edit_message_text(
                f"❌ این نام پک قبلاً استفاده شده است.\n"
                f"🔄 نام جدید تولید شد: {new_pack_name}\n\n"
                f"لطفاً دوباره دکمه 'ایجاد پک' را بزنید.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🚀 ایجاد پک", callback_data="create_final")],
                    [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
                ])
            )
        elif "invalid sticker set name" in error_message.lower():
            bot_username = context.bot.username
            new_pack_name = generate_random_pack_name(bot_username)
            user_data[user_id]['pack_name'] = new_pack_name

            await query.edit_message_text(
                f"❌ مشکل در نام پک.\n"
                f"🔄 نام جدید تولید شد: {new_pack_name}\n\n"
                f"لطفاً دوباره دکمه 'ایجاد پک' را بزنید.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🚀 ایجاد پک", callback_data="create_final")],
                    [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
                ])
            )
        elif "dimensions" in error_message.lower():
            await query.edit_message_text(
                "❌ مشکل در ابعاد استیکر! لطفاً فقط استیکرهای استاندارد تلگرام ارسال کنید.\n"
                "📏 ابعاد باید 512x512 پیکسل باشد.",
                reply_markup=create_glass_inline_keyboard()
            )
        else:
            await query.edit_message_text(
                f"❌ خطا در ایجاد پک استیکر:\n{error_message}\n\n"
                "⚠️ لطفاً دوباره تلاش کنید.",
                reply_markup=create_glass_inline_keyboard()
            )
        if user_id in user_data and "sticker set name is already occupied" not in error_message.lower() and "invalid sticker set name" not in error_message.lower():
            del user_data[user_id]
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    text = update.message.text 
    if is_banned(user_id):
        await update.message.reply_text("❌ حساب شما مسدود شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.")
        return
    if user_id not in user_data:
        await update.message.reply_text(
            "لطفاً از دکمه‌های زیر برای استفاده از ربات استفاده کنید:",
            reply_markup=create_glass_inline_keyboard()
        )
        return

    user_state = user_data[user_id]

    if user_state.get('step') == 'awaiting_pack_title':
        user_state['pack_title'] = text
        user_state['step'] = 'awaiting_stickers'

        await update.message.reply_text(
            f"✅ عنوان پک ذخیره شد: {text}\n\n"
            "📤 حالا استیکرها یا عکس‌ها را ارسال کنید\n"
            "📸 عکس‌ها به صورت خودکار به استیکر تبدیل می‌شوند\n"
            "پس از ارسال همه استیکرها، دکمه 'اتمام استیکرها' را بزنید",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ اتمام استیکرها", callback_data="done_stickers")],
                [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
            ])
        )

    elif user_state.get('step') == 'awaiting_emoji':
        if text.strip():
            user_state['current_sticker']['emoji'] = text.strip()
            user_state['stickers'].append(user_state['current_sticker'])
            del user_state['current_sticker']
            user_state['step'] = 'awaiting_stickers'

            count = len(user_state['stickers'])
            await update.message.reply_text(
                f"✅ استیکر {count} ذخیره شد!\n"
                "📤 استیکر بعدی را ارسال کنید یا دکمه 'اتمام' را بزنید",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ اتمام استیکرها", callback_data="done_stickers")],
                    [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
                ])
            )
        else:
            await update.message.reply_text(
                "⚠️ لطفاً یک ایموجی معتبر ارسال کنید:\n"
                "مثال: 😊 یا ❤️"
            )
async def handle_sticker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    text = update.message.text 
    if is_banned(user_id):
        await update.message.reply_text("❌ حساب شما مسدود شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.")
        return

    if user_id not in user_data or user_data[user_id].get('step') != 'awaiting_stickers':
        await update.message.reply_text(
            "⚠️ لطفاً اول دکمه 'ساخت پک استیکر جدید' را بزنید و عنوان پک را تنظیم کنید.",
            reply_markup=create_glass_inline_keyboard()
        )
        return

    sticker = update.message.sticker
    user_state = user_data[user_id]
    user_state['current_sticker'] = {
        'file_id': sticker.file_id,
        'format': sticker.is_animated and 'animated' or sticker.is_video and 'video' or 'static',
        'is_photo': False
    }
    user_state['step'] = 'awaiting_emoji'

    await update.message.reply_text(
        "✅ استیکر دریافت شد!\n\n"
        "🎮 لطفاً یک ایموجی برای این استیکر انتخاب کنید و ارسال کنید:\n"
        "مثال: 😊 یا ❤️\n\n"
        "⚠️ فقط یک ایموجی ارسال کنید",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
        ])
    )

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    text = update.message.text 
    if is_banned(user_id):
        await update.message.reply_text("❌ حساب شما مسدود شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.")
        return

    if user_id not in user_data or user_data[user_id].get('step') != 'awaiting_stickers':
        await update.message.reply_text(
            "⚠️ لطفاً اول دکمه 'ساخت پک استیکر جدید' را بزنید و عنوان پک را تنظیم کنید.",
            reply_markup=create_glass_inline_keyboard()
        )
        return

    photo = update.message.photo[-1]
    user_state = user_data[user_id]
    user_state['current_sticker'] = {
        'file_id': photo.file_id,
        'format': 'static',
        'is_photo': True
    }
    user_state['step'] = 'awaiting_emoji'

    await update.message.reply_text(
        "📸 عکس دریافت شد! (به استیکر تبدیل خواهد شد)\n\n"
        "🎮 لطفاً یک ایموجی برای این استیکر انتخاب کنید و ارسال کنید:\n"
        "مثال: 😊 یا ❤️\n\n"
        "⚠️ فقط یک ایموجی ارسال کنید",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ انصراف", callback_data="cancel")]
        ])
    )

def convert_to_webp(input_path, output_path, size=512):
    try:
        with Image.open(input_path) as img:
            if img.mode in ('RGBA', 'LA'):
                background = Image.new('RGB', img.size, (255, 255, 255))
                background.paste(img, mask=img.split()[-1])
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')
            width, height = img.size
            if width > height:
                new_width = size
                new_height = int(height * (size / width))
            else:
                new_height = size
                new_width = int(width * (size / height))
            try:
                img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            except AttributeError:
                img = img.resize((new_width, new_height), Image.LANCZOS)
            new_img = Image.new('RGB', (size, size), (255, 255, 255))
            x_offset = (size - new_width) // 2
            y_offset = (size - new_height) // 2
            new_img.paste(img, (x_offset, y_offset))

            new_img.save(output_path, 'WEBP', quality=95)

    except Exception as e:
        logger.error(f"Error converting image to WEBP: {e}")
        raise

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Exception while handling an update: {context.error}")
    try:
        if update and update.effective_message:
            user_info = f"User: {update.effective_user.id} - {update.effective_user.username}"
            message_info = f"Message: {update.effective_message.text}"
            logger.error(f"{user_info} | {message_info}")
    except:
        pass
    try:
        if update and update.effective_message:
            await update.effective_message.reply_text(
                "❌ متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
                reply_markup=create_glass_inline_keyboard()
            )
    except:
        pass

def main():
    init_database()
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("admin", admin_panel))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("unban", unban_command))
    application.add_handler(CommandHandler("addadmin", addadmin_command))
    application.add_handler(CommandHandler("removeadmin", removeadmin_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    application.add_handler(MessageHandler(filters.Sticker.ALL, handle_sticker))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_error_handler(error_handler)
    application.add_handler(CommandHandler("setchannel", setchannel_command))
    application.add_handler(CommandHandler("panel", panel_command))
    application.add_handler(CommandHandler("getchannel", getchannel_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    application.add_handler(CommandHandler("fbroadcast", fbroadcast_command))
    # راه اندازی ربات
    logger.info("ربات در حال راه اندازی...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()