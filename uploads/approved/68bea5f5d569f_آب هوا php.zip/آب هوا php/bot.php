<?php

define('TELEGRAM_TOKEN', 'BOT_TOKEN'); //توکن ربات شما 


function sendTelegramRequest($method, $params = []) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getWeather($latitude, $longitude) {
    $url = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current_weather=true";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['current_weather'])) {
        $weather = $data['current_weather'];
        $temperature = $weather['temperature'];
        $windspeed = $weather['windspeed'];
        $winddirection = $weather['winddirection'];
        $weathercode = $weather['weathercode'];
        
      
        $weather_descriptions = [
            0 => "آسمان صاف",
            1 => "عمدتاً صاف",
            2 => "نیمه ابری",
            3 => "ابری",
            45 => "مه",
            48 => "مه رسانا",
            51 => "نمنم باران",
            53 => "باران ملایم",
            55 => "باران شدید",
            56 => "باران یخ‌زده",
            57 => "باران یخ‌زده شدید",
            61 => "باران ملایم",
            63 => "باران",
            65 => "باران شدید",
            66 => "باران یخ‌زده",
            67 => "باران یخ‌زده شدید",
            71 => "بارش برف ملایم",
            73 => "بارش برف",
            75 => "بارش برف شدید",
            77 => "دانه‌های برف",
            80 => "رگبار باران ملایم",
            81 => "رگبار باران",
            82 => "رگبار باران شدید",
            85 => "رگبار برف",
            86 => "رگبار برف شدید",
            95 => "رعد و برق",
            96 => "رعد و برق با بارش تگرگ",
            99 => "رعد و برق با بارش تگرگ شدید"
        ];
        
        $description = $weather_descriptions[$weathercode] ?? "نامشخص";
        
        return "دمای فعلی: {$temperature}°C\nسرعت باد: {$windspeed} km/h\nجهت باد: {$winddirection}°\nوضعیت: {$description}";
    } else {
        return "مشکلی در دریافت اطلاعات آب و هوا پیش آمد.";
    }
}


$update = json_decode(file_get_contents('php://input'), true);

if (isset($update['message'])) {
    $message = $update['message'];
    $chat_id = $message['chat']['id'];
    $text = $message['text'] ?? '';
    
  
    if ($text === '/start') {
        $keyboard = [
            'keyboard' => [
                ['تهران', 'مشهد'],
                ['اصفهان', 'شیراز'],
                ['موقعیت من']
            ],
            'resize_keyboard' => true
        ];
        
        $params = [
            'chat_id' => $chat_id,
            'text' => "به ربات آب و هوا خوش آمدید!\nلطفاً یک شهر را انتخاب کنید یا موقعیت خود را ارسال کنید.",
            'reply_markup' => json_encode($keyboard)
        ];
        
        sendTelegramRequest('sendMessage', $params);
    }
    
    elseif (isset($message['location'])) {
        $latitude = $message['location']['latitude'];
        $longitude = $message['location']['longitude'];
        
        $weather_info = getWeather($latitude, $longitude);
        
        $params = [
            'chat_id' => $chat_id,
            'text' => $weather_info
        ];
        
        sendTelegramRequest('sendMessage', $params);
    }
   
    else {
       
        $cities = [
            'تهران' => [35.6892, 51.3890],
            'مشهد' => [36.2605, 59.6168],
            'اصفهان' => [32.6546, 51.6680],
            'شیراز' => [29.5918, 52.5837],
            'تبریز' => [38.0962, 46.2738],
            'کرج' => [35.8400, 50.9391],
            'اهواز' => [31.3183, 48.6706],
            'قم' => [34.6400, 50.8764],
            'کرمان' => [30.2839, 57.0834],
            'ارومیه' => [37.5527, 45.0761]
        ];
        
        if (isset($cities[$text])) {
            list($latitude, $longitude) = $cities[$text];
            $weather_info = getWeather($latitude, $longitude);
            
            $params = [
                'chat_id' => $chat_id,
                'text' => "آب و هوای $text:\n$weather_info"
            ];
            
            sendTelegramRequest('sendMessage', $params);
        }
        elseif ($text === 'موقعیت من') {
            $params = [
                'chat_id' => $chat_id,
                'text' => "لطفاً موقعیت خود را از طریق گزینه اشتراک‌گذاری موقعیت ارسال کنید."
            ];
            
            sendTelegramRequest('sendMessage', $params);
        }
        else {
            $params = [
                'chat_id' => $chat_id,
                'text' => "شهر مورد نظر یافت نشد. لطفاً از بین گزینه‌ها انتخاب کنید."
            ];
            
            sendTelegramRequest('sendMessage', $params);
        }
    }
}


echo "OK";
?>