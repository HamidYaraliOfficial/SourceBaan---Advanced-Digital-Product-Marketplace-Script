import telebot
import requests
import qrcode
from io import BytesIO

TOKEN = "BOT_TOKEN"  #توکن ربات 
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "سلام! فایل، عکس یا ویدیوی خود را بفرستید تا QR Code دانلود آن تولید شود.")

@bot.message_handler(content_types=['document', 'photo', 'video'])
def handle_file(message):
    file_id = None
    if message.document:
        file_id = message.document.file_id
    elif message.photo:
        file_id = message.photo[-1].file_id  
    elif message.video:
        file_id = message.video.file_id
    
    if file_id:
        
        msg = bot.reply_to(message, "❖ **در حال ایجاد QR Code...**", parse_mode="Markdown")
        
        
        file_info = bot.get_file(file_id)
        file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_info.file_path}"
        
        
        api_url = f"https://tinyurl.com/api-create.php?url={file_url}"
        response = requests.get(api_url)
        
        if response.status_code == 200 and response.text.startswith("https://tinyurl.com"):
            short_url = response.text
            
            
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(short_url)
            qr.make(fit=True)
            
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            
            bio = BytesIO()
            img.save(bio, format="PNG")
            bio.seek(0)
            
            
            bot.send_photo(message.chat.id, bio, caption=f"https://info-me.netlify.app")
            bot.delete_message(message.chat.id, msg.message_id)  # حذف پیام "در حال ایجاد..."
        else:
            bot.edit_message_text("خطا", 
                                 chat_id=message.chat.id, message_id=msg.message_id)
    else:
        bot.reply_to(message, "⚠️ لطفاً یک فایل معتبر ارسال کنید!")

bot.polling(non_stop=True)