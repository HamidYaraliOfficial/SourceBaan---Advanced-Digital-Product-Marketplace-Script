<?php
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam

$token = '';//token
$admin = 0000000;//admin
$url = "https://api.telegram.org/bot$token";

$update = json_decode(file_get_contents("php://input"), true);

if (!isset($update['message'])) exit;

$message = $update['message'];
$text = $message['text'] ?? '';
$chat_id = $message['chat']['id'];
$user_id = $message['from']['id'];
$message_id = $message['message_id'];
$is_reply = isset($message['reply_to_message']);


if ($text === '/start') {
    send($chat_id, "سلام به ربات من خوش امدید پیام خود را ارسال کنید تا به ادمین برسونم");
    exit;
}


if ($user_id == $admin && $is_reply) {
    $replied_text = $message['reply_to_message']['text'] ?? '';
    if (preg_match('/آیدی عددی: (\d+)/', $replied_text, $matches)) {
        $target_id = $matches[1];
        send($target_id, "📬 پاسخ ادمین:\n\n$text");
        send($admin, "✅ پیام شما برای کاربر ارسال شد.");
    } else {
        send($admin, "❌ آیدی کاربر وجود یوختو.");
    }
    exit;
}


if ($user_id != $admin) {
    send($chat_id, "✅ پیام شما ارسال شد منتظر پاسخ باشید.");

    $msg = "📩 پیام جدید از کاربر:\n"
         . "👤 نام: " . $message['from']['first_name'] . "\n"
         . "🏷️ یوزرنیم: @" . ($message['from']['username'] ?? 'ندارد') . "\n"
         . "🆔 آیدی عددی: $user_id\n\n"
         . "📝 پیام:\n$text";

    send($admin, $msg);
    exit;
}


function send($chat_id, $text)
{
    global $url;
    $data = [
        'chat_id' => $chat_id,
        'text' => $text
    ];
    file_get_contents($url . "/sendMessage?" . http_build_query($data));
    
}

//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam
//@criptalteam

?>