<?php
/*
 * In the name of god 
 * Developer : @Mr_Mordad
 * Channel : @Iceuploder
 */
include_once('config.php');
if (!isset($_GET['hash']) || $_GET['hash'] !== 'okiamking') {
    die("I'm safe =)");
}


if ($set['status'] == 'off' and $from_id != $config['bot']['admins'][0] and !$db->select('admins', '*',['user_id' => $from_id])[0] ){
    sm("❌ ربات فعلا خاموش است.");
    exit();
}
if ($user['ban'] == 'yes'){
    sm("❌ شما از ربات مسدود شده اید.");
    exit();
}
if ($text == '/start'){
    if (IsJoin() == false){
    sm($set['start']);
     }else{
     sm("👇 کاربر گرامی شما باید در تمامی چنل های زیر جوین شوید و سپس مجدد ربات را /start کنید.\n\n{$set['channel']}");   
    }
    $db->update('users',['step' => NULL],['user_id' => $chat_id]);
    if (!$user){
        $db->insert('users',[
            'user_id' => $from_id,
            ]);
    }
}

if (strpos($text,'/start dl_') !== false){
    if (!$user){
        $db->insert('users',[
            'user_id' => $from_id,
            ]);
    }
   if (IsJoin() == false){
    $code = explode ("/start dl_",$text)[1];
    $ex = $db->select('dlfile', '*', ['code'=>$code])[0];
    if ($ex['number_download'] > $ex['max_download']){
       sm("متاسفم محدودیت دانلود این رسانه به پایان رسیده است.");
       exit();
   }
    $type = $ex['type'];
     if ($ex){
      if ($ex['password'] == null){
        if ($db->select('dlfile','*',['code' => $code])[1]){
           foreach ($db->select('dlfile','*',['code' => $code]) as $infor){
            $type = $infor['type'];
             request('send'.$infor['type'], [
            'chat_id' => $from_id,
            "$type" => $infor['file_id'],
            'caption' => $infor['caption']
          ]);   
           }   
         }else{
       request('send'.$ex['type'], [
            'chat_id' => $from_id,
            "$type" => $ex['file_id'],
            'caption' => $ex['caption']
        ]); 
          }
        $db->update('dlfile',['number_download' => $ex['number_download'] +1 ],['code' => $code]);
        for ($i = 1; $i <= count($db->select('dlfile','*',['code' => $code])); $i += 1) {
          $db->insert('delmsg',['msg' => $message_id + $i , 'user_id' => $from_id]);
        }
        if ($set['del'] == 'on'){
            sm("👆 لطفا رسانه ارسالی را در پیام های ذخیره خود ذخیره کنید این رسانه تا چند لحظه دیگر پاک میشود.",null,$message_id +1); 
            if (!$db->select('dlfile','*',['code' => $code])[1]){
             $db->insert('delmsg',['msg' => $message_id + 1 , 'user_id' => $from_id]);
            }else{
             for ($i = 1; $i <= count($db->select('dlfile','*',['code' => $code])); $i += 1) {
              $db->insert('delmsg',['msg' => $message_id + $i , 'user_id' => $from_id]);
               }
            }
        }
        if ($set['sendtab'] == 'yes' and $set['tab'] != null){
            sm($set['tab']);
        }
      }else{
       sm("لطفا پسورد خود را وارد کنید");   
       $db->update('users',['step' => 'getfilepass','save' => $code],['user_id' => $chat_id]);   
      }
     }else{
     sm("کاربر گرامی این فایل در ربات موجود نیست.");   
    }  
   }else{
     $code = explode ("/start dl_",$text)[1];
     $key = json_encode([
         'inline_keyboard' => [
             [['text' => 'عضو شدم','callback_data' => "join|$code"]]
             ]
         ]);
     sm("👇 کاربر گرامی شما باید در تمامی چنل های زیر جوین شوید \n\n{$set['channel']}",$key);  
   }
}
else if (strpos($data,'join|') !== false){
   if (IsJoin() == false){
    $code = explode ("join|",$data)[1];
    $ex = $db->select('dlfile', '*', ['code'=>$code])[0];
    if ($ex['number_download'] > $ex['max_download']){
       sm("متاسفم محدودیت دانلود این رسانه به پایان رسیده است.");
       exit();
   }
    $type = $ex['type'];
     if ($ex){
        if ($ex['password'] == null){
       del($message_id);
       if ($db->select('dlfile','*',['code' => $code])[1]){
           foreach ($db->select('dlfile','*',['code' => $code]) as $infor){
            $type = $infor['type'];
             request('send'.$infor['type'], [
            'chat_id' => $from_id,
            "$type" => $infor['file_id'],
            'caption' => $infor['caption']
          ]);   
           }   
         }else{
       request('send'.$ex['type'], [
            'chat_id' => $from_id,
            "$type" => $ex['file_id'],
            'caption' => $ex['caption']
        ]); 
          }
        $db->update('dlfile',['number_download' => $ex['number_download'] +1 ],['code' => $code]);
        if ($set['del'] == 'on'){
            sm("👆 لطفا رسانه ارسالی را در پیام های ذخیره خود ذخیره کنید این رسانه تا چند لحظه دیگر پاک میشود.",null,$message_id +1); 
            if (!$db->select('dlfile','*',['code' => $code])[1]){
             $db->insert('delmsg',['msg' => $message_id + 1 , 'user_id' => $from_id]);
            }else{
             for ($i = 1; $i <= count($db->select('dlfile','*',['code' => $code])); $i += 1) {
              $db->insert('delmsg',['msg' => $message_id + $i , 'user_id' => $from_id]);
               }
            }
        }
        if ($set['sendtab'] == 'yes' and $set['tab'] != null){
            sm($set['tab']);
        }
        $db->update('users',['step' => null,'save' => null],['user_id' => $from_id]);
        }else{
       sm("لطفا پسورد خود را وارد کنید");   
       $db->update('users',['step' => 'getfilepass','save' => $code],['user_id' => $chat_id]);   
        }
     }else{
     sm("کاربر گرامی این فایل در ربات موجود نیست.");   
    }    
    }else{
     $code = explode ("join|",$data)[1];
     $key = json_encode([
         'inline_keyboard' => [
             [['text' => 'عضو شدم','callback_data' => "join|$code"]]
             ]
         ]);
     sm("👇 کاربر گرامی شما باید در تمامی چنل های زیر جوین شوید \n\n{$set['channel']}",$key);     
    }
}
else if ($user['step'] == 'getfilepass'){
   $ex = $db->select('dlfile', '*', ['code'=> $user['save']])[0];
   if ($ex['number_download'] > $ex['max_download']){
       sm("متاسفم محدودیت دانلود این رسانه به پایان رسیده است.");
       exit();
   }
   if ($text == $ex['password']){
     $type = $ex['type'];
     if ($db->select('dlfile','*',['code' => $user['save']])[1]){
           foreach ($db->select('dlfile','*',['code' => $user['save']]) as $infor){
            $type = $infor['type'];
             request('send'.$infor['type'], [
            'chat_id' => $from_id,
            "$type" => $infor['file_id'],
            'caption' => $infor['caption']
          ]);   
           }   
         }else{
       request('send'.$ex['type'], [
            'chat_id' => $from_id,
            "$type" => $ex['file_id'],
            'caption' => $ex['caption']
        ]); 
          }
        $db->update('dlfile',['number_download' => $ex['number_download'] +1 ],['code' => $code]);
        if ($set['del'] == 'on'){
            sm("👆 لطفا رسانه ارسالی را در پیام های ذخیره خود ذخیره کنید این رسانه تا چند لحظه دیگر پاک میشود.",null,$message_id +1); 
            if (!$db->select('dlfile','*',['code' => $code])[1]){
             $db->insert('delmsg',['msg' => $message_id + 1 , 'user_id' => $from_id]);
            }else{
             for ($i = 1; $i <= count($db->select('dlfile','*',['code' => $code])); $i += 1) {
              $db->insert('delmsg',['msg' => $message_id + $i , 'user_id' => $from_id]);
               }
            }
        }
        if ($set['sendtab'] == 'yes' and $set['tab'] != null){
            sm($set['tab']);
        }
    $db->update('users',['step' => null,'save' => null],['user_id' => $from_id]);
   }else{
       sm("کاربر گرامی پسورد شما اشتباه است لطفا مجدد تست کنید.");
       $db->update('users',['step' => null,'save' => null],['user_id' => $from_id]);
   }
}

else if (in_array($from_id,$config['bot']['admins']) or $db->select('admins', '*',['user_id' => $from_id])[0] ){
    if(strtolower($text) == '/panel' or $text == '🔙 بازگشت'){
        sm("💎 ادمین عزیز به پنل ربات خوش اومدید",$config['keyboards']['panel']);
        $db->update('users',['step' => null],['user_id' => $from_id]);
    }
    else if ($text == '👤 آمار ربات'){
        if ($set['status'] == 'on' or $set['status'] == NULL){
            $status = '✅ فعال';
        }else{
            $status = '❌ غیر فعال';
        }
        $block = count($db->select('users','*',['ban' => 'yes']));
        $pass = count($db->select('dlfile','*',["password[!]" => null]));
     sm("🤖 آمار ربات شما\n\n🤖 <b>وضعیت ربات :</b> <code>$status</code>\n📝 <b>تعداد کاربران :</b> <code>{$db->count('users')}</code>\n👥 <b>تعداد ادمین ها :</b> <code>{$db->count('admins')}</code>\n<b>🔑 تعداد رسانه های دارای پسورد : </b> <code>$pass</code>\n📥 <b>تعداد رسانه آپلود شده :</b> <code>{$db->count('dlfile')}</code>\n<b>❌ تعداد کاربران بلاک شده :</b> <code>$block</code>");
    }
    else if ($text == '🔺 روشن کردن'){
        if($set['status'] == 'on'){
          sm("ربات از قبل روشن بود❕️"); 
         }else{
          sm("ربات با موفقیت روشن شد ✅");
          $db->update('admin',['status' => 'on']);
        }
    }
    else if ($text == 'خاموش کردن 🔻'){
        if($set['status'] == 'off'){
          sm("ربات از قبل خاموش بود❕️"); 
         }else{
          sm("ربات با موفقیت خاموش شد ✅");
          $db->update('admin',['status' => 'off']);
        }
    }
    else if ($text == '❌ مسدود کردن' || $text == 'آزاد سازی ✅'){
      if ($text == 'آزاد سازی ✅'){
          $step = 'block|no';
      }else{
          $step = 'block|yes';
      }
      $db->update('users',['step' => $step],['user_id' => $from_id]);
      sm("👤 لطفا ایدی عددی کاربر را وارد کنید.",$config['keyboards']['back']);
    }
    else if (strpos($user['step'],'block|') !== false){
     $ex = explode('block|',$user['step'])[1];
     if ($ex == $usertext['ban']){
      sm("❌ این عملیات از قبل انجام شده است.",$config['keyboards']['panel']);
      $db->update('users',['step' => NULL],['user_id' => $from_id]);
      die();
     }
     if(preg_match("/^(-){0,1}([0-9]+)(,[0-9][0-9][0-9])*([.][0-9]){0,1}([0-9]*)$/",$text)){
       if ($db->select('users','*',['user_id' => $text]) or $text == $set['owner']){
         sm("✅ با موفقیت انجام شد.",$config['keyboards']['panel']);  
         $db->update('users',['step' => NULL],['user_id' => $from_id]);
         $db->update('users',['ban' => $ex],['user_id' => $text]);
       }else{
       sm("🗳 این کاربر ربات را استارت نکرده است یا مالک اصلی ربات است.");       
       }
      }else{
       sm("❌ لطفا از اعداد لاتین استفاده کنید."); 
     }
    }
    else if ($text == 'مدیریت متن ها 📝️'){
        $key = json_encode([
            'keyboard' => [
                [['text' => '📝 تنظیم متن استارت'],['text' => '🔖 تنظیم متن کپشن']],
                [['text'=>"🔙 بازگشت"]],
                ],
                'resize_keyboard' => true
            ]);
        sm("👇 لطفا بخش مورد نظر خود را انتخاب کنید.",$key);
    }
    else if ($text == '🔖 تنظیم متن کپشن' || $text == '📝 تنظیم متن استارت'){
        if ($text == '📝 تنظیم متن استارت'){
            $step = 'text|start'; 
        }else{
            $step = 'text|caption';
        }
        $db->update('users',['step' => $step],['user_id' => $from_id]);
        sm("👇 لطفا متن خود را وارد کنید.",$config['keyboards']['back']);
    }
    else if (strpos($user['step'],'text|') !== false and $text != '🔙 بازگشت'){
        $ex = explode('text|',$user['step'])[1];
        sm("✅ با موفقیت تنظیم شد.",$config['keyboards']['panel']);
        $db->update('admin',["$ex" => $text]);
        $db->update('users',['step' => NULL],['user_id' => $from_id]);
    }
    else if ($text == '📥 آپلود رسانه'){
        $db->update('users',['step' => 'uplode'],['user_id' => $from_id]);
        sm("🌟 لطفا فایل خود را وارد کنید \n\nشما می توانید پرونده(سند) ، ویدیو ، عکس ، ویس ، استیکر ، موزیک را ارسال کنید تا در ربات آپلود شود .",$config['keyboards']['back']);
    }
    else if ($user['step'] == 'uplode' and $text != '🔙 بازگشت'){
    if (isset($message->video)){
      $file_id = $message->video->file_id;
      $file_size = $message->video->file_size;
         $size = convert($file_size);
         $type = 'video';  
    }
    else if (isset($message->document)){
      $file_id = $message->document->file_id;
      $file_size = $message->document->file_size;
         $size = convert($file_size);
         $type = 'document';  
    }
    else if (isset($message->photo)){
      $photo = $message->photo;
      $file_id = $photo[count($photo)-1]->file_id;
      $file_size = $photo[count($photo)-1]->file_size;
         $size = convert($file_size);
         $type = 'photo';  
    }
    else if (isset($message->voice)){
      $file_id = $message->voice->file_id;
      $file_size = $message->voice->file_size;
         $size = convert($file_size);
         $type = 'voice';  
    }
    else if (isset($message->audio)){
      $file_id = $message->audio->file_id;
      $file_size = $message->audio->file_size;
         $size = convert($file_size);
         $type = 'audio';  
    }
    else if (isset($message->sticker)){
      $file_id = $message->sticker->file_id;
      $file_size = $message->sticker->file_size;
         $size = convert($file_size);
         $type = 'sticker';  
    }
    if ($file_id == NULL){
        sm("❌ این رسانه مجاز نیست.");
        die();
    }
    if ($db->select('dlfile','file_id',['file_id' => $file_id])[0]){
        sm("❌ این رسانه قبلا در دیتابیس اپلود شده است.");
        die();
     }
    $filefa = document($type);
    sm("🔰 توضیحات خود را وارد کنید\n\n🌟 نوع فایل شما : $filefa\n\nتوضیحات حداکثر 500 کاراکتر میتواند باشد.\n\n ❌ توجه داشته باشید در صورت ارسال /skip هیچ توضیحی برای رسانه شما نخواهد بود و در صورت ارسال /text متن از قبل تنظیم شده شما داده میشود.",$key);
    $db->update('users',['step' => 'uplode1','save' => "$size|$type|$file_id"],['user_id' => $from_id]);
   }
   else if ($user['step'] == 'uplode1'){
        
     if(mb_strlen($text) < 501){
        $info = $text;
        if($text == '/skip'){
          $info = null;
      }
      if($text == '/text'){
          if($db->select('admin','caption')[0] == NULL){
             sm("شما متنی از قبل تنظیم نکرده اید و رسانه بدون متن ارسال میشود."); 
             $info = null;
          }else{
              $info = $set['caption'];
          }
       }
         sm("در حال اپلودر فایل ...",$config['keyboards']['panel']);
         $db->update('users',['step' => NULL,'save' => null],['user_id' => $from_id]);
         $code = RandomString();
         $ex = explode('|',$user['save']);
         $type = document($ex[1]);
         $size = $ex[0];
         $botid = GetMe('username',$config['bot']['token']);
         $db->insert('dlfile',['code' => $code,'file_id' => $ex[2],'file_size' => $size,'time' => $date,'type' => $ex[1],'like_file' => 0,'max_download' => 9999999,'dl'  => 0,'caption' => $info,'number_download' => 0,]);
         sm("✅ رسانه شما با موفقیت اپلود شد.\n\n💡 کد رسانه : <code>$code</code>\n🌟 نوع رسانه : $type\n📅 تاریخ اپلود : $date\n🔸 اندازه : $size\n\n🔗 لینک دریافت : https://t.me/$botid?start=dl_$code",json_encode([
             'inline_keyboard' => [
                 [['text' => 'ارسال به چنل','callback_data' => "send|$code"]],
                 [['text' => 'تنظیم پسورد','callback_data' => "password|$code"]],
                 ],
             ]));
        }else{
         sm("❌ خطا ! توضیحات طولانی است");  
       }
   }
   else if (strpos($data,'send|') !== false){
       $ex = explode('send|',$data)[1];
       $select = $db->select('dlfile','*',['code' => $ex])[0];
       $info = $select['caption'];
       
       if ($db->select('admin','MediaChannel')[0] == NULL){
        sm("❌ کاربر گرامی چنل ارسال رسانه شما تنظیم نشده است لطفا از پنل مدیریت اقدام به تنظیم چنل بکنید.");   
        die();
        }else{
        sm("✅ رسانه با موفقیت به چنل ارسال شد.");
        $botid = GetMe('username',$config['bot']['token']);
        $key = json_encode([
            'inline_keyboard' => [
               [['text' => 'دریافت فایل','url' => "https://t.me/$botid?start=dl_$ex"]],
                ],
            ]);
        if ($info == null){
            $info = '😍 فیلم جدید رسید';
        }
        send($set['MediaChannel'],"$info\n\n <a href='https://t.me/$botid?start=dl_$ex'>😍 دریافت فایل 😍</a>",$key);
       }
   }
   else if (strpos($data,'password|') !== false){
       $ex = explode('password|',$data)[1];
       sm("🔑 لطفا پسورد خود را وارد کنید.",$config['keyboards']['back']);
       $db->update('users',['step' => "pass|$ex"],['user_id' => $from_id]);
   }
   else if (strpos($user['step'],'pass|') !== false){
       $ex  =  explode("pass|",$user['step'])[1];
       if (mb_strlen($text) < 11){
         sm("✅ پسورد شما برای رسانه <code>$ex</code> با موفقیت تنظیم شد.",$config['keyboards']['panel']);  
         $db->update('users',['step' => NULL],['user_id' => $from_id]);
         $db->update('dlfile',['password' => $text],['code' => $ex]);
        }else{
        sm("لطفا یک پسورد زیر 10 رقم وارد کنید");   
       }
   } 
   else if ($text == 'حذف رسانه ❌'){
       sm("🌟 لطفا کد رسانه را وارد کنید.",$config['keyboards']['back']);
       $db->update('users',['step' => 'delfile'],['user_id' => $from_id]);
   }
   else if ($user['step'] == 'delfile'){
    $db->update('users',['step' => NULL],['user_id' => $from_id]);
      if ($db->select('dlfile','*',['code' => $text])[0]){
          $db->delete("dlfile", ["AND" => ["code" => $text,]]);
       sm("✅ رسانه با کد <code>$text</code> با موفقیت حذف شد.",$config['keyboards']['panel']);  
       }else{
       sm("❌ رسانه ای با این کد یافت نشد.",$config['keyboards']['panel']);   
      }
   }
   else if ($text == '📖 اطلاعات آپلود'){
    sm("🌟 لطفا کد رسانه را وارد کنید.",$config['keyboards']['back']);
    $db->update('users',['step' => 'info'],['user_id' => $from_id]);   
   }
   else if ($user['step'] == 'info'){
    $db->update('users',['step' => NULL],['user_id' => $from_id]);
    if ($db->select('dlfile','*',['code' => $text])[0]){
     $sel = $db->select('dlfile','*',['code'=> $text])[0];
     $pass = $sel['password'];
     if ($pass == NULL){
         $pass = 'فاقد پسورد !';
     }
     sm("🔰 اطلاعات اپلود شما به شرح زیر است.\n〰️〰️〰️〰️〰️〰️〰️\n🌟 کد رسانه : <code>$text</code>\n📅 تاریخ اپلود : {$sel['time']}\n❤️ تعداد لایک : {$sel['like_file']}\n📥 تعداد دانلودی ها : {$sel['number_download']}\n🔑 پسورد : $pass\n🔖 کپشن پست : {$sel['like_file']}",$config['keyboards']['panel']);
     }else{
       sm("❌ رسانه ای با این کد یافت نشد.",$config['keyboards']['panel']);   
    }
   }
   else if ($text == 'تمام رسانه ها 🗂'){
       if ($db->select('dlfile','*')[0]){
        foreach ($db->select('dlfile','*',['LIMIT'=> 10])as $as){
            $code = $as['code'];
            $time = $as['time'];
            $do   = $as['number_download'];
            $res .= "🌟 کد رسانه : <code>$code</code>\n📥 تعداد دانلودی ها : $do\n📅 تاریخ اپلود : $time\n------------------\n";
        }   
        sm("🔰 لیست اپلودی های اخیر ربات شما : \n\n $res");
        }else{
        sm("❌ ربات شما فاقد اپلودی است.");   
       }
   }
   else if ($text == 'تنظیم پسورد 🔒'){
     sm("🌟 لطفا کد رسانه خود را وارد کنید.",$config['keyboards']['back']);
     $db->update('users',['step' => 'setpass'],['user_id' => $from_id]); 
   }
   else if ($user['step'] == 'setpass'){
       if ($db->select('dlfile','*',['code' => $text])[0]){
         sm("لطفا پسورد خود را وارد کنید.");
         $db->update('users',['step' => 'setpass2','save' => $text],['user_id' => $from_id]);
        }else{
       sm("❌ رسانه ای با این کد یافت نشد.",$config['keyboards']['panel']); 
       $db->update('users',['step' => NULL],['user_id' => $from_id]);
       }
   }
   else if ($user['step'] == 'setpass2'){
     $ex = $user['save'];
    if (mb_strlen($text) < 11){
         sm("✅ پسورد شما برای رسانه <code>$ex</code> با موفقیت تنظیم شد.",$config['keyboards']['panel']);  
         $db->update('users',['step' => NULL],['user_id' => $from_id]);
         $db->update('dlfile',['password' => $text],['code' => $ex]);
        }else{
        sm("لطفا یک پسورد زیر 10 رقم وارد کنید");   
       }   
   }
   else if ($text == '🔖 محدودیت دانلود'){
     sm("🌟 لطفا کد رسانه خود را وارد کنید.",$config['keyboards']['back']);
     $db->update('users',['step' => 'maxdl'],['user_id' => $from_id]); 
    }
    else if ($user['step'] == 'maxdl'){
       if ($db->select('dlfile','*',['code' => $text])[0]){
         sm("لطفا محدودیت دانلود خود را وارد کنید.");
         $db->update('users',['step' => 'maxdl2','save' => $text],['user_id' => $from_id]);
        }else{
       sm("❌ رسانه ای با این کد یافت نشد.",$config['keyboards']['panel']); 
       $db->update('users',['step' => NULL],['user_id' => $from_id]);
       }
   }
   else if ($user['step'] == 'maxdl2'){
       if(preg_match("/^(-){0,1}([0-9]+)(,[0-9][0-9][0-9])*([.][0-9]){0,1}([0-9]*)$/",$text)){
           sm("با موفقیت تنظیم شد",$config['keyboards']['panel']);
           $db->update('users',['step' => NULL,'save' => null],['user_id' => $from_id]);
           $db->update('dlfile',['max_download' => $text],['code' => $user['save']]);
       }else{
         sm("❌ لطفا از اعداد لاتین استفاده کنید."); 
       }
   }
   else if ($user['step'] == 'setpass2'){
    $ex = $user['save'];
    if(preg_match("/^(-){0,1}([0-9]+)(,[0-9][0-9][0-9])*([.][0-9]){0,1}([0-9]*)$/",$text)){
         sm("✅ محدودیت برای رسانه <code>$ex</code> با موفقیت تنظیم شد.",$config['keyboards']['panel']);  
         $db->update('users',['step' => NULL],['user_id' => $from_id]);
         $db->update('dlfile',['max_download' => $text],['code' => $ex]);
        }else{
       sm("❌ لطفا از اعداد لاتین استفاده کنید."); 
       }   
   }
   else if ($text == '📣 مدیریت چنل رسانه'){
       $key = json_encode([
           'keyboard' => [
               [['text' => '🔖 دریافت چنل رسانه']],
               [['text' => '➖ حذف چنل رسانه'],['text' => '➕ تنظیم چنل رسانه']],
               [['text'=>"🔙 بازگشت"]],
               ],
            'resize_keyboard' => true
         ]);
        sm("👇 لطفا بخش مورد نظر را اتخاب کنید.",$key);
   }
   else if ($text == '🔖 دریافت چنل رسانه'){
       $select = $db->select('admin','MediaChannel')[0];
       if ($select == NULL){
           sm("چنلی تنظیم نشده است !");
       }else{
         sm("🔖 چنل رسانه شما : $select");
       }
   }
   else if ($text == '➕ تنظیم چنل رسانه'){
    $os = $db->select('admin','MediaChannel')[0]; 
    if ($os == NULL){
        $os = 'تنظیم نشده';
    }
    sm("🌟 لطفا ایدی چنل را وارد کنید.\n\n🔖 چنل فعلی : $os",$config['keyboards']['back']);
    $db->update('users',['step' => 'setch'],['user_id' => $from_id]);
   }
   else if ($user['step'] == 'setch'){
    $os = $db->select('admin','MediaChannel')[0]; 
    if ($os == $text){
         sm("❌ این چنل قبلا تنظیم شده است");
         die();
    }
    $key = $text;
      if(strpos($key,"@") !== false){
            $json = json_decode(file_get_contents("https://api.telegram.org/bot".$config['bot']['token']."/getchat?chat_id=$key"));
            $idu = $json->result->username;
        if(isset($idu)){
            $botids = json_decode(file_get_contents("https://api.telegram.org/bot{$config['bot']['token']}/GETME"));
            $botid = $botids->result->id;
            $status2 = json_decode(file_get_contents("https://api.telegram.org/bot".$config['bot']['token']."/getChatMember?chat_id=$key&user_id=$botid"));
            $sta3 = $status2->result->status;
        if($sta3 == "administrator"){
            $db->update('admin',['MediaChannel' => $key]);
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"چنل با موفقیت تنظیم شد.",'reply_to_message_id'=>$message_id,'reply_markup'=>$config['keyboards']['panel']
             ]);
            $db->update('users',['step' => $data],['user_id' => $from_id]);
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ ربات در کانال $key ادمین نمیباشد!
        ابتدا ربات را ادمین کنید سپس دستور را ارسال کنید.",'reply_to_message_id'=>$message_id]);}
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ آیدی $key نادرست است لطفا با دقت ارسال کنید!",'reply_to_message_id'=>$message_id]);}
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ آیدی کانال باید با @ ارسال شود!",'reply_to_message_id'=>$message_id]);
        }
   }
   else if ($text == '➖ حذف چنل رسانه'){
    sm("🔖 لطفا ایدی چنل خود را با @ وارد کنید",$config['keyboards']['back']);
      $db->update('users',['step' => 'dekls'],['user_id' => $from_id]); 
   }
   else if ($user['step'] == 'dekls'){
    $os = $db->select('admin','MediaChannel')[0]; 
    if ($os == $text){
         sm("با موفقیت انجام شد !",$config['keyboards']['panel']);
         $db->update('users',['step' => NULL],['user_id' => $from_id]); 
         $db->update('admin',['MediaChannel' => NULL]); 
    }else{
        sm("❌ ایدی ارسالی ایدی تنظیم شده نیست !");
    }
   }
   else if ($text == '🔐 مدیریت قفل ها' or $data == 'backch'){
     $key = json_encode([
         'inline_keyboard'=>[
             [['text' => '➖ حذف چنل','callback_data'=>'delch'],['text' => '➕ افزودن چنل','callback_data'=>'addch']],
             [['text' => '🔖 لیست چنل ها','callback_data'=>'listch']]
             ]
         ]);
    if(!$data){
     sm("👇 لطفا بخش مورد نظر خود را انتخاب کنید 👇",$key); 
     }else{
     editmessage($message_id,"👇 لطفا بخش مورد نظر خود را انتخاب کنید 👇",$key);   
    }
  }
  else if ($data == 'listch'){
      $key = json_encode([
         'inline_keyboard'=>[
             [['text' => '🔙 بازگشت','callback_data'=>'backch']]
             ]
         ]);
      $select = $db->select('admin', '*')[0];
      if ($select ['channel'] == NULL){
          editmessage($message_id,"❌ چنلی برای جوین اجباری تنظیم نشده است",$key);
       }else{
         editmessage($message_id,"🔰 لیست چنل های شما به شرح زیر است :\n\n{$select['channel']}",$key); 
      }
  }
  else if ($data == 'addch'){
      $db->update('users',['step' => $data],['user_id' => $from_id]);
      del($message_id);
      sm("🔖 لطفا ایدی چنل خود را با @ وارد کنید\n\n❌ توجه : ربات شما باید حتما در کانال ادمین باشد",$config['keyboards']['back']);
  }
  else if ($user['step'] == 'addch'){
     $select2 = $db->select('admin', '*')[0];
     if(strpos($select2['channel'],$text) !== false){
         sm("❌ این چنل قبلا تنظیم شده است");
         die();
     }
      $key = $text;
      if(strpos($key,"@") !== false){
            $json = json_decode(file_get_contents("https://api.telegram.org/bot".$config['bot']['token']."/getchat?chat_id=$key"));
            $idu = $json->result->username;
        if(isset($idu)){
            $botids = json_decode(file_get_contents("https://api.telegram.org/bot{$config['bot']['token']}/GETME"));
            $botid = $botids->result->id;
            $status2 = json_decode(file_get_contents("https://api.telegram.org/bot".$config['bot']['token']."/getChatMember?chat_id=$key&user_id=$botid"));
            $sta3 = $status2->result->status;
        if($sta3 == "administrator"){
            $db->update('admin',['channel' => $select2['channel']."\n$key"]);
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ کانال $key جهت عضویت اجباری ثبت شد!",'reply_to_message_id'=>$message_id,'reply_markup'=>$config['keyboards']['panel']
             ]);
            $db->update('users',['step' => $data],['user_id' => $from_id]);
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ ربات در کانال $key ادمین نمیباشد!
        ابتدا ربات را ادمین کنید سپس دستور را ارسال کنید.",'reply_to_message_id'=>$message_id]);}
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ آیدی $key نادرست است لطفا با دقت ارسال کنید!",'reply_to_message_id'=>$message_id]);}
        }else{
            request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ آیدی کانال باید با @ ارسال شود!",'reply_to_message_id'=>$message_id]);
        }
  }
  else if ($data == 'delch'){
      $select2 = $db->select('admin', '*')[0];
     if ($select2['channel'] == NULL){
         del($message_id);
         sm("❌ چنلی جهت جوین اجباری تنظیم نشده است",$config['keyboards']['panel']);
         $db->update('users',['step' => NULL],['user_id' => $from_id]); 
         die();
     }
      del($message_id);
      sm("🔖 لطفا ایدی چنل خود را با @ وارد کنید",$config['keyboards']['back']);
      $db->update('users',['step' => $data],['user_id' => $from_id]); 
  }
  else if ($user['step'] =='delch'){
     $select2 = $db->select('admin', '*')[0];
     if(strpos($key,"@") !== false){
      sm("🔖 ایدی چنل خود را ارسال کنید",$config['keyboards']['back']);
      request('sendmessage',['chat_id'=>$chat_id,'text'=>"◄ آیدی کانال باید با @ ارسال شود!",'reply_to_message_id'=>$message_id]);
      die();
     }
     if(strpos($select2['channel'],$text) === false){
         sm("❌ این چنل تنظیم نشده است",$config['keyboards']['panel']);
         $db->update('users',['step' => NULL],['user_id' => $from_id]); 
         die();
     }
     if(strpos($select2['channel'],$text) !== false){
          $str = str_replace("$text",NULL,$select2['channel']);
          $str = str_replace("\n",NULL,$str);
          $db->update('admin',['channel' => $str]);   
          $db->update('users',['step' => NULL],['user_id' => $from_id]); 
          
          sm("✅ کانال $text با موفقیت حذف شد",$config['keyboards']['panel']);
     }else{
         sm("❌ کانال مورد نظر پیدا نشد");
     }
  }
  else if ($text == 'لیست چنل ها 📜'){
      $select = $db->select('admin','*')[0];
       if ($select['MediaChannel'] == NULL){
           $med = 'چنلی تنظیم نشده است.';
       }else{
           $med= $select['MediaChannel'];
       }
       if ($select['channel'] == NULL){
           $j = 'چنلی تنظیم نشده است.';
       }else{
           $j= $select['channel'];
       }
    sm("👇 چنل های شما به شرح زیر است \n\n🔖 چنل رسانه : $med\n\n🔑 چنل جوین اجباری :\n$j");
  }
  else if ($text == 'ارسال به کاربران ✏️'){
      sm("👇 لطفا پیام خود را جهت ارسال وارد کنید",$config['keyboards']['back']);  
      $db->update('users',['step' => 'sendall'],['user_id' => $from_id]); 
    }
    else if ($user['step'] == 'sendall'){
       if (isset($update->message->text)){
        $type = 'text';
       }
        else{
        $type = $update->message->photo[count($update->message->photo)-1]->file_id;
        $text = $update->message->caption;
        }
        sm("✅ پیام شما جهت ارسال تنظیم شد",$config['keyboards']['panel']);
        $db->update('users',['step' => NULL],['user_id' => $from_id]); 
        $db->update('send',['send' => 'yes','text' => $text,'type' => $type,'step' => 'send']); 
    }
    else if ($text == '🖌 فروارد به کاربران'){
      $db->update('users',['step' => 'for'],['user_id' => $from_id]); 
      sm("👇 لطفا بنر خود را جهت فوروارد بفرستید",$config['keyboards']['back']);  
    }
    else if ($user['step'] == 'for'){
     sm("✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",$config['keyboards']['panel']);
      $db->update('users',['step' => NULL],['user_id' => $from_id]); 
      $db->update('send',['step' => 'forward','send'=> 'yes','text'=>$message_id,'type' => $from_id]);
    }
    else if ($text == '♻️ لغو عملیات ارسال'){
        $chek = $db->select('send', '*')[0];
       if ($chek['send'] == 'no' or $chek['step'] == NULL){
        sm("❌ عملیات ارسال شروع نشده است");   
        }else{
       sm("✅ عملیات با موفقیت لغو شد");
       $db->update('send',['step' => NULL,'send' => 'no']);
      }
    }
    else if ($text == '🧑🏼‍🔧 تنظیمات ادمین' or $data == 'backadmin'){
        if (!in_array($from_id,$config['bot']['admins'])){
            sm("ادمین عزیز این بخش فقط مخصوص ادمین های اصلی است.");
            exit();
        }
        $key = json_encode([
            'inline_keyboard' => [
                [['text' => '🔖 لیست ادمین ها','callback_data'=> 'listadmin']],
                [['text' => '➖ حذف ادمین','callback_data'=> 'deladmin'],['text' => '➕ افزودن ادمین','callback_data'=> 'addadmin']],
                ],
            ]);
       if($data){
        editmessage($message_id,"👇 لطفا بخش مورد نظر خود را انتخاب کنید 👇",$key);
       }else{
        sm("👇 لطفا بخش مورد نظر خود را انتخاب کنید 👇",$key);
       }
    }
    else if ($data == 'listadmin'){
        $key = json_encode([
            'inline_keyboard' => [
                [['text' => '🔙 بازگشت','callback_data' => 'backadmin']]
                ],
            ]);
        if ($db->count('admins') == 0){
         editmessage($message_id,"❌ لیست ادمین های شما خالی میباشد",$key);   
         }else{
         foreach ($db->select('admins', '*') as $info => $id){
              $res .= $id['user_id']."\n";
          }  
         editmessage($message_id,"🔰 لیست ادمین ها به شرح زیر است\n<code>$res</code>",$key);
        }
    }
    else if ($data == 'deladmin'){
      if ($db->count('admins') == 0){
         editmessage($message_id,"❌ لیست ادمین های شما خالی میباشد");   
         }else{
         foreach ($db->select('admins', '*') as $info => $id){
              $ky [] = [['text' => "{$id['user_id']}",'callback_data' => 'delete-'.$id['user_id']]];
          }   
         $key = json_encode(['inline_keyboard'=>$ky,]);
         editmessage($message_id,"❌ جهت حذف ادمین روی ایدی عددی ادمین کلیک کنید.",$key);
        }  
    }
    else if (strpos($data,'delete-') !== false){
        $ex = explode('delete-',$data)[1];
        $select = $db->select('admins','*',['user_id' => $ex]);
        $key = json_encode([
            'inline_keyboard' => [
                [['text' => '❌ خیر','callback_data' => 'nos'],['text' => '✅ بله','callback_data' => 'yesdela-'.$ex]],
                ],
            ]);
        
        $db->update('users',['step' => null],['user_id' => $from_id]);
        if ($select){
        editmessage($message_id,"👇 آیا از تصمیم خود اطمینان کامل دارید ؟ ",$key);
        }else{
         del($message_id);
         sm("❌ این کاربر قبلا از ادمینی عزل شده است.",$config['key']['panel']);   
        }
    }
    else if (strpos($data,'yesdela-') !== false){
        $ex =  explode("yesdela-",$data)[1];
        $select = $db->select('admins','*',['user_id' => $ex]);
        if ($select){
          del($message_id);
          $db->delete("admins",["AND" => ["user_id" => $ex,]]);
          sm("✅ کاربر <code>$ex</code> با موفقیت عزل شد.",$config['key']['panel']);
         }else{
         del($message_id);
         sm("❌ این کاربر قبلا از ادمینی عزل شده است.",$config['key']['panel']);
        }
    }
    else if ($data == 'addadmin'){
      del($message_id);
      sm("👤 لطفا ایدی عددی شخص مورد نظر را ارسال کنید",$config['keyboards']['back']);
      $db->update('users',['step' => $data],['user_id' => $from_id]); 
    }  
    else if ($user['step'] =='addadmin'){
     $select = $db->select('users', '*', ['user_id'=>$text])[0];
     $select2 = $db->select('admins', '*',['user_id' => $text])[0];
     if($select2['admins']){
         sm("❌ این کاربر از قبل ادمین شده است",$config['keyboards']['panel']);
         $db->update('users',['step' => null],['user_id' => $from_id]); 
         die();
     }
     if(preg_match("/^(-){0,1}([0-9]+)(,[0-9][0-9][0-9])*([.][0-9]){0,1}([0-9]*)$/",$text)){
        if($select){
          $db->insert('admins',['user_id' => $text]);
          $info = request ('getchat',['chat_id'=>$text]);
          $db->update('users',['step' => null],['user_id' => $from_id]); 
          sm("✅ کاربر <a href='tg://user?id=$text'>{$info->result->first_name}</a> با موفقیت ادمین شد",$config['keyboards']['panel']);
         }else{
        sm("اوه ! متاسفم من نتونستم این یوزر رو در ربات پیدا کنم 🧐");
    }   
    }else{
    sm("🗳 لطفا فقط از عداد لاتین استفاده کنید");   
   }
  }
  else if ($text == '📑 تنظیمات تبلیغ'){
      $key = json_encode([
          'keyboard' => [
              [['text' => '✅ فعال کردن تبلیغ']],
              [['text' => '❌ حذف تبلیغ'],['text' => '📝 تنظیم بنر']],
              [['text' => '❌ غیر فعال کردن']],
              [['text'=>"🔙 بازگشت"]],
              ],
              'resize_keyboard' => true,
          ]);
      sm("👇 لطفا بخش مورد نظر خود را انتخاب کنید 👇",$key);
  }
  else if ($text == '✅ فعال کردن تبلیغ'){
      if ($set['tab'] == null){
          sm("ابتدا یک تبلیغ تنظیم کنید");
      }else{
         if ($set['sendtab'] != 'yes'){
          sm("✅ تبلیغ با موفقیت فعال شد.");
          $db->update('admin',['sendtab' => 'yes']);
         }else{
          sm("تبلیغ از قبل فعال شده بود.");
         }
      }
  }
  else if ($text == '❌ غیر فعال کردن'){
      if ($set['tab'] == null){
          sm("ابتدا یک تبلیغ تنظیم کنید");
      }else{
          if ($set['sendtab'] == 'no'){
          sm("تبلیغ از قبل غیر فعال بود.");
         }else{
          sm("❌ با موفقیت غیر فعال شد.");
          $db->update('admin',['sendtab' => 'no']);
         }
     } 
  }
  else if ($text == '❌ حذف تبلیغ'){
   if ($set['tab'] == null){
          sm("ابتدا یک تبلیغ تنظیم کنید");
      }else{
          $db->update('admin',['tab' => NULL,'sendtab' => 'no']);
          sm("✅ تبلیغ با موفقیت حذف شد.");
      }   
  }
  else if ($text == '📝 تنظیم بنر'){
      sm("لطفا پیام تبلیغ خود را ارسال کنید.",$config['keyboards']['back']);
      $db->update('users',['step' => 'setbanner'],['user_id' => $from_id]); 
  }
  else if ($user['step'] == 'setbanner' and $text != '🔙 بازگشت'){
      if($text){
       sm("✅ با موفقیت تنظیم شد.",$config['keyboards']['panel']);   
       $db->update('users',['step' => null],['user_id' => $from_id]); 
       $db->update('admin',['tab' => $text]);
      }else{
          sm("شما فقط مجاز به ارسال تکست هستید.");
      }
  }
  else if ($text == '✅ روشن / ❌ خاموش حذف خودکار'){
      if ($set['del'] == 'off'){
          sm("✅ دیلیت خودکار پیام با زمان یک دقیقه با موفقیت فعال شد");
          $db->update('admin',['del' => 'on']); 
      }else{
          sm("❌ دیلیت خودکار با موفقیت خاموش شد.");
          $db->update('admin',['del' => 'off']); 
      }
  }
  else if ($text == '📂 اپلود گروهی'){
      $db->update('users',['step' => 'uplodegroup'],['user_id' => $from_id]);
      sm("🔰 توضیحات خود را وارد کنید\n\nتوضیحات حداکثر 500 کاراکتر میتواند باشد.\n\n❌ توجه داشته باشید در صورت ارسال /skip هیچ توضیحی برای رسانه شما نخواهد بود و در صورت ارسال /text متن از قبل تنظیم شده شما داده میشود.",$config['keyboards']['back']);
  }
  else if ($user['step'] =='uplodegroup' and $text != '🔙 بازگشت'){
      if(mb_strlen($text) < 501){
        $info = $text;
        if($text == '/skip'){
          $info = null;
      }
      if($text == '/text'){
          if($db->select('admin','caption')[0] == NULL){
             sm("شما متنی از قبل تنظیم نکرده اید و رسانه بدون متن ارسال میشود."); 
             $info = null;
          }else{
              $info = $set['caption'];
          }
       }
        $key = json_encode([
            'keyboard' => [
                [['text' => 'اتمام اپلود']],
                ],
                'resize_keyboard' => true,
            ]);
        sm("👇 لطفا رسانه های خود را ارسال کنید و سپس روی گزینه اتمام بزنید 👇",$key);
        $db->update('users',['step' => 'getgroup','save' => $info],['user_id' => $from_id]);
        }else{
         sm("❌ خطا ! توضیحات طولانی است");  
       }
  }
  else if ($user['step'] == 'getgroup' and $text != 'اتمام اپلود' and $text != '🔙 بازگشت'){
    if (isset($message->video)){
      $file_id = $message->video->file_id;
      $file_size = $message->video->file_size;
         $size = convert($file_size);
         $type = 'video';  
    }
    else if (isset($message->document)){
      $file_id = $message->document->file_id;
      $file_size = $message->document->file_size;
         $size = convert($file_size);
         $type = 'document';  
    }
    else if (isset($message->photo)){
      $photo = $message->photo;
      $file_id = $photo[count($photo)-1]->file_id;
      $file_size = $photo[count($photo)-1]->file_size;
         $size = convert($file_size);
         $type = 'photo';  
    }
    else if (isset($message->voice)){
      $file_id = $message->voice->file_id;
      $file_size = $message->voice->file_size;
         $size = convert($file_size);
         $type = 'voice';  
    }
    else if (isset($message->audio)){
      $file_id = $message->audio->file_id;
      $file_size = $message->audio->file_size;
         $size = convert($file_size);
         $type = 'audio';  
    }
    else if (isset($message->sticker)){
      $file_id = $message->sticker->file_id;
      $file_size = $message->sticker->file_size;
         $size = convert($file_size);
         $type = 'sticker';  
    }
    if ($file_id == NULL){
        sm("❌ این رسانه مجاز نیست.");
        die();
    }
    $explode = explode("|",$user['save']);
    sm("✅ رسانه شما با موفقیت اپلود شد در صورت نیاز پست بعدی بفرستید.\n\n🌟 اطلاعات رسانه پس از اتمام اپلود قابل نمایش است.");
    $code = RandomString();
    if ($explode[1] !== null){
        $code = $explode[1];
    }
    $db->update('users',['save' => "{$explode[0]}|$code"],['user_id' => $from_id]);
    $db->insert('dlfile',['code' => $code,'file_id' => $file_id,'file_size' => $size,'time' => $date,'type' => $type,'like_file' => 0,'max_download' => 9999999,'dl'  => 0,'caption' => $explode[0],'number_download' => 0,]);
  }
  else if ($text == 'اتمام اپلود' and $user['step'] == 'getgroup'){
      $explode = explode("|",$user['save']);
      $code = $explode[1];
      sm("$code");
      $db->update('users',['step' => null,'save' => null],['user_id' => $from_id]);
      if ($db->select('dlfile','*',['code' => $code])[1]){
      $botid = GetMe('username',$config['bot']['token']);
      sm("✅ فایل ها با موفقیت اپلود شدن.\n\n💡 کد رسانه : <code>$code</code>\n📅 تاریخ اپلود : $date\n\n🔗 لینک دریافت : https://t.me/$botid?start=dl_$code",$config['keyboards']['panel']);
     }else{
       sm("شما برای اپلود گروهی باید حداقل دو رسانه اپلود میکردید.",$config['keyboards']['panel']);  
     }
  }
}






