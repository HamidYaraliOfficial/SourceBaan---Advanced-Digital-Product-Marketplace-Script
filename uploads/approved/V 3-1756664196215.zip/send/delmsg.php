<?php

include '../config.php';


foreach ($db->select('delmsg', '*') as $id){
    request('deletemessage',['chat_id'=>$id['user_id'],'message_id'=>$id['msg']]);
    $db->delete("delmsg",["AND" => ["msg" => $id['msg'],]]);
}
echo 'done';