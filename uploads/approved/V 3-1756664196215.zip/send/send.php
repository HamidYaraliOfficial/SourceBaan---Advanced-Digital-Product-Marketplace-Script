<?php 

include '../config.php';

$chek = $db->select('send', '*')[0];


//======================// send //=======================
if ($chek ['step'] == 'send' and $chek['send'] == 'yes'){
   $alluser = $db->count('users');
   $users = $db->select('users', 'user_id',['LIMIT' => [$chek['user'],100]]);
   if ($chek['type'] == 'text'){
    foreach ($users as $id){
       send ($id,$chek['text']); 
    }    
   }else{
   foreach ($users as $id){
       request('sendphoto',[
           'chat_id' => $id,
           'photo'   => $chek['type'],
           'caption' => $chek['text'],
           ]);
    }   
  }
    $db->update('send',['user' => $chek['user'] + 100]);
  if($chek['user'] + 100 >= $alluser){
      $db->update('send',['user' => 0,'send' => 'no','type' =>NULL,'text' => NULL,'step' => NULL]);
   foreach ($config['bot']['admins'] as $admin){
       send($admin,"✏️ پیام همگانی با موفقیت به $alluser نفر ارسال شد");
     }
   }
}
//======================// forward //=======================
if ($chek['step'] == 'forward' and $chek['send'] == 'yes'){
  $alluser = $db->count('users');
  $users = $db->select('users', 'user_id',['LIMIT' => [$chek['user'],100]]);
   foreach ($users as $id){
    request('ForwardMessage',[
        'chat_id'=>$id,   
        'from_chat_id'=>$chek['type'],
       'message_id'=>$chek['text'],
      ]);	  
  }
  $db->update('send',['user' => $chek['user'] + 100]);
  if($chek['user'] + 100 >= $alluser){
      $db->update('send',['user' => 0,'send' => 'no','type' =>NULL,'text' => NULL,'step' => NULL]);
   foreach ($config['bot']['admins'] as $admin){
       send($admin,"✏️ فوروارد همگانی با موفقیت به $alluser نفر ارسال شد");
     }
   }
}












