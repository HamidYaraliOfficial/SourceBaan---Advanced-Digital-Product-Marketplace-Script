<?php

include_once 'config.php';
if (!$set){
$db->query("CREATE TABLE `users` (
    `user_id` BIGINT PRIMARY KEY,
	`step` varchar(50) DEFAULT NULL,
	`ban` varchar(50) DEFAULT NULL,
	`save` varchar(5000) DEFAULT NULL
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");
    
$db->query("CREATE TABLE `dlfile` (
    `code` varchar(50) DEFAULT NULL,
	`file_id` varchar(200) PRIMARY KEY,
	`file_size` varchar(1000) DEFAULT NULL,
	`time` varchar(1000) DEFAULT NULL,
	`like_file` INT(11) DEFAULT NULL,
	`dl` INT(11) DEFAULT NULL,
	`number_download` INT(11) DEFAULT NULL,
	`max_download` INT(11) DEFAULT NULL,
	`caption` varchar(1000) DEFAULT NULL,
	`password` varchar(1000) DEFAULT NULL,
	`type` varchar(5000) DEFAULT NULL
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");
    
$db->query("CREATE TABLE `send` (
	`send` varchar(50) PRIMARY KEY,
	`step` varchar(50) DEFAULT NULL,
	`user` INT(11) DEFAULT NULL,
	`type` varchar(50) DEFAULT NULL,
	`text` varchar(5000) DEFAULT NULL
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");
    
$db->query("CREATE TABLE `delmsg` (
	`user_id` BIGINT,
	`msg` INT(11) PRIMARY KEY
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");
    
$db->query("CREATE TABLE `admin` (
    `owner` BIGINT PRIMARY KEY,
	`start` varchar(5000) DEFAULT NULL,
	`caption` varchar(5000) DEFAULT NULL,
	`channel` LONGTEXT DEFAULT NULL,
	`MediaChannel` LONGTEXT DEFAULT NULL,
	`tab` varchar(5000) DEFAULT NULL,
	`sendtab` varchar(50) DEFAULT NULL,
	`status` varchar(50) DEFAULT NULL,
	`del` varchar(50) DEFAULT NULL
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");

$db->query("CREATE TABLE `admins` (
	`user_id` BIGINT PRIMARY KEY
    ) CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;");

$db->insert('admin', [
        'start' => 'تنظیم نشده',
        'del'   => 'off'
    ]);
$db->insert('send', [
        'send' => 'no'
    ]);    
}



echo 'done';
    
    