<?php

ob_start();
error_reporting(E_ALL);
require_once 'Medoo.php';
require_once 'jdf.php';
include_once 'file.php';
use Medoo\Medoo;

define('API_KEY',$config['bot']['token']);


$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => '', // database name
    'server' => 'localhost',
    'username' => '', // database username
    'password' => '', // database password
    'charset' => 'utf8mb4',
	'collation' => 'utf8mb4_general_ci',
]);


function request($method , $array = [],$token = API_KEY)
{
    $url = 'https://api.telegram.org/bot'.$token.'/'.$method;
    $ch = curl_init();
    curl_setopt_array($ch,[
        CURLOPT_URL => $url ,
        CURLOPT_RETURNTRANSFER => true ,
        CURLOPT_POSTFIELDS => $array ,
        CURLOPT_TIMEOUT => 5
    ]);
    $result = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    } else{
        return json_decode($result);
    }
}
function convert($size){
    return round($size / pow(1024, ($i = floor(log($size, 1024)))), 2).' '.['', 'K', 'M', 'G', 'T', 'P'][$i].'B';
}

function document($name) {
    if ($name == "document") {
        return "فایل";
    }
    if ($name == "video") {
        return "ویدیو";
    }
    if ($name == "photo") {
        return "عکس";
    }
    if ($name == "voice") {
        return "ویس";
    }
    if ($name == "audio") {
        return "موزیک";
    }
    if ($name == "sticker") {
        return "استیکر";
  }
}
function send($from_id,$text,$key=null,$msg='',$markdown='html'){
    return request('sendMessage',['chat_id'=>$from_id,'text'=>$text,'reply_markup'=>$key,'reply_to_message_id'=>$msg,'parse_mode'=>$markdown]);
} 

function sm($text,$key=null,$msg='',$markdown='html'){
    global $chat_id;
    return request('sendMessage',['chat_id'=>$chat_id,'text'=>$text,'reply_markup'=>$key,'reply_to_message_id'=>$msg,'parse_mode'=>$markdown]);
} 
function IsJoin(){
  global $from_id;
  global $set;
  $explode = explode ("\n",$set['channel']);
  foreach ($explode as $channel){
   $res = request('getChatMember',['chat_id'=>$channel,'user_id'=>$from_id])->result->status == 'left';
   if ($res){
      if (strpos($res,'left') !== false){
         return false;
      }else{
          return true;
      }
   }else{
       echo true;
   }
    
 }
}

function GetMe($method,$token = API_KEY){
    return request('GetMe',[],$token)->result->$method;
} 

function editmessage($msg,$text,$key=null,$markdown='html',$ch=null){
    global $chat_id;
    if(isset($ch)) $chat_id = $ch;
    return request('editMessageText',['chat_id'=>$chat_id,'text'=>$text,'reply_markup'=>$key,'message_id'=>$msg,'parse_mode'=>$markdown]);
}
function del($message_id){
    global $chat_id;
    return request('deletemessage',['chat_id'=>$chat_id,'message_id'=>$message_id]);
}
function RandomString() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randstring = null;
    for ($i = 0; $i < 5; $i++) {
        $randstring .= $characters[
            rand(0, strlen($characters))
        ];
    }
    return $randstring;
}



$date = jdate('Y/m/d');
$time = jdate('H:i:s');
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
   $message = $update->message ?? null;
   $text = $update->message->text ?? null ;
   $chat_id = $update->message->chat->id ?? null;
   $from_id = $update->message->from->id ?? null;
   $message_id = $update->message->message_id ?? null;
   $user = $db->select('users', '*', ['user_id'=>$from_id])[0];
   $set = $db->select('admin', '*')[0];
   $usertext = $db->select('users', '*', ['user_id'=>$text])[0];
   $first_name = $update->message->from->first_name ?? null ;
}
elseif(isset($update->callback_query)){
  $data = $update->callback_query->data;
  $chat_id = $update->callback_query->message->chat->id;
  $from_id = $update->callback_query->from->id;
  $callback_id = $update->callback_query->id;
  $message_id = $update->callback_query->message->message_id;
  $set = $db->select('admin', '*')[0];
  $user = $db->select('users', '*', ['user_id'=>$chat_id])[0];
}