<?php
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
// یک بار صفحه اجرا شود
include "bot.php";
// table creator
mysqli_multi_query($connect,"CREATE TABLE user (
    id bigint(10) PRIMARY KEY,
	step varchar(50) NOT NULL,
	coin int(10) NOT NULL,
	member int(10) NOT NULL,
	nugame int(10) NOT NULL,
	process varchar(500) NOT NULL
  );
CREATE TABLE game (
    game_id varchar(50) PRIMARY KEY,
	step int(5) NOT NULL,
	type varchar(50) NOT NULL,
	qu int(5) NOT NULL,
	time varchar(30) NOT NULL,
	count int(5) NOT NULL,
	creator bigint(5) NOT NULL,
	allque varchar(100) NOT NULL
  );
CREATE TABLE gamer (
    game_id varchar(50) NOT NULL,
	gemer bigint(10) NOT NULL,
	answer varchar(20) NOT NULL,
	allanswer varchar(100) NOT NULL,
	coin int(5) NOT NULL,
	PRIMARY KEY (`game_id`,`gemer`)
  );
CREATE TABLE vsgame (
	id bigint(10) PRIMARY KEY,
	type varchar(50) NOT NULL
  );
  CREATE TABLE vsgames (
    game_id varchar(50) PRIMARY KEY,
	step int(5) NOT NULL,
	type varchar(50) NOT NULL,
	qu int(5) NOT NULL,
	time varchar(30) NOT NULL,
	count int(5) NOT NULL,
	allque varchar(100) NOT NULL
  );
  CREATE TABLE vsgamer (
    game_id varchar(50) NOT NULL,
	gemer bigint(10) NOT NULL,
	answer varchar(20) NOT NULL,
	allanswer varchar(100) NOT NULL,
	coin int(5) NOT NULL,
	msg int(5) NOT NULL,
	PRIMARY KEY (`game_id`,`gemer`)
  );
CREATE TABLE qu (
	id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	type varchar(50) NOT NULL,
	qu varchar(200) NOT NULL,
	answer varchar(300) NOT NULL,
	trueanswer INT(5) NOT NULL,
	name varchar(200) NOT NULL
  );
 CREATE TABLE addque (
    msg_id int(10) PRIMARY KEY,
	from_id bigint(10) NOT NULL,
	type varchar(50) NOT NULL,
	qu varchar(400) NOT NULL,
	answer varchar(500) NOT NULL,
	trueanswer INT(5) NOT NULL,
	name varchar(200) NOT NULL
  );
  CREATE TABLE topdaily (
    id bigint(10) PRIMARY KEY,
	coin int(10) DEFAULT '0'
  );
    CREATE TABLE topweek (
    id bigint(10) PRIMARY KEY,
	coin int(10) DEFAULT '0'
  );
      CREATE TABLE topmonth (
    id bigint(10) PRIMARY KEY,
	coin int(10) DEFAULT '0'
  );
    CREATE TABLE timetop (
  	timedaily varchar(20) NOT NULL,
	timeweek varchar(20) NOT NULL,
	timemonth varchar(20) NOT NULL
  );
CREATE TABLE sendall (
  	step varchar(20) NOT NULL,
  	msgid varchar(10) NOT NULL,
	text varchar(2000) NOT NULL,
	chat varchar(20) NOT NULL,
	user int(10) NOT NULL
  );
  CREATE TABLE daily (
  	time varchar(20) NOT NULL,
	user int(10) NOT NULL
  );
INSERT INTO `sendall` (`msgid`, `step`, `text`,  `chat`, `user`) VALUES ('', 'none', '', '', '0');
INSERT INTO `daily` (`time`, `user`) VALUES ('', '0');
INSERT INTO `timetop` (`timedaily`, `timeweek` , `timemonth`) VALUES ('', '' , '');
");
// Check connection
$check = new mysqli($servername, $username, $password, $dbname);
if ($check->connect_error) {
   die("خطا در ارتصال به خاطره :" . $check->connect_error);
}
  echo "دیتابیس متصل و نصب شد ."
?>