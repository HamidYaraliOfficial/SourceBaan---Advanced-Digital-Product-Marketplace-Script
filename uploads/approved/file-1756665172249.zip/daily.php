<?php
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
// کرون جاب هر دقیقه یک بار فعال شود
include "bot.php"; // سازگار با سورس های خودم
//===================================================================
$sendtoall = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM sendall  LIMIT 1"));
if($sendtoall["step"] == "sendall"){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 200 OFFSET {$sendtoall["user"]}");
if($sendtoall["msgid"] == false){
while($row = mysqli_fetch_assoc($users)){
     bot('sendmessage',[
          'chat_id'=>$row["id"],        
		  'text'=>$sendtoall["text"],
        ]);
}	
}
else
{
while($row = mysqli_fetch_assoc($users)){
		bot('sendphoto',[
	'chat_id'=>$row["id"],
	'photo'=>$sendtoall["msgid"],
	'caption'=>$sendtoall["text"],
 ]);
 		bot('sendDocument',[
	'chat_id'=>$row["id"],
	'document'=>$sendtoall["msgid"],
	'caption'=>$sendtoall["text"],
 ]);
}
}
$plus = $sendtoall["user"] + 200;
$connect->query("UPDATE sendall SET user = '$plus' LIMIT 1");
if($plus >= $alluser){
  bot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران ارسال شد",
 ]);
$connect->query("UPDATE sendall SET step = 'none' LIMIT 1");	
}
}
//================================================
if($sendtoall["step"] == "forall"){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 200 OFFSET {$sendtoall["user"]}");
while($row = mysqli_fetch_assoc($users)){
		bot('ForwardMessage',[
'chat_id'=>$row["id"],   
'from_chat_id'=>$sendtoall["chat"],
'message_id'=>$sendtoall["msgid"],
]);	
}
$plus = $sendtoall["user"] + 200;
$connect->query("UPDATE sendall SET user = '$plus' LIMIT 1");
if($plus >= $alluser){
  bot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران فوروارد شد",
 ]);
$connect->query("UPDATE sendall SET step = 'none' LIMIT 1");	
}
}
//=================================================
$daily = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM daily  LIMIT 1"));
$timenow = date("Y-m-d H:i:s");
if($timenow > $daily["time"]){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 200 OFFSET {$daily["user"]}");
while($row = mysqli_fetch_assoc($users)){
     bot('sendmessage',[
          'chat_id'=>$row["id"],        
		  	'text'=>"🎲 چند روزی هست از ربات چالش اطلاعات استفاده نکردی !
			
🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید  😝 

🤔 چطوری ؟ کافیه از دکمه 🎮 بازی با دوستان یا 🎲 بازی ناشناس استفاده کنی تا با یک یا چند نفره وارد یک رقابت اطلاعات در موضوع های مختلف بشی .

👇🏻 همین الان بازی رو شروع کن ببینم چند مَرده حلاجی !

📣 @$channelgame
🤖 @$usernamebot",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[
	['text'=>"🌟 شروع دوباره",'callback_data'=>"join"]
	],
              ]
        ])
        ]);
}	
$plus = $daily["user"] + 200;
$connect->query("UPDATE daily SET user = '$plus' LIMIT 1");
if($plus >= $alluser){
  bot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام یاداوری ارسال شد",
 ]);
$time = date("Y-m-d H:i:s", strtotime("+2 day"));
$connect->query("UPDATE daily SET time = '$time' , user = '0' LIMIT 1");	
}
}	
//=================================================
$timenow = date("Y-m-d H:i:s");
$daily = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM timetop LIMIT 1"));
if($timenow > $daily["timedaily"]){
$connect->query("UPDATE topdaily SET coin = '0'");	
$time = date("Y-m-d H:i:s", strtotime("+1 day"));
$connect->query("UPDATE timetop SET timedaily = '$time' LIMIT 1");	
}
if($timenow > $daily["timeweek"]){
$connect->query("UPDATE topweek SET coin = '0'");	
$time = date("Y-m-d H:i:s", strtotime("+7 day"));
$connect->query("UPDATE timetop SET timeweek = '$time' LIMIT 1");	
}
if($timenow > $daily["timemonth"]){
$connect->query("UPDATE topmonth SET coin = '0'");	
$time = date("Y-m-d H:i:s", strtotime("+30 day"));
$connect->query("UPDATE timetop SET timemonth = '$time' LIMIT 1");	
}
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
?> 