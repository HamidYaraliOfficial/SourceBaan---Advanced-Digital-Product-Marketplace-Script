﻿<?php
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
// کرون جاب هر دقیقه یک بار فعال شود
include "bot.php";
$timestamp = time() + 55;
while(true){
if(time() <= $timestamp){
$row = mysqli_query($connect,"SELECT * FROM `vsgames` WHERE step > 0 AND step < 6");
while($game = mysqli_fetch_assoc($row)){
if(date("Y-m-d H:i:s") >= $game["time"]){
$plusstep = $game["step"] + 1;
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '{$game["game_id"]}' ORDER BY coin DESC");
if($plusstep < 6){
$result = "";
$zplus = 0;
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","10")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
$connect->query("UPDATE vsgamer SET  answer = 'false' WHERE game_id = '{$game["game_id"]}' AND gemer = '{$row["gemer"]}'  LIMIT 1");
}
$allqu = explode("^",$game["allque"]);
$qu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id NOT IN ('" . implode( "', '" , $allqu ) . "') AND type = '{$game["type"]}' ORDER BY RAND() LIMIT 1"));
$all = explode("^",$qu["answer"]);
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '{$game["game_id"]}'");
while($row = mysqli_fetch_assoc($gamers)){
      bot('editmessagetext',[
                'chat_id'=>$row["gemer"],
     'message_id'=>$row["msg"],
	'text'=>"$result
➖➖
📍 سوال $plusstep :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"choice 1 {$game["game_id"]}"],['text'=>"2️⃣ ️",'callback_data'=>"choice 2 {$game["game_id"]}"],['text'=>"3️⃣ ",'callback_data'=>"choice 3 {$game["game_id"]}"],['text'=>"4️⃣ ",'callback_data'=>"choice 4 {$game["game_id"]}]"]
	],
	]
	])
    		]);
}
$time = date("Y-m-d H:i:s", strtotime("+25 seconds"));
$connect->query("UPDATE vsgames SET  step = '$plusstep' , qu = '{$qu["id"]}' , allque = CONCAT (allque,'{$qu["id"]}^') , time = '$time' , count = '0'  WHERE game_id = '{$game["game_id"]}' LIMIT 1");
}
else
{
$result = "";
$zplus = 0;
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","10")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
}
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '{$game["game_id"]}'");
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$game["type"]);
while($row = mysqli_fetch_assoc($gamers)){
      bot('editmessagetext',[
                'chat_id'=>$row["gemer"],
     'message_id'=>$row["msg"],
		'text'=>"⏰ خوب خوب بازیه اطلاعات $replace به پایان رسید !
💡 یه چالش $replace عالی داشتیم بین $zplus شرکت کننده .
	
🎮 نتایج بازی به شکل زیره 👇🏻

$result
➖➖➖

🔴 در صورتی که مشکلی در سوالات وجود داشت یا دوست داشتین جواب هارو ببنید میتونید از دکمه گزارش ها استفاده کنید 👇🏻

🔄 اگر خواستین دوباره بازی کنید یا تو گروه یا پیوی باهم بازی کنید کافیه از زیر منوی پایین استفاده کنی 👇🏻

🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"↗️ بازی با رفیقام",'switch_inline_query'=>"play"]
	],
			[
	['text'=>"🔄 دوباره",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
				[
	['text'=>"🔴 گزارش|پاسخ ها",'url'=>"t.me/$usernamebot?start=answer_{$game["game_id"]}"]
	],
	]
	])
    		]);
}
$connect->query("DELETE FROM vsgamer WHERE game_id = '{$game["game_id"]}'");
$connect->query("UPDATE vsgames SET step = '6' WHERE game_id = '{$game["game_id"]}' LIMIT 1");
}
}
}
sleep(2);
}
else
{
exit();
}
}
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
?> 