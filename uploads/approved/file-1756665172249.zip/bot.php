<?php
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
ob_start();
error_reporting(0);
define('API_KEY','token'); // توکن
//-----------------------------------------------------------------------------------------
//فانکشن bot :
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    return json_decode($res);
    }
//-----------------------------------------------------------------------------------------
//متغیر ها :
$admin = array("000000000","000000000","000000000"); // ایدی ادمین ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = "Bot"; // یوزرنیم ربات بدون @
$channel = "netcopy"; // ایدی کانال بدون @
$channelname = "کانال نت کپی"; // نام کانال برای نمایش
$channelgame = "netcopy"; // کانال جوایزه ربات و اطلاع
//-----------------------------------------------------------------------------------------
// database 
// اطلاعات دیتا بیس را وارد کنید
$servername = "localhost";//تغییرش ندهید
$username = "username";//یوزرنیم در دیتابیس
$password = 'password';//پسورد 
$dbname = "dbname";//نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
//-----------------------------------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$message = $update->message;
$message_id = $message->message_id;
$text = $message->text;
if(isset($message->chat)){
$chat_id = $message->chat->id;
$tc = $message->chat->type;
}
if(isset($message->from)){
$first_name = $message->from->first_name;
$from_id = $message->from->id;
$user_name = isset($message->from->username)?"@{$message->from->username}":"وجود ندارد";
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
}
}
if(isset($update->callback_query)){
$callback_query = $update->callback_query;
$callback_query_id = $callback_query->id;
$data = $callback_query->data;
$inline_message_id = $callback_query->inline_message_id;
if(isset($callback_query->from)){
$firstname = $callback_query->from->first_name;
$username = isset($callback_query->from->username)?"@{$callback_query->from->username}":"وجود ندارد";
$fromid = $callback_query->from->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$fromid' LIMIT 1"));
}
if(isset($callback_query->message)){
$messageid = $callback_query->message->message_id;
if(isset($callback_query->message->chat)){
$chatid = $callback_query->message->chat->id;
}
}
}
if(isset($update->inline_query)){
$inline_query = $update->inline_query;
$inline_query_id = $inline_query->id;
$inline_query_text = $inline_query->query;
if(isset($inline_query->from)){
$inline_query_from_id = $inline_query->from->id;
$inline_query_firstname = $inline_query->from->first_name;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$inline_query_from_id' LIMIT 1"));
}
}
//==============================================================
// function
function RandomString(){
    $characters = 'ABC1DE2FGHI3JKL8MNOP4QRST9UV5WX6YZ7';
    $randstring = '';
    for ($i = 0; $i < 15; $i++) {
        $randstring .= $characters[rand(0, strlen($characters))];
    }
    return $randstring;
}
//==============================================================
if($text=="/start" && $tc == "private"){	
bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text'=>"سلام $first_name 👋🏻

💡 به ربات « چالش اطلاعات » خوش آمدید 🌹

🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید  😝 

🤔 چطوری ؟ کافیه از دکمه 🎮 بازی با دوستان یا 🎲 بازی ناشناس استفاده کنی تا با یک یا چند نفره وارد یک رقابت اطلاعات در موضوع های مختلف بشی .

👇🏻 همین الان بازی رو شروع کن ببینم چند مَرده حلاجی !",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
if ($user["id"] != true)
$connect->query("INSERT INTO user (id, step, coin, nugame , member, process) VALUES ('$from_id', '', '0', '0' , '0','')");
$connect->query("INSERT INTO topdaily (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topweek (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topmonth (id) VALUES ('$from_id')");
}
elseif(preg_match('/^(\/start) (.*)/',$text , $prameter)){
if(is_numeric($prameter[2]) or $prameter[2] == "start"){
bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text'=>"سلام $first_name 👋🏻

💡 به ربات « چالش اطلاعات » خوش آمدید 🌹

🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید  😝 

🤔 چطوری ؟ کافیه از دکمه 🎮 بازی با دوستان یا 🎲 بازی ناشناس استفاده کنی تا با یک یا چند نفره وارد یک رقابت اطلاعات در موضوع های مختلف بشی .

👇🏻 همین الان بازی رو شروع کن ببینم چند مَرده حلاجی !",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
if($user["id"] != true and $prameter[2] != "start"){
$userinvite = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '{$prameter[2]}' LIMIT 1"));
$plusmember = $userinvite["member"] + 1;
$pluscoin = $userinvite["coin"] + 7;
$name = str_replace(["`","*","_","[","]","(",")","```"],"",$first_name);
bot('sendmessage',[
	'chat_id'=>$prameter[2],
	'text'=>"🌟 تبریک ! کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده
	
🗣 هفت امتیاز دریافت کردید و یک نفر به مجموع زیر مجموعه های شما اضاف شد .
🏅 کل امتیازات : $pluscoin
👥 تعداد زیر مجموعه ها : $plusmember",
	'parse_mode'=>'Markdown',
	  	]);
$connect->query("UPDATE user SET member = '$plusmember' , coin = '$pluscoin' WHERE id = '{$prameter[2]}' LIMIT 1");
$connect->query("UPDATE topdaily SET coin = coin + 7 WHERE id = '{$prameter[2]}' LIMIT 1");
$connect->query("UPDATE topweek SET coin = coin + 7 WHERE id = '{$prameter[2]}' LIMIT 1");
$connect->query("UPDATE topmonth SET  coin = coin + 7 WHERE id = '{$prameter[2]}' LIMIT 1");
}
$connect->query("INSERT INTO user (id, step, coin, nugame , member, process) VALUES ('$from_id', '', '0', '0' , '0','')");
$connect->query("INSERT INTO topdaily (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topweek (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topmonth (id) VALUES ('$from_id')");
}
else
{
if($user["id"] != true){
bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text'=>"سلام $first_name 👋🏻

💡 به ربات « چالش اطلاعات » خوش آمدید 🌹

🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید  😝 

🤔 چطوری ؟ کافیه از دکمه 🎮 بازی با دوستان یا 🎲 بازی ناشناس استفاده کنی تا با یک یا چند نفره وارد یک رقابت اطلاعات در موضوع های مختلف بشی .

👇🏻 همین الان بازی رو شروع کن ببینم چند مَرده حلاجی !",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
$connect->query("INSERT INTO user (id, step, coin, nugame , member, process) VALUES ('$from_id', '', '0', '0' , '0','')");
$connect->query("INSERT INTO topdaily (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topweek (id) VALUES ('$from_id')");
$connect->query("INSERT INTO topmonth (id) VALUES ('$from_id')");
}
switch ($prameter[2]) {
case "addque":
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❓ به بخش اضافه کردن سوال خوش آمدید
			
🗣 به وسیله این بخش میتونید سوال به ربات اضافه کنی و علاوه بر حمایت از موارد زیر برخوردار بشی 👇🏻

⚠️ توجه داشته باش که ! درخواست شما برای ادمین ارسال میشه و در صورت تایید ادمین سوال درخواستی تو به ربات اضافه میشه اسم تو زیر سوال درج میشه !	
🏅 علاوه بر همه این ها با اضافه کردن هر سوال درست 20 امتیاز جایزه میگیری ! این عالیه نه ؟	
	
❗️ قبل از اضافه کردن سوال به موارد زیر توجه داشته باش 👇🏻

1️⃣ سوالات حتما باید 3 تا بخش داشته باشه : صورت سوال , چهار پاسخ , جواب درست .
2️⃣ سوالت باید مربوط به موضوعی که انتخاب میکنی باشه  .
3️⃣ از گذاشتن علامت سوال اخر صورت سوال , گذاشتن ایموجی یا هر گونه اشاره به پاسخ درست خود داری کنید .

💡 موضوع سوالات رو با توجه به موضوعات ربات انتخاب کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
		[
		['text'=>"🏛 خانه"]
	],
		[
		['text'=>"فوتبالی"],['text'=>"تاریخی"],['text'=>"مذهبی"]
	],
			[
		['text'=>"خوراکی ها"],['text'=>"تکنولوژی"],['text'=>"ورزشی"]
	],
				[
		['text'=>"والیبال"],['text'=>"سینمایی"],['text'=>"ماشین ها"]
	],
						[
		['text'=>"مشاهیر"],['text'=>"بازی ها"],['text'=>"موسیقی"]
	],
							[
		['text'=>"اطلاعات عمومی"],['text'=>"هوش و ریاضی"],['text'=>"کتاب"]
	],
					[
		['text'=>"برند و چیستان"],['text'=>"زبان انگلیسی"]
	],
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
break;
case "vsgame":
        bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🎮 برای شروع بازی با ناشناس و دو نفره کافیه موضوع چالش رو انتخاب کنی 👇🏻
			
ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
		[
		['text'=>"🏛 خانه"]
	],
		[
		['text'=>"🎲 فوتبالی"],['text'=>"🎲 تاریخی"],['text'=>"🎲 مذهبی"]
	],
			[
		['text'=>"🎲 خوراکی ها"],['text'=>"🎲 تکنولوژی"],['text'=>"🎲 ورزشی"]
	],
				[
		['text'=>"🎲 والیبال"],['text'=>"🎲 سینمایی"],['text'=>"🎲 ماشین ها"]
	],
						[
		['text'=>"🎲 مشاهیر"],['text'=>"🎲 بازی ها"],['text'=>"🎲 موسیقی"]
	],
							[
		['text'=>"🎲 اطلاعات عمومی"],['text'=>"🎲 هوش و ریاضی"],['text'=>"🎲 کتاب"]
	],
					[
		['text'=>"🎲 برند و چیستان"],['text'=>"🎲 زبان انگلیسی"]
	],
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
break;
}
if(preg_match('/^(bag)_(.*)/',$prameter[2] , $gameid)){
$game = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM game WHERE game_id = '$gameid[2]' LIMIT 1"));
$all = explode("^", $game["allque"]);
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$game["type"]);
for($z = 0;$z <= count($all) - 2;$z++){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '$all[$z]' LIMIT 1"));
$answer = explode("^", $getque["answer"]);
$zplus += 1;
$result = $result."📍 سوال $zplus :\n🗣 صورت سوال : {$getque["qu"]}\n🔘پاسخ ها  👇🏻\n1️⃣  $answer[0]\n2️⃣  $answer[1]\n3️⃣  $answer[2]\n4️⃣  $answer[3]\n✅ پاسخ درست گزینه : {$getque["trueanswer"]}\n📨 گزارش این سوال : /report_{$getque["id"]}\n➖➖➖"."\n\n";
}
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎮 پاسخ درست سوالات موجود در بازی 👇🏻
💎 موضوع چالش : $replace
➖➖

$result",
            ]);
}
if(preg_match('/^(answer)_(.*)/',$prameter[2] , $gameid)){
$game = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM vsgames WHERE game_id = '$gameid[2]' LIMIT 1"));
$all = explode("^", $game["allque"]);
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$game["type"]);
for($z = 0;$z <= count($all) - 2;$z++){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '$all[$z]' LIMIT 1"));
$answer = explode("^", $getque["answer"]);
$zplus += 1;
$result = $result."📍 سوال $zplus :\n🗣 صورت سوال : {$getque["qu"]}\n🔘پاسخ ها  👇🏻\n1️⃣  $answer[0]\n2️⃣  $answer[1]\n3️⃣  $answer[2]\n4️⃣  $answer[3]\n✅ پاسخ درست گزینه : {$getque["trueanswer"]}\n📨 گزارش این سوال : /report_{$getque["id"]}\n➖➖➖"."\n\n";
}
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎮 پاسخ درست سوالات موجود در بازی 👇🏻
💎 موضوع چالش : $replace
➖➖

$result",
            ]);
}
}
}
elseif($text=="🏛 خانه" && $tc == "private"){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔘 به منوی اصلی ربات برگشتیم 
	
👇🏻 خوب چه کاری برات انجام بدم ؟ از منوی پایین انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
            ]);
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
}
elseif($text=="🔙 لغو جست جو" && $tc == "private"){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❌ جستجو لغو شده 
	
🔘 به منوی اصلی ربات برگشتیم 	
👇🏻 خوب چه کاری برات انجام بدم ؟ از منوی پایین انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
            ]);
$connect->query("DELETE FROM vsgame WHERE id = '$from_id'");
}
elseif($text=="🎮 بازی با دوستان" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎮 برای شروع بازی با دوستات یا تو گروه و کانال کافیه روی دکمه زیر بزنی و بعدش چت مورد نظر خودت رو انتخاب کنی 👇🏻
	
ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🤔 در صورتی که نیاز به اطلاعات بیشتری در مورد بازی ها و نحوه بازی و امتیازدهی دارید از دکمه راهنما استفاده کنید",
	 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	              [
              ['text'=>"💡 بریم بازی",'switch_inline_query'=>"play"]
              ] 
              ],
        ])
            ]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="🎲 بازی با ناشناس" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
        bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🎮 برای شروع بازی با ناشناس و دو نفره کافیه موضوع چالش رو انتخاب کنی 👇🏻
			
ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
		[
		['text'=>"🏛 خانه"]
	],
		[
		['text'=>"🎲 فوتبالی"],['text'=>"🎲 تاریخی"],['text'=>"🎲 مذهبی"]
	],
			[
		['text'=>"🎲 خوراکی ها"],['text'=>"🎲 تکنولوژی"],['text'=>"🎲 ورزشی"]
	],
				[
		['text'=>"🎲 والیبال"],['text'=>"🎲 سینمایی"],['text'=>"🎲 ماشین ها"]
	],
						[
		['text'=>"🎲 مشاهیر"],['text'=>"🎲 بازی ها"],['text'=>"🎲 موسیقی"]
	],
							[
		['text'=>"🎲 اطلاعات عمومی"],['text'=>"🎲 هوش و ریاضی"],['text'=>"🎲 کتاب"]
	],
					[
		['text'=>"🎲 برند و چیستان"],['text'=>"🎲 زبان انگلیسی"]
	],
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="👤 حساب کاربری" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$getlevel = ($user["coin"]  * $user["nugame"]) / 10000;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎫 حساب کاربری شما در ربات چالش اطلاعات:

🆔 شناسه شما : $from_id
🗣 نام شما : $first_name
💎 یوزرنیم شما : $user_name

🏅 کل امتیازات : {$user["coin"]}
🎮 تعداد بازی ها : {$user["nugame"]}
📶 لول شما : $getlevel
👥 تعداد زیر مجموعه ها : {$user["member"]}

🔆 با انجام بازی و پاسخ درست به سوالات امتیاز دریافت میکنید
🌟 با دعوت هر نفر به ربات از طریق دکمه معرفی ربات 7 امتیاز دریافت میکنید
🎈 با افزودن هر سوال صحیح 20 امتیاز دریافت میکنید",
	 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	              [
              ['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
              ],
			                [
              ['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
              ],
              ],
        ])
            ]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="🏆 رتبه من | نفرات برتر" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏳ ربات در حال پردازش نفرات برتر است منتظر بمانید ...",
            ]);
$users = mysqli_query($connect,"SELECT id,coin FROM `user` ORDER BY coin DESC LIMIT 50");
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number ++;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
$users = mysqli_query($connect,"SELECT id,coin FROM `user` ORDER BY coin DESC");
while($row = mysqli_fetch_assoc($users)){
$rank ++;
if($from_id == $row["id"])$myrank = $rank;
}
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🏆 نفرات برتر در بازی چالش اطلاعات 👇🏻
🏵 رتبه شما : $myrank

🏅 50 نفر برتر 👇🏻

$result

➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"نفرات بعدی ➡",'callback_data'=>"next"]
	],
			[
	['text'=>"☀️ نفرات برتر امروز",'callback_data'=>"topdaily"],['text'=>"📅 نفرات برتر هفته",'callback_data'=>"topweek"]
	],
				[
	['text'=>"💎 نفرات برتر ماه",'callback_data'=>"topmonth"]
	],
			[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
				[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ])
            ]);	
$connect->query("UPDATE user SET step = '0' WHERE id = '$fromid' LIMIT 1");	
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="🚦 راهنما" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💡 راهنمای ربات چالش اطلاعات :
  
❄️ هدف ربات : اجرای بازی به دوستان و اشنایان و بالابردن سطح دانش افراد و ایجاد لحظات شاد برای شما عزیزان 

🔘 توضیح دو نوع بازی :
🎮 برای اجرای بازی دو راه وجود دارد 

🎲 بازی دو نفره با ناشناس : در این نوع بازی ربات شما را به یک حریف رندوم و اتفاقی متصل میکند و بازی دو نفره انجام میشود 
🎳 بازی با دوستان : این نوع بازی هم در گروه و کانال و هم در پیوی افراد قابل اجرا است و میتواند به صورت دو نفره یا بیش تر باشد

🔆 برای شروع بازی میتوانید از دکمه های '🎮 بازی با دوستان' یا '🎲 بازی با ناشناس ' استفاده کنید

📶 نحوه بالا بردن سطح یا امتیاز :
🌟خوب در این مورد سطح شما با توجه به امتیاز شما و تعداد بازی های شما بالا میره هرچی امتیازت بیش تر باشه سطح شماهم بالا تر میره 

ℹ️اما خوب چطوری امتیاز جمع کنیم ؟ برای جمع کردن امتیاز 3 راه وجود داره 
📌یکیش همین راه اصلیه که بازی کردنه شما با انجام بازی میتونید امتیاز کسب کنید
📌 با دعوت هر نفر به ربات از طریق دکمه معرفی ربات 7 امتیاز دریافت میکنید
📌با افزودن هر سوال صحیح 20 امتیاز دریافت میکنید

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎖نحوه محاسبات امتیازات :
🔖 خوب برای نحوه محاسبه امتیازات به این شکله که : زمانی که سوال از شما پرسیده میشه یک تایمر 25 ثانیه ای فعال میشه  و تو هرچقدر زود تر پاسخ بدی امتیاز بیشتری میگیری مثل اگر بعد 4 ثانیه جواب بدی 16 ثانیه زمان اضافه داری 16 تقسیم بر 2 میشه 8 یعنی 8 امتیاز گرفتی که این امتیاز به مجموع امتیازات اضافه میشه .

😫یک سوالمو مطمعنم درست جواب دادم اما زد اشتباه !
سوالات توسط کابران اضافه میشه پس ممکنه سوال اشکالاتی داشته باشه شما میتونید از طریق دکمه گزارش در آخر بازی اشکال رو گزارش کنید تا سوال ویرایش بشه .

😏 چرا فقط دوتا چالش هست ؟
زمانی که برای ارسال بازی میرید و لیست چالش ها براتون لود میشه دستتون رو مثل منو به سمت پایین بکشین تا چالش های دیگه رو هم ببنید .

🕹چطوری با دوستام بازی کنم ؟
1️⃣ دکمه بازی با دوستان
2️⃣ انتخاب گروه یا دوست مورد نظر
3️⃣ صبر تا لیست چالش ها لود بشه
4️⃣ انتخاب چالش
5️⃣ صبر تا یک یا چند نفر پایه بازی بشن
6️⃣ دکمه شروع بازی
🎥 برای درک بهتر فیلم اموزشی ارسال بازی برای دیگران رو برات ارسال کردم

🎈 لحظات خوشی رو برای شما ارزومند هستیم 

🤖 ربات چالش اطلاعات : @$usernamebot
📣 کانال اخبار : @$channelgame",
	 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	              [
              ['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
              ],
			                [
              ['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
              ],
              ],
        ])
            ]);
bot('forwardMessage',[
	'chat_id'=>$chat_id,
	'from_chat_id'=>"@netcopy",
	'message_id'=>5,
            ]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="👨🏻‍💻 ارتباط با ما" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👮🏻 همکاران ما در خدمت شما هستن !
	
🔘 در صورت وجود نظر , ایده , گزارش مشکل , پیشنهاد , ایراد سوال , یا انتقاد میتوانید با ما در ارتباط باشید 
💬 لطفا پیام خود را به صورت فارسی و روان ارسال کنید

📁 لطفا در صورت وجود هرگونه مشکل در ربات برای گزارش آن را برای ما ارسال کنید , پیام رو میتونید به صورت عکس یا متن ارسال کنید
🌟 لطفا تو گزارشی که ارسال میکنید سعی کنید موارد زیر رو رعایت کنید  👇🏻
✅ اشکال مربوط به بخش , دائمی یا بعضی مواقع",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								    [
                ['text'=>"🏛 خانه"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
            ]);
$connect->query("UPDATE user SET step = 'sup' WHERE id = '$from_id' LIMIT 1");	
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text=="🤖 معرفی ربات" && $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$getlevel = ($user["coin"]  * $user["nugame"]) / 1000 ;
$id  = bot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>"https://t.me/netcopy/28",
	'caption'=>"💡 ربات چالش اطلاعات
	
💡 دوس داری خودت و دوستات رو به چالش اطلاعات دعوت کنی ؟ ببینیم کی اطلاعاتش بیش تره !
🤖 همین الان وارد ربات شو 👇🏻

telegram.me/$usernamebot?start=$from_id",
    		])->result->message_id;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💬 پیام بالا حاوی لینک دعوت اختصاصی شما به ربات است 	
🗣 با دعوت هرنفر به ربات 7 امتیاز دریافت خواهید کرد و یک نفر به مجموع زیر مجموعه های شما اضافه خواهد شد  .

🏅 کل امتیازات : {$user["coin"]}
👥 تعداد زیر مجموعه ها : {$user["member"]}
📶 لول شما : $getlevel",
	'reply_to_message_id'=>$id,
    		]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text == "🏵 پیشنهاد سوال"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❓ به بخش اضافه کردن سوال خوش آمدید
			
🗣 به وسیله این بخش میتونید سوال به ربات اضافه کنی و علاوه بر حمایت از موارد زیر برخوردار بشی 👇🏻

⚠️ توجه داشته باش که ! درخواست شما برای ادمین ارسال میشه و در صورت تایید ادمین سوال درخواستی تو به ربات اضافه میشه اسم تو زیر سوال درج میشه !	
🏅 علاوه بر همه این ها با اضافه کردن هر سوال درست 20 امتیاز جایزه میگیری ! این عالیه نه ؟	
	
❗️ قبل از اضافه کردن سوال به موارد زیر توجه داشته باش 👇🏻

1️⃣ سوالات حتما باید 3 تا بخش داشته باشه : صورت سوال , چهار پاسخ , جواب درست .
2️⃣ سوالت باید مربوط به موضوعی که انتخاب میکنی باشه  .
3️⃣ از گذاشتن علامت سوال اخر صورت سوال , گذاشتن ایموجی یا هر گونه اشاره به پاسخ درست خود داری کنید .

💡 موضوع سوالات رو با توجه به موضوعات ربات انتخاب کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
		[
		['text'=>"🏛 خانه"]
	],
		[
		['text'=>"فوتبالی"],['text'=>"تاریخی"],['text'=>"مذهبی"]
	],
			[
		['text'=>"خوراکی ها"],['text'=>"تکنولوژی"],['text'=>"ورزشی"]
	],
				[
		['text'=>"والیبال"],['text'=>"سینمایی"],['text'=>"ماشین ها"]
	],
						[
		['text'=>"مشاهیر"],['text'=>"بازی ها"],['text'=>"موسیقی"]
	],
							[
		['text'=>"اطلاعات عمومی"],['text'=>"هوش و ریاضی"],['text'=>"کتاب"]
	],
					[
		['text'=>"برند و چیستان"],['text'=>"زبان انگلیسی"]
	],
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
elseif($text== "☑️ تایید سوال"){
$all = explode("^", $user["process"]);
$total = mysqli_fetch_assoc(mysqli_query($connect,"SELECT MAX( id ) AS max FROM qu"))['max'] + 1;
$name_substr = mb_substr($first_name,"0","15");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ درخواست تایید سوال شما با موفقیت برای ادمین ارسال شد
🌟 در صورت تایید ادمین سوالت به ربات اضافه میشه. نام تو زیر سوال درج میشه و امتیاز اضافه کردن سوال هم به امتیازاتت اضافه میشه !

👇🏻 خوب چه کاری برات انجام بدم ؟ از منوی پایین انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
   	]);	
$id = bot('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"📍 یک درخواست برای اضافه کردن سوال :

📍 مشخصات سوال : 
-----------------
📍 موضوع سوال : $all[0]
📍 $all[1] ?

1️⃣  $all[2]
2️⃣  $all[3]
3️⃣  $all[4]
4️⃣  $all[5]

✅ پاسخ درست گزینه : $all[6]
📍 فرستنده : $name_substr...
🔢 شماره این سوال : $total",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"✅ تایید",'callback_data'=>'okqu']
	],
			[
	['text'=>"❌ رد",'callback_data'=>'dontokqu']
	],
              ]
        ])
   	])->result->message_id;	
$connect->query("INSERT INTO addque (msg_id, qu, type ,answer, trueanswer , name , from_id) VALUES ('$id', '$all[1]' ,'$all[0]' , '$all[2]^$all[3]^$all[4]^$all[5]', '$all[6]' , '$name_substr' , '$from_id')");
}
elseif(preg_match('/^(\/report_)(.*)/',$text , $prameter)){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '$prameter[2]' LIMIT 1"));
$answer = explode("^", $getque["answer"]);
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$getque["type"]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📨 شما در حال ارسال گزارش برای سوال $prameter[2] هستید

🗣 پیش نمایش سوال 👇🏻
💎 موضوع سوال : $replace
➖➖
📍 {$getque["qu"]} ؟

1️⃣  $answer[0]
2️⃣  $answer[1]
3️⃣  $answer[2]
4️⃣  $answer[3]

✅ پاسخ درست گزینه : {$getque["trueanswer"]}
👾 فرستنده سوال : {$getque["name"]}
➖➖
🤔 خوب چه اشکالی تو سوال وجود داره ؟

⚠️ در خط اول بخشی که اشکال داره رو بنویس و در خط بعدی اگر نیاز به توضیح داره ارسال کن 👇🏻
ℹ️ مثال : 
پاسخ درست اشکال داره 
پاسخ درستش میشه گزینه 3",
'reply_markup'=>json_encode([
            	'keyboard'=>[
[
                ['text'=>"🏛 خانه"]
                ],
 	],
            	'resize_keyboard'=>true
       		])
   	]);	
$connect->query("UPDATE user SET step = 'report' , process = '$prameter[2]' WHERE id = '$from_id' LIMIT 1");
}
elseif(in_array($text,["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","سینمایی","ماشین ها","مشاهیر","بازی ها","موسیقی","اطلاعات عمومی","هوش و ریاضی","کتاب","برند و چیستان","زبان انگلیسی"])){
	         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🗣 شما در حال اضافه کردن سوال به بخش '$text' هستید با توجه به موارد زیر سوال خود را ارسال کنید 👇🏻
			
💡 توجه کن ! در خط اول صورت سوال در خط دوم تا پنجم پاسخ ها و در خط ششم پاسخ رو به صورت عدد ارسال کنید . و اگر سوالات طولانیه میتونی چند خط بنویسی اما نباید از دکمه خط پایین استفاده کنی !

ℹ مثال برای اضافه کردن سوال  به بخش فوتبالی :
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

🙂 سوالی که میخوای با نام خودت ثبت بشه رو ارسال کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'addque' , process = '$text^' WHERE id = '$from_id' LIMIT 1");
}
elseif(in_array($text,["🎲 فوتبالی","🎲 تاریخی","🎲 مذهبی","🎲 خوراکی ها","🎲 تکنولوژی","🎲 ورزشی","🎲 والیبال","🎲 سینمایی","🎲 ماشین ها","🎲 مشاهیر","🎲 بازی ها","🎲 موسیقی","🎲 اطلاعات عمومی","🎲 هوش و ریاضی","🎲 کتاب","🎲 برند و چیستان","🎲 زبان انگلیسی"])){
        bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🔍 در حال جستجو حریف برای اغاز بازی ...",
 ]);
$replace = str_replace(["🎲 فوتبالی","🎲 تاریخی","🎲 مذهبی","🎲 خوراکی ها","🎲 تکنولوژی","🎲 ورزشی","🎲 والیبال","🎲 بازی ها","🎲 سینمایی","🎲 ماشین ها","🎲 برند و چیستان","🎲 هوش و ریاضی","🎲 مشاهیر","🎲 اطلاعات عمومی","🎲 موسیقی","🎲 زبان انگلیسی","🎲 کتاب"],["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],$text);
$game = mysqli_fetch_assoc(mysqli_query($connect,"SELECT id FROM vsgame WHERE id NOT IN ('$from_id') AND type = '$replace' LIMIT 1"));
if($game["id"] == true){
$connect->query("DELETE FROM vsgame WHERE id = '{$game["id"]}'");
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🎮 به حریف با موفقیت متصل شدید !

⏳ منتظر باشید بازی در حال پردازش و آغاز شدن هست ...",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
	  	]);
bot('sendmessage',[
	'chat_id'=>$game["id"],
	'text'=>"🎮 به حریف با موفقیت متصل شدید !

⏳ منتظر باشید بازی در حال پردازش و آغاز شدن هست ...",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
	  	]);
$getname = bot('getChatMember',['chat_id'=>"$from_id",'user_id'=>"$from_id"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getname = bot('getChatMember',['chat_id'=>"{$game["id"]}",'user_id'=>"{$game["id"]}"])->result->user->first_name;
$getnamesubr = mb_substr($getname,"0","12")."...";
$qu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE type = '$replace' ORDER BY RAND() LIMIT 1"));
$all = explode("^",$qu["answer"]);
$game_id = RandomString();
$idme = bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👤 1- (0) ⚪️⚪️⚪️⚪️⚪️ $getnamesub
👤 2- (0) ⚪️⚪️⚪️⚪️⚪️ $getnamesubr
➖➖
📍 سوال 1 :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"choice 1 $game_id"],['text'=>"2️⃣ ️",'callback_data'=>"choice 2 $game_id"],['text'=>"3️⃣ ",'callback_data'=>"choice 3 $game_id"],['text'=>"4️⃣ ",'callback_data'=>"choice 4 $game_id"]
	],
	]
	])
	  	])->result->message_id;
	$idre =	bot('sendmessage',[
	'chat_id'=>$game["id"],
	'text'=>"👤 1- (0) ⚪️⚪️⚪️⚪️⚪️ $getnamesub
👤 2- (0) ⚪️⚪️⚪️⚪️⚪️ $getnamesubr
➖➖
📍 سوال 1 :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"choice 1 $game_id"],['text'=>"2️⃣ ️",'callback_data'=>"choice 2 $game_id"],['text'=>"3️⃣ ",'callback_data'=>"choice 3 $game_id"],['text'=>"4️⃣ ",'callback_data'=>"choice 4 $game_id"]
	],
	]
	])
	  	])->result->message_id;
$time = date("Y-m-d H:i:s", strtotime("+25 seconds"));
$connect->query("INSERT INTO vsgames (game_id , step , qu , time , count , allque , type) VALUES ('$game_id' , '1' ,'{$qu["id"]}' , '$time' , '0' , '{$qu["id"]}^' , '$replace')");
$connect->query("INSERT INTO vsgamer (game_id , gemer , allanswer , coin , answer , msg) VALUES ('$game_id', '$from_id','1^2^3^4^5' , '0' ,'' , '$idme')");
$connect->query("INSERT INTO vsgamer (game_id , gemer , allanswer , coin , answer , msg) VALUES ('$game_id', '{$game["id"]}','1^2^3^4^5' , '0' ,'' , '$idre')");
}
else
{
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❌ در حال حاظر حریفی برای رقابت به شما یافت نشده است .
	
🔍 شما در لیست انتظار قرار دارد و به زودی سیستم خودکار شما را به حریف متصل خواهد کرد ...",
	    'reply_markup'=>json_encode([
            	'keyboard'=>[
								[
				['text'=>"🔙 لغو جست جو"]
				],
 	],
            	'resize_keyboard'=>true
       		])
	  	]);
$connect->query("INSERT INTO vsgame (id, type) VALUES ('$from_id' , '$replace')");
}
}
//==============================================================
// panel admin
elseif($text=="/panel" and $tc == "private" and in_array($from_id,$admin)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍 ادمین عزیز به پنل مدریت ربات خوش امدید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"],['text'=>"📍 افزودن سوال"]     
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
	   	[
	  	['text'=>"📍 ویرایش سوال"],['text'=>"📍 حذف سوال"]  
	  ],
	  	   	[
	  	['text'=>"📍 ارسال یا کسر امتیاز"] 
	  ],
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
elseif($text== "برگشت 🔙" and $tc == "private" and in_array($from_id,$admin)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🚦 به منوی مدیریت بازگشتید",
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [
		['text'=>"📍 امار ربات"],['text'=>"📍 افزودن سوال"]     
		 ],
 	[
	  	['text'=>"📍 ارسال به همه"],['text'=>"📍 فروارد همگانی"]
	  ],
	   	[
	  	['text'=>"📍 ویرایش سوال"],['text'=>"📍 حذف سوال"]  
	  ],
	  	   	[
	  	['text'=>"📍 ارسال یا کسر امتیاز"] 
	  ],
   ],
      'resize_keyboard'=>true
   ])
    ]);
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");		
}
elseif($text== "📍 امار ربات" and $tc == "private" and in_array($from_id,$admin)){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from user"));
$allgame = mysqli_num_rows(mysqli_query($connect,"select game_id from game")) + mysqli_num_rows(mysqli_query($connect,"select game_id from vsgames"));
$allqu = mysqli_num_rows(mysqli_query($connect,"select id from qu"));
$array = ["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"];
$name = ["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"];
for($z = 0;$z <= count($name) - 1;$z++){
$getqu = mysqli_num_rows(mysqli_query($connect,"select id from qu WHERE type = '$array[$z]'"));
$result = $result."📍 تعداد سوالات $name[$z] : $getqu"."\n";
}
				bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 امار ربات شما : 
📍 تعداد عضو ها : $alluser
📍 تعداد بازی های انجام شده  : $allgame
📍 تعداد کل سوالات : $allqu

$result",
		]);
		}
elseif ($text == "📍 ارسال به همه" and $tc == "private" and in_array($from_id,$admin)) {
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید]",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'sendtoall' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE sendall SET step = 'none' , text = '' , msgid = '' , user = '0' , chat = '' LIMIT 1");	
}
elseif ($text == "📍 فروارد همگانی" and $tc == "private" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 لطفا پیام خود را فوروارد کنید [پیام فوروارد شده میتوانید از شخص یا کانال باشد]",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'fortoall' WHERE id = '$from_id' LIMIT 1");		
$connect->query("UPDATE sendall SET step = 'none' , text = '' , msgid = '' , user = '0' , chat = '' LIMIT 1");	
}
elseif ($text == "📍 افزودن سوال" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 موضوع سوالات رو انتخاب کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
		[
		['text'=>"برگشت 🔙"] 
	],
		[
		['text'=>"📍 فوتبالی"],['text'=>"📍 تاریخی"],['text'=>"📍 مذهبی"]
	],
			[
		['text'=>"📍 خوراکی ها"],['text'=>"📍 تکنولوژی"],['text'=>"📍 ورزشی"]
	],
				[
		['text'=>"📍 والیبال"],['text'=>"📍 سینمایی"],['text'=>"📍 ماشین ها"]
	],
						[
		['text'=>"📍 مشاهیر"],['text'=>"📍 بازی ها"],['text'=>"📍 موسیقی"]
	],
							[
		['text'=>"📍 اطلاعات عمومی"],['text'=>"📍 هوش و ریاضی"],['text'=>"📍 کتاب"]
	],
					[
		['text'=>"📍 برند و چیستان"],['text'=>"📍 زبان انگلیسی"]
	],
	[
		['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
elseif ($text == "📍 حذف سوال" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 لطفا شماره سوال را وارد کنید !",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'removeque' WHERE id = '$from_id' LIMIT 1");
}
elseif ($text == "📍 ویرایش سوال" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 لطفا شماره سوال را وارد کنید !",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'editque' WHERE id = '$from_id' LIMIT 1");
}
elseif ($text == "📍 ارسال یا کسر امتیاز" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 در خط اول ایدی فرد و در خط دوم تعداد سکه را وارد کنید اگر میخواهید سکه کسر کنید منفی وارد کنید !",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'sendcoin' WHERE id = '$from_id' LIMIT 1");
}
elseif ($text == "📍 تایید" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
'text'=>"📍 سوال با شماره {$user["process"]} حذف شد",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("DELETE FROM qu WHERE id = '{$user["process"]}'");
}
elseif ($text == "📍 ویرایش" and in_array($from_id,$admin)){
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
'text'=>"📍 لطفا سوال را مانند الگوریتم زیر ویرایش کنید

موضوع سوال
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

📍 لیست موضوعات : فوتبالی , تاریخی ,  مذهبی , خوراکی ها , تکنولوژی , ورزشی , والیبال ,  سینمایی , ماشین ها , بازی ها , موسیقی , هوش و ریاضی , کتاب , برند و چیستان , مشاهیر , عمومی , زبان انگلیسی
📍 در وارد کردن موضوع دقت کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'geteditque' WHERE id = '$from_id' LIMIT 1");
}
elseif(in_array($text,["📍 فوتبالی","📍 تاریخی","📍 مذهبی","📍 خوراکی ها","📍 تکنولوژی","📍 ورزشی","📍 والیبال","📍 سینمایی","📍 ماشین ها","📍 مشاهیر","📍 بازی ها","📍 موسیقی","📍 اطلاعات عمومی","📍 هوش و ریاضی","📍 کتاب","📍 برند و چیستان","📍 زبان انگلیسی"])){
$str = str_replace("📍 ","",$text);
	         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"🗣 شما در حال اضافه کردن سوال به بخش '$str' هستید با توجه به موارد زیر سوال خود را ارسال کنید 👇🏻
			
💡 توجه کن ! در خط اول صورت سوال در خط دوم تا پنجم پاسخ ها و در خط ششم پاسخ رو به صورت عدد ارسال کنید . و اگر سوالات طولانیه میتونی چند خط بنویسی اما نباید از دکمه خط پایین استفاده کنی !

ℹ مثال برای اضافه کردن سوال  به بخش فوتبالی :
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

🙂 سوالی که میخوای با نام خودت ثبت بشه رو ارسال کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$connect->query("UPDATE user SET step = 'addqueadmin' , process = '$str' WHERE id = '$from_id' LIMIT 1");
}
//=======================================================
elseif($data=="join"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$fromid"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
	bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"☑️ عضویت شما تایید شد . به منوی اصلی ربات خوش آمدید		
🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید 😝 

👇🏻 خوب چه کاری برات انجام بدم ؟ از منوی پایین انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' =>true
        ]);
}
}
elseif($data=="topdaily"){
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' =>"⏳ در حال پردازش ...",
            'show_alert' =>false
        ]);
$users = mysqli_query($connect,"SELECT * FROM `topdaily` ORDER BY coin DESC LIMIT 200");
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number ++;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🏆 نفرات برتر امروز بازی چالش اطلاعات 👇🏻

$result
➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
				[
	['text'=>"💎 نفرات برتر ماه",'callback_data'=>"topmonth"],['text'=>"📅 نفرات برتر هفته",'callback_data'=>"topweek"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ])
            ]);	
}
elseif($data=="topweek"){
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' =>"⏳ در حال پردازش ...",
            'show_alert' =>false
        ]);
$users = mysqli_query($connect,"SELECT * FROM `topweek` ORDER BY coin DESC LIMIT 200");
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number ++;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🏆 نفرات برتر هفته بازی چالش اطلاعات 👇🏻

$result
➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
				[
	['text'=>"💎 نفرات برتر ماه",'callback_data'=>"topmonth"],['text'=>"☀️ نفرات برتر امروز",'callback_data'=>"topdaily"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ])
            ]);	
}
elseif($data=="topmonth"){
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' =>"⏳ در حال پردازش ...",
            'show_alert' =>false
        ]);
$users = mysqli_query($connect,"SELECT * FROM `topmonth` ORDER BY coin DESC LIMIT 200");
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number ++;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🏆 نفرات برتر این ماه بازی چالش اطلاعات 👇🏻

$result
➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
				[
	['text'=>"☀️ نفرات برتر امروز",'callback_data'=>"topdaily"],['text'=>"📅 نفرات برتر هفته",'callback_data'=>"topweek"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ])
            ]);	
}
elseif($data=="next"){
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' =>"⏳ در حال پردازش ...",
            'show_alert' =>false
        ]);
$plus = $user["step"] + 50 ;
$users = mysqli_query($connect,"SELECT id,coin FROM `user` ORDER BY coin DESC LIMIT $plus,50");
$number = $plus;
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number += 1;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🏆 نفرات برتر در بازی چالش اطلاعات 👇🏻

$result
➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"نفرات بعدی ➡",'callback_data'=>"next"],['text'=>"⬅️ نفرات قبلی",'callback_data'=>"back"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ])
            ]);
$connect->query("UPDATE user SET step = '$plus' WHERE id = '$fromid' LIMIT 1");	
}
elseif($data=="back"){
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' =>"⏳ در حال پردازش ...",
            'show_alert' =>false
        ]);
$plus = $user["step"] - 50;
if($plus == 0)
$key = json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"نفرات بعدی ➡",'callback_data'=>"next"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ]);
else
$key =  json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"نفرات بعدی ➡",'callback_data'=>"next"],['text'=>"⬅️ نفرات قبلی",'callback_data'=>"back"]
	],
				[
	['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
	],
					[
	['text'=>"🏆 کانال جوایز",'url'=>"https://t.me/$channelgame"]
	],
              ]
        ]);
$users = mysqli_query($connect,"SELECT id,coin FROM `user` ORDER BY coin DESC LIMIT $plus,50");
$number = $plus;
while($row = mysqli_fetch_assoc($users)){
$name = bot('getChatMember',['chat_id'=>$row["id"],'user_id'=>$row["id"]])->result->user->first_name;
$getnamesub = mb_substr("$name","0","15");
$number += 1;
$result = $result."$number - $getnamesub 🏅 {$row["coin"]}"."\n";
}
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"🏆 نفرات برتر در بازی چالش اطلاعات 👇🏻

$result
➖➖
🎉 هرماه دوره های مختلف بازی چالش اطلاعات شروع میشه و به 10 نفر برتر ربات جایزه داده میشه !
🏆 اطلاع از اخبار اخیر جوایز و کانال اخبار ربات : @$channelgame",
'reply_markup'=>$key
            ]);
$connect->query("UPDATE user SET step = '$plus' WHERE id = '$fromid' LIMIT 1");	
}
elseif($data=="okqu"){
$get = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM addque WHERE msg_id = '$messageid' LIMIT 1"));
$all = explode("^", $get["answer"]);
$total = mysqli_fetch_assoc(mysqli_query($connect,"SELECT MAX( id ) AS max FROM qu"))['max'] + 1;
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"✅ سوال اضافه شد با مشخصات زیر :
----
📍 موضوع سوال : {$get["type"]}
📍 {$get["qu"]} ?

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

✅ پاسخ درست گزینه : {$get["trueanswer"]}
📍 فرستنده : {$get["name"]}...
🔢 شماره این سوال : $total",
	  	]);
         bot('sendmessage',[
        	'chat_id'=>$get["from_id"],
        	'text'=>"🎉 سوال ارسالی شما توسط ادمین تایید شد !
🌟 20 امتیاز بابت اضافه کردن سوال جایزه گرفتید و همچنین نام شما در زیر سوال درج شد .

🗣 پیش نمایش سوال شما 👇🏻
💎 موضوع سوال : {$get["type"]}
➖
{$get["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال : {$get["name"]}...
✅ پاسخ درست گزینه : {$get["trueanswer"]}",
	 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	              [
              ['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
              ],
			                [
              ['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
              ],
              ],
        ])
 ]);
$replace = str_replace(["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","اطلاعات عمومی","موسیقی","زبان انگلیسی","کتاب"],["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],$get["type"]);
$connect->query("INSERT INTO qu (qu, answer, trueanswer , name , type) VALUES ('{$get["qu"]}' , '$all[0]^$all[1]^$all[2]^$all[3]', '{$get["trueanswer"]}', '{$get["name"]}' , '$replace')");
$connect->query("UPDATE user SET coin = coin + 20 WHERE id = '{$get["from_id"]}' LIMIT 1");	
$connect->query("UPDATE topdaily SET coin = coin + 20 WHERE id = '{$get["from_id"]}' LIMIT 1");
$connect->query("UPDATE topweek SET coin = coin + 20 WHERE id = '{$get["from_id"]}' LIMIT 1");
$connect->query("UPDATE topmonth SET coin = coin + 20 WHERE id = '{$get["from_id"]}' LIMIT 1");
$connect->query("DELETE FROM addque WHERE msg_id = '$messageid'");
}
elseif($data=="dontokqu"){
$get = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM addque WHERE msg_id = '$messageid' LIMIT 1"));
$all = explode("^", $get["answer"]);
bot('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"❌ سوال با اطلاعات زیر رد شد 
----
📍 موضوع سوال : {$get["type"]}
📍 {$get["qu"]} ?

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

✅ پاسخ درست گزینه : {$get["trueanswer"]}
📍 فرستنده : {$get["name"]}",
	  	]);
         bot('sendmessage',[
        	'chat_id'=>$get["from_id"],
        	'text'=>"⭕️ سوال ارسالی شما توسط ادمین رد شد !
⚠️ لطفا با دقت بیش تری سوال رو ارسال کنید ! [در صورت ارسال های نادرست از ربات مسدود یا کسر امتیاز پیدا میکنید]

🗣 پیش نمایش سوال شما 👇🏻
➖
💎 موضوع سوال : {$get["type"]}
{$get["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال : {$get["name"]}
✅ پاسخ درست گزینه : {$get["trueanswer"]}",
	 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	              [
              ['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🎳 بریم بازی",'switch_inline_query'=>"play"]
              ],
			                [
              ['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
              ],
              ],
        ])
 ]);
$connect->query("DELETE FROM addque WHERE msg_id = '$messageid'");
}
elseif(preg_match('/^(joingame) (.*) (.*)/',$data , $prameter)){
$creator = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM game WHERE game_id = '$prameter[2]' LIMIT 1"));
if($fromid != $creator["creator"]){
$megame = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[2]' AND gemer = '$fromid'  LIMIT 1"));
if($fromid != $megame["gemer"]){
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "🎈 دمت گرم ! توهم تو این بازی هستی . منتظر باش سازنده بازی بازی رو شروع کنه ...",
            'show_alert' =>false
        ]);
$connect->query("INSERT INTO gamer (game_id , gemer , allanswer , coin , answer) VALUES ('$prameter[2]', '$fromid','1^2^3^4^5' , '0' ,'')");
$gamers = mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[2]'");
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$zplus += 1;
$result = $result."$zplus - $getnamesub"."\n";
}
$getname = bot('getChatMember',['chat_id'=>"{$creator["creator"]}",'user_id'=>"{$creator["creator"]}"])->result->user->first_name;
$getnamesubname = mb_substr($getname,"0","12")."...";
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["⚽️ کی بهتر بازیکنان فوتبال ایران و کشور های دیگرو میشناسه و اطلاعات فوتبالی داره ؟","🏛 کی تاریخش بهتر تره ؟ و نسبت به تاریخ اطلاعات بیش تری داره ؟","🕌 کی مذهبی تره ؟ و نسبت به مذهب اطلاعات بیش تری داره ؟","🍔 کی شکمو تره ؟ و نسبت به خوراکی ها اطلاعات بیش تری داره ؟","📱 کی تو تکنولوژی اطلاعات بیش تری داره ؟ و نسبت به شرکت های مختلف اطلاعات داره ؟","🏓 کی ورزشکار تره ؟ و ورزش های مختلف رو میشناسه و نسبت بهشون اطلاعات داره ؟","🏐 کی والیبالی تره ؟ و نسبت به والیبال اطلاعات بیش تری داره ؟","🕹 بهترین گیمر کیه ؟ کی بهتر بازی های مختلف رو میشناسه و بازی کرده ؟","🎬 کی سینمایی تره ؟ و نسبت به سینما و بازیگران کشور های مختلف اطلاعات داره ؟","🚗 کی عشقه ماشینه ؟ ماشین های مختلف رو بهتر میشناسه و اطلاعات ماشینی بیش تری داره ؟","🎖 کی بهتر برند های مختلف رو میشناسه ؟ کی بهتر از همه چیستان هارو حل میکنه ؟","🔢 کی باهوش تره ؟ تو انجام محاسبات سریع تره و با دقت تره ؟","👨🏻‍🎓 کی بهتر انسان های معروف دنیا و مشاهیر رو میشناسه ؟ و اطلاعات بیشتری درموردشون داره ؟","🗣 کی اطلاعات عمومی بیش تری داره ؟ و نسبت به موضوعات مختلف مطالعه داره ؟","🎵 کی اهله اهنگه ؟ و نسبت به موزیک های مختلف اطلاعات داره و اهنگ زیاد گوش میده ؟","🇬🇧 کی زبان انگلیسیش خوبه ؟ و نسبت به زبان انگلیسی اطلاعات بیشتری داردو ترجمش خوبه ؟","📚 کی اهل کتابه ؟ نسبت به کتاب های مختلف اطلاعات داره و زیاد کتاب میخونه ؟"],$prameter[3]);
bot('editmessagetext',[
     'inline_message_id'=>$inline_message_id,
	'text'=>"🎮 بیاین بازی !
			
$replace

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $getnamesubname

🙋🏻🙋🏻‍♂️ بازیکنان پایه 👇🏻

$result
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $prameter[2] $prameter[3]"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $prameter[2] $prameter[3]"]
	],
				[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
    		]);
}
else
{
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "😛 شما که قبلا تو بازی حضور داشتی . صبر کن سازنده بازی رو شروع کنه",
            'show_alert' =>true
        ]);
}
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "☹️ شما که سازنده بازی میدونم پایه ای . دوستات رو بگو پایه باشن",
            'show_alert' =>true
        ]);
}
}
elseif(preg_match('/^(playgame) (.*) (.*)/',$data , $prameter)){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$fromid"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
$creator = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM game WHERE game_id = '$prameter[2]' LIMIT 1"));
if($fromid == $creator["creator"]){
if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[2]'")) > 1){
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "🎮 در حال شروع بازی ...",
            'show_alert' =>false
        ]);
$gamers = mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[2]'");
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$zplus += 1;
$result = $result."👤 $zplus- (0) ⚪️⚪️⚪️⚪️⚪️ $getnamesub"."\n";
if ($gamer["id"] != true)
$connect->query("INSERT INTO user (id, step, coin, nugame , member, process) VALUES ('{$row["gemer"]}', '', '0', '0' , '0','')");
$connect->query("INSERT INTO topdaily (id) VALUES ('$fromid')");
$connect->query("INSERT INTO topweek (id) VALUES ('$fromid')");
$connect->query("INSERT INTO topmonth (id) VALUES ('$fromid')");
$connect->query("UPDATE user SET nugame = nugame + 1 WHERE id = '{$row["gemer"]}' LIMIT 1");
$connect->query("UPDATE gamer SET game_id = '$inline_message_id' WHERE game_id = '$prameter[2]' AND gemer = '{$row["gemer"]}'  LIMIT 1");
}
$qu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE type = '$prameter[3]' ORDER BY RAND() LIMIT 1"));
$all = explode("^",$qu["answer"]);
bot('editmessagetext',[
     'inline_message_id'=>$inline_message_id,
	'text'=>"$result
➖➖
📍 سوال 1 :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}...
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"select 1 $inline_message_id"],['text'=>"2️⃣ ️",'callback_data'=>"select 2 $inline_message_id"],['text'=>"3️⃣ ",'callback_data'=>"select 3 $inline_message_id"],['text'=>"4️⃣ ",'callback_data'=>"select 4 $inline_message_id"]
	],
	]
	])
    		]);
$time = date("Y-m-d H:i:s", strtotime("+25 seconds"));
$connect->query("UPDATE game SET game_id = '$inline_message_id' , step = '1' , type = '$prameter[3]' , qu = '{$qu["id"]}' , allque = '{$qu["id"]}^' , time = '$time'  WHERE game_id = '$prameter[2]' LIMIT 1");
}
else
{
		  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "☺️ تعداد بازیکنان بازی هنوز کمه ! بگو رفیقات بیان بازی",
            'show_alert' =>true
        ]);
}
}
else
{
$name = bot('getChatMember',['chat_id'=>"{$creator["creator"]}",'user_id'=>"{$creator["creator"]}"])->result->user->first_name;
$getnamesub = mb_substr($name,"0","12");
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "😯 عه ! شما که دست رسی ندارید فقط $getnamesub میتونه بازی رو شروع کنه .",
            'show_alert' =>true
        ]);
}
}
else
{
		      bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "❌ برای شروع بازی ابتدا داخل کانال $channelname [@$channel] عضو شوید سپس روی شروع بازی بزنید 👇🏻",
            'show_alert' =>true
        ]);
}
}
elseif(preg_match('/^(select) (.*) (.*)/',$data , $prameter)){
$game = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM game WHERE game_id = '$prameter[3]' LIMIT 1"));
$megame = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[3]' AND gemer = '$fromid'  LIMIT 1"));
if($megame["gemer"] == true){
if($megame["answer"] != "true"){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '{$game["qu"]}' LIMIT 1"));
if($prameter[2] == $getque["trueanswer"]){ 
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "ایول باو ! درست بود ✅",
            'show_alert' =>false
        ]);
$amoungtime = floor((strtotime($game["time"]) - strtotime(date("Y-m-d H:i:s"))) / 2);
$upcoin = ($amoungtime < 0?1:$amoungtime);
$pluscoin = $megame["coin"] + $upcoin;
$get = str_replace($game["step"],"✅",$megame["allanswer"]);
$connect->query("UPDATE gamer SET allanswer = '$get' , answer = 'true' , coin = '$pluscoin' WHERE game_id = '$prameter[3]' AND gemer = '$fromid'  LIMIT 1");
$connect->query("UPDATE user SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");	
$connect->query("UPDATE topdaily SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");
$connect->query("UPDATE topweek SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");
$connect->query("UPDATE topmonth SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");	
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "عه ! اشتباه بود ❌",
            'show_alert' =>false
        ]);
$get = str_replace($game["step"],"❌",$megame["allanswer"]);
$connect->query("UPDATE gamer SET allanswer = '$get' , answer = 'true' WHERE game_id = '$prameter[3]' AND gemer = '$fromid'  LIMIT 1");
}
$connect->query("UPDATE game SET count = count + 1 WHERE game_id = '$prameter[3]' LIMIT 1");
$gamers = mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[3]' ORDER BY coin DESC");
$numgamer = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM gamer WHERE game_id = '$prameter[3]'"));
if($numgamer > $game["count"] + 1){
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
}
$all = explode("^",$getque["answer"]);
bot('editmessagetext',[
     'inline_message_id'=>$inline_message_id,
	'text'=>"$result
➖➖
📍 سوال {$game["step"]} : 
{$getque["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده : {$getque["name"]}...
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"select 1 $prameter[3]"],['text'=>"2️⃣ ️",'callback_data'=>"select 2 $prameter[3]"],['text'=>"3️⃣ ",'callback_data'=>"select 3 $prameter[3]"],['text'=>"4️⃣ ",'callback_data'=>"select 4 $prameter[3]"]
	],
	]
	])
    		]);
}
else
{
$plusstep = $game["step"] + 1;
if($plusstep < 6){
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
$connect->query("UPDATE gamer SET  answer = 'false' WHERE game_id = '$prameter[3]' AND gemer = '{$row["gemer"]}'  LIMIT 1");
}
$allqu = explode("^",$game["allque"]);
$qu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id NOT IN ('" . implode( "', '" , $allqu ) . "') AND type = '{$game["type"]}' ORDER BY RAND() LIMIT 1"));
$all = explode("^",$qu["answer"]);
bot('editmessagetext',[
     'inline_message_id'=>$inline_message_id,
	'text'=>"$result
➖➖
📍 سوال $plusstep :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}...
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"select 1 $prameter[3]"],['text'=>"2️⃣ ️",'callback_data'=>"select 2 $prameter[3]"],['text'=>"3️⃣ ",'callback_data'=>"select 3 $prameter[3]"],['text'=>"4️⃣ ",'callback_data'=>"select 4 $prameter[3]"]
	],
	]
	])
    		]);
$time = date("Y-m-d H:i:s", strtotime("+25 seconds"));
$connect->query("UPDATE game SET  step = '$plusstep' , qu = '{$qu["id"]}' , allque = CONCAT (allque,'{$qu["id"]}^') , time = '$time' , count = '0'  WHERE game_id = '$prameter[3]' LIMIT 1");
}
else
{
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
}
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$game["type"]);
bot('editmessagetext',[
     'inline_message_id'=>$inline_message_id,
	'text'=>"⏰ خوب خوب بازیه اطلاعات $replace به پایان رسید !
💡 یه چالش $replace عالی داشتیم بین $zplus شرکت کننده .
	
🎮 نتایج بازی به شکل زیره 👇🏻

$result
➖➖

🔴 در صورتی که مشکلی در سوالات وجود داشت یا دوست داشتین جواب هارو ببنید میتونید از دکمه گزارش ها استفاده کنید 👇🏻

🔄 اگر خواستین دوباره بازی کنید یا باهم کَل کَل کنید کافیه از زیر منوی پایین استفاده کنی 👇🏻

🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"🎲 بازی باناشناس",'url'=>"t.me/$usernamebot?start=vsgame"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
				[
	['text'=>"🔴 گزارش|پاسخ ها",'url'=>"t.me/$usernamebot?start=bag_$prameter[3]"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
	]
	])
    		]);
$connect->query("DELETE FROM gamer WHERE game_id = '$prameter[3]'");
$connect->query("UPDATE game SET step = '6' WHERE game_id = '$prameter[3]' LIMIT 1");
}
}
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "🤗 قبلا به این سوال پاسخ دادی ! صبر کن بریم سوال بعدی",
            'show_alert' =>false
        ]);
}
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "😞 عه ! شما که داخل این بازی نیستید که جواب بدین . خودت یک بازی بساز یا تو بازی های دیگران پایه باش",
            'show_alert' =>true
        ]);
}
}
elseif(preg_match('/^(choice) (.*) (.*)/',$data , $prameter)){
$game = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM vsgames WHERE game_id = '$prameter[3]' LIMIT 1"));
$getgamer = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '$prameter[3]' AND gemer = '$fromid' LIMIT 1"));
if($getgamer["answer"] != "true"){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '{$game["qu"]}' LIMIT 1"));
if($prameter[2] == $getque["trueanswer"]){ 
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "ایول باو ! درست بود ✅",
            'show_alert' =>false
        ]);
$amoungtime = floor((strtotime($game["time"]) - strtotime(date("Y-m-d H:i:s"))) / 2);
$upcoin = ($amoungtime < 0?1:$amoungtime);
$pluscoin = $getgamer["coin"] + $upcoin;
$get = str_replace($game["step"],"✅",$getgamer["allanswer"]);
$connect->query("UPDATE vsgamer SET allanswer = '$get' , answer = 'true' , coin = '$pluscoin' WHERE game_id = '$prameter[3]' AND gemer = '$fromid'  LIMIT 1");
$connect->query("UPDATE user SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");	
$connect->query("UPDATE topdaily SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");
$connect->query("UPDATE topweek SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");
$connect->query("UPDATE topmonth SET coin = coin + $pluscoin WHERE id = '$fromid' LIMIT 1");		
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "عه ! اشتباه بود ❌",
            'show_alert' =>false
        ]);
$get = str_replace($game["step"],"❌",$getgamer["allanswer"]);
$connect->query("UPDATE vsgamer SET allanswer = '$get' , answer = 'true' WHERE game_id = '$prameter[3]' AND gemer = '$fromid'  LIMIT 1");	
}
$connect->query("UPDATE vsgames SET count = count + 1 WHERE game_id = '$prameter[3]' LIMIT 1");
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '$prameter[3]' ORDER BY coin DESC");
if(2 > $game["count"] + 1){
$all = explode("^",$getque["answer"]);
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
}
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '$prameter[3]'");
while($row = mysqli_fetch_assoc($gamers)){
      bot('editmessagetext',[
                'chat_id'=>$row["gemer"],
     'message_id'=>$row["msg"],
	'text'=>"$result
➖➖
📍 سوال {$game["step"]} : 
{$getque["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده : {$getque["name"]}
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"choice 1 $prameter[3]"],['text'=>"2️⃣ ️",'callback_data'=>"choice 2 $prameter[3]"],['text'=>"3️⃣ ",'callback_data'=>"choice 3 $prameter[3]"],['text'=>"4️⃣ ",'callback_data'=>"choice 4 $prameter[3]"]
	],
	]
	])
    		]);
}
}
else
{
$plusstep = $game["step"] + 1;
if($plusstep < 6){
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
$connect->query("UPDATE vsgamer SET  answer = 'false' WHERE game_id = '$prameter[3]' AND gemer = '{$row["gemer"]}'  LIMIT 1");
}
$allqu = explode("^",$game["allque"]);
$qu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id NOT IN ('" . implode( "', '" , $allqu ) . "') AND type = '{$game["type"]}' ORDER BY RAND() LIMIT 1"));
$all = explode("^",$qu["answer"]);
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '$prameter[3]'");
while($row = mysqli_fetch_assoc($gamers)){
      bot('editmessagetext',[
                'chat_id'=>$row["gemer"],
     'message_id'=>$row["msg"],
	'text'=>"$result
➖➖
📍 سوال $plusstep :
{$qu["qu"]} ؟

1️⃣  $all[0]
2️⃣  $all[1]
3️⃣  $all[2]
4️⃣  $all[3]

👾 فرستنده سوال  : {$qu["name"]}...
➖➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"1️⃣ ",'callback_data'=>"choice 1 $prameter[3]"],['text'=>"2️⃣ ️",'callback_data'=>"choice 2 $prameter[3]"],['text'=>"3️⃣ ",'callback_data'=>"choice 3 $prameter[3]"],['text'=>"4️⃣ ",'callback_data'=>"choice 4 $prameter[3]"]
	],
	]
	])
    		]);
}
$time = date("Y-m-d H:i:s", strtotime("+25 seconds"));
$connect->query("UPDATE vsgames SET  step = '$plusstep' , qu = '{$qu["id"]}' , allque = CONCAT (allque,'{$qu["id"]}^') , time = '$time' , count = '0'  WHERE game_id = '$prameter[3]' LIMIT 1");
}
else
{
while($row = mysqli_fetch_assoc($gamers)){
$getname = bot('getChatMember',['chat_id'=>"{$row["gemer"]}",'user_id'=>"{$row["gemer"]}"])->result->user->first_name;
$getnamesub = mb_substr($getname,"0","12")."...";
$getall = preg_replace(['/[0-9]/','/[\^]/'], ['⚪️',''],$row["allanswer"]);
$zplus += 1;
$result = $result."👤 $zplus- ({$row["coin"]}) $getall $getnamesub"."\n";
}
$gamers = mysqli_query($connect,"SELECT * FROM vsgamer WHERE game_id = '$prameter[3]'");
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$game["type"]);
while($row = mysqli_fetch_assoc($gamers)){
      bot('editmessagetext',[
                'chat_id'=>$row["gemer"],
     'message_id'=>$row["msg"],
		'text'=>"⏰ خوب خوب بازیه اطلاعات $replace به پایان رسید !
💡 یه چالش $replace عالی داشتیم بین $zplus شرکت کننده .
	
🎮 نتایج بازی به شکل زیره 👇🏻

$result
➖➖➖

🔴 در صورتی که مشکلی در سوالات وجود داشت یا دوست داشتین جواب هارو ببنید میتونید از دکمه گزارش ها استفاده کنید 👇🏻

🔄 اگر خواستین دوباره بازی کنید یا تو گروه یا پیوی باهم بازی کنید کافیه از زیر منوی پایین استفاده کنی 👇🏻

🎮 @$usernamebot 🎮",
			  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
		[
	['text'=>"↗️ بازی با رفیقام",'switch_inline_query'=>"play"]
	],
			[
	['text'=>"🔄 دوباره",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
				[
	['text'=>"🔴 گزارش|پاسخ ها",'url'=>"t.me/$usernamebot?start=answer_$prameter[3]"]
	],
	]
	])
    		]);
}
$connect->query("DELETE FROM vsgamer WHERE game_id = '$prameter[3]'");
$connect->query("UPDATE vsgames SET step = '6' WHERE game_id = '$prameter[3]' LIMIT 1");
}
}
}
else
{
  bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "🤗 قبلا به این سوال پاسخ دادی ! صبر کن بریم سوال بعدی",
            'show_alert' =>false
        ]);
}
}
//==============================================================
elseif($user["step"] == "addque" && $tc == "private"){
$all = explode("\n",$text);
if(count($all) == 6){
if(is_numeric($all[5])){
$name_substr = mb_substr($first_name,"0","15");
$str = str_replace("^","",$user["process"]);
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"🗣 پیش نمایش سوال شما 👇🏻
💎 موضوع سوال : $str
➖
$all[0] ؟

1️⃣  $all[1]
2️⃣  $all[2]
3️⃣  $all[3]
4️⃣  $all[4]

👾 فرستنده سوال : $name_substr...
✅ پاسخ درست گزینه : $all[5]
➖➖
🤔 آیا ارسال درخواست برای سوال فوق را تایید میکنید ؟",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
		['text'=>"☑️ تایید سوال"],['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
	]);	
$connect->query("UPDATE user SET process = CONCAT (process,'$all[0]^$all[1]^$all[2]^$all[3]^$all[4]^$all[5]') , step = 'none' WHERE id = '$from_id' LIMIT 1");
}
else
{
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❗️ پاسخ درست سوال به درسته وارد نشده است . پاسخ درست را به عدد و به صورت لاتین وارد کنید !
			
❗️ قبل از اضافه کردن سوال به موارد زیر توجه داشته باش 👇🏻

1️⃣ سوالات حتما باید 3 تا بخش داشته باشه : صورت سوال , چهار پاسخ , جواب درست .
2️⃣ سوالت باید مربوط به موضوعی که انتخاب میکنی باشه  .
3️⃣ از گذاشتن علامت سوال اخر صورت سوال , گذاشتن ایموجی یا هر گونه اشاره به پاسخ درست خود داری کنید .

💡 توجه کن ! در خط اول صورت سوال در خط دوم تا پنجم پاسخ ها و در خط ششم پاسخ رو به صورت عدد ارسال کنید . و اگر سوالات طولانیه میتونی چند خط بنویسی اما نباید از دکمه خط پایین استفاده کنی !

ℹ مثال برای اضافه کردن سوال  به بخش فوتبالی :
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

🙂 سوالی که میخوای با نام خودت ثبت بشه رو ارسال کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
else
{
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❗️ پارامتر های سوال به درستی رعایت نشده است . سوال شما باید داری 3 قسمت باشد
				
❗️ قبل از اضافه کردن سوال به موارد زیر توجه داشته باش 👇🏻

1️⃣ سوالات حتما باید 3 تا بخش داشته باشه : صورت سوال , چهار پاسخ , جواب درست .
2️⃣ سوالت باید مربوط به موضوعی که انتخاب میکنی باشه  .
3️⃣ از گذاشتن علامت سوال اخر صورت سوال , گذاشتن ایموجی یا هر گونه اشاره به پاسخ درست خود داری کنید .

💡 توجه کن ! در خط اول صورت سوال در خط دوم تا پنجم پاسخ ها و در خط ششم پاسخ رو به صورت عدد ارسال کنید . و اگر سوالات طولانیه میتونی چند خط بنویسی اما نباید از دکمه خط پایین استفاده کنی !

ℹ مثال برای اضافه کردن سوال  به بخش فوتبالی :
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

🙂 سوالی که میخوای با نام خودت ثبت بشه رو ارسال کن 👇🏻",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
		['text'=>"🏛 خانه"]
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
elseif($user["step"] == "report" && $tc == "private"){
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
'text'=>"☑️ گزارش اشکال در سوال {$user["process"]} با موفقیت برای ادمین ارسال شد !
🗣 پس از برسی ادمین در صورت درست بودن گزارش سوال ویرایش خواهد شد . تشکر بابت گزارش شما
			
👇🏻 خوب چه کاری برات انجام بدم ؟ از منوی پایین انتخاب کن",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
	]);	
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '{$user["process"]}' LIMIT 1"));
$answer = explode("^", $getque["answer"]);
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$getque["type"]);
	$id = bot('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"📍 گزاش اشکال در سوال {$user["process"]} ارسال شده !
📍 توضیحات کابر : $text

📍 مشخصات سوال : 
📍 موضوع سوال : $replace
-----------------
📍 {$getque["qu"]} ؟

1️⃣  $answer[0]
2️⃣  $answer[1]
3️⃣  $answer[2]
4️⃣  $answer[3]

✅ پاسخ درست گزینه : {$getque["trueanswer"]}
👾 فرستنده سوال : {$getque["name"]}
🔢 شماره این سوال : {$getque["id"]}",
   	]);	
$connect->query("UPDATE user SET  step = 'none' WHERE id = '$from_id' LIMIT 1");
  }
elseif($user["step"] == "sup" && $tc == "private"){
bot('ForwardMessage',[
'chat_id'=>$admin[0],
'from_chat_id'=>$chat_id,
'message_id'=>$message_id
]);
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"🗣 پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید",
			'reply_to_message_id'=>$message_id,
	]);	
}
elseif($user["step"] == "addqueadmin" && $tc == "private"){
$all = explode("\n",$text);
if(count($all) == 6){
if(is_numeric($all[5])){
$total = mysqli_fetch_assoc(mysqli_query($connect,"SELECT MAX( id ) AS max FROM qu"))['max'] + 1;
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
'text'=>"📍 سوال با موفقیت اضافه شد به بخش {$user["process"]}
📍 شماره این سوال : $total
📍 قصد اضافه کردن سوال دیگه ای را دارید ؟ ان را ارسال کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
	]);	
$name_substr = mb_substr($first_name,"0","15");
$replace = str_replace(["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","اطلاعات عمومی","موسیقی","زبان انگلیسی","کتاب"],["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],$user["process"]);
$connect->query("INSERT INTO qu (qu, answer, trueanswer , name , type) VALUES ('$all[0]' , '$all[1]^$all[2]^$all[3]^$all[4]', '$all[5]', '$name_substr' , '$replace')");
}
else
{
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❗️ پاسخ درست سوال به درسته وارد نشده است . پاسخ درست را به عدد و به صورت لاتین وارد کنید !
			
ℹ مثال برای اضافه کردن سوال :
موضوع سوال
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

📍 لیست موضوعات : فوتبالی , تاریخی ,  مذهبی , خوراکی ها , تکنولوژی , ورزشی , والیبال ,  سینمایی , ماشین ها , بازی ها , موسیقی , هوش و ریاضی , کتاب , برند و چیستان , مشاهیر , عمومی , زبان انگلیسی
📍 در وارد کردن موضوع دقت کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
else
{
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"❗️ پارامتر های سوال به درستی رعایت نشده است . سوال شما باید داری 3 قسمت باشد
				
موضوع سوال
نام بازی کن برتر سال 2016
لیونل مسی
لوئیس سوارز
کریستیانو رونالدو
آنتوان گریزمان
3

📍 لیست موضوعات : فوتبالی , تاریخی ,  مذهبی , خوراکی ها , تکنولوژی , ورزشی , والیبال ,  سینمایی , ماشین ها , بازی ها , موسیقی , هوش و ریاضی , کتاب , برند و چیستان , مشاهیر , عمومی , زبان انگلیسی
📍 در وارد کردن موضوع دقت کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
    ]);
}
}
elseif($user["step"] == "removeque" && $tc == "private"){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '$text' LIMIT 1"));
$answer = explode("^", $getque["answer"]);
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$getque["type"]);
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"📍 مشخصات سوال : 
-----------------
📍 موضوع سوال : $replace
📍 {$getque["qu"]} ؟

1️⃣  $answer[0]
2️⃣  $answer[1]
3️⃣  $answer[2]
4️⃣  $answer[3]

✅ پاسخ درست گزینه : {$getque["trueanswer"]}
👾 فرستنده سوال : {$getque["name"]}
🔢 شماره این سوال : {$getque["id"]}

📍 ایا میخواین سوال رو حذف کنید ؟",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"📍 تایید"],['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
	]);	
$connect->query("UPDATE user SET process = '$text' WHERE id = '$from_id' LIMIT 1");
}
elseif($user["step"] == "editque" && $tc == "private"){
$getque = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM qu WHERE id = '$text' LIMIT 1"));
$replace = str_replace(["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],$getque["type"]);
$answer = explode("^", $getque["answer"]);
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"📍 مشخصات سوال : 
-----------------
📍 موضوع سوال : $replace
📍 {$getque["qu"]} ؟

1️⃣  $answer[0]
2️⃣  $answer[1]
3️⃣  $answer[2]
4️⃣  $answer[3]

✅ پاسخ درست گزینه : {$getque["trueanswer"]}
👾 فرستنده سوال : {$getque["name"]}
🔢 شماره این سوال : {$getque["id"]}

📍 ایا میخواین سوال رو ویرایش کنید",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"📍 ویرایش"],['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
	]);	
$connect->query("UPDATE user SET process = '$text' WHERE id = '$from_id' LIMIT 1");
}
elseif($user["step"] == "geteditque" && $tc == "private"){
$all = explode("\n",$text);
if(count($all) == 7 and is_numeric($all[6])){
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"📍 سوال با شماره {$user["process"]} با موفقیت ویرایش شد",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
	]);	
$replace = str_replace(["فوتبالی","تاریخی","مذهبی","خوراکی ها","تکنولوژی","ورزشی","والیبال","بازی ها","سینمایی","ماشین ها","برند و چیستان","هوش و ریاضی","مشاهیر","عمومی","موسیقی","زبان انگلیسی","کتاب"],["fotball","history","religion","food","tech","sport","vallyball","game","cinma","car","brand","mind","famus","info","music","english","book"],$all[0]);
$connect->query("UPDATE qu SET qu = '$all[1]' , answer = '$all[2]^$all[3]^$all[4]^$all[5]' , trueanswer = '$all[6]' , type = '$replace' WHERE id = '{$user["process"]}' LIMIT 1");
}
}
elseif($user["step"] == "sendcoin" && $tc == "private"){
$allanswer = explode("\n", $text);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍 ارسال شد",
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"برگشت 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
   	]);
$connect->query("UPDATE user SET coin = coin + $allanswer[1] WHERE id = '$allanswer[0]' LIMIT 1");
$connect->query("UPDATE user SET  step = 'none' WHERE id = '$from_id' LIMIT 1");
}
elseif ($user["step"] == 'sendtoall' && $tc == "private") {
$filephoto = $message->photo;
$photo = $filephoto[count($filephoto)-1]->file_id;
$file = $update->message->document->file_id;
$caption = $update->message->caption;
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام شما با موفقیت برای ارسال همگانی تنظیم شد  ✔️",
 ]);
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE sendall SET step = 'sendall' , text = '$text$caption' , msgid = '$file$photo' LIMIT 1");			
}
elseif ($user["step"] == 'fortoall' && $tc == "private") {
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد ✔️",
 ]);
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
$connect->query("UPDATE sendall SET step = 'forall' , msgid = '$message_id' , chat = '$chat_id' LIMIT 1");		
}
//===========================================================
elseif($inline_query){
if(!preg_match('/^(kal)(.*)/',$inline_query_text)){
bot('answerInlineQuery', [
        'inline_query_id' =>$inline_query_id,
		'is_personal' =>true,
		'cache_time' =>"0",
        'results' => json_encode([[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/29",
            'id' =>base64_encode(rand(5,555)),
            'title' => "فوتبال",
			'description' => "⚽️ بزن تا چالش اطلاعات فوتبالی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
⚽️ کی بهتر بازیکنان فوتبال ایران و کشور های دیگرو میشناسه و اطلاعات فوتبالی داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id fotball"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id fotball"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/30",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات تاریخی",
			'description' => "🏛 بزن تا چالش اطلاعات تاریخی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🏛 کی تاریخش بهتر تره ؟ و نسبت به تاریخ اطلاعات بیش تری داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id history"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id history"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
	],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/31",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات مذهبی",
			'description' => "🕌 بزن تا چالش اطلاعات مذهبی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🕌 کی مذهبی تره ؟ و نسبت به مذهب اطلاعات بیش تری داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id religion"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id religion"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
		],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/32",
            'id' =>base64_encode(rand(5,555)),
            'title' => "خوراکی ها",
			'description' => "🍔 بزن تا چالش خوراکی ها شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🍔 کی شکمو تره ؟ و نسبت به خوراکی ها اطلاعات بیش تری داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id food"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id food"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
			],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/33",
            'id' =>base64_encode(rand(5,555)),
            'title' => "تکنولوژی",
			'description' => "📱 بزن تا چالش تکنولوژی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
📱 کی تو تکنولوژی اطلاعات بیش تری داره ؟ و نسبت به شرکت های مختلف اطلاعات داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id tech"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id tech"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
				],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/34",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات ورزشی",
			'description' => "🏓 بزن تا چالش اطلاعات ورزشی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🏓 کی ورزشکار تره ؟ و ورزش های مختلف رو میشناسه و نسبت بهشون اطلاعات داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id sport"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id sport"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
					],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/35",
            'id' =>base64_encode(rand(5,555)),
            'title' => "والیبال",
			'description' => "🏐 بزن تا چالش والیبالی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🏐 کی والیبالی تره ؟ و نسبت به والیبال اطلاعات بیش تری داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id vallyball"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id vallyball"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
						],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/36",
            'id' =>base64_encode(rand(5,555)),
            'title' => "بازی های کامپیوتری",
			'description' => "🕹 بزن تا چالش بازی های کامپیوتری شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🕹 بهترین گیمر کیه ؟ کی بهتر بازی های مختلف رو میشناسه و بازی کرده ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id game"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id game"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
							],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/37",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات سینمایی",
			'description' => "🎬 بزن تا چالش اطلاعات سینمایی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🎬 کی سینمایی تره ؟ و نسبت به سینما و بازیگران کشور های مختلف اطلاعات داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id cinma"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id cinma"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
								],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/38",
            'id' =>base64_encode(rand(5,555)),
            'title' => "ماشین ها",
			'description' => "🚗 بزن تا چالش ماشینی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🚗 کی عشقه ماشینه ؟ ماشین های مختلف رو بهتر میشناسه و اطلاعات ماشینی بیش تری داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id car"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id car"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
									],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/39",
            'id' =>base64_encode(rand(5,555)),
            'title' => "برند و چیستان",
			'description' => "🎖 بزن تا چالش برند ها و چیستان شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🎖 کی بهتر برند های مختلف رو میشناسه ؟ کی بهتر از همه چیستان هارو حل میکنه ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id brand"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id brand"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
									],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/40",
            'id' =>base64_encode(rand(5,555)),
            'title' => "هوش و ریاضی",
			'description' => "🔢 بزن تا چالش هوش و ریاضی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🔢 کی باهوش تره ؟ تو انجام محاسبات سریع تره و با دقت تره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id mind"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id mind"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
										],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/41",
            'id' =>base64_encode(rand(5,555)),
            'title' => "مشاهیر",
			'description' => "👨🏻‍🎓 بزن تا چالش مشاهیر شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
👨🏻‍🎓 کی بهتر انسان های معروف دنیا و مشاهیر رو میشناسه ؟ و اطلاعات بیشتری درموردشون داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id famus"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id famus"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
											],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/42",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات عمومی",
			'description' => "🗣 بزن تا چالش اطلاعات عمومی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🗣 کی اطلاعات عمومی بیش تری داره ؟ و نسبت به موضوعات مختلف مطالعه داره ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id info"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id info"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
												],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/43",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اطلاعات موسیقی",
			'description' => "🎵 بزن تا چالش اطلاعات موسیقی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🎵 کی اهله اهنگه ؟ و نسبت به موزیک های مختلف اطلاعات داره و اهنگ زیاد گوش میده ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id music"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id music"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
													],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/44",
            'id' =>base64_encode(rand(5,555)),
            'title' => "زبان انگلیسی",
			'description' => "🇬🇧 بزن تا چالش زبان انگلیسی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
🇬🇧 کی زبان انگلیسیش خوبه ؟ و نسبت به زبان انگلیسی اطلاعات بیشتری دارد و ترجمش خوبه ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id english"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id english"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
														],
[
            'type' => 'article',
            'thumb_url'=>"https://t.me/netcopy/45",
            'id' =>base64_encode(rand(5,555)),
            'title' => "کتاب",
			'description' => "📚 بزن تا چالش کتاب و کتاب خوانی شروع بشه",
            'input_message_content' => [ 'message_text' => "🎮 بیاین بازی !
			
📚 کی اهل کتابه ؟ نسبت به کتاب های مختلف اطلاعات داره و زیاد کتاب میخونه ؟

🤔 بیاین ببینیم کی تو این چالش اطلاعات برنده میشه ! برای شروع بازی روی دکمه 🙋🏻 پایه ام بزن .

ℹ️ قوانین کلی بازی :
1️⃣ زمان پاسخ گویی به هر سوال 20 ثانیه است
2️⃣ پاسخ سریع تر امتیاز بیش تری دارد
3️⃣ امکان تغییر گزینه انتخابی وجود ندارد

🎳 درخواست بازی از طرف : $inline_query_firstname

🙋🏻 کی پایست بازی کنیم 🙋🏻‍♂️
➖➖

🕉 @netcopy - نت کپی
🎮 @$usernamebot 🎮"],
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"☑️ شروع بازی",'callback_data'=>"playgame $inline_query_id book"],['text'=>"🙋🏻 پایه ام 🙋🏻‍♂️",'callback_data'=>"joingame $inline_query_id book"]
	],
			[
	['text'=>"📢 $channelname",'url'=>"https://t.me/$channel"]
	],
	]
	])
        ]])
    ]);
if($inline_query_id == true){
$connect->query("INSERT INTO game (game_id ,type , step, qu , time , count , allque , creator) VALUES ('$inline_query_id' ,'' , '0' ,'0' , '' , '0' , '' , '$inline_query_from_id')");
$connect->query("INSERT INTO gamer (game_id , gemer , allanswer , coin , answer) VALUES ('$inline_query_id', '$inline_query_from_id','1^2^3^4^5' , '0' ,'')");
}
}
else
{
bot('answerInlineQuery', [
        'inline_query_id' =>$inline_query_id,
		'is_personal' =>true,
		'cache_time' =>"0",
        'results' => json_encode([[
            'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/354",
			'thumb_url'=>"https://t.me/netcopy/354",
            'id' =>base64_encode(rand(5,555)),
            'title' => "مگه میشه !",
			'caption' => "🗣 $inline_query_firstname میگه :
پشمام ! تو چطوری بردی ؟",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/355",
			'thumb_url'=>"https://t.me/netcopy/355",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نفهمیدم چی شد !",
			'caption' => "🗣 $inline_query_firstname میگه :
من نفهمیدم چی شد ! اصلا",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
	],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/356",
			'thumb_url'=>"https://t.me/netcopy/356",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اینه !",
			'caption' => "🗣 $inline_query_firstname میگه :
حال کن باو :) ما اینیم دیگه",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
			],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/357",
			'thumb_url'=>"https://t.me/netcopy/357",
            'id' =>base64_encode(rand(5,555)),
            'title' => "حالا بیا بیا",
			'caption' => "🗣 $inline_query_firstname میگه :
حالا بیاه بیاه حالا بیاه بیاه",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
				],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/359",
			'thumb_url'=>"https://t.me/netcopy/359",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نابودم کردی",
			'caption' => "🗣 $inline_query_firstname میگه :
نابودم کردی :( له شدم کلا !",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
					],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/358",
			'thumb_url'=>"https://t.me/netcopy/358",
            'id' =>base64_encode(rand(5,555)),
            'title' => "ایول باو",
			'caption' => "🗣 $inline_query_firstname میگه :
بابا تو دیگه کی هستی",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
						],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/341",
			'thumb_url'=>"https://t.me/netcopy/341",
            'id' =>base64_encode(rand(5,555)),
            'title' => "ناراحت نباش",
			'caption' => "🗣 $inline_query_firstname میگه :
ناراحت نباش ; بیا یک دور دیگه بازی کنیم ؟",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
							],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/342",
			'thumb_url'=>"https://t.me/netcopy/342",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نه نمیتونی",
			'caption' => "🗣 $inline_query_firstname میگه :
نه نه! تو حریف من نمیشی",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
								],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/343",
			'thumb_url'=>"https://t.me/netcopy/343",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اره ما اینیم",
			'caption' => "🗣 $inline_query_firstname میگه :
اره اره ! دیدی شکست دادم :)",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
									],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/349",
			'thumb_url'=>"https://t.me/netcopy/349",
            'id' =>base64_encode(rand(5,555)),
            'title' => "هه فاک",
			'caption' => "🗣 $inline_query_firstname میگه :
اره گاییدمتون :) در سطح من نیستین",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
										],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/338",
			'thumb_url'=>"https://t.me/netcopy/338",
            'id' =>base64_encode(rand(5,555)),
            'title' => "دلتون میاد ؟",
			'caption' => "🗣 $inline_query_firstname میگه :
نامردا چطور دلتون اومد :(",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
											],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/344",
			'thumb_url'=>"https://t.me/netcopy/344",
            'id' =>base64_encode(rand(5,555)),
            'title' => "هه !",
			'caption' => "🗣 $inline_query_firstname میگه :
هه ! نه آفرین آفرین",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
												],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/345",
			'thumb_url'=>"https://t.me/netcopy/345",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نخیر !",
			'caption' => "🗣 $inline_query_firstname میگه :
نخیر ! این بازی قبول نیست",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
													],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/347",
			'thumb_url'=>"https://t.me/netcopy/347",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نخیر !",
			'caption' => "🗣 $inline_query_firstname میگه :
یا ابلفض ! این بازی چی شد",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
														],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/346",
			'thumb_url'=>"https://t.me/netcopy/346",
            'id' =>base64_encode(rand(5,555)),
            'title' => "وای",
			'caption' => "🗣 $inline_query_firstname میگه :
ببیین چی شد ! من برم تو افق محو شم",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
															],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/350",
			'thumb_url'=>"https://t.me/netcopy/350",
            'id' =>base64_encode(rand(5,555)),
            'title' => "نه بیا بگیرش",
			'caption' => "🗣 $inline_query_firstname میگه :
من دیگه حرفی ندارم :!",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
																],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/351",
			'thumb_url'=>"https://t.me/netcopy/351",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اخه !",
			'caption' => "🗣 $inline_query_firstname میگه :
اخه تو رو چه حسابی با من بازی میکنی ؟ هان",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
																	],
[
                       'type' => 'gif',
            'gif_url'=>"https://t.me/netcopy/353",
			'thumb_url'=>"https://t.me/netcopy/353",
            'id' =>base64_encode(rand(5,555)),
            'title' => "اقا !",
			'caption' => "🗣 $inline_query_firstname میگه :
اقا من میخوام اول بشم :(",
			 'reply_markup'=>([
    'inline_keyboard'=>[
		[
	['text'=>"🔄 دوباره",'switch_inline_query_current_chat'=>"play"],['text'=>"➕ افزودن سوال",'url'=>"t.me/$usernamebot?start=addque"]
	],
			[
	['text'=>"↗️ با دیگران",'switch_inline_query'=>"play"],['text'=>"💪🏻 کَل کَل",'switch_inline_query_current_chat'=>"kal"]
	],
					[
	['text'=>"🎲 با ناشناس",'url'=>"t.me/$usernamebot?start=vsgame"],['text'=>"🤖 ربات",'url'=>"t.me/$usernamebot?start=start"]
	],
	]
	])
        ]])
    ]);
}
}
elseif($update->message->text && $update->message->reply_to_message && $from_id == $admin[0] && $tc == "private"){
	bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"پاسخ شما برای فرد ارسال شد ☑️"
		]);
	bot('sendmessage',[
        "chat_id"=>$update->message->reply_to_message->forward_from->id,
        "text"=>"👨🏻‍💻 پاسخ پشتیبان برای شما : `$text`",
'parse_mode'=>'MarkDown'
		]);
}
elseif($update->message and $tc == "private"){
$tch = bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>"$from_id"])->result->status;
if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
bot('sendmessage',[
	'chat_id'=>$chat_id, 
	'text'=>"❗️ پیامت رو متوجه نشدم

💡 به ربات « چالش اطلاعات » خوش آمدید 🌹

🎮 این ربات چی کار میکنه ؟ میتونی با دوستات به صورت یک نفره یا چند نفر بازی کنید  😝 

🤔 چطوری ؟ کافیه از دکمه 🎮 بازی با دوستان یا 🎲 بازی ناشناس استفاده کنی تا با یک یا چند نفره وارد یک رقابت اطلاعات در موضوع های مختلف بشی .

👇🏻 همین الان بازی رو شروع کن ببینم چند مَرده حلاجی !",
'reply_markup'=>json_encode([
            	'keyboard'=>[
								                 [
                   ['text'=>"🎲 بازی با ناشناس"],['text'=>"🎮 بازی با دوستان"]
                ],
												                 [
                ['text'=>"👨🏻‍💻 ارتباط با ما"],['text'=>"👤 حساب کاربری"]
                ],
								    [
                ['text'=>"🏵 پیشنهاد سوال"],['text'=>"🚦 راهنما"],['text'=>"🤖 معرفی ربات"]
                ],	
				[
                ['text'=>"🏆 رتبه من | نفرات برتر"]
                ]
 	],
            	'resize_keyboard'=>true
       		])
    		]);
}
else
{
 bot('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"💡 برای استفاده از ربات « چالش اطلاعات »  ابتدا باید وارد کانال زیر شوید
		
📣 @$channel 📣 @$channel
📣 @$channel 📣 @$channel

👇 بعد از « عضویت » بروی دکمه زیر کلیک کنید 👇",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[
	['text'=>"🔔 عضویت در کانال",'url'=>"https://t.me/$channel"]
	],
		[
	['text'=>"📢 عضو شدم",'callback_data'=>'join']
	],
              ]
        ])
			]);
}
}
/*
Website : https://netcopy.ir
Telegram : https://t.me/netcopy
*/
?>