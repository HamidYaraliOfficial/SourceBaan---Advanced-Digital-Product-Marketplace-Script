import telebot
import requests
import utils
import json
import os
import time
import datetime
from telebot import types, util
from telebot.util import quick_markup
from utils import Generate_Email, Load_Mail_Box, escape_markdown, Smart_Random_String
from collections import defaultdict


TempMailBot = telebot.TeleBot(utils.Token)
print(f"🤖 ربات آنلاین شد (شناسه: {TempMailBot.get_me().id})...")

# Admin panel constants
ADMIN_IDS = [123456789]  # Add your admin user IDs here


user_stats = defaultdict(lambda: {
    'emails_created': 0,
    'last_activity': None,
    'total_emails': 0
})


PERSIAN_TEXTS = {
    'welcome_back': """🎉 خوش برگشتی {name}!

✨ ربات ایمیل موقت شما آماده است
📧 از منوی /mail استفاده کن

🔮 ویژگی‌های جدید:
• طراحی شیشه‌ای مدرن
• دکمه کپی ایمیل
• رابط کاربری زیبا
• پنل ادمین پیشرفته

💎 انتخاب کنید:""",
    
    'welcome_new': """🎊 سلام {name} عزیز!

✨ به ربات ایمیل موقت خوش آمدی
📧 ایمیل‌های موقت و امن
💡 از منوی /mail استفاده کن

🔮 ویژگی‌های جدید:
• طراحی شیشه‌ای مدرن
• دکمه کپی ایمیل
• رابط کاربری زیبا
• پنل ادمین پیشرفته

💎 انتخاب کنید:""",
    
    'mail_menu_title': """🔮 منوی ایمیل موقت

✨ انتخاب کنید:""",
    
    'mail_menu_subtitle': "انتخاب کن:",
    
    'generating_email': """⏳ در حال ایجاد ایمیل...

✨ لطفاً صبر کنید
⏱️ ممکن است تا یک دقیقه طول بکشد""",
    
    'no_emails': """📭 هنوز هیچ ایمیلی نداری

✨ از منوی /mail ایمیل جدید بساز""",
    
    'email_list_title': """📋 لیست ایمیل‌های شما

✨ روی هر کدام کلیک کن تا جزئیات را ببینی""",
    
    'email_list_subtitle': "روی هر کدام کلیک کن تا جزئیات را ببینی",
    
    'delete_confirm': """⚠️ آیا مطمئنی که می‌خوای این ایمیل را حذف کنی؟

🗑️ این عملیات قابل بازگشت نیست""",
    
    'email_deleted': "✅ ایمیل با موفقیت حذف شد",
    
    'operation_cancelled': "❌ عملیات لغو شد",
    
    'error_occurred': "❌ خطایی رخ داد! دوباره امتحان کن",
    
    'stats_title': """📊 آمار کاربری

✨ اطلاعات کامل شما:""",
    
    'stats_emails': "📧 تعداد ایمیل‌ها: {count}",
    'stats_created': "🆕 ایمیل‌های ایجاد شده: {count}",
    'stats_last_activity': "🕐 آخرین فعالیت: {time}",
    
    'help_text': """🤖 راهنمای ربات ایمیل موقت

✨ قابلیت‌ها:
• 🔮 ایجاد ایمیل موقت
• 📬 مشاهده صندوق ورودی
• 🗑️ مدیریت ایمیل‌ها
• 📊 آمار کاربری

🔧 دستورات:
/start - شروع ربات
/mail - منوی اصلی
/stats - آمار کاربری
/help - راهنما

💡 نکات:
• هر کاربر تا 99 ایمیل می‌تواند بسازد
• ایمیل‌ها موقت و امن هستند
• پیوست‌ها پشتیبانی می‌شوند
• رابط کاربری مدرن و زیبا""",
    
    'email_created_success': """🎉 ایمیل شما با موفقیت ایجاد شد!

✨ ایمیل شما آماده استفاده است
📧 می‌توانید از منوی /mail صندوق ورودی را ببینید

🔮 ایمیل شما:""",
    
    'inbox_empty': """📭 صندوق ورودی خالی است!

✨ بعد از چند دقیقه دوباره امتحان کنید""",
    
    'inbox_loading': """⏳ در حال بارگذاری صندوق ورودی...

✨ لطفاً صبر کنید""",
    
    'attachment_support': """📎 پیوست‌ها پشتیبانی می‌شوند
🔐 می‌توانی از این ایمیل برای تایید OTP یا لینک استفاده کنی""",
    
    'delete_all_confirm': """⚠️ آیا مطمئنی که می‌خوای همه ایمیل‌ها را حذف کنی؟

🗑️ این عملیات قابل بازگشت نیست""",
    
    'all_emails_deleted': "✅ همه ایمیل‌ها با موفقیت حذف شدند",
    
    'email_info_title': """📧 اطلاعات ایمیل

✨ جزئیات کامل:""",
    
    'email_info_username': "👤 نام کاربری: {username}",
    'email_info_password': "🔑 رمز عبور: {password}",
    'email_info_token': "🔐 توکن: {token}...",
    'email_info_created': "📅 تاریخ ایجاد: {date}",
    'email_info_domain': "🌐 دامنه: {domain}",
    
    'mailbox_title': """📬 صندوق ورودی

✨ ایمیل‌های دریافتی:""",
    
    'message_from': "👤 از: {name}\n📧 {address}\n\n",
    'message_subject': "📋 موضوع: {subject}\n\n",
    'message_content': "📄 محتوا:\n{content}",
    'no_subject': "📋 موضوع: بدون موضوع\n\n",
    'empty_message': "📄 محتوا: پیام خالی یا قابل دریافت نیست",
    
    # Admin panel texts
    'admin_panel_title': """🔐 پنل ادمین

✨ مدیریت ربات:""",
    
    'admin_stats_title': """📊 آمار کلی ربات

✨ اطلاعات کامل:""",
    
    'admin_stats_users': "👥 تعداد کاربران: {count}",
    'admin_stats_emails': "📧 تعداد ایمیل‌ها: {count}",
    'admin_stats_today': "📅 ایمیل‌های امروز: {count}",
    'admin_stats_online': "🟢 ربات آنلاین",
    
    'admin_broadcast_title': """📢 ارسال پیام همگانی

✨ پیام خود را ارسال کنید:""",
    
    'admin_broadcast_sent': "✅ پیام با موفقیت ارسال شد\n📊 تعداد دریافت‌کنندگان: {count}",
    
    'admin_user_management': """👥 مدیریت کاربران

✨ انتخاب کنید:""",
    
    'admin_user_list': "📋 لیست کاربران",
    'admin_user_search': "🔍 جستجوی کاربر",
    'admin_user_ban': "🚫 مسدود کردن کاربر",
    'admin_user_unban': "✅ آزاد کردن کاربر",
    
    'admin_settings': """⚙️ تنظیمات ربات

✨ انتخاب کنید:""",
    
    'admin_settings_maintenance': "🔧 حالت تعمیر",
    'admin_settings_limits': "📊 تنظیم محدودیت‌ها",
    'admin_settings_backup': "💾 پشتیبان‌گیری",
}

def escape_markdown_safe(text):
    """Escape special characters for MarkdownV2"""
    special_chars = ['_', '*', '[', ']', '(', ')', '~', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!', '`']
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text

def ensure_directories():
    """Create necessary directories if they don't exist"""
    directories = ['Accounts', 'Accounts/mails']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
            print(f"✅ پوشه {directory} ایجاد شد")

def update_user_stats(user_id, action='activity'):
    """Update user statistics"""
    user_stats[user_id]['last_activity'] = datetime.datetime.now()
    if action == 'email_created':
        user_stats[user_id]['emails_created'] += 1
        user_stats[user_id]['total_emails'] += 1

def get_user_stats(user_id):
    """Get user statistics"""
    stats = user_stats[user_id]
    last_activity = stats['last_activity']
    if last_activity:
        time_str = last_activity.strftime("%Y-%m-%d %H:%M")
    else:
        time_str = "نامشخص"
    
    return {
        'emails_created': stats['emails_created'],
        'total_emails': len(os.listdir(f"Accounts/{user_id}/mails/")) if os.path.exists(f"Accounts/{user_id}/mails/") else 0,
        'last_activity': time_str
    }

def create_persian_keyboard():
    """Create modern glass-like Persian keyboard with beautiful emojis"""
    return quick_markup({
        "🔮 ایمیل جدید": {"callback_data": "NewEmail"},
        "📬 لیست ایمیل‌ها": {"callback_data": "EmailList"},
        "📩 صندوق ورودی": {"callback_data": "EMailBoxMenu"},
        "🗑️ حذف ایمیل": {"callback_data": "DelEMailMenu"},
        "📊 آمار": {"callback_data": "UserStats"},
        "🔙 بازگشت": {"callback_data": "BackToStart"},
        "❌ بستن": {"callback_data": "Close"},
    }, row_width=2)

def create_admin_keyboard():
    """Create admin panel keyboard with glass-like design"""
    return quick_markup({
        "📊 آمار کلی": {"callback_data": "AdminStats"},
        "📢 ارسال پیام": {"callback_data": "AdminBroadcast"},
        "👥 مدیریت کاربران": {"callback_data": "AdminUsers"},
        "⚙️ تنظیمات": {"callback_data": "AdminSettings"},
        "❌ بستن": {"callback_data": "Close"},
    }, row_width=2)

def is_admin(user_id):
    """Check if user is admin"""
    return user_id in ADMIN_IDS

def get_total_users():
    """Get total number of users"""
    try:
        if os.path.exists("Accounts/"):
            return len([d for d in os.listdir("Accounts/") if os.path.isdir(f"Accounts/{d}")])
        return 0
    except:
        return 0

def get_total_emails():
    """Get total number of emails"""
    try:
        total = 0
        if os.path.exists("Accounts/"):
            for user_dir in os.listdir("Accounts/"):
                user_mails_dir = f"Accounts/{user_dir}/mails/"
                if os.path.exists(user_mails_dir):
                    total += len(os.listdir(user_mails_dir))
        return total
    except:
        return 0

def get_today_emails():
    """Get number of emails created today"""
    try:
        today = datetime.datetime.now().date()
        total = 0
        if os.path.exists("Accounts/"):
            for user_dir in os.listdir("Accounts/"):
                user_mails_dir = f"Accounts/{user_dir}/mails/"
                if os.path.exists(user_mails_dir):
                    for email_file in os.listdir(user_mails_dir):
                        try:
                            with open(f"Accounts/{user_dir}/mails/{email_file}", "r") as f:
                                lines = f.readlines()
                                if len(lines) >= 4:
                                    created_date = lines[3].split(":", 1)[1].strip()
                                    if created_date:
                                        email_date = datetime.datetime.strptime(created_date.split()[0], "%Y-%m-%d").date()
                                        if email_date == today:
                                            total += 1
                        except:
                            pass
        return total
    except:
        return 0


ensure_directories()

@TempMailBot.message_handler(commands=["start", "restart"])
def start_command_handler(message):
    """Handle /start & /restart commands"""
    try:
        user_id = message.from_user.id
        user_name = message.from_user.first_name
        
        # Update user stats
        update_user_stats(user_id)
        

        ensure_directories()
        

        if f"{user_id}" in os.listdir("Accounts/"):
            welcome_text = PERSIAN_TEXTS['welcome_back'].format(name=user_name)
        else:
            # Create user directory
            os.makedirs(f"Accounts/{user_id}/mails/", exist_ok=True)
            welcome_text = PERSIAN_TEXTS['welcome_new'].format(name=user_name)
        

        keyboard = [
            [types.InlineKeyboardButton("🔮 منوی اصلی", callback_data="MainMenu")],
            [types.InlineKeyboardButton("📊 آمار من", callback_data="UserStats")],
            [types.InlineKeyboardButton("❓ راهنما", callback_data="HelpMenu")],
        ]
        

        if is_admin(user_id):
            keyboard.append([types.InlineKeyboardButton("🔐 پنل ادمین", callback_data="AdminPanel")])
        
        markup = types.InlineKeyboardMarkup(keyboard)
        

        TempMailBot.send_chat_action(chat_id=message.chat.id, action="typing")
        TempMailBot.send_message(
            chat_id=message.chat.id,
            text=welcome_text,
            reply_markup=markup,
            parse_mode=None
        )
        
    except Exception as e:
        print(f"Error in start_command_handler: {e}")
        TempMailBot.reply_to(message, "خطایی رخ داد! دوباره امتحان کن")

@TempMailBot.message_handler(commands=["mail"])
def mail_generator_handler(message):
    """Handle /mail command"""
    try:
        if utils.force_private(message):
            keyboard = create_persian_keyboard()
            
            TempMailBot.send_chat_action(chat_id=message.chat.id, action="typing")
            TempMailBot.send_message(
                chat_id=message.chat.id,
                text=f"{PERSIAN_TEXTS['mail_menu_title']}",
                reply_markup=keyboard,
                parse_mode=None,
            )
    except Exception as e:
        print(f"Error in mail_generator_handler: {e}")
        TempMailBot.reply_to(message, "خطایی رخ داد! دوباره امتحان کن")

@TempMailBot.message_handler(commands=["stats"])
def stats_handler(message):
    """Handle /stats command"""
    try:
        user_id = message.from_user.id
        stats = get_user_stats(user_id)
        
        stats_text = f"{PERSIAN_TEXTS['stats_title']}\n\n"
        stats_text += f"{PERSIAN_TEXTS['stats_emails'].format(count=stats['total_emails'])}\n"
        stats_text += f"{PERSIAN_TEXTS['stats_created'].format(count=stats['emails_created'])}\n"
        stats_text += f"{PERSIAN_TEXTS['stats_last_activity'].format(time=stats['last_activity'])}"
        
        TempMailBot.reply_to(message, stats_text, parse_mode=None)
    except Exception as e:
        print(f"Error in stats_handler: {e}")
        TempMailBot.reply_to(message, "خطایی رخ داد! دوباره امتحان کن")

@TempMailBot.message_handler(commands=["help"])
def help_handler(message):
    """Handle /help command"""
    TempMailBot.reply_to(message, PERSIAN_TEXTS['help_text'], parse_mode=None)

@TempMailBot.message_handler(commands=["admin"])
def admin_handler(message):
    """Handle /admin command"""
    try:
        user_id = message.from_user.id
        
        if not is_admin(user_id):
            TempMailBot.reply_to(message, "❌ شما دسترسی ادمین ندارید!")
            return
        
        keyboard = create_admin_keyboard()
        
        TempMailBot.send_chat_action(chat_id=message.chat.id, action="typing")
        TempMailBot.send_message(
            chat_id=message.chat.id,
            text=PERSIAN_TEXTS['admin_panel_title'],
            reply_markup=keyboard,
            parse_mode=None,
        )
        
    except Exception as e:
        print(f"Error in admin_handler: {e}")
        TempMailBot.reply_to(message, "خطایی رخ داد! دوباره امتحان کن")

@TempMailBot.message_handler(commands=["broadcast"])
def broadcast_handler(message):
    """Handle /broadcast command for admin"""
    try:
        user_id = message.from_user.id
        
        if not is_admin(user_id):
            TempMailBot.reply_to(message, "❌ شما دسترسی ادمین ندارید!")
            return
        
        # Extract broadcast message
        broadcast_text = message.text.replace("/broadcast", "").strip()
        
        if not broadcast_text:
            TempMailBot.reply_to(message, "❌ لطفاً پیام خود را بعد از /broadcast بنویسید")
            return
        

        sent_count = 0
        if os.path.exists("Accounts/"):
            for user_dir in os.listdir("Accounts/"):
                try:
                    user_id_to_send = int(user_dir)
                    TempMailBot.send_message(
                        chat_id=user_id_to_send,
                        text=f"📢 پیام همگانی:\n\n{broadcast_text}",
                        parse_mode=None
                    )
                    sent_count += 1
                except:
                    pass
        
        TempMailBot.reply_to(
            message, 
            f"✅ پیام با موفقیت ارسال شد\n📊 تعداد دریافت‌کنندگان: {sent_count}",
            parse_mode=None
        )
        
    except Exception as e:
        print(f"Error in broadcast_handler: {e}")
        TempMailBot.reply_to(message, "خطایی رخ داد! دوباره امتحان کن")

@TempMailBot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    """Handle callback queries"""
    try:
        uid = call.from_user.id
        cid = call.message.chat.id
        mid = call.message.message_id
        

        update_user_stats(uid)
        
        if call.data == "NewEmail":
            try:
                TempMailBot.answer_callback_query(call.id, "⏳ لطفاً صبر کن...")
                
                new_mail_msg = TempMailBot.send_message(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['generating_email'],
                    parse_mode=None, 
                )
                
                result = "".join(Generate_Email(call))
                update_user_stats(uid, 'email_created')
                

                keyboard = [
                    [types.InlineKeyboardButton("📋 کپی ایمیل", callback_data=f"CopyEmail_{result.split('`')[1].split('`')[0]}")],
                    [types.InlineKeyboardButton("📬 صندوق ورودی", callback_data="EMailBoxMenu")],
                    [types.InlineKeyboardButton("❌ بستن", callback_data="Close")]
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                

                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=result,
                    message_id=new_mail_msg.message_id,
                    parse_mode=None,  # No Markdown parsing
                    reply_markup=markup,
                    disable_web_page_preview=None,
                )
                
            except Exception as e:
                print(f"Error generating email: {e}")
                TempMailBot.answer_callback_query(
                    call.id, PERSIAN_TEXTS['error_occurred'], show_alert=True
                )

        elif call.data.startswith("CopyEmail_"):
            try:
                email = call.data.split("_")[1]
                TempMailBot.answer_callback_query(
                    call.id, 
                    f"📋 ایمیل کپی شد:\n{email}", 
                    show_alert=True
                )
                
            except Exception as e:
                print(f"Error in CopyEmail: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "MainMenu":
            try:
                keyboard = create_persian_keyboard()
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['mail_menu_title'],
                    message_id=mid,
                    reply_markup=keyboard,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in MainMenu: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "HelpMenu":
            try:
                keyboard = [
                    [types.InlineKeyboardButton("🔮 منوی اصلی", callback_data="MainMenu")],
                    [types.InlineKeyboardButton("📊 آمار من", callback_data="UserStats")],
                    [types.InlineKeyboardButton("❌ بستن", callback_data="Close")]
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['help_text'],
                    message_id=mid,
                    reply_markup=markup,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in HelpMenu: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "AdminPanel":
            try:
                if not is_admin(uid):
                    TempMailBot.answer_callback_query(call.id, "❌ شما دسترسی ادمین ندارید!", show_alert=True)
                    return
                
                keyboard = create_admin_keyboard()
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['admin_panel_title'],
                    message_id=mid,
                    reply_markup=keyboard,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in AdminPanel: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "BackToStart":
            try:
                user_name = call.from_user.first_name
                welcome_text = PERSIAN_TEXTS['welcome_back'].format(name=user_name)
                

                keyboard = [
                    [types.InlineKeyboardButton("🔮 منوی اصلی", callback_data="MainMenu")],
                    [types.InlineKeyboardButton("📊 آمار من", callback_data="UserStats")],
                    [types.InlineKeyboardButton("❓ راهنما", callback_data="HelpMenu")],
                ]
                

                if is_admin(uid):
                    keyboard.append([types.InlineKeyboardButton("🔐 پنل ادمین", callback_data="AdminPanel")])
                
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=welcome_text,
                    message_id=mid,
                    reply_markup=markup,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in BackToStart: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "EmailList":
            try:
                ensure_directories()
                keyboard = []
                user_mails_dir = f"Accounts/{uid}/mails/"
                if os.path.exists(user_mails_dir):
                    mails = sorted(os.listdir(user_mails_dir))
                else:
                    mails = []
                
                for mail in mails:
                    keyboard.append([
                        types.InlineKeyboardButton(f"📧 {mail}", callback_data=f"MailInfo_{mail}")
                    ])
                
                keyboard.append([types.InlineKeyboardButton("❌ بستن", callback_data="Close")])
                markup = types.InlineKeyboardMarkup(keyboard)
                
                if len(keyboard) == 1:
                    TempMailBot.send_message(
                        chat_id=cid,
                        text=PERSIAN_TEXTS['no_emails'],
                        reply_markup=markup,
                    )
                else:
                    TempMailBot.send_message(
                        chat_id=cid,
                        text=PERSIAN_TEXTS['email_list_title'],
                        reply_markup=markup,
                    )
                
                TempMailBot.answer_callback_query(call.id, "✅ رایگان و بدون محدودیت!")
                
            except Exception as e:
                print(f"Error in EmailList: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("MailInfo"):
            try:
                mail = call.data.split("_")[1]
                with open(f"Accounts/{uid}/mails/{mail}", "r") as data:
                    infos = [d.split("\n")[0].split(":", maxsplit=1)[1] for d in data.readlines()]
                
                info_text = f"{PERSIAN_TEXTS['email_info_title']}\n\n"
                info_text += f"{PERSIAN_TEXTS['email_info_username'].format(username=infos[0])}\n"
                info_text += f"{PERSIAN_TEXTS['email_info_password'].format(password=infos[1])}\n"
                info_text += f"{PERSIAN_TEXTS['email_info_token'].format(token=infos[2][:20])}\n"
                info_text += f"{PERSIAN_TEXTS['email_info_created'].format(date=infos[3])}\n"
                info_text += f"{PERSIAN_TEXTS['email_info_domain'].format(domain=infos[4])}"
                
                TempMailBot.answer_callback_query(call.id, info_text, show_alert=True)
                
            except Exception as e:
                print(f"Error in MailInfo: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("EMailBoxMenu"):
            try:
                ensure_directories()
                keyboard = []
                user_mails_dir = f"Accounts/{uid}/mails/"
                if os.path.exists(user_mails_dir):
                    mails = sorted(os.listdir(user_mails_dir))
                else:
                    mails = []
                
                for mail in mails:
                    keyboard.append([
                        types.InlineKeyboardButton(f"📧 {mail}", callback_data=f"EMailBox_{mail}")
                    ])
                
                keyboard.append([types.InlineKeyboardButton("❌ بستن", callback_data="Close")])
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.send_chat_action(chat_id=cid, action="typing")
                TempMailBot.send_message(
                    chat_id=cid,
                    text="📬 ایمیل مورد نظر را انتخاب کن تا صندوق ورودی را ببینی",
                    reply_markup=markup,
                )
                
            except Exception as e:
                print(f"Error in EMailBoxMenu: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("EMailBox_"):
            try:
                mail = call.data.split("_")[1]
                
                with open(f"Accounts/{uid}/mails/{mail}", "r") as data:
                    token = data.readlines()[2].split("\n")[0].split(":", maxsplit=1)[1]
                
                cond, result = Load_Mail_Box(token)
                
                if not cond:
                    TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['inbox_empty'], show_alert=True)
                    return
                
                # Send note about attachments
                TempMailBot.send_chat_action(chat_id=cid, action="typing")
                TempMailBot.send_message(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['attachment_support'],
                    disable_web_page_preview=True,
                    parse_mode=None  # Don't use Markdown for this message
                )
                

                for i, msg in enumerate(result):
                    TempMailBot.send_chat_action(chat_id=cid, action="typing")
                    TempMailBot.send_message(
                        chat_id=cid, 
                        text=msg, 
                        disable_web_page_preview=True,
                        parse_mode=None  # Don't use Markdown for user messages
                    )
                    
 
                    if i < len(result) - 1:  # Don't delay after the last message
                        time.sleep(0.5)
                    
            except Exception as e:
                print(f"Error in EMailBox: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "DelEMailMenu":
            try:
                ensure_directories()
                keyboard = []
                user_mails_dir = f"Accounts/{uid}/mails/"
                if os.path.exists(user_mails_dir):
                    mails = sorted(os.listdir(user_mails_dir))
                else:
                    mails = []
                
                for mail in mails:
                    keyboard.append([
                        types.InlineKeyboardButton(f"📧 {mail}", callback_data=f"DeleteMail_{mail}")
                    ])
                
                keyboard.append([
                    types.InlineKeyboardButton("⚠️ حذف همه", callback_data="DelAllMails"),
                    types.InlineKeyboardButton("❌ بستن", callback_data="Close")
                ])
                
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.send_chat_action(chat_id=cid, action="typing")
                TempMailBot.send_message(
                    chat_id=cid,
                    text="🗑️ ایمیل مورد نظر را برای حذف انتخاب کن\n⚠️ این عملیات قابل بازگشت نیست",
                    reply_markup=markup,
                )
                
            except Exception as e:
                print(f"Error in DelEMailMenu: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("DeleteMail_"):
            try:
                mail = call.data.split("_")[1]
                
                keyboard = [
                    [types.InlineKeyboardButton("⚠️ حذف", callback_data=f"DeleteYes_{mail}")],
                    [types.InlineKeyboardButton("❌ لغو", callback_data=f"DeleteNo_{mail}")],
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.send_chat_action(chat_id=cid, action="typing")
                TempMailBot.send_message(
                    chat_id=cid,
                    text=f"{PERSIAN_TEXTS['delete_confirm']}\n\n📧 {escape_markdown_safe(mail)}",
                    parse_mode="MarkdownV2",
                    reply_markup=markup,
                )
                
            except Exception as e:
                print(f"Error in DeleteMail: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("DeleteYes_"):
            try:
                mail = call.data.split("_")[1]
                
                try:
                    os.remove(f"Accounts/{uid}/mails/{mail}")
                    TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['email_deleted'], show_alert=True)
                except FileNotFoundError:
                    TempMailBot.answer_callback_query(call.id, "این ایمیل وجود ندارد!", show_alert=True)
                
                TempMailBot.delete_message(chat_id=cid, message_id=mid)
                
            except Exception as e:
                print(f"Error in DeleteYes: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data.startswith("DeleteNo_"):
            try:
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['operation_cancelled'], show_alert=True)
                TempMailBot.delete_message(chat_id=cid, message_id=mid)
                
            except Exception as e:
                print(f"Error in DeleteNo: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "DelAllMails":
            try:
                keyboard = [
                    [types.InlineKeyboardButton("⚠️ حذف همه", callback_data="DeleteAll_Yes")],
                    [types.InlineKeyboardButton("❌ لغو", callback_data="DeleteNo_")],
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.send_chat_action(chat_id=cid, action="typing")
                TempMailBot.send_message(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['delete_all_confirm'],
                    reply_markup=markup,
                )
                
            except Exception as e:
                print(f"Error in DelAllMails: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "DeleteAll_Yes":
            try:
                user_mails_dir = f"Accounts/{uid}/mails/"
                if os.path.exists(user_mails_dir):
                    for mail in os.listdir(user_mails_dir):
                        try:
                            os.remove(f"Accounts/{uid}/mails/{mail}")
                        except FileNotFoundError:
                            pass
                
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['all_emails_deleted'], show_alert=True)
                TempMailBot.delete_message(chat_id=cid, message_id=mid)
                
            except Exception as e:
                print(f"Error in DeleteAll_Yes: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "UserStats":
            try:
                stats = get_user_stats(uid)
                
                stats_text = f"{PERSIAN_TEXTS['stats_title']}\n\n"
                stats_text += f"{PERSIAN_TEXTS['stats_emails'].format(count=stats['total_emails'])}\n"
                stats_text += f"{PERSIAN_TEXTS['stats_created'].format(count=stats['emails_created'])}\n"
                stats_text += f"{PERSIAN_TEXTS['stats_last_activity'].format(time=stats['last_activity'])}"
                
                keyboard = [
                    [types.InlineKeyboardButton("🔮 منوی اصلی", callback_data="MainMenu")],
                    [types.InlineKeyboardButton("📊 آمار من", callback_data="UserStats")],
                    [types.InlineKeyboardButton("❌ بستن", callback_data="Close")]
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=stats_text,
                    message_id=mid,
                    reply_markup=markup,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in UserStats: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])


        elif call.data == "AdminStats":
            try:
                if not is_admin(uid):
                    TempMailBot.answer_callback_query(call.id, "❌ شما دسترسی ادمین ندارید!", show_alert=True)
                    return
                
                total_users = get_total_users()
                total_emails = get_total_emails()
                today_emails = get_today_emails()
                
                stats_text = f"{PERSIAN_TEXTS['admin_stats_title']}\n\n"
                stats_text += f"{PERSIAN_TEXTS['admin_stats_users'].format(count=total_users)}\n"
                stats_text += f"{PERSIAN_TEXTS['admin_stats_emails'].format(count=total_emails)}\n"
                stats_text += f"{PERSIAN_TEXTS['admin_stats_today'].format(count=today_emails)}\n"
                stats_text += f"{PERSIAN_TEXTS['admin_stats_online']}"
                
                TempMailBot.answer_callback_query(call.id, stats_text, show_alert=True)
                
            except Exception as e:
                print(f"Error in AdminStats: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "AdminBroadcast":
            try:
                if not is_admin(uid):
                    TempMailBot.answer_callback_query(call.id, "❌ شما دسترسی ادمین ندارید!", show_alert=True)
                    return
                
                TempMailBot.answer_callback_query(call.id, "📢 از دستور /broadcast استفاده کنید", show_alert=True)
                
            except Exception as e:
                print(f"Error in AdminBroadcast: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "AdminUsers":
            try:
                if not is_admin(uid):
                    TempMailBot.answer_callback_query(call.id, "❌ شما دسترسی ادمین ندارید!", show_alert=True)
                    return
                
                keyboard = [
                    [types.InlineKeyboardButton("📋 لیست کاربران", callback_data="AdminUserList")],
                    [types.InlineKeyboardButton("🔍 جستجوی کاربر", callback_data="AdminUserSearch")],
                    [types.InlineKeyboardButton("🚫 مسدود کردن", callback_data="AdminUserBan")],
                    [types.InlineKeyboardButton("✅ آزاد کردن", callback_data="AdminUserUnban")],
                    [types.InlineKeyboardButton("❌ بستن", callback_data="Close")]
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['admin_user_management'],
                    message_id=mid,
                    reply_markup=markup,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in AdminUsers: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "AdminSettings":
            try:
                if not is_admin(uid):
                    TempMailBot.answer_callback_query(call.id, "❌ شما دسترسی ادمین ندارید!", show_alert=True)
                    return
                
                keyboard = [
                    [types.InlineKeyboardButton("🔧 حالت تعمیر", callback_data="AdminMaintenance")],
                    [types.InlineKeyboardButton("📊 تنظیم محدودیت‌ها", callback_data="AdminLimits")],
                    [types.InlineKeyboardButton("💾 پشتیبان‌گیری", callback_data="AdminBackup")],
                    [types.InlineKeyboardButton("❌ بستن", callback_data="Close")]
                ]
                markup = types.InlineKeyboardMarkup(keyboard)
                
                TempMailBot.edit_message_text(
                    chat_id=cid,
                    text=PERSIAN_TEXTS['admin_settings'],
                    message_id=mid,
                    reply_markup=markup,
                    parse_mode=None
                )
                
            except Exception as e:
                print(f"Error in AdminSettings: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])

        elif call.data == "Close":
            try:
                TempMailBot.delete_message(chat_id=cid, message_id=mid)
            except Exception as e:
                print(f"Error in Close: {e}")
                TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])
                
    except Exception as e:
        print(f"General callback error: {e}")
        try:
            TempMailBot.answer_callback_query(call.id, PERSIAN_TEXTS['error_occurred'])
        except:
            pass

# Error handler
@TempMailBot.message_handler(func=lambda message: True)
def echo_all(message):
    """Handle all other messages"""
    TempMailBot.reply_to(message, "💡 از دستور /mail استفاده کن")

if __name__ == "__main__":
    print("🚀 راه‌اندازی ربات...")
    print("📧 ربات ایمیل موقت آماده است!")
    
    try:
        TempMailBot.infinity_polling(skip_pending=True, none_stop=True)
    except Exception as e:
        print(f"❌ خطا در اتصال: {e}")
        print("🔄 تلاش مجدد...")
        time.sleep(5)
        TempMailBot.infinity_polling(skip_pending=True, none_stop=True) 