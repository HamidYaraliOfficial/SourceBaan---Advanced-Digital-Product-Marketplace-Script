



import requests  
import json      
import random    
import os        
import base64    
import re        


# Bot token to use
Token = ""


# Decode and format MIME mail
def Decode_MIME(mime_message: str) -> str:
    """
    Decode and extract important content from MIME message with clean formatting.
    
    Args:
        mime_message (str): The MIME message containing email content.

    Returns:
        str: The cleaned and formatted important content.
    """
    
    try:
        # First try to find base64-encoded parts
        base64_parts = re.findall(
            r'Content-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n(.*?)--', 
            mime_message, 
            re.DOTALL
        )
        
        if base64_parts:
            # Decode base64 and extract important content
            decoded_parts = []
            for part in base64_parts:
                try:
                    decoded_part = base64.b64decode(part).decode('utf-8', errors='ignore')
                    important_content = extract_important_content(decoded_part)
                    if important_content:
                        decoded_parts.append(important_content)
                except:
                    continue
            return "\n".join(decoded_parts)
        

        base64_patterns = [
            r'Content-Type: text/plain[^\r\n]*\r\nContent-Transfer-Encoding: base64\r\n\r\n(.*?)(?=\r\n--|$)',
            r'Content-Type: text/html[^\r\n]*\r\nContent-Transfer-Encoding: base64\r\n\r\n(.*?)(?=\r\n--|$)',
            r'Content-Transfer-Encoding: base64\r\n\r\n(.*?)(?=\r\n--|$)'
        ]
        
        for pattern in base64_patterns:
            base64_parts = re.findall(pattern, mime_message, re.DOTALL)
            if base64_parts:
                decoded_parts = []
                for part in base64_parts:
                    try:
                        decoded_part = base64.b64decode(part).decode('utf-8', errors='ignore')
                        important_content = extract_important_content(decoded_part)
                        if important_content:
                            decoded_parts.append(important_content)
                    except:
                        continue
                if decoded_parts:
                    return "\n".join(decoded_parts)
        

        plain_text_parts = re.findall(
            r'Content-Type: text/plain[^\r\n]*\r\n\r\n(.*?)(?=\r\n--|$)', 
            mime_message, 
            re.DOTALL
        )
        
        if plain_text_parts:
            # Clean and extract important content
            cleaned_parts = []
            for part in plain_text_parts:
                important_content = extract_important_content(part)
                if important_content:
                    cleaned_parts.append(important_content)
            return "\n".join(cleaned_parts)
        

        text_content = re.findall(
            r'Content-Type: text/[^\r\n]*\r\n\r\n(.*?)(?=\r\n--|$)', 
            mime_message, 
            re.DOTALL
        )
        
        if text_content:
            # Clean and extract important content
            cleaned_parts = []
            for part in text_content:
                important_content = extract_important_content(part)
                if important_content:
                    cleaned_parts.append(important_content)
            return "\n".join(cleaned_parts)
        

        simple_content = re.findall(r'\r\n\r\n(.*?)(?=\r\n--|$)', mime_message, re.DOTALL)
        if simple_content:
            cleaned_parts = []
            for part in simple_content:
                important_content = extract_important_content(part)
                if important_content and len(important_content) > 10:
                    cleaned_parts.append(important_content)
            if cleaned_parts:
                return "\n".join(cleaned_parts)
        

        return "محتوا قابل نمایش نیست یا ایمیل خالی است."
        
    except Exception as e:
        print(f"Error decoding MIME: {e}")
        return "خطا در خواندن محتوا"

def extract_important_content(text: str) -> str:
    """
    Extract important content from email text (verification codes, important messages, etc.)
    
    Args:
        text (str): The email text content
        
    Returns:
        str: Clean and formatted important content
    """
    try:


        span_patterns = [
            r'<span[^>]*>([A-Z0-9]{6,8})</span>',
            r'<span[^>]*>([A-Z0-9]{6,8})</span\s*>',
            r'<span[^>]*>([A-Z0-9]{6,8})</span\s*>\s*</span>',
        ]
        
        for pattern in span_patterns:
            span_codes = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)
            if span_codes:
                code = span_codes[0]
                if 6 <= len(code) <= 8 and code.isalnum():
                    return f"🔐 کد تایید: {code}"
        

        all_span_content = re.findall(r'<span[^>]*>([^<]+)</span>', text, re.IGNORECASE | re.DOTALL)
        for content in all_span_content:
            # Look for codes in the span content
            codes = re.findall(r'\b([A-Z0-9]{6,8})\b', content)
            for code in codes:
                if code.isalnum() and not code.isdigit():  # Must contain letters
                    return f"🔐 کد تایید: {code}"
        

        text = re.sub(r'<[^>]+>', '', text)
        

        text = re.sub(r'\s+', ' ', text).strip()
        

        verification_patterns = [
            r'verification code[:\s]*([A-Z0-9]{6,8})',
            r'code[:\s]*([A-Z0-9]{6,8})',
            r'verification[:\s]*([A-Z0-9]{6,8})',
            r'enter the code[:\s]*([A-Z0-9]{6,8})',
            r'your code[:\s]*([A-Z0-9]{6,8})',
            r'code is[:\s]*([A-Z0-9]{6,8})',
            r'verification code is[:\s]*([A-Z0-9]{6,8})',
        ]
        
        for pattern in verification_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                code = matches[0]
                # Check if it's a reasonable verification code (6-8 characters)
                if 6 <= len(code) <= 8 and code.isalnum():
                    return f"🔐 کد تایید: {code}"
        

        standalone_codes = re.findall(r'\b([A-Z0-9]{6,8})\b', text)
        for code in standalone_codes:
            if code.isalnum() and not code.isdigit():  # Must contain letters
                return f"   کد تایید: {code}"
        

        important_keywords = [
            'verification', 'confirm', 'activate', 'verify', 'code', 'password', 'reset',
            'تایید', 'فعال‌سازی', 'کد', 'رمز', 'بازنشانی'
        ]
        
        lines = text.split('\n')
        important_lines = []
        
        for line in lines:
            line = line.strip()
            if any(keyword.lower() in line.lower() for keyword in important_keywords):
                # Clean the line
                clean_line = re.sub(r'[^\w\s\-:\.]', '', line)
                if clean_line and len(clean_line) > 3:
                    important_lines.append(clean_line)
        
        if important_lines:
            return "\n".join(important_lines)
        

        meaningful_lines = []
        for line in lines:
            line = line.strip()
            if line and len(line) > 10 and not line.startswith('http'):
                meaningful_lines.append(line)
                if len(meaningful_lines) >= 3:  # Limit to 3 lines
                    break
        
        if meaningful_lines:
            return "\n".join(meaningful_lines)
        

        return "محتوا قابل نمایش نیست"
        
    except Exception as e:
        print(f"Error extracting important content: {e}")
        return "خطا در استخراج محتوا"



def escape_markdown(string: str) -> str:
    """
    Function to escape markdown syntax
    
    Parameter:
        String to be escaped
    
    Returns:
        Filtered string
    """


    return (
        string.replace("_", "\_").replace("*", "\*").replace("[", "\[")
        .replace("]", "\]").replace("(", "\(").replace(")", "\)")
        .replace("~", "\~").replace(">", "\>").replace("#", "\#")
        .replace("+", "\+").replace("-", "\-").replace("=", "\=")
        .replace("|", "\|").replace("{", "\{").replace("}", "\}")
        .replace(".", "\.").replace("!", "\!").replace(",", "\,")
    )



def force_private(message: object) -> bool:
    """
    Function to force chat into private chat

    Parameter:
        Message object

    Returns:
        Boolean value
    """


    if message.chat.type == "private":
        return True
    
    return False



def Smart_Random_String(length: int) -> str:
    """
    Function to generate Smart random String
    
    Generates a random word string by alternating between 
       consonants and vowels. It uses the random.choice 
       function to randomly select characters from the 
       consonants or vowels strings

    Parameter:
        Length of string
    """
    

    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    

    random_string = ""


    while len(random_string) < length:


        if len(random_string) % 2 == 0:
            char = random.choice(consonants)
        else:
            char = random.choice(vowels)
        
        # Adding result to string
        random_string += char
    

    return random_string[:length]



def Generate_Email(message: callable) -> str:
    """
    Function to generate temporary Email

    Generates temporary Email address less then one
       minute with access to Inbox

    Parameter:
        Bot message object (You don't need to pass anything)
    """


    try:

        # Initializing Username and Password (Not important for user)
        addrs = Smart_Random_String(8)
        paswd = Smart_Random_String(8)

        # Get available domain names
        req1 = requests.get(url="https://api.mail.tm/domains", timeout=10).json()
        res1 = req1
        for key, val in res1.items():
            if key == "hydra:member":
                tmp = res1[key][0]


                if tmp["isActive"]:
                    account_mail_name = tmp["domain"]


                    with open(
                        f"Accounts/{message.from_user.id}/mails/{addrs}@{account_mail_name}",
                        "w",
                    ) as data:
                        data.write(
                            f"account_addrs:\n"
                            f"account_psswd:\n"
                            f"account_token:\n"
                            f"account_creat:\n"
                            f"account_mail_name:{account_mail_name}\n"
                        )


        headers = {"Content-type": "application/json"}
        params = {"address": f"{addrs}@{account_mail_name}", "password": paswd}
        

        req2 = requests.post(
            url="https://api.mail.tm/accounts", json=params, headers=headers, timeout=10
        )
        res2 = req2.json()


        creat = " ".join(res2["createdAt"].split("T"))


        with open(
            f"Accounts/{message.from_user.id}/mails/{addrs}@{account_mail_name}", "w"
        ) as data:
            data.write(
                f"account_addrs:{addrs}\n"
                f"account_psswd:{paswd}\n"
                f"account_token:\n"
                f"account_creat:{creat}\n"
                f"account_mail_name:{account_mail_name}\n"
            )


        req3 = requests.post(
            url="https://api.mail.tm/token", json=params, headers=headers, timeout=10
        )
        res3 = req3.json()
        token = res3["token"]


        with open(
            f"Accounts/{message.from_user.id}/mails/{addrs}@{account_mail_name}", "w"
        ) as data:
            data.write(
                f"account_addrs:{addrs}\n"
                f"account_psswd:{paswd}\n"
                f"account_token:{token}\n"
                f"account_creat:{creat}\n"
                f"account_mail_name:{account_mail_name}\n"
            )


        return (
            f"🎉 ایمیل شما با موفقیت ایجاد شد!\n\n"
            f"✨ ایمیل شما آماده است\n"
            f"📧 می‌توانید از منوی /mail صندوق ورودی را ببینید\n\n"
            f"🔮 ایمیل شما:\n"
            f"`{addrs}@{account_mail_name}`"
        )

    except:
        # Return error message
        return f"❌ خطایی رخ داد! دوباره امتحان کنید"



def Load_Mail_Box(token: str) -> tuple:
    """
    Function to Load mailbox by given Token

    Shows all messages from User Email's mailbox (Attachment are now supported)

    Parameter:
        Token
    """


    try:

 
        headers = {"Authorization": f"Bearer {token}"}
        req1 = requests.get(
            url="https://api.mail.tm/messages", headers=headers, timeout=10
        )
        res1 = req1.json()


        messages_count = res1["hydra:totalItems"]
        

        if messages_count == 0:
            return False, "📭 صندوق ورودی خالی است!\n\n✨ بعد از چند دقیقه دوباره امتحان کنید"
        

        else:
            inboxes = []
            for message in res1["hydra:member"]:
                # Fetch sender information with modern formatting
                message_from = (
                    f"👤 از: {message['from']['name']}\n"
                    f"📧 {message['from']['address']}\n\n"
                )


                try:
                    message_subj = (
                        f"📋 موضوع: {message['subject']}\n\n"
                        if message["subject"] != ""
                        else "📋 موضوع: بدون موضوع\n\n"
                    )
                except KeyError:
                    message_subj = f"📋 موضوع: بدون موضوع\n\n"


                try:

                    message_response = requests.get(
                        url=f"https://api.mail.tm{message['downloadUrl']}", 
                        headers=headers, 
                        timeout=10
                    )
                    
                    if message_response.status_code == 200:
                        message_intr = Decode_MIME(message_response.text)
                        

                        if message_intr and message_intr.strip():
                            # Format the content in a glass-like style
                            if "کد تایید" in message_intr:
                                message_content = f"✨ {message_intr}"
                            else:
                                message_content = f"📄 محتوا:\n{message_intr}"
                        else:
                            message_content = f"📄 محتوا: ایمیل خالی است یا محتوا قابل نمایش نیست"
                    else:
                        message_content = f"📄 محتوا: خطا در دریافت محتوا (کد: {message_response.status_code})"
                        
                except Exception as e:
                    print(f"Error fetching message content: {e}")
                    message_content = f"📄 محتوا: خطا در خواندن محتوا - {str(e)}"


                full_message = message_from + message_subj + message_content
                

                message_parts = split_long_message(full_message)
                inboxes.extend(message_parts)
            

            if len(inboxes) > 1:
                summary_message = f"📬 تعداد ایمیل‌ها: {len(inboxes)}\n\n✨ ایمیل‌های شما:"
                inboxes.insert(0, summary_message)
            
            return True, inboxes
    
    except:

        return False, f"❌ خطایی رخ داد! دوباره امتحان کنید"


def debug_email_content(mime_message: str) -> str:
    """
    Debug function to understand email content structure
    """
    try:

        content_types = re.findall(r'Content-Type: ([^\r\n]+)', mime_message)
        

        encodings = re.findall(r'Content-Transfer-Encoding: ([^\r\n]+)', mime_message)
        

        boundaries = re.findall(r'boundary="([^"]+)"', mime_message)
        
        debug_info = f"Content Types: {content_types}\n"
        debug_info += f"Encodings: {encodings}\n"
        debug_info += f"Boundaries: {boundaries}\n"
        debug_info += f"Message Length: {len(mime_message)} characters\n"
        
        return debug_info
    except Exception as e:
        return f"Debug error: {e}"


def split_long_message(text: str, max_length: int = 4000) -> list:
    """
    Split long text into smaller parts for Telegram message limit
    
    Args:
        text (str): The text to split
        max_length (int): Maximum length per message (default 4000 for safety)
    
    Returns:
        list: List of text parts
    """
    if len(text) <= max_length:
        return [text]
    
    parts = []
    current_part = ""
    

    lines = text.split('\n')
    
    for line in lines:

        if len(current_part + line + '\n') > max_length:
            if current_part:
                parts.append(current_part.strip())
                current_part = line + '\n'
            else:

                if len(line) > max_length:
                    # Split the long line
                    for i in range(0, len(line), max_length):
                        parts.append(line[i:i + max_length])
                else:
                    parts.append(line)
        else:
            current_part += line + '\n'
    

    if current_part.strip():
        parts.append(current_part.strip())
    

    if len(parts) > 1:
        numbered_parts = []
        for i, part in enumerate(parts, 1):
            header = f"📄 بخش {i} از {len(parts)}:\n\n"
            numbered_parts.append(header + part)
        return numbered_parts
    
    return parts
