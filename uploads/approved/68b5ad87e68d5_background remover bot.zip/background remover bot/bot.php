<?php

/**
 * ربات حذف بگراند تلگرام
 * 
 * @author   silvon Developer
 * @contact  https://t.me/Mrsilvon
 * @version  1.0.0
 * @date     2025-07-27
 * @license  Private Use Only - Do Not Distribute
 */


$telegramToken = 'توکن';
$removeBgApiKey = 'Ff5g84dTfzLkzX7BJzZKDRXP';
$adminId = 11111111; // ایدی تلگرام ادمین

// کانال جوین اجباری (تنظیم فقط اینجا، نه از بات)
$joinChannel = '@TomanRate_bot';

$configFile = __DIR__ . '/config.json';
$usersFile = __DIR__ . '/users.json';
$stateFile = __DIR__ . '/state.json';


$config = file_exists($configFile) ? json_decode(file_get_contents($configFile), true) : ['join_channel' => '', 'enabled' => true];
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : ['blocked' => [], 'users' => []];
$states = file_exists($stateFile) ? json_decode(file_get_contents($stateFile), true) : [];


function saveConfig() {
    global $config, $configFile;
    file_put_contents($configFile, json_encode($config));
}
function saveUsers() {
    global $users, $usersFile;
    file_put_contents($usersFile, json_encode($users));
}
function saveStates() {
    global $states, $stateFile;
    file_put_contents($stateFile, json_encode($states));
}


function sendMessage($chatId, $text, $keyboard = null, $parseMode = 'HTML') {
    global $telegramToken;
    $data = ['chat_id' => $chatId, 'text' => $text, 'parse_mode' => $parseMode];
    if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    file_get_contents("https://api.telegram.org/bot$telegramToken/sendMessage?" . http_build_query($data));
}

function deleteMessage($chatId, $messageId) {
    global $telegramToken;
    file_get_contents("https://api.telegram.org/bot$telegramToken/deleteMessage?" . http_build_query(['chat_id' => $chatId, 'message_id' => $messageId]));
}

function answerCallback($callbackId, $text = '') {
    global $telegramToken;
    $data = ['callback_query_id' => $callbackId];
    if ($text) $data['text'] = $text;
    $data['show_alert'] = false;
    file_get_contents("https://api.telegram.org/bot$telegramToken/answerCallbackQuery?" . http_build_query($data));
}

function sendPhoto($chatId, $photoPath, $replyToMessageId = null) {
    global $telegramToken;
    $curl = curl_init();
    $postFields = [
        'chat_id' => $chatId,
        'photo' => new CURLFile($photoPath),
    ];
    if ($replyToMessageId) $postFields['reply_to_message_id'] = $replyToMessageId;
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.telegram.org/bot$telegramToken/sendPhoto",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postFields,
    ]);
    curl_exec($curl);
    curl_close($curl);
}

function isUserJoined($userId, $channelUsername) {
    global $telegramToken;
    $url = "https://api.telegram.org/bot$telegramToken/getChatMember?chat_id=$channelUsername&user_id=$userId";
    $res = file_get_contents($url);
    $res = json_decode($res, true);
    if (!$res['ok']) return false;
    $status = $res['result']['status'];
    return in_array($status, ['member', 'administrator', 'creator']);
}

function registerUser($userId) {
    global $users;
    if (!in_array($userId, $users['users'])) {
        $users['users'][] = $userId;
        saveUsers();
    }
}


$update = json_decode(file_get_contents('php://input'), true);
if (!$update) exit;

$message = $update['message'] ?? null;
$callback = $update['callback_query'] ?? null;

if ($message) {
    $chatId = $message['chat']['id'];
    $userId = $message['from']['id'];
    $text = $message['text'] ?? '';
    $messageId = $message['message_id'];

    global $states, $config, $users;

    registerUser($userId);

    if (in_array($userId, $users['blocked'])) {
        sendMessage($chatId, "شما بلاک شده‌اید و نمی‌توانید از ربات استفاده کنید.");
        exit;
    }

    if (!$config['enabled']) {

        if ($userId != $adminId) {
            sendMessage($chatId, "ربات در حال حاضر خاموش است. بعدا تلاش کنید.");
            exit;
        } else {

            if ($text === '/admin') {
                $keyboard = [
                    'inline_keyboard' => [
                        [['text' => '🟢 روشن', 'callback_data' => 'enable']],
                        [['text' => '📋 لیست کاربران', 'callback_data' => 'list_users']],
                    ]
                ];
                sendMessage($chatId, "ربات خاموش است. شما می‌توانید آن را روشن کنید:", $keyboard);
                exit;
            } else {
                sendMessage($chatId, "ربات در حال حاضر خاموش است. لطفا دستور /admin را ارسال کنید تا پنل مدیریت را باز کنید.");
                exit;
            }
        }
    }

    if ($text === '/admin' && $userId == $adminId) {
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📊 آمار', 'callback_data' => 'stats']],
                [['text' => '🔄 فوروارد', 'callback_data' => 'forward'], ['text' => '📢 همگانی', 'callback_data' => 'broadcast']],
                [['text' => '✅ آنبلاک', 'callback_data' => 'unblock'], ['text' => '🚫 بلاک', 'callback_data' => 'block']],
                [['text' => $config['enabled'] ? '🔴 خاموش' : '🟢 روشن', 'callback_data' => $config['enabled'] ? 'disable' : 'enable']],
                [['text' => '📁 لیست کاربران', 'callback_data' => 'list_users']],
            ]
        ];
        sendMessage($chatId, "پنل مدیریت ربات:", $keyboard);
        exit;
    }

    if ($userId != $adminId && !isUserJoined($userId, $joinChannel)) {
        $joinText = "🔒 برای استفاده از ربات ابتدا در کانال ما عضو شوید:";
        $keyboard = [
            'inline_keyboard' => [
                [['text' => "📢 عضویت در کانال", 'url' => "https://t.me/" . ltrim($joinChannel, '@')]],
                [['text' => "✅ عضو شدم", 'callback_data' => "check_join"]]
            ]
        ];
        sendMessage($chatId, $joinText, $keyboard, 'HTML');
        exit;
    }


    if (isset($message['photo'])) {
        $photos = $message['photo'];
        $fileId = end($photos)['file_id'];

        $fileInfo = file_get_contents("https://api.telegram.org/bot$telegramToken/getFile?file_id=$fileId");
        $fileInfo = json_decode($fileInfo, true);
        if (!$fileInfo['ok']) {
            sendMessage($chatId, "خطا در دریافت فایل", $messageId);
            exit;
        }
        $filePath = $fileInfo['result']['file_path'];
        $fileUrl = "https://api.telegram.org/file/bot$telegramToken/$filePath";

        sendMessage($chatId, "در حال حذف پس‌زمینه عکس، لطفا صبر کنید...", $messageId);

        $imageContent = file_get_contents($fileUrl);
        $tmpImage = tempnam(sys_get_temp_dir(), 'img_') . '.jpg';
        file_put_contents($tmpImage, $imageContent);

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.remove.bg/v1.0/removebg',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ["X-Api-Key: $removeBgApiKey"],
            CURLOPT_POSTFIELDS => ['image_file' => new CURLFile($tmpImage), 'size' => 'auto'],
        ]);
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        unlink($tmpImage);

        if ($httpCode != 200) {
            sendMessage($chatId, "خطا در حذف پس‌زمینه، لطفا دوباره تلاش کنید.", $messageId);
            exit;
        }

        $outputFile = tempnam(sys_get_temp_dir(), 'out_') . '.png';
        file_put_contents($outputFile, $response);

        sendPhoto($chatId, $outputFile, $messageId);
        unlink($outputFile);

        exit;
    }


    sendMessage($chatId, "سلام رفیق! 🤖  
این ربات اومده تا پس‌زمینه عکس‌هات رو پاک کنه!  
کافیه یه عکس بفرستی، من پس‌زمینه‌ش رو می‌زنم بیرون! 🧙‍♂️✨  
راستی، اینجا خبری از تبلیغات مزخرف نیست، فقط کلی حال و هوای فوتوشاپی دیجیتال! 😎📸");

    exit;
}

if ($callback) {
    $callbackId = $callback['id'];
    $userId = $callback['from']['id'];
    $chatId = $callback['message']['chat']['id'];
    $messageId = $callback['message']['message_id'];
    $data = $callback['data'];

    global $config, $users, $states;


    if ($data !== 'check_join' && $userId != $adminId) {
        answerCallback($callbackId, "❌ فقط ادمین می‌تواند استفاده کند.");
        exit;
    }

    if ($data == 'stats') {
        $totalUsers = count($users['users']);
        $blockedUsers = count($users['blocked']);
        answerCallback($callbackId, "📊 آمار:\nکاربران ثبت‌شده: $totalUsers\nکاربران بلاک شده: $blockedUsers");
    }
    elseif ($data == 'disable') {
        $config['enabled'] = false;
        saveConfig();
        answerCallback($callbackId, "ربات خاموش شد.");
        deleteMessage($chatId, $messageId);
    }
    elseif ($data == 'enable') {
        $config['enabled'] = true;
        saveConfig();
        answerCallback($callbackId, "ربات روشن شد.");
        deleteMessage($chatId, $messageId);
    }
    elseif ($data == 'list_users') {
        $list = "📋 لیست کاربران ثبت‌شده:\n";
        foreach ($users['users'] as $uid) {
            $list .= "- <code>$uid</code>\n";
        }
        sendMessage($chatId, $list);
        answerCallback($callbackId);
    }
    elseif ($data == 'block') {
        sendMessage($chatId, "برای بلاک کردن، شناسه کاربر مورد نظر را بفرستید:");
        answerCallback($callbackId);
        $states[$userId] = 'waiting_for_block';
        saveStates();
    }
    elseif ($data == 'unblock') {
        sendMessage($chatId, "برای آنبلاک کردن، شناسه کاربر را بفرستید:");
        answerCallback($callbackId);
        $states[$userId] = 'waiting_for_unblock';
        saveStates();
    }
    elseif ($data == 'forward') {
        sendMessage($chatId, "لطفا پیامی که می‌خواهید فوروارد شود را ارسال کنید:");
        answerCallback($callbackId);
        $states[$userId] = 'waiting_for_forward';
        saveStates();
    }
    elseif ($data == 'broadcast') {
        sendMessage($chatId, "پیامی که می‌خواهید همگانی ارسال شود را بفرستید:");
        answerCallback($callbackId);
        $states[$userId] = 'waiting_for_broadcast';
        saveStates();
    }
    /*
    elseif ($data == 'channel_settings') {

    }
    */
    elseif ($data == 'check_join') {
        if (isUserJoined($userId, $joinChannel)) {
            answerCallback($callbackId, "✅ عضویت شما تایید شد، حالا می‌توانید از ربات استفاده کنید.");
        } else {
            answerCallback($callbackId, "❌ هنوز عضو کانال نشده‌اید، لطفا عضو شوید و سپس دوباره امتحان کنید.");
        }
    }
}
?>
