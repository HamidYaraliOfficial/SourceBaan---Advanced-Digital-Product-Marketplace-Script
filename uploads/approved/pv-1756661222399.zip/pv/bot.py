import json
import os
import time
import requests
from threading import Thread
import asyncio
from typing import Dict, List, Optional

class TelegramBot:
    def __init__(self, token: str):
        self.token =  # توکن
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.dev_id =  # عددی مالک
        self.data_file = "data.json"
        self.members_file = "members.txt"
        self.banlist_file = "banlist.txt"
        self.init_files()
        
    def init_files(self):
        if not os.path.exists(self.data_file):
            default_data = {
                "stats": "on",
                "step": "none",
                "buttons": [],
                "buttonans": {},
                "quick": {},
                "filters": [],
                "lock": {
                    "text": "🔑", "photo": "🔑", "video": "🔑",
                    "audio": "🔑", "voice": "🔑", "sticker": "🔑",
                    "document": "🔑", "forward": "🔑", "link": "🔑",
                    "channel": "🔑"
                },
                "text": {"start": "", "done": ""},
                "channel": None,
                "feed": None,
                "admins": [],
                "contact": {"name": "", "phone": ""}
            }
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(default_data, f, ensure_ascii=False, indent=2)
        
        for file in [self.members_file, self.banlist_file]:
            if not os.path.exists(file):
                open(file, 'w').close()

    def load_data(self) -> dict:
        try:
            with open(self.data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}

    def save_data(self, data: dict):
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def bot_request(self, method: str, params: dict = None) -> dict:
        try:
            url = f"{self.base_url}/{method}"
            response = requests.post(url, json=params or {}, timeout=30)
            return response.json()
        except Exception as e:
            print(f"Error in bot_request: {e}")
            return {}

    def send_message(self, chat_id: int, text: str, reply_markup=None, parse_mode="HTML"):
        params = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode
        }
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self.bot_request("sendMessage", params)

    def edit_message_text(self, chat_id: int, message_id: int, text: str, reply_markup=None):
        params = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML"
        }
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self.bot_request("editMessageText", params)

    def forward_message(self, chat_id: int, from_chat_id: int, message_id: int):
        return self.bot_request("forwardMessage", {
            "chat_id": chat_id,
            "from_chat_id": from_chat_id,
            "message_id": message_id
        })

    def get_chat_member(self, chat_id: str, user_id: int):
        return self.bot_request("getChatMember", {
            "chat_id": chat_id,
            "user_id": user_id
        })

    def get_chat(self, chat_id: int):
        return self.bot_request("getChat", {"chat_id": chat_id})

    def answer_callback_query(self, callback_query_id: str, text: str, show_alert=False):
        return self.bot_request("answerCallbackQuery", {
            "callback_query_id": callback_query_id,
            "text": text,
            "show_alert": show_alert
        })

    def check_spam(self, user_id: int) -> bool:
        spam_file = f"spam_{user_id}.json"
        current_time = int(time.time())
        
        try:
            if os.path.exists(spam_file):
                with open(spam_file, 'r') as f:
                    spam_data = json.load(f)
                
                if current_time < spam_data.get('until', 0):
                    if spam_data.get('count', 0) >= 3:
                        return True
                    spam_data['count'] += 1
                else:
                    spam_data = {'count': 1, 'until': current_time + 2}
            else:
                spam_data = {'count': 1, 'until': current_time + 2}
            
            with open(spam_file, 'w') as f:
                json.dump(spam_data, f)
            
            return False
        except:
            return False

    def is_banned(self, user_id: int) -> bool:
        try:
            with open(self.banlist_file, 'r') as f:
                banned_users = f.read().strip().split('\n')
            return str(user_id) in banned_users
        except:
            return False

    def add_member(self, user_id: int):
        try:
            with open(self.members_file, 'r') as f:
                members = f.read().strip().split('\n')
            if str(user_id) not in members:
                with open(self.members_file, 'a') as f:
                    f.write(f"{user_id}\n")
        except:
            pass

    def get_members_count(self) -> int:
        try:
            with open(self.members_file, 'r') as f:
                members = f.read().strip().split('\n')
            return len([m for m in members if m.strip()])
        except:
            return 0

    def get_admin_panel(self, data: dict):
        if data.get('stats') == 'on':
            buttons = [
                [{"text": "🔕 بن کردن"}, {"text": "🔔 آنبن کردن"}, {"text": "📓 لیست بن"}],
                [{"text": "🔌 خاموش کردن"}, {"text": "🪄 بهینه سازی"}],
                [{"text": "📚 راهنمای ربات"}, {"text": "📊 آمار ربات"}, {"text": "📮 پیام همگانی"}],
                [{"text": "📮 فروارد همگانی"}, {"text": "📧 پیام به کاربر"}, {"text": "📇 متن ها"}],
                [{"text": "🦉 پاسخ خودکار"}, {"text": "⌨ کیبورد"}, {"text": "🔐 قفل ها"}],
                [{"text": "🧑🏻‍🎓 ادمین ها"}, {"text": "🔍 جستجو"}],
                [{"text": "🔐 قفل کانال"}, {"text": "☎️ شماره تلفن"}, {"text": "⛔ فیلتر لیست"}],
                [{"text": "💾 بکاپ گیری"}, {"text": "♻️ ریست کردن"}, {"text": "🏛 منوی اصلی"}]
            ]
        else:
            buttons = [
                [{"text": "🔕 بن کردن"}, {"text": "🔔 آنبن کردن"}, {"text": "📓 لیست بن"}],
                [{"text": "💡 روشن کردن"}, {"text": "🪄 بهینه سازی"}],
                [{"text": "📚 راهنمای ربات"}, {"text": "📊 آمار ربات"}, {"text": "📮 پیام همگانی"}],
                [{"text": "📮 فروارد همگانی"}, {"text": "📧 پیام به کاربر"}, {"text": "📇 متن ها"}],
                [{"text": "🦉 پاسخ خودکار"}, {"text": "⌨ کیبورد"}, {"text": "🔐 قفل ها"}],
                [{"text": "🧑🏻‍🎓 ادمین ها"}, {"text": "🔍 جستجو"}],
                [{"text": "🔐 قفل کانال"}, {"text": "☎️ شماره تلفن"}, {"text": "⛔ فیلتر لیست"}],
                [{"text": "💾 بکاپ گیری"}, {"text": "♻️ ریست کردن"}, {"text": "🏛 منوی اصلی"}]
            ]
        
        return {"keyboard": buttons, "resize_keyboard": True}

    def get_user_buttons(self, data: dict):
        if not data.get('buttons'):
            return None
        
        buttons = []
        for button_text in data['buttons']:
            buttons.append([{"text": button_text}])
        
        buttons.append([{"text": "💼 پنل مدیریت", "callback_data": "panel"}])
        return {"keyboard": buttons, "resize_keyboard": True}

    def get_locks_keyboard(self, data: dict):
        locks = data.get('lock', {})
        return {
            "inline_keyboard": [
                [
                    {"text": f"فیلم : {locks.get('video', '🔑')}", "callback_data": "video"},
                    {"text": f"موزیک : {locks.get('audio', '🔑')}", "callback_data": "audio"},
                    {"text": f"ویس : {locks.get('voice', '🔑')}", "callback_data": "voice"}
                ],
                [
                    {"text": f"متن : {locks.get('text', '🔑')}", "callback_data": "text"},
                    {"text": f"استیکر : {locks.get('sticker', '🔑')}", "callback_data": "sticker"}
                ],
                [
                    {"text": f"لینک : {locks.get('link', '🔑')}", "callback_data": "link"},
                    {"text": f"عکس : {locks.get('photo', '🔑')}", "callback_data": "photo"},
                    {"text": f"فایل : {locks.get('document', '🔑')}", "callback_data": "document"}
                ],
                [
                    {"text": f"فوروارد : {locks.get('forward', '🔑')}", "callback_data": "forward"},
                    {"text": f"کانال : {locks.get('channel', '🔑')}", "callback_data": "channel"}
                ]
            ]
        }

    def broadcast_message(self, message_text: str):
        try:
            with open(self.members_file, 'r') as f:
                members = f.read().strip().split('\n')
            
            count = 0
            for member_id in members:
                if member_id.strip():
                    try:
                        self.send_message(int(member_id), message_text)
                        count += 1
                        time.sleep(0.05)
                    except:
                        continue
            return count
        except:
            return 0

    def process_update(self, update: dict):
        try:
            data = self.load_data()
            
            if 'message' in update:
                message = update['message']
                chat_id = message['chat']['id']
                user_id = message['from']['id']
                text = message.get('text', '')
                message_id = message['message_id']
                chat_type = message['chat']['type']
                
                if self.is_banned(user_id):
                    self.send_message(chat_id, "⛔ <b>شما مسدود شده‌اید!</b>")
                    return
                
                if self.check_spam(user_id):
                    self.send_message(chat_id, "🫐 <b>بدلیل اسپم ۲۰ ثانیه بلاک شدید!</b>")
                    return
                
                if chat_type == 'private':
                    self.add_member(user_id)
                    
                    if data.get('stats') == 'off' and user_id != self.dev_id:
                        self.send_message(chat_id, "⚠️ <b>ربات موقتا خاموش می‌باشد</b>")
                        return
                    
                    if data.get('channel') and data['lock'].get('channel') == '🔒':
                        member_status = self.get_chat_member(data['channel'], user_id)
                        if member_status.get('result', {}).get('status') in ['left', 'kicked']:
                            self.send_message(chat_id, f"""
🔔 <b>برای حمایت از ما و همچنین فعال شدن ربات
ابتدا در کانال زیر عضو شوید و سپس /start
را ارسال کنید!</b>

🔗 {data['channel']}
""")
                            return
                    
                    self.handle_private_message(chat_id, user_id, text, message, data)
                
                elif chat_type in ['group', 'supergroup']:
                    self.handle_group_message(chat_id, user_id, text, message, data)
            
            elif 'callback_query' in update:
                callback = update['callback_query']
                chat_id = callback['message']['chat']['id']
                user_id = callback['from']['id']
                callback_data = callback['data']
                message_id = callback['message']['message_id']
                callback_id = callback['id']
                
                self.handle_callback_query(chat_id, user_id, callback_data, message_id, callback_id, data)
        
        except Exception as e:
            print(f"Error processing update: {e}")

    def handle_private_message(self, chat_id: int, user_id: int, text: str, message: dict, data: dict):
        if text == '/start':
            start_text = data.get('text', {}).get('start') or "سلام، پیام خود را ارسال کنید:"
            user_buttons = self.get_user_buttons(data)
            self.send_message(chat_id, f"👋 <b>{start_text}</b>", user_buttons)
            return
        
        if user_id == self.dev_id:
            self.handle_admin_commands(chat_id, text, message, data)
        else:
            if data.get('quick', {}).get(text):
                response = data['quick'][text]
                user_buttons = self.get_user_buttons(data)
                self.send_message(chat_id, response, user_buttons)
                return
            
            if data.get('buttonans', {}).get(text):
                response = data['buttonans'][text]
                user_buttons = self.get_user_buttons(data)
                self.send_message(chat_id, response, user_buttons)
                return
            
            self.forward_to_support(chat_id, user_id, message, data)

    def handle_admin_commands(self, chat_id: int, text: str, message: dict, data: dict):
        if text in ['🔙 بازگشت', '💼 پنل مدیریت', '/panel', '/admin']:
            data['step'] = 'none'
            self.save_data(data)
            admin_panel = self.get_admin_panel(data)
            self.send_message(chat_id, "🎛 <b>به پنل مدیریت خوش آمدید:</b>", admin_panel)
            return
        
        if text == '📊 آمار ربات':
            member_count = self.get_members_count()
            current_time = time.strftime("%H:%M:%S")
            current_date = time.strftime("%Y/%m/%d")
            
            stats_text = f"""
📊 <b>آمار ربات:</b>

👥 <b>تعداد کاربران:</b> <code>{member_count}</code>
📅 <b>تاریخ:</b> <code>{current_date}</code>
⏰ <b>ساعت:</b> <code>{current_time}</code>
"""
            self.send_message(chat_id, stats_text)
            return
        
        if text == '🔐 قفل ها':
            locks_keyboard = self.get_locks_keyboard(data)
            self.send_message(chat_id, """
🔐 <b>وضعیت داده‌های ارسالی کاربران را بر اساس
( قفل: 🔒 | آزاد: 🔑 ) تنظیم کنید!</b>
""", locks_keyboard)
            return
        
        if text == '💡 روشن کردن':
            data['stats'] = 'on'
            self.save_data(data)
            admin_panel = self.get_admin_panel(data)
            self.send_message(chat_id, "✅ <b>ربات با موفقیت روشن شد</b>", admin_panel)
            return
        
        if text == '🔌 خاموش کردن':
            data['stats'] = 'off'
            self.save_data(data)
            admin_panel = self.get_admin_panel(data)
            self.send_message(chat_id, "☑️ <b>ربات با موفقیت خاموش شد</b>", admin_panel)
            return
        
        if text == '📮 پیام همگانی':
            data['step'] = 'broadcast'
            self.save_data(data)
            back_keyboard = {"keyboard": [[{"text": "🔙 بازگشت"}]], "resize_keyboard": True}
            self.send_message(chat_id, "📮 <b>پیام مورد نظر را ارسال کنید:</b>", back_keyboard)
            return
        
        if text == '🔕 بن کردن':
            data['step'] = 'ban_user'
            self.save_data(data)
            back_keyboard = {"keyboard": [[{"text": "🔙 بازگشت"}]], "resize_keyboard": True}
            self.send_message(chat_id, "⚠️ <b>شناسه کاربر را ارسال کنید:</b>", back_keyboard)
            return
        
        if text == '🔔 آنبن کردن':
            data['step'] = 'unban_user'
            self.save_data(data)
            back_keyboard = {"keyboard": [[{"text": "🔙 بازگشت"}]], "resize_keyboard": True}
            self.send_message(chat_id, "⚠️ <b>شناسه کاربر را ارسال کنید:</b>", back_keyboard)
            return
        
        if text == '📓 لیست بن':
            try:
                with open(self.banlist_file, 'r') as f:
                    banned_list = f.read().strip()
                if banned_list:
                    banned_users = banned_list.split('\n')
                    count = len([u for u in banned_users if u.strip()])
                    self.send_message(chat_id, f"📓 <b>تعداد {count} نفر در بلاک لیست:</b>\n\n<code>{banned_list}</code>")
                else:
                    self.send_message(chat_id, "📓 <b>لیست بن خالی است</b>")
            except:
                self.send_message(chat_id, "📓 <b>لیست بن خالی است</b>")
            return
        
        step = data.get('step', 'none')
        if step == 'broadcast' and text != '🔙 بازگشت':
            count = self.broadcast_message(text)
            data['step'] = 'none'
            self.save_data(data)
            admin_panel = self.get_admin_panel(data)
            self.send_message(chat_id, f"✅ <b>پیام به {count} کاربر ارسال شد</b>", admin_panel)
            return
        
        if step == 'ban_user' and text != '🔙 بازگشت':
            if text.isdigit():
                try:
                    with open(self.banlist_file, 'a') as f:
                        f.write(f"{text}\n")
                    data['step'] = 'none'
                    self.save_data(data)
                    admin_panel = self.get_admin_panel(data)
                    self.send_message(chat_id, f"✅ <b>کاربر {text} بن شد</b>", admin_panel)
                except:
                    self.send_message(chat_id, "❌ <b>خطا در بن کردن کاربر</b>")
            return
        
        if step == 'unban_user' and text != '🔙 بازگشت':
            if text.isdigit():
                try:
                    with open(self.banlist_file, 'r') as f:
                        banned_list = f.read()
                    new_list = banned_list.replace(f"{text}\n", "")
                    with open(self.banlist_file, 'w') as f:
                        f.write(new_list)
                    data['step'] = 'none'
                    self.save_data(data)
                    admin_panel = self.get_admin_panel(data)
                    self.send_message(chat_id, f"✅ <b>کاربر {text} از مسدودیت خارج شد</b>", admin_panel)
                except:
                    self.send_message(chat_id, "❌ <b>خطا در آنبن کردن کاربر</b>")
            return
        
        if text == '🔙 بازگشت':
            data['step'] = 'none'
            self.save_data(data)
            admin_panel = self.get_admin_panel(data)
            self.send_message(chat_id, "🎛 <b>به پنل مدیریت خوش آمدید:</b>", admin_panel)
            return

    def handle_callback_query(self, chat_id: int, user_id: int, callback_data: str, message_id: int, callback_id: str, data: dict):
        if callback_data in ['video', 'audio', 'voice', 'text', 'sticker', 'link', 'photo', 'document', 'forward', 'channel']:
            current_lock = data['lock'].get(callback_data, '🔑')
            new_lock = '🔒' if current_lock == '🔑' else '🔑'
            data['lock'][callback_data] = new_lock
            self.save_data(data)
            
            locks_keyboard = self.get_locks_keyboard(data)
            self.edit_message_text(chat_id, message_id, """
🔐 <b>وضعیت داده‌های ارسالی کاربران را بر اساس
( قفل: 🔒 | آزاد: 🔑 ) تنظیم کنید!</b>
""", locks_keyboard)
            
            lock_text = "قفل" if new_lock == '🔒' else "آزاد"
            self.answer_callback_query(callback_id, f"{callback_data} {lock_text} شد")

    def handle_group_message(self, chat_id: int, user_id: int, text: str, message: dict, data: dict):
        if text == '/setfeed' and user_id == self.dev_id:
            data['feed'] = str(chat_id)
            self.save_data(data)
            self.send_message(chat_id, "✅ <b>این گروه برای پشتیبانی تنظیم گردید</b>")

    def forward_to_support(self, chat_id: int, user_id: int, message: dict, data: dict):
        target_chat = data.get('feed') or self.dev_id
        message_id = message['message_id']
        
        self.forward_message(target_chat, chat_id, message_id)
        
        response_keyboard = {
            "inline_keyboard": [[
                {"text": "💬 پاسخ به کاربر", "callback_data": f"reply_{user_id}"},
                {"text": "بن", "callback_data": f"ban_{user_id}"}
            ]]
        }
        
        self.send_message(target_chat, f"📨 <b>پیام جدید از کاربر:</b> <code>{user_id}</code>", response_keyboard)
        
        done_text = data.get('text', {}).get('done') or "✅ درخواست ارسال شد..."
        user_buttons = self.get_user_buttons(data)
        self.send_message(chat_id, done_text, user_buttons)

    def get_updates(self, offset: int = 0):
        params = {"offset": offset, "timeout": 30}
        return self.bot_request("getUpdates", params)

    def run(self):
        print("🤖 Bot started successfully!")
        offset = 0
        
        while True:
            try:
                updates = self.get_updates(offset)
                
                if updates.get('ok') and updates.get('result'):
                    for update in updates['result']:
                        Thread(target=self.process_update, args=(update,)).start()
                        offset = update['update_id'] + 1
                
                time.sleep(1)
                
            except KeyboardInterrupt:
                print("\n🛑 Bot stopped by user")
                break
            except Exception as e:
                print(f"❌ Error in main loop: {e}")
                time.sleep(5)

if __name__ == "__main__":
    try:
        with open("config.json", "r") as f:
            config = json.load(f)
        token = config["bot_token"]
    except:
        token = input("🔑 Enter your bot token: ").strip()
        config = {"bot_token": token}
        with open("config.json", "w") as f:
            json.dump(config, f, indent=2)
    
    bot = TelegramBot(token)
    bot.run()