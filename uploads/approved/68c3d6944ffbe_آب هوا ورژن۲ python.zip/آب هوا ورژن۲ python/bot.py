import requests
import json
import logging
import re
from datetime import datetime, timedelta
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

TELEGRAM_TOKEN = "BOT_TOKEN" #توکن ربات 
CHANNEL_USERNAME = "@your_channel" #آیدی چنل 

WEATHER_DESCRIPTIONS = {
    0: "☀️ آسمان صاف",
    1: "🌤 عمدتاً صاف",
    2: "⛅️ نیمه ابری",
    3: "☁️ ابری",
    45: "🌫 مه",
    48: "🌫 مه رسانا",
    51: "🌧 نمنم باران",
    53: "🌧 باران ملایم",
    55: "🌧 باران شدید",
    56: "🌧❄️ باران یخ‌زده",
    57: "🌧❄️ باران یخ‌زده شدید",
    61: "🌧 باران ملایم",
    63: "🌧 باران",
    65: "🌧 باران شدید",
    66: "🌧❄️ باران یخ‌زده",
    67: "🌧❄️ باران یخ‌زده شدید",
    71: "❄️ بارش برف ملایم",
    73: "❄️ بارش برف",
    75: "❄️ بارش برف شدید",
    77: "❄️ دانه‌های برف",
    80: "🌧 رگبار باران ملایم",
    81: "🌧 رگبار باران",
    82: "🌧 رگبار باران شدید",
    85: "❄️ رگبار برف",
    86: "❄️ رگبار برف شدید",
    95: "⛈ رعد و برق",
    96: "⛈ رعد و برق با بارش تگرگ",
    99: "⛈ رعد و برق با بارش تگرگ شدید"
}

def get_coordinates_from_city(city_name):
    try:
        url = f"https://nominatim.openstreetmap.org/search?format=json&q={city_name}&limit=1"
        headers = {'User-Agent': 'WeatherBot/1.0'}
        
        response = requests.get(url, headers=headers)
        data = response.json()
        
        if data:
            latitude = float(data[0]['lat'])
            longitude = float(data[0]['lon'])
            display_name = data[0]['display_name']
            return latitude, longitude, display_name
        return None, None, None
    except Exception as e:
        logger.error(f"Error getting coordinates: {e}")
        return None, None, None

def get_weather_forecast(latitude, longitude, days=3):
    try:
        url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&daily=weathercode,temperature_2m_max,temperature_2m_min,windspeed_10m_max,winddirection_10m_dominant&timezone=auto&forecast_days={days}"
        
        response = requests.get(url)
        data = response.json()
        
        if 'daily' in data:
            forecast = []
            for i in range(len(data['daily']['time'])):
                day_forecast = {
                    'date': data['daily']['time'][i],
                    'temp_max': data['daily']['temperature_2m_max'][i],
                    'temp_min': data['daily']['temperature_2m_min'][i],
                    'windspeed': data['daily']['windspeed_10m_max'][i],
                    'winddirection': data['daily']['winddirection_10m_dominant'][i],
                    'weathercode': data['daily']['weathercode'][i]
                }
                forecast.append(day_forecast)
            return forecast
        return None
    except Exception as e:
        logger.error(f"Error getting forecast: {e}")
        return None

def get_current_weather(latitude, longitude):
    try:
        url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true&hourly=temperature_2m,relativehumidity_2m"
        
        response = requests.get(url)
        data = response.json()
        
        if 'current_weather' in data:
            weather = data['current_weather']
            return weather
        return None
    except Exception as e:
        logger.error(f"Error getting current weather: {e}")
        return None

async def check_membership(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = update.effective_user.id
        member = await context.bot.get_chat_member(CHANNEL_USERNAME, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Membership check error: {e}")
        return False

async def send_membership_required(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📢 عضویت در کانال", url=f"https://t.me/{CHANNEL_USERNAME[1:]}")],
        [InlineKeyboardButton("✅ بررسی عضویت", callback_data="check_membership")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "👋 برای استفاده از ربات، لطفاً در کانال ما عضو شوید:\n\n"
        f"{CHANNEL_USERNAME}\n\n"
        "پس از عضویت، روی دکمه 'بررسی عضویت' کلیک کنید.",
        reply_markup=reply_markup
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_membership(update, context):
        await send_membership_required(update, context)
        return
    
    keyboard = [
        ['🌤 آب و هوای فعلی', '📅 پیش‌بینی 3 روزه'],
        ['📍 ارسال موقعیت', '🔍 جستجوی شهر'],
        ['🗺 لینک گوگل مپ', 'ℹ️ راهنما']
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    await update.message.reply_text(
        "🌤 به ربات پیشرفته آب و هوا خوش آمدید!\n\n"
        "🔹 می‌توانید:\n"
        "• آب و هوای فعلی را دریافت کنید\n"
        "• پیش‌بینی 3 روزه را ببینید\n"
        "• موقعیت خود را ارسال کنید\n"
        "• نام شهر را جستجو کنید\n"
        "• لینک گوگل مپ دریافت کنید\n\n"
        "لطفاً یک گزینه را انتخاب کنید:",
        reply_markup=reply_markup
    )

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "check_membership":
        if await check_membership(update, context):
            await query.edit_message_text("✅ عضویت شما تأیید شد! لطفاً از /start استفاده کنید.")
        else:
            await query.edit_message_text("❌ هنوز در کانال عضو نشده‌اید. لطفاً ابتدا عضو شوید.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_membership(update, context):
        await send_membership_required(update, context)
        return
    
    text = update.message.text
    
    if text == '🌤 آب و هوای فعلی':
        await update.message.reply_text(
            "📍 لطفاً موقعیت خود را ارسال کنید یا نام شهر را بنویسید:",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        context.user_data['awaiting_city'] = 'current'
        
    elif text == '📅 پیش‌بینی 3 روزه':
        await update.message.reply_text(
            "📍 لطفاً موقعیت خود را ارسال کنید یا نام شهر را بنویسید:",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        context.user_data['awaiting_city'] = 'forecast'
        
    elif text == '📍 ارسال موقعیت':
        await update.message.reply_text(
            "📍 لطفاً موقعیت خود را از طریق گزینه اشتراک‌گذاری موقعیت ارسال کنید:",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        
    elif text == '🔍 جستجوی شهر':
        await update.message.reply_text(
            "🏙 لطفاً نام شهر مورد نظر خود را وارد کنید:",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        context.user_data['awaiting_city'] = 'search'
        
    elif text == '🗺 لینک گوگل مپ':
        await update.message.reply_text(
            "📍 لطفاً موقعیت خود را ارسال کنید یا نام شهر را بنویسید:",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        context.user_data['awaiting_city'] = 'map'
        
    elif text == 'ℹ️ راهنما':
        await update.message.reply_text(
            "📖 راهنمای ربات آب و هوا:\n\n"
            "🔹 آب و هوای فعلی: اطلاعات لحظه‌ای آب و هوا\n"
            "🔹 پیش‌بینی 3 روزه: پیش‌بینی آب و هوا برای 3 روز آینده\n"
            "🔹 ارسال موقعیت: ارسال موقعیت مکانی شما\n"
            "🔹 جستجوی شهر: جستجو بر اساس نام شهر\n"
            "🔹 لینک گوگل مپ: دریافت لینک موقعیت در گوگل مپ\n\n"
            "شما می‌توانید مستقیماً نام هر شهری را نیز ارسال کنید.",
            reply_markup=ReplyKeyboardMarkup([['🔙 بازگشت']], resize_keyboard=True)
        )
        
    elif text == '🔙 بازگشت':
        keyboard = [
            ['🌤 آب و هوای فعلی', '📅 پیش‌بینی 3 روزه'],
            ['📍 ارسال موقعیت', '🔍 جستجوی شهر'],
            ['🗺 لینک گوگل مپ', 'ℹ️ راهنما']
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("منوی اصلی:", reply_markup=reply_markup)
        
    else:
        if 'awaiting_city' in context.user_data:
            action = context.user_data['awaiting_city']
            latitude, longitude, display_name = get_coordinates_from_city(text)
            
            if latitude and longitude:
                await process_location(update, context, latitude, longitude, display_name, action)
            else:
                await update.message.reply_text("❌ شهر مورد نظر یافت نشد. لطفاً نام دیگری امتحان کنید.")
        else:
            latitude, longitude, display_name = get_coordinates_from_city(text)
            
            if latitude and longitude:
                await process_location(update, context, latitude, longitude, display_name, 'current')
            else:
                await update.message.reply_text("❌ شهر مورد نظر یافت نشد. لطفاً از منو استفاده کنید.")

async def handle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_membership(update, context):
        await send_membership_required(update, context)
        return
    
    latitude = update.message.location.latitude
    longitude = update.message.location.longitude
    
    action = context.user_data.get('awaiting_city', 'current')
    await process_location(update, context, latitude, longitude, "موقعیت شما", action)

async def process_location(update: Update, context: ContextTypes.DEFAULT_TYPE, latitude, longitude, location_name, action):
    try:
        if action == 'current':
            weather = get_current_weather(latitude, longitude)
            if weather:
                description = WEATHER_DESCRIPTIONS.get(weather['weathercode'], "نامشخص")
                
                message = (
                    f"🌤 آب و هوای {location_name}:\n\n"
                    f"🌡 دمای فعلی: {weather['temperature']}°C\n"
                    f"💨 سرعت باد: {weather['windspeed']} km/h\n"
                    f"🧭 جهت باد: {weather['winddirection']}°\n"
                    f"📊 وضعیت: {description}\n\n"
                    f"📍 مختصات: {latitude:.4f}, {longitude:.4f}"
                )
                
                map_url = f"https://www.google.com/maps?q={latitude},{longitude}"
                keyboard = [[InlineKeyboardButton("🗺 مشاهده در گوگل مپ", url=map_url)]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.message.reply_text(message, reply_markup=reply_markup)
            else:
                await update.message.reply_text("❌ خطا در دریافت اطلاعات آب و هوا.")
                
        elif action == 'forecast':
            forecast = get_weather_forecast(latitude, longitude, 3)
            if forecast:
                message = f"📅 پیش‌بینی 3 روزه برای {location_name}:\n\n"
                
                for day in forecast:
                    date_obj = datetime.strptime(day['date'], '%Y-%m-%d')
                    persian_date = date_obj.strftime('%d %B')
                    description = WEATHER_DESCRIPTIONS.get(day['weathercode'], "نامشخص")
                    
                    message += (
                        f"📅 {persian_date}:\n"
                        f"🌡 دمای بیشینه: {day['temp_max']}°C\n"
                        f"🌡 دمای کمینه: {day['temp_min']}°C\n"
                        f"💨 باد: {day['windspeed']} km/h\n"
                        f"📊 وضعیت: {description}\n\n"
                    )
                
                await update.message.reply_text(message)
            else:
                await update.message.reply_text("❌ خطا در دریافت پیش‌بینی آب و هوا.")
                
        elif action == 'map':
            map_url = f"https://www.google.com/maps?q={latitude},{longitude}"
            keyboard = [[InlineKeyboardButton("🗺 مشاهده در گوگل مپ", url=map_url)]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                f"📍 لینک موقعیت {location_name} در گوگل مپ:",
                reply_markup=reply_markup
            )
            
    except Exception as e:
        logger.error(f"Error processing location: {e}")
        await update.message.reply_text("❌ خطا در پردازش اطلاعات.")

def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    application.add_handler(MessageHandler(filters.LOCATION, handle_location))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    application.run_polling()
    logger.info("ربات در حال اجراست...")

if __name__ == "__main__":
    main()