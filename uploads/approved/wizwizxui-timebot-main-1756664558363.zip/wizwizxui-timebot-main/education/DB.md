
- وارد هاست سی پنل وب سایتمون میشیم، سپس از قسمت databases بر روی آیکون mysql databases کلیک می کنیم


<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789211-c476a648-1d82-487c-b1ef-d7af583fd8c6.jpg" />
    </a>
</p>


<br>
<br>


- اینجا از قسمت create new database باید یه دیتابیس جدید برای خودمون بسازیم، و تو قسمت new database تو این فیلد باید نام دیتابیس مورد نظرمون رو وارد کنیم، ما مینویسیم test و حالا برای ایجاد این دیتابیس بر روی دکمه آبی رنگ create database کلیک می کنیم



<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789283-a77afe2d-b6c2-42a7-84a1-d0c2305479b0.jpg" />
    </a>
</p>


<br>
<br>


- تا پیغام سبز رنگ aaed the database رو مشاهده کنیم، مشاهده این پیغام به این معناست که دیتابیس ما با موفقیت ایجاد شده، حالا بر روی دکمه go back  کلیک می کنیم



<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789302-6fc10858-2c58-4e36-99b5-7c3a3b1532ec.jpg" />
    </a>
</p>


<br>
<br>


- اینجا قسمتی که نوشته شده add new user داخل فیلد username نام کاربری این یوزر از دیتابیسمون رو به صورت دلخواه وارد می کنیم، ما تو اینجا باز هم مینیوسیم test اما این به این معنا نیست که نام کاربری دیتابیس باید با نام خود دیتابیس که تو مرحله قبلی ایجادش کردم حتما مثل هم باشن و میتونید یک اسم دلخواه نیز انتخاب کنید و تو فیلد های password و password again باید یه رمزعبور مطمئن به صورت دلخواه برای این یوزر از دیتابیسمون وارد کنیم



<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789313-225e3c2e-e9b9-41d9-aa45-5e6e8ac2d151.jpg" />
    </a>
</p>



- تا پیغام سبز رنگ You have successfully created a MySQL user named رو مشاهده کنیم و حالا بر روی دکمه go back کلیک می کنیم تا مجددا وارد صفحه اصلی تنظیمات دیتابیس هاستمون بشیم

<br>
<br>



- تو مرحله نهایی ما باید دیتابیس ساخته شده رو به یوزر یا همون کاربر دیتابیس ساخته شده که الان ایجادش کردیم متصل کنیم، تا ارتباط بین نام دیتابیس و نام کاربری دیتابیس به خوبی برقرار بشه، برای انجام این کار اسکرول رو به پایین میکشیم تا برسیم به قسمت Add User To Database و از این قسمت یوزر دیتابیسمون رو انتخاب می کنیم و از اینجا هم دیتابیسمون که تو مرحله اول ایجادش کردیم رو انتخاب می کنیم، سپس بر روی دکمه آبی رنگ add از اینجا کلیک می کنیم


<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789343-f35da7de-4930-4b28-952d-a0d3213870bd.jpg" />
    </a>
</p>


<br>
<br>

- وارد صفحه Manage User Privileges بشیم و تو این صفحه باید سطح دسترسی های دیتابیسمون رو کامل کنیم اما اولش دقت می کنیم که از مقابل قسمت user و database دقیقا کاربر مورد نظر و دیتابیس مورد نظر وارد شده باشه و حالا از اینجا گزینه all privileges رو تیک دار می کنیم تا تموم این سطح دسترسی ها انتخاب بشن و حالا برای نهایی سازی این تنظیمات بر روی دکمه آبی رنگ make changes کلیک می کنیم


<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228789349-4d4079fc-f550-40ed-8a32-0979ead172ab.jpg" />
    </a>
</p>

<br>
<br>

- پیغام سبز رنگ You have given the requested privileges on the database to the user رو مشاهده کنیم


<p align="center">
    <a>
        <img src="https://user-images.githubusercontent.com/27927279/228792953-408ddf7e-6bf3-4957-a7d1-dad6c40010b5.jpg" />
    </a>
</p>

<br>
<br>
