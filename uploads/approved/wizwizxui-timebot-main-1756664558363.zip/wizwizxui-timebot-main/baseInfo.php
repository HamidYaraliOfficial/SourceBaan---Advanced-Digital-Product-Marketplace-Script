<?php 
	error_reporting(0);
	$botToken = '[BOTTOKEN]';
	$dbUserName = '[DBUSERNAME]';
	$dbPassword = '[DBPASSWORD]';
	$dbName = '[DBNAME]';
	$admin = [ADMIN];
	$channelLock = "[CHANNELLOCK]";
	$botUrl = "[BOTURL]";
	$walletwizwiz = "[WALLET]";
	$pursantPercent = [PURSANT];
    $nowPaymentKey = "[NOWPAYMENTKEY]";
    $zarinpalId = "[ZARINPALKEY]";
?>