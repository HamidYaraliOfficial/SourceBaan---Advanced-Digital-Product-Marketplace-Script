<?php
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/
error_reporting(0);
//========================== // token // ==============================
define('API_KEY', 'Token'); // توکن ربات
define('API_URL', 'https://api.telegram.org/bot' . API_KEY . '/');
//========================== // config // ==============================
$admin    = "Admin"; // آیدی عددی ادمین ها

$channel  = "Chnl"; // آیدی کانال بدون @
$usernamebot  = "Bot"; // آیدی ربات

$web = "https://telegram.server.com/Chat"; // محل قرارگیری سورس

$botname = "چت ناشناس";
$channellog = "-1000000";

$support = "Sup";

$MerchantID = "Merch"; // مرچند کد زرین پال

$hadaddfuns = "1000"; // حداقل شارژ حساب
$maxaddfuns = "10000"; // حداکثر شارژ حساب

$token_amount = "100000"; // به ازای هر حرف چقدر قیمتش بیشتر شه
$start_token = "7"; // از ۷ حرف به بعد مجانیه
//========================== // database // ==============================
$dbuser = "Db"; // یوزر دیتابیس
$dbpass = "Db"; // رمز دیتابیس
$dbname = "Db"; // نام دیتابیس
$connect = new mysqli('localhost', $dbuser, $dbpass, $dbname);
$connect->query("SET NAMES 'utf8'");
$connect->set_charset('utf8mb4');
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/