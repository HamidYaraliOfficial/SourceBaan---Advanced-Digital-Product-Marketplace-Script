<?php
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/
ob_start();
include '../../config.php';
include('../../lib/jdf.php');

$Amount = $_GET['amount'];
$from_id = $_GET['user_id'];

if (isset($_GET['amount']) && isset($_GET['user_id'])) {

  if ($Amount >= $hadaddfuns && $Amount <= $maxaddfuns) {

    $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
    $result = $client->PaymentRequest([
      'MerchantID' => $MerchantID,
      'Amount' => $Amount,
      'Description' => "ربات $botname | قیمت $Amount تومان | کاربر $from_id",
      'Email' => 'mail',
      'Mobile' => 'mob',
      'CallbackURL' => "$web/pay/zarinpal/back.php/?id=" . $from_id . "&amount=" . $Amount
    ]);

    if ($result->Status == 100) {
      header("Location: https://www.zarinpal.com/pg/StartPay/" . $result->Authority . "/ZarinGate");
    } else {
      header("Location: $web/pay/error.php");
    }
  } else {
    echo ('مبلغ وارد شده نامعتبر است.');
    exit;
  }
} else {
  echo ('مشخصات کافی نیست.');
  exit;
}
