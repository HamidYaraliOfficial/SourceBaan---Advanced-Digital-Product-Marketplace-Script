<!DOCTYPE HTML>
<html lang="en">

<head>
  <title>چت ناشناس | Anonymous Chat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://microseen.otpserver.net/view/res/css/style.css?v=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body>
  <div class="container">
    <br>
    <div class="alert alert-danger">
      <div class="card border-danger mb-12">
        <div class="card-header bg-transparent border-danger text-danger">چت ناشناس</div>
        <div class="card-body">
          <p class="card-text">خطا، مشکلی در ایجاد صفحه پرداخت به وجود آمد. لطفا مجدد اقدام به افزایش موجودی کنید.</p>
        </div>
      </div>
    </div>
  </div>
</body>

</html>