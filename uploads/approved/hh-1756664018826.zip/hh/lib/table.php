<?php
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/
include '../config.php';
//==========================// table creator //==========================//
#-- User --#
mysqli_multi_query($connect, "CREATE TABLE `user` (
  `id` BIGINT(32) PRIMARY KEY,
  `amount` float DEFAULT '0',
  `step` VARCHAR(50) DEFAULT NULL,
  `data` TEXT DEFAULT NULL,
  `link` TEXT DEFAULT NULL,
  `name` TEXT DEFAULT NULL,
  `username` TEXT DEFAULT NULL,
  `silent` TEXT DEFAULT 'false',
  `copy` TEXT DEFAULT 'false',
  `create_at` BIGINT DEFAULT NULL,
  `update_at` BIGINT DEFAULT NULL
  ) default charset = utf8mb4;");
#-- Links --#
mysqli_multi_query($connect, "CREATE TABLE `links` (
  `id` BIGINT(32) NOT NULL,
  `link` TEXT NOT NULL,
  `create_at` BIGINT NOT NULL
  ) default charset = utf8mb4;");
#-- Messages --#
mysqli_multi_query($connect, "CREATE TABLE `messages` (
  `id` BIGINT(32) AUTO_INCREMENT PRIMARY KEY,
  `from` BIGINT(32) NOT NULL,
  `to` BIGINT(32) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment` TEXT DEFAULT NULL,
  `attachment_type` TEXT DEFAULT NULL,
  `status` TEXT DEFAULT 'unseen',
  `message_id` TEXT DEFAULT NULL,
  `reply_message` TEXT DEFAULT NULL,
  `time` varchar(155) NOT NULL,
  `date` varchar(155) NOT NULL
  ) default charset = utf8mb4;");
#-- Buy --#
mysqli_multi_query($connect, "CREATE TABLE `buy` (
  `key` BIGINT(32) AUTO_INCREMENT PRIMARY KEY,
  `id` BIGINT(32) NOT NULL,
  `amount` BIGINT(32) NOT NULL,
  `ip` TEXT DEFAULT NULL,
  `time` varchar(155) NOT NULL,
  `date` varchar(155) NOT NULL
  ) default charset = utf8mb4;");
#-- Channels --#
mysqli_multi_query($connect, "CREATE TABLE `channels` (
  `idoruser` varchar(30) PRIMARY KEY,
  `link` varchar(200) NOT NULL
  ) default charset = utf8mb4;");
#-- Admins --#
mysqli_multi_query($connect, "CREATE TABLE `admin` (
  `admin` bigint(40) PRIMARY KEY
  ) default charset = utf8mb4;
  INSERT INTO `admin` (`admin`) VALUES ('$admin')");
#-- Block List --#
mysqli_multi_query($connect, "CREATE TABLE `block` (
  `id` BIGINT(32) NOT NULL
  ) default charset = utf8mb4;");
#-- User Block List --#
mysqli_multi_query($connect, "CREATE TABLE `block_user` (
  `from` BIGINT(32) NOT NULL,
  `to` BIGINT(32) NOT NULL
  ) default charset = utf8mb4;");
#-- User Block List --#
mysqli_multi_query($connect, "CREATE TABLE `settings` (
  `main_menu` TEXT DEFAULT 'on',
  `favorite_user` TEXT DEFAULT 'on',
  `help_support` TEXT DEFAULT 'on',
  `charge_account` TEXT DEFAULT 'on',
  `favorite_link` TEXT DEFAULT 'on'
  ) default charset = utf8mb4;
  INSERT INTO `settings` () VALUES ();");
#-- Send All --#
mysqli_multi_query($connect, "CREATE TABLE `sendall` (
  `step` VARCHAR(20) DEFAULT NULL,
  `admin` BIGINT(32) DEFAULT NULL,
  `messageid` BIGINT(32) DEFAULT NULL,
	`text` TEXT DEFAULT NULL,
	`chat` VARCHAR(100) DEFAULT NULL,
	`sended` BIGINT(32) DEFAULT '0'
  ) default charset = utf8mb4;
  INSERT INTO `sendall` () VALUES ();");
//========================== // Check connection // ==============================
if ($connect->connect_error) {
  die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
echo "دیتابیس متصل و نصب شد .";
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/