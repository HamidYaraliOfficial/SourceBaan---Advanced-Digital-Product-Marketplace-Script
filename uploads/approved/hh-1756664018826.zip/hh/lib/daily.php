<?php
/*
********** MalBo.ir - مالبو تیم *********

coded By Mahdi HajiAbadi 

******* https://t.me/MalBo_Dev *******
*/
//======================// START //======================//
include '../bot.php';
include '../config.php';
//=======================//  //=======================//
$send = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendall` LIMIT 1"));
//=======================// Function //=======================//
function Takhmin2($fil)
{
  if ($fil <= 100) {
    return "1";
  } else {
    $besanie = $fil / 100;
    return ceil($besanie) + 1;
  }
}
//======================// send //======================//
if ($send['step'] == 'send') {
  $alluser = mysqli_num_rows(mysqli_query($connect, "select id from `user`"));
  $users = mysqli_query($connect, "SELECT id FROM `user` LIMIT 100 OFFSET {$send['sended']}");
  if ($send['chat'] == false) {
    while ($row = mysqli_fetch_assoc($users))
      bot('sendmessage', [
        'chat_id' => $row['id'],
        'text' => $send['text'],
      ]);
  } else {
    while ($row = mysqli_fetch_assoc($users))
      bot('sendphoto', [
        'chat_id' => $row['id'],
        'photo' => $send['chat'],
        'caption' => $send['text'],
      ]);
  }
  $connect->query("UPDATE `sendall` SET `sended` = `sended` + 100 LIMIT 1");
  $send = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendall` LIMIT 1"));
  $tddd = $send['sended'];
  $tfrigh = $alluser - $send['sended'];
  $min = Takhmin2($tfrigh);
  bot('editMessageReplyMarkup', [
    'chat_id' => $send['admin'],
    'message_id' => $send['messageid'],
    'reply_markup' => json_encode([
      'inline_keyboard' => [
        [['text' => "🔹 تعداد افراد ارسال شده : $tddd", 'callback_data' => "none"]],
        [['text' => "🚀 زمان تخمینی ارسال : $min دقیقه (باقیمانده)", 'callback_data' => "none"]],
      ]
    ])
  ]);

  if ($send['sended'] + 100 >= $alluser) {
    bot('sendMessage', [
      'chat_id' => $admin[0],
      'text' => "✅ عملیات همگانی پایان یافت !",
      'parse_mode' => "HTML",
    ]);
    bot('editMessageReplyMarkup', [
      'chat_id' => $send['admin'],
      'message_id' => $send['messageid'],
      'reply_markup' => json_encode([
        'inline_keyboard' => [
          [['text' => "✅ همگانی پایان یافت .", 'callback_data' => "none"]],
        ]
      ])
    ]);
    $connect->query("UPDATE `sendall` SET `step` = 'none' , `admin` = null , `messageid` = null , `text` = '' , `sended` = '0' , `chat` = '' LIMIT 1");
  }
}
//======================// forward //======================//
if ($send['step'] == 'forward') {
  $alluser = mysqli_num_rows(mysqli_query($connect, "select id from `user`"));
  $users = mysqli_query($connect, "SELECT id FROM `user` LIMIT 100 OFFSET {$send['sended']}");
  while ($row = mysqli_fetch_assoc($users))
    bot('ForwardMessage', [
      'chat_id' => $row['id'],
      'from_chat_id' => $send['chat'],
      'message_id' => $send['text'],
    ]);
  $connect->query("UPDATE `sendall` SET `sended` = `sended` + 100 LIMIT 1");
  $send = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendall` LIMIT 1"));
  $tddd = $send['sended'];
  $tfrigh = $alluser - $send['sended'];
  $min = Takhmin2($tfrigh);
  bot('editMessageReplyMarkup', [
    'chat_id' => $send['admin'],
    'message_id' => $send['messageid'],
    'reply_markup' => json_encode([
      'inline_keyboard' => [
        [['text' => "🔹 تعداد افراد ارسال شده : $tddd", 'callback_data' => "none"]],
        [['text' => "🚀 زمان تخمینی ارسال : $min دقیقه (باقیمانده)", 'callback_data' => "none"]],
      ]
    ])
  ]);
  if ($send['sended'] + 100 >= $alluser) {
    bot('sendMessage', [
      'chat_id' => $admin[0],
      'text' => "✅ عملیات همگانی پایان یافت !",
      'parse_mode' => "HTML",
    ]);
    bot('editMessageReplyMarkup', [
      'chat_id' => $send['admin'],
      'message_id' => $send['messageid'],
      'reply_markup' => json_encode([
        'inline_keyboard' => [
          [['text' => "✅ همگانی پایان یافت .", 'callback_data' => "none"]],
        ]
      ])
    ]);
    $connect->query("UPDATE `sendall` SET `step` = 'none' , `admin` = null , `messageid` = null , `text` = '' , `sended` = '0' , `chat` = '' LIMIT 1");
  }
}
//======================// Delete Link //======================//
$result = mysqli_query($connect, "SELECT * FROM `links` LIMIT 100");

$hours = 24;
$timeDifferenceInSeconds = $hours * 60 * 60;

while ($row = mysqli_fetch_assoc($result)) {
  $createdAt = $row['create_at'];
  $currentTime = time();
  $timeDifference = $currentTime - $createdAt;

  if ($timeDifference >= $timeDifferenceInSeconds) {
    mysqli_query($connect, "DELETE FROM `links` WHERE `id` = " . $row['id']);
  }
}
//======================// End //======================//
