import logging
import sqlite3
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, CallbackContext, filters

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

SELECT_CHANNEL, CONFIRMATION = range(2)

BOT_TOKEN = "BOT_TOKEN"#توکن ربات 
ADMIN_ID = 123456789  #آیدی عددی 

def init_database():
    conn = sqlite3.connect("channels.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS channels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel_id INTEGER,
        channel_name TEXT,
        added_date TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS left_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        channel_id INTEGER,
        left_date TIMESTAMP)""")
    conn.commit()
    conn.close()

def add_channel(channel_id, channel_name):
    conn = sqlite3.connect("channels.db")
    c = conn.cursor()
    c.execute("INSERT INTO channels (channel_id, channel_name, added_date) VALUES (?, ?, ?)", (channel_id, channel_name, datetime.now()))
    conn.commit()
    conn.close()

def get_all_channels():
    conn = sqlite3.connect("channels.db")
    c = conn.cursor()
    c.execute("SELECT channel_id, channel_name FROM channels")
    data = c.fetchall()
    conn.close()
    return data

def add_left_user(user_id, username, first_name, last_name, channel_id):
    conn = sqlite3.connect("channels.db")
    c = conn.cursor()
    c.execute("INSERT INTO left_users (user_id, username, first_name, last_name, channel_id, left_date) VALUES (?, ?, ?, ?, ?, ?)", (user_id, username or "", first_name or "", last_name or "", channel_id, datetime.now()))
    conn.commit()
    conn.close()

def get_left_users(channel_id):
    conn = sqlite3.connect("channels.db")
    c = conn.cursor()
    c.execute("SELECT * FROM left_users WHERE channel_id = ? ORDER BY left_date DESC", (channel_id,))
    users = c.fetchall()
    conn.close()
    return users

async def start(update: Update, context: CallbackContext):
    user = update.effective_user
    text = f"👋 سلام {user.first_name}!\n\n🤖 به ربات مانیتورینگ خوش اومدی.\n\n📊 دستورات:\n/check_left\n/add_channel\n/list_channels\n/stats"
    keyboard = [[KeyboardButton("/check_left"), KeyboardButton("/list_channels")],[KeyboardButton("/add_channel"), KeyboardButton("/stats")]]
    markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(text, reply_markup=markup)

async def check_left_start(update: Update, context: CallbackContext):
    channels = get_all_channels()
    if not channels:
        await update.message.reply_text("❌ هیچ کانالی ثبت نشده.")
        return ConversationHandler.END
    buttons = [[InlineKeyboardButton(name, callback_data=f"check_{cid}")] for cid, name in channels]
    buttons.append([InlineKeyboardButton("❌ انصراف", callback_data="cancel")])
    await update.message.reply_text("📋 یکی از کانال‌ها رو انتخاب کن:", reply_markup=InlineKeyboardMarkup(buttons))
    return SELECT_CHANNEL

async def handle_channel_selection(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    if query.data == "cancel":
        await query.edit_message_text("❌ عملیات لغو شد.")
        return ConversationHandler.END
    if query.data.startswith("check_"):
        channel_id = int(query.data.split("_")[1])
        context.user_data["selected_channel"] = channel_id
        channels = get_all_channels()
        channel_name = next((n for cid, n in channels if cid == channel_id), "نامشخص")
        left_users = get_left_users(channel_id)
        if not left_users:
            await query.edit_message_text(f"✅ در کانال {channel_name} کسی لفت نداده.")
        else:
            msg = f"📊 کاربران لفت داده از {channel_name}:\n\n"
            for u in left_users[-10:]:
                _, uid, uname, fname, lname, _, date = u
                msg += f"👤 {fname} {lname or ''}"
                if uname:
                    msg += f" (@{uname})"
                msg += f"\n🆔 {uid}\n⏰ {date}\n{'─'*30}\n"
            msg += f"\n📈 مجموع: {len(left_users)}"
            await query.edit_message_text(msg)
        return ConversationHandler.END

async def add_channel_command(update: Update, context: Update):
    if len(context.args) < 2:
        await update.message.reply_text("❌ فرمت دستور:\n/add_channel channel_id channel_name")
        return
    try:
        channel_id = int(context.args[0])
        channel_name = " ".join(context.args[1:])
        add_channel(channel_id, channel_name)
        await update.message.reply_text(f"✅ کانال {channel_name} اضافه شد.")
    except ValueError:
        await update.message.reply_text("❌ channel_id باید عدد باشه.")

async def list_channels(update: Update, context: CallbackContext):
    channels = get_all_channels()
    if not channels:
        await update.message.reply_text("❌ هیچ کانالی ثبت نشده.")
        return
    msg = "📋 کانال‌ها:\n\n"
    for cid, name in channels:
        count = len(get_left_users(cid))
        msg += f"📢 {name}\n🆔 {cid}\n📊 لفت: {count}\n{'─'*30}\n"
    await update.message.reply_text(msg)

async def stats(update: Update, context: CallbackContext):
    channels = get_all_channels()
    total = 0
    msg = "📊 آمار:\n\n"
    for cid, name in channels:
        count = len(get_left_users(cid))
        total += count
        msg += f"📢 {name}: {count}\n"
    msg += f"\n📈 مجموع: {total}\n📋 تعداد کانال‌ها: {len(channels)}"
    await update.message.reply_text(msg)

async def track_left_members(update: Update, context: CallbackContext):
    try:
        if update.my_chat_member:
            cm = update.my_chat_member
            old = cm.old_chat_member.status
            new = cm.new_chat_member.status
            if old in ["member","administrator","creator"] and new in ["left","kicked"]:
                user = cm.from_user
                chat = cm.chat
                ids = [cid for cid, _ in get_all_channels()]
                if chat.id in ids:
                    add_left_user(user.id, user.username, user.first_name, user.last_name, chat.id)
                    msg = f"🚨 کاربر لفت داد!\n\n👤 {user.full_name}\n📛 یوزرنیم: @{user.username if user.username else 'ندارد'}\n🆔 {user.id}\n\n📢 {chat.title}\n🆔 {chat.id}\n⏰ {datetime.now()}"
                    await context.bot.send_message(chat_id=ADMIN_ID, text=msg)
    except Exception as e:
        logger.error(f"Error in track_left_members: {e}")

async def cancel(update: Update, context: CallbackContext):
    await update.message.reply_text("❌ عملیات لغو شد.")
    return ConversationHandler.END

def main():
    init_database()
    app = Application.builder().token(BOT_TOKEN).build()
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("check_left", check_left_start)],
        states={SELECT_CHANNEL: [CallbackQueryHandler(handle_channel_selection)]},
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("add_channel", add_channel_command))
    app.add_handler(CommandHandler("list_channels", list_channels))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(MessageHandler(filters.StatusUpdate.ALL, track_left_members))
    print("🤖 ربات فعال شد!")
    app.run_polling()

if __name__ == "__main__":
    main()