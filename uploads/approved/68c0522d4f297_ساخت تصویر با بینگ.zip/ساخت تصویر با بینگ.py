import asyncio
import logging
import os
from io import BytesIO
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from BingImageCreator import ImageGen  # Import wrapper

# تنظیم لاگینگ
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# توکن ربات تلگرام (از BotFather بگیرید)
TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'  # جایگزین کنید

# کوکی Bing (از مرورگر استخراج کنید)
BING_COOKIE_U = os.getenv('BING_COOKIE_U', 'YOUR_BING_COOKIE_U_HERE')  # از env استفاده کنید برای امنیت

# تابع شروع ربات
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text('سلام! پرامپت تصویر را ارسال کنید (مثال: "یک گربه ناز در فضا").')

# تابع تولید تصویر
async def generate_image(prompt: str):
    try:
        # ایجاد شیء ImageGen با کوکی
        image_generator = ImageGen(BING_COOKIE_U, "", all_cookies=None)  # all_cookies=None اگر فقط _U دارید
        
        # تولید تصاویر (۴ تا برمی‌گرداند)
        images = image_generator.get_images(prompt)
        
        # دانلود اولین تصویر (می‌توانید همه را دانلود کنید)
        response = requests.get(images[0])
        if response.status_code == 200:
            return BytesIO(response.content)
        else:
            return None
    except Exception as e:
        logger.error(f"خطا در تولید تصویر: {e}")
        return None
    finally:
        image_generator.close()  # بستن سشن

# هندلر پیام متنی (پرامپت)
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    prompt = update.message.text
    await update.message.reply_text('در حال تولید تصویر... لطفاً صبر کنید.')
    
    image_bytes = await generate_image(prompt)
    if image_bytes:
        await update.message.reply_photo(photo=image_bytes, caption=f'تصویر تولید شده برای: {prompt}')
    else:
        await update.message.reply_text('خطا در تولید تصویر. کوکی‌ها را چک کنید یا بعداً امتحان کنید.')

def main() -> None:
    # ایجاد اپلیکیشن
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    # هندلرها
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # شروع ربات
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()