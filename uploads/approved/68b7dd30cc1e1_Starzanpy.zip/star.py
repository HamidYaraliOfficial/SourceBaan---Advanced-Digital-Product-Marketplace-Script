import re
import os
import time
import json
from pyrogram.enums import ParseMode
import random
import string
import asyncio
from pyrogram.types import CallbackQuery
from pyrogram import Client, filters, idle
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.raw.core import TLObject
from pyrogram.raw.core.primitives import Int, Long, Bool
from pyrogram.raw.base import InputPeer
import pytz
from datetime import datetime
# ---------------------------------------#
bot_active = True 
SUPPORT_MESSAGES = {} 
GROUP_COMPETITIONS = {} 
GROUP_COMPETITION_DATA_FILE = "group_competitions.json"
ADMINS = [00000, 00000]
FORCE_JOIN_CHANNELS = ["ایدی", "ایدی"] # ایدی چنل یا گروه بدون @
DATA_FILE = "users_data.json"
MINIMUM_POINTS_FOR_ORDER = 40
POINTS_PER_ORDER = 40 

user_verification_data = {}
# ---------------------------------------#
def load_group_competitions():
    try:
        if os.path.exists(GROUP_COMPETITION_DATA_FILE):
            with open(GROUP_COMPETITION_DATA_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading group competitions: {e}")
    return {}

def save_group_competitions(data):
    try:
        with open(GROUP_COMPETITION_DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving group competitions: {e}")

GROUP_COMPETITIONS = load_group_competitions()
def get_iran_time():
    tehran = pytz.timezone('Asia/Tehran')
    return datetime.now(tehran)
class SendPaidReaction(TLObject):
    __slots__ = ["flags", "peer", "msg_id", "count", "random_id", "private"]
    ID = 0x9dd6a67b
    QUALNAME = "functions.messages.SendPaidReaction"

    def __init__(self, peer: InputPeer, msg_id: int, count: int, random_id: int, private: bool = None):
        self.flags = 0
        if private is not None:
            self.flags |= 1
        self.peer = peer
        self.msg_id = msg_id
        self.count = count
        self.random_id = random_id
        self.private = private
    
    def write(self):
        b = b""
        b += Int(self.ID, False)
        b += Int(self.flags)
        b += self.peer.write()
        b += Int(self.msg_id)
        b += Int(self.count)
        b += Long(self.random_id)
        if self.flags & 1:
            b += Bool(self.private)
        return b
active_lotteries = {}
LOTTERY_DATA_FILE = "lottery_data.json"
def load_lottery_data():
    try:
        if os.path.exists(LOTTERY_DATA_FILE):
            with open(LOTTERY_DATA_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading lottery data: {e}")
    return {}

def save_lottery_data(data):
    try:
        with open(LOTTERY_DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving lottery data: {e}")
async def is_bot_active() -> bool:
    """بررسی وضعیت فعال/غیرفعال بودن ربات"""
    return BOT_ACTIVE
async def send_paid_reaction(client, chat_id, message_id, count=1, private=False):
    try:
        peer = await client.resolve_peer(chat_id)
        random_id = int(time.time()) * 2**32
        await client.invoke(
            SendPaidReaction(
                peer=peer,
                msg_id=message_id,
                count=count,
                random_id=random_id,
                private=private
            )
        )
    except Exception as e:
        print(f"Error in send_paid_reaction: {e}")
def admin_only(func):
    async def wrapper(client, message):
        if message.from_user.id not in ADMINS:
            await message.reply_text("❌ شما دسترسی به این بخش را ندارید!")
            return
        return await func(client, message)
    return wrapper
async def check_force_join(client: Client, user_id: int):
    try:
        for channel in FORCE_JOIN_CHANNELS:
            try:
                member = await client.get_chat_member(channel, user_id)
                if member.status in ["left", "kicked"]:
                    return False
            except Exception:
                return False
        return True
    except Exception as e:
        print(f"Error in check_force_join: {e}")
        return False
async def notify_admins(client: Client, message: str):
    for admin_id in ADMINS:
        try:
            await client.send_message(admin_id, message)
        except Exception as e:
            print(f"Error sending message to admin {admin_id}: {e}")
async def send_force_join_message(client: Client, message):
    text = "⚠️ برای استفاده از ربات باید ابتدا عضو کانال‌های زیر شوید:\n\n"
    for ch in FORCE_JOIN_CHANNELS:
        text += f"👉 https://t.me/{ch}\n"
    text += "\n✅ بعد از عضویت، دوباره دستور /start را بفرستید."
    
    if isinstance(message, Message):
        await message.reply_text(text)
    else:
        await message.message.edit_text(text)
def load_users_data():
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading users data: {e}")
    return {}

def save_users_data(data):
    try:
        with open(DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving users data: {e}")

users_data = load_users_data()

def get_user_data(user_id):
    user_id_str = str(user_id)
    if user_id_str not in users_data:
        users_data[user_id_str] = {
            "points": 0,
            "invited_by": None,
            "invite_code": generate_invite_code(),
            "invited_users": [],
            "security_code": None,
            "security_code_expiry": None,
            "daily_messages": 0 
        }
        save_users_data(users_data)
    return users_data[user_id_str]

def generate_invite_code():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(8))

def generate_security_code():
    return str(random.randint(10000, 99999)) 

def add_invited_user(inviter_id, invited_id):
    inviter_id_str = str(inviter_id)
    invited_id_str = str(invited_id)
    
    if inviter_id_str in users_data and invited_id_str not in users_data[inviter_id_str]["invited_users"]:
        users_data[inviter_id_str]["invited_users"].append(invited_id_str)
        users_data[inviter_id_str]["points"] += 10 # امتیاز دلخواه زیرمجموعه گیری
        save_users_data(users_data)
def extract_link_info(link):
    pattern = r"https?://t\.me/([a-zA-Z0-9_]+)/(\d+)"
    match = re.search(pattern, link)
    if match:
        return {
            "channel": match.group(1),
            "post_id": int(match.group(2))
        }
    return None
def generate_verification_code():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(7))
bot = Client(
    "my_bot",
    api_id=Apiid, # api ایدی بزار
    api_hash="Apihash", # api hash بزار
    bot_token="Tokne" # توکن رباتت
)

user_session_file = "user.session" # اسم فایل سشن
user_client = Client(
    "user_account",
    api_id=Apiid, # api ایدی بزار
    api_hash="Apihash" # api hash بزار
)

async def login_user_account():
    if os.path.exists(user_session_file):
        user_client.session_string = open(user_session_file).read()
        await user_client.start()
        print("✅ اکانت کاربر با session موجود وارد شد!")
        return True
    else:
        print("\n🔐 لاگین اکانت کاربر مورد نیاز است:")
        phone = input("لطفاً شماره تلفن را وارد کنید (با کد کشور مثلاً +989123456789): ")
        
        await user_client.connect()
        sent_code = await user_client.send_code(phone)
        
        code = input("کد تأیید ارسال شده را وارد کنید: ")
        
        try:
            await user_client.sign_in(phone, sent_code.phone_code_hash, code)
            session_string = await user_client.export_session_string()
            with open(user_session_file, "w") as f:
                f.write(session_string)
            print("✅ لاگین موفقیت‌آمیز بود و session ذخیره شد!")
            return True
        except Exception as e:
            print(f"❌ خطا در لاگین: {e}")
            return False
@bot.on_message(filters.command("send") & filters.group)
async def group_transfer(client: Client, message: Message):
    """
    دستور ارسال مخصوص گروه که فقط در گروه کار می‌کند
    """
    user_id = message.from_user.id
    if not await check_force_join(client, user_id):
        await send_force_join_message(client, message)
        return
    
    if not message.reply_to_message:
        await message.reply_text(
            "❌ لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر ارسال کنید!",
            reply_to_message_id=message.id
        )
        return
    
    from_user = message.from_user
    to_user = message.reply_to_message.from_user
 
    if from_user.id == to_user.id:
        await message.reply_text(
            "❌ نمی‌توانید به خودتان امتیاز ارسال کنید!",
            reply_to_message_id=message.id
        )
        return
    
    try:

        amount = int(message.text.split()[1])
    except (IndexError, ValueError):
        await message.reply_text(
            "❌ فرمت دستور نادرست!\n\n"
            "استفاده صحیح:\n"
            "<code>/send [مقدار امتیاز]</code>\n\n"
            "مثال:\n"
            "<code>/send 50</code> (در پاسخ به پیام کاربر)",
            reply_to_message_id=message.id,
            parse_mode=ParseMode.HTML
        )
        return

    if amount <= 0:
        await message.reply_text(
            "❌ مقدار امتیاز باید بیشتر از صفر باشد!",
            reply_to_message_id=message.id
        )
        return
    

    from_user_data = get_user_data(from_user.id)
    to_user_data = get_user_data(to_user.id)
    

    fee = int(amount * 0.15) 
    net_amount = amount - fee
    
    
    if from_user_data["points"] < amount:
        await message.reply_text(
            f"❌ امتیاز کافی ندارید!\n"
            f"موجودی شما: {from_user_data['points']}\n"
            f"مبلغ درخواستی: {amount} (شامل {fee} کارمزد)",
            reply_to_message_id=message.id
        )
        return
    

    confirm_keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ تأیید ارسال", callback_data=f"group_confirm_{to_user.id}_{amount}"),
            InlineKeyboardButton("❌ انصراف", callback_data="group_cancel")
        ]
    ])
    

    confirm_msg = await message.reply_text(
        f"🔰 درخواست ارسال امتیاز در گروه\n\n"
        f"👤 از کاربر: {from_user.mention}\n"
        f"👤 به کاربر: {to_user.mention}\n"
        f"💰 مبلغ ارسال: <code>{amount}</code> امتیاز\n"
        f"💸 کارمزد (15%): <code>{fee}</code> امتیاز\n"
        f"💳 مبلغ خالص دریافتی: <code>{net_amount}</code> امتیاز\n\n"
        f"موجودی شما پس از ارسال: <code>{from_user_data['points'] - amount}</code>\n\n"
        f"آیا از ارسال اطمینان دارید؟",
        reply_markup=confirm_keyboard,
        reply_to_message_id=message.id,
        parse_mode=ParseMode.HTML
    )
    

    user_verification_data[from_user.id] = {
        "state": "awaiting_group_transfer",
        "to_user_id": to_user.id,
        "amount": amount,
        "confirm_msg_id": confirm_msg.id
    }

@bot.on_callback_query(filters.regex(r"^group_confirm_(\d+)_(\d+)$"))
async def confirm_group_transfer(client: Client, callback_query: CallbackQuery):
    from_user_id = callback_query.from_user.id
    match = re.match(r"^group_confirm_(\d+)_(\d+)$", callback_query.data)
    to_user_id = int(match.group(1))
    amount = int(match.group(2))
    
    if from_user_id not in user_verification_data or \
       user_verification_data[from_user_id].get("state") != "awaiting_group_transfer" or \
       user_verification_data[from_user_id].get("to_user_id") != to_user_id:
        await callback_query.answer("❌ درخواست نامعتبر یا منقضی شده!", show_alert=True)
        return
    

    from_user_data = get_user_data(from_user_id)
    to_user_data = get_user_data(to_user_id)
    

    fee = int(amount * 0.15)
    net_amount = amount - fee
    

    if from_user_data["points"] < amount:
        await callback_query.answer("❌ موجودی شما کافی نیست!", show_alert=True)
        return
    

    from_user_data["points"] -= amount
    to_user_data["points"] += net_amount
    

    users_data[str(from_user_id)] = from_user_data
    users_data[str(to_user_id)] = to_user_data
    save_users_data(users_data)
    

    del user_verification_data[from_user_id]
    

    try:
        await callback_query.message.edit_text(
            f"✅ ارسال امتیاز با موفقیت انجام شد!\n\n"
            f"👤 از کاربر: <a href='tg://user?id={from_user_id}'>{callback_query.from_user.first_name}</a>\n"
            f"👤 به کاربر: <a href='tg://user?id={to_user_id}'>{to_user_data.get('first_name', 'کاربر')}</a>\n"
            f"💰 مبلغ ارسال: <code>{amount}</code> امتیاز\n"
            f"💸 کارمزد (15%): <code>{fee}</code> امتیاز\n"
            f"💳 مبلغ واریزی: <code>{net_amount}</code> امتیاز",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        print(f"Error editing message: {e}")
    

    try:
        await client.send_message(
            from_user_id,
            f"✅ ارسال گروهی شما تکمیل شد!\n\n"
            f"👤 به کاربر: {to_user_data.get('first_name', 'کاربر')}\n"
            f"💰 مبلغ ارسال: {amount} امتیاز\n"
            f"💸 کارمزد: {fee} امتیاز\n"
            f"🏦 موجودی جدید شما: {from_user_data['points']}"
        )
        
        await client.send_message(
            to_user_id,
            f"🎉 شما {net_amount} امتیاز دریافت کردید!\n\n"
            f"👤 از کاربر: {callback_query.from_user.first_name}\n"
            f"💰 مبلغ اصلی: {amount} امتیاز\n"
            f"💸 کارمزد سیستم: {fee} امتیاز\n"
            f"🏦 موجودی جدید شما: {to_user_data['points']}"
        )
    except Exception as e:
        print(f"Error sending private messages: {e}")
    
    await callback_query.answer()

@bot.on_callback_query(filters.regex("^group_cancel$"))
async def cancel_group_transfer(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    if user_id in user_verification_data:
        del user_verification_data[user_id]
    
    await callback_query.message.edit_text("❌ ارسال امتیاز لغو شد.")
    await callback_query.answer()
@bot.on_message(~filters.user(ADMINS))
async def block_non_admins(client: Client, message: Message):
    if not await is_bot_active():
        return  
    await message.continue_propagation()

@bot.on_message(filters.command(["gp", "gp_on", "gp_off"]) & filters.group)
async def group_competition_control(client: Client, message: Message):
    if message.from_user.id not in ADMINS:
        await message.reply_text("❌ فقط ادمین‌ها می‌توانند رقابت گروهی را مدیریت کنند!")
        return
    
    chat_id = str(message.chat.id)
    
    if message.command[0] == "gp_on":

        if chat_id in GROUP_COMPETITIONS and GROUP_COMPETITIONS[chat_id]["active"]:
            await message.reply_text("✅ رقابت گروهی از قبل فعال است!")
            return
            
        GROUP_COMPETITIONS[chat_id] = {
            "active": True,
            "start_time": time.time(),
            "end_time": None,
            "participants": {},
            "message_count": {}
        }
        save_group_competitions(GROUP_COMPETITIONS)
        
        await message.reply_text(
            "🎉 رقابت گروهی فعال شد!\n\n"
            "📌 برای تنظیم زمان رقابت از دستور زیر استفاده کنید:\n"
            "<code>/time 10d</code> (برای 10 دقیقه)\n"
            "<code>/time 1h</code> (برای 1 ساعت)\n\n"
            "شرکت‌کنندگان با ارسال پیام در گروه امتیاز کسب می‌کنند."
        )
        
    elif message.command[0] == "gp_off":
        if chat_id not in GROUP_COMPETITIONS or not GROUP_COMPETITIONS[chat_id]["active"]:
            await message.reply_text("ℹ️ رقابت گروهی از قبل غیرفعال است!")
            return
            

        await end_group_competition(client, message.chat.id)
        
    elif message.command[0] == "gp":

        if chat_id in GROUP_COMPETITIONS and GROUP_COMPETITIONS[chat_id]["active"]:
            remaining = GROUP_COMPETITIONS[chat_id]["end_time"] - time.time() if GROUP_COMPETITIONS[chat_id]["end_time"] else None
            if remaining and remaining > 0:
                mins, secs = divmod(int(remaining), 60)
                await message.reply_text(
                    f"🏆 رقابت گروهی فعال است!\n\n"
                    f"⏳ زمان باقیمانده: {mins} دقیقه و {secs} ثانیه\n"
                    f"👥 شرکت‌کنندگان: {len(GROUP_COMPETITIONS[chat_id]['participants'])}"
                )
            else:
                await message.reply_text(
                    "🏆 رقابت گروهی فعال است (زمان نامحدود)!\n\n"
                    f"👥 شرکت‌کنندگان: {len(GROUP_COMPETITIONS[chat_id]['participants'])}\n"
                    "برای تنظیم زمان از /time استفاده کنید."
                )
        else:
            await message.reply_text(
                "ℹ️ رقابت گروهی غیرفعال است!\n\n"
                "برای فعال کردن از /gp_on استفاده کنید."
            )

@bot.on_message(filters.command("time") & filters.group)
async def set_competition_time(client: Client, message: Message):
    if message.from_user.id not in ADMINS:
        await message.reply_text("❌ فقط ادمین‌ها می‌توانند زمان رقابت را تنظیم کنند!")
        return
    
    chat_id = str(message.chat.id)
    
    if chat_id not in GROUP_COMPETITIONS or not GROUP_COMPETITIONS[chat_id]["active"]:
        await message.reply_text("ℹ️ ابتدا رقابت گروهی را با /gp_on فعال کنید!")
        return
    
    try:
        time_str = message.text.split()[1].lower()
        if time_str.endswith("d"):
            minutes = int(time_str[:-1])
            duration = minutes * 60
        elif time_str.endswith("h"):
            hours = int(time_str[:-1])
            duration = hours * 3600 
        else:
            raise ValueError
    except (IndexError, ValueError):
        await message.reply_text(
            "❌ فرمت زمان نامعتبر!\n\n"
            "استفاده صحیح:\n"
            "<code>/time 10d</code> (برای 10 دقیقه)\n"
            "<code>/time 1h</code> (برای 1 ساعت)"
        )
        return
    
    GROUP_COMPETITIONS[chat_id]["end_time"] = time.time() + duration
    save_group_competitions(GROUP_COMPETITIONS)
   
    tehran = pytz.timezone('Asia/Tehran')
    end_time = datetime.fromtimestamp(GROUP_COMPETITIONS[chat_id]["end_time"], tehran)
    end_time_str = end_time.strftime("%Y/%m/%d - %H:%M")
    
    await message.reply_text(
        f"⏰ زمان رقابت گروهی تنظیم شد!\n\n"
        f"⏳ مدت زمان: {time_str}\n"
        f"🕒 زمان پایان: {end_time_str} (به وقت ایران)\n\n"
        f"برنده بر اساس بیشترین تعداد پیام ارسال شده انتخاب خواهد شد."
    )
    

    asyncio.create_task(end_group_competition_after_delay(chat_id, duration))

async def end_group_competition_after_delay(chat_id, delay):
    await asyncio.sleep(delay)
    await end_group_competition(bot, int(chat_id))

async def end_group_competition(client: Client, chat_id: int):
    chat_id_str = str(chat_id)
    
    if chat_id_str not in GROUP_COMPETITIONS or not GROUP_COMPETITIONS[chat_id_str]["active"]:
        return
    
    competition = GROUP_COMPETITIONS[chat_id_str]
    participants = competition["participants"]
    message_count = competition["message_count"]
    
    if not participants:
        await client.send_message(
            chat_id,
            "⏳ رقابت گروهی به پایان رسید، اما هیچ شرکت‌کننده‌ای وجود نداشت!"
        )
    else:

        winner_id = max(message_count.items(), key=lambda x: x[1])[0]
        winner_count = message_count[winner_id]
        
        
        try:
            await client.send_message(
                chat_id,
                f"🏆 رقابت گروهی به پایان رسید!\n\n"
                f"👑 برنده: <a href='tg://user?id={winner_id}'>کاربر</a>\n"
                f"📊 تعداد پیام‌ها: {winner_count}\n\n"
                f"👥 تعداد کل شرکت‌کنندگان: {len(participants)}\n"
                f"💬 تعداد کل پیام‌ها: {sum(message_count.values())}",
                parse_mode=ParseMode.HTML
            )
            
            
            user_data = get_user_data(winner_id)
            points_awarded = min(100, winner_count)  
            user_data["points"] += points_awarded
            users_data[str(winner_id)] = user_data
            save_users_data(users_data)
            
            await client.send_message(
                winner_id,
                f"🎉 شما در رقابت گروهی برنده شدید!\n\n"
                f"🏆 {points_awarded} امتیاز به حساب شما اضافه شد.\n"
                f"📊 تعداد پیام‌های شما: {winner_count}\n\n"
                f"امتیاز جدید شما: {user_data['points']}"
            )
        except Exception as e:
            print(f"Error announcing group competition winner: {e}")
    

    GROUP_COMPETITIONS[chat_id_str]["active"] = False
    save_group_competitions(GROUP_COMPETITIONS)


@bot.on_message(filters.group & filters.text)
async def track_group_messages(client: Client, message: Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    
    if chat_id in GROUP_COMPETITIONS and GROUP_COMPETITIONS[chat_id]["active"]:
       
        if user_id not in GROUP_COMPETITIONS[chat_id]["participants"]:
            GROUP_COMPETITIONS[chat_id]["participants"][user_id] = {
                "username": message.from_user.username,
                "first_name": message.from_user.first_name,
                "join_time": time.time()
            }
        

        GROUP_COMPETITIONS[chat_id]["message_count"][user_id] = GROUP_COMPETITIONS[chat_id]["message_count"].get(user_id, 0) + 1
        save_group_competitions(GROUP_COMPETITIONS)
@bot.on_message(filters.command(["bot_on", "bot_off"]) & filters.user(ADMINS))
async def bot_control(client: Client, message: Message):
    global BOT_ACTIVE
    
    if message.command[0] == "bot_on":
        BOT_ACTIVE = True
        await message.reply_text("🟢 ربات فعال شد (فقط ادمین‌ها دسترسی دارند)")
        
    elif message.command[0] == "bot_off":
        BOT_ACTIVE = False
        await message.reply_text("🔴 ربات غیرفعال شد (فقط ادمین‌ها دسترسی دارند)")
@bot.on_callback_query(~filters.user(ADMINS))
async def block_inline_clicks(client: Client, callback_query: CallbackQuery):
    if not await is_bot_active():
        await callback_query.answer()  
        return
    await callback_query.continue_propagation()
@bot.on_message(filters.command("remaining_time") & filters.group)
async def show_remaining_time(client: Client, message: Message):
    """نمایش زمان باقیمانده برای چالش‌های فعال در گروه"""
    active_in_chat = [
        lottery for lottery in active_lotteries.values() 
        if lottery["chat_id"] == message.chat.id
    ]
    
    if not active_in_chat:
        await message.reply_text("⏳ در حال حاضر هیچ چالش فعالی در این گروه وجود ندارد.")
        return
    
    response = "⏳ زمان باقیمانده چالش‌های فعال:\n\n"
    
    for lottery in active_in_chat:
        remaining = lottery["end_time"] - time.time()
        if remaining <= 0:
            continue
            
        hours, remainder = divmod(remaining, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        response += (
            f"🏆 جایزه: {lottery['points']} امتیاز\n"
            f"🔑 کلمه کلیدی: {lottery['keyword']}\n"
            f"⏳ زمان باقیمانده: {int(hours)} ساعت و {int(minutes)} دقیقه\n"
            f"👥 شرکت‌کنندگان: {len(lottery['participants'])}\n"
            "──────────────────\n"
        )
    
    await message.reply_text(response)
@bot.on_callback_query(filters.regex("^active_lotteries$"))
@admin_only
async def show_active_lotteries(client: Client, callback_query):
    """نمایش چالش‌های فعال در پنل مدیریت"""
    if not active_lotteries:
        await callback_query.answer("⚠️ هیچ چالش فعالی وجود ندارد!", show_alert=True)
        return
    
    response = "🎯 چالش‌های فعال:\n\n"
    
    for lottery_id, lottery in active_lotteries.items():
        remaining = lottery["end_time"] - time.time()
        if remaining <= 0:
            continue
            
        hours, remainder = divmod(remaining, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        try:
            chat = await client.get_chat(lottery["chat_id"])
            chat_title = chat.title
        except:
            chat_title = f"Chat ID: {lottery['chat_id']}"
        
        response += (
            f"🏷 چالش ID: {lottery_id}\n"
            f"💬 گروه: {chat_title}\n"
            f"🏆 جایزه: {lottery['points']} امتیاز\n"
            f"🔑 کلمه کلیدی: {lottery['keyword']}\n"
            f"⏳ زمان باقیمانده: {int(hours)} ساعت و {int(minutes)} دقیقه\n"
            f"👥 شرکت‌کنندگان: {len(lottery['participants'])}\n"
            "──────────────────\n"
        )
    
    await callback_query.message.edit_text(
        response,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
        ])
    )
    await callback_query.answer()


@bot.on_message(filters.command("panel") & filters.private)
@admin_only
async def admin_panel(client: Client, message: Message):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ اضافه کردن امتیاز", callback_data="add_points")],
        [InlineKeyboardButton("➖ کم کردن امتیاز", callback_data="remove_points")],
        [InlineKeyboardButton("👥 لیست کاربران", callback_data="users_list")],
        [InlineKeyboardButton("🎯 چالش‌های فعال", callback_data="active_lotteries")],
        [InlineKeyboardButton("📢 ارسال پیام همگانی", callback_data="broadcast_message")],
        [InlineKeyboardButton("📊 آمار ربات", callback_data="stats_panel")]
    ])
    
    await message.reply_text(
        "🔧 پنل مدیریت پیشرفته ربات\n\n"
        "لطفاً عملیات مورد نظر را انتخاب کنید:",
        reply_markup=keyboard
    )


@bot.on_message(filters.command("create") & filters.group)
async def create_lottery(client: Client, message: Message):
    try:
        if message.from_user.id not in ADMINS:
            await message.reply_text("❌ شما مجاز به ایجاد چالش نیستید!")
            return

        try:
            _, points, keyword, duration = message.text.split()
            points = int(points)
            duration = int(duration)
        except ValueError:
            await message.reply_text(
                "❌ فرمت دستور نادرست!\n"
                "استفاده صحیح:\n"
                "<code>/create [امتیاز] [کلمه کلیدی] [مدت زمان(دقیقه)]</code>\n\n"
                "📝 مثال:\n"
                "<code>/create 50 vote 120</code>\n\n"
                "• 50: امتیاز جایزه (عدد)\n"
                "• vote: کلمه کلیدی برای شرکت (بدون فاصله)\n"
                "• 120: مدت زمان چالش (دقیقه - عدد)",
                parse_mode=ParseMode.HTML
            )
            return

        lottery_id = f"{message.chat.id}_{int(time.time())}"
        active_lotteries[lottery_id] = {
            "chat_id": message.chat.id,
            "creator_id": message.from_user.id,
            "points": points,
            "keyword": keyword,
            "duration": duration,
            "end_time": time.time() + (duration * 60),
            "participants": [],
            "message_id": message.id
        }

        all_lotteries = load_lottery_data()
        all_lotteries[lottery_id] = active_lotteries[lottery_id]
        save_lottery_data(all_lotteries)


        tehran = pytz.timezone('Asia/Tehran')
        end_time = datetime.fromtimestamp(active_lotteries[lottery_id]["end_time"], tehran)
        end_time_str = end_time.strftime("%Y/%m/%d - %H:%M")
        
        await message.reply_text(
            f"🎉 چالش جدید ایجاد شد!\n\n"
            f"🏆 جایزه: <code>{points}</code> امتیاز\n"
            f"🔑 کلمه کلیدی: <code>{keyword}</code>\n"
            f"⏳ مدت زمان: <code>{duration}</code> دقیقه\n"
            f"🕒 زمان پایان: <code>{end_time_str}</code> (به وقت ایران)\n\n"
            f"برای شرکت در چالش، کلمه <code>{keyword}</code> را در این گروه ارسال کنید.\n\n"
            f"برای مشاهده زمان باقیمانده: <code>/remaining_time</code>",
            parse_mode=ParseMode.HTML
        )

        asyncio.create_task(end_lottery(lottery_id))

    except Exception as e:
        print(f"Error in create_lottery: {e}")
        await message.reply_text("❌ خطایی در ایجاد چالش رخ داد!")

    except Exception as e:
        print(f"Error in create_lottery: {e}")
        await message.reply_text("❌ خطایی در ایجاد قرعه‌کشی رخ داد!")

async def end_lottery(lottery_id):
    if lottery_id not in active_lotteries:
        return

    remaining_time = active_lotteries[lottery_id]["end_time"] - time.time()
    if remaining_time > 0:
        await asyncio.sleep(remaining_time)
    
    if lottery_id not in active_lotteries:
        return
    
    lottery = active_lotteries[lottery_id]
    participants = lottery["participants"]
    

    iran_time = get_iran_time()
    end_time_str = iran_time.strftime("%H:%M:%S")
    

    if participants:
        winner_id = random.choice(participants)
        winner_data = get_user_data(winner_id)
        winner_data["points"] += lottery["points"]
        users_data[str(winner_id)] = winner_data
        save_users_data(users_data)
        
        try:
            await bot.send_message(
                lottery["chat_id"],
                f"🎉 قرعه‌کشی به پایان رسید!\n"
                f"🕒 زمان پایان: {end_time_str} (به وقت ایران)\n\n"
                f"🏆 برنده: <a href='tg://user?id={winner_id}'>کاربر</a>\n"
                f"🎁 جایزه: {lottery['points']} امتیاز\n"
                f"👥 تعداد شرکت‌کنندگان: {len(participants)}\n\n"
                f"تبریک به برنده! 🎊",
                parse_mode=ParseMode.HTML
            )
            
            await bot.send_message(
                winner_id,
                f"🎊 شما در قرعه‌کشی گروه برنده شدید!\n\n"
                f"🏆 {lottery['points']} امتیاز به حساب شما اضافه شد.\n"
                f"امتیاز جدید شما: {winner_data['points']}\n\n"
                f"🕒 زمان قرعه‌کشی: {end_time_str} (به وقت ایران)"
            )
        except Exception as e:
            print(f"Error announcing lottery winner: {e}")
    else:
        await bot.send_message(
            lottery["chat_id"],
            f"⏳ قرعه‌کشی به پایان رسید، اما هیچ شرکت‌کننده‌ای وجود نداشت!\n"
            f"🕒 زمان پایان: {end_time_str} (به وقت ایران)"
        )

    del active_lotteries[lottery_id]
    all_lotteries = load_lottery_data()
    if lottery_id in all_lotteries:
        del all_lotteries[lottery_id]
        save_lottery_data(all_lotteries)
@bot.on_message(filters.command("send") & (filters.group | filters.private) & filters.create(lambda _, __, ___: bot_active))
async def universal_send_points(client: Client, message: Message):
    if not bot_active:
        await message.reply_text("❌ ربات موقتاً غیرفعال است. لطفاً بعداً تلاش کنید.")
        return
    
    user_id = message.from_user.id
    user_data = get_user_data(user_id)
    
    try:

        if message.reply_to_message:
            try:
                target_user = message.reply_to_message.from_user.id
                amount = int(message.text.split()[1])
            except IndexError:
                await message.reply_text(
                    "❌ لطفاً مقدار امتیاز را مشخص کنید!\n\n"
                    "استفاده صحیح با ریپلی:\n"
                    "<code>/send [مقدار امتیاز]</code>\n\n"
                    "مثال:\n"
                    "<code>/send 50</code> (در پاسخ به کاربر)",
                    parse_mode=ParseMode.HTML
                )
                return
        else:
            parts = message.text.split()
            if len(parts) < 3:
                await message.reply_text(
                    "❌ فرمت دستور نادرست!\n\n"
                    "استفاده صحیح:\n"
                    "1. با ریپلی روی پیام کاربر:\n"
                    "<code>/send [مقدار امتیاز]</code>\n\n"
                    "2. با ذکر آیدی کاربر:\n"
                    "<code>/send [آیدی کاربر] [مقدار امتیاز]</code>\n\n"
                    "مثال:\n"
                    "<code>/send 50</code> (در پاسخ به کاربر)\n"
                    "یا\n"
                    "<code>/send 123456789 50</code>",
                    parse_mode=ParseMode.HTML
                )
                return
            target_user = int(parts[1])
            amount = int(parts[2])
    except (ValueError, IndexError) as e:
        await message.reply_text(
            "❌ خطا در پردازش دستور!\n"
            "لطفاً از فرمت صحیح استفاده کنید.",
            parse_mode=ParseMode.HTML
        )
        return

    if amount <= 0:
        await message.reply_text("❌ مقدار امتیاز باید بیشتر از صفر باشد!")
        return
    
    if user_id == target_user:
        await message.reply_text("❌ نمی‌توانید به خودتان امتیاز انتقال دهید!")
        return
    

    fee = int(amount * 0.15)  # کارمزد انتقال
    net_amount = amount - fee
    
    if user_data["points"] < amount:
        await message.reply_text(
            f"❌ امتیاز کافی ندارید!\n"
            f"موجودی شما: {user_data['points']}\n"
            f"مبلغ درخواستی: {amount} (شامل {fee} کارمزد)"
        )
        return
    
    
    target_data = get_user_data(target_user)
    

    confirm_keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ تأیید انتقال", callback_data=f"confirm_send_{target_user}_{amount}"),
            InlineKeyboardButton("❌ انصراف", callback_data="cancel_send")
        ]
    ])
    
    try:

        await client.send_message(
            user_id,
            f"🔰 درخواست انتقال امتیاز\n\n"
            f"👤 کاربر مقصد: <code>{target_user}</code>\n"
            f"💰 مبلغ انتقال: <code>{amount}</code> امتیاز\n"
            f"💸 کارمزد (15%): <code>{fee}</code> امتیاز\n"
            f"💳 مبلغ خالص دریافتی: <code>{net_amount}</code> امتیاز\n\n"
            f"موجودی پس از انتقال: <code>{user_data['points'] - amount}</code>\n\n"
            f"آیا از انتقال اطمینان دارید؟",
            reply_markup=confirm_keyboard,
            parse_mode=ParseMode.HTML
        )
        

        reply_text = f"📨 درخواست انتقال به کاربر {target_user} به پیوی شما ارسال شد. لطفاً از طریق پیام خصوصی تأیید کنید."
        if message.chat.type != "private":
            await message.reply_text(reply_text)
        else:
            await message.reply_text("لطفاً در پیام ارسال شده در بالا انتقال را تأیید کنید.")
            
    except Exception as e:
        await message.reply_text(
            "❌ نمی‌توانم به شما پیام خصوصی ارسال کنم. "
            "لطفاً ابتدا به ربات پیام دهید و سپس مجدداً تلاش کنید."
        )


@bot.on_callback_query(filters.regex(r"^confirm_send_(\d+)_(\d+)$"))
async def confirm_send(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    match = re.match(r"^confirm_send_(\d+)_(\d+)$", callback_query.data)
    target_user = int(match.group(1))
    amount = int(match.group(2))
    
    user_data = get_user_data(user_id)
    target_data = get_user_data(target_user)
    

    fee = int(amount * 0.15)
    net_amount = amount - fee
    
    
    if user_data["points"] < amount:
        await callback_query.answer("❌ موجودی شما کافی نیست!", show_alert=True)
        return
    
    
    user_data["points"] -= amount
    target_data["points"] += net_amount
    
    
    users_data[str(user_id)] = user_data
    users_data[str(target_user)] = target_data
    save_users_data(users_data)
    

    await callback_query.message.edit_text(
        f"✅ انتقال با موفقیت انجام شد!\n\n"
        f"👤 به کاربر: <code>{target_user}</code>\n"
        f"💰 مبلغ انتقال: <code>{amount}</code> امتیاز\n"
        f"💸 کارمزد (15%): <code>{fee}</code> امتیاز\n"
        f"💳 مبلغ واریزی: <code>{net_amount}</code> امتیاز\n\n"
        f"🏦 موجودی جدید شما: <code>{user_data['points']}</code>",
        parse_mode=ParseMode.HTML
    )
    

    try:
        await client.send_message(
            target_user,
            f"🎉 شما <code>{net_amount}</code> امتیاز دریافت کردید!\n\n"
            f"👤 از کاربر: <code>{user_id}</code>\n"
            f"💰 مبلغ اصلی: <code>{amount}</code> امتیاز\n"
            f"💸 کارمزد سیستم: <code>{fee}</code> امتیاز\n\n"
            f"🏦 موجودی جدید شما: <code>{target_data['points']}</code>",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        print(f"Error notifying recipient: {e}")
        await callback_query.message.reply_text(
            f"⚠️ انتقال انجام شد اما اطلاع‌رسانی به کاربر مقصد امکان‌پذیر نبود!"
        )
    
    await callback_query.answer()


@bot.on_callback_query(filters.regex("^cancel_send$"))
async def cancel_send(client: Client, callback_query: CallbackQuery):
    await callback_query.message.edit_text("❌ انتقال امتیاز لغو شد.")
    await callback_query.answer()
@bot.on_message(filters.group & filters.text)
async def handle_group_messages(client: Client, message: Message):
    
    for lottery_id, lottery in list(active_lotteries.items()):
        if lottery["chat_id"] == message.chat.id and message.text.strip() == lottery["keyword"]:
            
            if message.from_user.id in lottery["participants"]:
                try:
                    await message.reply_text(
                        f"⚠️ شما قبلاً در این قرعه‌کشی شرکت کرده‌اید!",
                        reply_to_message_id=message.id
                    )
                except Exception:
                    pass
                return
            

            lottery["participants"].append(message.from_user.id)
            active_lotteries[lottery_id] = lottery
            
            all_lotteries = load_lottery_data()
            if lottery_id in all_lotteries:
                all_lotteries[lottery_id]["participants"] = lottery["participants"]
                save_lottery_data(all_lotteries)
            
            try:
                await message.reply_text(
                    f"✅ شما با موفقیت در قرعه‌کشی شرکت کردید!\n"
                    f"🏆 جایزه: {lottery['points']} امتیاز\n"
                    f"⏳ زمان باقیمانده: {int((lottery['end_time'] - time.time()) // 60)} دقیقه",
                    reply_to_message_id=message.id
                )
            except Exception as e:
                print(f"Error replying to participant: {e}")
            return
async def load_active_lotteries():
    all_lotteries = load_lottery_data()
    current_time = time.time()
    
    for lottery_id, lottery in list(all_lotteries.items()):
        if lottery["end_time"] > current_time:
            active_lotteries[lottery_id] = lottery
            
            asyncio.create_task(end_lottery(lottery_id))
        else:
           
            del all_lotteries[lottery_id]
    
    save_lottery_data(all_lotteries)
@bot.on_message(filters.command("add_user_points") & filters.private)
@admin_only
async def add_user_points(client: Client, message: Message):
    try:
        _, user_id, amount = message.text.split()
        user_id = int(user_id)
        amount = int(amount)
        
        user_data = get_user_data(user_id)
        user_data["points"] += amount
        save_users_data(users_data)
        
        await message.reply_text(f"✅ {amount} امتیاز به کاربر {user_id} اضافه شد.")
        await client.send_message(user_id, f"🎉 مدیر به شما {amount} امتیاز اضافه کرد!\n\nامتیاز جدید: {user_data['points']}")
        
    except Exception as e:
        await message.reply_text("❌ فرمت دستور نادرست!\nاستفاده صحیح:\n<code>/add_user_points user_id amount</code>", parse_mode=ParseMode.HTML)

@bot.on_message(filters.command("remove_user_points") & filters.private)
@admin_only
async def remove_user_points(client: Client, message: Message):
    try:
        _, user_id, amount = message.text.split()
        user_id = int(user_id)
        amount = int(amount)
        
        user_data = get_user_data(user_id)
        if user_data["points"] < amount:
            await message.reply_text(f"❌ کاربر فقط {user_data['points']} امتیاز دارد!")
            return
            
        user_data["points"] -= amount
        save_users_data(users_data)
        
        await message.reply_text(f"✅ {amount} امتیاز از کاربر {user_id} کسر شد.")
        await client.send_message(user_id, f"⚠️ مدیر از شما {amount} امتیاز کسر کرد!\n\nامتیاز جدید: {user_data['points']}")
        
    except Exception as e:
        await message.reply_text("❌ فرمت دستور نادرست!\nاستفاده صحیح:\n<code>/remove_user_points user_id amount</code>", parse_mode=ParseMode.HTML)
@bot.on_message(filters.command("panel") & filters.private)
@admin_only
async def admin_panel(client: Client, message: Message):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ اضافه کردن امتیاز", callback_data="add_points")],
        [InlineKeyboardButton("➖ کم کردن امتیاز", callback_data="remove_points")],
        [InlineKeyboardButton("👥 لیست کاربران", callback_data="users_list")],
        [InlineKeyboardButton("🎯 چالش‌های فعال", callback_data="active_lotteries")],
        [InlineKeyboardButton("📢 ارسال پیام همگانی", callback_data="broadcast_message")],
        [InlineKeyboardButton("📊 آمار ربات", callback_data="stats_panel")]
    ])
    
    await message.reply_text(
        "🔧 پنل مدیریت ربات\n\n"
        "لطفاً عملیات مورد نظر را انتخاب کنید:",
        reply_markup=keyboard
    )
@bot.on_callback_query(filters.regex("^stats_panel$"))
@admin_only
async def stats_panel_callback(client: Client, callback_query):
    total_users = len(users_data)
    active_users = sum(1 for user_id, data in users_data.items() if data.get("points", 0) > 0)
    total_points = sum(data.get("points", 0) for user_id, data in users_data.items())
    
    stats_text = (
        "📊 آمار ربات:\n\n"
        f"👥 کاربران کل: {total_users}\n"
        f"🌟 کاربران فعال: {active_users}\n"
        f"🏆 مجموع امتیازات: {total_points}\n\n"
        f"📅 آخرین به‌روزرسانی: {time.strftime('%Y-%m-%d %H:%M:%S')}"
    )
    
    await callback_query.message.edit_text(
        stats_text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
        ])
    )
    await callback_query.answer()
@bot.on_callback_query(filters.regex("^add_points$"))
@admin_only
async def add_points_callback(client: Client, callback_query):
    await callback_query.message.edit_text(
        "➕ افزودن امتیاز\n\n"
        "لطفاً آیدی کاربر و تعداد امتیاز را به این فرمت ارسال کنید:\n"
        "<code>/add_user_points user_id amount</code>\n\n"
        "مثال:\n"
        "<code>/add_user_points 123456789 50</code>",
        parse_mode=ParseMode.HTML
    )
    await callback_query.answer()

@bot.on_callback_query(filters.regex("^remove_points$"))
@admin_only
async def remove_points_callback(client: Client, callback_query):
    await callback_query.message.edit_text(
        "➖ کسر امتیاز\n\n"
        "لطفاً آیدی کاربر و تعداد امتیاز را به این فرمت ارسال کنید:\n"
        "<code>/remove_user_points user_id amount</code>\n\n"
        "مثال:\n"
        "<code>/remove_user_points 123456789 30</code>",
        parse_mode=ParseMode.HTML
    )
    await callback_query.answer()

@bot.on_callback_query(filters.regex("^users_list$"))
@admin_only
async def users_list_callback(client: Client, callback_query):
    users_list = "\n".join([f"{uid}: {data['points']} امتیاز" for uid, data in users_data.items()][:50])
    await callback_query.message.edit_text(
        f"👥 لیست کاربران (50 مورد اول):\n\n{users_list}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
        ])
    )
    await callback_query.answer()
@bot.on_callback_query(filters.regex("^back_to_admin_panel$"))
@admin_only
async def back_to_admin_panel(client: Client, callback_query):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ اضافه کردن امتیاز", callback_data="add_points")],
        [InlineKeyboardButton("➖ کم کردن امتیاز", callback_data="remove_points")],
        [InlineKeyboardButton("👥 لیست کاربران", callback_data="users_list")],
        [InlineKeyboardButton("📊 آمار ربات", callback_data="stats_panel")],
        [InlineKeyboardButton("🎯 چالش‌های فعال", callback_data="active_lotteries")],
        [InlineKeyboardButton("📢 ارسال پیام همگانی", callback_data="broadcast_message")]
    ])
    
    await callback_query.message.edit_text(
        "🔧 پنل مدیریت ربات\n\n"
        "لطفاً عملیات مورد نظر را انتخاب کنید:",
        reply_markup=keyboard
    )
    await callback_query.answer()
@bot.on_message(filters.command("start"))
async def start_command(client: Client, message: Message):
    user_id = message.from_user.id
    args = message.text.split()
    

    if len(args) > 1 and args[1].startswith("invite_"):
        invite_code = args[1][7:]
        inviter_id = None
        

        for uid, data in users_data.items():
            if data.get("invite_code") == invite_code:
                inviter_id = int(uid)
                break
        
        if inviter_id and inviter_id != user_id:
            user_data = get_user_data(user_id)
            if not user_data["invited_by"]:
                user_data["invited_by"] = inviter_id
                

                security_code = generate_security_code()
                user_data["security_code"] = security_code
                user_data["security_code_expiry"] = time.time() + 300  
                
                users_data[str(user_id)] = user_data
                save_users_data(users_data)
                

                try:
                    await client.send_message(
                        inviter_id,
                        f"🎉 کاربری با آیدی {user_id} از لینک دعوت شما استفاده کرد!\n\n"
                        f"پس از تکمیل مراحل (عضویت در کانال‌ها و وارد کردن کد امنیتی)، 10 امتیاز دریافت خواهید کرد."
                    )
                except Exception as e:
                    print(f"Error sending message to inviter: {e}")
                
                
                join_buttons = [
                    [InlineKeyboardButton("🔵 عضویت در کانال اول", url=f"https://t.me/{FORCE_JOIN_CHANNELS[0]}")],
                    [InlineKeyboardButton("🔴 عضویت در کانال دوم", url=f"https://t.me/{FORCE_JOIN_CHANNELS[1]}")],
                    [InlineKeyboardButton("✅ بررسی عضویت در همه کانال‌ها", callback_data="check_join")]
                ]
                
                join_check_keyboard = InlineKeyboardMarkup(join_buttons)
                
                await message.reply_text(
                    f"🔐 کد امنیتی شما: <code>{security_code}</code>\n\n"
                    "برای ادامه لطفاً:\n"
                    "1. در همه کانال‌های زیر عضو شوید\n"
                    "2. روی دکمه 'بررسی عضویت' کلیک کنید\n"
                    "3. سپس کد امنیتی بالا را ارسال کنید\n\n"
                    "⏳ اعتبار کد: 5 دقیقه",
                    reply_markup=join_check_keyboard,
                    parse_mode=ParseMode.HTML
                )
                return
    

    if not await check_force_join(client, user_id):

        join_buttons = [
            [InlineKeyboardButton("🔵 عضویت در کانال اول", url=f"https://t.me/{FORCE_JOIN_CHANNELS[0]}")],
            [InlineKeyboardButton("🔴 عضویت در کانال دوم", url=f"https://t.me/{FORCE_JOIN_CHANNELS[1]}")],
            [InlineKeyboardButton("✅ بررسی عضویت در همه کانال‌ها", callback_data="check_join")]
        ]
        
        join_check_keyboard = InlineKeyboardMarkup(join_buttons)
        
        await message.reply_text(
            "⚠️ برای استفاده از ربات باید ابتدا عضو همه کانال‌های زیر شوید:\n\n"
            f"🔵 کانال اول: https://t.me/{FORCE_JOIN_CHANNELS[0]}\n"
            f"🔴 کانال دوم: https://t.me/{FORCE_JOIN_CHANNELS[1]}\n\n"
            "✅ پس از عضویت در همه کانال‌ها، روی دکمه 'بررسی عضویت' کلیک کنید.",
            reply_markup=join_check_keyboard
        )
        return
    

    user_data = get_user_data(user_id)
    if user_data.get("security_code") and user_data.get("invited_by"):
        await message.reply_text(
            "🔐 لطفاً کد امنیتی 5 رقمی که دریافت کرده‌اید را ارسال کنید:\n\n"
            f"کد شما: <code>{user_data['security_code']}</code>\n"
            "⏳ اعتبار کد: 5 دقیقه",
            parse_mode=ParseMode.HTML
        )
        return
    

    await show_main_menu(client, message)

async def show_main_menu(client: Client, message: Message):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✨ سفارش استار", callback_data="order_star")],
        [InlineKeyboardButton("✅ تایید نهایی", callback_data="final_confirm")],
        [InlineKeyboardButton("👤 حساب کاربری", callback_data="user_account")],
        [InlineKeyboardButton("📩 لینک دعوت", callback_data="invite_link")],
        [InlineKeyboardButton("📞 پشتیبانی", callback_data="support")]  
    ])
    
    welcome_text = """
    <b>🌟 به ربات استارزن خوش آمدید! 🌟</b>

    <i>📌 با استفاده از این ربات می‌توانید:</i>
    • استار رسمی به پست‌های تلگرام ارسال کنید
    • از کانال‌ها و گروه‌ها حمایت کنید
    • با پشتیبانی در ارتباط باشید
    
    <code>🔹 لطفاً عملیات مورد نظر را انتخاب کنید:</code>
    """
    
    await message.reply_text(
        welcome_text,
        reply_markup=keyboard,
        parse_mode=ParseMode.HTML
    )
@bot.on_message(filters.command("reply") & filters.user(ADMINS))
async def reply_to_support(client: Client, message: Message):
    try:

        _, user_id, *reply_text = message.text.split()
        user_id = int(user_id)
        reply_text = " ".join(reply_text)
        
        try:
            await client.send_message(
                user_id,
                f"📨 پاسخ پشتیبانی:\n\n{reply_text}\n\n"
                "برای ارتباط مجدد با پشتیبانی از منوی اصلی استفاده کنید."
            )
            await message.reply_text("✅ پاسخ با موفقیت ارسال شد.")
        except Exception as e:
            await message.reply_text(f"❌ خطا در ارسال پاسخ: {e}")
    except ValueError:
        await message.reply_text(
            "❌ فرمت دستور نادرست!\n"
            "استفاده صحیح:\n"
            "<code>/reply user_id متن پاسخ</code>"
        )
@bot.on_callback_query(filters.regex("^check_join$"))
async def check_join_callback(client: Client, callback_query):
    user_id = callback_query.from_user.id
    
    if await check_force_join(client, user_id):
        user_data = get_user_data(user_id)
        if user_data.get("security_code") and user_data.get("invited_by"):
            await callback_query.message.edit_text(
                "✅ شما در همه کانال‌ها عضو هستید!\n\n"
                f"🔐 لطفاً کد امنیتی زیر را ارسال کنید:\n"
                f"<code>{user_data['security_code']}</code>\n\n"
                "⏳ اعتبار کد: 5 دقیقه",
                parse_mode=ParseMode.HTML
            )
        else:
            await callback_query.message.edit_text(
                "✅ شما در همه کانال‌ها عضو هستید!\n\n"
                "اکنون می‌توانید از امکانات ربات استفاده کنید."
            )
            await show_main_menu(client, callback_query.message)
    else:
        join_buttons = [
            [InlineKeyboardButton("🔵 عضویت در کانال اول", url=f"https://t.me/{FORCE_JOIN_CHANNELS[0]}")],
            [InlineKeyboardButton("🔴 عضویت در کانال دوم", url=f"https://t.me/{FORCE_JOIN_CHANNELS[1]}")],
            [InlineKeyboardButton("✅ بررسی مجدد عضویت", callback_data="check_join")]
        ]
        
        join_check_keyboard = InlineKeyboardMarkup(join_buttons)
        
        await callback_query.message.edit_text(
            "❌ شما هنوز در همه کانال‌ها عضو نشده‌اید!\n\n"
            "لطفاً در کانال‌های زیر عضو شوید و سپس روی دکمه 'بررسی مجدد' کلیک کنید:\n\n"
            f"🔵 کانال اول: https://t.me/{FORCE_JOIN_CHANNELS[0]}\n"
            f"🔴 کانال دوم: https://t.me/{FORCE_JOIN_CHANNELS[1]}",
            reply_markup=join_check_keyboard
        )
    
    await callback_query.answer()

@bot.on_message(filters.text & filters.private)
async def handle_messages(client: Client, message: Message):
    user_id = message.from_user.id
    user_data = get_user_data(user_id)
    text = message.text.strip()


    if user_id not in ADMINS and not await check_force_join(client, user_id):
        join_buttons = [
            [InlineKeyboardButton("🔵 عضویت در کانال اول", url=f"https://t.me/{FORCE_JOIN_CHANNELS[0]}")],
            [InlineKeyboardButton("🔴 عضویت در کانال دوم", url=f"https://t.me/{FORCE_JOIN_CHANNELS[1]}")],
            [InlineKeyboardButton("✅ بررسی عضویت", callback_data="check_join")]
        ]
        await message.reply_text(
            "⚠️ برای استفاده از ربات باید در کانال‌های زیر عضو شوید:",
            reply_markup=InlineKeyboardMarkup(join_buttons)
        )
        return


    if user_data.get("security_code") and user_data.get("invited_by"):
        if time.time() > user_data["security_code_expiry"]:
            await message.reply_text("⏳ کد امنیتی منقضی شده! لطفاً از /start مجدد استفاده کنید.")
            return
        
        if text == user_data["security_code"]:

            inviter_id = user_data["invited_by"]
            add_invited_user(inviter_id, user_id)
            
            user_data.pop("security_code", None)
            user_data.pop("security_code_expiry", None)
            save_users_data(users_data)
            
            try:
                await client.send_message(
                    inviter_id,
                    f"🎉 کاربر {user_id} از لینک شما استفاده کرد!\n"
                    f"🏆 10 امتیاز به حساب شما اضافه شد."
                )
            except Exception as e:
                print(f"Error notifying inviter: {e}")
            
            await message.reply_text(
                "✅ عضویت شما با موفقیت تأیید شد!\n"
                "10 امتیاز به دعوت کننده تعلق گرفت."
            )
            await show_main_menu(client, message)
            return
        else:
            await message.reply_text("❌ کد امنیتی نامعتبر!")
            return


    if user_id in user_verification_data and user_verification_data[user_id].get("state") == "awaiting_support_message":
        if text.lower() == "/cancel":
            del user_verification_data[user_id]
            await message.reply_text("❌ ارسال پیام به پشتیبانی لغو شد.")
            await show_main_menu(client, message)
            return
        

        support_message_id = f"support_{int(time.time())}_{user_id}"
        SUPPORT_MESSAGES[support_message_id] = {
            "user_id": user_id,
            "message": text,
            "time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        for admin_id in ADMINS:
            try:
                await client.send_message(
                    admin_id,
                    f"📩 پیام جدید از پشتیبانی\n\n"
                    f"👤 کاربر: {user_id}\n"
                    f"🕒 زمان: {SUPPORT_MESSAGES[support_message_id]['time']}\n"
                    f"📝 پیام:\n{text}\n\n"
                    f"برای پاسخ از دستور زیر استفاده کنید:\n"
                    f"/reply {user_id} متن پاسخ",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✏️ پاسخ", callback_data=f"reply_{user_id}")]
                    ])
                )
            except Exception as e:
                print(f"Error sending support message to admin {admin_id}: {e}")
        
        await message.reply_text(
            "✅ پیام شما با موفقیت به پشتیبانی ارسال شد.\n"
            "به زودی پاسخ شما داده خواهد شد."
        )
        del user_verification_data[user_id]
        await show_main_menu(client, message)
        return


    if user_id in ADMINS and user_id in user_verification_data and user_verification_data[user_id].get("state") == "admin_reply":
        target_user_id = user_verification_data[user_id]["target_user_id"]
        
        try:
            await client.send_message(
                target_user_id,
                f"📨 پاسخ پشتیبانی:\n\n{text}\n\n"
                "برای ارتباط مجدد با پشتیبانی از منوی اصلی استفاده کنید."
            )
            await message.reply_text(f"✅ پاسخ به کاربر {target_user_id} ارسال شد.")
            

            for admin_id in ADMINS:
                if admin_id != user_id:
                    try:
                        await client.send_message(
                            admin_id,
                            f"📩 پاسخ به پیام پشتیبانی\n\n"
                            f"👤 پاسخ دهنده: {user_id}\n"
                            f"👤 کاربر: {target_user_id}\n"
                            f"📝 پاسخ:\n{text}"
                        )
                    except Exception as e:
                        print(f"Error notifying admin {admin_id}: {e}")
            
        except Exception as e:
            await message.reply_text(f"❌ خطا در ارسال پاسخ: {e}")
        
        del user_verification_data[user_id]
        return


    if user_id in ADMINS and user_id in user_verification_data and user_verification_data[user_id].get("state") == "awaiting_broadcast_message":
        if text.lower() == "/cancel":
            del user_verification_data[user_id]
            await message.reply_text("❌ ارسال پیام همگانی لغو شد.")
            await show_admin_panel(client, message)
            return
        

        confirm_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ تأیید و ارسال", callback_data=f"confirm_broadcast_{message.id}")],
            [InlineKeyboardButton("❌ انصراف", callback_data="cancel_broadcast")]
        ])
        
        await message.reply_text(
            f"📢 پیام همگانی برای تأیید:\n\n{text}\n\n"
            f"⚠️ این پیام برای تمامی {len(users_data)} کاربر ارسال خواهد شد. آیا مطمئن هستید؟",
            reply_markup=confirm_keyboard
        )
        

        user_verification_data[user_id]["broadcast_message"] = text
        user_verification_data[user_id]["broadcast_message_id"] = message.id
        return

    
    if user_id in user_verification_data:
        state = user_verification_data[user_id].get("state")
        
        if state == "awaiting_link":
            link_info = extract_link_info(text)
            if not link_info:
                await message.reply_text(
                    "❌ فرمت لینک نامعتبر!\n\n"
                    "لطفاً لینک را به این فرمت ارسال کنید:\n"
                    "<code>https://t.me/نام_کانال/آیدی_پست</code>\n\n"
                    "مثال:\n<code>https://t.me/my_channel/123</code>",
                    parse_mode=ParseMode.HTML
                )
                return
            
            user_verification_data[user_id].update({
                "link_info": link_info,
                "state": "link_received"
            })
            
            await message.reply_text(
                "✅ لینک دریافت شد.\n"
                "لطفاً از منوی اصلی گزینه «✅ تایید نهایی» را انتخاب کنید."
            )
            await show_main_menu(client, message)
        
        elif state == "awaiting_verification":
            if text != user_verification_data[user_id]["verification_code"]:
                await message.reply_text("❌ کد تأیید نامعتبر!")
                return
            
            if time.time() > user_verification_data[user_id]["expiration_time"]:
                await message.reply_text("⏳ کد تأیید منقضی شده!")
                del user_verification_data[user_id]
                return
            

            reaction_keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("👤 ناشناس (خصوصی)", callback_data="private_reaction")],
                [InlineKeyboardButton("🌍 عمومی", callback_data="public_reaction")],
                [InlineKeyboardButton("❌ انصراف", callback_data="cancel_order")]
            ])
            
            await message.reply_text(
                "🔒 لطفاً نوع ریکشن را انتخاب کنید:\n\n"
                "👤 ناشناس: فقط شما و صاحب پست می‌توانید ببینید\n"
                "🌍 عمومی: همه می‌توانند ببینید\n\n"
                "نوع ریکشن مورد نظر خود را انتخاب کنید:",
                reply_markup=reaction_keyboard
            )
            
            user_verification_data[user_id]["state"] = "awaiting_reaction_type"
    

    elif user_id in ADMINS and text.startswith("/"):
        if text.startswith("/reply "):
            try:
                parts = text.split(" ", 2)
                if len(parts) < 3:
                    await message.reply_text("❌ فرمت دستور نادرست!\nاستفاده صحیح:\n/reply user_id متن پاسخ")
                    return
                
                target_user_id = int(parts[1])
                reply_text = parts[2]
                
                try:
                    await client.send_message(
                        target_user_id,
                        f"📨 پاسخ پشتیبانی:\n\n{reply_text}\n\n"
                        "برای ارتباط مجدد با پشتیبانی از منوی اصلی استفاده کنید."
                    )
                    await message.reply_text(f"✅ پاسخ به کاربر {target_user_id} ارسال شد.")
                except Exception as e:
                    await message.reply_text(f"❌ خطا در ارسال پاسخ: {e}")
            except ValueError:
                await message.reply_text("❌ فرمت دستور نادرست!\nاستفاده صحیح:\n/reply user_id متن پاسخ")
    

    else:
        if user_id in ADMINS:
            await show_admin_panel(client, message)
        else:
            await show_main_menu(client, message)


@bot.on_callback_query(filters.regex("^(private_reaction|public_reaction|cancel_order)$"))
async def handle_reaction_choice(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    data = callback_query.data
    
    if user_id not in user_verification_data:
        await callback_query.answer("❌ اطلاعات سفارش یافت نشد!", show_alert=True)
        return
    
    if data == "cancel_order":
        del user_verification_data[user_id]
        await callback_query.message.edit_text("❌ سفارش شما لغو شد.")
        await show_main_menu(client, callback_query.message)
        await callback_query.answer()
        return
    

    is_private = data == "private_reaction"
    user_data = get_user_data(user_id)
    
    if user_data["points"] < POINTS_PER_ORDER:
        await callback_query.answer(
            f"❌ امتیاز کافی نیست!\nنیاز: {POINTS_PER_ORDER} | موجودی: {user_data['points']}",
            show_alert=True
        )
        del user_verification_data[user_id]
        return
    
    link_info = user_verification_data[user_id]["link_info"]
    
    try:
        if not user_client.is_connected:
            await login_user_account()
        
        channel = await user_client.get_chat(link_info["channel"])
        
        processing_text = f"""
        <b>⏳ در حال ارسال استار ({'ناشناس' if is_private else 'عمومی'})...</b>
        
        <i>▫️ کانال: {channel.title}</i>
        <i>▫️ آیدی پست: {link_info['post_id']}</i>
        
        <code>لطفاً 10-15 ثانیه صبر کنید...</code>
        """
        
        await callback_query.message.edit_text(
            processing_text,
            parse_mode=ParseMode.HTML
        )
        
        asyncio.create_task(send_paid_reaction(
            user_client,
            channel.id,
            link_info["post_id"],
            count=1,
            private=is_private
        ))
        
        await asyncio.sleep(2)
        

        user_data["points"] -= POINTS_PER_ORDER
        users_data[str(user_id)] = user_data
        save_users_data(users_data)
        
        success_text = f"""
        <b>✅ استار با موفقیت ارسال شد!</b>
        
        <i>✨ کانال: {channel.title}</i>
        <i>📌 آیدی پست: {link_info['post_id']}</i>
        <i>🔒 نوع ریکشن: {'ناشناس 👤' if is_private else 'عمومی 🌍'}</i>
        <i>💰 {POINTS_PER_ORDER} امتیاز از حساب شما کسر شد.</i>
        <i>🏆 امتیاز باقیمانده: {user_data['points']}</i>
        
        <code>🌟 از حمایت شما متشکریم!</code>
        """
        
        await callback_query.message.edit_text(
            success_text,
            parse_mode=ParseMode.HTML
        )
        

        await notify_admins(
            client,
            f"📦 سفارش جدید\n\n"
            f"👤 کاربر: {user_id}\n"
            f"📌 پست: https://t.me/{link_info['channel']}/{link_info['post_id']}\n"
            f"🏷 کانال: {channel.title}\n"
            f"🔒 نوع: {'ناشناس' if is_private else 'عمومی'}\n"
            f"⭐ امتیاز کسر شده: {POINTS_PER_ORDER}"
        )
        

        await asyncio.sleep(5)
        await delete_user_chat(client, user_id)
        
    except Exception as e:
        print(f"Order Error: {e}")
        await callback_query.message.edit_text(
            "❌ خطا در پردازش سفارش! لطفاً بعداً تلاش کنید."
        )
    
    finally:
        del user_verification_data[user_id]
        await callback_query.answer()

async def delete_user_chat(client: Client, user_id: int):
    """حذف چت کاربر پس از تکمیل سفارش"""
    try:
        history = []
        async for msg in client.get_chat_history(user_id, limit=20):
            history.append(msg.id)
        
        if history:
            await client.delete_messages(user_id, history)
    except Exception as e:
        print(f"Error deleting chat history for {user_id}: {e}")
@bot.on_callback_query(filters.regex("^broadcast_message$"))
@admin_only
async def broadcast_message_callback(client: Client, callback_query: CallbackQuery):
    await callback_query.message.edit_text(
        "📢 ارسال پیام همگانی\n\n"
        "لطفاً پیامی که می‌خواهید برای همه کاربران ارسال شود را بنویسید:\n\n"
        "برای انصراف از ارسال، از دستور /cancel استفاده کنید.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
        ])
    )
    

    user_verification_data[callback_query.from_user.id] = {
        "state": "awaiting_broadcast_message"
    }
    await callback_query.answer()

@bot.on_callback_query(filters.regex("^confirm_broadcast_(\d+)$"))
@admin_only
async def confirm_broadcast(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    message_id = int(callback_query.data.split("_")[2])
    
    if user_id not in user_verification_data or "broadcast_message" not in user_verification_data[user_id]:
        await callback_query.answer("❌ اطلاعات پیام یافت نشد!", show_alert=True)
        return
    
    message_text = user_verification_data[user_id]["broadcast_message"]
    
    await callback_query.message.edit_text("⏳ در حال ارسال پیام به کاربران...")
    
    success_count = 0
    fail_count = 0
    
    for user_id_str in users_data:
        try:
            await client.send_message(int(user_id_str), f"📢 پیام همگانی از مدیریت:\n\n{message_text}")
            success_count += 1
            await asyncio.sleep(0.5)  
        except Exception as e:
            print(f"Error sending broadcast to {user_id_str}: {e}")
            fail_count += 1
    
    await callback_query.message.edit_text(
        f"✅ ارسال پیام همگانی تکمیل شد!\n\n"
        f"👥 کاربران موفق: {success_count}\n"
        f"❌ کاربران ناموفق: {fail_count}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
        ])
    )
    
    del user_verification_data[user_id]
    await callback_query.answer()

@bot.on_callback_query(filters.regex("^cancel_broadcast$"))
@admin_only
async def cancel_broadcast(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    if user_id in user_verification_data:
        del user_verification_data[user_id]
    
    await callback_query.message.edit_text("❌ ارسال پیام همگانی لغو شد.")
    await callback_query.answer()
    await show_admin_panel(client, callback_query.message)
@bot.on_callback_query()
async def handle_callback_query(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    data = callback_query.data
    

    if user_id not in ADMINS and not await check_force_join(client, user_id):
        await send_force_join_message(client, callback_query)
        await callback_query.answer()
        return
    
    try:
        if data == "order_star":
            user_data = get_user_data(user_id)
            
            if user_data["points"] < MINIMUM_POINTS_FOR_ORDER:
                await callback_query.answer(
                    f"⚠️ امتیاز شما کافی نیست! حداقل {MINIMUM_POINTS_FOR_ORDER} امتیاز نیاز دارید.\n"
                    f"امتیاز شما: {user_data['points']}",
                    show_alert=True
                )
                return
                
            request_text = """
            <b>📥 درخواست استار</b>
            
            <i>لطفاً لینک پست مورد نظر را به این فرمت ارسال کنید:</i>
            <code>https://t.me/نام_کانال/آیدی_پست</code>
            
            <u>مثال:</u>
            <code>https://t.me/testchannel/123</code>
            
            <i>💰 این سفارش {POINTS_PER_ORDER} امتیاز از حساب شما کسر خواهد کرد.</i>
            """.format(POINTS_PER_ORDER=POINTS_PER_ORDER)
            
            await callback_query.message.edit_text(
                request_text,
                parse_mode=ParseMode.HTML
            )
            user_verification_data[user_id] = {"state": "awaiting_link"}
            await callback_query.answer()
        
        elif data == "final_confirm":
            if user_id in user_verification_data and "link_info" in user_verification_data[user_id]:
                
                verification_code = generate_security_code()
                
                
                user_verification_data[user_id].update({
                    "verification_code": verification_code,
                    "state": "awaiting_verification",
                    "expiration_time": time.time() + 300  
                })
                
                await callback_query.message.edit_text(
                    f"🔐 کد تأیید شما: <code>{verification_code}</code>\n\n"
                    "لطفاً این کد را در چت ربات وارد کنید:\n\n"
                    "⏳ این کد فقط 5 دقیقه اعتبار دارد",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_main")]
                    ])
                )
                await callback_query.answer()
            else:
                await callback_query.answer(
                    "⚠️ شما هنوز لینک پستی را ارسال نکرده‌اید!",
                    show_alert=True
                )
        
        elif data == "user_account":
            user_data = get_user_data(user_id)
            account_text = f"""
            <b>👤 حساب کاربری شما</b>
            
            <i>🏆 امتیاز شما:</i> <code>{user_data['points']}</code>
            <i>💰 امتیاز مورد نیاز برای سفارش:</i> <code>{MINIMUM_POINTS_FOR_ORDER}</code>
            <i>👥 تعداد دعوت شده‌ها:</i> <code>{len(user_data['invited_users'])}</code>
            <i>🎯 امتیاز از دعوت:</i> <code>{len(user_data['invited_users']) * 10}</code>
            
            <code>💡 با دعوت دوستان خود امتیاز بیشتری کسب کنید!</code>
            """
            
            await callback_query.message.edit_text(
                account_text,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📩 لینک دعوت", callback_data="invite_link")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_main")]
                ])
            )
            await callback_query.answer()
        
        elif data == "invite_link":
            user_data = get_user_data(user_id)
            bot_username = (await client.get_me()).username
            invite_text = f"""
            <b>📩 لینک دعوت شما</b>
            
            <i>با ارسال این لینک به دوستان خود، پس از وارد کردن کد امنیتی توسط آنها، 10 امتیاز دریافت می‌کنید!</i>
            
            <code>https://t.me/{bot_username}?start=invite_{user_data['invite_code']}</code>
            
            <i>📌 هر کاربر فقط یکبار می‌تواند از طریق لینک دعوت عضو شود.</i>
            """
            
            await callback_query.message.edit_text(
                invite_text,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_main")]
                ])
            )
            await callback_query.answer()
        
        elif data == "support":
            await callback_query.message.edit_text(
                "📞 پشتیبانی\n\n"
                "لطفاً پیام خود را ارسال کنید. پیام شما مستقیماً به ادمین‌ها ارسال خواهد شد.\n\n"
                "برای انصراف از ارسال پیام، از دستور /cancel استفاده کنید.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_main")]
                ])
            )
            user_verification_data[user_id] = {"state": "awaiting_support_message"}
            await callback_query.answer()
        
        elif data == "back_to_main":
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("✨ سفارش استار", callback_data="order_star")],
                [InlineKeyboardButton("✅ تایید نهایی", callback_data="final_confirm")],
                [InlineKeyboardButton("👤 حساب کاربری", callback_data="user_account")],
                [InlineKeyboardButton("📩 لینک دعوت", callback_data="invite_link")],
                [InlineKeyboardButton("📞 پشتیبانی", callback_data="support")]
            ])
            
            welcome_text = """
            <b>🌟 به ربات استارزن خوش آمدید! 🌟</b>

            <i>📌 با استفاده از این ربات می‌توانید:</i>
            • استار رسمی به پست‌های تلگرام ارسال کنید
            • از کانال‌ها و گروه‌ها حمایت کنید
            • با پشتیبانی در ارتباط باشید
            
            <code>🔹 لطفاً عملیات مورد نظر را انتخاب کنید:</code>
            """
            
            await callback_query.message.edit_text(
                welcome_text,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML
            )
            await callback_query.answer()
        
        elif data == "check_join":
            if await check_force_join(client, user_id):
                user_data = get_user_data(user_id)
                if user_data.get("security_code") and user_data.get("invited_by"):
                    await callback_query.message.edit_text(
                        "✅ شما در همه کانال‌ها عضو هستید!\n\n"
                        f"🔐 لطفاً کد امنیتی زیر را ارسال کنید:\n"
                        f"<code>{user_data['security_code']}</code>\n\n"
                        "⏳ اعتبار کد: 5 دقیقه",
                        parse_mode=ParseMode.HTML
                    )
                else:
                    await callback_query.message.edit_text(
                        "✅ شما در همه کانال‌ها عضو هستید!\n\n"
                        "اکنون می‌توانید از امکانات ربات استفاده کنید."
                    )
                    await show_main_menu(client, callback_query.message)
            else:
                join_buttons = [
                    [InlineKeyboardButton("🔵 عضویت در کانال اول", url=f"https://t.me/{FORCE_JOIN_CHANNELS[0]}")],
                    [InlineKeyboardButton("🔴 عضویت در کانال دوم", url=f"https://t.me/{FORCE_JOIN_CHANNELS[1]}")],
                    [InlineKeyboardButton("✅ بررسی مجدد عضویت", callback_data="check_join")]
                ]
                
                join_check_keyboard = InlineKeyboardMarkup(join_buttons)
                
                await callback_query.message.edit_text(
                    "❌ شما هنوز در همه کانال‌ها عضو نشده‌اید!\n\n"
                    "لطفاً در کانال‌های زیر عضو شوید و سپس روی دکمه 'بررسی مجدد' کلیک کنید:\n\n"
                    f"🔵 کانال اول: https://t.me/{FORCE_JOIN_CHANNELS[0]}\n"
                    f"🔴 کانال دوم: https://t.me/{FORCE_JOIN_CHANNELS[1]}",
                    reply_markup=join_check_keyboard
                )
            await callback_query.answer()
        
        elif data.startswith("reply_"):
            if callback_query.from_user.id not in ADMINS:
                await callback_query.answer("❌ شما دسترسی ندارید!", show_alert=True)
                return
            
            target_user_id = int(data.split("_")[1])
            await callback_query.message.edit_text(
                f"در حال پاسخ به کاربر {target_user_id}\n\n"
                "لطفاً پیام پاسخ را ارسال کنید:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ انصراف", callback_data="cancel_reply")]
                ])
            )
            user_verification_data[callback_query.from_user.id] = {
                "state": "admin_reply",
                "target_user_id": target_user_id
            }
            await callback_query.answer()
        
        elif data == "cancel_reply":
            if callback_query.from_user.id in user_verification_data:
                del user_verification_data[callback_query.from_user.id]
            await callback_query.message.edit_text("❌ پاسخ دهی لغو شد.")
            await callback_query.answer()
        
        elif data == "active_lotteries":
            if not active_lotteries:
                await callback_query.answer("⚠️ هیچ چالش فعالی وجود ندارد!", show_alert=True)
                return
            
            response = "🎯 چالش‌های فعال:\n\n"
            
            for lottery_id, lottery in active_lotteries.items():
                remaining = lottery["end_time"] - time.time()
                if remaining <= 0:
                    continue
                    
                hours, remainder = divmod(remaining, 3600)
                minutes, seconds = divmod(remainder, 60)
                
                try:
                    chat = await client.get_chat(lottery["chat_id"])
                    chat_title = chat.title
                except:
                    chat_title = f"Chat ID: {lottery['chat_id']}"
                
                response += (
                    f"🏷 چالش ID: {lottery_id}\n"
                    f"💬 گروه: {chat_title}\n"
                    f"🏆 جایزه: {lottery['points']} امتیاز\n"
                    f"🔑 کلمه کلیدی: {lottery['keyword']}\n"
                    f"⏳ زمان باقیمانده: {int(hours)} ساعت و {int(minutes)} دقیقه\n"
                    f"👥 شرکت‌کنندگان: {len(lottery['participants'])}\n"
                    "──────────────────\n"
                )
            
            await callback_query.message.edit_text(
                response,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
                ])
            )
            await callback_query.answer()
        
        elif data == "back_to_admin_panel":
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ اضافه کردن امتیاز", callback_data="add_points")],
                [InlineKeyboardButton("➖ کم کردن امتیاز", callback_data="remove_points")],
                [InlineKeyboardButton("👥 لیست کاربران", callback_data="users_list")],
                [InlineKeyboardButton("🎯 چالش‌های فعال", callback_data="active_lotteries")],
                [InlineKeyboardButton("📢 ارسال پیام همگانی", callback_data="broadcast_message")],
                [InlineKeyboardButton("📊 آمار ربات", callback_data="stats_panel")]
            ])
            
            await callback_query.message.edit_text(
                "🔧 پنل مدیریت ربات\n\n"
                "لطفاً عملیات مورد نظر را انتخاب کنید:",
                reply_markup=keyboard
            )
            await callback_query.answer()
        
        elif data == "stats_panel":
            total_users = len(users_data)
            active_users = sum(1 for user_id, data in users_data.items() if data.get("points", 0) > 0)
            total_points = sum(data.get("points", 0) for user_id, data in users_data.items())
            
            stats_text = (
                "📊 آمار ربات:\n\n"
                f"👥 کاربران کل: {total_users}\n"
                f"🌟 کاربران فعال: {active_users}\n"
                f"🏆 مجموع امتیازات: {total_points}\n\n"
                f"📅 آخرین به‌روزرسانی: {time.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            await callback_query.message.edit_text(
                stats_text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
                ])
            )
            await callback_query.answer()
        
        elif data == "users_list":
            users_list = "\n".join([f"{uid}: {data['points']} امتیاز" for uid, data in users_data.items()][:50])
            await callback_query.message.edit_text(
                f"👥 لیست کاربران (50 مورد اول):\n\n{users_list}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
                ])
            )
            await callback_query.answer()
        
        elif data == "add_points":
            await callback_query.message.edit_text(
                "➕ افزودن امتیاز\n\n"
                "لطفاً آیدی کاربر و تعداد امتیاز را به این فرمت ارسال کنید:\n"
                "<code>/add_user_points user_id amount</code>\n\n"
                "مثال:\n"
                "<code>/add_user_points 123456789 50</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
                ])
            )
            await callback_query.answer()
        
        elif data == "remove_points":
            await callback_query.message.edit_text(
                "➖ کسر امتیاز\n\n"
                "لطفاً آیدی کاربر و تعداد امتیاز را به این فرمت ارسال کنید:\n"
                "<code>/remove_user_points user_id amount</code>\n\n"
                "مثال:\n"
                "<code>/remove_user_points 123456789 30</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_admin_panel")]
                ])
            )
            await callback_query.answer()
        
        else:
            await callback_query.answer("⚠️ دستور نامعتبر!", show_alert=True)
    
    except Exception as e:
        print(f"Error in callback query handler: {e}")
        await callback_query.answer("❌ خطایی رخ داد! لطفاً دوباره تلاش کنید.", show_alert=True)

async def main():
    await bot.start()
    print("🤖 ربات در حال اجراست...")
    
    if not user_client.is_connected:
        if not await login_user_account():
            print("❌ بدون اکانت کاربر، امکان ارسال واکنش پولی وجود ندارد")
    
    
    await load_active_lotteries()
     
    await idle()
    
    await bot.stop()
    if user_client.is_connected:
        await user_client.stop()

if __name__ == "__main__":
    bot.run(main())