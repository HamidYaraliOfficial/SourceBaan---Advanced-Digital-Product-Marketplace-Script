import logging
import qrcode
from io import BytesIO
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "BOT_TOKEN"#توکن ربات 

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = """
    🤖 **ربات تولید QR Code**
    
    لینک خود را ارسال کنید تا برای شما QR Code تولید کنم!
    
    📋 دستورات:
    /start - شروع دوباره 
    /help - راهنما
    
    ✨ فقط کافیست لینک خود را بفرستید!
    """
    await update.message.reply_text(welcome_text, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """
    📖 راهنمای استفاده:
    
    1. لینک مورد نظر خود را ارسال کنید
    2. ربات به صورت خودکار QR Code تولید می‌کند
    3. QR Code را دانلود و استفاده کنید
    
    🔗 پشتیبانی از انواع لینک:
    - وبسایت (https://example.com)
    - تلگرام (t.me/editor_a0)
    - واتساپ، اینستاگرام و...
    - هر نوع لینک معتبر دیگر
    
    ⚠️ توجه: لینک باید با http:// یا https:// شروع شود
    """
    await update.message.reply_text(help_text)

async def generate_qr_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text.strip()
    
    if not (user_message.startswith('http://') or user_message.startswith('https://')):
        await update.message.reply_text(
            "⚠️ لینک باید با http:// یا https:// شروع شود!\n\n"
            "مثال: https://example.com"
        )
        return
    
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(user_message)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        bio = BytesIO()
        bio.name = 'qrcode.png'
        img.save(bio, 'PNG')
        bio.seek(0)
        
        await update.message.reply_photo(
            photo=bio,
            caption=f"✅ QR Code برای لینک شما:\n`{user_message}`",
            parse_mode='Markdown'
        )
        
        logger.info(f"QR Code generated for: {user_message}")
        
    except Exception as e:
        logger.error(f"Error generating QR code: {e}")
        await update.message.reply_text("❌ خطا در تولید QR Code!")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_type = update.message.chat.type
    text = update.message.text
    
    if message_type == 'private':
        if not text.startswith('/'):
            await generate_qr_code(update, context)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Update {update} caused error {context.error}")

def main():
    application = Application.builder().token(BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    application.add_error_handler(error_handler)
    
    print("🤖 ربات در حال اجرا است...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()