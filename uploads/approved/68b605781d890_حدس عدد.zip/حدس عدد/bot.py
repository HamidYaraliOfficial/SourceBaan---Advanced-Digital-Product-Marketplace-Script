import telebot
import random

TOKEN = "BOT_TOKEN"#توکن ربات 
bot = telebot.TeleBot(TOKEN)

games = {}

def start_game(chat_id):
    games[chat_id] = {"number": random.randint(1, 100), "tries": 0, "active": True}

@bot.message_handler(commands=['start', 'help'])
def handle_start(message):
    chat_id = message.chat.id
    start_game(chat_id)
    bot.send_message(chat_id,
                     "سلام!\nمن ربات حدس عدد هستم.\nمن یک عدد بین 1 تا 100 انتخاب کردم.\nعدد رو با یک پیام ساده بفرست تا حد بزنی.\nدستورها:\n/new - بازی جدید\n/giveup - تسلیم شدن و دیدن جواب")

@bot.message_handler(commands=['new'])
def handle_new(message):
    chat_id = message.chat.id
    start_game(chat_id)
    bot.send_message(chat_id, "بازی جدید شروع شد! یک عدد بین 1 تا 100 حدس بزن.")

@bot.message_handler(commands=['giveup'])
def handle_giveup(message):
    chat_id = message.chat.id
    g = games.get(chat_id)
    if g and g["active"]:
        number = g["number"]
        g["active"] = False
        bot.send_message(chat_id, f"تو تسلیم شدی — عدد من {number} بود.\nبرای شروع مجدد /new را بزن.")
    else:
        bot.send_message(chat_id, "هیچ بازی فعالی وجود ندارد. برای شروع /new را بزن.")

@bot.message_handler(func=lambda m: True)
def handle_all_messages(message):
    chat_id = message.chat.id
    text = message.text.strip()
    if text.startswith('/'):
        bot.send_message(chat_id, "دستور ناشناخته. از /new یا /giveup استفاده کن.")
        return
    try:
        guess = int(text)
    except ValueError:
        bot.send_message(chat_id, "لطفاً یک عدد بین 1 تا 100 بفرست.")
        return

    if not (1 <= guess <= 100):
        bot.send_message(chat_id, "عدد باید بین 1 و 100 باشد.")
        return

    if chat_id not in games or not games[chat_id]["active"]:
        start_game(chat_id)
        bot.send_message(chat_id, "هیچ بازی فعالی نبود؛ بازی جدید شروع شد. دوباره حدس بزن!")

    game = games[chat_id]
    game["tries"] += 1
    secret = game["number"]

    if guess < secret:
        bot.send_message(chat_id, f"{guess} خیلی کوچیکه. تلاش‌ها: {game['tries']}")
    elif guess > secret:
        bot.send_message(chat_id, f"{guess} خیلی بزرگه. تلاش‌ها: {game['tries']}")
    else:
        tries = game["tries"]
        game["active"] = False
        bot.send_message(chat_id, f"آفرین! درست حدس زدی 🎉\nعدد {secret} بود.\nتعداد تلاش‌ها: {tries}\nبرای بازی جدید /new را بزن.")

if __name__ == "__main__":
    print("Bot started...")
    bot.infinity_polling()