<?php

define('bot token'); # توکن ربات
$admin = 'uid';
$databaseName = 'namedb';
$databaseUser = 'userdb';
$databasePass = 'passdb';
$web = 'https://domin/folder/';