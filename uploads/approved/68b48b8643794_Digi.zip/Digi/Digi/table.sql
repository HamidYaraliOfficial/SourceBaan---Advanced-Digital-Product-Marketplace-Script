
CREATE TABLE `groups` (
  `id`            BIGINT NOT NULL,
  `creator`       BIGINT NULL,
  `vip`           JSON NULL,
  `promote`       JSON NULL,
  `ban`           JSON NULL,
  `flood`         JSON NULL,
  `locked`        JSON NULL,
  `warn`          JSON NULL,
  `silent`        JSON NULL,
  `step`          JSON NULL,
  `filter`        JSON NULL,
  `installer`     BIGINT NULL,
  `del`           JSON NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `members` (
  `id` BIGINT NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `sendall` (
  `id`   INT NOT NULL AUTO_INCREMENT,
  `send` JSON NULL,
  `now`  INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;