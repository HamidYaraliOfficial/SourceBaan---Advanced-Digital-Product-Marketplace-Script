<?php
/*

دیباگ شده : @Camaeal

*/
error_reporting(0);
set_time_limit(60);
$ne=new mysqli('localhost','user','pass','name');//اطلاعات دیتابیس وارد کنید
$ne->set_charset('utf8mb4');

$token= '';//توکن ربات
define('API_KEY',$token);

function Neman($method,$data=[],$token=API_KEY) {
	$ch=curl_init('https://api.telegram.org/bot'.$token.'/'.$method);
	curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_POSTFIELDS=>$data]);
	return json_decode(curl_exec($ch));
}
$i=0;
while($i<=60) {
$q=$ne->query("select id,del from groups where `del` IS NOT NULL");
	while($r=$q->fetch_assoc()) {
		$del=json_decode($r['del'],true);
		if(!is_array($del)) continue;
		$changed=false;
		foreach($del as $msgid=>$time){
			if($time<=time()){
				Neman('deletemessage',[
					'chat_id'=>$r['id'],
					'message_id'=>$msgid
				]);
				unset($del[$msgid]);
				$changed=true;
			}
		}
		if($changed){
			$new=json_encode($del,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
			$ne->query("update groups set del=".($new==="[]"||$new==="{}"?"NULL":"'".$ne->real_escape_string($new)."'")." where id='{$r['id']}'");
		}
	}
sleep(1);
$i++;
}
/*

دیباگ شده : @Camaeal

*/