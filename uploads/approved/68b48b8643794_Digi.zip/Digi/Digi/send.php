<?php
/*

دیباگ شده : @Camaeal

*/
ini_set('display_errors',1);
error_reporting(E_ALL);

$ne=new mysqli('localhost','user','pass','name');//اطلاعات دیتابیس را وارد کنید
$ne->set_charset('utf8mb4');

$token= '';//توکن 
define('API_KEY',$token);

function Neman($method,$data=[],$token=API_KEY) {
	$ch=curl_init('https://api.telegram.org/bot'.$token.'/'.$method);
	curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>1,CURLOPT_POSTFIELDS=>$data]);
	return json_decode(curl_exec($ch));
}

$fetch=$ne->query("select * from sendall")->fetch_assoc();

if($fetch) {
	$now=$fetch['now'];
	$send=json_decode($fetch['send'],1);
	$for=$send['for']=='gp'?'groups':'members';
	$num=$ne->query("select id from $for")->num_rows;
    $limit=max(0,min(100,$num-$now));
    $offset=max(0,$now);
    $q=$ne->query("select id from $for limit $limit offset $offset") or die('error : '.$ne->error);
	$i=0;
	while(($r=$q->fetch_assoc())!==null) {
		if($send['send']=='forward')
			Neman('forwardmessage',[
				'chat_id'=>$r['id'],
				'from_chat_id'=>$send['chat'],
				'message_id'=>$send['msgid']
			]);
		else
			Neman('send'.$send['send'],[
				'chat_id'=>$r['id'],
				'text'=>$send['caption'],
				'caption'=>$send['caption'],
				$send['send']=>$send['file_id']
			]);
		++$i;
	}
	
	if($now+$i>=$num) {
		$ne->query("delete from sendall where id={$fetch['id']}") or die('error : '.$ne->error);
		Neman('sendmessage',[
			'chat_id'=>$send['chat'],
			'text'=>"ارسال شماره {$fetch['id']} به پایان رسید."
		]);
	}else
		$ne->query("update sendall set now=".($now+$i)." where id={$fetch['id']}");
}
/*

دیباگ شده : @Camaeal

*/


