<?php
ob_start();
//-------------------------------t.me/Maniawma---------------------------------------------
define('API_KEY','TOKEN');//add_token
//-------------------------------function-bot---------------------------------------------
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//----------------------------Variable------------------------------------------------
$token = 'TOKEN';//add_token
$web = 'https://HOST';//add_host
$Dev = SUDO;//add_admin
$token2 = TOKEN;//add_token
$channel = USERNAME;//add_channel
$bot = USERNAME;//add_bot
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
mkdir("data/$from_id");
$message_id = $message->message_id;
$text1 = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$rt = $update->message->reply_to_message;
$tc = $update->message->chat->type;
$reply = $update->message->reply_to_message;
$time= file_get_contents("https://provps.ir/td?td=time");
$data = $update->callback_query->data;
$reply = $update->message->reply_to_message;
$coin = file_get_contents("data/$from_id/coin.txt");
$step = file_get_contents("data/$from_id/step.txt");
$type = file_get_contents("data/$from_id/type.txt");
$viph = file_get_contents("data/$from_id/viph.txt");
$to =  file_get_contents("data/$from_id/token.txt");
$url =  file_get_contents("data/$from_id/url.txt");
$flist =  file_get_contents("data/$from_id/flist.txt");
$addres =  file_get_contents("data/$from_id/addres.txt");
$nfile =  file_get_contents("data/$from_id/namefile.txt");
$fcode =  file_get_contents("data/$from_id/fcode.txt");
$fup =  file_get_contents("data/$from_id/fup.txt");
$maroof =  file_get_contents("data/$from_id/maroof.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$token2/getChatMember?chat_id=@$channel&user_id=".$from_id));
$tch = $forchaneel->result->status;
//----------------------------------------------------------------------------
function SendMessage($chat_id, $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function SendDocument($chat_id, $document, $caption = null){
	bot('SendDocument',[
	'chat_id'=>$chat_id,
	'document'=>$document,
	'caption'=>$caption
	]);
	}
	function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
  bot('editMessagetext',[
    'chat_id'=>$chat_id,
 'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
 'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
 ]);
 }
 function SendPhoto($chat_id, $photo, $caption = null){
	bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$photo,
	'caption'=>$caption
	]);
	}
 function sendAction($chat_id, $action){
bot('sendChataction',[
'chat_id'=>$chat_id,
'action'=>$action]);
}

//---------------------------START---------------------------
if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
  SendMessage($chat_id,"برای اطلاع از آخرین اخبار ربات و استفاده از ربات ابتدا در چنل ربات عضو شوید و سپس /start کنید✨
@$channel 💫");
  }
  elseif($text1=="/start"){
    if (file_exists("data/$from_id/step.txt")) {
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"<a href='tg://user?id=$from_id'>$first_name</a>
به ربات هوشمند ربات ساز خوش آمدید!🌹
با دادن سورس به این ربات میتوانید ربات خود را تحویل بگیرید!✨
اگر با نحوه کار ربات آشنایی ندارید حتما راهنما را مطالعه کنید و در چنل ربات عضو باشید ⚠️

راهنما : /help
تعداد سکه های شما : /mycoins
درباره : /about

این ربات توسط Maniawma نوشته شده !
channel : @$channel 🔥",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
                    'keyboard'=>[
    [['text'=>"✨ نصب آسان ✨"]],
    [['text'=>"📂ساخت پوشه📂"],['text'=>"🗂پوشه های من🗂"]],
	[['text'=>"📤آپلود سورس📤"]],
	[['text'=>"🗝ست وب هوک🗝"],['text'=>"🔑حذف وب هوک🔑"]],
	[['text'=>"🔥حساب ویژه🔥"],['text'=>"💎راهنما💎"]],
	[['text'=>"✨ثبت معروف✨"]],
	[['text'=>"🗣پشتیبانی🗣"]]   
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}  
    else{
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/coin.txt","3");
        file_put_contents("data/$from_id/step.txt","none");
        file_put_contents("data/$from_id/maroof.txt","none");
        file_put_contents("data/$from_id/type.txt","free");
        $myfile2 = fopen("Member.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
        SendMessage($chat_id,"ثبت نام با موفقیت انجام شد✅
ربات را دوباره استارت کنید :
/start");
    }
}
//---------------------------MAROOF-----------------------------
elseif($text1 == "✨ثبت معروف✨" && $maroof == "ok"){
     file_put_contents("data/$from_id/step.txt","none");
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما یک مرتبه شناسه معروف خود را وارد کرده اید✨",
 'parse_mode'=>"MarkDown",
	 ]);
}
elseif($text1 == "✨ثبت معروف✨" && $maroof == "none"){
     file_put_contents("data/$from_id/step.txt","sabtem");
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اگر ربات از طرف کسی به شما معرفی شده لطفا کد معروف فرد را وارد کنید تا هم شما و هم فرد سکه بگیرید : (کد معروف همان شناسه عددی است)🔥
کد معروف شما : 
$from_id 💎

در صورتی که قصد انجام این کار ربات ندارید دستور /start را ارسال کنید✨",
 'parse_mode'=>"MarkDown",
	 ]);
}
elseif($step == "sabtem"){
    $text2 = $message->text;
    $txxt = file_get_contents('Member.txt');
$pmembersid= explode("\n",$txxt);
if(!in_array($text2,$pmembersid)){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر مورد نظرهنوز ربات را استارت نکرده است📛",
 'parse_mode'=>"MarkDown",
	 ]);
	 file_put_contents("data/$from_id/step.txt","none");
	   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به منوی اصلی برگشتیم",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
    'keyboard'=>[
    [['text'=>"✨ نصب آسان ✨"]],
    [['text'=>"📂ساخت پوشه📂"],['text'=>"🗂پوشه های من🗂"]],
	[['text'=>"📤آپلود سورس📤"]],
	[['text'=>"🗝ست وب هوک🗝"],['text'=>"🔑حذف وب هوک🔑"]],
	[['text'=>"🔥حساب ویژه🔥"],['text'=>"💎راهنما💎"]],
	[['text'=>"✨ثبت معروف✨"]],
	[['text'=>"🗣پشتیبانی🗣"]]   
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
if($text2 == $from_id){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"شما نمیتوانید شناسه خود را ثبت کنید !⚠️",
 'parse_mode'=>"MarkDown",
	 ]);
	 file_put_contents("data/$from_id/step.txt","none");
	   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به منوی اصلی برگشتیم",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
    'keyboard'=>[
    [['text'=>"✨ نصب آسان ✨"]],
    [['text'=>"📂ساخت پوشه📂"],['text'=>"🗂پوشه های من🗂"]],
	[['text'=>"📤آپلود سورس📤"]],
	[['text'=>"🗝ست وب هوک🗝"],['text'=>"🔑حذف وب هوک🔑"]],
	[['text'=>"🔥حساب ویژه🔥"],['text'=>"💎راهنما💎"]],
	[['text'=>"✨ثبت معروف✨"]],
	[['text'=>"🗣پشتیبانی🗣"]]   
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}else{
    $coin = file_get_contents("data/$from_id/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin + 3;
          save("data/$from_id/coin.txt",$newcoin);
     SendMessage($chat_id,"کد معروف ثبت شد و مقدار 3 سکه به شما افزوده شد🌹
جهت ادامه ربات را استارت کنید!");
SendMessage($text2,"یک کاربر شناسه معروف شما رو ثبت کرد!");
$coin = file_get_contents("data/$text2/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin + 5;
          save("data/$text2/coin.txt",$newcoin);
file_put_contents("data/$from_id/maroof.txt","ok");
file_put_contents("data/$from_id/step.txt","none");
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به منوی اصلی برگشتیم",
 'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
    'keyboard'=>[
    [['text'=>"✨ نصب آسان ✨"]],
    [['text'=>"📂ساخت پوشه📂"],['text'=>"🗂پوشه های من🗂"]],
	[['text'=>"📤آپلود سورس📤"]],
	[['text'=>"🗝ست وب هوک🗝"],['text'=>"🔑حذف وب هوک🔑"]],
	[['text'=>"🔥حساب ویژه🔥"],['text'=>"💎راهنما💎"]],
	[['text'=>"✨ثبت معروف✨"]],
	[['text'=>"🗣پشتیبانی🗣"]]   
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}}

elseif($text1 == "/mycoins"){
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تعداد سکه های شما : $coin
برای دریافت سکه بیشتر باید دوستان خود را به ربات دعوت کنید و آنها شناسه معروف شما را ثبت کنند 📛
شناسه شما : $from_id",
 'parse_mode'=>"MarkDown",
	 ]);
}
//---------------------------COMMANDS---------------------------
elseif($text1 == "/help"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"⚠️ توجه ⚠️
خواندن این متن اجباری میباشد !
برای استفاده از ربات ابتدا باید راهنما را مشاهده کنید تا به مشکلی برخورد نکنید✨

ابتدا یک ربات در بات فادر ایجاد کنید و توکن آن را در سورس خود قرار دهید💎
سپس به ربات آمده و روی دکمه ساخت پوشه کلیک کنید (اعضای معمولی فقط یک پوشه دارند)🗂
سپس به بخش آپلود سورس رفته و سورسی که در آن توکن قرار داده اید را ارسال کنید !🔥

✨نصب آسان✨
برای استفاده از این بخش هر مرتبه 1 سکه از حساب شما کم میشود!
ابتدا توکن را در سورس گزاشته و در گام اول سورس را برای ربات ارسال کنید😼
سپس توکن را رسال کنید تا ربات فعال شود🌹

اعضای ویژه ربات :
امکان ساخت 6 پوشه در ربات را دارند ✨
پس از ساخت پوشه برای مشاهده شناسه پوشه خود به بخش (پوشه های من) بروید📁
شناسه پوشه ای که میخواهید در آن سورس آپلود کنید را به یاد بسپارید و به بخش آپلود سورس بیایید📤
در گام اول شناسه پوشه را وارد کنید🌹
در گام دوم نام فایلی که میخواهید آپلود شود وارد کنید🔥
ربات فایل را در پوشه شما آپلود و آدر آن را به شما میدهد💎
برای آپلود بیش از یک فایل دوباره اینکار را انجام دهید اما نام فایل با فایل موجود در پوشه یکی نباشد!📛

📛توجه📛
فایل هایی که به ربات میفرستید نباید فشرده (زیپ) باشند⚠️
فایل حتما در فرمت php باشد!⚠️
استفاده از ربات های کد شده ممنوع و پیگرد قانونی دارد!📛

برای دریافت راهنما :
/help
برای دریافت تعداد سکه ها:
/mycoins
برای دریافت متن درباره:
/about
برای ارتقا ربات به ویژه :
/upgrade
@$channel"
]);
}
elseif($text1 == "/about"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"This bot created by #Cyber_Dev
You can create your own Bot
------------------------------------------------------------------
این ربات توسط  #Cyber_Dev نوشته شده و شما میتونید ربات خودتون رو بسازید"
]);
}
elseif($text1 == "/upgrade" && $type == "free"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"با سلام کاربر گرامی
شما از پنل رایگان ربات استفاده میکنید💫
در پنل رایگان محدودیت هایی از نظیر 
امکان ساخت یک پوشه❌
امکان آپلود یک فایل داخل پوشه (فایل اصلی سورس)❌
و محدودیت های دیگری هستید📛

با ویژه شدن حساب شما در ربات محدودیت ها رفع شده و شما میتوانید:

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

❎با مبلغ 2 هزار تومان میتوانید حساب خود را در ربات ویژه کنید❎

توجه !
شما میتوانید بصورت رایگان خود را ویژه کنید
تنها با 50 سکه !
تعداد سکه های شما :
$coin
برای افزایش سکه از دستور زیر کمک بگیرید:
/mycoins

اگر حساب شما مقدار سکه لازم برای ویژه شدن را دارد از دستور زیر برای ویژه شدن استفاده کنید:
/vipconfig
👤جهت خرید با بخش پشتیبانی در ارتباط باشید👤"
]);
}
elseif($text1 == "/upgrade" && $type == "none"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"با سلام کاربر گرامی
شما از پنل رایگان ربات استفاده میکنید💫
در پنل رایگان محدودیت هایی از نظیر 
امکان ساخت یک پوشه❌
امکان آپلود یک فایل داخل پوشه (فایل اصلی سورس)❌
و محدودیت های دیگری هستید📛

با ویژه شدن حساب شما در ربات محدودیت ها رفع شده و شما میتوانید:

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

❎با مبلغ 2 هزار تومان میتوانید حساب خود را در ربات ویژه کنید❎

توجه !
شما میتوانید بصورت رایگان خود را ویژه کنید
تنها با 50 سکه !
تعداد سکه های شما :
$coin
برای افزایش سکه از دستور زیر کمک بگیرید:
/mycoins

اگر حساب شما مقدار سکه لازم برای ویژه شدن را دارد از دستور زیر برای ویژه شدن استفاده کنید:
/vipconfig
👤جهت خرید با بخش پشتیبانی در ارتباط باشید👤"
]);
}
elseif($text1 == "/upgrade" && $type == "vip"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"کاربر گرامی حساب شما در ربات ویژه است✨

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

با تشکر از شما🌹"
]);
}
//----------------------------Back---------------------------
elseif($text1 == "برگشت به منوی اصلی🔙"){
    file_put_contents("data/$from_id/step.txt","none");
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"به منوی اصلی برگشتیم✨",
 'parse_mode'=>"MarkDown",  
	  'reply_markup'=>json_encode([
    'keyboard'=>[
    [['text'=>"✨ نصب آسان ✨"]],
    [['text'=>"📂ساخت پوشه📂"],['text'=>"🗂پوشه های من🗂"]],
	[['text'=>"📤آپلود سورس📤"]],
	[['text'=>"🗝ست وب هوک🗝"],['text'=>"🔑حذف وب هوک🔑"]],
	[['text'=>"🔥حساب ویژه🔥"],['text'=>"💎راهنما💎"]],
	[['text'=>"✨ثبت معروف✨"]],
	[['text'=>"🗣پشتیبانی🗣"]]   
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
//---------------------------easy-installer---------------------------
elseif($text1 == "✨ نصب آسان ✨"){
    if($coin < 1){
     file_put_contents("data/$from_id/step.txt","none");
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاربر گرامی متاسفانه به اندازه کافی سکه ندارید!😶
برای انجام این کار به 1 سکه نیاز دارید⚠️
سکه های شما : $coin است✨
برای جمع آوری سکه میتوانید ربات را به دوستان خود معرفی کنید و آنها در بهش ثبت معروف شناسه شما ($from_id) را وارد کنند تا شما 5 سکه و دوستتان نیز 32 سکه بگیرد 😃
برای دریافت تعداد سکه ای شما دستور /mycoins را ارسال کنید🌹",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
else{ 
    
    if($text1 == "✨ نصب آسان ✨" && $coin > 0){
     file_put_contents("data/$from_id/step.txt","easy");
     $code = rand(10000000,999999999);
    mkdir("bots/$code");
    mkdir("bots/$code/data");
    file_put_contents("data/$from_id/fcode.txt",$code);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست عزیز به بخش نصب آسان خوش آمدید🌹
این بخش برای همه اعضا رایگان و نامحدود است و دقیقا مانند بخش ساخت پوشه عمل میکند!✨
توکن و اطلاعات لازم رو داخل سورس قرار بده و سورس رو اینجا بفرست:
(سورس نباید فشرده یا زیپ باشه)
توجه برای این کار مقدار 1 سکه از حساب شما کم میشود در صورتی که نمیخواهید این کار انجام شود دستور /start را ارسال کنید!🔥🔥🔥",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}}}
  elseif($step == "easy"){
    file_put_contents("data/$from_id/step.txt","tokenin");
          $document = $message->document;
      $file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      $source1 = file_put_contents("bots/$fcode/bot.php",file_get_contents('https://api.telegram.org/file/bot'.$token.'/'.$patch));
      $source = file_get_contents("bots/$fcode/bot.php");
      $source = str_replace("fwrite","nottrue",$source);
      $source = str_replace("fclose","nottrue",$source);
      $source = str_replace("rmdir","nottrue",$source);
      $source = str_replace("fopen","nottrue",$source);
      save("bots/$fcode/bot.php",$source);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"برای ادامه لطفا توکن ربات را اینجا ارسال کنید:",
 'parse_mode'=>"MarkDown",  
 $button_back
	 ]);
}
	elseif($step == "tokenin"){
    file_put_contents("data/$from_id/step.txt","none");
 $text2 = $message->text;
 file_put_contents("data/$from_id/token.txt","$text2");
 file_get_contents("https://api.telegram.org/bot$to/setwebhook?url=$web/$bot/bots/$fcode/bot.php");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"تبریک ربات شما با موفقیت فعال شد✅
برای ادامه دستور /start را بزنید✨",
            ]);
                  $coin = file_get_contents("data/$from_id/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin - 1;
          save("data/$from_id/coin.txt",$newcoin);
        }
//---------------------------FOLDER-----------------------------------
elseif($text1 == "📂ساخت پوشه📂" && $type == "none"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"$first_name عزیز 
شما از پنل رایگان ربات استفاده میکنید و در این پنل فقط میتوانید یک پوشه در ربات ایجاد کنید🌹
برای ویژه شدن ربات با مبلغ 5 هزار تومان دستور /upgrade
را بفرستید.

آدرس پوشه شما:
$web/$bot/bots/$fcode "
]);
}
elseif($text1 == "📂ساخت پوشه📂" && $viph == "1\n1\n1\n1\n1\n"){
    file_put_contents("data/$from_id/type.txt","none");
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"کاربر گرامی✨
امکان ساخت بیش از 6 پوشه در پنل ویژه ممکن نیست!🔥
برای مشاهده پوشه های خود از دکمه (پوشه های من)🗂
و برای آپلود سورس در پوشه خود از دکمه (آپلود سورس استفاده کنید)📤
با تشکر تیم مدیریت $bot🌹"
]);
}
elseif($text1 == "📂ساخت پوشه📂" && $type == "vip"){
    $myfile3 = fopen("data/$from_id/viph.txt", "a") or die("Unable to open file!");
        fwrite($myfile3, "1\n");
        fclose($myfile3);
    $code = rand(10000000,999999999);
    mkdir("bots/$code");
    mkdir("bots/$code/data");
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"کاربر گرامی🌹
حساب شما ویژه میباشد و میتوانید 6 پوشه اختصاصی داشته باشید💎
پوشه جدید شما ساخته شد:
$web/$bot/bots/$code

برای مشاهده پوشه ها به بخش  پوشه های من مراجعه کنید🗂"
]);
 $myfile4 = fopen("data/$from_id/flist.txt", "a") or die("Unable to open file!");
        fwrite($myfile4, "$code\n");
        fclose($myfile4);
}
elseif($text1 == "📂ساخت پوشه📂" && $type == "free"){
     file_put_contents("data/$from_id/type.txt","none");
     $code = rand(10000000,999999999);
    mkdir("bots/$code");
       mkdir("bots/$code/data");
       file_put_contents("data/$from_id/fcode.txt","$code");
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"کاربر گرامی پوشه مخصوص شما در هاست ساخته شد 📂
برای آپلود سورس به بخش آپلود سورس بروید ✨
توجه کنید که در پنل رایگان شما میتوانید فقط یک پوشه بسازید💎
آدرس پوشه شما:
$web/$bot/bots/$code"
]);
$myfile4 = fopen("data/$from_id/flist.txt", "a") or die("Unable to open file!");
        fwrite($myfile4, "$code\n");
        fclose($myfile4);
}
//---------------------------MYFOLDER---------------------------
elseif($text1 == "🗂پوشه های من🗂"){
$file = file_get_contents("data/$from_id/flist.txt");
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"📂شناسه پوشه های شما تا کنون :
$file"
]);

fclose($file);
}
//---------------------------UPLOAD---------------------------
elseif($text1 == "📤آپلود سورس📤" && $type == "free"){
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"کاربر گرامی🌹
شما هنوز پوشه ای در هاست ندارید!
ابتدا از بخش (ساخت پوشه) پوشه مخصوص خود را ساخته و سپس شناسه پوشه را از بخش (پوشه های من) برداشه و برای آپلود سورس  به این بخش مراجعه کنید✨",
            ]);
        }
        elseif($text1 == "📤آپلود سورس📤" && $fup == "ok" && $type == "none"){
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"کاربر گرامی🌹
پنل شما رایگان است و یک فایل را در پوشه خود آپلود کردید‼️
متاسفانه این کار در پنل رایگان برگشت پذیر نیست📛
برای ویژه کردن حساب به بخش حساب ویژه مراجعه کنید یا دستور /upgrade را ارسال کنید⚠️
آدرس فایل آپلودی شما:
$web/$bot/bots/$fcode/bot.php️",
            ]);
        }
elseif($text1 == "📤آپلود سورس📤" && $type == "none"){
    file_put_contents("data/$from_id/step.txt","upload");
    file_put_contents("data/$from_id/fup.txt","ok");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"دوست عزیز توجه کنید که این کار برای اعضای معمولی یک بار انجام پذیر است!⚠️
لطفا در انجام این کار دقت کنید!📛
لطفا سورس را ارسال کنید📤
سورس نباید زیپ و فشرده باشد‼️
فقط سورس هایی در پنل رایگان قابل اجراست که دارای یک فایل است!✨
سورس را در فرمت php ارسال کنید (قبل از ارسال توکن و اطلاعات لازم را در سورس جایگزین کنید)",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
        elseif($step == "upload"){
            file_put_contents("data/$from_id/step.txt","none");
      $document = $message->document;
      $file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      $source1 = file_put_contents("bots/$fcode/bot.php",file_get_contents('https://api.telegram.org/file/bot'.$token.'/'.$patch));
      $source = file_get_contents("bots/$fcode/bot.php");
      $source = str_replace("fwrite","nottrue",$source);
      $source = str_replace("fclose","nottrue",$source);
      $source = str_replace("rmdir","nottrue",$source);
      $source = str_replace("fopen","nottrue",$source);
      save("bots/$fcode/bot.php",$source);
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"فایل شما با موفقیت آپلود شد✅
برای ست کردن وب هوک از آدرس زیر استفاده کنید:
$web/$bot/bots/$fcode/bot.php",
            ]);
        }
elseif($text1 == "📤آپلود سورس📤" && $type == "vip"){
file_put_contents("data/$from_id/step.txt","addres");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"کاربر عزیز لطفا شناسه پوشه خود را از بخش (پوشه های من) کپی کرده و در اینجا وارد کنید:",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
        elseif($step == "addres"){
    file_put_contents("data/$from_id/step.txt","namefile");
$text2 = $message->text;
 file_put_contents("data/$from_id/addres.txt","$text2");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"پوشه مورد نظر با موفقیت انتخاب شد ✅ (اگر مشکلی در انتخاب پوشه وجود دارد ربات را یک مرتبه استارت کنید)
آدرس پوشه انتخاب شده :
$web/$bot/bots/$text2",
            ]);
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"خب حالا برای فایل خود یک نام انتخاب کنید✨
بدون فرمت !
مثال :
bot
robot",
            ]);
        }
        elseif($step == "namefile"){
    file_put_contents("data/$from_id/step.txt","upload");
$text2 = $message->text;
 file_put_contents("data/$from_id/namefile.txt","$text2");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"نام فایل شما با موفقیت ذخیره شد:
$text2.php",
            ]);
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"حالا سورس خود را ارسال کنید📂
دقت کنید سورس نباید بصورت زیپ باشد!🔥
فقط در فرمت php ✨",
            ]);
        }
elseif($step == "upload"){
    file_put_contents("data/$from_id/step.txt","none");
      $document = $message->document;
      $file = $document->file_id;
      $get = bot('getfile',['file_id'=>$file]);
      $patch = $get->result->file_path;
      $source = file_put_contents("bots/$addres/$nfile.php",file_get_contents('https://api.telegram.org/file/bot'.$token.'/'.$patch));
      $source1 = file_put_contents("bots/$addres/$nfile.php",file_get_contents('https://api.telegram.org/file/bot'.$token.'/'.$patch));
      $source = file_get_contents("bots/$addres/$nfile.php");
      $source = str_replace("fwrite","nottrue",$source);
      $source = str_replace("fclose","nottrue",$source);
      $source = str_replace("rmdir","nottrue",$source);
      $source = str_replace("file_id","nottrue",$source);
      $source = str_replace("fopen","nottrue",$source);
      save("bots/$addres/$nfile.php",$source);
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"فایل با موفقیت ذخیره شد!
آدرس سورس شما:
$web/$bot/bots/$addres/$nfile.php
در صورتی که سورس شما بیش از یک فایل دارد دوباره فایل بعدی را در همین پوشه با نامی دیگر آپلود کنید!",
            ]);
        }
//---------------------------SETWEBHOOK---------------------------
elseif($text1 == "🗝ست وب هوک🗝"){
      file_put_contents("data/$from_id/step.txt","token");
				bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"به بخش ست وب هوک خوش آمدید🌹
آخرین مرحله برای فعال سازی ربات شما💐

توکن ربات خود را ارسال کنید :",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}	elseif($step == "token"){
    file_put_contents("data/$from_id/step.txt","urll");
 $text2 = $message->text;
 file_put_contents("data/$from_id/token.txt","$text2");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"توکن با موفقیت ثبت شد✅
لطفا آدرس سورس (که از ربات دریافت کردید) را ارسال کنید :",
            ]);
        }
        elseif($step == "urll"){
    file_put_contents("data/$from_id/step.txt","setwebhook");
$text2 = $message->text;
 file_put_contents("data/$from_id/url.txt","$text2");
 file_get_contents("https://api.telegram.org/bot$to/setwebhook?url=$url");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"تبریک ربات شما با موفقیت فعال شد✅
حالا میتوانید ربات خود را استارت کنید و ار آن استفاده کنید🌹",
            ]); }
//---------------------------DELWEBHOOK---------------------------
            elseif($text1 == "🔑حذف وب هوک🔑"){
      file_put_contents("data/$from_id/step.txt","tokenn");
				bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"این کار برای آفلاین کردن ربات اصلی است و برای برگشت به حلت آنلاین باید ربات را ست وب هوک کنید⚠️
در صورتی که میخواهید ربات را حذف وب هوک کنید توکن ربات را ارسال کنید:",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
	elseif($step == "tokenn"){
    file_put_contents("data/$from_id/step.txt","none");
 $text2 = $message->text;
 file_get_contents("https://api.telegram.org/bot$text2/setwebhook?url=");
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"تبریک وب هوک با موفقیت از روی ربات شما حذف شد !✨",
            ]);
        }
//---------------------------COINTOVIP--------------------------------
elseif($text1 == "/vipconfig" && $type == "free" or $type == "none"){
    if($coin > 50){
      $coin = file_get_contents("data/$from_id/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin - 50;
          save("data/$from_id/coin.txt",$newcoin);
          file_put_contents("data/$from_id/type.txt","vip");
          file_put_contents("data/$from_id/step.txt","none");
          bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"دوست عزیز مقدار 50 سکه از شما کم شد و حساب شما ویژه شد🌹
تعداد سکه های باقی مانده : $coin",
            ]);
        }else{
     bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"تعداد سکه های شما $coin است ✨
برای ویژه شدن به 50 سکه نیاز دارید!
برای جمع آوری سکه از دستور /mycoins استفاده کنید💎",
            ]);}}
//---------------------------VIP-ACCOUNT------------------------------
elseif($text1 == "🔥حساب ویژه🔥" && $type == "free"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"با سلام کاربر گرامی
شما از پنل رایگان ربات استفاده میکنید💫
در پنل رایگان محدودیت هایی از نظیر 
امکان ساخت یک پوشه❌
امکان آپلود یک فایل داخل پوشه (فایل اصلی سورس)❌
و محدودیت های دیگری هستید📛

با ویژه شدن حساب شما در ربات محدودیت ها رفع شده و شما میتوانید:

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

❎با مبلغ 2 هزار تومان میتوانید حساب خود را در ربات ویژه کنید❎

توجه !
شما میتوانید بصورت رایگان خود را ویژه کنید
تنها با 50 سکه !
تعداد سکه های شما :
$coin
برای افزایش سکه از دستور زیر کمک بگیرید:
/mycoins

اگر حساب شما مقدار سکه لازم برای ویژه شدن را دارد از دستور زیر برای ویژه شدن استفاده کنید:
/vipconfig
👤جهت خرید با بخش پشتیبانی در ارتباط باشید👤"
]);
}
elseif($text1 == "🔥حساب ویژه🔥" && $type == "none"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"با سلام کاربر گرامی
شما از پنل رایگان ربات استفاده میکنید💫
در پنل رایگان محدودیت هایی از نظیر 
امکان ساخت یک پوشه❌
امکان آپلود یک فایل داخل پوشه (فایل اصلی سورس)❌
و محدودیت های دیگری هستید📛

با ویژه شدن حساب شما در ربات محدودیت ها رفع شده و شما میتوانید:

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

❎با مبلغ 2 هزار تومان میتوانید حساب خود را در ربات ویژه کنید❎

توجه !
شما میتوانید بصورت رایگان خود را ویژه کنید
تنها با 50 سکه !
تعداد سکه های شما :
$coin
برای افزایش سکه از دستور زیر کمک بگیرید:
/mycoins

اگر حساب شما مقدار سکه لازم برای ویژه شدن را دارد از دستور زیر برای ویژه شدن استفاده کنید:
/vipconfig
👤جهت خرید با بخش پشتیبانی در ارتباط باشید👤"
]);
}
elseif($text1 == "🔥حساب ویژه🔥" && $type == "vip"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"کاربر گرامی حساب شما در ربات ویژه است✨

امکان ساخت 6 عدد پوشه اختصاصی✅
امکان آپلود نامحدود فایل داخل هر پوشه✅
امکان تغییر نام فایل قبل از آپلود داخل پوشه✅

با تشکر از شما🌹"
]);
}
//---------------------------HELP-------------------------------------
elseif($text1 == "💎راهنما💎"){
    bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"⚠️ توجه ⚠️
خواندن این متن اجباری میباشد !
برای استفاده از ربات ابتدا باید راهنما را مشاهده کنید تا به مشکلی برخورد نکنید✨

ابتدا یک ربات در بات فادر ایجاد کنید و توکن آن را در سورس خود قرار دهید💎
سپس به ربات آمده و روی دکمه ساخت پوشه کلیک کنید (اعضای معمولی فقط یک پوشه دارند)🗂
سپس به بخش آپلود سورس رفته و سورسی که در آن توکن قرار داده اید را ارسال کنید !🔥

✨نصب آسان✨
برای استفاده از این بخش هر مرتبه 1 سکه از حساب شما کم میشود!
ابتدا توکن را در سورس گزاشته و در گام اول سورس را برای ربات ارسال کنید😼
سپس توکن را رسال کنید تا ربات فعال شود🌹

اعضای ویژه ربات :
امکان ساخت 6 پوشه در ربات را دارند ✨
پس از ساخت پوشه برای مشاهده شناسه پوشه خود به بخش (پوشه های من) بروید📁
شناسه پوشه ای که میخواهید در آن سورس آپلود کنید را به یاد بسپارید و به بخش آپلود سورس بیایید📤
در گام اول شناسه پوشه را وارد کنید🌹
در گام دوم نام فایلی که میخواهید آپلود شود وارد کنید🔥
ربات فایل را در پوشه شما آپلود و آدر آن را به شما میدهد💎
برای آپلود بیش از یک فایل دوباره اینکار را انجام دهید اما نام فایل با فایل موجود در پوشه یکی نباشد!📛

📛توجه📛
فایل هایی که به ربات میفرستید نباید فشرده (زیپ) باشند⚠️
فایل حتما در فرمت php باشد!⚠️
استفاده از ربات های کد شده ممنوع و پیگرد قانونی دارد!📛

برای دریافت راهنما :
/help
برای دریافت تعداد سکه ها:
/mycoins
برای دریافت متن درباره:
/about
برای ارتقا ربات به ویژه :
/upgrade
@$channel"
]);
}
//---------------------------SUPPORT----------------------------------
elseif($text1 == '🗣پشتیبانی🗣'){
    file_put_contents("data/$from_id/step.txt","feedback");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در صورت وجود مشکل در ربات پیغام خود را ارسال کنید تا بدست ادمین برسد:️",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
elseif($step == "feedback"){
$text2 = $message->text;
bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"با تشکر از همکاری شما💐
پیام شما به مدیران ارسال شد و به زودی پیگیری خواهد شد✅",
            ]);
                file_put_contents("data/$from_id/step.txt","none");
bot('sendmessage', [
                'chat_id' => $Dev,
                'text' =>"💥پیغام پشتیبانی💥
فردی با نام : $firstname
آیدی : @$username
شناسه : $from_id
در زمان : $time
گزارش  زیر را به شما ارسال کرد :

$text2",
            ]);
}

//---------------------------ADMIN-PANEL---------------------------
elseif($text1 == "/panel"){
    if ($from_id == $Dev) {
        bot('sendmessage', [
                'chat_id' =>$chat_id,
                'text' =>"Hi Admin",
                'parse_mode'=>'html',
      'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>"👤آمار ربات👤"],['text'=>"🎗ارسال همگانی🎗"]],
               	[['text'=>"برگشت به منوی اصلی🔙"]],
              
              ],'resize_keyboard'=>true
        ])
            ]);
        }
        else {
SendMessage($chat_id,"You Are Not Admin");
}
}
        
elseif($text1 == "👤آمار ربات👤" && $chat_id == $Dev){
    $user = file_get_contents("Member.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
	sendmessage($chat_id , "Bot Stats : $member_count" , "html");
}
elseif($text1 == "🎗ارسال همگانی🎗" && $chat_id == $Dev){
    file_put_contents("data/$from_id/step.txt","bc");
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"Please Send Your Message :",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
	  [['text'=>'/panel']],
      ],
      'resize_keyboard'=>true
      ])
  ]);
}
elseif($step == "bc" && $chat_id == $Dev){
    file_put_contents("data/$from_id/step.txt","none");
	bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"Your message Has Been Send",
  ]);
	$all_member = fopen( "Member.txt", "r");
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			SendMessage($user,$text1,"html");
		}
}
elseif (strpos($text1 , "/setvip") !== false ) {
if ($from_id == $Dev) {
$text = str_replace("/setvip ","",$text1);
		save("data/$text/type.txt","vip");
SendMessage($Dev,"*Vip Set: $text*");
}
else {
SendMessage($chat_id,"You Are Not Admin");
}
}
elseif (strpos($text1 , "/delvip") !== false ) {
if ($from_id == $Dev) {
$text = str_replace("/delvip ","",$text1);
		save("data/$text/type.txt","free");
SendMessage($Dev,"*Vip Del: $text*");
}
else {
SendMessage($chat_id,"You Are Not Admin");
}
}
elseif($text1 == "/setcoin" && $from_id == $Dev){
file_put_contents("data/$from_id/step.txt","fromidforcoin");
bot('sendmessage', [
                'chat_id' => $Dev,
                'text' =>"برای انتقال سکه ابتدا شناسه فرد را وارد کنید:",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"برگشت به منوی اصلی🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);
}
        elseif($step == "fromidforcoin"){
    file_put_contents("data/$from_id/step.txt","tedadecoin4set");
$text2 = $message->text;
 file_put_contents("data/$from_id/token.txt",$text2);
 $coin1 = file_get_contents("data/$text2/coin.txt");
bot('sendmessage', [
                'chat_id' => $Dev,
                'text' =>"این فرد $coin1 سکه دارد💎
چه مقدار سکه به فرد افزوده شود؟",
            ]);
        }
        elseif($step == "tedadecoin4set"){
    file_put_contents("data/$from_id/step.txt","none");
$text2 = $message->text;
$coin = file_get_contents("data/$to/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin + $text2;
          save("data/$to/coin.txt",$newcoin);
          $cooin = $coin + $text2;
bot('sendmessage', [
                'chat_id' => $Dev,
                'text' =>"به فرد $text2 سکه اضافه شد و سکه های او تا الان $cooin میباشد!",
            ]);
            bot('sendmessage', [
                'chat_id' => $to,
                'text' =>"مقدار $text2 سکه به شما افزوده شد!🔥",
            ]);
        }
     unlink('error_log');
?>