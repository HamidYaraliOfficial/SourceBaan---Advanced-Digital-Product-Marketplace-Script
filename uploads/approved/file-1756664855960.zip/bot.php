<?php
//Editor @Amir_H1379
//سورس ربات سخنگو عمو جعفر
//یادتون نره بعد ران ست وبهوک + کرون جابز 1دقیقه 2دودقیقه ای 5دقیقه ای حتما بزنید❤️
// پوشه دیتا بسازید
// لاین 17 توکن 
// لاین 42 ایدی ربات بدون @
//لاین 43 ایدی عددی ادمین
// لاین 44 ایدی عددی چنل -100
//لاین 45 ایدی گروه پشتیبانی یا لینک
//لاین 46 ایدی کانال بدون @
// لاین 121 128 135 ایدی عددی گروه خودتونو وارد کنید
//کانال پروکسی ما حتما عضو شید https://t.me/telproksi
date_default_timezone_set('Asia/Tehran');
$time = date('H:i');
error_reporting(0);
define('API_KEY','5814676264:AAHrreWUpHDBjzSBX2QsD-q5lKd284C7ON8'); // توکن ربات
ini_set("log_errors","off");
//------- فانکشن
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------ متغیر
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
//- بخش ادیت --------------------####----
$bottag = "Prooksitytybot";
$admin = "1293982905";
$channel_id = "-1001808297284";$link_GP = "amojafae";
$channel = "telproksi";
////-----دیگر متغیر ها----------$--$-$$$$$-
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$tc = $update->message->chat->type;
$new_chat_member = $message->new_chat_member;
$new_chat_member_id = $new_chat_member->id;
$new_chat_member_first_name = $new_chat_member->first_name;
$new_chat_member_last_name = $new_chat_member->last_name;
$new_chat_member_username = $new_chat_member->username;
$suchi = file_get_contents("data/$chat_id/setnt.txt");
//-----دیگر فانکشن-
function sendphoto($chat_id, $photo, $captionl){
 bot('sendphoto',[
 'chat_id'=>$chat_id,
 'photo'=>$photo,
 'caption'=>$caption,
 ]);
 }
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function DeleteFolder($path){
 if($handle=opendir($path)){
  while (false!==($file=readdir($handle))){
   if($file<>"." AND $file<>".."){
    if(is_file($path.'/'.$file)){ 
     @unlink($path.'/'.$file);
    } 
    if(is_dir($path.'/'.$file)) { 
     deletefolder($path.'/'.$file); 
     @rmdir($path.'/'.$file); 
    }
   }
        }
    }
}

function sendaction($chat_id, $action){
  bot('sendchataction',[
  'chat_id'=>$chat_id,
  'action'=>$action
  ]);
  }
//بخش تایم
if($time == '00:00'){
$botd = [
"ساعت 00:00 شد شب بخیر همگی شب خوبی داشته باشین😍♥️",
];
$r00 = $botd[rand(0, count($botd)-1)];
Deletefolder("data/spam");
rmdir("data/spam");
	bot('sendMessage',[
            'chat_id' =>-1001988517973,
            'text' => "$r00",
            'parse_mode'=>"HTML",
]);
}
if($time == '20:00'){
	bot('sendMessage',[
 'chat_id'=>-1001977660055,
'text'=>"ساعت 20:00 شد شب خوبی داشته باشید گل های تو گروه",
'parse_mode'=>"HTML",
	 ]); 
	 }
	 if($time == '14:00'){
	bot('sendMessage',[
 'chat_id'=>-1001977660055,
'text'=>"ساعت 14:00 شد ظهرتون بخیر روز خوبی داشته باشین عزیزان",
'parse_mode'=>"HTML",
	 ]); 
	 }
	 	 if($time == '07:00'){
	bot('sendMessage',[
 'chat_id'=>-1001977660055,
'text'=>"ساعت 07:00 شد صبح خوبی داشته باشین گل های تو خونه",
'parse_mode'=>"HTML",
	 ]); 
	 }
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
		 $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($textmessage == "‌Hqysisha81735yav" ){
		 bot('sendMessage',[
                    'chat_id'=>$chat_id,
'text'=>"Fuck You!",
                   'parse_mode'=>"HTML",
]); 

}else{
    function Spam($user_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$user_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time = time() + 30;
$spam_status = ["time $time"];
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
bot('SendMessage',[
'chat_id'=>$user_id,
'text'=>"
😐حرامی اسپم نزن کونت میخاره مگه کیر شدی به مدت 30 ثانیه بلاک شدی ادم شدی استارت کن
"
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}}else{
$spam_status = [1,time()+2];
}}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$user_id.json",json_encode($spam_status,true));
}
Spam($from_id);
//____
if($textmessage == "/start" && $tc == "private" or $textmessage == "Back | برگشت" && $tc == "private"){
	$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام خوش اومدی به پیویم عشقم 😍
اگه میخوای از  من استفاده کنی منو به گروهت اد کن 🙄
چون اکثر حرفامو تو گروه واسه دوستان میزنم ❤️
لینک دعوت من به گروهت 
https://t.me/$bottag?startgroup=new",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"• نصب رایگان در گروه •", 'url'=>"https://t.me/$bottag?startgroup=new"]],
              ]
        ])
	 ]); 
	}		 
	elseif($textmessage == "پنل" or $textmessage == "راهنما" or $textmessage == "🍿 راهنمای ربات" ){
	sendaction($chat_id,'typing');
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
<code>از لینک زیر منو ببر گروهت با من گروهتو شلوغ و جذاب کن😂!</code>

❤️لینک دعوت من به گروه خودت 
https://t.me/$bottag?startgroup=new",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"☆افزودن به گروه☆", 'url'=>"https://t.me/$bottag?startgroup=new"]],
              ]
        ])
	 ]); 
	 }
//time
	 elseif($textmessage == "زمان" or $textmessage == "time" ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"⏰ $time",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 }
//add
elseif(strpos($textmessage,"/start@Prooksitytybot") !== false){
 bot('sendMessage',[
'chat_id' => $chat_id,
'text' =>"
✅ *ربات با موفقیت در گروه نصب شد*

😀 *بطور خودکار ربات سخنگو TyTy قادر به فعالیت میباشد*

😎 *اطلاع از فعالیت ربات دستور ( جعفر )*
======================
♻️ *اطلاعات کاربری که ربات رو به گروه افزوده*

♻️ *نام فرد افزودن ربات به گروه* 
*• name :* $first_name 
♻️ *ایدی گروه نصب شده*
*• id* : $chat_id 
♻️ *ساعت ورود ربات* 
*•time* ; $time
============================
‼️ *درصورت وجود هرگونه مشکل به گروه پشتیبانی مراجعه کنید* 
•*link Gp* : @$link_GP
•*channel* : @$channel",
 'parse_mode'=>"MarkDown",
  'reply_to_message_id'=>$message_id,
	 ]); 
	}	
//me	 
		 elseif($textmessage == "من" or $textmessage == "me"){
	 $profile = "https://telegram.me/$username";
 bot('sendphoto',[
'photo'=>$profile,
'chat_id' => $chat_id,
'caption' =>"
#پروفایل_شما  :)
➖➖➖➖➖➖➖
🔹First Name : $first_name
🔹Last Name : $last_name
🔹Username : @$username
🔹id : $chat_id",
  'reply_to_message_id'=>$message_id,
	 ]); 
	}	
		 elseif($textmessage == "ping" or $textmessage == "/ping" or $textmessage == "پینگ" ){
	 $load = sys_getloadavg();
	 $mem = memory_get_usage();
	 $ver = phpversion();  
	bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"
• ᴘɪɴɢ : <code>$load[0]</code>

• ᴍᴇᴍ : <code>$mem KB</code>

• ᴘʜᴘ ᴠᴇʀ : <code>$ver</code>
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
	 }
	 elseif($textmessage == "bot" or $textmessage == "عمو جعفر" or $textmessage == "جعفر" or $textmessage == "ربات"){
$bot = [
"از من بکش بیرون انقد صدام نکن کپک😐",
"دوستت دارم 😐❤️",
"مرگ جعفر بس کن خستم کردی ط😐",
"جووون کارم داری عزیزم😐",
"چه مرگته انقد صدام میکنی😐",
"درد بگیری بگو چته 😐",
"اماده شدم بریم 😐",
"ها 😐",
];
$r = $bot[rand(0, count($bot)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$r",
'reply_to_message_id'=>$message_id,
]);
}
	 elseif($textmessage == "سلام" or $textmessage == "سلوم" or $textmessage == "صلام" or $textmessage == "ثلام"){
$botss = [
"سلام عزیز دلم ",
"سلام خوبی کوچولو",
"سلام عزیزم",
"سلام کسو کونم",
"سلام به روی ماهت جیگر",
"مرگ سلام انقد سلام نکن دیه",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
	 elseif($textmessage == "خوبی" or $textmessage == "خوبین" or $textmessage == "خوبید" or $textmessage == "خوب هستین"){
$botss = [
"بخوبیت عزیزم",
"تو خوب باشی منم خوبم گلم",
"بخوبیت خودت چطوری",
"حالم بستگی به حالت داره",
"مثل همیشه خوبم پفیوز",
"جعفر مگه میشه با تو باشه حالش خوب نباشه",
"بس کن حالم خوبه تا خراب نکنی حالمو ول کن نیستی",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"چخبر") !== false){
$botss = [
"سلامتیت عنتر",
"سلامتیت فقط جیگر",
"سلامتی دوستان گپ",
"سلامتی فقط",
"خبرا دست شماست گل",
"خبری نیست",
"خبر مرگت خخخ",
"دسته تبر ط چون ادم بیخر",
"والا خبری نیست",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"چطوری") !== false){
$botss = [
"خوبم تو چطوری؟",
"هستیم به امید خدا",
"شکر خوبم خودت چطوری",
"همون طورم خخ خودت خوبی",
"بدک نیستم گل خوبم شکر",
"هعی میگذره شکر",
"با ط عالیم جیگر",
"از همیشه بهترم",
"خوبم نگرانم نباش خخخ",
"بس کن خوبم دیگ",
"بهترم شکر",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
	 elseif($textmessage == "پیوی" or $textmessage == "بیا اونور" or $textmessage == "بیا پیوی" or $textmessage == "خصوصی"){
$botss = [
"حرامه پیوی مومئن",
"اهل پیوی نیستم خخخ",
"ادرس بفرست بیام در خونه پیوی چیه",
"اونور اب میام فقط خخخ",
"حسش نیست/:",
"مزاحمت ایجاد نکن کپک",
"اینجا بگو خب همه دوستیم باهم",
"بگو میشنوم حسش نیست بیام",
"اهل پیوی نیستم گل",
"پیویم سوخته خخخ",
"مزاحم بچه مردم نشو پفیوز",
"بزنمت اسم پیوی یادت بره کچل",
"خاصی میتونی بیایی",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
	 elseif($textmessage == "حالم بده" or $textmessage == "حال خرابه" or $textmessage == "حالم داغونه" or $textmessage == "حال بد"){
$botss = [
"چی شده",
"چیشده قربونت برم",
"الهی بمیری",
"جعفر به دورت بگرده چته گلم 😍",
"غصه نخور درست می شه",
"چون میگذرد غمی نیست 🚶‍♀🚶‍♂",
"حالت رو خریدارم عشقم 😍❤️",
"من که رباتم حالم بده تو جای خود داری😂",
"هعی رفیق حال منم خرابه مثل ط",
"درکت میکنم",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
/*
Editor @Amir_H1379
*/
elseif(strpos($textmessage,"⚽") !== false){
$botss = [
"به احتمال زیاد گل میشه",
"پیشبینی میکنم که میزنی بیرون",
"پیشبینی میکنم که با اینکه میخوره به تیرک ولی گل میشه",
"پیشبینی میکنم که یه گل عالی میشه",
"پیشبینی میکنم که گل میشه ولی گلی که دوست دارم نیست",
"90 درصد احتمال داره گل بشه",
"پیشبینی میکنم که میخوره به تیرک",
"گل خوبی زدی ولی باب دلم نبود",
"بلدنیستی من باید گل بزنم",
"پنارتی زن خوبی نیستی",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"کجایی") !== false){
$botss = [
"باید بهت جواب پس بدم😕",
"به تو ربطی نداره کجام😂",
"به توچه😐 ",
"بیرون هستم",
"وایستا اومدم🏇 ",
"رو چشمات",
"تو ابرها",
"تو قلبت",
"تو قلبت😍♥️",
"توی لباسام",
"سر جام 😊",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"خداحافظ") !== false){
$botss = [
"فعلا",
"نرووو سمیههه🥺💔",
"حالا بودی😍 داشتیم میحرفیدیم",
"داری میری؟ دست خدا به همرات👋",
"بای دلم تا فردا برات تنگ میشه",
"زود بر گردی 🙂",
"مواظب خوبیات باش",
"سلام😜",
"جون من بمون🥺",
"عشق من داره میره 🥺",
"فردا بخور های بای",
"✋🏻❤️",
"بسلامت گامشو که نیای",
"بای💙",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"🚶‍♂") !== false){
$botss = [
"اژدها وارد میشود",
"شلغم وارد میشود",
"پفیوز اومد😄",
"عمو پورنگ قدم میزنیه😅",
"شماره بدم پاره کنی دلبر",
"برسونمت جیگر",
"چه جیگری اوف",
"بیا باهم قدم بزنیم تنها نباشی",
"حوصلت سررفته بیچاره",
"بپر بالا بوریم رشت",
"اخی",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"😐") !== false){
$botss = [
"لال شدی چرا 😢",
"چیه خوشگل ندیدی",
"ها چیه",
"😐",
"مرز با این قیافت😐",
"😂دکمه نشو عزیزم",
"حرف بزن زبون بسته 😂",
"چیه چرا اینطوری نگا میکنی بیا منو بخور",
"خاک بر سرت بشه",
"😄",
"چه قیافه میگیره عنتر",
"Love",
"قیافشو قربون😐",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
elseif(strpos($textmessage,"بای") !== false){
$botss = [
"فعلا",
"نرووو سمیههه🥺💔",
" حالا بودی😍 داشتیم میحرفیدیم",
" داری میری؟ دست خدا به همرات👋",
" بای دلم تا فردا برات تنگ میشه",
" زود بر گردی 🙂",
" مواظب خوبیات باش",
" سلام😜",
" جون من بمون🥺",
" عشق من داره میره 🥺",
" فردا بخور های بای",
" ✋🏻❤️",
" بسلامت گامشو که نیای",
"بای💙",
"نروووو",
"خوشحال شدیم",
"رفتی دیگ",
"یک نون خور کم شد",
];
$s = $botss[rand(0, count($botss)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$s",
'reply_to_message_id'=>$message_id,
]);
}
	elseif(strpos($textmessage,"❤️") !== false){
$bots = [
"jon che dafi❤️",
"اوف فدای گلبت",
"چه قلب خوشگلی",
"قلب منی پفیوز",
"قلبتو به هرکسی نده بیشعور خخ",
"مراقب قلبم باش ضعیفه دافی جون❤️",
"اوف اوف اوف",
"رل بزنیم❤️",
"مخمو زدی توله با این قلبت",
"برای منه توله",
"جووووووووون😘",
"بگردم",
];
$b = $bots[rand(0, count($bots)-1)];
	bot('sendMessage',[
            'chat_id' =>$chat_id,
            'text' => "$b",
'reply_to_message_id'=>$message_id,
]);
}
if($textmessage and file_exists("cmd/$textmessage.txt")){
	$textcmd = file_get_contents("cmd/$textmessage.txt");
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$textcmd,
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	    	 //-----admin-panel-----
elseif($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>" به پنل مدیریت خوش آمدید🎈
✅ <code> شما آدمین شناخته شدید </code>
➖➖➖➖➖➖➖➖
💭اسم شما : $first_name
⏳ آیدی عددی : $chat_id
➖➖➖➖➖➖➖➖
👇 یکی از گزینه هارا انتخاب کنید 👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"👥آمار کلی ربات👥"],['text'=>"🍿پاکسازی اسپم"]],
    	[['text'=>"📮پیام همگانی📮"],['text'=>"📤فوروارد همگانی📤"]],
    	[['text'=>"یادگیری"],['text'=>"Back | برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
///*-*-*-*-*-**-*-*-*-*--*-*-*-*-*---
elseif($textmessage == "🔹بازگشت به پنل"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 به منوی اصلی پنل مدیریت #برگشتید!
🔹 <code> درصورتی که نیاز به راهنمایی دارید روی گزینه راهنمای پنل بزنید</code>
➖➖➖➖➖➖➖➖
👇 یکی از گزینه های زیر را انتخاب کنید 👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"👥آمار کلی ربات👥"],['text'=>"🍿پاکسازی اسپم"]],
    	[['text'=>"📮پیام همگانی📮"],['text'=>"📤فوروارد همگانی📤"]],
    	[['text'=>"یادگیری"],['text'=>"Back | برگشت"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
/*
Editor @Amir_H1379
*/
elseif($textmessage == "🍿پاکسازی اسپم"){
Deletefolder("data/spam");
rmdir("data/spam");
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😄🍿 لیست اسپم پاکسازی شد.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😑شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
elseif($textmessage == "یادگیری"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 در این بخش میتونی کلمه یاد بدید.. کلمه حذف کنید و یا کلمه هارو ببینید.
➖➖➖➖➖➖➖➖
👇 یکی از گزینه های زیر را انتخاب کنید 👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    	[['text'=>"📉لیست کلمه ها"]],
    	[['text'=>"😄 یاد دادن کلمه جدید"],['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😑شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
elseif($chat_id == $admin and $textmessage == "📉لیست کلمه ها"){
$list = file_get_contents("cmd/list.txt");
bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"
✏️ لیست کلمه هایی که به من یاد دادی !
➖➖➖➖➖➖➖➖➖➖➖➖
<code>$list</code>",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]); 	
}
elseif($chat_id == $admin and $textmessage == "😄 یاد دادن کلمه جدید"){	
mkdir("cmd");
$user["step"] = "settextanpa";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🔺 متنی که می خواهید ربات به آن پاسخ دهد را بفرستید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}

elseif($step == "settextanpa" and $chat_id == $admin and $textmessage != "🔹بازگشت به پنل"){	
	if(!file_exists("cmd/$textmessage.txt")){
$user["step"] = "set-cmd-text";
$user["gpgramtok"] = $textmessage;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"حالا پاسخ را ارسال کنید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}else{
	  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"❌ این کلمه رو قبلا بلد بودم.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 	
}
}
elseif($step == "set-cmd-text" and $chat_id == $admin and $textmessage != "🔹بازگشت به پنل"){	
$cmds = $user["gpgramtok"];
file_put_contents("cmd/$cmds.txt",$textmessage);
$myfile2 = fopen("cmd/list.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$cmds\n");
fclose($myfile2);
$user["step"] = "none";
$user["gpgramtok"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"✅ ثبت شد.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
//---
elseif($chat_id == $admin and $textmessage == "📮پیام همگانی📮"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال همگانی ارسال نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "🔹بازگشت به پنل"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"HTML",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"HTML",
  ]);
}
//Editor @Amir_H1379
//----
elseif($chat_id == $admin and $textmessage == "📤فوروارد همگانی📤"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}

elseif($textmessage != "🔹بازگشت به پنل" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379
?>llusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>��𝐫_𝐙𝐞𝐮𝐬™
?>sers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>>>s",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>embers.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"HTML",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"HTML",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "📤فوروارد همگانی📤"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}

elseif($textmessage != "🔹بازگشت به پنل" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
// Edtor @Amir_H1379
?>arse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
// Edtor @Amir_H1379
?>🇫🇷]𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>>�™
?>���™
?>🇷]𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>anceIR & @Source_FranceIR
اسکی با ذکر منبع :/
*/
//----
elseif($chat_id == $admin and $textmessage == "📤فوروارد همگانی📤"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}

elseif($textmessage != "🔹بازگشت به پنل" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>��
?>��
?>���𝐫_𝐙𝐞𝐮𝐬™
?>R | [🇫🇷]𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>R | [🇫🇷]𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>R | [🇫🇷]𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>��𝐞𝐮𝐬™
?>�𝐬™
?>
?>
𝐫_𝐙𝐞𝐮𝐬™
?>
log');
//Editor @Amir_H1379?>
��™
?>
𝐫_𝐙𝐞𝐮𝐬™
?>
log');
//Editor @Amir_H1379?>
rdMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>
��™
?>
𝐫_𝐙𝐞𝐮𝐬™
?>
log');
//Editor @Amir_H1379?>
�𝐞𝐮𝐬™
?>

?>
one";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>
��™
?>
𝐫_𝐙𝐞𝐮𝐬™
?>
log');
//Editor @Amir_H1379?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬™
?>
>

?>
>
��™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>
𝐬™
?>
>
ر کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
}
unlink('error_log');
//Editor @Amir_H1379?>
��™
?>
𝐫_𝐙𝐞𝐮𝐬™
?>
log');
//Editor @Amir_H1379?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬™
?>
>

?>
>
��™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>

>
>
𝐮𝐬™
?>
>

�𝐬™
?>
>

>
™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�𝐬™
?>
>

�𝐬™
?>
>

>
™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>
>

�𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐮𝐬™
?>
>

>
>
𝐮𝐬™
?>
>

�𝐬™
?>
>

>
™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
�™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
���𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
��_𝐙𝐞𝐮𝐬™
?>

𝐬™
?>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
>

𝐎𝐬𝐜𝐚𝐫_𝐙𝐞𝐮𝐬™
?>
>
