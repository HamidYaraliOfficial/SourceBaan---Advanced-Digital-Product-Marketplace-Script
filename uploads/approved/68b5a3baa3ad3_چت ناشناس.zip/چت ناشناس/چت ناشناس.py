import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = "YOUR_BOT_TOKEN" #توکن ربات 
ADMIN_ID = 123456789  #آیدی  ادمین

user_data_storage = {}
message_counter = 0

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)
logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "سلام! من ربات ارسال پیام ناشناس هستم.\n"
        "هر پیامی بفرستید، به صورت ناشناس برای ادمین ارسال می‌شود."
    )

async def handle_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global message_counter
    
    user = update.effective_user
    message = update.message
    
    message_counter += 1
    message_id = f"msg_{message_counter}"
    
    user_data_storage[message_id] = user.id
    
    try:
        admin_message = await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=f"📩 پیام از یک کاربر:\n\n{message.text}\n\n"
                 f"برای پاسخ، روی این پیام ریپلای کنید.",
            reply_markup=None
        )
        
        user_data_storage[f"admin_msg_{admin_message.message_id}"] = message_id
        
        await message.reply_text("✅ پیام شما با موفقیت ارسال شد.")
        logger.info(f"پیام از کاربر {user.id} به ادمین ارسال شد. Message ID: {message_id}")
        
    except Exception as e:
        await message.reply_text("❌ خطایی در ارسال پیام رخ داد.")
        logger.error(f"خطا در ارسال پیام: {e}")

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    
    if message.from_user.id != ADMIN_ID:
        return
    
    if not message.reply_to_message:
        await message.reply_text("لطفاً روی یک پیام ریپلای کنید تا پاسخ ارسال شود.")
        return
    
    replied_message_id = message.reply_to_message.message_id
    storage_key = f"admin_msg_{replied_message_id}"
    
    if storage_key not in user_data_storage:
        await message.reply_text("❌ امکان پاسخ به این پیام وجود ندارد. لطفاً فقط به پیام‌های اخیر ریپلای کنید.")
        return
    
    message_id = user_data_storage[storage_key]
    
    if message_id not in user_data_storage:
        await message.reply_text("❌ اطلاعات این پیام یافت نشد.")
        return
    
    user_id = user_data_storage[message_id]
    
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"📨 پاسخ ادمین:\n\n{message.text}"
        )
        await message.reply_text("✅ پاسخ شما ارسال شد.")
        logger.info(f"پاسخ ادمین به کاربر {user_id} ارسال شد")
        
    except Exception as e:
        await message.reply_text("❌ خطایی در ارسال پاسخ رخ داد. ممکن است کاربر ربات را بلاک کرده باشد.")
        logger.error(f"خطا در ارسال پاسخ: {e}")

def main():
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    
    application.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & ~filters.User(ADMIN_ID) & filters.TEXT,
        handle_user_message
    ))
    
    application.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.User(ADMIN_ID) & filters.TEXT,
        handle_admin_message
    ))
    
    print("ربات در حال اجراست...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()