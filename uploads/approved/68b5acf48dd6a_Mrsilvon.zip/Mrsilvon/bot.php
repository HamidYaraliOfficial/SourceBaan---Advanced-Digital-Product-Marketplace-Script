<?php
/**
 * ربات دانلود پیام تلگرام 
 *
 * @author   silvon Developer
 * @contact  https://t.me/Mrsilvon
 * @version  1.1.0
 * @date     2025-07-27
 * @license  Private Use Only - Do Not Distribute
 */
 
$TOKEN = 'توکن_ربات';
$admin_id = 1482706652; // آی‌دی ادمین عددی

$blocked_users_file = 'blocked_users.txt';
$users_file = 'users.txt';

if (!file_exists($blocked_users_file)) file_put_contents($blocked_users_file, '');
if (!file_exists($users_file)) file_put_contents($users_file, '');

function loadIdsFromFile($file) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return array_map('intval', $lines);
}

function saveIdsToFile($file, $data) {
    file_put_contents($file, implode("\n", array_values($data)));
}

$blocked_users = loadIdsFromFile($blocked_users_file);
$users = loadIdsFromFile($users_file);

$input = file_get_contents('php://input');
$update = json_decode($input, true);

function sendMessage($chat_id, $text, $reply_markup = null) {
    global $TOKEN;
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) $data['reply_markup'] = json_encode($reply_markup);
    file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?" . http_build_query($data));
}

function sendCopy($to, $from_msg) {
    global $TOKEN;
    $from_chat_id = $from_msg['chat']['id'];
    $message_id = $from_msg['message_id'];

    $url = "https://api.telegram.org/bot$TOKEN/copyMessage";
    $post_fields = [
        'chat_id' => $to,
        'from_chat_id' => $from_chat_id,
        'message_id' => $message_id
    ];

    file_get_contents($url . '?' . http_build_query($post_fields));
}

function answerCallbackQuery($id, $text = '') {
    global $TOKEN;
    file_get_contents("https://api.telegram.org/bot$TOKEN/answerCallbackQuery?" . http_build_query([
        'callback_query_id' => $id,
        'text' => $text,
        'show_alert' => false
    ]));
}

function sendAdminPanel($chatId) {
    $panelText = "🎛 پنل مدیریت:";
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => "📊 آمار", 'callback_data' => 'admin:stats'],
                ['text' => "📢 ارسال همگانی", 'callback_data' => 'admin:broadcast']
            ],
            [
                ['text' => "🔁 فوروارد به همه", 'callback_data' => 'admin:forward'],
                ['text' => "📋 لیست بلاک‌شده‌ها", 'callback_data' => 'admin:bannedList']
            ],
            [
                ['text' => "🚫 بلاک کاربر", 'callback_data' => 'admin:blockUser'],
                ['text' => "♻️ آنبلاک کاربر", 'callback_data' => 'admin:unblockUser']
            ],
            [
                ['text' => "🟢 روشن کردن بات", 'callback_data' => 'admin:boton'],
                ['text' => "🔴 خاموش کردن بات", 'callback_data' => 'admin:botoff']
            ],

            [
                ['text' => "👨‍💻 سازنده", 'url' => "https://t.me/Mrsilvon"]
            ]
        ]
    ];
    sendMessage($chatId, $panelText, $keyboard);
}

function reloadData() {
    global $blocked_users_file, $users_file, $blocked_users, $users;
    $blocked_users = loadIdsFromFile($blocked_users_file);
    $users = loadIdsFromFile($users_file);
}

function isBotOn() {
    if (!file_exists("bot_status.txt")) return true;
    return trim(file_get_contents("bot_status.txt")) === "on";
}

if (isset($update['message'])) {
    $chat_id = (int)$update['message']['chat']['id'];
    $message_id = $update['message']['message_id'];
    $text = $update['message']['text'] ?? '';

    reloadData();

    if (in_array($chat_id, $blocked_users)) {
        sendMessage($chat_id, "⛔ متاسفم! شما بلاک شده‌اید.");
        exit;
    }

    if (!isBotOn() && $chat_id != $admin_id) {
        sendMessage($chat_id, "🤖 ربات در حال حاضر خاموش است.");
        exit;
    }

    if (!in_array($chat_id, $users)) {
        $users[] = $chat_id;
        saveIdsToFile($users_file, $users);
    }

    if (file_exists("broadcast_mode.txt") && $chat_id == $admin_id) {
        $broadcast_mode = file_get_contents("broadcast_mode.txt");
        if ($broadcast_mode == "on") {
            foreach ($users as $user_id) {
                sendCopy($user_id, $update['message']);
                usleep(150000);
            }
            unlink("broadcast_mode.txt");
            sendMessage($admin_id, "✅ ارسال همگانی با موفقیت انجام شد.");
            exit;
        }
    }

    if (file_exists("forward_mode.txt") && $chat_id == $admin_id) {
        $forward_mode = file_get_contents("forward_mode.txt");
        if ($forward_mode == "on") {
            foreach ($users as $user_id) {
                $from_chat_id = $update['message']['chat']['id'];
                $message_id = $update['message']['message_id'];
                $url = "https://api.telegram.org/bot$TOKEN/forwardMessage?" . http_build_query([
                    'chat_id' => $user_id,
                    'from_chat_id' => $from_chat_id,
                    'message_id' => $message_id
                ]);
                file_get_contents($url);
                usleep(150000);
            }
            unlink("forward_mode.txt");
            sendMessage($admin_id, "✅ فوروارد به همه کاربران انجام شد.");
            exit;
        }
    }

    if (file_exists("block_state.txt") && $chat_id == $admin_id) {
        $state = file_get_contents("block_state.txt");
        if ($state === "on") {
            $block_id = intval($text);
            if ($block_id > 0 && !in_array($block_id, $blocked_users)) {
                $blocked_users[] = $block_id;
                saveIdsToFile($blocked_users_file, $blocked_users);
                sendMessage($block_id, "🚫 شما توسط ادمین بلاک شدید.");
                sendMessage($admin_id, "✅ کاربر $block_id بلاک شد.");
            } else {
                sendMessage($admin_id, "❌ آیدی نامعتبر یا قبلاً بلاک شده است.");
            }
            unlink("block_state.txt");
            exit;
        }
    }

    if (file_exists("unblock_state.txt") && $chat_id == $admin_id) {
        $state = file_get_contents("unblock_state.txt");
        if ($state === "on") {
            $unblock_id = intval($text);
            if ($unblock_id > 0 && in_array($unblock_id, $blocked_users)) {
                $blocked_users = array_diff($blocked_users, [$unblock_id]);
                saveIdsToFile($blocked_users_file, $blocked_users);
                sendMessage($unblock_id, "🚀 شما توسط ادمین آنبلاک شدید.");
                sendMessage($admin_id, "✅ کاربر $unblock_id آنبلاک شد.");
            } else {
                sendMessage($admin_id, "❌ آیدی نامعتبر یا بلاک نشده است.");
            }
            unlink("unblock_state.txt");
            exit;
        }
    }

    if ($text == '/start') {
        if ($chat_id == $admin_id) sendAdminPanel($chat_id);
        else sendMessage($chat_id, "🎉 به ربات خوش آمدی رفیق! فقط پیام بده تا بره پیش ادمین. شاید جوابتو بده، شاید نه! 😅");
        exit;
    }

    if ($text == '/panel' && $chat_id == $admin_id) {
        sendAdminPanel($chat_id);
        exit;
    }

    if ($chat_id == $admin_id && file_exists("reply_to_user.txt")) {
        $target_id = (int)file_get_contents("reply_to_user.txt");
        sendCopy($target_id, $update['message']);
        unlink("reply_to_user.txt");
        sendMessage($chat_id, "✅ پیام فرستاده شد!");
        exit;
    }

    $keyboard = [
        'inline_keyboard' => [
            [['text' => "💬 پاسخ", 'callback_data' => "reply:$chat_id"]],
            [
                ['text' => "✅ خواندن", 'callback_data' => "read:$chat_id"],
                ['text' => "🔗 پیوی", 'url' => "tg://user?id=$chat_id"]

            ],
            [
                ['text' => "🚫 بلاک", 'callback_data' => "block:$chat_id"],
                ['text' => "♻️ آنبلاک", 'callback_data' => "unblock:$chat_id"]
            ]
        ]
    ];

    sendCopy($admin_id, $update['message']);
    sendMessage($admin_id, "📩 پیام جدید از کاربر: <code>$chat_id</code>", $keyboard);
    sendMessage($chat_id, "✅ پیام شما ارسال شد! حالا بریم دعا کنیم جواب بده 🚀");
}

if (isset($update['callback_query'])) {
    $data = $update['callback_query']['data'];
    $cid = (int)$update['callback_query']['from']['id'];
    $callback_id = $update['callback_query']['id'];

    reloadData();

    if ($cid != $admin_id) {
        answerCallbackQuery($callback_id, "⛔ فقط ادمین اجازه دارد!");
        exit;
    }

    switch ($data) {
        case "admin:stats":
            $count = count($users);
            $text = "📊 تعداد کاربران ثبت شده: $count";
            answerCallbackQuery($callback_id, $text);
            sendMessage($cid, $text);
            break;

        case "admin:broadcast":
            answerCallbackQuery($callback_id, "💡 لطفا پیام همگانی را ارسال کنید:");
            file_put_contents("broadcast_mode.txt", "on");
            break;

        case "admin:forward":
            answerCallbackQuery($callback_id, "💡 لطفا پیام برای فوروارد به همه ارسال کنید:");
            file_put_contents("forward_mode.txt", "on");
            break;

        case "admin:blockUser":
            answerCallbackQuery($callback_id, "🚫 لطفا آیدی کاربر برای بلاک وارد کنید:");
            file_put_contents("block_state.txt", "on");
            break;

        case "admin:unblockUser":
            answerCallbackQuery($callback_id, "♻️ لطفا آیدی کاربر برای آنبلاک وارد کنید:");
            file_put_contents("unblock_state.txt", "on");
            break;

        case "admin:bannedList":
            $blockedListText = "🚫 لیست کاربران بلاک‌شده:\n";
            foreach ($blocked_users as $buser) {
                $blockedListText .= "• <code>$buser</code>\n";
            }
            sendMessage($cid, $blockedListText ?: "لیست بلاک شده‌ها خالی است.");
            answerCallbackQuery($callback_id);
            break;

        case "admin:boton":
            file_put_contents("bot_status.txt", "on");
            sendMessage($cid, "🤖 ربات روشن شد.");
            answerCallbackQuery($callback_id, "بات روشن شد");
            break;

        case "admin:botoff":
            file_put_contents("bot_status.txt", "off");
            sendMessage($cid, "🤖 ربات خاموش شد.");
            answerCallbackQuery($callback_id, "بات خاموش شد");
            break;

    

        default:
            if (preg_match('/^(reply|read|block|unblock):(\d+)$/', $data, $matches)) {
                $action = $matches[1];
                $target_id = intval($matches[2]);

                if ($action == "reply") {
                    file_put_contents("reply_to_user.txt", $target_id);
                    answerCallbackQuery($callback_id, "💬 لطفاً پیام خود را تایپ کنید.");
                } elseif ($action == "read") {
                    answerCallbackQuery($callback_id, "✅ پیام خوانده شد.");
                    sendMessage($target_id, "✅ پیام شما توسط ادمین خوانده شد. ممنون که با ما در ارتباطی!");
                } elseif ($action == "block") {
                    if (!in_array($target_id, $blocked_users)) {
                        $blocked_users[] = $target_id;
                        saveIdsToFile($blocked_users_file, $blocked_users);
                        sendMessage($target_id, "🚫 شما توسط ادمین بلاک شدید.");
                        answerCallbackQuery($callback_id, "کاربر بلاک شد.");
                    } else {
                        answerCallbackQuery($callback_id, "کاربر قبلاً بلاک شده است.");
                    }
                } elseif ($action == "unblock") {
                    if (in_array($target_id, $blocked_users)) {
                        $blocked_users = array_diff($blocked_users, [$target_id]);
                        saveIdsToFile($blocked_users_file, $blocked_users);
                        sendMessage($target_id, "🚀 شما آنبلاک شدید.");
                        answerCallbackQuery($callback_id, "کاربر آنبلاک شد.");
                    } else {
                        answerCallbackQuery($callback_id, "کاربر بلاک نیست.");
                    }
                }
            }
            break;
    }
}
