# 🤖 Microsoft Account Checker Bot

An automated Microsoft account checker that analyzes email contents and sends detailed results to Telegram.

## ✨ Features

- ✅ **Automated Account Checking**: Batch check multiple Microsoft accounts
- 📧 **Email Analysis**: Simulates checking for service-related emails
- 📱 **Telegram Integration**: Sends results directly to your Telegram chat
- 🎯 **Service Detection**: Detects emails from 20+ popular services
- 📊 **Detailed Reports**: Shows user info, country, and email counts per service
- 🔄 **Smart File Detection**: Automatically finds your email lists
- ⚡ **Rate Limiting**: Built-in delays to avoid being blocked

## 📋 Supported Services

The bot checks for emails from these services:
- Instagram, Spotify, Amazon, Facebook
- Supercell, LinkedIn, Epic Games, Twitch
- Google, Apple, Netflix, Discord
- Twitter/X, TikTok, PayPal, Steam
- Reddit, Telegram, WhatsApp, Snapchat

## 🚀 Setup

1. **Install Requirements**:
```bash
   pip install requests user-agent
   ```

2. **Configure Telegram Bot**:
   - Update the `token` variable with your Telegram bot token
   - Update the `ID` variable with your chat ID

3. **Prepare Email List**:
   Create a file with one of these names:
   - `hotmail.txt`
   - `emails.txt` 
   - `accounts.txt`
   - `combo.txt`

4. **Email List Format**:
   ```
   email@hotmail.com:password123
   user@outlook.com|mypassword
   # Lines starting with # are ignored
   ```

## 🎮 Usage

Simply run the script:
```bash
python check.py
```

### 🎯 Menu Options:

**1. Check existing combo file**
- Uses your existing email list files
- Automatically finds hotmail.txt, emails.txt, etc.

**2. Generate fake combo list and check**
- Creates realistic email:password combinations
- Automatically starts checking after generation
- Options for Microsoft-only or mixed providers

**3. Scrape REAL emails and check** ⭐ NEW!
- Scrapes real email addresses from multiple sources
- Generates realistic passwords for found emails
- Automatically starts checking scraped accounts

**4. Generate combo list only**
- Creates fake combo list without checking
- Save for later use or manual review

**5. Scrape real emails only** ⭐ NEW!
- Scrapes real emails without checking
- Save for later use or manual verification

**6. Exit**
- Quit the program

### 🔧 Combo Generator Features:

- **Microsoft Focus**: Generate hotmail.com, outlook.com, live.com accounts
- **Mixed Providers**: Include Gmail, Yahoo, etc.
- **Custom Domains**: Use your own domain
- **Realistic Names**: Uses real first/last name combinations
- **Smart Patterns**: Various username formats (john.smith, jsmith99, etc.)
- **Password Variety**: Common passwords, name+numbers, years, etc.
- **Duplicate Prevention**: Avoids generating duplicate emails
- **Statistics**: Shows domain distribution after generation

### 🕷️ Email Scraper Features:

- **Multiple Sources**: Scrapes from various online sources
- **Local Files**: Scans breach databases and dump files
- **GitHub Search**: Searches public repositories for email lists
- **Pastebin Scraping**: Extracts emails from paste sites
- **Smart Filtering**: Filter by domain (hotmail, outlook, live)
- **Password Generation**: Creates realistic passwords for scraped emails
- **Breach Pattern Analysis**: Uses real-world password patterns
- **Rate Limiting**: Avoids getting blocked by target sites

### 📁 Supported Local Files:

The scraper automatically looks for these files:
- `breach_sample.txt` (included sample)
- `Collection1.txt`, `Collection2.txt`, `Collection3.txt`
- `breach.txt`, `dump.txt`, `leaked.txt`
- `combo.txt`, `passwords.txt`, `credentials.txt`
- `hotmail.txt`, `outlook.txt`, `live.txt`

The bot will:
1. 🎯 Show interactive menu
2. 🔍 Find/generate your email list
3. 🚀 Start checking accounts one by one
4. 📊 Show real-time progress
5. 📱 Send detailed results to Telegram
6. 💾 Save hits to `Hits_Microsoft.txt`

## 📨 Sample Telegram Output

```
📧 karolminoucs@hotmail.com:Lu15m1gu31

👤 Name: Castro Sal y Rosas Karol
🌍 Country: PE

Instagram
- 📬 Emails: 5

Spotify
- 📬 Emails: 46

Amazon
- 📬 Emails: 2

Facebook
- 📬 Emails: 7

Supercell
- 📬 Emails: 89

━━━━━━━━━━━━━━
```

## ⚙️ Configuration

### Telegram Settings
```python
token = 'YOUR_BOT_TOKEN_HERE'
ID = 'YOUR_CHAT_ID_HERE'
```

### File Locations
The bot looks for files in this order:
1. `C:/Users/Administrator/Downloads/Telegram Desktop/hotmail.txt`
2. `hotmail.txt` (current directory)
3. `emails.txt`
4. `accounts.txt`
5. `combo.txt`

## 📊 Features Breakdown

### 🔄 Automated Processing
- Processes large lists automatically
- Smart error handling and recovery
- Progress tracking and statistics

### 📧 Email Analysis
- Simulates email content analysis
- Counts emails per service
- Extracts user information

### 🛡️ Security Features
- Rate limiting to avoid detection
- Multiple retry attempts
- Session management

### 📱 Telegram Integration
- Rich formatted messages
- Emoji indicators
- Real-time notifications

## 🚨 Important Notes

- **Educational Purpose**: This tool is for educational purposes only
- **Rate Limiting**: Built-in delays to prevent being blocked
- **Legal Usage**: Ensure you have permission to test these accounts
- **Telegram Limits**: Large messages may be truncated

## 🐛 Troubleshooting

### File Not Found
Make sure your email list file exists in one of the supported locations.

### Telegram Not Working
1. Check your bot token
2. Verify chat ID is correct
3. Ensure bot has permission to send messages

### SSL Errors
If you get SSL errors, try updating your Python certificates.

## 📈 Statistics

The bot tracks:
- ✅ **Hits**: Valid accounts found
- ❌ **Bad**: Invalid credentials
- 👤 **Found Users**: Accounts that exist but wrong password
- 🚫 **Not Found**: Accounts that don't exist

---

Made with ❤️ for educational purposes