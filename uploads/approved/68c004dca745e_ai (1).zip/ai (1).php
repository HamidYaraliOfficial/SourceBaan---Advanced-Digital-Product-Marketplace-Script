<?php
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

$TOKEN = " توکنتون"; 
$API_URL = "https://api.telegram.org/bot$TOKEN/";

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
function telegramCall($method, $payload = []) {
    global $API_URL;
    $url = $API_URL . $method;
    $ch = curl_init($url);
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    $resp = curl_exec($ch);
    curl_close($ch);
    return @json_decode($resp, true);
} 
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

function sendMessage($chat_id, $text, $reply_to_message_id = null, $parse_mode = null, $reply_markup = null) {
    $payload = ['chat_id'=>$chat_id,'text'=>$text];
    if($reply_to_message_id) $payload['reply_to_message_id'] = (int)$reply_to_message_id;
    if($parse_mode) $payload['parse_mode'] = $parse_mode;
    if($reply_markup) $payload['reply_markup'] = $reply_markup;
    return telegramCall('sendMessage', $payload);
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

function sendPhoto($chat_id, $photo_url, $caption, $reply_to_message_id = null) {
    $payload = [
        'chat_id'=>$chat_id,
        'photo'=>$photo_url,
        'caption'=>$caption
    ];
    if($reply_to_message_id) $payload['reply_to_message_id'] = (int)$reply_to_message_id;
    return telegramCall('sendPhoto', $payload);
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

function getReplyChain($message) {
    $chain = [];
    while(isset($message['reply_to_message'])) {
        $message = $message['reply_to_message'];
        $author = $message['from']['username'] ?? $message['from']['first_name'] ?? 'unk';
        $text = $message['text'] ?? '';
        $chain[] = "$author: $text";
    }
    return array_reverse($chain);
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

$update = json_decode(file_get_contents("php://input"), true);
if(!$update) exit;

$message = $update['message'] ?? $update['edited_message'] ?? null;
if(!$message) exit;
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

$chat = $message['chat'] ?? null;
$chat_id = $chat['id'] ?? null;
$chat_type = $chat['type'] ?? null;
$message_id = $message['message_id'] ?? null;
$text = $message['text'] ?? '';

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
if($chat_type === "private" && trim($text) === "/start") {
    $welcome = "👋 سلام! من *هوشی* هستم — دستیار هوش مصنوعی فارسی.\n\n".
               "می‌تونی از من توی گروه‌ها سؤالات عمومی و محاوره‌ای بپرسی؛ کافی اسمم رو صدا بزنی:\n\n".
               "`هوشی سلام`  یا  `هوشی چی خبر؟`\n\n".
               "همچنین برای ساخت تصویر : هوشی تصویر بتمن".
               "برای افزودن من به گروه، دکمه زیر رو بزن:";
    $keyboard = ["inline_keyboard"=>[[["text"=>"➕ افزودن به گروه","url"=>"https://t.me/Hooshi_AiBot?startgroup=true"]]]];
    sendMessage($chat_id, $welcome, null, "Markdown", $keyboard);
    exit;
}

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
if($chat_type !== "group" && $chat_type !== "supergroup") exit;

$is_call = false;
$user_query = "";
$is_image = false;

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
if(mb_stripos($text,"هوشی") !== false) {
    $is_call = true;
    $user_query = trim(str_ireplace("هوشی","",$text));

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
    if(mb_stripos($user_query,"تصویر") === 0) {
        $is_image = true;
        $user_query = trim(mb_substr($user_query, mb_strlen("تصویر")));
    }
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

if(!$is_call && isset($message['reply_to_message'])) {
    $reply_to = $message['reply_to_message'];
    if(($reply_to['from']['is_bot'] ?? false) === true) {
        $is_call = true;
        $user_query = trim($text);
    }
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

if(!$is_call) exit;
if($is_call && $user_query === "") {
    sendMessage($chat_id, "🤖 بگو چی می‌خوای !", $message_id);
    exit;
}

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

if($is_image) {
    $img_url = "https://mionapi.ir/api/imageai/dalle-3.php?prompt=" . urlencode($user_query);
    $caption = "🌐 MionApi.ir\n📢 @Mion_Api\n👨‍💻 پشتیبانی: @Artin_Hastame | @Mani_Coder";
    sendPhoto($chat_id, $img_url, $caption, $message_id);
    exit;
}

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

$replyChain = getReplyChain($message);
$full_query = (!empty($replyChain) ? implode("\n", $replyChain)."\n" : "") . $user_query;
$api_url = "https://mionapi.ir/api/ai/gpt3-5.php?q=" . urlencode($full_query);
$api_resp = @file_get_contents($api_url);
$data = @json_decode($api_resp,true);
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

if(isset($data['code']) && $data['code']==200 && isset($data['answer'])) {
    $answer = $data['answer'];
    $website = $data['Website'] ?? '';
    $channel = $data['Channel'] ?? '';
    $support = isset($data['Support']) ? implode(' | ',$data['Support']) : '';
    $final = $answer . "\n\n🌐 $website\n📢 $channel\n👨‍💻 پشتیبانی: $support";
} else {
    $final = "❌ سرویس هوش مصنوعی موقتاً در دسترس نیست. لطفاً بعداً دوباره تلاش کنید.";
}
// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس

sendMessage($chat_id, $final, $message_id);

// اولین بار در @mion_apiاوپن شده بدون منبع جایی نبینم
// نویسنده : تیم میون وبسرویس
