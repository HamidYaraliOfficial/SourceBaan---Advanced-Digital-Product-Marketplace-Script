from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters
)
import logging

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


TOKEN = 'BOT_TOKEN' #توکن ربات 

ADMIN_CHAT_ID = 123456789 #چت آیدی شما 

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    
    if update.effective_chat.id == ADMIN_CHAT_ID:
        await update.message.reply_text(
            "سلام ادمین! چت آیدی کاربر را ارسال کنید تا یوزرنیم آن را پیدا کنم."
        )

async def handle_chat_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    
    if update.effective_chat.id != ADMIN_CHAT_ID:
        return
        
    try:
        chat_id = update.message.text.strip()
        
        if not chat_id.lstrip('-').isdigit():
            await update.message.reply_text(
                "⚠️ لطفاً یک چت آیدی معتبر ارسال کنید (فقط عدد)"
            )
            return
            
        chat_id = int(chat_id)
        user = await context.bot.get_chat(chat_id)
        
        if user.username:
            response = f"🆔 چت آیدی: {chat_id}\n👤 یوزرنیم: @{user.username}"
        else:
            response = f"🆔 چت آیدی: {chat_id}\n⚠️ این کاربر یوزرنیم ندارد"
            
        await update.message.reply_text(response)
        
    except Exception as e:
        logger.error(f"Error: {e}")
        await update.message.reply_text('❌ خطا در دریافت اطلاعات کاربر. مطمئن شوید چت آیدی صحیح است و ربات با کاربر تعامل داشته است.')

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_chat_id))
    
    logger.info("ربات در حال اجراست...")
    app.run_polling()

if __name__ == "__main__":
    main()