import os
import re
import json
import requests
from datetime import datetime
import telebot
from telebot import types

TOKEN = '8476419974:AAHzVeOn5nI-dT76p5YJUtFFgQlsLbeTLM0'
ADMIN_ID = 8272359057  # آیدی ادمین
API_URL = 'https://api.fast-creat.ir/nobitex/v2?apikey=1482706652:OKgqGoiu8wlYJbP@Api_ManagerRoBot'
GOLD_API_URL = 'https://api.fast-creat.ir/gold?apikey=1482706652:FpB0xDHYzM38NtW@Api_ManagerRoBot'

bot = telebot.TeleBot(TOKEN)

MANUAL_ALIASES = {
    'طلا': 'gold',
    'دلار': 'tether',
    'تتر': 'tether',
    'تون': 'ton',
    'ترون': 'trx',
    'اتریوم': 'eth',
    'اتریوم کلاسیک': 'etc',
    'بیت کوین': 'btc',
    'بیت کوین کش': 'bch',
    'دوج کوین': 'doge',
    'پالیگان': 'pol',
    'استلار': 'xlm',
    'کاردانو': 'ada',
    'چین لینک': 'link',
    'یونی سواپ': 'uni',
    'دای': 'dai',
    'پولکادات': 'dot',
    'آوه': 'aave',
    'اکسی': 'axs',
    'دیسنترالند': 'mana',
    'سندباکس': 'sand',
    'آوالانچ': 'avax',
    'یو اس دی کوین': 'usdc',
    'استپن': 'gmt',
    'میکر': 'mkr',
    'سولانا': 'sol',
    'اتم': 'atom',
    'گراف': 'grt',
    'بت': 'bat',
    'نیر پروتکل': 'near',
    'ایپ کوین': 'ape',
    'کوانت': 'qnt',
    'چیلیز': 'chz',
    'مونرو': 'xmr',
    'گالا': 'egala',
    'الگورند': 'algo',
    'هدرا': 'hbar',
    'وان ایچ نتورک': '1inch',
    'یرن فایننس': 'yfi',
    'فلو': 'flow',
    'سینتتیکس': 'snx',
    'انجین کوین': 'enj',
    'کرو دائو توکن': 'crv',
    'فایل کوین': 'fil',
    'رپد بیت کوین': 'wbtc',
    'لیدو دائو': 'ldo',
    'دی وای دی ایکس': 'dydx',
    'اپتاس': 'apt',
    'مسک نتورک': 'mask',
    'کامپاند': 'comp',
    'بالانسر': 'bal',
    'لوپرینگ': 'lrc',
    'لایوپیر': 'lpt',
    'اتریوم نیم سرویس': 'ens',
    'سوشی سواپ': 'sushi',
    'ای پی آی 3': 'api3',
    'هارمونی': 'one',
    'گولم': 'glm',
    'پیمان': 'pmn',
    'دائو میکر': 'dao',
    'سیویک': 'cvc',
    'نومریر': 'nmr',
    'استورج': 'storj',
    'استاتوس': 'snt',
    'آراگون': 'ant',
    'زیرو ایکس': 'zrx',
    'اسموث لاو پوشن': 'slp',
    'مولتی ورس ایکس': 'egld',
    'ایموتبل ایکس': 'imx',
    'بلر': 'blur',
    '100 هزار فلوکی': '100k_floki',
    '1 میلیارد بیبی دوج': '1b_babydoge',
    '1 میلیون ایپ ان اف تی': '1m_nft',
    '1 میلیون بیت تورنت': '1m_btt',
    'ترشولد': 't',
    'سلر نتورک': 'celr',
    'اربیتروم': 'arb',
    'مجیک': 'magic',
    'جی ام اکس': 'gmx',
    'بند': 'band',
    'کانوکس فایننس': 'cvx',
    'اس اس وی نتوورک': 'ssv',
    'مرژبل دیتا': 'mdt',
    'او ام جی نتورک': 'omg',
    'ورلد کوین': 'wld',
    'رادیانت کپیتال': 'rdnt',
    'جاست': 'jst',
    'بیکو': 'bico',
    'وو نتورک': 'woo',
    'اسکیل': 'skl',
    'گلکس': 'gal',
    'سینگولاریتی نت': 'agix',
    'فچ ای آی': 'fet',
    'فانتوم': 's',
}

USERS_FILE = 'users.txt'
GROUPS_FILE = 'groups.txt'
BLOCKED_FILE = 'blocked.txt'
BOT_STATUS_FILE = 'bot_status.txt'
PENDING_FILE = 'pending_actions.txt'

def fa_num_to_en(text):
    fa_digits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
    en_digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    for f, e in zip(fa_digits, en_digits):
        text = text.replace(f, e)
    return text

def save_user(user_id):
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w'): pass
    
    with open(USERS_FILE, 'r+') as f:
        users = f.read().splitlines()
        if str(user_id) not in users:
            f.write(f"{user_id}\n")

def save_group(group_id):
    if not os.path.exists(GROUPS_FILE):
        with open(GROUPS_FILE, 'w'): pass
    
    with open(GROUPS_FILE, 'r+') as f:
        groups = f.read().splitlines()
        if str(group_id) not in groups:
            f.write(f"{group_id}\n")

def add_blocked(user_id):
    if not os.path.exists(BLOCKED_FILE):
        with open(BLOCKED_FILE, 'w'): pass
    
    with open(BLOCKED_FILE, 'r+') as f:
        blocked = f.read().splitlines()
        if str(user_id) not in blocked:
            f.write(f"{user_id}\n")

def remove_blocked(user_id):
    if not os.path.exists(BLOCKED_FILE):
        return
    
    with open(BLOCKED_FILE, 'r') as f:
        blocked = f.read().splitlines()
    
    blocked = [u for u in blocked if u != str(user_id)]
    
    with open(BLOCKED_FILE, 'w') as f:
        f.write('\n'.join(blocked))

def is_blocked(user_id):
    if not os.path.exists(BLOCKED_FILE):
        return False
    with open(BLOCKED_FILE, 'r') as f:
        blocked = f.read().splitlines()
    return str(user_id) in blocked

def set_bot_status(status):
    with open(BOT_STATUS_FILE, 'w') as f:
        f.write('enabled' if status else 'disabled')

def get_bot_status():
    if not os.path.exists(BOT_STATUS_FILE):
        return True 
    with open(BOT_STATUS_FILE, 'r') as f:
        return f.read().strip() == 'enabled'

def set_pending_action(user_id, action):
    pending = {}
    if os.path.exists(PENDING_FILE):
        with open(PENDING_FILE, 'r') as f:
            try:
                pending = json.load(f)
            except:
                pending = {}
    
    pending[str(user_id)] = action
    
    with open(PENDING_FILE, 'w') as f:
        json.dump(pending, f)

def get_pending_action(user_id):
    if not os.path.exists(PENDING_FILE):
        return None
    
    with open(PENDING_FILE, 'r') as f:
        try:
            pending = json.load(f)
            return pending.get(str(user_id))
        except:
            return None

def clear_pending_action(user_id):
    if not os.path.exists(PENDING_FILE):
        return
    
    with open(PENDING_FILE, 'r') as f:
        try:
            pending = json.load(f)
        except:
            return
    
    if str(user_id) in pending:
        del pending[str(user_id)]
    
    with open(PENDING_FILE, 'w') as f:
        json.dump(pending, f)

def get_gold_price():
    try:
        response = requests.get(GOLD_API_URL, timeout=10)
        data = response.json()
        
        if not data.get('ok'):
            return None
        
        for item in data.get('result', []):
            if item.get('title', '').lower() == 'طلای 18 عیار / 750':
                return item.get('price', [0])[0]
        
        return None
    except Exception as e:
        print(f"Error getting gold price: {e}")
        return None

def get_coin_data():
    try:
        response = requests.get(API_URL, timeout=10)
        data = response.json()
        
        if not data.get('result'):
            return None
        
        coins = {}
        for sym, coin_data in data['result'].items():
            sym_lower = sym.lower()
            name_lower = coin_data['name'].lower()
            coins[sym_lower] = coin_data
            coins[name_lower] = coin_data
        
        return coins
    except Exception as e:
        print(f"Error getting coin data: {e}")
        return None

def get_group_invite_link(group_id):
    try:
        chat = bot.get_chat(group_id)
        if chat.invite_link:
            return chat.invite_link
        return None
    except:
        return None

def broadcast_to_users(text):
    if not os.path.exists(USERS_FILE):
        return 0
    
    with open(USERS_FILE, 'r') as f:
        users = f.read().splitlines()
    
    success = 0
    for user_id in users:
        if is_blocked(user_id):
            continue
        
        try:
            bot.send_message(user_id, text, parse_mode='HTML')
            success += 1
            time.sleep(0.2)
        except:
            continue
    
    return success

def forward_to_all(from_chat_id, message_id):
    forwarded = 0
    
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            users = f.read().splitlines()
        
        for user_id in users:
            if is_blocked(user_id):
                continue
            
            try:
                bot.forward_message(user_id, from_chat_id, message_id)
                forwarded += 1
                time.sleep(0.15)
            except:
                continue
    
    if os.path.exists(GROUPS_FILE):
        with open(GROUPS_FILE, 'r') as f:
            groups = f.read().splitlines()
        
        for group_id in groups:
            try:
                bot.forward_message(group_id, from_chat_id, message_id)
                forwarded += 1
                time.sleep(0.15)
            except:
                continue
    
    return forwarded

def get_target_user_id(message):
    if message.reply_to_message:
        return message.reply_to_message.from_user.id
    
    text = message.text.strip()
    if text.isdigit():
        return int(text)
    
    if message.forward_from:
        return message.forward_from.id
    
    return None

@bot.message_handler(commands=['start'])
def send_welcome(message):
    save_user(message.from_user.id)
    welcome_text = (
        "👋 سلام! به ربات قیمت لحظه‌ای ارز دیجیتال خوش آمدید.\n"
        "💡 می‌توانید نام یا نماد ارز مورد نظر خود را ارسال کنید تا قیمت و اطلاعات آن را دریافت کنید.\n"
        "\n"
        "مثال‌ها:\n"
        "• بیت کوین\n"
        "• 0.5 اتریوم\n"
        "• 2 USDT"
    )
    bot.reply_to(message, welcome_text)

@bot.message_handler(commands=['admin'])
def admin_panel(message):
    if message.from_user.id != ADMIN_ID:
        return
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.row(
        types.InlineKeyboardButton("📊 آمار", callback_data='stats'),
    )
    keyboard.row(
        types.InlineKeyboardButton("🔄 فوروارد", callback_data='forward'),
        types.InlineKeyboardButton("📢 همگانی", callback_data='broadcast')
    )
    keyboard.row(
        types.InlineKeyboardButton("✅ آنبلاک", callback_data='unblock'),
        types.InlineKeyboardButton("🚫 بلاک", callback_data='block')
    )
    keyboard.row(
        types.InlineKeyboardButton("🔴 خاموش", callback_data='disable'),
        types.InlineKeyboardButton("🟢 روشن", callback_data='enable')
    )
    keyboard.row(
        types.InlineKeyboardButton("📁 لیست گروه‌ها", callback_data='list_groups')
    )
    
    bot.send_message(message.chat.id, "پنل مدیریت ربات:", reply_markup=keyboard)

@bot.message_handler(func=lambda message: True)
def handle_messages(message):
    if message.chat.type == 'private':
        save_user(message.from_user.id)
    elif message.chat.type in ['group', 'supergroup']:
        save_group(message.chat.id)
    
    if not get_bot_status() and message.from_user.id != ADMIN_ID:
        return
    
    if message.from_user.id == ADMIN_ID:
        pending_action = get_pending_action(message.from_user.id)
        
        if pending_action == 'broadcast':
            handle_broadcast(message)
            return
        elif pending_action == 'forward':
            handle_forward(message)
            return
        elif pending_action in ['block', 'unblock']:
            handle_block_unblock(message, pending_action)
            return
    
    text = fa_num_to_en(message.text.lower().strip())
    
    if text in ['طلا', 'gold'] or any(t in text for t in ['طلا', 'gold']):
        handle_gold_request(message)
        return
    
    handle_coin_request(message)

def handle_broadcast(message):
    if message.text:
        success = broadcast_to_users(message.text)
        bot.reply_to(message, f"✅ پیام همگانی به {success} کاربر ارسال شد.")
    else:
        try:
            forwarded = forward_to_all(message.chat.id, message.message_id)
            bot.reply_to(message, f"✅ پیام به {forwarded} کاربر/گروه فوروارد شد.")
        except Exception as e:
            bot.reply_to(message, f"⚠️ خطا در فوروارد پیام: {e}")
    
    clear_pending_action(message.from_user.id)

def handle_forward(message):
    try:
        forwarded = forward_to_all(message.chat.id, message.message_id)
        bot.reply_to(message, f"✅ پیام به {forwarded} کاربر/گروه فوروارد شد.")
    except Exception as e:
        bot.reply_to(message, f"⚠️ خطا در فوروارد پیام: {e}")
    
    clear_pending_action(message.from_user.id)

def handle_block_unblock(message, action):
    target_id = get_target_user_id(message)
    if not target_id:
        bot.reply_to(message, "⚠️ نتوانستم آیدی کاربر را استخراج کنم. لطفا آیدی عددی را بفرستید یا به پیام کاربر ریپلای کنید.")
        return
    
    if action == 'block':
        add_blocked(target_id)
        bot.reply_to(message, f"🚫 کاربر با آیدی {target_id} بلاک شد.")
    else:
        remove_blocked(target_id)
        bot.reply_to(message, f"✅ کاربر با آیدی {target_id} آنبلاک شد.")
    
    clear_pending_action(message.from_user.id)

def handle_gold_request(message):
    text = fa_num_to_en(message.text.lower().strip())

    amount = 1
    match = re.match(r'^(\d+\.?\d*)\s*(?:گرم)?\s*(?:طلا|gold)', text)
    if match:
        try:
            amount = float(match.group(1))
        except:
            amount = 1
    
    gold_price = get_gold_price()
    if gold_price is None:
        bot.reply_to(message, "⚠️ متاسفانه نتوانستم قیمت طلا را دریافت کنم. لطفا بعدا تلاش کنید.")
        return
    
    gold_price_toman = gold_price / 10
    total_price = amount * gold_price_toman
    
    msg = (
        f"💰 قیمت لحظه‌ای طلای ۱۸ عیار برای {amount} گرم:\n"
        f"{int(total_price):,} تومان\n\n"
        f"📅 آخرین بروزرسانی: {datetime.now().strftime('%Y/%m/%d | %H:%M:%S')}"
    )
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(
        types.InlineKeyboardButton("➕ اضافه کردن به گروه", url="https://t.me/Toman_RateBot?startgroup=start")
    )
    
    bot.reply_to(message, msg, reply_markup=keyboard)

def handle_coin_request(message):
    text = fa_num_to_en(message.text.lower().strip())
    
    amount = 1
    coin_key = text
    
    parts = text.split()
    if len(parts) > 1 and parts[0].replace('.', '').isdigit():
        amount = float(parts[0])
        coin_key = ' '.join(parts[1:])
    elif any(c.isdigit() for c in text):
        match = re.match(r'^(\d+\.?\d*)\s*([^\d]+)$', text)
        if match:
            amount = float(match.group(1))
            coin_key = match.group(2).strip()
    
    coin_key = MANUAL_ALIASES.get(coin_key, coin_key)
    
    coins = get_coin_data()
    if not coins:
        bot.reply_to(message, "⚠️ مشکلی در دریافت داده از API پیش آمد. لطفا بعدا تلاش کنید.")
        return
    
    coin = coins.get(coin_key)
    if not coin:
        bot.reply_to(message, f"⚠️ ارز '{message.text}' پیدا نشد. لطفا نام دقیق ارز یا عدد + نام ارز رو بفرستید.")
        return
    
    usd_price = float(coin['usdt'])
    toman_price = float(coin['irr'])
    change_percent = float(coin['dayChange'])
    
    profit_usd = amount * usd_price * (change_percent / 100)
    profit_toman = amount * toman_price * (change_percent / 100)
    date_time = datetime.now().strftime('%Y/%m/%d | %H:%M:%S')
    
    symbol = None
    for sym, c in coins.items():
        if c == coin and len(sym) <= 5:
            symbol = sym.upper()
            break
    if not symbol:
        symbol = coin_key.upper()
    
    amount_str = f"{amount:,.2f}".rstrip('0').rstrip('.') if '.' in f"{amount:,.2f}" else f"{amount:,.0f}"
    usd_total_str = f"{amount * usd_price:,.2f}".rstrip('0').rstrip('.') if '.' in f"{amount * usd_price:,.2f}" else f"{amount * usd_price:,.0f}"
    toman_total_str = f"{amount * toman_price:,.0f}"
    profit_usd_str = f"{profit_usd:.6f}".rstrip('0').rstrip('.') if '.' in f"{profit_usd:.6f}" else f"{profit_usd:.0f}"
    profit_toman_str = f"{profit_toman:,.0f}"
    
    msg = (
        f"💰 {amount_str} {symbol} = ${usd_total_str}\n"
        f"💶 {toman_total_str} تومان\n\n"
        f"{'🟢' if change_percent >= 0 else '🔴'} درصد تغییرات: {change_percent:.2f}%\n"
        f"{'🔺 مقدار سود' if change_percent >= 0 else '🔻 مقدار ضرر'}: "
        f"{profit_usd_str} $ / {profit_toman_str} تومان\n\n"
        f"📅 {date_time}"
    )
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(
        types.InlineKeyboardButton("➕ اضافه کردن به گروه", url="https://t.me/Toman_RateBot?startgroup=start")
    )
    
    bot.reply_to(message, msg, reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "شما دسترسی ندارید!", show_alert=True)
        return
    
    if call.data == 'stats':
        users_count = 0
        if os.path.exists(USERS_FILE):
            with open(USERS_FILE, 'r') as f:
                users_count = len(f.read().splitlines())
        
        groups_count = 0
        if os.path.exists(GROUPS_FILE):
            with open(GROUPS_FILE, 'r') as f:
                groups_count = len(f.read().splitlines())
        
        blocked_count = 0
        if os.path.exists(BLOCKED_FILE):
            with open(BLOCKED_FILE, 'r') as f:
                blocked_count = len(f.read().splitlines())
        
        msg = (
            f"📊 آمار ربات:\n\n"
            f"👥 تعداد کاربران: {users_count}\n"
            f"📁 تعداد گروه‌ها: {groups_count}\n"
            f"🚫 کاربران بلاک شده: {blocked_count}\n"
            f"🔴 وضعیت ربات: {'🟢 روشن' if get_bot_status() else '🔴 خاموش'}"
        )
        bot.send_message(call.message.chat.id, msg)
        bot.answer_callback_query(call.id)
    
    elif call.data == 'list_groups':
        if not os.path.exists(GROUPS_FILE):
            bot.send_message(call.message.chat.id, "📁 هیچ گروهی ثبت نشده.")
            bot.answer_callback_query(call.id)
            return
        
        with open(GROUPS_FILE, 'r') as f:
            groups = f.read().splitlines()
        
        if not groups:
            bot.send_message(call.message.chat.id, "📁 هیچ گروهی ثبت نشده.")
            bot.answer_callback_query(call.id)
            return
        
        msg = "📁 لیست گروه‌ها:\n\n"
        for group_id in groups[:50]:
            link = get_group_invite_link(group_id)
            if link:
                msg += f"- <a href='{link}'>لینک گروه</a> (ID: {group_id})\n"
            else:
                msg += f"- آیدی: {group_id} (لینک موجود نیست)\n"
        
        if len(groups) > 50:
            msg += f"\nو {len(groups)-50} گروه دیگر..."
        
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML', disable_web_page_preview=True)
        bot.answer_callback_query(call.id)
    
    elif call.data in ['enable', 'disable']:
        set_bot_status(call.data == 'enable')
        status_msg = "🟢 ربات روشن شد." if call.data == 'enable' else "🔴 ربات خاموش شد. (فقط ادمین می‌تواند با ربات کار کند)"
        bot.send_message(call.message.chat.id, status_msg)
        bot.answer_callback_query(call.id)
    
    elif call.data in ['broadcast', 'forward', 'block', 'unblock']:
        set_pending_action(call.from_user.id, call.data)
        
        if call.data == 'broadcast':
            msg = "📢 لطفا متن یا پیام مورد نظر برای ارسال همگانی را ارسال یا فوروارد کنید."
        elif call.data == 'forward':
            msg = "📨 لطفا پیام مورد نظر را فوروارد کنید یا پیام را ارسال/ریپلای کنید تا به همهٔ کاربران و گروه‌ها فوروارد شود."
        elif call.data == 'block':
            msg = "🚫 لطفا آیدی کاربر را ارسال کنید یا به پیام او ریپلای کنید تا بلاک شود."
        else:
            msg = "✅ لطفا آیدی کاربر را ارسال کنید یا به پیام او ریپلای کنید تا آنبلاک شود."
        
        bot.send_message(call.message.chat.id, msg)
        bot.answer_callback_query(call.id)

if __name__ == '__main__':
    print("🤖 ربات در حال اجرا است...")
    bot.infinity_polling()