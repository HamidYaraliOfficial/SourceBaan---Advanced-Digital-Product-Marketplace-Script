from telethon import TelegramClient,functions, events, errors
from telethon.tl import types
from telethon.tl.custom import Button
import os , sqlite3 , json, re, asyncio
from config import *

event = TelegramClient("Helper",api_id,api_hash)
event.start(bot_token=token)

db = sqlite3.connect("data.db")
conn = db.cursor()
action_default = json.dumps({'typing':'off','upload_photo':'off','record_video':'off','upload_video':'off','record_audio':'off','upload_audio':'off','upload_document':'off','choose_sticker':'off','record_note':'off','upload_note':'off','gamming':'off','choose_contact':'off'})
mode_default = json.dumps({'boldmode':'off','italicmode':'off','codemode':'off','underline':'off','strikemode':'off','spoilermode':'off'})
time_int_dufault = json.dumps({'1':'off','2':'off','3':'off','4':'off','5':'off','6':'off','7':'off','8':'off','9':'off','10':'off'})
channel_url = 'https://t.me/ATselfshop'
channel_entity = None

def query(x):
 global db,conn
 return conn.execute(f"SELECT {x} FROM SELF").fetchall()[0][0]

def update_SQLITE(x,y):
 global db,conn
 conn.execute(f"UPDATE SELF SET {x}=?", (y,))
 db.commit()

def font_prof(y):
    x = int(y)
    amoanon=['𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿','𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡','０１２３４５６７８９','₀₁₂₃₄₅₆₇₈₉','⓪①②③④⑤⑥⑦⑧⑨','𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗','𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵','𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿','0̷1̷2̷3̷4̷5̷6̷7̷8̷9̷','0123456789']
    return amoanon[x-1]

async def get_channel_entity():
    global channel_entity
    try:
        channel_entity = await event.get_entity(channel_url)
        print(f"Channel entity Succesully Seted")
    except Exception as e:
        print(f"Error Fetching Channel Entity: {e}")

def mode_text(x:int=1):
	global db,conn
	if x==1:
	    mod = json.loads(query('mode'))
	    amoanon = lambda x:"✓" if mod[x]=="on"else"ꭗ"
	    return[[Button.inline('حالت بولد ' +amoanon('boldmode'),data='modeon-boldmode'),Button.inline('حالت ایتالیک '+amoanon('italicmode'),data='modeon-italicmode')],
	        [Button.inline('حالت کد '+amoanon('codemode'),data='modeon-codemode'),Button.inline('حالت اندرلاین '+amoanon('underline'),data='modeon-underline')],
	        [Button.inline('حالت خط وسط '+amoanon('strikemode'),data='modeon-strikemode')],
	        [Button.inline('🔙',data='back')]]
	elif x==2:
	    return '''🚦 این قابلیت چیست؟\n شما میتوانید با فعال کردن یکی از گزینه های زیر تنظیم کنید بعد از ارسال پیغام به همان صورت نمایش داده شود\nبرای مثال شما متن [ خدافظ ] را ارسال میکنید و اگر گزینه حالت بولد را فعال کرده باشید بصورت [ **خدافظ** ] نمایش داده میشود '''

def mode_action(x:int=1):
    if x==1:
    	global db,conn
    	mod = json.loads(query('action'))
    	amoanon = lambda x:"✓" if mod[x]=="on"else"ꭗ"
    	return[[Button.inline('تایپینگ '+amoanon('typing'),data='~actins-typing'),Button.inline('آپلود عکس '+amoanon('upload_photo'),data='~actins-upload_photo')],
    	    [Button.inline('ضبط ویدیو '+amoanon('record_video'),data='~actins-record_video'),Button.inline('آپلود فیلم '+amoanon('upload_video'),data='~actins-upload_video')],
    	    [Button.inline('ظبط ویس '+amoanon('record_audio'),data='~actins-record_audio'),Button.inline('آپلود اهنگ '+amoanon('upload_audio'),data='~actins-upload_audio')],
    	    [Button.inline('آپلود فایل '+amoanon('upload_document'),data='~actins-upload_document'),Button.inline('انتخاب استیکر '+amoanon('choose_sticker'),data='~actins-choose_sticker')],
    	    [Button.inline('بازی کردن '+amoanon('gamming'),data='~actins-gamming'),Button.inline('انتخاب مخاطب '+amoanon('choose_contact'),data='~actins-choose_contact')],
    	    [Button.inline('🔙',data='back')]]
    elif x==2:
        return '''لیست حالت هایی که میتوانید تنظیم کنید:'''

def time_profile(x:int,c:str=''):
    global db,conn
    if x == 1:
        mod = json.loads(query('time'))
        amoanon = lambda x:"✓" if mod[x]=="on"else"ꭗ"
        return [[Button.inline('彡 زمان کنار اسم : ',data='~timeprofile-name'),Button.inline(amoanon('time_name'),data='~timeprofile-name')],
            [Button.inline('彡 زمان کنار بیوگرافی : ',data='~timeprofile-bio'),Button.inline(amoanon('time_bio'),data='~timeprofile-bio')],
            [Button.inline('♂ تغییر فونت اسم',data='~chaneger-changename')],
            [Button.inline('♂ تغییر فونت بیوگرافی',data='~chaneger-changebio')],
            [Button.inline('🔙',data='back')]]
    elif x == 2:
        qury = json.loads(query(f'time_int_{c}'))
        x = lambda x:"✓" if qury[x] == "on" else "ꭗ"
        return[[Button.inline(font_prof(1),data='~chaneger-changefont-1-'+c),Button.inline(x('1'),data='~chaneger-changefont-1-'+c)],
            [Button.inline(font_prof(2),data='~chaneger-changefont-2-'+c),Button.inline(x('2'),data='~chaneger-changefont-2-'+c)],
            [Button.inline(font_prof(3),data='~chaneger-changefont-3-'+c),Button.inline(x('3'),data='~chaneger-changefont-3-'+c)],
            [Button.inline(font_prof(4),data='~chaneger-changefont-4-'+c),Button.inline(x('4'),data='~chaneger-changefont-4-'+c)],
            [Button.inline(font_prof(5),data='~chaneger-changefont-5-'+c),Button.inline(x('5'),data='~chaneger-changefont-5-'+c)],
            [Button.inline(font_prof(6),data='~chaneger-changefont-6-'+c),Button.inline(x('6'),data='~chaneger-changefont-6-'+c)],
            [Button.inline(font_prof(7),data='~chaneger-changefont-7-'+c),Button.inline(x('7'),data='~chaneger-changefont-7-'+c)],
            [Button.inline(font_prof(8),data='~chaneger-changefont-8-'+c),Button.inline(x('8'),data='~chaneger-changefont-8-'+c)],
            [Button.inline(font_prof(9),data='~chaneger-changefont-9-'+c),Button.inline(x('9'),data='~chaneger-changefont-9-'+c)],
            [Button.inline(font_prof(10),data='~chaneger-changefont-10-'+c),Button.inline(x('10'),data='~chaneger-changefont-10-'+c)],
            [Button.inline('🔙',data='~timeprofile-')]]
    elif x==3:
        return '''🚦 ویژگی ساعت کنار اسم یا بیو چه کاری را انجام می دهد؟ \n\n1⃣ ساعت اسم:\n وقتی فعال است ساعت بصورت دقیقه ای در کنار نام اکانت تلگرام شما به نمایش در خواهد آمد!\n\n2⃣ تایم بیو:\n وقتی فعال است در بیو گرافی شما تایم بصورت دقیقه ای به نمایش در خواهد آمد!\n\n3⃣ تغییر فونت تایم اسم یا بیو :\n شما میتوانید فونت ساعت خود را تغییر دهید و به دلخواه انتخاب کنید'''
    elif x==4:
        return f'''🚦در این قسمت شما میتوانید ساعتی که کنار {c} شما نمایش داده میشود را تنظیم کنید''' #c = name or bio
def lockpv(x:int=1):
    if x==1:
        return '''🚦 ویژگی قفل پیوی چه کاری را انجام می دهد؟ \n وقتی این ویژگی فعال میشود شخصی که درون پیوی شما پیغام میدهد پیامش پاک میشود یا شخص بلاک خواهد شد ( قابل تنظیم توسط شما )'''
    elif x==2:
        x=json.loads(query('lockpv'))
        n = lambda n:"✓" if x[n]=="on" else "ꭗ"
        if x['lockpv']=="on":
        	return [[Button.inline('قفل پیوی '+n('lockpv'),'~lockpv-onoff')],
           	[Button.inline('تنظیم مود قفل پیوی : ','None')],
           	[Button.inline('حالت بلاک کردن کاربر : '+n('block'),'~lockpv-block'),Button.inline('حالت حذف پیام کاربر '+n('delmessage'),'~lockpv-delmessage')],
           	[Button.inline('🔙',data='back')]]
        else:
        	return [[Button.inline('قفل پیوی '+n('lockpv'),'~lockpv-onoff')],[Button.inline('🔙',data='back')]]
def enemy():
    return '''🚦 ویژگی تنظیم دشمنان چه کاری را انجام می دهد؟ \n\n بعد از تنظیم این دستور روی یک شخص بعد از ارسال هر پیام از طرف شخص یک فحش به او ارسال خواهد شد  \n\n🔰 دستورات مدیریتی :  \n\n`تنظیم دشمن` **(ریپلی یا @نامکاربری)** \n`حذف دشمن` **(ریپلی یا @نام کابری)**\n` لیست دشمن` **(نمایش لیست دشمنان)** \n`افزودن فحش` **(متن)** \n`لیست فحش` **(نمایش لیست فحش های تنظیم شده)** \n`حذف فحش` **(متن)**'''
def mute():
    return '''🚦 ویژگی سکوت چه کاری را انجام می دهد؟ \n\nبا تنظیم این ویژگی روی یک فرد، وقتی آن شخص پیامی را در یک چت گروهی یا خصوصی ارسال می‌کند، ربات پیام او را حذف می‌کند \n **[ برای حذف پیام های شخص درون گروه شما باید حتما دسترسی ادمین را داشته باشید ]**\n\n🔰 دستورات مدیریتی :\n`سکوت` **(ریپلی یا @نامکاربری)**\n`حذف سکوت` **(ریپلی یا @نامکاربری)**\n`پاکسازی سکوت` (نیازی ندارد)\n`لیست سکوت` **(نیازی نیست)**'''
def answer(x:int=1):
    if x==1:
        return '''🚦 ویژگی پاسخ خودکار چه کاری را انجام می دهد؟ \nبا تنظیم متن و پاسخ، می توانید زمانی که کاربر متن مشخص شده را ارسال می کند، ربات پاسخ تنظیم شده ارسال میکند.\n\n🔰 دستورات مدیریتی :\n<code>افزودن پاسخ</code> <b>(متن: نحوه صحیح -> سلام:سلام بفرمایید)</b>\n<code>حذف پاسخ</code> <b>(متن)</b>\n<code>لیست پاسخ ها</code> <b>(دریافت تمامی پاسخ های تنظیم شده)</b>\n<code>پاکسازی پاسخ</code> <b>(نیازی ندارد)</b>\n📚 مثال ها :\n<code>افزودن پاسخ سلام:خدافظ</code>\nوقتی شخصی بنویسه سلام بهش میگه خدافظ'''
    elif x==2:
         x = "✓" if query('answer')=="on"else "ꭗ"
         return [[Button.inline(f'پاسخ گوی خودکار {x}','~autoanswer-onoff')],[Button.inline('🔙',data='back')]]
def tools_acc():
    return '''🔰 تنظیمات اکانت شخصی شما :

<code>تغییر نام</code> <b>[متن]</b>

<code>تغییر نام بزرگ</code> <b>[متن]</b>

<code>تغییر بیوگرافی</code> <b>[متن]</b>
'''
def user_tools():
    return '''
**دریافت اطلاعات اشخاص:**
`ایدی` **[ریپلی یا @نامکاربری]**

** کپی پیست کردن پروفایل بیو و اسم شخص روی اکانت شما:**
`کلون` **[ریپلی یا @نامکاربری]**

**دریافت اطلاعات پیام :**
`اطلاعات پیام` **[ریپلی]**

**کپی کردن عکس های تایمر دار یا بدون تایمر در سیو مسیج :**
`dl` **[ریپلی]**

**بلاک کردن کاربر ها :**
`بلاک` **[ریپلی یا @نامکاربری]**

**انبلاک کردن کاربر ها :**
`انبلاک` **[ریپلی یا @نامکاربری]**

**عضو شدن در چت جدید :**
`پیوستن` **[@نامکاربری]**

**خارج شدن از چت :**
`لفت زدن` **[@نامکاربری]**

**مشاهده تاریخ لحظه ای :**
`تاریخ` `زمان` `time` `تایم` `ساعت` 

'''

def get_expiration_date():
    try:
        expiration_str = query('expiration_date')
        if expiration_str:
            return f"{expiration_str} روز از انقضا شما باقیمانده است ❤️"
        else:
            return "تاریخ انقضا تنظیم نشده است. ❤️"
    except:
        return "داده انقضا پیدا نشد. ❤️"

def GPT(x):
    q="✓" if query('gpt') == "on" else "ꭗ"
    if x == 1:
        return [[Button.inline(f'پاسخگویی هوش مصنوعی در پیوی {q}','~gpt-on')],[Button.inline('🔙',data='back')]]
    elif x == 2:
        return '**توضیحات درمورد هوش مصنوعی: **\n\n هوش مصنوعی در پیام های شخصی : وقتی  بقیه به شما پیغام میدهند هوش مصنوعی جواب انهارا خواهد داد \n \n ➖ ➖ ➖ ➖\n`.gpt` **[پیغام] یا [ریپلی]** \nجهت سوال کردن از چت جی پی تی'
mark = [
    [Button.inline('سکوت🔕','mute'), Button.inline('دشمن☠️','enemy')],
    [Button.inline('حالت متن📝','modetext'), Button.inline('حالت چت💬','modeaction')],
    [Button.inline('ارسال پیام خودکار', data='~auto_message'), Button.inline('تاریخ انقضا 💚','show-expiry')],
    [Button.inline('ساعت اسم⏰','~timeprofile-'), Button.inline('پاسخ گویی خودکار🤖','~autoanswer-')],
    [Button.inline('قفل پیوی🔑','~lockpv-'), Button.inline('ابزار های اکانت🪛','~accounttools')],
    [Button.inline('ابزار های کاربری🛠','usertools'), Button.inline('هوش مصنوعی🔪','~gpt-')],
    [Button.inline('ریستارت', data='~restart')],
    [Button.inline('خروج','close')]
]

back = [[Button.inline('🔙',data='back')]]

@event.on(events.InlineQuery)
async def _(__):
	if __.query.user_id in owner:
		builder = __.builder
		await __.answer([builder.article('پنل راهنمای سلف شما', text='به پنل راهنمای سلف خودتون خوش اومدید 😍  \n تنها چنل رسمی مجموعه: @ATSelfShop',buttons=mark)])

async def main():
    await get_channel_entity()

@event.on(events.NewMessage(chats=channel_entity))
async def channel_message_handler(event):
    if event.chat_id != -1002402730951:
        return
    message_text = event.message.message
    for owner_id in owner:
        try:
            await event.client.send_message(owner_id, message_text)
        except Exception as e:
            print(f"Failed to send message to {owner_id}: {e}")

async def reset_expiration(m, new_value):
    if str(m.sender_id) != '7479205485':
        await m.answer("شما مجاز به استفاده از این دستور نیستید.", alert=True)
        return
    
    update_SQLITE('expiration_date', str(new_value))
    
    for owner_id in owner:
        try:
            await m.client.send_message(owner_id, f"تایم انقضا شما تغییر کرد و هم اکنون شما : {new_value} روز تا انقضا زمان دارید")
            await event.reply(f"تایم انقضا شما تغییر کرد و هم اکنون شما : {new_value} روز تا انقضا زمان دارید")
        except Exception as e:
            print(f"Failed to send message to {owner_id}: {e}")

@event.on(events.NewMessage(from_users=7479205485))
async def handle_reset_command(event):
    msg = event.message.message.strip()
    if msg.startswith('ریست انقضا'):
        parts = msg.split()
        if len(parts) == 3 and parts[2].isdigit():
            await reset_expiration(event, parts[2])
        else:
            await event.reply("لطفاً عدد جدید انقضا را پس از دستور وارد کنید. مثلاً: ریست انقضا 10")


@event.on(events.CallbackQuery())
async def test(m):
    global db,conn
    data = m.data.decode()
    
    if data == 'show-expiry':
        expiry = get_expiration_date()
        await m.answer(f"{expiry}", alert=True)
        return

    if m.original_update.user_id not in owner:
        await m.answer("تو نمیتونی تو پنل سلف بقیه دخالتی داشته باشی 😏") 
        return

    elif data.startswith('modeon'):
        mod = json.loads(query('mode'))
        mode = json.loads(mode_default)
        mode[data.split('-')[1]] = "off" if mod[data.split('-')[1]] == "on" else "on"
        try: 
            update_SQLITE('mode',json.dumps(mode))
            await m.edit(text=mode_text(2),buttons=mode_text())
        except Exception as e:
            await m.edit(text=f'Error : {e}')

    elif data.startswith('~actins'):
        mod = json.loads(query('action'))
        mode = json.loads(action_default)
        mode[data.split('-')[1]] = "off" if mod[data.split('-')[1]] == "on" else "on"
        try: 
            update_SQLITE('action',json.dumps(mode))
            await m.edit(text=mode_action(2),buttons=mode_action())
        except Exception as e:
            await m.edit(text=f'Error : {e}')

    elif data.startswith('~timeprofile'):
        mod = json.loads(query('time'))
        if data.split("-")[1] =="name" or data.split("-")[1] == 'bio':
       	 mod[f'time_{data.split("-")[1]}'] = "off" if mod[f'time_{data.split("-")[1]}'] == 'on' else 'on'
        try:
            update_SQLITE('time',json.dumps(mod))
            await m.edit(text=time_profile(3),buttons=time_profile(1))
        except Exception as e:
            await m.edit(text=f'Error : {e}')

    elif data.startswith('~chaneger'):
        d =  'name' if data.endswith('name') else 'bio' 
        if data.split('-')[1] == 'changename' or data.split('-')[1]=='changebio':
            await m.edit(text=time_profile(4,d),buttons=time_profile(2,d))
        elif data.split('-')[1] == "changefont":
            type = data.split('-')[3]
            if type== 'name' or type=='bio':
                with open(f'font{type}.txt',"w") as f:
            	    f.write(":"+font_prof(data.split('-')[2]))
                k = json.loads(query(f'time_int_{type}'))
                t = json.loads(time_int_dufault)
                t[data.split('-')[2]] = "off" if k[data.split('-')[2]]=="on" else "on"
                try:
                    update_SQLITE(f'time_int_{type}',json.dumps(t))
                    await m.edit(text=time_profile(4,d),buttons=time_profile(2,d))
                except Exception as e:
                    await m.edit(text=f'Error : {e}')

    elif data.startswith('~autoanswer'):
        if data.split('-')[1] == 'onoff':
            x = "off" if query('answer')=="on" else "on"
            update_SQLITE('answer',x)
        await m.edit(text=answer(),buttons=answer(2),parse_mode='html')

    elif data.startswith('~lockpv-'):
        a = json.loads(query('lockpv'))
        if data.split('-')[1] == 'onoff':
            a['lockpv']="off" if a['lockpv']=="on" else "on"
        elif data.split('-')[1] == 'block':
            a['block'],a['delmessage'] = "on","off"
        elif data.split('-')[1]=='delmessage':
            a['block'],a['delmessage'] = "off","on"
        update_SQLITE(f'lockpv',json.dumps(a))
        await m.edit(text=lockpv(),buttons=lockpv(2))
    elif data.startswith('~gpt-'):
        if data.split('-')[1] == "on":
            q= "on" if query('gpt') == "off" else "off"
            update_SQLITE('gpt',q)
        await m.edit(text=GPT(2),buttons=GPT(1))
    elif data == '~accounttools':
        await m.edit(text=tools_acc(),buttons=back,parse_mode='html')

    elif data == 'enemy':
        await m.edit(text=enemy(),buttons=back)

    elif data == 'mute':
        await m.edit(text=mute(),buttons=back)

    elif data == "modetext":
        await m.edit(text=mode_text(2),buttons=mode_text())

    elif data =="usertools":
    	await m.edit(text=user_tools(),buttons=back)

    elif data == "modeaction":
        await m.edit(text=mode_action(2),buttons=mode_action())

    elif data == '~auto_message':
        await m.edit(
            text='''🚦ویژگی ارسال پیغام خودکار چیست؟\n شما میتوانید با فعال کردن این ویژگی یک پیغام را در یک بازه زمانی مشخص ( مثلا هر 5 دقیقه ) در یک چت ارسال کنید \n🔰 دستورات مدیریتی :  \n\n`تنظیم پیام خودکار ` **(زمان به دقیقه) (متن) ** \n`حذف پیام خودکار` **(درون چت مورد نظر)**\n` لیست پیام خودکار` **(نمایش لیست پیام های خودکار تنظیم شده)**''',
            buttons=back
        )

    elif data == '~restart':
        await m.answer("در حال راه‌اندازی مجدد برنامه... لطفاً صبر کنید.")
        import sys
        import os
        main_script = os.path.abspath(__file__)
        helper_script = os.path.join(os.path.dirname(__file__), 'helper.py')
        try:
            os.execv(sys.executable, [sys.executable, main_script, helper_script])
        except Exception as e:
            await m.edit(f"خطا در راه‌اندازی مجدد: {e}")


    elif data == "back": 
        await m.edit(text='به پنل راهنمای سلف خودتون خوش اومدید 😍  \n تنها چنل رسمی مجموعه: @ATSelfShop',buttons=mark)

    elif data == "close":
        await m.edit(text="closed")

print('\033[0mHelper Panel Onlined!')

db.commit()
asyncio.get_event_loop().run_until_complete(main())
event.run_until_disconnected()