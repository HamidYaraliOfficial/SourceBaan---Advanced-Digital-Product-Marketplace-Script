import sqlite3, json, os, time, asyncio, random, datetime, jdatetime, pytz, subprocess, sys, re, yt_dlp, requests
from config import *
from pip import main
try:
    from datetime import datetime, timedelta
    from telethon import TelegramClient,events,sync,functions
    from telethon.tl import types
    from telethon.tl.custom.message import Message
    from telethon.tl.functions.messages import SetTypingRequest
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from requests import post
    from pytz import timezone,datetime
except ModuleNotFoundError:
    main(['install','telethon'])
    main(['install','APScheduler==3.10.0'])
    main(['install','tzdata'])
    main(['install','pytz'])
    main(['install','datetime'])
    main(['install','requests'])
    os.system('python3 self.py')
	
time_default = json.dumps({'time_name':'off','time_bio':'off'})
pvblock_default = json.dumps({'lockpv':'off','block':'off','delmessage':'on'})
time_int_default = json.dumps({'1':'on','2':'off','3':'off','4':'off','5':'off','6':'off','7':'off','8':'off','9':'off','10':'off'})
mode_default = json.dumps({'boldmode':'off','italicmode':'off','codemode':'off','underline':'off','strikemode':'off','spoilermode':'off'})
action_default = json.dumps({'typing':'off','upload_photo':'off','record_video':'off','upload_video':'off','record_audio':'off','upload_audio':'off','upload_document':'off','choose_sticker':'off','record_note':'off','upload_note':'off','gamming':'off','choose_contact':'off'})
org = [":","0","1","2","3","4","5","6","7","8","9"]
enemy_list = []
mute = []
self_enabled = True
download_requests = 0
successful_downloads = 0
last_gpt_time = 0
auto_tasks = {}
auto_messages = {}
auto_intervals = {}
answer=[]
javab=[]
fosh_list = ["یا الله کیرم به قلب مادرت",
    "مادرتو میدم سگ بگاد",
    "با کیرم ناموستو پاره میکنم",
    "کیرمو حلقه میکنم دور گردن مادرت",
    "کسخارتو بتن ریزی کردم",
    "ننتو تو پورن هاب دیدم",
    "کیر و خایه هام به کل اجدادت",
    "فیلم ننت فروشی",
    "کسننت پدرتم",
    "میرم تو کسمادرت با بیل پارش میکنم",
    "کیر به ناموس گشادت",
    "خسته نشدی ننتو گاییدم؟",
    "کیرم شلاقی به ناموس جندت",
    "با ناموست تریسام زدم",
    "برج خلیفه تو مادرت",
    "دو پایی میرم تو کسمادرت",
    "داگی استایل ننتو گاییدم",
    "هندل زدم به کون مادرت گاییدمش",
    "یگام دو گام ننتو میگام",
    "کیرمو نکن تو کسمادرت",
    "کیر و خایم به توان دو تو کسمادرت",
    "قمه تو کسمادرت",
    "نود ننتو دارم مادرکسده",
    "با کله میرم تو کسمادرت",
    "دستام تو کسمادرت",
    "کیرم به استخون های ننت",
    "مادرتو حراج زدم مادرجنده",
    "بریم برای راند بعد با ننت",
    "کیرم به رحم نجس ننت",
    "کیرم به چش و چال ننت",
    "کیروم به فرق سر ناموست",
    "مادرجنده کیری ناموس",
    "با کون ننت ناگت درست کردم",
    "خایه هام به کسمادرت",
    "برج میلاد تو کسمادرت",
    "یخچال تو کسمادرت",
    "کیرم به پوزه مادرت",
    "مادرتو زدم به سیخ",
    "کسمادرت",
    "کیر شتر تو ناموست",
    "نودا ننت فروشی",
    "خایه با پرزش تو ننت",
    "چشای ننت تو کون خارت بره",
    "ننتو ریدم",
    "لال شو مادرجنده اوبنه ای",
    "اوب از کون ننت میباره",
    "ماهی تو کسمادرت",
    "کیر هرچی خره تو کسمادرت",
    "کیر رونالدو به کس خار و مادرت",
    "مادرت زیر کیرم شهید شد",
    "اسپنک زدم به کون مادر جندت",
    "کیرم یهویی به مردع و زندت",
    "کیر به فیس ننت",
    "برو مادرجنده بی غیرت",
    "استخون های مرده هات تو کسمادرت",
    "اسپرمم تو نوامیست",
    "مادرتو با پوزیشن های مختلف گاییدم",
    "میز و صندلی تو کسمادرت",
    "کیر به ناموس دلقکت",
    "دمپایی تو کون ننت",
    "دماغ پینوکیو رو گذاشتم جلو کص مادرت و بهش گفتم که بگه مادرت جنده نیست تا با دراز شدن دماغش کص مادرت پاره بشه",
    "مادر فلش شده جوری با کیر میزنم ب فرق سر ننت ک حافظش بپره",
    "كيرم شيك تو كس ننت",
    "مادرتو کردم تو بشکه نفت از بالا کوه قل دادم پایین",
    "با کیرم مادرتو هیپنوتیزم کردم",
    "ناموستو تو کوچه موقع عید دیدنی دیدم رفتم خونه به یادش جق زدم",
    "با خیسی عرق کون مادرت جقیدم",
    "با سرعت نور تو فضا حرکت میکنم تا پیر نشم و بزارم آبجی کوچیکت بزرگ بشه تا وقتی بزرگ شد باهاش سکس کنم",
    "مادرتو پودر میکنم ازش سنگ توالت میسازم هر روز صبح رو مادرت میرینم",
    "مادرتو مجبور میکنم خودکشی کوانتومی کنه تا در بی نهایت جهان موازی یتیم بشی",
    "دیدی چه لگدی به مادرت زدم ؟",
    "فرشی که مادرت روش کونشو گذاشته بو کردم",
    "مادرتو جوری گاییدم که همسایه ها فکر کردن اسب ترکمن اومده خونتون"]
	
slf = TelegramClient("session",api_id,api_hash)
db = sqlite3.connect("data.db")
conn = db.cursor()

try:
    conn.execute(f"CREATE TABLE IF NOT EXISTS SELF(time json,time_int_name json,time_int_bio json,mode json,action json,gpt varchar(3),answer varchar(3),lockpv json, expiration_date TEXT DEFAULT NULL)")
    conn.execute("INSERT INTO SELF(time,mode,action,time_int_name,time_int_bio,answer,lockpv,gpt,expiration_date) SELECT ?,?,?,?,?,?,?,?,30 WHERE NOT EXISTS (SELECT 1 FROM SELF)", (time_default, mode_default, action_default, time_int_default, time_int_default, "off", pvblock_default, "off"))
except:
    pass

if not os.path.isfile('fontname.txt'):
 with open('fontname.txt',"w") as a:
  a.write(":𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿")
if not os.path.isfile('fontbio.txt'):
 with open('fontbio.txt',"w") as a:
  a.write(":𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿")
# - - - - FUNCTION - - - - #
def query(x):
 global db,conn
 return conn.execute(f"SELECT {x} FROM SELF").fetchall()[0][0]
def update_SQLITE(x,y):
 global db,conn
 conn.execute(f"UPDATE SELF SET {x}=?", (y,))
 db.commit()
async def get_me():
	myid = await slf.get_me()
	return myid.id
def gpt(text):
    false=False
    true=True
    null=None
    h = {"authority": "api.binjie.fun","method": "POST","path": "/api/generateStream","scheme": "https","accept": "application/json, text/plain, */*","accept-encoding": "gzip, deflate, br","accept-language": "en-US,en;q=0.9","content-length": "112","origin": "https://chat18.aichatos.xyz","referer": "https://chat18.aichatos.xyz/","sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"","sec-ch-ua-mobile": "?0","sec-ch-ua-platform": "\"Windows\"","sec-fetch-dest": "empty","sec-fetch-mode": "cors","sec-fetch-site": "cross-site","user-agent": "Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"}
    data={"prompt":text,"userId":"#/chat/1711529530173","network":true,"system":"","withoutContext":false,"stream":false}
    return post("https://api.binjie.fun/api/generateStream",headers=h,data=data).text

day_names_fa = {
    'Monday': 'دوشنبه',
    'Tuesday': 'سه‌شنبه',
    'Wednesday': 'چهارشنبه',
    'Thursday': 'پنج‌شنبه',
    'Friday': 'جمعه',
    'Saturday': 'شنبه',
    'Sunday': 'یک‌شنبه'
}

month_names_fa = {
    'January': 'ژانویه',
    'February': 'فوریه',
    'March': 'مارس',
    'April': 'آوریل',
    'May': 'مه',
    'June': 'ژوئن',
    'July': 'ژوئیه',
    'August': 'اوت',
    'September': 'سپتامبر',
    'October': 'اکتبر',
    'November': 'نوامبر',
    'December': 'دسامبر'
}

jalali_month_names_fa = [
    'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
]

import pytz
import calendar

tehran_tz = pytz.timezone('Asia/Tehran')

def get_date_time_info():
    now_tehran = datetime.datetime.now(tz=tehran_tz)
    gregorian_date = now_tehran.strftime("%Y/%m/%d")
    time_now = now_tehran.strftime("%H:%M:%S")
    jalali_now = jdatetime.datetime.now(tz=tehran_tz)
    jalali_date = jalali_now.strftime("%Y/%m/%d")
    jalali_month_index = jalali_now.month - 1
    day_name_en = calendar.day_name[now_tehran.weekday()]
    day_name_fa = day_names_fa.get(day_name_en, "")
    month_name_en = calendar.month_name[now_tehran.month]
    month_name_fa = month_names_fa.get(month_name_en, "")
    jalali_month_name_fa = jalali_month_names_fa[jalali_month_index]
    utc_now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc)
    utc_date = utc_now.strftime("%A %Y-%m-%d %H:%M:%S")
    return {
        'gregorian_date': gregorian_date,
        'jalali_date': jalali_date,
        'time_now': time_now,
        'day_name_en': day_name_en,
        'day_name_fa': day_name_fa,
        'month_name_en': month_name_en,
        'month_name_fa': month_name_fa,
        'jalali_month_name_fa': jalali_month_name_fa,
        'utc_date': utc_date
    }


def create_time(c:str):
    a = datetime.datetime.now(timezone("Asia/Tehran")).strftime("%H:%M")
    with open(f"font{c}.txt","r") as fn:
     ran = list(fn.read())
    for char in a:
     a = a.replace(char,ran[int(org.index(str(char)))])
    return a

def reduce_expiration():
    try:
        db = sqlite3.connect("data.db")
        conn = db.cursor()
        rows = conn.execute("SELECT expiration_date FROM SELF").fetchall()
        for row in rows:
            exp_date_str = row[0] 
            try:
                number = int(exp_date_str)
                if number < 0:
                    number = 0
                else:
                    number -= 1
                new_exp_date_str = str(number)
                conn.execute("UPDATE SELF SET expiration_date = ? WHERE expiration_date = ?", (new_exp_date_str, exp_date_str))
            except ValueError:
                print(f"Invalid number format in {exp_date_str}")
        db.commit()
    except Exception as e:
        print(f"Error in reducing expiration date: {e}")

async def set_auto_message(event):
    global auto_messages, auto_intervals, auto_tasks
    txt = event.text.strip()

    if not text.startswith("تنظیم پیام خودکار "):
        await event.reply("فرمان معتبر نیست. لطفاً فرمان را به شکل صحیح وارد کنید.")
        return

    rest = text[len("تنظیم پیام خودکار "):]
    parts = rest.split(" ", 1)
    if len(parts) != 2:
        await event.reply("نحوه استفاده: تنظیم پیام خودکار (زمان به دقیقه) (پیام)")
        return

    interval_str, message_text = parts
    try:
        interval = int(interval_str)
        if interval < 5:
            await event.reply("لطفاً زمان را حداقل 5 دقیقه وارد کنید.")
            return
    except ValueError:
        await event.reply("لطفاً عدد صحیح برای زمان وارد کنید.")
        return

    chat_id = event.chat_id

    if chat_id in auto_messages:
        auto_messages[chat_id] = message_text
        auto_intervals[chat_id] = interval
        await event.message.edit(f"پیام خودکار برای این چت بروزرسانی شد!\nهر {interval} دقیقه پیام زیر ارسال می‌شود:\n{message_text}")
    else:
        auto_messages[chat_id] = message_text
        auto_intervals[chat_id] = interval
        await event.message.edit(f"پیام خودکار تنظیم شد!\nهر {interval} دقیقه پیام زیر ارسال می‌شود:\n{message_text}")

    if chat_id in auto_tasks:
        auto_tasks[chat_id].cancel()

    auto_tasks[chat_id] = asyncio.create_task(send_auto_message(chat_id))

async def delete_auto_message(event):
    global auto_messages, auto_intervals, auto_tasks
    chat_id = event.chat_id

    if chat_id in auto_messages:
        del auto_messages[chat_id]
        del auto_intervals[chat_id]
        if chat_id in auto_tasks:
            auto_tasks[chat_id].cancel()
            del auto_tasks[chat_id]
        await event.message.edit("متن خودکار این چت حذف شد.")
    else:
        await event.reply("در این چت متن خودکار تنظیم نشده است.")

async def send_auto_message(chat_id):
    global auto_messages, auto_intervals, self_enabled
    if not self_enabled:
        return
    try:
        while True:
            interval = auto_intervals.get(chat_id)
            message = auto_messages.get(chat_id)
            if not interval or not message:
                break
            sleep_time = interval * 60
            await asyncio.sleep(sleep_time)
            await slf.send_message(chat_id, message)
    except asyncio.CancelledError:
        pass


async def list_auto_messages(event):
    global auto_messages
    if not auto_messages:
        await event.message.edit("هیچ پیام خودکاری تنظیم نشده است.")
        return

    message_list = "لیست پیام‌های خودکار:\n"
    for chat_id, message_text in auto_messages.items():
        chat_link = f"https://t.me/c/{str(chat_id)[4:]}" if str(chat_id).startswith("-100") else f"tg://user?id={chat_id}"
        message_list += f"[چت]({chat_link}) - پیام: {message_text}\n"
    await event.message.edit(message_list, parse_mode='markdown')

async def time_accs():
 db = sqlite3.connect("data.db")
 conn = db.cursor()
 a = json.loads(conn.execute(f"SELECT time FROM SELF").fetchall()[0][0])
 Amo_Anon = await slf.get_me()
 g = await slf(functions.users.GetFullUserRequest("me"))
 about = g.full_user
 try:
   if(a["time_bio"])=="on":
   	bio = create_time('bio') if str(about.about) == 'None' else about.about[:-5]+ create_time('bio')
   	await slf(functions.account.UpdateProfileRequest(about=bio))

   if(a["time_name"])=="on": 
   	name = create_time('name') if str(Amo_Anon.last_name) == 'None' else Amo_Anon.last_name[:-5]+ create_time('name')
   	await slf(functions.account.UpdateProfileRequest(last_name=name))
 except :
  pass

ghabls = ["❤️", "🩷", "🧡", "💛", "🩵", "💙", "💚", "💜", "🖤", "❤️‍🩹", "❤️‍🔥", "💔", "🤎", "🤍", "🩶", "❤️"]
reloadl = [
    "`شروع ریستارت شدن`",
    "░░░░░░░░░░░░░░",
    "▒░░░░░░░░░░░░░",
    "▒▒░░░░░░░░░░░░",
    "▒▒▒░░░░░░░░░░░",
    "▒▒▒▒░░░░░░░░░░",
    "▒▒▒▒▒░░░░░░░░░",
    "▒▒▒▒▒▒░░░░░░░░",
    "▒▒▒▒▒▒▒░░░░░░░",
    "▒▒▒▒▒▒▒▒░░░░░░",
    "▒▒▒▒▒▒▒▒▒░░░░░",
    "▒▒▒▒▒▒▒▒▒▒░░░░",
    "▒▒▒▒▒▒▒▒▒▒▒░░░",
    "▒▒▒▒▒▒▒▒▒▒▒▒░░",
    "▒▒▒▒▒▒▒▒▒▒▒▒▒░",
    "▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
    "▓▒▒▒▒▒▒▒▒▒▒▒▒▒",
    "▓▓▒▒▒▒▒▒▒▒▒▒▒▒",
    "▓▓▓▒▒▒▒▒▒▒▒▒▒▒",
    "▓▓▓▓▒▒▒▒▒▒▒▒▒▒",
    "▓▓▓▓▓▒▒▒▒▒▒▒▒▒",
    "▓▓▓▓▓▓▒▒▒▒▒▒▒▒",
    "▓▓▓▓▓▓▓▒▒▒▒▒▒▒",
    "▓▓▓▓▓▓▓▓▒▒▒▒▒▒",
    "▓▓▓▓▓▓▓▓▓▒▒▒▒▒",
    "▓▓▓▓▓▓▓▓▓▓▒▒▒▒",
    "▓▓▓▓▓▓▓▓▓▓▓▒▒▒",
    "▓▓▓▓▓▓▓▓▓▓▓▓▒▒",
    "▓▓▓▓▓▓▓▓▓▓▓▓▓▒",
    "▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
    "ریستارت.",
    "ریستارت..",
    "ریستارت...",
    "ریستارت.",
    "ریستارت..",
    "ریستارت...",
    "ریستارت.",
    "ریستارت..",
    "ریستارت...",
    "`ریستارت شد! :)`",
]

@slf.on(events.NewMessage(pattern="^ریستارت$", from_users='me'))
async def reload_handler(event):
    try:
        for stage in reloadl:
            await event.edit(stage)
            await asyncio.sleep(0.5)

        os.execv(sys.executable, [sys.executable, os.path.join(os.path.dirname(__file__), 'self.py')])
    except Exception as e:
        print(f"Error In Restarting: {e}")

@slf.on(events.NewMessage(pattern="^قلب$", from_users='me'))
async def reload_handler(event):
    try:
        for stage in ghabls:
            await event.edit(stage)
            await asyncio.sleep(2)

    except Exception as e:
        print(f"Error In Sending Ghalbs: {e}")

def get_exchange_rates():
    try:
        nobitex_resp = requests.get('https://api.nobitex.ir/market/stats?srcCurrency=usdt,trx,ton,btc,shib,eth,etc,usdt,ada,bch,ltc,bnb&dstCurrency=irt,rls,usdt')
        nobitex_data = nobitex_resp.json()

        usdt_to_irt_price = None
        btc_to_irt_price = None
        for symbol in nobitex_data['stats']:
            if symbol['baseAsset'] == 'usdt' and symbol['quoteAsset'] == 'irt':
                usdt_to_irt_price = symbol['last']
            elif symbol['baseAsset'] == 'btc' and symbol['quoteAsset'] == 'irt':
                btc_to_irt_price = symbol['last']


        # ساخت رشته خروجی
        text = f"لیست قیمت:"
        if usdt_to_irt_price:
            text += f"قیمت USDT به ریال: {usdt_to_irt_price}"
        if btc_to_irt_price:
            text += f"قیمت BTC به ریال: {btc_to_irt_price}"

        return text

    except requests.exceptions.RequestException as e:
        return "خطا در دریافت داده‌ها از API: " + str(e)
    except (KeyError, TypeError) as e:
        return "خطا در پردازش داده‌ها: " + str(e)
    except Exception as e:
        return "خطای غیرمنتظره: " + str(e)

@slf.on(events.NewMessage(pattern='/dinsta'))
async def handle_dinsta_link(event):
    sender_id = event.sender_id
    message_text = event.message.message
    args = message_text.split(maxsplit=1)
    if len(args) < 2:
        await event.respond("لینک را ارسال کنید. مثلا: /dinsta https://www.instagram.com/...")
        return
    url = args[1]
    chat_id = event.chat_id

    # اعتبارسنجی لینک
    if "instagram.com" not in url:
        await event.respond("فقط لینک‌های معتبر اینستاگرام پذیرفته می‌شوند.")
        return

    message = await event.respond("در حال دریافت ویدیو از اینستاگرام... لطفاً منتظر بمانید.")

    ydl_opts = {
        'format': 'best',
        'noplaylist': True,
        'quiet': True,
        'skip_download': True,
        'forcejson': True,
        'extract_flat': False,
        'cachedir': False,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)

            # بررسی اینکه ویدیو یا مدیا موجود است
            if not info:
                await message.edit("نمی‌توان اطلاعات ویدیو را دریافت کرد.")
                return

            # استخراج URL مستقیم مدیا
            media_url = info.get('url')
            title = info.get('title', 'video')
            ext = info.get('ext', 'mp4')

            # دانلود مستقیم فایل به صورت بایت
            import requests
            response = requests.get(media_url)
            if response.status_code != 200:
                await message.edit("در دریافت فایل ویدیو خطایی رخ داد.")
                return

            file_bytes = io.BytesIO(response.content)
            file_bytes.name = f"{title}.{ext}"

            await client.send_video(
                chat_id,
                file=file_bytes,
                caption="ویدیو با موفقیت از اینستاگرام دریافت شد!"
            )

            await message.edit("ویدیو با موفقیت ارسال شد!")

    except Exception as e:
        await message.edit("در دریافت ویدیو مشکلی پیش آمد. لطفاً دوباره امتحان کنید.")
		
@slf.on(events.NewMessage(pattern='/stats', from_users='me'))
async def handle_stats(event):
    stats_message = (
        f"تعداد درخواست‌های دانلود: {download_requests}\n"
        f"تعداد دانلود های موفق از اینستاگرام: {successful_downloads}"
    )
    await event.edit(stats_message)

from telethon import events
from telethon.tl.types import User, Chat, Channel

@slf.on(events.NewMessage(pattern="^امارمن$", from_users='me'))
async def amar_man(event):
    private_chats = 0
    small_groups = 0
    supergroups = 0
    channels = 0
    total_dialogs = 0
    unread_messages = 0
    pinned_chats = 0

    async for dialog in client.iter_dialogs():
        total_dialogs += 1

        if getattr(dialog, 'pinned', False):
            pinned_chats += 1
        unread_messages += getattr(dialog, 'unread_count', 0)
        entity = dialog.entity
            # دسته‌بندی بر اساس نوع
        if isinstance(entity, User):
            private_chats += 1
        elif isinstance(entity, Chat):
            small_groups += 1
        elif isinstance(entity, Channel):
            if getattr(entity, 'megagroup', False):
                supergroups += 1
            elif getattr(entity, 'broadcast', False):
                channels += 1

    response = (
        "📊 آمار چت‌ها:\n"
        f"• چت‌های خصوصی: {private_chats}\n"
        f"• گروه‌های کوچک: {small_groups}\n"
        f"• سوپرگروه‌ها: {supergroups}\n"
        f"• کانال‌ها: {channels}\n"
        f"• کل دیالوگ‌ها: {total_dialogs}\n"
        f"• پیام‌های خوانده نشده: {unread_messages}\n"
        f"• چت‌های پین‌شده: {pinned_chats}"
    )
    await event.respond(response)

@slf.on(events.NewMessage(from_users='me'))
async def amo_abolfazl(event:Message):
	global db, conn, self_enabled, love_messages, love_target
	mode = json.loads(conn.execute(f"SELECT mode FROM SELF").fetchall()[0][0])
	message = event.message
	text = event.text
	chat_id = event.chat_id

	try:
		row = conn.execute("SELECT expiration_date FROM SELF").fetchone()
		if row and row[0] is not None:
			try:
				expiration_value = int(row[0])
			except ValueError:
				print("مشکل در تبدیل مقدار به عدد صحیح.")
				return
			if expiration_value <= 0:
				await event.edit("کاربر گرامی از انقضای سلف شما زمانی باقی نمانده است لطفا با ادمین مربوطه در ارتباط باشید \n @ATSelfShop با تشکر از انتخاب شما")
				sys.exit()
				return
		else:
			print("هیچ سطری پیدا نشد یا مقدار null است.")
	except Exception as e:
		print(f"خطا در اجرای کوئری: {e}")


	if self_enabled and not text.startswith('.') and not text.startswith('/'):
		if event.message and event.message.text and not event.message.media:
			if (mode["boldmode"] == "on"):
				await event.edit(f"**{text}**")
			elif (mode["italicmode"] == "on"):
				await event.edit(f"__{text}__")
			elif (mode["codemode"] == "on"):
				await event.edit(f"`{text}`")
			elif (mode["underline"] == "on"):
				await event.edit(f"<u>{text}</u>",parse_mode='html')
			elif (mode["strikemode"] == "on"):
				await event.edit(f"~~{text}~~")

	if text == "سلف روشن":
		if not self_enabled:
			self_enabled = True
			await message.edit("سلف روشن شد ✓")
		else:
			await message.edit("سلف روشن است ✓")

	if text == "سلف خاموش":
		if self_enabled:
			self_enabled = False
			await message.edit("سلف خاموش شد ✓")
		else:
			await message.edit("سلف خاموش است ✓")

	if not self_enabled:
		return

	if text.startswith("تنظیم دشمن"):
	    try:
	        myid = await slf.get_me()
	        if event.reply_to_msg_id:
	            id = await event.get_reply_message()
	            from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	            if from_id != myid.id:
	            	if from_id not in enemy_list:
	        	    	enemy_list.append(from_id)
	        	    	await event.edit(f"<a href=tg://user?id={from_id}>{from_id} به لیست دشمنان اضافه شد </a>",parse_mode='html')
	            	else:
	        	        await event.edit(f"<a href=tg://user?id={from_id}>{from_id} هم اکنون درون لیست دشمنان قرار دارد </a>",parse_mode='html')
	        else:
	    	    id = await slf.get_entity(text.split()[1])
	    	    if id.id != myid.id:
	    		    if id.id not in enemy_list:
	    			    enemy_list.append(id.id)
	    			    await event.edit(f"<a href=tg://user?id={id.id}>{id.id} به لیست دشمنان اضافه شد </a>",parse_mode='html')
	    		    else:
	    		        await event.edit(f"<a href=tg://user?id={id.id}>{id.id} هم اکنون درون لیست دشمنان قرار دارد </a>",parse_mode='html')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text == "پنل" or text == "panel":
	   results = await slf.inline_query(idbot, 'panel')
	   message = await results[0].click(chat_id)
	   await event.delete()

	elif text == "نرخ ارز":
		response = get_exchange_rates()
		await event.edit(response)

	elif text.startswith('حذف دشمن'):
		try:
			if event.reply_to_msg_id:
				id = await event.get_reply_message()
				from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
				if from_id in enemy_list:
					enemy_list.remove(from_id)
					await event.edit(f'{from_id} از لیست دشمنان پاک شد')
				else:
					await event.edit(f'{from_id} درون لیست دشمنان موجود نیست')
			else:
				id = await slf.get_entity(text.split()[1])
				if id.id in enemy_list:
					enemy_list.remove(id.id)
					await event.edit(f"{id.id} از لیست دشمنان پاک شد")
				else: 
					await event.edit(f'{id.id} درون لیست دشمنان وجود ندارد')
		except Exception as e:
			await event.edit(f"‡ Error {e}")

	elif text == 'پاکسازی دشمن':
	    t,i = '',1
	    if len(enemy_list) >= 1:
	    	for id in enemy_list:
	    		info = await slf.get_entity(id)
	    		t += f"<a href=tg://user?id={id}>{i} : {info.first_name}</a>\n "
	    		i+=1
	    	await event.edit(f'لیست دشمنان خالی شد : \n {t}',parse_mode='html')
	    	enemy_list.clear()
	    else:
	    	await event.edit(f'لیست دشمنان هم اکنون خالی است')

	elif text.startswith('افزودن فحش'):
		t = text.replace("افزودن فحش ", "")
		t = t.split(',')
		added = False
		for i in t:
			i = i.strip()
			if i not in fosh_list:
				fosh_list.append(i)
				added = True
			else:
				await event.edit(f"فحش '{i}' قبلاً در لیست وجود دارد.")
		if added:
			await event.edit('فحش جدید به لیست فحش‌ها افزوده شد.')


	elif text.startswith('حذف فحش'):
		t = text.replace("حذف فحش ", "")
		t = t.split(',')
		for i in t:
			try:
				fosh_list.remove(i.strip())
				await event.edit('فحش مورد نظر از لیست فحش‌ها حذف شد.')
			except ValueError:
				await event.edit(f'فحش "{i.strip()}" در لیست وجود نداشت.')

	elif text.startswith('لیست فحش'):
		list_text = ', '.join(fosh_list)
		await event.edit(f'لیست فحش‌های دشمنان:\n{list_text}')

	elif text == "لیست دشمن":
		if len(enemy_list) >= 1:
			t = ""
			for id in enemy_list:
				info = await slf.get_entity(id)
				t += f"<a href=tg://user?id={id}>{id} : {info.first_name}</a>\n "
			await event.edit(f'لیست دشمنان : \n {t}', parse_mode='html')
		else:
			await event.edit('لیست دشمنان خالی است')


	elif text.startswith("سکوت"):
	    try:
	        myid = await slf.get_me()
	        if event.reply_to_msg_id:
	            id = await event.get_reply_message()
	            from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	            if from_id != myid.id:
	            	if from_id not in mute:
	        	    	mute.append(from_id)
	        	    	await event.edit(f"{from_id} به لیست ساکت شده ها اضافه شد")
	            	else:
	        	        await event.edit(f"{from_id} درون لیست موجود است")
	        else:
	    	    id = await slf.get_entity(text.split()[1])
	    	    if id.id != myid.id:
	    		    if id.id not in mute:
	    			    mute.append(id.id)
	    			    await event.edit(f"{id.id} به لیست سکوت شده ها اضافه شد")
	    		    else:
	    		        await event.edit(f"{id.id} درون لیست موجود است")
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('حذف سکوت'):
		try:
			if event.reply_to_msg_id:
				id = await event.get_reply_message()
				from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
				if from_id in mute:
					mute.remove(from_id)
					await event.edit(f'{from_id} از لیست ساکت شده ها خارج شد')
				else:
					await event.edit(f'{from_id} درون لیست ساکت شده ها وجود ندارد')
			else:
				id = await slf.get_entity(text.split()[1])
				if id.id in mute:
					mute.remove(id.id)
					await event.edit(f"{id.id} از لیست ساکت شده ها خارج شد")
				else: 
					await event.edit(f'{id.id} این فرد درون لیست سکوت شده ها موجود نیست')
		except Exception as e:
			await event.edit(f"‡ Error {e}")

	elif text == "لیست سکوت":
	    if len(mute) >= 1:
	        t = ""
	        for id in mute:
	        	info = await slf.get_entity(id)
	        	t += f"<a href=tg://user?id={id}>{i} : {info.first_name}</a>\n "
	        	await event.edit(f'لیست سکوت افراد ساکت شده : \n {t}',parse_mode='html')
	    else:
	    	await event.edit(f'لیست افراد ساکت شده خالی است')
			
    
	elif text == 'پاکسازی سکوت':
	    t = ''
	    i = 1
	    if len(mute) >= 1:
	    	for id in mute:
	    		info = await slf.get_entity(id)
	    		t += f"<a href=tg://user?id={id}>{i} : {info.first_name}</a>\n "
	    		i+=1
	    	await event.edit(f'لیست افراد ساکت شده خالی شد : \n {t}',parse_mode='html')
	    	mute.clear()
	    else:
	    	await event.edit(f'لیست افراد ساکت شده خالی است')

	elif text.startswith('افزودن پاسخ'):
	    try:
	        an = text.replace("افزودن پاسخ","")[1::].split(":")[0]
	        en = text.replace("افزودن پاسخ","")[1::].split(":")[1]
	        answer.append(an)
	        javab.append(en)
	        await event.edit(f'پاسخ با موفقیت اضافه شد: \n[{an} -> {en}]')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('حذف پاسخ'):
	    if text.replace("حذف پاسخ" , "")[1::] in answer:
	        num = answer.index(text.replace("حذف پاسخ" , "")[1::])
	        answer.remove(answer[num])
	        javab.remove(javab[num])
	        await event.edit("این پاسخ با موفقیت از لیست جواب ها پاک شد") 
	    else:
	        await event.edit("این پاسخ درون لیست موجود نبود") 
	 
	elif text.startswith('لیست پاسخ ها'):
	    a,n= "",0
	    if len(answer) >= 1:
	        for i in range(0,int(len(answer))):
	            a+= f"{n} : {answer[i]} -> {javab[i]} \n"
	        await event.edit("<b> لیست پاسخ ها عبارت است از : </b>\n {a}",parse_mode='html') 
	    else:
	        await event.edit("لیست پاسخ ها خالی است ")
	elif text == 'پاکسازی پاسخ':
	    if len(answer) >= 1:
	        answer.clear()
	        javab.clear()
	        event.edit("لیست پاسخ ها پاکسازی شد") 
	    else:
	    	event.edit("لیست پاسخ ها خالی است")

	elif text.startswith('تغییر نام'):
	    t=text.replace("تغییر نام ", "")
	    await slf(functions.account.UpdateProfileRequest(first_name=t))

	elif text.startswith('تغییر نام بزرگ'):
	    t=text.replace("تغییر نام بزرگ ", "")
	    await slf(functions.account.UpdateProfileRequest(last_name=t))

	elif text.startswith('تنظیم بیو'):
	    t=text.replace("تنظیم بیو ", "")
	    await slf(functions.account.UpdateProfileRequest(about=t))

	elif text.startswith('کلون'):
	    try:
	        if event.reply_to_msg_id:
	            id = await event.get_reply_message()
	            from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	            get = await slf.get_entity(from_id)
	            first_name = get.first_name
	            last_name = get.last_name
	            g = await slf(functions.users.GetFullUserRequest(get.id))
	            about = g.full_user.about
	        else:
	            t=text.replace("کلون ", "")
	            get = await slf.get_entity(t)
	            from_id=get.id
	            first_name = get.first_name
	            last_name = get.last_name
	            g = await slf(functions.users.GetFullUserRequest(get.id))
	            about = g.full_user.about
	        await slf(functions.account.UpdateProfileRequest(first_name=first_name,last_name=last_name,about=about))
	        try:
	            photo = await slf.download_profile_photo(from_id)
	            m=await slf.upload_file(photo)
	            await slf(functions.photos.UploadProfilePhotoRequest(fallback=True,file=await slf.upload_file(m)))
	            os.remove(photo)
	        except:
	        	pass
	        await event.edit(f'با موفقیت همه موارد این شخص کپی شد \n نام : {first_name} \n نام بزرگ : {last_name} \n بیوگرافی : {about}')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('بلاک'):
	    try:
	        if event.reply_to_msg_id:
	            id = await event.get_reply_message()
	            from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	        else:
	            t=text.replace("بلاک ", "")
	            get = await slf.get_entity(t)
	            from_id=get.id
	        await slf(functions.contacts.BlockRequest(id=from_id))
	        await event.edit('<b>✓ شخص مورد نظر با موفقیت مسدود شد </b>',parse_mode='html')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('انبلاک'):
	    try:
	        if event.reply_to_msg_id:
	            id = await event.get_reply_message()
	            from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	        else:
	            t=text.replace("انبلاک ", "")
	            get = await slf.get_entity(t)
	            from_id=get.id
	        await slf(functions.contacts.UnblockRequest(id=from_id))
	        await event.edit('<b>✓ شخص مورد نظر با موفقیت انبلاک شد </b>',parse_mode='html')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('پیوستن'):
	    try:
	        a= text.replace('پیوستن ','')
	        await slf(functions.channels.JoinChannelRequest(channel=a))
	        await event.edit('<b>✓ شما با موفقیت به چت ارسال شده پیوستید</b>',parse_mode='html')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text.startswith('لفت زدن'):
	    try:
	        a=text.replace('لفت زدن ','')
	        await slf(functions.channels.LeaveChannelRequest(channel=a))
	        await event.edit('<b>✓ شما با موفقیت از این چت خارج شدید</b>',parse_mode='html')
	    except Exception as e:
	        await event.edit(f"‡ Error {e}")

	elif text=='اطلاعات پیام':
		if event.reply_to_msg_id:
		    try:
		        i = await event.get_reply_message()
		        mid = i.id
		        user_id = i.from_id.user_id if i.from_id else i.peer_id.user_id
		        get = await slf.get_entity(user_id)
		        name= get.first_name
		        lname= get.last_name
		        await event.edit(f"** اطلاعات پیغام انتخاب شده : **\n  **ایدی پیغام 🧿** : `{mid}` \n   **🆔ایدی شخص ارسال کننده** : `{user_id}` \n   **📛اسم کوچک** : `{name}` \n   **✳️اسم بزرگ** : `{lname}`",parse_mode='markdown')
		    except Exception as e:
		        await event.edit(f"‡ Error {e}")

	elif text.startswith('ایدی'):
	    if event.reply_to_msg_id:
	        id = await event.get_reply_message()
	        from_id = id.from_id.user_id if id.from_id else id.peer_id.user_id
	        g = await slf(functions.users.GetFullUserRequest(from_id))
	    else:
	        t=text.replace('ایدی ','')
	        from_id=t
	    t=""
	    m = await slf.get_entity(from_id)
	    try:
	    	for i in m.usernames:
	        	t+=f" @{i.username} |"
	    except:
	     	t = "None"
	    await event.edit(f'''**✓ اطلاعات کاربر انتخاب شده: : \nایدی عددی : `{m.id}`\nاسم کوچک: `{m.first_name}`\nاسم بزرگ: `{m.last_name}`\nآیدی: `{m.username}`\ایدی ها : `{t}`\nحالت اسکم اکانت : `{m.scam}`\n حالت فیک اکانت : `{m.fake}`\nوضعیت پرمیوم بودن : `{m.premium}`\n**''')

	if text == 'dl' and event.reply_to_msg_id:
	    message = await event.get_reply_message()
	    await event.delete()
	    media = await slf.download_media(message)
	    await slf.send_file('me',media,caption="😈")
	    os.remove(media)

	if text in ["تاریخ", "ساعت", "date", "time", "تایم", "زمان"]:
		info = get_date_time_info()
		response_text = (
			f"⏰ ساعت : {info['time_now']}"
			f"\n📅 تاریخ : ({info['jalali_date']} - {info['gregorian_date']})"
			f"\n☀️ روز : ({info['day_name_fa']} - {info['day_name_en']})"
			f"\n🌙 ماه : ({info['jalali_month_name_fa']} - {info['month_name_en']})"
			f"\nUTC : ({info['utc_date']})"
		)
		await event.message.edit(response_text)

	if text.startswith("تنظیم پیام خودکار "):
		await set_auto_message(event)

	if text == "حذف پیام خودکار":
		await delete_auto_message(event)

	if text == "لیست پیام خودکار":
		await list_auto_messages(event)


	elif text.startswith('.copy'):
		t = text.replace('.copy ', '')
		n = t.split('-')
		chat_id = n[0]
		message_id = int(n[1])
		try:
			message = await slf.get_messages(chat_id, ids=message_id)
			if message.media:
				media = await slf.download_media(message)
				await slf.send_file('me', media, caption=message.message)
				os.remove(media)
			else:
				await slf.send_message('me', message.message)
		except Exception as e:
			await slf.send_message('me', f"خطا رخ داد: {e}")

	if text.startswith("spam"):
		match = re.match(r"spam\s+(\d+)\s+(.+)", text)
		if match:
			count = int(match.group(1))
			message_text = match.group(2)
			if count > 0 and message_text:
				await event.delete()
				for _ in range(count):
					try:
						await event.respond(message_text)
					except Exception as e:
						print(f"Error sending Spam message: {e}")
			else:
				await event.respond("لطفاً تعداد(حداکثر 100) و پیام معتبر وارد کنید.")
		else:
			await event.respond("نحوه استفاده: spam <تعداد Max: 100> <متن پیام>")

	if text.startswith("اسپم"):
		match = re.match(r"اسپم\s+(\d+)\s+(.+)", text)
		if match:
			count = int(match.group(1))
			message_text = match.group(2)
			if count > 0 and message_text:
				await event.delete()
				for _ in range(count):
					try:
						await event.respond(message_text)
					except Exception as e:
						print(f"Error sending Spam message: {e}")
			else:
				await event.respond("لطفاً تعداد(حداکثر 100) و پیام معتبر وارد کنید.")
		else:
			await event.respond("نحوه استفاده: اسپم <تعداد Max: 100> <متن پیام>")

	if text.startswith("شمارش"):
		match = re.match(r"شمارش\s+(\d+)", text)
		if match:
			count = int(match.group(1))
			if 0 < count <= 100:
				for i in range(1, count + 1):
					await event.delete()
					try:
						await event.respond(str(i))
					except Exception as e:
						print(f"Error sending message {i}: {e}")
					await asyncio.sleep(1)
			else:
				await event.respond("لطفاً تعداد بین 1 تا 100 وارد کنید.")
		else:
			await event.respond("نحوه استفاده: شمارش <تعداد Max: 100>")

	elif text.startswith('.gpt'):
		message = await event.edit('**درحال اتصال به هوش مصنوعی ...**')
		if event.reply_to_msg_id:
			i = await event.get_reply_message()
			response = gpt(i.text)
		else:
			response = gpt(text.replace('.gpt ', ''))
		await message.edit(response)

async def get_sender_id(m):
    from telethon.tl.types import PeerUser, PeerChannel, PeerChat
    if hasattr(m, 'from_id') and m.from_id:
        if isinstance(m.from_id, PeerUser):
            return m.from_id.user_id
        elif isinstance(m.from_id, PeerChannel):
            return None 
        elif isinstance(m.from_id, PeerChat):
            return None
    elif hasattr(m, 'peer_id') and m.peer_id:
        if isinstance(m.peer_id, PeerUser):
            return m.peer_id.user_id
        elif isinstance(m.peer_id, PeerChannel):
            return None
        elif isinstance(m.peer_id, PeerChat):
            return None
    return None

@slf.on(events.NewMessage())
async def online(m: Message):
    chat_id = m.chat_id
    text = m.raw_text
    from_id = await get_sender_id(m)
    if from_id is None:
        pass
    if from_id == 777000:
        print(message)

    global db, conn, last_gpt_time
    q = json.loads(query('lockpv'))
    if m.is_private and q['lockpv'] == "on" and from_id != await get_me():
        if q['block'] == 'on':
            await slf(functions.contacts.BlockRequest(id=from_id))
        elif q['delmessage'] == "on":
            await m.delete()
        
#    elif text == "😐" and from_id != await get_me():
#        await m.reply("😐")
    elif from_id in enemy_list:
        await m.reply(random.choice(fosh_list))
    elif from_id in mute:
        await m.delete()
    elif conn.execute(f"SELECT answer FROM SELF").fetchall()[0][0] == "on" and from_id != await get_me():
        info = await slf.get_entity(from_id)
        if text in answer and info.bot == False:
            await m.reply(javab[answer.index(text)])
    elif m.is_private and conn.execute("SELECT gpt FROM SELF").fetchall()[0][0] == "on" and from_id != await get_me():
        current_time = time.time()
        if current_time - last_gpt_time >= 30:
            try:
                sender_id = from_id
                await m.reply(gpt(text))
                last_gpt_time = current_time
            except Exception as e:
                print(f"Error checking online status or replying with GPT: {e}")
        else:
            pass
 
    a = json.loads(conn.execute(f"SELECT action FROM SELF").fetchall()[0][0])

    if a.get('typing') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageTypingAction()))
    elif a.get('upload_photo') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageUploadPhotoAction(1)))
    elif a.get('record_video') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageRecordVideoAction()))
    elif a.get('upload_video') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageUploadVideoAction(1)))
    elif a.get('record_audio') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageRecordAudioAction()))
    elif a.get('upload_audio') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageUploadAudioAction(1)))
    elif a.get('upload_document') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageUploadDocumentAction(1)))
    elif a.get('choose_sticker') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageChooseStickerAction()))
    elif a.get('gamming') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageGamePlayAction()))
    elif a.get('choose_contact') == "on" and not m.is_channel:
        await slf(functions.messages.SetTypingRequest(chat_id, types.SendMessageChooseContactAction()))

scheduler = AsyncIOScheduler()
scheduler.add_job(time_accs, "interval", seconds=60)
scheduler.add_job(reduce_expiration, "interval", hours=24)
scheduler.start()
db.commit()
slf.start()
print('\033[1m\033[92mBot Now Running ...\n\033[31mSelf Telegram Channel : @ATSelfShop')
print('\033[0m dont Forgot Enable Helper Bot!')
slf.send_message('me', "سلف با موفقیت ریستارت شد")

slf.run_until_disconnected()