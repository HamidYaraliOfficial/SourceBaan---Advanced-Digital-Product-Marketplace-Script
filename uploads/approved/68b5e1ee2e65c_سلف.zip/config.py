token = ""
api_id = 
api_hash = ""
owner = []
idbot = ""