import sqlite3
import random
from pathlib import Path
import string
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, InlineQueryHandler, ContextTypes, filters
from telegram.constants import ParseMode

API_KEY = ''

DB_PATH = Path(__file__).parent / "like.db"


conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cursor = conn.cursor()


def init_db():
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS user (
        id INTEGER PRIMARY KEY,
        step TEXT
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS like (
        hash TEXT PRIMARY KEY,
        type TEXT,
        file TEXT,
        caption TEXT,
        join_channel TEXT DEFAULT 'none',
        button TEXT,
        admin INTEGER,
        likes1 INTEGER DEFAULT 0,
        likes2 INTEGER DEFAULT 0,
        likes3 INTEGER DEFAULT 0,
        likes4 INTEGER DEFAULT 0,
        likes5 INTEGER DEFAULT 0,
        likes6 INTEGER DEFAULT 0
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS set_table (
        id INTEGER,
        post INTEGER
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY,
        history TEXT
    )
    ''')
    
    conn.commit()


def random_string(length=6):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


def str_split(text):
    return list(text)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    

    cursor.execute("SELECT * FROM user WHERE id = ?", (user_id,))
    if cursor.fetchone() is None:
        cursor.execute("INSERT INTO user (id, step) VALUES (?, 'none')", (user_id,))
        conn.commit()
    

    cursor.execute("UPDATE user SET step = 'none' WHERE id = ?", (user_id,))
    conn.commit()
    
    await update.message.reply_text(
        "بیایید یک پیام با دکمه‌های واکنش اموجی ایجاد کنیم. ابتدا پیام را برای من بفرستید. "
        "این می‌تواند هر چیزی باشد — متن، عکس، ویدیو یا حتی استیکر\n"
        parse_mode=ParseMode.MARKDOWN
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    

    cursor.execute("UPDATE user SET step = 'none' WHERE id = ?", (user_id,))
    conn.commit()
    
    await update.message.reply_text(
        "من می‌توانم به شما در ایجاد پست‌های با دکمه‌های واکنش بر اساس اموجی کمک کنم، آن‌ها را با دوستانتان به اشتراک بگذارید و نظرات آن‌ها را جمع‌آوری کنید. "
        "هم‌اکنون امکان ارسال پست‌ها فقط در چت‌های خصوصی وجود دارد.\n\n"
        "همچنین می‌توانید از حالت اینلاین برای ایجاد سریع پست‌ها با دکمه‌های 👍/👎 استفاده کنید. برای این کار در هر چتی پیامی با آیدی + `share-` من شروع کنید و سپس شناسه پست خود را بنویسید",
        parse_mode=ParseMode.MARKDOWN
    )


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    

    cursor.execute("SELECT step FROM user WHERE id = ?", (user_id,))
    result = cursor.fetchone()
    step = result[0] if result else 'none'
    
    if step != "none":
        cursor.execute("UPDATE user SET step = 'none' WHERE id = ?", (user_id,))
        conn.commit()
        await update.message.reply_text("دستور لغو شد. اگر می‌خواهید شروع کنید، فقط یک پیام برای من بفرستید")
    else:
        await update.message.reply_text("هیچ دستور فعالی برای لغو وجود ندارد، من در حال استراحت هستم 💤")


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    user_id = query.from_user.id
    
    if data.startswith("like-"):

        parts = data.split("-")
        like_id = parts[1]
        button_index = int(parts[2])
        

        cursor.execute("SELECT * FROM like WHERE hash = ?", (like_id,))
        like_data = cursor.fetchone()
        
        if like_data:
            join_channel = like_data[4]
            button_texts = like_data[5].split("-") if like_data[5] else []
            
            if join_channel == 'none':

                column_name = f"likes{button_index}"
                cursor.execute(f"UPDATE like SET {column_name} = {column_name} + 1 WHERE hash = ?", (like_id,))
                conn.commit()
                

                cursor.execute(f"SELECT {column_name} FROM like WHERE hash = ?", (like_id,))
                likes_count = cursor.fetchone()[0]
                

                keyboard = []
                for i, emoji in enumerate(button_texts, start=1):
                    if i > 6:  # حداکثر ۶ دکمه
                        break
                    cursor.execute(f"SELECT likes{i} FROM like WHERE hash = ?", (like_id,))
                    count = cursor.fetchone()[0]
                    keyboard.append([InlineKeyboardButton(f"{emoji} ({count})", callback_data=f"like-{like_id}-{i}")])
                

                await query.edit_message_reply_markup(reply_markup=InlineKeyboardMarkup(keyboard))
                await query.answer(f"شما {button_texts[button_index-1]} این پست را انتخاب کردید...!")
            else:

                try:
                    member = await context.bot.get_chat_member(join_channel, user_id)
                    if member.status in ['member', 'administrator', 'creator']:

                        column_name = f"likes{button_index}"
                        cursor.execute(f"UPDATE like SET {column_name} = {column_name} + 1 WHERE hash = ?", (like_id,))
                        conn.commit()
                        

                        cursor.execute(f"SELECT {column_name} FROM like WHERE hash = ?", (like_id,))
                        likes_count = cursor.fetchone()[0]
                        

                        keyboard = []
                        for i, emoji in enumerate(button_texts, start=1):
                            if i > 6:  # حداکثر ۶ دکمه
                                break
                            cursor.execute(f"SELECT likes{i} FROM like WHERE hash = ?", (like_id,))
                            count = cursor.fetchone()[0]
                            keyboard.append([InlineKeyboardButton(f"{emoji} ({count})", callback_data=f"like-{like_id}-{i}")])
                        

                        await query.edit_message_reply_markup(reply_markup=InlineKeyboardMarkup(keyboard))
                        await query.answer(f"شما {button_texts[button_index-1]} این پست را انتخاب کردید...!")
                    else:
                        await query.answer("ابتدا باید در کانال عضو شوید!")
                except Exception as e:
                    print(f"Error checking channel membership: {e}")
                    await query.answer("خطا در بررسی عضویت در کانال!")


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.message
    

    cursor.execute("SELECT step FROM user WHERE id = ?", (user_id,))
    result = cursor.fetchone()
    step = result[0] if result else 'none'
    
    if step == 'none':

        if message.text and not message.text.startswith('/'):
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-text-{message.text}-none", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.photo:
            file_id = message.photo[-1].file_id
            caption = message.caption or 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-photo-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.video:
            file_id = message.video.file_id
            caption = message.caption or 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-video-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.document:
            file_id = message.document.file_id
            caption = message.caption or 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-document-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.voice:
            file_id = message.voice.file_id
            caption = message.caption or 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-voice-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.audio:
            file_id = message.audio.file_id
            caption = message.caption or 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-audio-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
        
        elif message.sticker:
            file_id = message.sticker.file_id
            caption = 'none'
            cursor.execute("UPDATE user SET step = ? WHERE id = ?", (f"SendEmoji-sticker-{file_id}-{caption}", user_id))
            conn.commit()
            await message.reply_text("حالا یک یا چند ایموجی برای استفاده در دکمه‌ها برایم بفرستید (حداکثر ۶ ایموجی). اگر نظرتان تغییر کرد از /cancel استفاده کنید")
    
    elif step.startswith('SendEmoji'):

        if message.text:
            parts = step.split('-')
            msg_type = parts[1]
            content = parts[2]
            caption = parts[3] if len(parts) > 3 else 'none'
            

            like_hash = random_string(6)
            

            emojis = str_split(message.text)
            button_text = "-".join(emojis[:6])  # حداکثر ۶ ایموجی
            
            cursor.execute(
                "INSERT INTO like (hash, type, file, caption, admin, button) VALUES (?, ?, ?, ?, ?, ?)",
                (like_hash, msg_type, content, caption, user_id, button_text)
            )
            conn.commit()
            

            keyboard = []
            for i, emoji in enumerate(emojis[:6], start=1):  # حداکثر ۶ دکمه
                keyboard.append([InlineKeyboardButton(emoji, callback_data=f"like-{like_hash}-{i}")])
            

            keyboard.append([InlineKeyboardButton("انتشار", switch_inline_query=f"share-{like_hash}")])
            

            try:
                if msg_type == "text":
                    sent_message = await message.reply_text(
                        content,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "photo":
                    sent_message = await message.reply_photo(
                        content,
                        caption=caption if caption != 'none' else None,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "video":
                    sent_message = await message.reply_video(
                        content,
                        caption=caption if caption != 'none' else None,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "document":
                    sent_message = await message.reply_document(
                        content,
                        caption=caption if caption != 'none' else None,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "voice":
                    sent_message = await message.reply_voice(
                        content,
                        caption=caption if caption != 'none' else None,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "audio":
                    sent_message = await message.reply_audio(
                        content,
                        caption=caption if caption != 'none' else None,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                elif msg_type == "sticker":
                    sent_message = await message.reply_sticker(
                        content,
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )

                await message.reply_text(
                    f"✅ پست ایجاد شد.\n\n"
                    f"شناسه پست: `{like_hash}`\n\n"
                    f"اکنون می‌توانید از دکمه 'انتشار' برای ارسال پست به دوستانتان استفاده کنید.\n\n"
                    f"همچنین می‌توانید از این شناسه برای اشتراک‌گذاری مستقیم پست استفاده کنید:\n"
                    f"`@{context.bot.username} share-{like_hash}`",
                    reply_to_message_id=sent_message.message_id,
                    parse_mode='Markdown'
                )
                
            except Exception as e:
                print(f"Error sending message: {e}")
                await message.reply_text("خطایی در ایجاد پست شما رخ داد.")
            

            cursor.execute("UPDATE user SET step = 'none' WHERE id = ?", (user_id,))
            conn.commit()


async def inline_query_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.inline_query.query
    user_id = update.inline_query.from_user.id
    
    if query.startswith("share-"):
        like_id = query.replace("share-", "")
        

        cursor.execute("SELECT * FROM like WHERE hash = ?", (like_id,))
        like_data = cursor.fetchone()
        
        if like_data:
            msg_type = like_data[1]
            content = like_data[2]
            caption = like_data[3]
            button_texts = like_data[5].split("-") if like_data[5] else []
            

            keyboard = []
            for i, emoji in enumerate(button_texts, start=1):
                if i > 6:  # حداکثر ۶ دکمه
                    break
                likes_count = like_data[6 + i]  # likes1 تا likes6
                keyboard.append([InlineKeyboardButton(f"{emoji} ({likes_count})", callback_data=f"like-{like_id}-{i}")])
            

            if msg_type == "text":
                result = InlineQueryResultArticle(
                    id=like_id,
                    title="❤️ اینجا کلیک کنید...!",
                    input_message_content=InputTextMessageContent(content),
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            else:

                result = InlineQueryResultArticle(
                    id=like_id,
                    title="این نوع محتوا هنوز در حالت اینلاین پشتیبانی نمی‌شود",
                    input_message_content=InputTextMessageContent("این نوع محتوا هنوز در حالت اینلاین پشتیبانی نمی‌شود")
                )
            
            await update.inline_query.answer([result], cache_time=0, is_personal=True)


def main():

    init_db()
    

    application = (
        Application.builder()
        .token(API_KEY)
        # .proxy("http://127.0.0.1:10808")
        # .get_updates_proxy("http://127.0.0.1:10808")
        .build()
    )
    

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("cancel", cancel))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(InlineQueryHandler(inline_query_handler))
    application.add_handler(MessageHandler(filters.ALL, message_handler))
    

    application.run_polling()

if __name__ == "__main__":
    main()
