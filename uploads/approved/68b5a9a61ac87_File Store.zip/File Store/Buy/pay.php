<?php
error_reporting(0);
header('Content-type: application/json;');
$amountkobs = $_GET['amount'];
$orderid = $_GET['id'];
$imdevabolfazl = "https://server.telegram.com/Buy/back.php"; //آدرس فایل back


if (!isset($amountkobs) or !isset($orderid)) {

  echo "تراکنش شما با مشکل مواجه شد
لطفا از دست زدن به مقادیر پرهیز کرده و دوباره امتحان کنید";
} else {


  $params = array(
    'order_id' => "$orderid",
    'amount' => "$amountkobs",
    'callback' => "$imdevabolfazl",
  );

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment');
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'X-API-KEY: apikey' //api کی دریافتی از آیدی پی
  ));

  $result = curl_exec($ch);
  curl_close($ch);

  $rep = json_decode($result, true);
  $code = $rep['id'];
  $transid = $rep['link'];


  echo "$code\n$transid";

  if (!isset($code) or !isset($transid)) {
    echo "تراکنش با مشکل روبرو شد
لطفا دوباره امتحان کنید";
  } else {

    header("Location: $transid");
  }
}