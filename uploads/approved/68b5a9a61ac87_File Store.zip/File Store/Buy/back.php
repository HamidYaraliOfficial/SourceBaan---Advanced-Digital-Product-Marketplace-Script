<?php
header('Content-type: application/json;');
include "config.php";
error_reporting(0);
$status        = $_POST['status'];
$track_id      = $_POST['track_id'];
$id            = $_POST['id'];
$order_id      = $_POST['order_id'];
$amount        = $_POST['amount'];
$card_no       = $_POST['card_no'];
$hashed_card   = $_POST['hashed_card_no'];
$date          = $_POST['date'];

if (!isset($status) or !isset($track_id) or !isset($id) or !isset($order_id) or !isset($amount) or !isset($card_no) or !isset($hashed_card) or !isset($date)) {

  echo "تراکنش شما مورد تایید نیست";
} else {

  if ($status == '10') {

    $params = array(
      'id' => "$id",
      'order_id' => "$order_id",
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment/verify');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'X-API-KEY: apikey', //api کی دریافتی از آیدی پی
    ));

    $result = curl_exec($ch);
    curl_close($ch);

    $rep = json_decode($result, true);

    $status1          = $rep['status'];
    $track_idpay1     = $rep['track_id'];
    $id1              = $rep['id'];
    $order_id1        = $rep['order_id'];
    $amount1          = $rep['amount'];
    $date1            = $rep['date'];
    $track_id1        = $rep['payment']['track_id'];
    $amount2          = $rep['payment']['amount'];
    $card_no1         = $rep['payment']['card_no'];
    $hashed_card1     = $rep['payment']['hashed_card_no'];
  } else {
    echo "تراکنش ناموفق
خطا در مرحله پرداخت
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
  }
  if ($status1 == '100') {

    $result1 = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM repay WHERE id = '$id1'")); //جستجو از میان پرداختی های قبل برای جلوگیری از ثبت تراکنش تکراری
    //شما بر اساس دیتابیس خودتون ست کنید

    if ($result1 == null) {

      //کد های افزایش اعتبار به حساب کاربر
      //بر اساس دیتابیس خودتون کد ها رو ست کنید تا اعتبار رو افزایش بده

      echo "
آیدی کاربر : $order_id1\n
مبلغ تراکنش : $newcoin\n
شماره کارت : $card_no1\n
کد پیگیری : $track_id1";
    } else {
      echo "تراکنش تکراری
از تکرار مجدد خودداری کنید";
    }
  } else {
    echo "تراکنش ناموفق
تراکنش شما تایید نشد
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
  }
}