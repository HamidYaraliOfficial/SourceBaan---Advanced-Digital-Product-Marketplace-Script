<?php
flush();
ob_start();
ob_implicit_flush(1);
$load = sys_getloadavg();
$telegram_ip_ranges = [
    ['lower' => '149.154.160.0', 'upper' => '149.154.175.255'],
    ['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok = false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
    $lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
    $upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
    if ($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok = true;
}
if (!$ok) header("Location: https://irateam.ir");
include 'config.php';
include('lib/jdf.php');
// error_reporting(0);
date_default_timezone_set('Asia/Tehran');
$timestamp = time();
$time = date('H:i:s');
$timefa = str_replace(['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], range(0, 9), $time);
$date = date('Y/m/d');
$datefa = str_replace(['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], range(0, 9), $date);
//========================== // bot // ==============================
function bot($method, $datas = [])
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot' . API_KEY . '/' . $method);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    return json_decode(curl_exec($ch));
}
function save($file, $data)
{
    $data = base64_encode($data);
    file_put_contents($file, $data);
}
function loadData($url)
{
    $data = (string) base64_decode(file_get_contents($url));
    return $data;
}
function safe($text)
{
    global $connect;
    $text = $connect->real_escape_string($text);
    $array = ['$', ';', '"', "'", '<', '>'];
    return str_replace($array, '', $text);
}
function EditMessageText($chat_id, $message_id, $text, $parse_mode, $disable_web_page_preview, $keyboard)
{
    bot('editMessagetext', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => $parse_mode,
        'disable_web_page_preview' => $disable_web_page_preview,
        'reply_markup' => $keyboard
    ]);
}

function is_join($id)
{
    global $Channels;
    global $botname;
    global $channelname;
    $in_ch = [];
    foreach ($Channels as $ch_id) {
        $type = bot("getChatMember", ["chat_id" => "@$ch_id", "user_id" => $id]);
        $type = (is_object($type)) ? $type->result->status : $type['result']['status'];
        if ($type == 'creator' || $type ==  'administrator' || $type ==  'member') {
            $in_ch[$ch_id] = $type;
        } else {
            $keyboard = [];
            foreach ($Channels as $ch_id) {
                $ch_info = bot("getChat", ["chat_id" => "@$ch_id"]); //get channel
                $ch_name = (is_object($ch_info)) ? $ch_info->result->title : $ch_info['result']['title']; //channel name
                $keyboard[] = [['text' => $ch_name, 'url' => "https://t.me/$ch_id"]];
            }
            $keyboard[] = [['text' => '✅ تایید عضویت', 'callback_data' => 'join']];
            $text = "☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
❗️ برای دریافت سورس ها ، اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید


👈🏻 بعد از عضویت مجدد به ربات برگشته و اقدام به استفاده از ربات کنید";

            bot('sendmessage', [
                'chat_id' => $id,
                'text' => "$text", 'parse_mode' => 'MarkDown', 'reply_markup' =>
                json_encode(['inline_keyboard' => $keyboard])
            ]);
            break;
        }
    }
    return true;
}

function check_join($id)
{
    global $Channels;
    $in_ch = [];
    foreach ($Channels as $ch_id) {
        $type = bot("getChatMember", ["chat_id" => "@$ch_id", "user_id" => $id]);
        $type = (is_object($type)) ? $type->result->status : $type['result']['status'];
        if ($type == 'creator' || $type ==  'administrator' || $type ==  'member') {
            $in_ch[$ch_id] = $type;
        } else {
            return false;
            break;
        }
    }
    return true;
}

//========================== // update // ==============================
$update = json_decode(file_get_contents('php://input'));
if (isset($update->message)) {
    $message = $update->message;
    $message_id = $message->message_id;
    $text = safe($update->message->text);
    $chat_id = $message->chat->id;
    $tc = $message->chat->type;
    $first_name = $message->from->first_name;
    $from_id = $message->from->id;
    $username = $update->message->from->username;

    // databse
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$from_id' LIMIT 1"));
    $subscription = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `subscription` WHERE `id` = '$from_id' LIMIT 1"));
    $blocked = mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$from_id' LIMIT 1");
    $block = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$from_id' LIMIT 1"));
    $banreason = $block['reason'];
    $bandate = $block['date'];
    $bantime = $block['time'];
}
if (isset($update->callback_query)) {
    $callback_query = $update->callback_query;
    $callback_query_id = $callback_query->id;
    $data = $callback_query->data;
    $fromid = $callback_query->from->id;
    $messageid = $callback_query->message->message_id;
    $chatid = $callback_query->message->chat->id;
    // databse
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
    $blocked = mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1");
    $block = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1"));
    $banreason = $block['reason'];
    $bandate = $block['date'];
    $bantime = $block['time'];
}
//==============================// function //=======================================
function convert($string)
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١', '٠'];
    $num = range(0, 9);
    $convertedPersianNums = str_replace($persian, $num, $string);
    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
    return $englishNumbersOnly;
}
function isemoji(string $text)
{
    return mb_substr($text, 0, 1) === $text[0];
}
//==============================// keybord and Text //=======================================
$home = json_encode([
    'keyboard' => [
        [['text' => '🔍 جستجو سورس']],
        [['text' => 'محبوب ترین ها ❤️'], ['text' => '📊 جدیدترین ها']],
        [['text' => 'برترین کاربر ها 🌟'], ['text' => '👤 مدیریت حساب']],
        [['text' => 'پشتیبانی ربات 🆘'], ['text' => '📚 راهنما ربات']],
        [['text' => '🗂 ارسال سورس']],
    ],
    'resize_keyboard' => true,
]);
if (in_array($from_id, $admin)) {
    $homeData = json_decode($home, true);
    $homeData['keyboard'][] = [['text' => '👤 پنل مدیریت 👤']];
    $home = json_encode($homeData);
}
$back = json_encode([
    'keyboard' => [
        [['text' => '🔙 بازگشت']],
    ],
    'resize_keyboard' => true,
]);
$reason = json_encode([
    'keyboard' => [
        [['text' => 'نقص قوانین'], ['text' => 'نقص کپی رایت']],
        [['text' => 'هویت جعلی'], ['text' => 'فیشینگ']],
        [['text' => 'توهین به پشتیبانی'], ['text' => 'باگ ابیوز']],
        [['text' => '🔙 بازگشت']],
    ],
    'resize_keyboard' => true,
]);
$maintext = "✅ ربات $botname جهت دریافت سورس های داخل کانال $channelname و همچنین پشتیبانی کاربران ایجاد شده است

☑️ اگر سورس را نمیتوانید دریافت کنید یا از دست داده اید میتوانید از بخش افزایش سکه استفاده کنید .
👇🏻 از منوی پایین انتخاب کنید";
//===========================// block //===========================
if (mysqli_num_rows($blocked) > 0) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "❗️ خطا در ارتباط با سرور ❗️

📝 متاسفانه شما توسط مدیریت به دلیل $banreason از ربات مسدود شده اید

📆 $bandate $bantime",
    ]);
    exit();
}
//===========================// start //===========================
if (strpos($text, '#') !== false or strpos($text, "'") !== false) {
    exit;
}
//===================spam==========================
$datez = time();

if (!empty($from_id) && !in_array($from_id, $admin)) {
    $Spamlist = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM spam WHERE id = '$from_id'"));
    if ($Spamlist["id"] != true) {
        $connect->query("INSERT INTO spam (id, block, spam, timee) VALUES ('$from_id', '$datez', '0', '$datez')");
    }
}

if (!empty($Spamlist)) {
    if (time() < $Spamlist['block']) {
        $connect->close();
        die();
    } else {
        $timer = $Spamlist['timee'] + 5;
        $sp = ++$Spamlist['spam'];
        if ($datez <= $timer) {
            if ($Spamlist['spam'] >= 6) {
                $times = time() + 60;
                $connect->query("UPDATE spam SET block = '" . $times . "', spam=0 WHERE id = " . $Spamlist['id']);
                bot('sendmessage', [
                    'chat_id' => $Spamlist['id'],
                    'text' => 'کاربر گرامی,شما به علت اسپم به مدت 60 ثانیه از ربات بلاک شدید.لطفا از اسپم مجدد خودداری کنید',
                    'reply_to_message_id' => $message_id,
                    'parse_mode' => 'html',
                    'reply_markup' => null,
                    'disable_web_page_preview' => false,
                ]);
                $imdevabol = $Spamlist['id'];
                $kobs = "» [ᴄʟɪᴄᴋ ʜᴇʀᴇ](tg://user?id=$imdevabol) !";
                bot('sendmessage', [
                    'chat_id' => "$admin[0]",
                    'text' => "کاربر " . $Spamlist['id'] . " به دلیل اسپم از ربات @$usernamebot مسدود شد
$kobs",
                    'reply_to_message_id' => null,
                    'parse_mode' => 'MarkDown',
                    'reply_markup' => null,
                    'disable_web_page_preview' => false,
                ]);
                $connect->close();
                die();
            } else {
                $connect->query("UPDATE spam SET spam = $sp WHERE id = " . $Spamlist['id']);
            }
        } else {
            $connect->query("UPDATE spam SET spam = 1,timee=$datez WHERE id = " . $Spamlist['id']);
        }
    }
}

//===========================//data//==============================
if ($data == 'join') {
    if (check_join("$fromid") == 'true') {
        bot('sendmessage', [
            'chat_id' => $chatid,
            'text' => "☑️ عضویت شما در کانال تایید شد

$maintext",
            'reply_to_message_id' => $messageid,
            'reply_markup' => $home
        ]);
    } elseif (check_join("$fromid") != 'true') {
        bot('answercallbackquery', [
            'callback_query_id' => $callback_query_id,
            'text' => "❌ هنوز داخل کانال عضو نیستی",
            'show_alert' => true
        ]);
    }
}
if ($data == 'download') {
    bot('answercallbackquery', [
        'callback_query_id' => $callback_query_id,
        'text' => '❗️ این دکمه جهت نمایش تعداد محدودیت دانلود این سورس است 
👈🏻 شما میتوانید با افزایش سکه های حساب خود در ربات اقدام به دریافت سورس ها بدون محدودیت کنید',
        'show_alert' => true
    ]);
}
if ($data == 'hazinesource') {
    bot('answercallbackquery', [
        'callback_query_id' => $callback_query_id,
        'text' => '❗️ این دکمه جهت نمایش هزینه سورس است
👈🏻 شما میتوانید با افزایش سکه های حساب خود در ربات اقدام به دریافت سورس ها بدون محدودیت کنید',
        'show_alert' => true
    ]);
}
if ($data == 'kharidmovafagh') {
    bot('answercallbackquery', [
        'callback_query_id' => $callback_query_id,
        'text' => '❗️ این دکمه جهت نمایش تعداد خرید موفق است
👈🏻 شما میتوانید با افزایش سکه های حساب خود در ربات اقدام به دریافت سورس ها بدون محدودیت کنید',
        'show_alert' => true
    ]);
}
if (preg_match('/^(acceptsource\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $match[2],
        'text' => '✅ سورس شما قبول شد ، لطفا صبور باشید تا نوع سورس مشخص شود',
        'reply_to_message_id' => $message_id,
    ]);
    $file = bot('ForwardMessage', [
        'chat_id' => $admin[0],
        'from_chat_id' => $fromid,
        'message_id' => $message_id
    ])->result->message_id;
    bot('sendmessage', [
        'chat_id' => $admin[0],
        'text' => "لطفا از منوی پایین نوع سورس را مشخص کنید <a href='tg://user?id={$fromid}'>{$fromid}</a>",
        'parse_mode' => 'html',
        'reply_to_message_id' => $file,
        'reply_markup' => json_encode(['inline_keyboard' => [
            [['text' => 'سورس ویژه', 'callback_data' => "accept2^{$match[2]}"], ['text' => 'سورس معمولی', 'callback_data' => "accept1^{$match[2]}"]]
        ]])
    ]);
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
if (preg_match('/^(accept1\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => 'تایید شد',
        'reply_to_message_id' => $messageid,
        'reply_markup' => $back
    ]);
    bot('sendmessage', [
        'chat_id' => $match[2],
        'text' => "سورس شما توسط مدیریت بررسی و تایید شد ✅
		
		👈 نوع سورس : معمولی
		👈 به شما $tarofesendsource سکه داده شد",
        'reply_markup' => $back
    ]);
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$match[2]' LIMIT 1"));
    $coin = $user['coin'] + $tarofesendsource;
    $connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$match[2]' LIMIT 1");
}
if (preg_match('/^(accept2\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => 'تایید شد',
        'reply_to_message_id' => $messageid,
        'reply_markup' => $back
    ]);
    bot('sendmessage', [
        'chat_id' => $match[2],
        'text' => "سورس شما توسط مدیریت بررسی و تایید شد ✅
		
		👈 نوع سورس : ویژه
		👈 به شما $tarofesendsource2 سکه داده شد",
        'reply_markup' => $back
    ]);
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$match[2]' LIMIT 1"));
    $coin = $user['coin'] + $tarofesendsource2;
    $connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$match[2]' LIMIT 1");
}
if (preg_match('/^(reject\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => 'رد شد',
        'reply_to_message_id' => $messageid,
    ]);
    bot('sendmessage', [
        'chat_id' => $match[2],
        'text' => 'سورس شما توسط مدیریت بررسی و رد شد❌',
    ]);
}
if (preg_match('/^(acceptban\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "✅ کاربر {$match[2]} با موفقیت رفع مسدودیت شد",
    ]);
    $connect->query("DELETE FROM `block` WHERE `id` = '$match[2]'");
}
if (preg_match('/^(rejectban\^(.*))/', $data, $match)) {
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "🥸 عملیات رفع مسدودیت کاربر {$match[2]} با موفقیت لغو شد",
    ]);
}
if (preg_match('/^like_(.*)/', $data, $match)) {
    if (mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `like` WHERE `file` = '$match[1]' AND `id` = '$fromid' LIMIT 1")) <= 0) {
        bot('answercallbackquery', [
            'callback_query_id' => $callback_query_id,
            'text' => '❤️ لایک شما با موفقیت انجام شد و سکه به حساب شما اضافه شد',
            'show_alert' => true
        ]);
        $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$match[1]' LIMIT 1"));
        $like = $file['like'] + 1;

        $userdevabol = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
        $newcoindevabol = $userdevabol['coin'] + $likecoinn;

        $freepostid = $file['messageid'];

        $coinabol = $file['coindownload'];
        bot('editMessageReplyMarkup', [
            'chat_id' => "@$channel",
            'message_id' => $freepostid,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$match[1]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ($like)", 'callback_data' => "like_$match[1]"]],
                ]
            ])
        ]);
        $connect->query("UPDATE `file` SET `like` = '$like' WHERE `id` = '$match[1]' LIMIT 1");
        $connect->query("UPDATE `user` SET `coin` = '$newcoindevabol' WHERE `id` = '$fromid' LIMIT 1");
        $connect->query("INSERT INTO `like` (`id` , `file`) VALUES ('$fromid' , '$match[1]')");
    } else
        bot('answercallbackquery', [
            'callback_query_id' => $callback_query_id,
            'text' => '❗️ شما قبلا این سورس را لایک کرده اید',
            'show_alert' => true
        ]);
}
if (preg_match('/^viplike_(.*)/', $data, $match)) {
    if (mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `like` WHERE `file` = '$match[1]' AND `id` = '$fromid' LIMIT 1")) <= 0) {
        bot('answercallbackquery', [
            'callback_query_id' => $callback_query_id,
            'text' => '❤️ لایک شما با موفقیت انجام شد و سکه به حساب شما اضافه شد',
            'show_alert' => true
        ]);
        $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[1]' LIMIT 1"));
        $postid = $vipfile['messageid'];
        $like = $vipfile['like'] + 1;
        $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[1]'"));

        $userdevabol = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
        $newcoindevabol = $userdevabol['coin'] + $likecoinn;


        $gheymatsource = $vipfile['moneydownload'];
        $gheyakharsorce = number_format($gheymatsource);
        bot('editMessageReplyMarkup', [
            'chat_id' => "@$channel",
            'message_id' => $postid,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$match[1]"]],
                    [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                    [['text' => "❤️ ($like)", 'callback_data' => "viplike_$match[1]"]],
                ]
            ])
        ]);
        $connect->query("UPDATE `vipfile` SET `like` = '$like' WHERE `id` = '$match[1]' LIMIT 1");
        $connect->query("UPDATE `user` SET `coin` = '$newcoindevabol' WHERE `id` = '$fromid' LIMIT 1");
        $connect->query("INSERT INTO `like` (`id` , `file`) VALUES ('$fromid' , '$match[1]')");
    } else
        bot('answercallbackquery', [
            'callback_query_id' => $callback_query_id,
            'text' => '❗️ شما قبلا این سورس را لایک کرده اید',
            'show_alert' => true
        ]);
}
if (strpos($data, "answer|") !== false) {
    $getsendmessage = explode("|", $data);
    $idd = $getsendmessage[1];
    $midd = $getsendmessage[2];
    bot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "پاسخ خود را ارسال نمایید : 

⚠️فقط پیام متنی قابل ارسال میباشد.",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "لغو", 'callback_data' => "cancelsend"]],
            ]
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendmessg|$idd|$midd' WHERE id = '$fromid' LIMIT 1");
}
if (strpos($data, "block|") !== false) {
    $getuserblock = explode("|", $data);
    $iduserblocker = $getuserblock[1];
    bot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "📛 کاربر [$iduserblocker](tg://user?id=$iduserblocker)  با موفقیت از ربات محروم شد.

جهت آزاد کردن کاربر از پنل مدیریت استفاده کنید.",
        'parse_mode' => "MarkDown",
    ]);
    $connect->query("INSERT INTO `block` (`id`,`reason`,`date`,`time`) VALUES ('$iduserblocker','توهین به پشتیبانی','$date','$time')");
}
if ($data == "cancelsend") {
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    bot('deletemessage', [
        'chat_id' => $chatid,
        'message_id' => $messageid
    ]);
    bot('sendMessage', [
        'chat_id' => $chatid,
        'text' => "عملیات با موفقیت لغو شد",
    ]);
    exit();
}
if (strpos($data, "score|") !== false) {
    $match = explode("|", $data);
    $scores = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]' and `id` = '$fromid';"));
    if ($match[1] <= 4) {
        if ($scores['score'] == "0") {
            bot('sendMessage', [
                'chat_id' => $fromid,
                'text' => "⭐️ امتیاز $match[1] ستاره شما با موفقیت ثبت شد

همواره با شرکت در نظر سنجی های ربات و کانال علاوه بر حمایت از ما به بهبود خرید دیگران کمک کنید 🌹

📣 @$channel
👨‍💻 @$usernamesup",
            ]);
            $connect->query("UPDATE `vipdownload` SET `score` = '$match[1]' WHERE `file` = '$match[2]' and `id` = '$fromid';");
            $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[2]' LIMIT 1"));
            $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]'"));

            $allscore = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]' AND `score` >= 1;"));
            $sql = "SELECT `score` FROM `vipdownload` WHERE `file` = '$match[2]'";
            $result = mysqli_query($connect, $sql);
            $sum = 0;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $sum += $row["score"];
                }
            }
            $scoresource = $sum / $allscore;
            $scoresource = round($scoresource, 1);

            $gheymatsource = $vipfile['moneydownload'];
            $gheyakharsorce = number_format($gheymatsource);
            $postid = $vipfile['messageid'];
            bot('editMessageCaption', [
                'chat_id' => "@$channel",
                'message_id' => $postid,
                'caption' => "{$vipfile['caption']}

⭐️ $scoresource ($allscore)

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$match[2]"]],
                        [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                        [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "viplike_$match[2]"]],
                    ]
                ])
            ]);
        } else {
            bot('sendMessage', [
                'chat_id' => $fromid,
                'text' => "🥸 شما قبلا برای این محصول امتیاز {$scores['score']} ستاره ثبت کرده اید",
            ]);
            exit;
        }
    }
    if ($match[1] == 5) {
        if ($scores['score'] != "0") {
            bot('sendMessage', [
                'chat_id' => $fromid,
                'text' => "🥸 شما قبلا برای این محصول امتیاز {$scores['score']} ستاره ثبت کرده اید",
            ]);
            exit;
        } else {
            $randomcoin = rand(1, 10);
            @$s = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
            $newbalance = $s['coin'] + $randomcoin;
            $connect->query("UPDATE `user` SET `coin` = '$newbalance' WHERE id = '$fromid' LIMIT 1");
            bot('sendMessage', [
                'chat_id' => $fromid,
                'text' => "♥️ دوست عزیزم بابت امتیاز $match[1] ستاره ای که دادی ممنونم

به شما $randomcoin سکه هدیه داده شد 🎁

همواره با شرکت در نظر سنجی های ربات و کانال علاوه بر حمایت از ما به بهبود خرید دیگران کمک کنید 🌹

📣 @$channel
👨‍💻 @$usernamesup",
            ]);
            $connect->query("UPDATE `vipdownload` SET `score` = '$match[1]' WHERE `file` = '$match[2]' and `id` = '$fromid';");
            $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[2]' LIMIT 1"));

            $allscore = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]' AND `score` >= 1;"));
            $sql = "SELECT `score` FROM `vipdownload` WHERE `file` = '$match[2]'";
            $result = mysqli_query($connect, $sql);
            $sum = 0;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $sum += $row["score"];
                }
            }
            $scoresource = $sum / $allscore;
            $scoresource = round($scoresource, 1);

            $gheymatsource = $vipfile['moneydownload'];
            $gheyakharsorce = number_format($gheymatsource);
            $postid = $vipfile['messageid'];
            $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]'"));
            bot('editMessageCaption', [
                'chat_id' => "@$channel",
                'message_id' => $postid,
                'caption' => "{$vipfile['caption']}

⭐️ $scoresource ($allscore)

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$match[2]"]],
                        [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                        [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "viplike_$match[2]"]],
                    ]
                ])
            ]);
        }
    }
}
if ($data == 'jadidtarinamount') {
    $vipfile = mysqli_query($connect, "SELECT * FROM `vipfile` ORDER BY `id` DESC LIMIT 20");
    while ($row = mysqli_fetch_assoc($vipfile)) {
        $name = explode("\n", $row['caption']);
        $result = $result . "نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /vipfile_{$row['id']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "🗂 لیست 20 سورس اخیر اضافه شده به ربات و کانال
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید

📣 @$channel",
        'reply_to_message_id' => $messageid - 1,
    ]);
    bot('deletemessage', [
        'chat_id' => $chatid,
        'message_id' => $messageid,
    ]);
} elseif ($data == 'jadidtarinfree') {
    $file = mysqli_query($connect, "SELECT * FROM `file` ORDER BY `id` DESC LIMIT 20");
    while ($row = mysqli_fetch_assoc($file)) {
        $name = explode("\n", $row['caption']);
        $result = $result . "نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /file_{$row['id']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "🗂 لیست 20 سورس اخیر اضافه شده به ربات و کانال
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید",
        'reply_to_message_id' => $messageid - 1,
    ]);
    bot('deletemessage', [
        'chat_id' => $chatid,
        'message_id' => $messageid,
    ]);
}
if ($data == 'mahbobtarinamount') {
    $vipfile = mysqli_query($connect, "SELECT * FROM `vipfile` ORDER BY `like` DESC LIMIT 18");
    while ($row = mysqli_fetch_assoc($vipfile)) {
        $name = explode("\n", $row['caption']);
        $result = $result . "نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /vipfile_{$row['id']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "♥️ لیست سورس های محبوب در ربات از نطر تعداد لایک
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید

📣 @$channel",
        'reply_to_message_id' => $messageid - 1,
    ]);
    bot('deletemessage', [
        'chat_id' => $chatid,
        'message_id' => $messageid,
    ]);
}
if ($data == 'mahbobtarinfree') {
    $file = mysqli_query($connect, "SELECT * FROM `file` ORDER BY `like` DESC LIMIT 18");
    while ($row = mysqli_fetch_assoc($file)) {
        $name = explode("\n", $row['caption']);
        $result = $result . "نام سورس : $name[0]\n❤️ تعداد لایک : {$row['like']}\n📥 دریافت سورس : /file_{$row['id']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $fromid,
        'text' => "♥️ لیست سورس های محبوب در ربات از نطر تعداد لایک
	
$result
━ ━ ━ ━
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
🎁 با دعوت دوستان خود به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر $membercoinn سکه دریافت کنید",
        'reply_to_message_id' => $messageid - 1,
    ]);
    bot('deletemessage', [
        'chat_id' => $chatid,
        'message_id' => $messageid,
    ]);
}
//========================== O F F ============================//
if (file_exists('bot') and !in_array($from_id, $admin))
    return bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "⚠️ ربات جهت بروزرسانی خاموش است ! لطفا پیام مجدد ارسال نکنید.",
    ]);
//===========================// back and start //===========================//
if ($text == "/start") {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => $maintext,
        'reply_to_message_id' => $message_id,
        'reply_markup' => $home
    ]);
    if ($user['id'] != true)
        $connect->query("INSERT INTO `user` (`id` , `create_at`) VALUES ('$from_id' , '$timestamp')");
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    exit;
}

if ($text == '🔙 بازگشت') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "⬅️ به منوی اصلی بازگشتید
	
$maintext",
        'reply_to_message_id' => $message_id,
        'reply_markup' => $home
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    exit;
}
//===========================================//
if (preg_match('/^(\/start) file_(.*)/', $text, $match)) {
    if (check_join("$from_id") != 'true') {
        is_join("$from_id");
        if ($user['id'] != true)
            $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
    } else {
        $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$match[2]' LIMIT 1"));
        if (mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `download` WHERE `file` = '$match[2]' AND `id` = '$from_id' LIMIT 1")) > 0)
            bot('sendDocument', [
                'chat_id' => $from_id,
                'document' => $file['file'],
                'caption' => "{$file['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[2]"]],
                    ]
                ])
            ]);
        elseif ($file['download'] < $file['limit']) {
            bot('sendDocument', [
                'chat_id' => $from_id,
                'document' => $file['file'],
                'caption' => "{$file['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[2]"]],
                    ]
                ])
            ]);
            $download = $file['download'] + 1;
            $coinabol = $file['coindownload'];
            $freepostid = $file['messageid'];
            bot('editMessageReplyMarkup', [
                'chat_id' => "@$channel",
                'message_id' => $freepostid,
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$match[2]"]],
                        [['text' => "📥 تعداد دانلود رایگان : $download از {$file['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                        [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[2]"]],
                    ]
                ])
            ]);
            $connect->query("UPDATE `file` SET `download` = '$download' WHERE `id` = '$match[2]' LIMIT 1");
            $connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$from_id' , '$match[2]')");
        } elseif ($user['coin'] >= $file['coindownload']) {
            bot('sendDocument', [
                'chat_id' => $from_id,
                'document' => $file['file'],
                'caption' => "{$file['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[2]"]],
                    ]
                ])
            ]);
            $imdevabol = $file['coindownload'];
            $imdevabol1 = $user['coin'];
            $mincoin = $imdevabol1 - $imdevabol;
            $connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$from_id' , '$match[2]')");
            $connect->query("UPDATE `user` SET `coin` = '$mincoin'  WHERE `id` = '$from_id' LIMIT 1");
        } elseif ($subscription['id'] == true) {
            if ($subscription['expire'] >= "1") {
                bot('sendDocument', [
                    'chat_id' => $from_id,
                    'document' => $file['file'],
                    'caption' => "{$file['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => [
                            [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[2]"]],
                        ]
                    ])
                ]);
                $connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$from_id' , '$match[2]')");
            } else
                bot('sendmessage', [
                    'chat_id' => $from_id,
                    'text' => "❗️ ظرفیت دانلود رایگان این سورس به پایان رسیده است و نمیتوانید سورس را رایگان دریافت کنید

☑️ شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید
👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است سکه از شما کسر خواهد شد

👇🏻 از منوی پایین انتخاب کنید",
                    'reply_to_message_id' => $message_id,
                    'reply_markup' => $home
                ]);
        }
    }
}

//=========================== #-- Source Poli --# ===========================\\

if (preg_match('/^(\/start) vipfile_(.*)/', $text, $match)) {
    if (check_join("$from_id") != 'true') {
        is_join("$from_id");
        if ($user['id'] != true)
            $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
    } else {
        $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[2]' LIMIT 1"));
        if ($vipfile['sale'] != "true") {
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "🤔 متاسفانه فروش این محصول به دستور مدیریت موقف شده، برای بررسی آخرین اخبار به کانال ما مراجعه کنید",
                'reply_to_message_id' => $message_id,
                'reply_markup' => $home
            ]);
        } else {
            if (mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[2]' AND `id` = '$from_id' LIMIT 1")) > 0) {
                bot('sendDocument', [
                    'chat_id' => $from_id,
                    'document' => $vipfile['file'],
                    'caption' => "{$vipfile['caption']}
 
📣 @$channel
👨‍💻 @$usernamesup",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => [
                            [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "viplike_$match[2]"]],
                        ]
                    ])
                ]);
            } else {
                $gheymatsource = $vipfile['moneydownload'];
                $gheyakharsorce = number_format($gheymatsource);
                bot('sendphoto', [
                    'chat_id' => $from_id,
                    'photo' => $vipfile['photo'],
                    'caption' => "{$vipfile['caption']}
  
📣 @$channel
👨‍💻 @$usernamesup",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => [
                            [['text' => "💳 خرید سورس به مبلغ $gheyakharsorce تومان", 'url' => "$addres/pay/buyfile.php?file=$match[2]&id=$from_id"]],
                        ]
                    ])
                ]);
            }
        }
    }
}
if (preg_match('/^(\/start) (.*)/', $text, $match) and $user['id'] != true and $match[2] > 0) {
    if (check_join("$from_id") == 'true') {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "🌹 سلام $first_name عزیز به $botname خوش آمدید

$maintext",
            'reply_to_message_id' => $message_id,
            'reply_markup' => $home
        ]);
        $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
        $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$match[2]' LIMIT 1"));
        $member = $user['member'] + 1;
        $coin = $user['coin'] + $membercoinn;
        bot('sendmessage', [
            'chat_id' => $match[2],
            'text' => "🌟 تبریک ! کاربر [$from_id](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده	
⬆️ مفداری سکه به سکه حساب شما افزوده شده

💰 موجودی حساب : $coin سکه
👥 تعداد زیر مجموعه : $member نفر",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[2]' LIMIT 1");
        $connect->query("UPDATE `user` SET `master` = '$match[2]' WHERE `id` = '$from_id' LIMIT 1");
        $connect->query("INSERT INTO `member` (`id` , `master`) VALUES ('$from_id' , '$match[2]')");
    } else {
        $connect->query("INSERT INTO `user` (`id` , `step`) VALUES ('$from_id' , 'send $match[2]')");
        is_join("$from_id");
    }
}
//===========================// join //===========================
if (check_join("$from_id") != 'true') {
    if ($user['id'] != true)
        $connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");

    is_join("$from_id");
}
//========================== // key // ==============================
if ($text == '🔍 جستجو سورس') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👇🏻 جهت جست و جوی سورس مورد نظر خود لطفا نام محصول را ارسال کنید
	
👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است یک سکه از شما کسر خواهد شد
👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید",
        'reply_to_message_id' => $message_id,
        'reply_markup' => $back,
    ]);
    $connect->query("UPDATE `user` SET `step` = 'search' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '📊 جدیدترین ها') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👇 لطفا از منوی پایین لیست مورد نظر انتخاب کنید",
        'reply_to_message_id' => $message_id,
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "📊 جدیدترین های پولی", 'callback_data' => "jadidtarinamount"]],
                [['text' => "📊 جدیدترین های سکه ای", 'callback_data' => "jadidtarinfree"]],
            ]
        ])
    ]);
}
if ($text == 'محبوب ترین ها ❤️') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👇 لطفا از منوی پایین لیست مورد نظر انتخاب کنید",
        'reply_to_message_id' => $message_id,
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "❤️ محبوب ترین های پولی", 'callback_data' => "mahbobtarinamount"]],
                [['text' => "❤️ محبوب ترین های سکه ای", 'callback_data' => "mahbobtarinfree"]],
            ]
        ])
    ]);
}
if ($text == '🗂 ارسال سورس') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "♨️ به بخش ارسال سورس خوش آمدید.

🔅 شما در این بخش برای ما سورس ارسال میکنید و پس از تایید ما سورس ارسالی شما در کانال قرار میگیرد همچنین به ازای تایید هر سورس ارسالی توسط شما با توجه به تعرفه ای که در پایین ذکر شده سکه دریافت میکنید !

👈 تعرفه ارسال سورس معمولی : $tarofesendsource سکه ( سورسی که پاب هست )
👈 تعرفه ارسال سورس کمیاب : $tarofesendsource2 سکه ( سورسی که پاب نیست و با ارزشه )

📤 لطفا سورس خود به همراه کپشن ارسال کنید",
        'reply_to_message_id' => $message_id,
        'reply_markup' => $back
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sfile' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '💲 انتقال سکه') {
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا در خط اول ایدی فرد و در خط دوم میزان سکه انتقالی را وارد کنید

⚠️ این عمل غیر قابل بازگشت است
523853682
20

حداقل باید $cointranslimit سکه در حساب شما بماند

موجودی شما {$user['coin']} سکه است ",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "🔙 بازگشت"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendcointouser' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '👤 مدیریت حساب') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👤 به بخش حساب کاربری خوش امدید ، لطفا از منوی زیر درخواست خود را ارسال کنید :",
        'reply_to_message_id' => $message_id,
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => '🗣 دعوت دیگران']],
                [['text' => '💲 انتقال سکه'], ['text' => '🛍 فروشگاه'], ['text' => 'حساب من 👤']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard' => true,
        ])
    ]);
}
if ($text == '🛍 فروشگاه') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "🛍 به بخش فروشگاه خوش امدید ، لطفا از منوی زیر درخواست خود را ارسال کنید :",
        'reply_to_message_id' => $message_id,
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => '🛍 حساب ویژه'], ['text' => '💳 خرید سکه']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard' => true,
        ])
    ]);
}
if ($text == '🛍 حساب ویژه') {
    if ($user['activeuser'] == "1") {
        $amount1 = 30 * $onemah;
        $amount2 = 60 * $onemah;
        $amount3 = number_format($amount1);
        $amount4 = number_format($amount2);
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "🛍 جهت خرید اشتراک ویژه از دکمه های زیر استفاده کنید 👇",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "❤️ اشتراک یک ماهه $amount3 هزار تومان", 'url' => "$addres/pay/buyVIP.php?id=$from_id&time=30"]],
                    [['text' => "❤️ اشتراک دو ماهه $amount4 هزار تومان", 'url' => "$addres/pay/buyVIP.php?id=$from_id&time=60"]],
                ]
            ])
        ]);
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🔐 در راستای افزایش هر چه بیشتر امنیت در پرداخت ها، لطفا شماره همراه خود را ارسال نمایید.

☑️ برای تایید شماره از دکمه '🔐 ارسال شماره' استفاده کنید

❗️ شماره ارسالی نزد ما محفوظ است و هیچکس امکان دسترسی به آن را ندارد.
",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => "🔐 ارسال شماره", 'request_contact' => true]],
                    [['text' => '🔙 بازگشت']],
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'oknum' WHERE id = '$from_id' LIMIT 1");
    }
}
if ($text == 'حساب من 👤') {
    $file = mysqli_num_rows(mysqli_query($connect, "select `id` from `download` WHERE `id` = '$from_id'"));
    $like = mysqli_num_rows(mysqli_query($connect, "select `id` from `like` WHERE `id` = '$from_id'"));
    if ($subscription['id'] != true) {
        $nulllsss = "شما اشتراک فعال ندارید";
    } else {
        $nulllsss = "{$subscription['expire']} روز";
    }
    $pays = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay` WHERE `id` = '$text'"));
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👤 حساب کاربری شما در $botname :

🏷 شناسه : $from_id
🗣 نام : $first_name
♥️ مدت زمان اشتراک شما : $nulllsss

💰 موجودی حساب : {$user['coin']} سکه
👥 تعداد زیر مجموعه : {$user['member']} نفر

📁 تعداد فایل دریافت شده : $file
👍🏻 تعداد لایک انجام شده : $like
💎 تعداد خرید انجام شده : $pays

👈🏻 جهت ارسال سورس خود به کانال کافیست به پشتیبانی مراجعه کنید

👈🏻 تعداد سکه دانلود هر سورس متفاوت میباشد
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید",
        'reply_to_message_id' => $message_id,
    ]);
}
if ($text == 'افزایش سکه 💰') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👇🏻 یکی از بخش های زیر را جهت افزایش سکه انتخاب کنید	
💰 سکه حساب شما : {$user['coin']} سکه

👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است مقدار مشخصی از شما سکه کثر میشود
	
🗣 با دعوت دوستان خود به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر $membercoinn سکه دریافت کنید
ℹ️ جهت افزایش سکه به مبلغ دلخواه به صورت آنلاین میتوانید از خرید سکه استفاده کنید",
        'reply_to_message_id' => $message_id,
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => '🗣 دعوت دیگران'], ['text' => '💳 خرید سکه']],
                [['text' => '🔙 بازگشت']],
            ],
            'resize_keyboard' => true,
        ])
    ]);
}
if ($text == '💳 خرید سکه') {
    if ($user['activeuser'] == "1") {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "❗️ توجه کنید که حداقل $hadaghalbuy سکه و حداکثر $hadaksarbuy سکه میتوانید حساب خود را شارژ کنید

👈🏻 تعرفه هر 1 سکه $gheymatcoin تومان است
",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => '🔙 بازگشت']],
                ],
                'resize_keyboard' => true,
            ])
        ]);
        $connect->query("UPDATE `user` SET `step` = 'pay' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🔐 در راستای افزایش هر چه بیشتر امنیت در پرداخت ها، لطفا شماره همراه خود را ارسال نمایید.

☑️ برای تایید شماره از دکمه '🔐 ارسال شماره' استفاده کنید

❗️ شماره ارسالی نزد ما محفوظ است و هیچکس امکان دسترسی به آن را ندارد.
",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => "🔐 ارسال شماره", 'request_contact' => true]],
                    [['text' => '🔙 بازگشت']],
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'oknum' WHERE id = '$from_id' LIMIT 1");
    }
}
if ($text == '🗣 دعوت دیگران') {
    $id = bot('sendphoto', [
        'chat_id' => $from_id,
        'photo' => $baner,
        'caption' => "📢 کانال $channelname مرجع انواع سورس کد های مختلف

✅ سورس انواع ربات ها , قالب ها و اسکریپت های تست شده و حرفه ای
🌟 هر روز کلی سورس کد و اسکریپت منتظر شماست !

👇🏻 برای دریافت سورس ها کافیه از این ربات فوق العاده استفاده کنی

t.me/$usernamebot?start=$from_id",
    ])->result->message_id;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👆🏻 بنر بالا حاوی لینک دعوت شما به ربات است
	
🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر مقداری سکه دریافت کنید
☑️ پس با زیرمجموعه گیری به راحتی میتوانید سکه حساب خود را رایگان! افزایش دهید

❗️ توجه کنید که زیر مجموعه های شما برای دریافت سکه رایگان حتما باید در کانال ما عضو شوند

⚠️ توجه توجه ⚠️

در صورت ترک حتی یک کانال توسط زیرمجموعه شما مقداری سکه از شما کسر می شود

💰 موجودی حساب : {$user['coin']} سکه
👥 تعداد زیر مجموعه : {$user['member']} نفر",
        'reply_to_message_id' => $id,
    ]);
}
if (isset($update->message->contact->phone_number)) {
    if (preg_match('/^(98|\+98)(.*)/', $update->message->contact->phone_number)) {
        if ($update->message->contact->user_id == $from_id) {
            $phone = $update->message->contact->phone_number;
            $phone = str_replace("+98", "0", $phone);
            $rand = rand(10000, 99999);
            file_get_contents("http://ippanel.com:8080/?apikey=GVKDaXDjU76O9Ie8GRPYqLjJ6c4wXTtDYeTVCj5OQjg=&pid=0h5a5kauboxu8rb&fnum=3000505&tnum=$phone&p1=verification-code&v1=$rand");
            $connect->query("UPDATE `user` SET `codeveri` = '$rand' WHERE `id` = '$from_id' LIMIT 1");
            $connect->query("UPDATE user SET step = 'oknum2' WHERE id = '$from_id' LIMIT 1");
            $connect->query("UPDATE `user` SET `fakenumber` = '$phone' WHERE `id` = '$from_id' LIMIT 1");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
🔢 کد تایید تا چند ثانیه دیگر به شماره همراه شما پیامک میشود و تا 2 دقیقه اعتبار دارد.
👈 لطفا کد 5 رقمی دریافتی را وارد نمایید :

شماره تلفن شما : $phone
",
                'reply_markup' => $back,
            ]);
        } else {

            $connect->query("UPDATE user SET step = 'oknum' WHERE id = '$from_id' LIMIT 1");
            bot('SendMessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در انجام عملیات

گفتم شماره خودتو بفرست نه مخاطبینت رو 😬

☑️ برای تایید شماره از دکمه '🔐 ارسال شماره' استفاده کنید

❗️ شماره ارسالی نزد ما محفوظ است و هیچکس امکان دسترسی به آن را ندارد.
",
                'reply_to_message_id' => $message_id,
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [['text' => "🔐 ارسال شماره", 'request_contact' => true]],
                        [['text' => '🔙 بازگشت']],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
    } else {

        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        bot('SendMessage', [
            'chat_id' => $chat_id,
            'text' => "
❌ خطا در انجام عملیات

استفاده از خدمات ربات فقط با شماره ایران امکان پذیر میباشد 😬

🤷‍♂️ برای خرید کردن از ربات باید با شماره ایران از ربات استفاده کنید
",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => '🔙 بازگشت']],
                ],
                'resize_keyboard' => true
            ])
        ]);
    }
}
if ($user['step'] == 'oknum2') {
    if ($user['codeveri'] == $text) {
        $numberus = $user['fakenumber'];
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ تبریک، شماره شما تایید شد و میتوانید از تمامی امکانات ربات استفاده نمایید.",
            'reply_to_message_id' => $message_id,
            'reply_markup' => $home,
        ]);
        bot('sendMessage', [
            'chat_id' => $log_channel,
            'text' => "
💎 یک شماره جدید در سیستم ثبت شد.

+ ثبت نام کننده : $from_id
+ شماره تلفن شما : $numberus
+ زمان ثبت : `$date` در ساعت `$time`

`$botname`",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE `user` SET `phone` = '$numberus' WHERE `id` = '$from_id' LIMIT 1");
        $connect->query("UPDATE `user` SET `activeuser` = '1' WHERE `id` = '$from_id' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
❌ کد وارد شده اشتباه میباشد لطفا مجدد تلاش کنید
",
        ]);
    }
}
if ($text == 'پشتیبانی ربات 🆘') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👮🏻 همکاران ما در خدمت شما هستن

📨 جهت ارتباط به صورت مستقیم 👈🏻 @$usernamesup	
⚖️ کاربر گرامی، چنانچه شما از ربات $botname استفاده نمایید به منزله قبول قوانین است
 
• سعی بخش پشتیبانی بر این است که تمامی پیام های دریافتی در کمتر از ۱۲ ساعت پاسخ داده شوند، بنابراین تا زمان دریافت پاسخ صبور باشید

• لطفا پیام، سوال، پیشنهاد و یا انتقاد خود را در قالب یک پیام واحد به طور کامل ارسال کنید 👇🏻",
        'reply_to_message_id' => $message_id,
        'reply_markup' => $back
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sup' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '📚 راهنما ربات') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "📢 کانال $channelname مرجع انواع سورس کد های مختلف
📂 بانک انواع سورس کد های مختلف به صورت کاملا تست شده

✅ سورس انواع ربات ها , قالب ها و اسکریپت های تست شده و حرفه ای

☑️ با ما همراه باشید و مارو به دوستاتون معرفی کنید 
🌟 هر روز کلی سورس کد و اسکریپت منتظر شماست !

👈🏻 جهت مشاهده لیست کامل سورس ها کافیست به « @$channel » مراجعه کنید
👈🏻 جهت ارسال سورس خود به کانال کافیست به پشتیبانی مراجعه کنید

👈🏻 با دریافت هر سورس که ظرفیت دانلود رایگان آن به پایان رسیده است سکه از شما کسر خواهد شد
👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید

🎁 با دعوت دوستان خود به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر $membercoinn سکه دریافت کنید
ℹ️ جهت افزایش سکه به مبلغ دلخواه به صورت آنلاین میتوانید از خرید سکه استفاده کنید

📣 @$channel

❤️ توجه کنید که در صورت لایک یک سورس در پیوی ربات , تغییرات در کانال به صورت همگانی اعمال خواهد شد

♥️ راهنمای ربات به پایان رسید , در صورت داشتن هر نوع پیشنهاد یا انتقاد از دکمه پشتیبانی استفاده کنید . حضور شما تنها دلگرمی ماست، مارو از حضورتون بی نصیب نذارید .

🤖 ارتباط با ما و دریافت سورس ها : @$usernamebot
👈🏻 کانال $channelname : @$channel",
        'reply_to_message_id' => $message_id,
    ]);
}
if (preg_match('/^\/file_(.*)/', $text, $match)) {
    $query = mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$match[1]' LIMIT 1");
    if (mysqli_num_rows($query) > 0) {
        $file = mysqli_fetch_assoc($query);
        $coinabol = $file['coindownload'];
        bot('sendphoto', [
            'chat_id' => $from_id,
            'photo' => $file['photo'],
            'caption' => "{$file['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$match[1]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$match[1]"]],
                ]
            ])
        ]);
    } else
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => '❌ خطا ، محصول مورد نظر شما یافت نشد',
            'reply_to_message_id' => $message_id,
            'reply_markup' => $home,
        ]);
}
if (preg_match('/^\/vipfile_(.*)/', $text, $match)) {
    $query = mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[1]' LIMIT 1");
    if (mysqli_num_rows($query) > 0) {
        $vipfile = mysqli_fetch_assoc($query);
        $coinsource = $vipfile['moneydownload'];
        $gheymatsource = $coinsource;
        $gheyakharsorce = number_format($gheymatsource);

        $allscore = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[1]' AND `score` >= 1;"));
        $sql = "SELECT `score` FROM `vipdownload` WHERE `file` = '$match[1]'";
        $result = mysqli_query($connect, $sql);
        $sum = 0;
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $sum += $row["score"];
            }
        }
        $scoresource = $sum / $allscore;
        $scoresource = round($scoresource, 1);

        $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[1]'"));
        bot('sendphoto', [
            'chat_id' => $from_id,
            'photo' => $vipfile['photo'],
            'caption' => "{$vipfile['caption']}

⭐️ $scoresource ($allscore)

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$match[1]"]],
                    [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                    [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "like"]],
                ]
            ])
        ]);
    } else
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => '❌ خطا ، محصول مورد نظر شما یافت نشد',
            'reply_to_message_id' => $message_id,
            'reply_markup' => $home,
        ]);
}


//===========================// step //===========================

if ($user['step'] == 'sendcointouser' && $text != "/start" && $text != "🔙 بازگشت" && $tc == 'private') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    if (is_numeric($all[0]) && is_numeric($all[1])) {
        if ($all[1] >= '1' && $all[0] != $from_id) {


            $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
            $userdes = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));

            if ($user['coin'] >= $all[1] + $cointranslimit) {

                $coindes = $userdes['coin'] + $all[1];

                $coinuser = $user['coin'] - $all[1];

                $connect->query("UPDATE `user` SET `coin` = '$coindes' WHERE `id` = '$all[0]' LIMIT 1");

                $connect->query("UPDATE `user` SET `coin` = '$coinuser' WHERE `id` = '$from_id' LIMIT 1");

                bot('sendmessage', [
                    'chat_id' => $all[0],
                    'text' => "✅ میزان $all[1] سکه از کاربر $from_id به شما منتقل شد
			
موجودی قبلی:  {$userdes['coin']}
موجودی فعلی:  $coindes", 'reply_markup' => $home
                ]);

                bot('sendmessage', [
                    'chat_id' => $chat_id,
                    'text' => "✅ انتقال $all[1] سکه به کاربر $all[0] با موفقیت انجام شد
			
موجودی قبلی:  {$user['coin']}
موجودی فعلی:  $coinuser", 'reply_markup' => $home
                ]);

                bot('sendmessage', [
                    'chat_id' => $log_channel,
                    'text' => "انتقال سکه:

میزان انتقال:
$all[1]
آیدی کاربر انتقال دهنده:
$from_id
[profile](tg://user?id=$from_id)
[message](tg://openmessage?user_id=$from_id)
میزان سکه قبل انتقال:
{$user['coin']}
میزان سکه بعد انتقال:
$coinuser
آیدی کاربر مقصد:
$all[0]
[profile](tg://user?id=$all[0])
[message](tg://openmessage?user_id=$all[0])
میزان سکه قبل انتقال:
{$userdes['coin']}
میزان سکه بعد انتقال:
$coindes
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
                ]);

                $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
            } else {
                bot('sendmessage', [
                    'chat_id' => $chat_id,
                    'text' => "❌ موجودی شما کافی نیست", 'reply_markup' => $home
                ]);
                $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
            }
        } else {
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "❌   مقادیر وارد شده صحیح نیست", 'reply_markup' => $home
            ]);


            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
        }
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌   مقادیر وارد شده صحیح نیست", 'reply_markup' => $home
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    }
}
if (strpos($user['step'], "sendmessg|") !== false && $data != "cancelsend") {
    $getsendmessage = explode("|", $user['step']);
    $idd = $getsendmessage[1];
    $midd = $getsendmessage[2];
    bot('sendmessage', [
        "chat_id" => "$idd",
        'reply_to_message_id' => "$midd",
        "text" => "
👮🏻 تیم ما برای شما یک پاسخ ارسال کرده :

*$text*",
        'parse_mode' => 'MarkDown',
    ]);
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id - 1,
    ]);
    bot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
if ($user['step'] == 'sfile') {
    if (isset($message->document)) {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => '✅ سورس شما ثبت و پس از تایید توسط مدیران به شما 2 سکه ارسال میگردد',
            'reply_to_message_id' => $message_id,
            'reply_markup' => $back
        ]);
        $file = bot('ForwardMessage', [
            'chat_id' => $admin[0],
            'from_chat_id' => $from_id,
            'message_id' => $message_id
        ])->result->message_id;
        bot('sendmessage', [
            'chat_id' => $admin[0],
            'text' => "پیام بالا حاوی اطلاعات سورس است ان را تایید یا رد می کنید؟ <a href='tg://user?id={$from_id}'>{$from_id}</a>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $file,
            'reply_markup' => json_encode(['inline_keyboard' => [
                [['text' => 'تایید', 'callback_data' => "acceptsource^{$from_id}"], ['text' => 'رد', 'callback_data' => "reject^{$from_id}"]]
            ]])
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "⚠️ فقط فایل میتونی بفرستی!"
        ]);
    }
}
if ($user['step'] == 'search' && $tc == 'private') {
    if (isset($text) and mb_strlen($text) != 1 and isemoji($text) == false) {
        $file = mysqli_query($connect, "SELECT *, 'file' AS type FROM file WHERE caption like '%$text%' UNION SELECT *, 'vipfile' AS type FROM vipfile WHERE caption like '%$text%'");
        if (mysqli_num_rows($file) > 0) {
            while ($row = mysqli_fetch_assoc($file)) {
                if ($row['type'] == 'file') {
                    $is_vip = "false";
                } else {
                    if ($row['type'] == 'vipfile') {
                        $is_vip = "true";
                    }
                }

                if ($is_vip == "true") {
                    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '{$row['id']}' LIMIT 1"));
                    $gheyakharsorce = number_format($vipfile['moneydownload']);
                    $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '{$vipfile['id']}'"));
                    $allscore = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '{$vipfile['id']}' AND score >= 1;"));
                    $sql = "SELECT `score` FROM `vipdownload` WHERE `file` = '{$vipfile['id']}'";
                    $result = mysqli_query($connect, $sql);
                    $sum = 0;
                    if (mysqli_num_rows($result) > 0) {
                        while ($alpharow = mysqli_fetch_assoc($result)) {
                            $sum += $alpharow["score"];
                        }
                    }

                    $scoresource = $sum / $allscore;
                    $scoresource = round($scoresource, 1);

                    $caption = "{$vipfile['caption']}

⭐️ $scoresource ($allscore)

📣 @$channel
👨‍💻 @$usernamesup";
                    $keyboard = json_encode([
                        'inline_keyboard' => [
                            [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_{$vipfile['id']}"]],
                            [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                            [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "viplike_{$vipfile['id']}"]],
                        ]
                    ]);
                } else {
                    if ($is_vip == "false") {
                        $caption = "{$row['caption']}

📣 @$channel
👨‍💻 @$usernamesup";
                        $keyboard = json_encode([
                            'inline_keyboard' => [
                                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_{$row['id']}"]],
                                [['text' => "📥 تعداد دانلود رایگان : {$row['download']} از {$row['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : {$row['coindownload']} سکه", 'callback_data' => 'hazinesource']],
                                [['text' => "❤️ ({$row['like']})", 'callback_data' => "like_{$row['id']}"]],
                            ]
                        ]);
                    }
                }

                bot('sendphoto', [
                    'chat_id' => $from_id,
                    'photo' => $row['photo'],
                    'caption' => $caption,
                    'reply_markup' => $keyboard
                ]);
            }
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => '👆🏻 جست و جو به پایان رسید , نتایج مرتبط برای شما ارسال شد',
                'reply_markup' => $home
            ]);
            $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        } else {
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => '❗️ خطا ، محصول مرتبطی با عبارت مورد نظر شما یافت نشد',
                'reply_to_message_id' => $message_id,
                'reply_markup' => $back
            ]);
        }
    }
}
if ($user['step'] == 'pay' && $tc == 'private') {
    if ($text >= $hadaghalbuy and $text <= $hadaksarbuy) {
        $amount = $text * $gheymatcoin;
        $gheymatsource = $amount;
        $amount2 = number_format($gheymatsource);
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => '⏳ در حال ساخت فاکتور پرداخت ...',
            'reply_markup' => $home
        ]);
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "✅ فاکتور افزایش $text سکه با مبلغ $amount تومان با موفقیت برای شما ساخته شد
			
☑️ تمامی پرداخت ها به صورت اتوماتیک بوده و پس از تراکنش موفق مبلغ آن به سکه حساب شما در ربات افزوده خواهد شد .

👇🏻 پرای پرداخت کافیست از دکمه زیر استفاده کنید",
            'reply_to_message_id' => $message_id,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "💳 پرداخت $amount2 تومان", 'url' => "$addres/pay/zarinpal.php?amount=$amount&id=$from_id"]],
                ]
            ])
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    } else
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "❗️ خطا ، پیام شما دارای عدد ورودی نادرست است
			
👇🏻 لطفا تعداد سکه مورد نظر خود را به عدد وارد کنید
❗️ توجه کنید که حداکثر میتوانید $hadaksarbuy سکه حساب خود را شارژ کنید",
            'reply_to_message_id' => $message_id,
            'reply_markup' => $back
        ]);
}
if ($user['step'] == 'sup') {
    bot('ForwardMessage', [
        'chat_id' => $admin[0],
        'from_chat_id' => $from_id,
        'message_id' => $message_id
    ]);
    bot('sendMessage', [
        'chat_id' => $admin[0],
        'text' => "پیام بالا توسط کاربر زیر ارسال شده است :

نام کاربر : $first_name
آیدی عددی : $from_id
آیدی کاربر : @$username
شماره پیام : $message_id

<a href='tg://user?id=$from_id'>ᴄʟɪᴄᴋ ʜᴇʀᴇ</a>
<a href='tg://openmessage?user_id=$from_id'>ᴄʟɪᴄᴋ ʜᴇʀᴇ 2</a>",
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "💬 ارسال پاسخ به کاربر", 'callback_data' => "answer|$from_id|$message_id"]],
                [['text' => "📛 مسدود کردن کاربر", 'callback_data' => "block|$from_id"]],
            ]
        ])
    ]);
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => '✅ پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید',
        'reply_to_message_id' => $message_id,
        'reply_markup' => $home
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == 'برترین کاربر ها 🌟') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => '♻️ درحال بررسی دیتابیس برای جستجو برترین کاربر ها',
        'reply_to_message_id' => $message_id,
    ]);
    $connect->query("DELETE FROM `DevAbolfazl`");

    $djjsjdjd = mysqli_query($connect, "SELECT * FROM `user`");
    while ($row = mysqli_fetch_array($djjsjdjd)) {
        $djkskdkksks[] = $row['id'];
    }
    $coins = [];
    foreach ($djkskdkksks as $user) {
        $sjKkkskd = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
        $dnmdmsnkd = $sjKkkskd['member'];
        $coins[$user] = $dnmdmsnkd;
    }
    arsort($coins);
    foreach ($coins as $key => $user) {
        $query = "INSERT INTO `DevAbolfazl` (key_name, coin_value) VALUES ('$key', '$coins[$key]')";
        $result = mysqli_query($connect, $query);
    }

    $query = "SELECT * FROM `DevAbolfazl`";
    $result = mysqli_query($connect, $query);
    $jjajejf = array();
    $dhsjjsjxjd = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $jjajejf[] = $row['key_name'];
        $dhsjjsjxjd[] = $row['coin_value'];
    }
    bot('deletemessage', [
        'chat_id' => $from_id,
        'message_id' => $message_id + 1,
    ]);
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "🏆 برترین کاربر های زیرمجموعه گیری",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "🔢 با تعداد", 'callback_data' => 'none'], ['text' => "📣 ایدی عددی افراد", 'callback_data' => 'none'], ['text' => '🏆 نفرات برتر', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[0]", 'callback_data' => 'none'], ['text' => "$jjajejf[0]", 'callback_data' => 'none'], ['text' => '🥇 | نفر اول', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[1]", 'callback_data' => 'none'], ['text' => "$jjajejf[1]", 'callback_data' => 'none'], ['text' => '🥈 | نفر دوم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[2]", 'callback_data' => 'none'], ['text' => "$jjajejf[2]", 'callback_data' => 'none'], ['text' => '🥉 | نفر سوم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[3]", 'callback_data' => 'none'], ['text' => "$jjajejf[3]", 'callback_data' => 'none'], ['text' => '🏅 | نفر چهارم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[4]", 'callback_data' => 'none'], ['text' => "$jjajejf[4]", 'callback_data' => 'none'], ['text' => '🏅 | نفر پنجم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[5]", 'callback_data' => 'none'], ['text' => "$jjajejf[5]", 'callback_data' => 'none'], ['text' => '🏅 | نفر ششم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[6]", 'callback_data' => 'none'], ['text' => "$jjajejf[6]", 'callback_data' => 'none'], ['text' => '🏅 | نفر هفتم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[7]", 'callback_data' => 'none'], ['text' => "$jjajejf[7]", 'callback_data' => 'none'], ['text' => '🏅 | نفر هشتم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[8]", 'callback_data' => 'none'], ['text' => "$jjajejf[8]", 'callback_data' => 'none'], ['text' => '🏅 | نفر نهم', 'callback_data' => 'none']],
                [['text' => "$dhsjjsjxjd[9]", 'callback_data' => 'none'], ['text' => "$jjajejf[9]", 'callback_data' => 'none'], ['text' => '🏅 | نفر دهم', 'callback_data' => 'none']],
            ]
        ])
    ]);
}
//===========================// panel admin //===========================//
if (($text == '/panel' or $text == 'پنل' or $text == 'برگشت 🔙' or $text == "👤 پنل مدیریت 👤") and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👋 ادمین عزیز به پنل مدیریت ربات خوش امدید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "📊 آمار ربات"]],
                [['text' => 'بخش عمومی 🔴'], ['text' => "💬 بخش ارسال 💬"], ['text' => '📂 بخش سورس']],
                [['text' => "🔙 بازگشت"]],
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == 'بخش عمومی 🔴' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👋 ادمین عزیز به بخش عمومی خوش آمدید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "👤 اطلاعات کاربر"]],
                [['text' => '📂 اطلاعات سورس'], ['text' => '🔗 اطلاعات خرید']],
                [['text' => '😢 کمترین سکه'], ['text' => '😎 بیشترین سکه']],
                [['text' => '💰 ارسال سکه'], ['text' => '💎 اهدا اشتراک']],
                [['text' => '✅ لغو مسدودیت'], ['text' => '❌ مسدود کردن']],
                [['text' => '🟢 ربات روشن'], ['text' => '🔴 ربات خاموش']],
                [['text' => "برگشت 🔙"]],
            ],
            'resize_keyboard' => true
        ])
    ]);
}
if ($text == '💬 بخش ارسال 💬' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👋 ادمین عزیز به بخش ارسال خوش آمدید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "🎁 ارسال سورس به کاربر"], ['text' => "📜 ارسال لیست به کانال"]],
                [['text' => '↗️ فروارد به کاربران'], ['text' => '💬 ارسال به کاربران']],
                [['text' => "برگشت 🔙"]],
            ],
            'resize_keyboard' => true
        ])
    ]);
}
if ($text == '📂 بخش سورس' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👋 ادمین عزیز به بخش سورس خوش آمدید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => '⭐️ فروش سورس'], ['text' => '⚡️ ارسال سورس']],
                [['text' => '🗑 حذف سورس'], ['text' => '✏️ ویرایش فایل']],
                [['text' => '🔴 فروش غیرفعال'], ['text' => '🟢 فروش فعال']],
                [['text' => '💸 تغییر قیمت'], ['text' => '💰 تغییر سکه']],
                [['text' => "♥️ تغییر لایک پست"], ['text' => "🗳 تغییر دانلود "]],
                [['text' => "🌚 تغییر محدودیت دانلود"], ['text' => '💔 کمترین لایک']],
                [['text' => "برگشت 🔙"]],
            ],
            'resize_keyboard' => true
        ])
    ]);
}
if ($text == '📊 آمار ربات' and $tc == 'private' and in_array($from_id, $admin)) {
    $alluser = mysqli_num_rows(mysqli_query($connect, "select `id` from `user`"));
    $allfile = mysqli_num_rows(mysqli_query($connect, "select `id` from `file`"));
    $allfileamount = mysqli_num_rows(mysqli_query($connect, "select `id` from `vipfile`"));
    $alldownload = mysqli_num_rows(mysqli_query($connect, "select `id` from `download`"));
    $alllike = mysqli_num_rows(mysqli_query($connect, "select `id` from `like`"));
    $allbuy = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay`"));
    $allblock = mysqli_num_rows(mysqli_query($connect, "select `id` from `block`"));

    $ffnnbbd = mysqli_query($connect, "select * from user");
    $ressdd = mysqli_fetch_assoc($ffnnbbd);
    while ($ressdd = mysqli_fetch_assoc($ffnnbbd)) {
        $summmn += $ressdd['coin'];
    }
    $summmn = number_format($summmn);
    //============================================\\
    $ffnnbbd2 = mysqli_query($connect, "select * from pay");
    $ressdd2 = mysqli_fetch_assoc($ffnnbbd2);
    while ($ressdd2 = mysqli_fetch_assoc($ffnnbbd2)) {
        $summmn2 += $ressdd2['amount'];
    }
    $summmn2 = number_format($summmn2);

    //===========================================\\

    $ffnnbbd3 = mysqli_query($connect, "select * from user");
    $ressdd3 = mysqli_fetch_assoc($ffnnbbd3);
    while ($ressdd3 = mysqli_fetch_assoc($ffnnbbd3)) {
        $summmn3 += $ressdd3['member'];
    }
    $hourlyUsers = number_format(mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `user` WHERE `create_at` > $timestamp - 3600")) ?: 0);
    $dailyUsers = number_format(mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `user` WHERE `create_at` > $timestamp - 86400")) ?: 0);
    $weeklyUsers = number_format(mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `user` WHERE `create_at` > $timestamp - 604800")) ?: 0);
    $monthlyUsers = number_format(mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `user` WHERE `create_at` > $timestamp - 2592000")) ?: 0);

    //===========================================\\
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "👥 آمار ربات $botname
		
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		
👤 تعداد کاربران : $alluser
❌ تعداد بلاک : $allblock
📂 تعداد فایل رایگان : $allfile
💎 تعداد فایل ویژه : $allfileamount
🪙 تعداد دانلود : $alldownload
♥️ تعداد لایک : $alllike

🫂 تعداد کاربران دعوت شده : $summmn3

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

👥 آمار کاربران  جدید :

🟢 1 ساعت گذشته: $hourlyUsers
🕛 24 ساعت گذشته: $dailyUsers
📅 7 روز گذشته: $weeklyUsers
🗓 31 روز گذشته: $monthlyUsers

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

👈 سکه هدیه لایک کردن : $likecoinn
👈 قیمت هر یک سکه : $gheymatcoin
👈 پورسانت زیرمجموعه گیری : $membercoinn

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

👈 تعداد خرید ها : $allbuy عدد
👈 مجموع خرید ها : $summmn2 تومان
👈 مجموع موجودی کاربران : $summmn سکه

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

👈 ایدی عددی ادمین ها :
$admin[0] | $admin[1] | $admin[2]",
    ]);
}
if ($text == '😎 بیشترین سکه' and $tc == 'private' and in_array($from_id, $admin)) {
    $seke = mysqli_query($connect, "SELECT `id`,`coin` FROM `user` ORDER BY coin DESC limit 20");
    while ($row = mysqli_fetch_assoc($seke)) {
        $name = explode("\n", $row['id']);
        $result = $result . "آیدی کاربر : $name[0]\n❤️ تعداد سکه : {$row['coin']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "🗂 لیست 20 نفر با بیشترین سکه
	
$result",
        'reply_to_message_id' => $message_id,
    ]);
}
if ($text == '😢 کمترین سکه' and $tc == 'private' and in_array($from_id, $admin)) {
    $seke = mysqli_query($connect, "SELECT id, coin FROM user ORDER BY coin ASC LIMIT 20");
    while ($row = mysqli_fetch_assoc($seke)) {
        $name = explode("\n", $row['id']);
        $result = $result . "آیدی کاربر : $name[0]\n❤️ تعداد سکه : {$row['coin']}\n\n";
    }
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "🗂 لیست 20 نفر با کمترین سکه
	
$result",
        'reply_to_message_id' => $message_id,
    ]);
}
if ($text == '💎 اهدا اشتراک' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "برای اهدا اشتراک در خط اول آیدی عددی کاربر و در خط دوم مدت زمان اشتراک را وارد کنید
1323247682
30",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'ehdaeshterak' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '♥️ تغییر لایک پست' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📥 لطفا در خط اول ایدی سورس و در خط دوم تعداد لایکی که اضافه بشه ارسال کنید
1
20

❌ اگر میخواهید تعداد لایک هارو کم کنید از - منفی استفاده کنید

1
-20

اگر سورس رایگان هست بعد شناسه سورس f بزارید و اگر پولی است t مثلا

1 f ( سورس رایگان )
1 t ( سورس پولی )",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'liksze' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '🗳 تغییر دانلود' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📥 لطفا در خط اول ایدی سورس و در خط دوم تعداد دانلودی که اضافه بشه ارسال کنید
1
20",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'taqird' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '✏️ ویرایش فایل' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 شناسه سورس مورد نظر رو ارسال کنید

اگر سورس رایگان هست بعد شناسه سورس f بزارید و اگر پولی است t مثلا

12 f ( سورس رایگان )
12 t ( سورس پولی )",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'editfilepost' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '💬 ارسال به کاربران' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید]",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendtoall' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '↗️ فروارد به کاربران' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا پیام خود را فوروارد کنید [پیام فوروارد شده میتوانید از شخص یا کانال باشد]",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'fortoall' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '❌ مسدود کردن' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا شناسه کاربری فرد را ارسال کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'block' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '✅ لغو مسدودیت' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا شناسه کاربری فرد را ارسال کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'unblock' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '⚡️ ارسال سورس' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا عکس بنر و نام سورس را ارسال کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendbaner' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '🗑 حذف سورس' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا شناسه سورس را ارسال کنید

اگر سورس رایگان هست بعد شناسه سورس f بزارید و اگر پولی است t مثلا

12 f ( سورس رایگان )
12 t ( سورس پولی )",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'deletefile' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '🎁 ارسال سورس به کاربر' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا ایدی فرد را وارد کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendsourcetouser' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '💰 ارسال سکه' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا در خط اول ایدی فرد و در خط دوم میزان موجودی را وارد کنید
💎 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید

12
200",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendadmin' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '👤 اطلاعات کاربر' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا ایدی فرد را وارد کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'userinfoooooo' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '🔗 اطلاعات خرید' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا شماره پرداخت مربوطه را وارد کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'payinfo' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '📂 اطلاعات سورس' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا شناسه سورس مربوطه رو ارسال کنید ( فقط سورس های ویژه )",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'infovipsource' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '🌚 تغییر محدودیت دانلود' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا در خط اول ایدی سورس و در خط دوم تعداد محدودیت دانلود جدید را ارسال کنید
1
20",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'limsetbyme' WHERE `id` = '$from_id' LIMIT 1");
}
if ($text == '💰 تغییر سکه' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا در خط اول ایدی سورس و در خط دوم تعداد سکه جدید را ارسال کنید
6698
20",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE user SET step = 'skkesetbyme' WHERE id = '$from_id' LIMIT 1");
}
if ($text == '🟢 فروش فعال' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا شناسه سورس رو بفرستید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE user SET step = 'saletrue' WHERE id = '$from_id' LIMIT 1");
}
if ($text == '🔴 فروش غیرفعال' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا شناسه سورس رو بفرستید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE user SET step = 'salefalse' WHERE id = '$from_id' LIMIT 1");
}
if ($text == '💸 تغییر قیمت' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "💎 لطفا در خط اول ایدی سورس و در خط دوم قیمت جدید سورس را وارد کنید
6698
100000",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE user SET step = 'changesourceamount' WHERE id = '$from_id' LIMIT 1");
}
if ($text == '💔 کمترین لایک' and $tc == 'private' and in_array($from_id, $admin)) {

    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT min(`like`)  FROM `file`"));
    $rere = $file['min(`like`)'];
    $file1 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `like`=$rere"));

    $id = $file1['id'];
    $limit = $file1['limit'];
    $like = $file1['like'];
    $download = $file1['download'];

    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "کمترین لایک:
id = $id
limit= $limit
like = $like
link = https://t.me/$channel/$id
", 'disable_web_page_preview' => true,
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
}
if ($text == '📜 ارسال لیست به کانال' and $tc == 'private' and in_array($from_id, $admin)) {
    $file = mysqli_query($connect, "SELECT * FROM `file` ORDER BY `id` DESC LIMIT 50");
    while ($row = mysqli_fetch_assoc($file)) {
        $name = explode("\n", $row['caption']);
        $result = $result . "<a href='https://t.me/$usernamebot?start=file_{$row['id']}'>{$name[0]}</a>\n";
    }
    bot('sendmessage', [
        'chat_id' => "@$channel",
        'text' => "🗂 لیست آخرین سورس های اضافه شده به کانال و ربات
	
$result

👈🏻 شما میتوانید با افزایش سکه های حساب خود اقدام به دریافت سورس ها بدون محدودیت کنید

📣 @$channel",
        'disable_web_page_preview' => true,
        'parse_mode' => 'html',
    ]);
    bot('sendmessage', [
        'chat_id' => "$admin[0]",
        'text' => "✅ با موفقیت لیست 50 سورس آخر به کانال @$channel ارسال شد",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id,
    ]);
}
if ($text == '⭐️ فروش سورس' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا عکس بنر و نام سورس را ارسال کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendbanervip' WHERE `id` = '$from_id' LIMIT 1");
}

// ===========================// admin step //===========================
if ($user['step'] == 'sendsourcetouser') {
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
    if ($user['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "💎 حالا آیدی سورس را ارسال کنید
			
870 f ( سورس رایگان )
870 t ( سورس پولی )",
        ]);
        $connect->query("UPDATE `user` SET `step` = 'sendsourcetouser2 $text' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if (preg_match('/^sendsourcetouser2 (.*)/', $user['step'], $match)) {
    $textid = explode(' ', $text);
    $idsendsource = $match[1];
    if ($textid[1] == "f") {
        $connect->query("INSERT INTO `download` (`id` , `file`) VALUES ('$idsendsource' , '$textid[0]')");
        $filesend = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$textid[0]' LIMIT 1"));
        $postid = $filesend['messageid'];
        bot('sendDocument', [
            'chat_id' => $idsendsource,
            'document' => $filesend['file'],
            'caption' => "{$filesend['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "❤️ ({$filesend['like']})", 'callback_data' => "like_$textid[0]"]],
                ]
            ])
        ]);
        bot('sendmessage', [
            'chat_id' => $idsendsource,
            'text' => "👆 سورس بالا توسط مدیریت برای شما ارسال شده",
        ]);
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "💎 سورس با موفقیت به کاربر ارسال شد",
        ]);
        bot('editMessageReplyMarkup', [
            'chat_id' => "@$channel",
            'message_id' => $postid,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$textid[0]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$filesend['download']} از {$filesend['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : {$filesend['coindownload']} سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ({$filesend['like']})", 'callback_data' => "like_$textid[0]"]],
                ]
            ])
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        if ($textid[1] == "t") {
            $connect->query("INSERT INTO `vipdownload` (`id` , `file`) VALUES ('$idsendsource' , '$textid[0]')");
            $filesending = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$textid[0]' LIMIT 1"));
            $postid = $filesending['messageid'];
            bot('sendDocument', [
                'chat_id' => $idsendsource,
                'document' => $filesending['file'],
                'caption' => "{$filesending['caption']}

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "❤️ ({$filesending['like']})", 'callback_data' => "viplike_$textid[0]"]],
                    ]
                ])
            ]);
            bot('sendmessage', [
                'chat_id' => $idsendsource,
                'text' => "✅ #پرداخت_موفق 
	
⬆️ باتشکر از خرید شما ، سورس بالا با موفقیت به شما ارسال شد

⬇️ لطفا از منوی پایین به سورس خریداری شده رائ بدید ( درصورت رائ 5 ستاره به شما مقداری سکه هدیه داده میشه )",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "⭐️ 1", 'callback_data' => "score|1|$textid[0]"], ['text' => "⭐️ 2", 'callback_data' => "score|2|$textid[0]"], ['text' => "⭐️ 3", 'callback_data' => "score|3|$textid[0]"], ['text' => "⭐️ 4", 'callback_data' => "score|4|$textid[0]"], ['text' => "⭐️ 5", 'callback_data' => "score|5|$textid[0]"]],
                    ]
                ])
            ]);
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "💎 سورس با موفقیت به کاربر ارسال شد",
            ]);
            $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$textid[0]'"));
            $gheymatsource = $filesending['moneydownload'];
            $gheyakharsorce = number_format($gheymatsource);
            bot('editMessageReplyMarkup', [
                'chat_id' => "@$channel",
                'message_id' => $postid,
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$textid[0]"]],
                        [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                        [['text' => "❤️ ({$filesending['like']})", 'callback_data' => "viplike_$textid[0]"]],
                    ]
                ])
            ]);
            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
        }
    }
}
if ($user['step'] == 'sendbaner') {
    $photo = end($message->photo)->file_id;
    $name = $message->caption;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا زبان های توسعه دهنده سورس را بنویسید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setlanguage' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = '$photo^$name' LIMIT 1");
}
if ($user['step'] == 'setlanguage') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا توضیحات سورس را بنویسید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setcaption' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");
}
if ($user['step'] == 'setcaption') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا فایل سورس را ارسال کنید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setcoin' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");
}
if ($user['step'] == 'setcoin') {
    $file = $message->document->file_id;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا تعداد سکه برای دانلود را ارسال کنید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendfile' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$file') LIMIT 1");
}
if ($user['step'] == 'sendfile') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا محدودیت تعداد دانلود را ارسال کنید",
    ]);
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");
    $connect->query("UPDATE `user` SET `step` = 'sendlimit' WHERE `id` = '$from_id' LIMIT 1");
}
if ($user['step'] == 'sendlimit') {
    $idsource = mysqli_num_rows(mysqli_query($connect, "select `id` from `file`"));
    $idsource = $idsource + 1;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 سورس با موفقیت به کانال @$channel ارسال شد
			
➰ ایدی سورس : $idsource",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendfile` LIMIT 1"));
    $explode = explode('^', $file['data']);
    $coinabol = $explode[5];
    $getfile = bot('getfile', ['file_id' => $explode[0]])->result->file_path;
    $stamp = imagecreatefrompng('lib/logo.png');
    $im = imagecreatefromjpeg("https://api.telegram.org/file/bot" . API_KEY . "/$getfile");
    $marge_right = 10;
    $marge_bottom = 10;
    $sx = imagesx($stamp);
    $sy = imagesy($stamp);
    imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));
    imagepng($im, 'photo.png');
    imagedestroy($im);
    $id = bot('sendphoto', [
        'chat_id' => "@$channel",
        'photo' => new CURLFile('photo.png'),
        'caption' => "📂 {$explode[1]}
➰ ایدی سورس :
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}


🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید این سورس را رایگان دریافت کنید.

📣 @$channel
👨‍💻 @$usernamesup",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file"]],
                [['text' => "📥 تعداد دانلود رایگان : 0 از $text", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                [['text' => "❤️ (0)", 'callback_data' => "like"]],
            ]
        ])
    ])->result;
    bot('editMessageCaption', [
        'chat_id' => "@$channel",
        'message_id' => $id->message_id,
        'caption' => "📂 {$explode[1]}
➰ ایدی سورس : $idsource
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}


🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید این سورس را رایگان دریافت کنید.

📣 @$channel
👨‍💻 @$usernamesup",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$idsource"]],
                [['text' => "📥 تعداد دانلود رایگان : 0 از $text", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                [['text' => "❤️ (0)", 'callback_data' => "like_$idsource"]],
            ]
        ])
    ]);
    $caption = "📂 {$explode[1]}
➰ ایدی سورس : $idsource
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}


🎁 با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید این سورس را رایگان دریافت کنید.";
    $connect->query("INSERT INTO `file` (`id` , `messageid` , `file` , `photo` , `name` , `language` ,  `caption` ,`coindownload` , `limit`) VALUES ('$idsource' , '$id->message_id' , '$explode[4]' , '" . end($id->photo)->file_id . "' , '$explode[1]' , '$explode[2]' , '$caption' , '$explode[5]' , '$text')");
}
if ($user['step'] == 'sendbanervip') {
    $photo = end($message->photo)->file_id;
    $name = $message->caption;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا زبان های توسعه دهنده سورس را بنویسید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setlanguagevip' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = '$photo^$name' LIMIT 1");
}
if ($user['step'] == 'setlanguagevip') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا توضیحات سورس را بنویسید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setcaptionvip' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");
}
if ($user['step'] == 'setcaptionvip') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا فایل سورس را ارسال کنید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'setamount' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");
}
if ($user['step'] == 'setamount') {
    $file = $message->document->file_id;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 لطفا قیمت سورس را وارد کنید",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'sendfilevip' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$file') LIMIT 1");
}
if ($user['step'] == 'sendfilevip') {
    $idsourcevip = mysqli_num_rows(mysqli_query($connect, "select `id` from `vipfile`"));
    $idsourcevip = $idsourcevip + 1;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "💎 سورس با موفقیت به کانال @$channel ارسال شد

➰ ایدی سورس : $idsourcevip",
    ]);
    $connect->query("UPDATE `sendfile` SET `data` = CONCAT(`data`,'^$text') LIMIT 1");

    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    $vipsendfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendfile` LIMIT 1"));
    $explode = explode('^', $vipsendfile['data']);
    $amountabol = $explode[5];
    $gheyakharsorce = number_format($amountabol);
    $getfile = bot('getfile', ['file_id' => $explode[0]])->result->file_path;
    $stamp = imagecreatefrompng('lib/logo.png');
    $im = imagecreatefromjpeg("https://api.telegram.org/file/bot" . API_KEY . "/$getfile");
    $marge_right = 10;
    $marge_bottom = 10;
    $sx = imagesx($stamp);
    $sy = imagesy($stamp);
    imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));
    imagepng($im, 'photo.png');
    imagedestroy($im);
    $id = bot('sendphoto', [
        'chat_id' => "@$channel",
        'photo' => new CURLFile('photo.png'),
        'caption' => "📂 {$explode[1]}
➰ ایدی سورس :
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}

⭐️ 0 (0)

📣 @$channel
👨‍💻 @$usernamesup",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile"]],
                [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : 0 💎", 'callback_data' => 'kharidmovafagh']],
                [['text' => "❤️ (0)", 'callback_data' => "like"]],
            ]
        ])
    ])->result;
    bot('editMessageCaption', [
        'chat_id' => "@$channel",
        'message_id' => $id->message_id,
        'caption' => "📂 {$explode[1]}
➰ ایدی سورس : $idsourcevip ( ویژه )
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}

⭐️ 0 (0)

📣 @$channel
👨‍💻 @$usernamesup",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$idsourcevip"]],
                [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : 0 💎", 'callback_data' => 'kharidmovafagh']],
                [['text' => "❤️ (0)", 'callback_data' => "viplike_$idsourcevip"]],
            ]
        ])
    ]);
    $imcaption = "📂 {$explode[1]}
➰ ایدی سورس : $idsourcevip ( ویژه )
📝زبان توسعه دهنده : {$explode[2]}

📜 توضیحات بیشتر : {$explode[3]}";
    $connect->query("INSERT INTO `vipfile` (`id` , `messageid` , `file` , `photo` , `name` , `language` ,  `caption` ,`moneydownload`) VALUES ('$idsourcevip' , '$id->message_id' , '$explode[4]' , '" . end($id->photo)->file_id . "' , '$explode[1]' , '$explode[2]' , '$imcaption' , '$explode[5]')");
}
if ($user['step'] == 'deletefile' && $tc == 'private') {
    $command = explode(' ', $text);
    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$command[0]' LIMIT 1"));
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$command[0]' LIMIT 1"));
    if ($file['id'] == true or $vipfile['id'] == true) {
        if ($command[1] == "f") {
            $connect->query("DELETE FROM `file` WHERE `id` = '$command[0]'");
            $connect->query("DELETE FROM `download` WHERE `file` = '$command[0]'");
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "✅ با موفقیت حذف شد",
            ]);
        } elseif ($command[1] == "t") {
            $connect->query("DELETE FROM `vipfile` WHERE `id` = '$command[0]'");
            $connect->query("DELETE FROM `vipdownload` WHERE `file` = '$command[0]'");
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "✅ با موفقیت حذف شد",
            ]);
        }
    } else {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "❌ شناسه سورس در دیتابیس پیدا نشد",
        ]);
    }
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
if ($user['step'] == 'block' && $tc == 'private') {
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
    if ($user['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "📝 دلیل مسدودیت کاربر $text را وارد کنید",
            'reply_markup' => $reason
        ]);
        $connect->query("UPDATE `user` SET `step` = 'getblock $text' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if (preg_match('/^getblock (.*)/', $user['step'], $match)) {
    $connect->query("INSERT INTO `block` (`id`, `reason`, `date`, `time`) VALUES ('$match[1]','$text','$date','$time')");
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "✅ فرد با موفقیت مسدود شد",
        'reply_markup' => $back
    ]);
    bot('sendmessage', [
        'chat_id' => $match[1],
        'text' => "❗️ خطا در ارتباط با سرور ❗️

📝 متاسفانه شما توسط مدیریت به دلیل $text از ربات مسدود شده اید

📆 $date $time",
    ]);
}
if ($user['step'] == 'unblock' && $tc == 'private') {
    $block22 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$text' LIMIT 1"));
    if ($block22['id'] == true) {
        $banreason22 = $block22['reason'];
        $bandate22 = $block22['date'];
        $bantime22 = $block22['time'];
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "📝 اطلاعات مربوط به بن کاربر به صورت زیر میباشد:

🔎 Reason : $banreason22

📆 Time : $bandate22 $bantime22


🤔 آیا تایید میکنید که میخواهید کاربر $text رفع مسدودیت شود؟",
            'reply_markup' => json_encode(['inline_keyboard' => [
                [['text' => 'تایید', 'callback_data' => "acceptban^{$text}"]],
                [['text' => 'رد', 'callback_data' => "rejectban^{$text}"]]
            ]])
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'sendadmin') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));
    if ($user['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "انتقال موجودی با موفقیت انجام شد ✅",
        ]);
        $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));
        $coin = $user['coin'] + $all[1];
        bot('sendmessage', [
            'chat_id' => $all[0],
            'text' => "✅ $all[1] سکه  از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin سکه",
        ]);
        $connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'userinfoooooo') {
    $userfi = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
    if ($userfi['id'] == true) {
        $file = mysqli_num_rows(mysqli_query($connect, "select `id` from `download` WHERE `id` = '$text'"));
        $like = mysqli_num_rows(mysqli_query($connect, "select `id` from `like` WHERE `id` = '$text'"));
        $pays = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay` WHERE `id` = '$text'"));


        $getch = mysqli_query($connect, "SELECT * FROM `member` WHERE `id` = '$text'");
        while ($row = mysqli_fetch_assoc($getch)) {
            $Mastersss = $row['master'];
            $kobs .= "`$Mastersss`\n";
        }
        if ($kobs == null) {
            $kobs = "✉️ کاربر توسط کسی به ربات دعوت نشده است";
        } else {
            if ($kobs != null) {
                $kobs = "✉️ کاربر توسط $kobs عضو ربات شده است";
            }
        }

        $getch1 = mysqli_query($connect, "SELECT * FROM `member` WHERE `master` = '$text'");
        while ($row1 = mysqli_fetch_assoc($getch1)) {
            $Mastersss1 = $row1['id'];
            $kobs1 .= "`$Mastersss1`\n";
        }

        if ($kobs1 == null) {
            $kobs1 = "کاربر زیرمجموعه ای ندارد";
        } else {
            if ($kobs1 != null) {
                $kobs1 = "$kobs1";
            }
        }


        $resultaboli = $connect->query("SELECT SUM(amount) AS total FROM `pay` WHERE `id` = '$text'");


        while ($rowaboli = $resultaboli->fetch_assoc()) {
            $allbuyuser = number_format($rowaboli["total"]);
            $summmn = "$allbuyuser";
        }

        $pay = mysqli_query($connect, "SELECT * FROM `pay` WHERE `id` = '$text' ORDER BY `date` DESC LIMIT 10");
        while ($row = mysqli_fetch_assoc($pay)) {
            if ($row['coin'] != null) {
                $request = "💳 مقدار سکه خریداری شده : {$row['coin']}\n💸 مبلغ پرداختی : {$row['amount']}\n📅 تاریخ پرداخت : {$row['date']}\n⏰ ساعت پرداخت : {$row['time']}\n✅ آیپی : {$row['ip']}\n\n";
            } else {
                if ($row['coin'] == null) {
                    $request = "📁 شماره فایل : {$row['fileid']}\n💸 مبلغ پرداختی : {$row['amount']}\n📅 تاریخ پرداخت : {$row['date']}\n⏰ ساعت پرداخت : {$row['time']}\n✅ آیپی : {$row['ip']}\n\n";
                }
            }
            $result = $result . "$request";
        }

        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "👤 اطلاعات کاربر مربوطه:

🗝 شناسه : $text
💰 موجودی حساب : {$userfi['coin']} سکه
👥 تعداد زیر مجموعه : {$userfi['member']} نفر
📱 شماره کاربر : {$userfi['phone']}

📁 تعداد فایل دریافت شده : $file
👍🏻 تعداد لایک انجام شده : $like

💸 تعداد خرید انجام شده : $pays
💰 مجموع خرید انجام شده : $summmn تومان

$kobs

📊 لیست زیرمجموعه های کاربر:
$kobs1

💎 لیست 15 پرداخت آخر :

$result", 'parse_mode' => 'Markdown'
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'infovipsource') {
    $sourcess = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM vipfile WHERE id = '$text'"));
    if ($sourcess['id'] == true) {
        $amountesss = number_format("{$sourcess['moneydownload']}");
        $vaziat = ($sourcess['sale'] == "true") ? "فعال" : "غیرفعال";

        $result = mysqli_query($connect, "SELECT id FROM vipdownload WHERE file = '$text'");
        $listkharidaran = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $listkharidaran[] = $row['id'];
            }
            $list_text = implode("n", $listkharidaran);
        } else {
            $list_text = "خریداری یافت نشد";
        }

        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
    🔎 نام سورس : {$sourcess['name']}
    🗝 شناسه سورس : $text
	
    💰 قیمت سورس : $amountesss تومان
    📊 وضعیت فروش : $vaziat
	
    ♥️ تعداد لایک : {$sourcess['like']}
    📥 تعداد دانلود : {$sourcess['download']}
	
    📝 لیست خریداران : \n" . implode(", ", $listkharidaran),
            'parse_mode' => 'Markdown'
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ شناسه وارد شده در دیتابیس پیدا نشد !!!",
            'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'payinfo') {
    $pays = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `pay` WHERE `code` = '$text'"));
    if ($pays['code'] == true) {
        $amountesss = number_format($pays['amount']);

        if ($pays['fileid'] != NULL) {

            $dlinfo = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '{$pays['fileid']}' and `id` = '{$pays['id']}'"));
            $scoressss = $dlinfo['score'];
            $payinfoss = "📂 شناسه سورس خریداری شده : {$pays['fileid']} \n ⭐️ امتیاز کاربر به سورس : $scoressss";
        } else {
            if ($pays['coin'] != NULL) {

                $payinfoss = "💰 موجودی قبل پرداخت : {$pays['coinghabl']} سکه \n 💵 موجودی بعد پرداخت : {$pays['coinbad']} سکه";
            }
        }

        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🗝 شناسه پرداخت : $text
👤 آیدی عددی کاربر : {$pays['id']}

💰 مبلغ پرداخت شده : $amountesss تومان
$payinfoss

📱 شماره کاربر : {$pays['phone']}
💎 آیپی کاربر : {$pays['ip']}

📅 تاریخ پرداخت : {$pays['date']} {$pays['time']}", 'parse_mode' => 'Markdown'
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ شناسه وارد شده در دیتابیس پیدا نشد !!!",
            'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'sendtoall') {
    $photo = $message->photo[count($message->photo) - 1]->file_id;
    $caption = $update->message->caption;
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "✔️ پیام شما با موفقیت برای ارسال همگانی تنظیم شد",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendall` SET step = 'send' , `text` = '$text$caption' , `chat` = '$photo' LIMIT 1");
}
if ($user['step'] == 'limsetbyme') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    $files = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$all[0]' LIMIT 1"));
    if ($files['id'] == true) {
        $coinabol = $files['coindownload'];
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "تغییر محدودیت دانلود با موفقیت انجام شد ✅",
        ]);
        bot('editMessageReplyMarkup', [
            'chat_id' => "@$channel",
            'message_id' => $all[0],
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$all[0]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$files['download']} از {$all[1]}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ({$files['like']})", 'callback_data' => "like_$all[0]"]],
                ]
            ])
        ]);
        $connect->query("UPDATE `file` SET `limit` = '$all[1]' WHERE `id` = '$all[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'skkesetbyme') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    $files = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$all[0]' LIMIT 1"));
    if ($files['id'] == true) {
        $coinabol = $all[1];
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "تغییر سکه  با موفقیت انجام شد ✅",
        ]);
        bot('editMessageCaption', [
            'chat_id' => "@$channel",
            'message_id' => $id->message_id,
            'caption' => "{$files['caption']}

☑️ آخرین تغییر : $date $time",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$all[1]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$files['download']} از {$files['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ({$files['like']})", 'callback_data' => "like_$all[1]"]],
                ]
            ])
        ]);
        $connect->query("UPDATE `file` SET `coindownload` = '$all[1]' WHERE `id` = '$all[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'saletrue') {
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$text' LIMIT 1"));
    if ($vipfile['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "وضعیت فروش محصول با موفقیت فعال شد ✅",
        ]);
        $connect->query("UPDATE `vipfile` SET `sale` = 'true' WHERE `id` = '$text' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'salefalse') {
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$text' LIMIT 1"));
    if ($vipfile['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "وضعیت فروش محصول با موفقیت غیرفعال شد ✅",
        ]);
        $connect->query("UPDATE `vipfile` SET `sale` = 'false' WHERE `id` = '$text' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'changesourceamount') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    $vipsfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$all[0]' LIMIT 1"));
    if ($vipsfile['id'] == true) {
        $postid = $vipsfile['messageid'];
        $oldgheymat = $vipsfile['moneydownload'];
        $gheyakharsorce = number_format($all[1]);
        $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$all[0]'"));
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "قیمت سورس با موفقیت تغییر یافت ✅",
        ]);
        bot('editMessageReplyMarkup', [
            'chat_id' => "@$channel",
            'message_id' => $postid,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$all[0]"]],
                    [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                    [['text' => "❤️ ({$vipsfile['like']})", 'callback_data' => "viplike_$all[0]"]],
                ]
            ])
        ]);
        if ($oldgheymat > $all[1]) {

            $taghirgheimat = $oldgheymat - $all[1];
            $typetaghir = "کاهش";
        } else {
            if ($oldgheymat < $all[1]) {

                $taghirgheimat = $all[1] - $oldgheymat;
                $typetaghir = "افزایش";
            }
        }
        $typetaghirgheimat = number_format($taghirgheimat);
        $typeoldgheymat = number_format($oldgheymat);
        $typenewgheymat = number_format("{$all[1]}");
        bot('sendmessage', [
            'chat_id' => "@$channel",
            'text' => "#اطلاع_رسانی #تغییر_قیمت

💵 قیمت سورس با شناسه $all[0] به مقدار $typetaghirgheimat تومان $typetaghir پیدا کرد.

➖ قیمت قبل : $typeoldgheymat تومان
➕ قیمت جدید : $typenewgheymat تومان

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_to_message_id' => $postid
        ]);
        $connect->query("UPDATE `vipfile` SET `moneydownload` = '$all[1]' WHERE `id` = '$all[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'fortoall') {
    bot('sendmessage', [
        'chat_id' => $from_id,
        'text' => "✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",
    ]);
    $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    $connect->query("UPDATE `sendall` SET `step` = 'forward' , `text` = '$message_id' , `chat` = '$from_id' LIMIT 1");
}
if ($user['step'] == 'ehdaeshterak') {
    $text = str_replace('\\n', "--", $text);
    $alladdlike = explode("--", $text);
    $alladdlike2 = $alladdlike[0];
    $alladdlike3 = $alladdlike[1];
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$alladdlike2' LIMIT 1"));
    if ($user['id'] == true) {
        $expirenow = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `subscription` WHERE `id` = '$alladdlike2' LIMIT 1"));
        $newexpire = $expirenow['expire'] + $alladdlike3;;
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "با موفقیت به کاربر $alladdlike2 اشتراک $alladdlike3 روزه داده شد ✅ 
	  
مقدار اشتراک جدید : $newexpire",
        ]);
        if ($subscription['id'] == true) {
            $connect->query("UPDATE `subscription` SET `expire` = '$newexpire' WHERE `id` = '$alladdlike2' LIMIT 1");
            $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        } else {
            if ($subscription['id'] != true) {
                $connect->query("INSERT INTO `subscription` (`id` , `expire`) VALUES ('$alladdlike2' , '$alladdlike3')");
                $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
            }
        }
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات کاربر مورد نظر در دیتابیس وجود ندارد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'liksze') {
    $text = str_replace('\n', "--", $text);
    $alladdlike = explode("--", $text);
    $alladdlike2 = $alladdlike[0];
    $alladdlike3 = $alladdlike[1];
    $alladdlike4 = explode(' ', $alladdlike2);
    $alladdlike2 = $alladdlike4[0];

    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$alladdlike2' LIMIT 1"));
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$alladdlike2' LIMIT 1"));
    if ($file['id'] == true or $vipfile['id'] == true) {

        if ($alladdlike4[1] == "f") {
            $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM file WHERE id = '$alladdlike2' LIMIT 1"));
            $freepostid = $file['messageid'];
            $like = $file['like'] + $alladdlike3;
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "تغییر لایک  با موفقیت انجام شد ✅ 
    
مقدار لایک جدید : $like",
            ]);
            $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM file WHERE id = '$alladdlike2' LIMIT 1"));
            $coinabol = $file['coindownload'];

            bot('editMessageReplyMarkup', [
                'chat_id' => "@$channel",
                'message_id' => $freepostid,
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$alladdlike2"]],
                        [['text' => "📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                        [['text' => "❤️ ({$file['like']})", 'callback_data' => "like_$alladdlike2"]],
                    ]
                ])
            ]);
            $connect->query("UPDATE `file` SET `like` = '$like' WHERE `id` = '$alladdlike2' LIMIT 1");
            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
        } elseif ($alladdlike4[1] == "t") {
            $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM vipfile WHERE id = '$alladdlike2' LIMIT 1"));
            $postid = $vipfile['messageid'];
            $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$alladdlike2'"));
            $viplike = $vipfile['like'] + $alladdlike3;
            bot('sendmessage', [
                'chat_id' => $from_id,
                'text' => "تغییر لایک  با موفقیت انجام شد ✅ 
    
مقدار لایک جدید : $viplike",
            ]);
            $connect->query("UPDATE `vipfile` SET `like` = '$viplike' WHERE `id` = '$alladdlike2' LIMIT 1");
            $vipsfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$alladdlike2' LIMIT 1"));
            $amountabol = $vipsfile['moneydownload'];
            $gheyakharsorce = number_format($amountabol);

            bot('editMessageReplyMarkup', [
                'chat_id' => "@$channel",
                'message_id' => $postid,
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$alladdlike2"]],
                        [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                        [['text' => "❤️ ({$vipsfile['like']})", 'callback_data' => "viplike_$alladdlike2"]],
                    ]
                ])
            ]);
            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
        }
    } else {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "❌ شناسه سورس در دیتابیس پیدا نشد",
        ]);
    }
}
if ($user['step'] == 'taqird') {
    $text = str_replace('\\n', "--", $text);
    $all = explode("--", $text);
    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$all[0]' LIMIT 1"));
    if ($file['id'] == true) {
        $down = $file['download'] + $all[1];
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "تغییر دانلود با موفقیت انجام شد ✅",
        ]);
        $connect->query("UPDATE `file` SET `download` = '$down' WHERE `id` = '$all[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
if ($user['step'] == 'editfilepost') {
    $command = explode(' ', $text);
    $file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$command[0]' LIMIT 1"));
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$command[0]' LIMIT 1"));
    if ($file['id'] == true or $vipfile['id'] == true) {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => "✔️ حالا فایل مورد نظر را ارسال کنید

➖ در کپشن فایل میتونید تغییراتی که در آپدیت صورت گرفته را بنویسید",
        ]);
        $connect->query("UPDATE `user` SET `step` = 'postedit $command[0] $command[1]' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "❌ مشخصات سورس مورد نظر در دیتابیس پیدا نشد", 'parse_mode' => 'Markdown'
        ]);
    }
}
// ===================================================

if (preg_match('/^postedit (.*)/', $user['step'], $match)) {
    $match = explode(" ", $match[1]);
    $file = $message->document->file_id;
    $newversion = $message->caption;
    $sourceid = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$match[0]' LIMIT 1"));

    $files = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` WHERE `id` = '$match[0]' LIMIT 1"));
    $freepostid = $files['messageid'];
    $vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[0]' LIMIT 1"));
    $postid = $vipfile['messageid'];
    if ($match[1] == "f") {
        $coinabol = $files['coindownload'];

        bot('editMessageCaption', [
            'chat_id' => "@$channel",
            'message_id' => $freepostid,
            'caption' => "{$files['caption']}

☑️ آخرین تغییر : $date $time

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_$match[0]"]],
                    [['text' => "📥 تعداد دانلود رایگان : {$files['download']} از {$files['limit']}", 'callback_data' => 'download'], ['text' => "💰 هزینه سورس : $coinabol سکه", 'callback_data' => 'hazinesource']],
                    [['text' => "❤️ ({$files['like']})", 'callback_data' => "like_$match[0]"]],
                ]
            ])
        ]);

        bot('sendmessage', [
            'chat_id' => "@$channel",
            'text' => "#اطلاع_رسانی #بروزرسانی

♻️ سورس با شناسه $match[0] آپدیت شد و نسخه جدید قرار گرفت.

➖ لیست آخرین تغییرات:

$newversion

$date $time

📣 @$channel
👨‍💻 @$usernamesup",
            'reply_to_message_id' => $freepostid
        ]);

        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "تغییر فایل با موفقیت انجام شد ✅",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => "برگشت 🔙"]]
                ],
                'resize_keyboard' => true
            ])
        ]);

        $connect->query("UPDATE `file` SET `file` = '$file' WHERE `id` = '$match[0]' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        if ($match[1] == "t") {
            $vipsfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$match[0]' LIMIT 1"));
            $postid = $vipsfile['messageid'];
            $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[0]'"));
            $amountabol = $vipsfile['moneydownload'];
            $gheyakharsorce = number_format($amountabol);
            $allscore = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$match[0]' AND `score` >= 1;"));
            $sql = "SELECT `score` FROM `vipdownload` WHERE `file` = '$match[0]'";
            $result = mysqli_query($connect, $sql);
            $sum = 0;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $sum += $row["score"];
                }
            }
            $scoresource = $sum / $allscore;
            $scoresource = round($scoresource, 1);

            bot('editMessageCaption', [
                'chat_id' => "@$channel",
                'message_id' => $postid,
                'caption' => "{$vipsfile['caption']}

⭐️ $scoresource ($allscore)

☑️ آخرین تغییر : $date $time

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$match[0]"]],
                        [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $buynumber 💎", 'callback_data' => 'kharidmovafagh']],
                        [['text' => "❤️ ({$vipsfile['like']})", 'callback_data' => "viplike_$match[0]"]],
                    ]
                ])
            ]);
            bot('sendmessage', [
                'chat_id' => "@$channel",
                'text' => "#اطلاع_رسانی #بروزرسانی

♻️ سورس با شناسه $match[0] آپدیت شد و نسخه جدید قرار گرفت.

➖ لیست آخرین تغییرات:

$newversion

☑️ خریداران این محصول میتوانند از ربات نسخه جدید را دریافت کنند.

$date $time

📣 @$channel
👨‍💻 @$usernamesup",
                'reply_to_message_id' => $postid
            ]);

            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "تغییر فایل با موفقیت انجام شد ✅",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [['text' => "برگشت 🔙"]]
                    ],
                    'resize_keyboard' => true
                ])
            ]);

            $connect->query("UPDATE `vipfile` SET `file` = '$file' WHERE `id` = '$match[0]' LIMIT 1");
            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
        }
    }
}
if ($text == '🟢 ربات روشن' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "ادمین گرامی ربات با موفقیت روشن شد✅",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    unlink('bot');
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
if ($text == '🔴 ربات خاموش' and $tc == 'private' and in_array($from_id, $admin)) {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "ادمین گرامی ربات با موفقیت خاموش شد ✅",
        'reply_markup' => json_encode([
            'keyboard' => [
                [['text' => "برگشت 🔙"]]
            ],
            'resize_keyboard' => true
        ])
    ]);
    touch('bot');
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}

// ===========================// answer //===========================
if ($message->text && $message->reply_to_message && $from_id == $admin[0]) {
    $tc = $message->chat->type;
    if ($tc != 'group' and $tc != 'supergroup') {
        bot('sendmessage', [
            'chat_id' => $from_id,
            'text' => '☑️ پاسخ شما برای فرد ارسال شد'
        ]);
        bot('sendmessage', [
            'chat_id' => $message->reply_to_message->forward_from->id,
            'text' => "👮🏻 پاسخ پشتیبان برای شما : $text",
        ]);
    }
}
// ===========================// coin join //===========================	
if (preg_match('/^send (.*)/', $user['step'], $match)) {
    $usqid = $user['id'];
    if (check_join("$usqid") == 'true') {
        $data = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$match[1]' LIMIT 1"));
        $member = $data['member'] + 1;
        $coin = $data['coin'] + $membercoinn;
        bot('sendmessage', [
            'chat_id' => $match[1],
            'text' => "🌟 تبریک ! کاربر [{$user['id']}](tg://user?id={$user['id']}) با استفاده از لینک دعوت شما وارد ربات شده	
⬆️ یک سکه به سکه حساب شما افزوده شده

💰 موجودی حساب : $coin سکه
👥 تعداد زیر مجموعه : $member نفر",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[1]' LIMIT 1");
        $connect->query("UPDATE `user` SET `master` = '$match[1]' WHERE `id` = '$usqid' LIMIT 1");
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '{$user['id']}' LIMIT 1");
        $connect->query("INSERT INTO `member` (`id` , `master`) VALUES ('$usqid' , '$match[1]')");
    }
}
//=======================coin left======================================
if ($update->chat_member->new_chat_member->status == 'left') {

    $lfid = $update->chat_member->from->id;
    $lfchan = $update->chat_member->chat->username;
    $array = [];
    foreach ($Channels as $chy) {
        $tt = str_replace("@", "", $chy);
        $tt1 = strtolower($tt);
        $array[] = $tt1;
    }
    $lfchan1 = strtolower($lfchan);
    if (in_array($lfchan1, $array)) {

        $data = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$lfid' LIMIT 1"));

        $master = $data['master'];

        if ($master != null) {

            $data1 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$master' LIMIT 1"));
            $ncooin = $data1['coin'] - $leftfuckcoin;
            $connect->query("UPDATE `user` SET `coin` = '$ncooin' WHERE `id` = '$master' LIMIT 1");
            //===============
            $data2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$lfid' LIMIT 1"));
            $ncooin2 = $data2['coin'] - $leftfuckcoin;
            $connect->query("UPDATE `user` SET `coin` = '$ncooin2' WHERE `id` = '$lfid' LIMIT 1");
            //===============
            $connect->query("UPDATE `user` SET `master` = null WHERE `id` = '$lfid' LIMIT 1");

            bot('sendmessage', [
                'chat_id' => $lfid,
                'text' => "کاربر گرامی

شما یکی از کانال های جوین اجباری را ترک کردید.

از شخص ($master) و همچنین شما تعداد $leftfuckcoin سکه کسر شد"

            ]);
            bot('sendmessage', [
                'chat_id' => $master,
                'text' => "کاربر گرامی

اکانت زیر مجموعه شما ($lfid) یکی از کانال های جوین اجباری را ترک کرد
$leftfuckcoin سکه از شما کثر شد"

            ]);
        }
    }
}

//========// End //========//
$connect->close();
