<?php
ini_set("expose_php", "Off");
ini_set("Allow_url_fopen", "Off");
ini_set("disable_functions", "exec,passthru,shell_exec,system,proc_open,popen,curl_exec,curl_multi_exec,parse_ini_file,show_source,eval,file,file_get_contents,file_put_contents,fclose,fopen,fwrite,mkdir,rmdir,unlink,glob,echo,die,exit,print,scandir");
//========================== // token // ==============================
define('API_KEY', "TOKEN"); //token
//========================== // config // ==============================
$admin           = ["ID", "ID", "ID"]; // ها را ماننده این الگورتیم بگذارید ادمین پشتیبانی اولین آیدی عددی است
$Channels        = ["ID"]; //آیدی کانال های جوین اجباری(تعداد نامحدود است)

$usernamebot     = "ID"; // یوزرنیم ربات بدون @
$channel         = "ID"; // ایدی کانال بدون @ برای ارسال بنر پست

$channelname     = "NAME"; // نام کانال برای نمایش
$botname         = "NAME"; // نام ربات برای نمایش

$addres          = "DOMAIN + FILE";
$web             = "DOMAIN + FILE/pay"; // آدرس محل قرار گیری سورس درگاه پرداخت)(در صورتی که محل درگاه رو عوض کنید اضافه نمیکنه سکه)

$log_channel     = "-100000000"; //چنل گزارشات

$zarinpal_key    = "Merch"; // مرچند زرین پال
$idpay_key       = "Merch"; //کد آیدی پی
$backlink_idpay  = "DOMAIN + FILE/pay/idpayback.php"; //آدرس فایل برگشت آیدی پی

$apisms          = "Null";
$template        = "Null";

$usernamesup     = "ID"; // ایدی فرد پشتیبان مستقیم ربات
$baner           = "LINK"; // بنر زیر مجموعه گیری

$likecoinn       = "0.3"; //like coin
$membercoinn     = "1"; // member coin
$cointranslimit  = "10"; //transfer coin limit
$gheymatcoin     = "2000"; // قیمت هر سکه
$hadaghalbuy     = "20"; // حداقل خرید
$hadaksarbuy     = "500"; // حداکثر خرید

$tarofesendsource   = "2"; // با ارسال سورس پابلیک چند سکه بگیره
$tarofesendsource2  = "10"; // با ارسال سورس کمیاب چند سکه بگیره
$leftfuckcoin       = "1"; // اگه زیرمجموعه فرد لفت داد از خود و زیرمجموعه چه مقدار سکه کثر بشه

$onemah             = "4000"; // قیمت هر یک روز اشتراک ویژه

//========================== // database // ==============================
$userdb = "DB USERNAME"; // database username MySql
$passdb = "DB PASS"; // database password MySql
$dbname = "DB NAME"; // database name MySql

$connect = new mysqli('localhost', $userdb, $passdb, $dbname);
$connect->query("SET NAMES 'utf8'");
$connect->set_charset('utf8mb4');