<?php
// کرون جاب هر دقیقه یک بار فعال شود
error_reporting(0);
include '../config.php';
include 'jdf.php';
$token = API_KEY; // توکن ربات
$time = jdate('H:i:s');
$date = jdate('j F Y');
define('API_KEY', $token);
//========================================================
function bot($method, $datas = [])
{
	$url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
	$res = curl_exec($ch);
	if (curl_error($ch)) {
		var_dump(curl_error($ch));
	} else {
		return json_decode($res);
	}
}
//========================================================
function sendmessage($chat_id, $text)
{
	bot('sendMessage', [
		'chat_id' => $chat_id,
		'text' => $text,
		'parse_mode' => "MarkDown",
	]);
}
//=======================================================
$send = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `sendall` LIMIT 1"));
$daily = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `daily` LIMIT 1"));
//======================// send //=======================
if ($send['step'] == 'send') {
	$alluser = mysqli_num_rows(mysqli_query($connect, "select id from `user`"));
	$users = mysqli_query($connect, "SELECT id FROM `user` LIMIT 100 OFFSET {$send['user']}");
	if ($send['chat'] == false) {
		while ($row = mysqli_fetch_assoc($users))
			bot('sendmessage', [
				'chat_id' => $row['id'],
				'text' => $send['text'],
			]);
	} else {
		while ($row = mysqli_fetch_assoc($users))
			bot('sendphoto', [
				'chat_id' => $row['id'],
				'photo' => $send['chat'],
				'caption' => $send['text'],
			]);
	}
	$connect->query("UPDATE `sendall` SET `user` = `user` + 100 LIMIT 1");
	if ($send['user'] + 100 >= $alluser) {
		bot('sendmessage', [
			'chat_id' => $admin[0],
			'text' => "📍 پیام برای همه کابران ارسال شد",
		]);
		$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");
	}
}
//======================// forward //=======================
elseif ($send['step'] == 'forward') {
	$alluser = mysqli_num_rows(mysqli_query($connect, "select id from `user`"));
	$users = mysqli_query($connect, "SELECT id FROM `user` LIMIT 100 OFFSET {$send['user']}");
	while ($row = mysqli_fetch_assoc($users))
		bot('ForwardMessage', [
			'chat_id' => $row['id'],
			'from_chat_id' => $send['chat'],
			'message_id' => $send['text'],
		]);
	$connect->query("UPDATE `sendall` SET `user` = `user` + 100 LIMIT 1");
	if ($send['user'] + 100 >= $alluser) {
		bot('sendmessage', [
			'chat_id' => $admin[0],
			'text' => "📍 پیام برای همه کابران فوروارد شد",
		]);
		$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");
	}
}
//======================// daily user //=======================
elseif ($daily['time'] < date("Y-m-d H:i:s")) {
	$users = mysqli_num_rows(mysqli_query($connect, 'select `id` from `user`'));
	$userlimit = mysqli_query($connect, "SELECT id FROM `user` LIMIT 100 OFFSET {$daily['user']}");
	while ($row = mysqli_fetch_assoc($userlimit)) {
		$file = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `file` ORDER BY rand() LIMIT 1"));
		$coinmeys = $file['coindownload'];
		bot('sendphoto', [
			'chat_id' => $row['id'],
			'photo' => $file['photo'],
			'caption' => $file['caption'],
			'reply_markup' => json_encode([
				'inline_keyboard' => [
					[['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=file_{$file['id']}"]],
					[['text' => "📥 تعداد دانلود رایگان : {$file['download']} از {$file['limit']}", 'callback_data' => 'download']],
					[['text' => "❤️ ({$file['like']})", 'callback_data' => "like_{$file['id']}"], ['text' => "📢 $channelname", 'url' => "https://t.me/$channel"]],
					[['text' => "💰 هزینه سورس : $coinmeys سکه", 'callback_data' => 'hazinesource']],
				]
			])
		]);
	}
	$connect->query("UPDATE `daily` SET `user` = `user` + 100 LIMIT 1");
	if ($daily['user'] + 100 >= $users) {
		$time = date("Y-m-d H:i:s", strtotime("+3 day"));
		$connect->query("UPDATE `daily` SET `time` = '$time' , `user` = '0' LIMIT 1");
	}
}