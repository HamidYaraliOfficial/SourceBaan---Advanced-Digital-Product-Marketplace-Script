<?php
// کرون جاب روزانه
ini_set('error_logs', 'off');
error_reporting(0);
include '../config.php';

@$querycheckssa = mysqli_query($connect, "SELECT * FROM `subscription` WHERE `expire` >= '1';");
while ($users2 = mysqli_fetch_assoc($querycheckssa)) {
    $newexpire = $users2['expire'] - 1;
    $alluser = $users2['id'];
    $connect->query("UPDATE `subscription` SET `expire` = '$newexpire' WHERE `id` = '$alluser';");
}

echo "Down";