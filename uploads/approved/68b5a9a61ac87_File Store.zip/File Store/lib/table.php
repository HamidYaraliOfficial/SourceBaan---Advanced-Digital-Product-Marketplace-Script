<?php
// یک بار صفحه اجرا شود
include '../config.php';
//========================== // table creator // ==============================
$connect->multi_query("CREATE TABLE `user` (
    `id` bigint(32) PRIMARY KEY,
	`step` varchar(150) DEFAULT NULL,
	`member` int DEFAULT '0',
	`coin` float DEFAULT '0',
	`master` bigint(32) DEFAULT NULL,
	`activeuser` BIGINT(32) DEFAULT NULL,
	`codeveri` BIGINT(32) DEFAULT NULL,
	`fakenumber` BIGINT(32) DEFAULT NULL,
    `phone` BIGINT(32) DEFAULT NULL,
	`create_at` BIGINT DEFAULT NULL
    ) default charset = utf8mb4;
	CREATE TABLE `file` (
    `id` bigint(32) PRIMARY KEY,
	`messageid` bigint(32) PRIMARY KEY,
	`file` varchar(255) NOT NULL,
	`photo` varchar(255) NOT NULL,
	`name` text NOT NULL,
	`language` text NOT NULL,
	`caption` text NOT NULL,
	`like` int DEFAULT '0',
	`limit` int NOT NULL,
	`download` int DEFAULT '0',
	`coindownload` int DEFAULT '0'
    ) default charset = utf8mb4;
	CREATE TABLE `vipfile` (
    `id` bigint(32) PRIMARY KEY,
	`messageid` bigint(32) PRIMARY KEY,
	`file` varchar(255) NOT NULL,
	`photo` varchar(255) NOT NULL,
	`name` text NOT NULL,
	`language` text NOT NULL,
	`caption` text NOT NULL,
	`like` int DEFAULT '0',
	`download` int DEFAULT '0',
	`moneydownload` int DEFAULT '0',
	`sale` text EFAULT 'true'
    ) default charset = utf8mb4;
    CREATE TABLE `download` (
    `id` bigint(32) NOT NULL,
	`file` int NOT NULL
	) default charset = utf8mb4;
	CREATE TABLE `vipdownload` (
    `id` bigint(32) NOT NULL,
	`score` float DEFAULT '0',
	`file` int NOT NULL
	) default charset = utf8mb4;
	CREATE TABLE `like` (
    `id` bigint(32) NOT NULL,
	`file` int NOT NULL
    ) default charset = utf8mb4; 
	CREATE TABLE `member` (
    `id` bigint(32) NOT NULL,
    `master` bigint(32) NOT NULL
    ) default charset = utf8mb4; 
    CREATE TABLE `sendfile` (
	`data` text DEFAULT NULL
    ) default charset = utf8mb4; 
	CREATE TABLE `sendfilevip` (
	`data` text DEFAULT NULL
    ) default charset = utf8mb4; 
	CREATE TABLE `block` (
    `id` bigint(32) NOT NULL,
	`reason` text DEFAULT NULL,
	`date` text DEFAULT NULL,
	`time` text DEFAULT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `daily` (
    `time` varchar(50) DEFAULT '',
    `user` int DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `sendall` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`user` int DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `spam` (
    `id` bigint(32) PRIMARY KEY ,
    `block` VARCHAR(10) CHARACTER SET utf8mb4,
    `spam` INT(50) ,
    `timee` INT(50)
    ) default charset = utf8mb4;
    CREATE TABLE `pay` (
	`code` bigint(32) PRIMARY KEY,
	`id` bigint(32) NOT NULL,
	`coin` float DEFAULT NULL,
	`coinghabl` float DEFAULT NULL,
	`coinbad` float DEFAULT NULL,
	`amount` varchar(150) DEFAULT NULL,
    `fileid` varchar(150) DEFAULT NULL,
	`Authority` varchar(150) DEFAULT NULL,
	`time` varchar(150) DEFAULT NULL,
	`date` varchar(150) DEFAULT NULL,
	`phone` varchar(150) DEFAULT NULL,
	`ip` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4;    
    CREATE TABLE `subscription` (
	`id` bigint(32) PRIMARY KEY ,
	`expire` bigint(32) DEFAULT NULL
    ) default charset = utf8mb4;
	CREATE TABLE `DevAbolfazl` (
	`key_name` text DEFAULT NULL,
	`coin_value` text DEFAULT NULL
    ) default charset = utf8mb4;
    INSERT INTO `sendall` () VALUES ();
    INSERT INTO `daily` () VALUES ();
	INSERT INTO `sendfile` () VALUES ();");
//========================== // Check connection // ==============================
if ($connect->connect_error) {
	die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
echo "دیتابیس متصل و نصب شد .";