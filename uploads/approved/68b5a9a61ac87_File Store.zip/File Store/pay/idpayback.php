<?php
header('Content-type: application/json;');
include '../config.php';
include('../lib/jdf.php');
error_reporting(0);
$token = API_KEY; // توکن ربات
define('API_KEY', $token);
$status = $_POST['status'];
$track_id = $_POST['track_id'];
$id = $_POST['id'];
$order_id = $_POST['order_id'];
$amount = $_POST['amount'];
$card_no = $_POST['card_no'];
$hashed_card = $_POST['hashed_card_no'];
$date = $_POST['date'];
$user2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$order_id' LIMIT 1"));
$allbuy = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay`"));
$codebuy = $allbuy + 1;
//========================================================
function bot($method, $datas = [])
{
  $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
  $res = curl_exec($ch);
  if (curl_error($ch)) {
    var_dump(curl_error($ch));
  } else {
    return json_decode($res);
  }
}
//========================================================
function sendmessage($chat_id, $text)
{
  bot('sendMessage', [
    'chat_id' => $chat_id,
    'text' => $text,
    'parse_mode' => "MarkDown",
  ]);
}

if (strpos($status, '#') !== false or strpos($status, "'") !== false or strpos($status, '"') !== false) {
  exit;
}
if (strpos($track_id, '#') !== false or strpos($track_id, "'") !== false or strpos($track_id, '"') !== false) {
  exit;
}

if (strpos($id, '#') !== false or strpos($id, "'") !== false or strpos($id, '"') !== false) {
  exit;
}
if (strpos($order_id, '#') !== false or strpos($order_id, "'") !== false or strpos($order_id, '"') !== false) {
  exit;
}
if (strpos($amount, '#') !== false or strpos($amount, "'") !== false or strpos($amount, '"') !== false) {
  exit;
}

if ($user2['activeuser'] != "1") {
  echo "لطفا اول حساب خود را تایید کنید";
  exit;
}

if (!isset($status) or !isset($track_id) or !isset($id) or !isset($order_id) or !isset($amount) or !isset($card_no) or !isset($hashed_card) or !isset($date)) {

  echo "تراکنش شما مورد تایید نیست";

  bot('sendmessage', [
    'chat_id' => $log_channel,
    'text' => "
تراکنش برگشتی ناموفق:

• آیدی کاربر »
 [$order_id](tg://openmessage?user_id=$order_id)
•مبلغ تراکنش(ریال) »
 $amount
•شماره کارت »
 $card_no
•کد پیگیری »
 $track_id
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
  ]);
} else {

  bot('sendmessage', [
    'chat_id' => $log_channel,
    'text' => "
تراکنش برگشتی موفق:
• آیدی کاربر »
 [$order_id](tg://openmessage?user_id=$order_id)
•مبلغ تراکنش(ریال) »
 $amount
• شماره کارت »
 $card_no
• کد پیگیری »
 $track_id
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
  ]);


  if ($status == '10') {

    $params = array(
      'id' => "$id",
      'order_id' => "$order_id",
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment/verify');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      "X-API-KEY: $idpay_key",
    ));

    $result = curl_exec($ch);
    curl_close($ch);

    $rep = json_decode($result, true);

    $status1 = $rep['status'];
    $track_idpay1 = $rep['track_id'];
    $id1 = $rep['id'];
    $order_id1 = $rep['order_id'];
    $amount1 = $rep['amount'];
    $date1 = $rep['date'];
    $track_id1 = $rep['payment']['track_id'];
    $amount2 = $rep['payment']['amount'];
    $card_no1 = $rep['payment']['card_no'];
    $hashed_card1 = $rep['payment']['hashed_card_no'];
  } else {
    echo "تراکنش ناموفق
خطا در مرحله پرداخت
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
    Header("Location: $web/pay/Result/Cancelled.html");
  }
  if ($status1 == '100') {

    $result1 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM pay WHERE id = '$id1'"));

    if ($result1 == null) {

      $connect->query("INSERT INTO `pay`(`code`, `id`, `order_id`, `amount`, `track_idpay`, `track_id`, `amount_payment`, `date`, `card_number`, `hashed_card`) VALUES ('$codebuy','$id1','$order_id1','$amount1','$track_idpay1','$track_id1','$amount2','$date1','$card_no1','$hashed_card1')");


      $resultt = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$order_id1' LIMIT 1"));
      $id = $resultt['id'];

      $coin = $resultt['coin'];


      $amount111 = $amount1 / 10;

      $newcoin = $amount111 / 1000;

      $newmoney = $coin + $newcoin;

      $connect->query("UPDATE user SET coin = '$newmoney' WHERE id = $order_id1");
      //====================================================//
      $data = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
      $setcountbuy = $data['countbuy']  +  1;
      $connect->query("UPDATE `user` SET `countbuy` = '$setcountbuy' WHERE `id` = '$user' LIMIT 1");
      //====================================================//

      $result11 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$order_id1' LIMIT 1"));
      $money1 = $result11['coin'];

      bot('sendmessage', [
        'chat_id' => $admin[0],
        'text' => "
تراکنش تایید شده :

آیدی کاربرآیدی کاربر »
  [$order_id1](tg://openmessage?user_id=$order_id1)
• موجودی قبلی»
  $coin
• موجودی فعلی »
 $money1
•مبلغ تراکنش(ریال) »
 $amount1
• شماره کارت »
 $card_no1
• کد پیگیری » 
$track_id1
• شماره پرداخت »
$codebuy
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
      ]);
      bot('sendmessage', [
        'chat_id' => $log_channel,
        'text' => "
تراکنش تایید شده :

آیدی کاربرآیدی کاربر »
  [$order_id1](tg://openmessage?user_id=$order_id1)
• موجودی قبلی»
  $coin
• موجودی فعلی »
 $money1
•مبلغ تراکنش(ریال) »
 $amount1
• شماره کارت »
 $card_no1
• کد پیگیری » 
$track_id1
• شماره پرداخت »
$codebuy
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
      ]);
      bot('sendmessage', [
        'chat_id' => $order_id1,
        'text' => "✅ #پرداخت_موفق 
⬆️ با تشکر از خرید شما , سکه های حساب شما افزایش یافت

💰 موجودی جدید حساب : $money1 سکه
☑️ مبلغ پرداخت شده : $amount1 تومان",
      ]);

      echo "
آیدی کاربر : $order_id1\n
موجودی قبلی:  $coin\n
موجودی فعلی : $money1\n
مبلغ تراکنش : $newcoin\n
شماره کارت : $card_no1\n
کد پیگیری : $track_id1";

      Header("Location: $web/pay/Result/Successful.html");
    } else {
      echo "تراکنش تکراری
از تکرار مجدد خودداری کنید";
      Header("Location: $web/pay/Result/Cancelled.html");
    }
  } else {
    echo "تراکنش ناموفق
تراکنش شما تایید نشد
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
    Header("Location: $web/pay/Result/Cancelled.html");
  }
}