<?php
//==================================================
include '../config.php';
//====================//  Get  //==============================
$token = API_KEY; // توکن ربات
define('API_KEY', $token);
$user = $_GET['id'];
$time = $_GET['time'];
$amount = $time * $onemah;
$user2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$block = mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$user' LIMIT 1");
$blocked = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$user' LIMIT 1"));
$banreason = $blocked['reason'];
//========================== // config // ==============================
$CallbackURL = "$addres/pay/buyVIPback.php?time=$time&id=$user"; // لینک برگشت خرید
$Description = "خرید سورس از $botname";
//========================================================
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
//========================================================
function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown",
    ]);
}
//==================================================
if (strpos($user, '#') !== false or strpos($user, "'") !== false or strpos($user, '"') !== false) {
    exit;
}
if (strpos($time, '#') !== false or strpos($time, "'") !== false or strpos($time, '"') !== false) {
    exit;
}

if ($_GET['time'] != "30" and $_GET['time'] != "60") {
    echo "لطفا از دست زدن به مقادیر پرهیز کنید";
    exit;
}

if ($user2['id'] != true) {
    echo "لطفا اول در ربات ثبت نام کنید";
    exit;
}

if (mysqli_num_rows($block) > 0) {
    echo "شما به دلیل $banreason از ربات مسدود شده اید";
    exit;
}

if ($user2['activeuser'] != "1") {
    echo "لطفا اول حساب خود را تایید کنید";
    exit;
}

if (!isset($user) or !isset($time)) {

    echo "تراکنش شما با مشکل مواجه شد
لطفا از دست زدن به مقادیر پرهیز کرده و دوباره امتحان کنید";
} else {

    $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
    $result = $client->PaymentRequest([
        'MerchantID' => $zarinpal_key,
        'Amount' => $amount,
        'Description' => $Description,
        'Email' => $Email,
        'Mobile' => $Mobile,
        'CallbackURL' => $CallbackURL,
    ]);
    //==============================================================
    Header('Location: https://www.zarinpal.com/pg/StartPay/' . $result->Authority . '/ZarinGate');
}