<?php
error_reporting(0);
header('Content-type: application/json;');
include "../config.php";
$token = API_KEY; // توکن ربات
define('API_KEY', $token);
//========================================================
function bot($method, $datas = [])
{
  $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
  $res = curl_exec($ch);
  if (curl_error($ch)) {
    var_dump(curl_error($ch));
  } else {
    return json_decode($res);
  }
}
//========================================================
function sendmessage($chat_id, $text)
{
  bot('sendMessage', [
    'chat_id' => $chat_id,
    'text' => $text,
    'parse_mode' => "MarkDown",
  ]);
}
$amountkobs = $_GET['amount'] * 10;
$orderid = $_GET['id'];
$user2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$orderid' LIMIT 1"));
$block = mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$user' LIMIT 1");
$blocked = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `block` WHERE `id` = '$user' LIMIT 1"));
$banreason = $blocked['reason'];

if ($user2['id'] != true) {
  echo "لطفا اول در ربات ثبت نام کنید";
  exit;
}

if (mysqli_num_rows($block) > 0) {
  echo "شما به دلیل $banreason از ربات مسدود شده اید";
  exit;
}

if ($user2['activeuser'] != "1") {
  echo "لطفا اول حساب خود را تایید کنید";
  exit;
}

if (!isset($amountkobs) or !isset($orderid)) {

  echo "تراکنش شما با مشکل مواجه شد
لطفا از دست زدن به مقادیر پرهیز کرده و دوباره امتحان کنید";
} else {

  $params = array(
    'order_id' => "$orderid",
    'amount' => "$amountkobs",
    'callback' => "$backlink_idpay",
  );

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment');
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    "X-API-KEY: $idpay_key"
  ));

  $result = curl_exec($ch);
  curl_close($ch);

  $rep = json_decode($result, true);
  $code = $rep['id'];
  $transid = $rep['link'];

  bot('sendmessage', [
    'chat_id' => $log_channel,
    'text' => "
• آیدی کاربر »
 [$orderid](tg://openmessage?user_id=$orderid)
• کد تراکنش »
 $code
• لینک تراکنش »
 $transid
", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true
  ]);


  echo "$code\n$transid";

  if (!isset($code) or !isset($transid)) {
    echo "تراکنش با مشکل روبرو شد
لطفا دوباره امتحان کنید";
  } else {

    header("Location: $transid");
  }
}