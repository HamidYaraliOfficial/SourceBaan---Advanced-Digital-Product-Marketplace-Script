<?php
header('Content-type: application/json;');
include '../config.php';
include('../lib/jdf.php');
//==============================================================
$token = API_KEY; // توکن ربات
define('API_KEY', $token);
$user = $_GET['id'];
$fileid = $_GET['file'];
$user2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$vipfile = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `vipfile` WHERE `id` = '$fileid' LIMIT 1"));
$allbuy = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay`"));
$postid = $vipfile['messageid'];
$amount = $vipfile['moneydownload'];
$Authority = $_GET['Authority'];
$time = jdate('H:i:s');
$date = jdate('j F Y');
//==============================================================
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification([
    'MerchantID' => $zarinpal_key,
    'Authority' => $Authority,
    'Amount' => $amount,
]);
//========================================================
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
//========================================================
function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown",
    ]);
}
//==============================================================
if (strpos($user, '#') !== false or strpos($user, "'") !== false or strpos($user, '"') !== false) {
    exit;
}
if (strpos($fileid, '#') !== false or strpos($fileid, "'") !== false or strpos($fileid, '"') !== false) {
    exit;
}
if ($user2['activeuser'] != "1") {
    echo "لطفا اول حساب خود را تایید کنید";
    exit;
}


if ($_GET['Status'] == 'OK' and $result->Status == 100) {
    $data = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
    $ippardakhkonnande = $_SERVER['REMOTE_ADDR'];
    bot('sendDocument', [
        'chat_id' => $user,
        'document' => $vipfile['file'],
        'caption' => $vipfile['caption'],
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "like_$match[2]"]],
            ]
        ])
    ]);
    bot('sendmessage', [
        'chat_id' => $user,
        'text' => "✅ #پرداخت_موفق 
	
⬆️ باتشکر از خرید شما ، سورس بالا با موفقیت به شما ارسال شد

⬇️ لطفا از منوی پایین به سورس خریداری شده رائ بدید ( درصورت رائ 5 ستاره به شما مقداری سکه هدیه داده میشه )",
        'reply_to_message_id' => $message_id,
        'reply_markup' => $home,
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "⭐️ 1", 'callback_data' => "score|1|$fileid"], ['text' => "⭐️ 2", 'callback_data' => "score|2|$fileid"], ['text' => "⭐️ 3", 'callback_data' => "score|3|$fileid"], ['text' => "⭐️ 4", 'callback_data' => "score|4|$fileid"], ['text' => "⭐️ 5", 'callback_data' => "score|5|$fileid"]],
            ]
        ])
    ]);
    $codebuy = $allbuy + 1;
    bot('sendmessage', [
        'chat_id' => $admin[0],
        'text' => "✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
🏷 شماره پرداخت : $codebuy

👈 شماره سورس : $fileid

📱 شماره فرد : {$data['phone']}
📍 آیپی فرد : $ippardakhkonnande

👤 کاربر : [$user](tg://user?id=$user)",
        'parse_mode' => 'Markdown',
    ]);
    bot('sendmessage', [
        'chat_id' => $log_channel,
        'text' => "✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
🏷 شماره پرداخت : $codebuy

👈 شماره سورس : $fileid

📱 شماره فرد : {$data['phone']}
📍 آیپی فرد : $ippardakhkonnande

👤 کاربر : [$user](tg://user?id=$user)",
        'parse_mode' => 'Markdown',
    ]);
    $buynumber = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `vipdownload` WHERE `file` = '$fileid'"));
    $vipdownload2 = $buynumber + 1;
    $gheymatsource = $vipfile['moneydownload'];
    $gheyakharsorce = number_format($gheymatsource);
    bot('editMessageReplyMarkup', [
        'chat_id' => "@$channel",
        'message_id' => $postid,
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '📂 دریافت سورس', 'url' => "https://t.me/$usernamebot?start=vipfile_$fileid"]],
                [['text' => "💰 قیمت سورس : $gheyakharsorce تومان", 'callback_data' => 'hazinesource'], ['text' => "تعداد خرید موفق : $vipdownload2 💎", 'callback_data' => 'kharidmovafagh']],
                [['text' => "❤️ ({$vipfile['like']})", 'callback_data' => "viplike_$fileid"]],
            ]
        ])
    ]);
    $connect->query("INSERT INTO `pay` (`code` , `id`, `fileid`, `amount`, `Authority`, `time`, `date`, `phone`, `ip`) VALUES ('$codebuy' , '$user', '$fileid', '$amount', '$Authority', '$time', '$date', '${$data['phone']}', '$ippardakhkonnande')");
    $connect->query("UPDATE `vipfile` SET `download` = '$vipdownload2' WHERE `id` = '$fileid' LIMIT 1");
    $connect->query("INSERT INTO `vipdownload` (`id` , `file`) VALUES ('$user' , '$fileid')");
    //====================================================//
    echo "
آیدی کاربر : $user\n
شماره سورس:  $fileid\n
مبلغ تراکنش : $amount\n
شماره شما : {$data['phone']}\n
آیپی شما : $ippardakhkonnande\n";

    Header("Location: $web/pay/Result/Successful.html");
} else {
    echo "تراکنش ناموفق
تراکنش شما تایید نشد
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
    Header("Location: $web/pay/Result/Cancelled.html");
}