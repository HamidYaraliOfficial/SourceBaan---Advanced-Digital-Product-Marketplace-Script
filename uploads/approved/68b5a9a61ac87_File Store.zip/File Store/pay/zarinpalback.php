<?php
header('Content-type: application/json;');
include '../config.php';
include('../lib/jdf.php');
//==============================================================
$token = API_KEY; // توکن ربات
define('API_KEY', $token);
$user = $_GET['id'];
$amount = $_GET['amount'];
$Authority = $_GET['Authority'];
$coin = $amount / $gheymatcoin;
$time = jdate('H:i:s');
$date = jdate('j F Y');
$user2 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$allbuy = mysqli_num_rows(mysqli_query($connect, "select `id` from `pay`"));
$codebuy = $allbuy + 1;
//==============================================================
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification([
	'MerchantID' => $zarinpal_key,
	'Authority' => $Authority,
	'Amount' => $amount,
]);
//========================================================
function bot($method, $datas = [])
{
	$url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
	$res = curl_exec($ch);
	if (curl_error($ch)) {
		var_dump(curl_error($ch));
	} else {
		return json_decode($res);
	}
}
//========================================================
function sendmessage($chat_id, $text)
{
	bot('sendMessage', [
		'chat_id' => $chat_id,
		'text' => $text,
		'parse_mode' => "MarkDown",
	]);
}
//==============================================================

if ($user2['activeuser'] != "1") {
	echo "لطفا اول حساب خود را تایید کنید";
	exit;
}

// if (!isset($user) or !isset($amount) or !isset($Authority)) {

// echo "تراکنش شما مورد تایید نیست";

// }else{

if ($_GET['Status'] == 'OK' and $result->Status == 100) {
	$data = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
	$pluscoin = $data['coin']  +  $coin;
	$ippardakhkonnande = $_SERVER['REMOTE_ADDR'];
	bot('sendmessage', [
		'chat_id' => $user,
		'text' => "✅ #پرداخت_موفق 
⬆️ با تشکر از خرید شما , سکه های حساب شما افزایش یافت

💰 موجودی جدید حساب : $pluscoin سکه
☑️ مبلغ پرداخت شده : $amount تومان",
		'reply_markup' => $home
	]);
	bot('sendmessage', [
		'chat_id' => $admin[0],
		'text' => "✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
🏷 شماره پرداخت : $codebuy

👈 میزان سکه قبل خرید :
{$data['coin']}
👈 میزان سکه بعد خرید :
$pluscoin

📞 شماره فرد : {$data['phone']}
📍 آیپی فرد : $ippardakhkonnande

👤 کاربر : [$user](tg://user?id=$user)",
		'parse_mode' => 'Markdown',
	]);
	bot('sendmessage', [
		'chat_id' => $log_channel,
		'text' => "✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
🏷 شماره پرداخت : $codebuy

👈 میزان سکه قبل خرید :
{$data['coin']}
👈 میزان سکه بعد خرید :
$pluscoin

📞 شماره فرد : {$data['phone']}
📍 آیپی فرد : $ippardakhkonnande

👤 کاربر : [$user](tg://user?id=$user)",
		'parse_mode' => 'Markdown',
	]);
	echo "
آیدی کاربر : $user\n
موجودی قبلی:  {$data['coin']}\n
موجودی فعلی : $pluscoin\n
مبلغ تراکنش : $amount\n
شماره شما : {$data['phone']}\n
آیپی شما : $ippardakhkonnande\n";

	Header("Location: $web/pay/Result/Successful.html");

	$connect->query("INSERT INTO `pay` (`code` , `id` , `coin` , `coinghabl` , `coinbad` , `amount` , `Authority` , `time` , `date` , `phone` , `ip`) VALUES ('$codebuy' , '$user' , '$coin' , '{$data['coin']}' , '$pluscoin' , '$amount' , '$Authority' , '$time', '$date' , '{$data['phone']}' , '$ippardakhkonnande')");

	$connect->query("UPDATE `user` SET `coin` = '$pluscoin' WHERE `id` = '$user' LIMIT 1");
	//====================================================//

} else {
	echo "تراکنش ناموفق
تراکنش شما تایید نشد
در صورت کسر وجه به حساب شما بازگشت داده خواهد شد";
	Header("Location: $web/pay/Result/Cancelled.html");
}