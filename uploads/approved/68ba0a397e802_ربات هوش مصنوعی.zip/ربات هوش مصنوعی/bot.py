import sqlite3
import os
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    CallbackQueryHandler,
)
from openai import OpenAI
import json
import asyncio

load_dotenv()
TELEGRAM_BOT_TOKEN = os.getenv("BOT_TOKEN") #توکن ربات 
ADMIN_ID = int(os.getenv("CHAT_ID")) #چت آیدی شما 

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY")) #API شما

def init_db():
    try:
        with sqlite3.connect("bot.db", timeout=10) as conn:
            c = conn.cursor()
            c.execute(
                """CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )"""
            )
            c.execute(
                """CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    is_blocked BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )"""
            )
            c.execute(
                """INSERT OR IGNORE INTO settings (key, value) VALUES
                    ('bot_status', 'on'),
                    ('start_message', 'خوش آمدید به ربات!'),
                    ('off_message', 'ربات خاموش است.'),
                    ('force_join', ''),
                    ('buttons', '[]')"""
            )
            conn.commit()
    except sqlite3.Error as e:
        print(f"خطا در ایجاد پایگاه داده: {e}")

def get_setting(key):
    try:
        with sqlite3.connect("bot.db", timeout=10) as conn:
            c = conn.cursor()
            c.execute("SELECT value FROM settings WHERE key = ?", (key,))
            result = c.fetchone()
            return result[0] if result else None
    except sqlite3.Error as e:
        print(f"خطا در خواندن تنظیمات: {e}")
        return None

def update_setting(key, value):
    try:
        with sqlite3.connect("bot.db", timeout=10) as conn:
            c = conn.cursor()
            c.execute("UPDATE settings SET value = ? WHERE key = ?", (value, key))
            conn.commit()
    except sqlite3.Error as e:
        print(f"خطا در به‌روزرسانی تنظیمات: {e}")

def is_user_blocked(user_id):
    try:
        with sqlite3.connect("bot.db", timeout=10) as conn:
            c = conn.cursor()
            c.execute("SELECT is_blocked FROM users WHERE user_id = ?", (user_id,))
            result = c.fetchone()
            return bool(result[0]) if result else False
    except sqlite3.Error as e:
        print(f"خطا در بررسی وضعیت کاربر: {e}")
        return False

def add_or_update_user(user_id, username=None, first_name=None, last_name=None, is_blocked=False):
    try:
        with sqlite3.connect("bot.db", timeout=10) as conn:
            c = conn.cursor()
            c.execute(
                """INSERT OR REPLACE INTO users 
                (user_id, username, first_name, last_name, is_blocked) 
                VALUES (?, ?, ?, ?, ?)""",
                (user_id, username, first_name, last_name, is_blocked),
            )
            conn.commit()
    except sqlite3.Error as e:
        print(f"خطا در افزودن/به‌روزرسانی کاربر: {e}")

async def check_channel_membership(update: Update, context: ContextTypes.DEFAULT_TYPE):
    force_join = get_setting("force_join")
    if force_join:
        try:
            member = await context.bot.get_chat_member(force_join, update.effective_user.id)
            if member.status not in ["member", "administrator", "creator"]:
                await update.message.reply_text("لطفاً ابتدا در کانال ما عضو شوید: " + force_join)
                return False
        except Exception as e:
            print(f"خطا در بررسی عضویت: {e}")
            await update.message.reply_text("لطفاً ابتدا در کانال ما عضو شوید: " + force_join)
            return False
    return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    add_or_update_user(
        user.id, 
        user.username, 
        user.first_name, 
        user.last_name
    )
    
    if not await check_channel_membership(update, context):
        return
        
    start_message = get_setting("start_message")
    try:
        buttons = json.loads(get_setting("buttons") or "[]")
    except json.JSONDecodeError:
        buttons = []
        
    keyboard = [[InlineKeyboardButton(text, callback_data=text) for text in buttons]]
    reply_markup = InlineKeyboardMarkup(keyboard) if buttons else None
    await update.message.reply_text(start_message, reply_markup=reply_markup)

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("شما دسترسی به پنل مدیریت ندارید.")
        return
        
    if not await check_channel_membership(update, context):
        return
        
    keyboard = [
        [InlineKeyboardButton("تنظیم جوین اجباری", callback_data="set_force_join")],
        [InlineKeyboardButton("حذف جوین اجباری", callback_data="remove_force_join")],
        [InlineKeyboardButton("آمار ربات", callback_data="stats")],
        [InlineKeyboardButton("ارسال پیام به کاربر", callback_data="send_to_user")],
        [InlineKeyboardButton("ارسال پیام همگانی", callback_data="broadcast")],
        [InlineKeyboardButton("مسدود کردن کاربر", callback_data="block_user")],
        [InlineKeyboardButton("لغو مسدودیت کاربر", callback_data="unblock_user")],
        [InlineKeyboardButton("تغییر متن استارت", callback_data="change_start")],
        [InlineKeyboardButton("اضافه/حذف دکمه", callback_data="manage_buttons")],
        [InlineKeyboardButton("روشن/خاموش کردن ربات", callback_data="toggle_bot")],
        [InlineKeyboardButton("تغییر متن ربات خاموش", callback_data="change_off_message")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("پنل مدیریت:", reply_markup=reply_markup)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    add_or_update_user(
        user.id, 
        user.username, 
        user.first_name, 
        user.last_name
    )
    
    if not await check_channel_membership(update, context):
        return
        
    if is_user_blocked(user.id):
        await update.message.reply_text("شما مسدود شده‌اید.")
        return
        
    
    if user.id == ADMIN_ID and context.user_data.get("admin_action"):
        await handle_admin_action(update, context)
        return
        
    if get_setting("bot_status") == "off":
        await update.message.reply_text(get_setting("off_message"))
        return
        
    user_message = update.message.text
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": user_message}],
        )
        await update.message.reply_text(response.choices[0].message.content)
    except Exception as e:
        print(f"خطا در ارتباط با OpenAI: {e}")
        await update.message.reply_text("خطایی رخ داد. لطفاً دوباره امتحان کنید.")

async def handle_admin_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    action = context.user_data["admin_action"]
    message = update.message.text
    
    if action == "set_force_join":
        if not message.startswith("@"):
            await update.message.reply_text("آیدی کانال باید با @ شروع شود.")
            return
        update_setting("force_join", message)
        await update.message.reply_text("جوین اجباری تنظیم شد.")
        context.user_data["admin_action"] = None
        
    elif action == "send_to_user_id":
        try:
            context.user_data["target_user_id"] = int(message)
            context.user_data["admin_action"] = "send_to_user_message"
            await update.message.reply_text("پیام را برای کاربر ارسال کنید:")
            return
        except ValueError:
            await update.message.reply_text("شناسه کاربر باید عددی باشد.")
            
    elif action == "send_to_user_message":
        target_user_id = context.user_data.get("target_user_id")
        try:
            await context.bot.send_message(target_user_id, message)
            await update.message.reply_text("پیام ارسال شد.")
        except:
            await update.message.reply_text("خطا در ارسال پیام.")
        finally:
            context.user_data["admin_action"] = None
            context.user_data["target_user_id"] = None
            
    elif action == "broadcast":
        try:
            with sqlite3.connect("bot.db", timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT user_id FROM users WHERE is_blocked = 0")
                users = c.fetchall()
                
            await update.message.reply_text("در حال ارسال پیام همگانی...")
            success_count = 0
            for i, user_id in enumerate(users):
                try:
                    await context.bot.send_message(user_id[0], message)
                    success_count += 1
                    if i % 20 == 0:
                        await asyncio.sleep(1)
                except:
                    continue
                    
            await update.message.reply_text(f"پیام همگانی به {success_count} کاربر ارسال شد.")
        except sqlite3.Error:
            await update.message.reply_text("خطای پایگاه داده.")
        finally:
            context.user_data["admin_action"] = None
            
    elif action == "block_user":
        try:
            user_id_to_block = int(message)
            add_or_update_user(user_id_to_block, is_blocked=True)
            await update.message.reply_text("کاربر مسدود شد.")
        except ValueError:
            await update.message.reply_text("شناسه کاربر باید عددی باشد.")
        finally:
            context.user_data["admin_action"] = None
            
    elif action == "unblock_user":
        try:
            user_id_to_unblock = int(message)
            add_or_update_user(user_id_to_unblock, is_blocked=False)
            await update.message.reply_text("مسدودیت کاربر لغو شد.")
        except ValueError:
            await update.message.reply_text("شناسه کاربر باید عددی باشد.")
        finally:
            context.user_data["admin_action"] = None
            
    elif action == "change_start":
        update_setting("start_message", message)
        await update.message.reply_text("متن استارت تغییر کرد.")
        context.user_data["admin_action"] = None
        
    elif action == "manage_buttons":
        try:
            buttons = json.loads(get_setting("buttons") or "[]")
        except json.JSONDecodeError:
            buttons = []
            
        if message in buttons:
            buttons.remove(message)
            await update.message.reply_text("دکمه حذف شد.")
        else:
            buttons.append(message)
            await update.message.reply_text("دکمه اضافه شد.")
            
        update_setting("buttons", json.dumps(buttons))
        context.user_data["admin_action"] = None
        
    elif action == "change_off_message":
        update_setting("off_message", message)
        await update.message.reply_text("متن ربات خاموش تغییر کرد.")
        context.user_data["admin_action"] = None
    
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    if user_id != ADMIN_ID:
        await query.edit_message_text("شما دسترسی به این بخش ندارید.")
        return
        
    data = query.data
    
    if data == "set_force_join":
        await query.edit_message_text("لطفاً آیدی کانال (مانند @ChannelID) را ارسال کنید:")
        context.user_data["admin_action"] = "set_force_join"
        
    elif data == "remove_force_join":
        update_setting("force_join", "")
        await query.edit_message_text("جوین اجباری حذف شد.")
        
    elif data == "stats":
        try:
            with sqlite3.connect("bot.db", timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT COUNT(*) FROM users")
                user_count = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM users WHERE is_blocked = 1")
                blocked_count = c.fetchone()[0]
                
            await query.edit_message_text(
                f"تعداد کاربران: {user_count}\n"
                f"تعداد کاربران مسدود: {blocked_count}"
            )
        except sqlite3.Error:
            await query.edit_message_text("خطای پایگاه داده.")
            
    elif data == "send_to_user":
        await query.edit_message_text("شناسه کاربر را ارسال کنید:")
        context.user_data["admin_action"] = "send_to_user_id"
        
    elif data == "broadcast":
        await query.edit_message_text("پیام همگانی را ارسال کنید:")
        context.user_data["admin_action"] = "broadcast"
        
    elif data == "block_user":
        await query.edit_message_text("شناسه کاربر را برای مسدود کردن ارسال کنید:")
        context.user_data["admin_action"] = "block_user"
        
    elif data == "unblock_user":
        await query.edit_message_text("شناسه کاربر را برای لغو مسدودیت ارسال کنید:")
        context.user_data["admin_action"] = "unblock_user"
        
    elif data == "change_start":
        await query.edit_message_text("متن جدید استارت را ارسال کنید:")
        context.user_data["admin_action"] = "change_start"
        
    elif data == "manage_buttons":
        await query.edit_message_text("دکمه جدید را ارسال کنید (یا برای حذف، دکمه را وارد کنید):")
        context.user_data["admin_action"] = "manage_buttons"
        
    elif data == "toggle_bot":
        new_status = "off" if get_setting("bot_status") == "on" else "on"
        update_setting("bot_status", new_status)
        await query.edit_message_text(f"ربات {new_status} شد.")
        
    elif data == "change_off_message":
        await query.edit_message_text("متن جدید برای ربات خاموش را ارسال کنید:")
        context.user_data["admin_action"] = "change_off_message"

def main():
    init_db()
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print("ربات در حال اجرا است...")
    app.run_polling()

if __name__ == "__main__":
    main()