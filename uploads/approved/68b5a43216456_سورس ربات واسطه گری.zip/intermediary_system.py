# -*- coding: utf-8 -*-
"""
Advanced Intermediary/Escrow System for Secure Transactions
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import uuid
import asyncio

from database import Database, Transaction, TransactionStatus, User
from ui_components import GlassUI, MessageFormatter
from security import SecurityManager, InputSanitizer
from config import Config

class TransactionStep(Enum):
    TITLE = "title"
    DESCRIPTION = "description"
    AMOUNT = "amount"
    CONFIRMATION = "confirmation"
    BUYER_SELECTION = "buyer_selection"

@dataclass
class EscrowTransaction:
    """Escrow transaction data"""
    id: str
    seller_id: int
    buyer_id: Optional[int]
    title: str
    description: str
    amount: int
    commission: int
    status: TransactionStatus
    created_at: datetime
    expires_at: datetime
    escrow_funds: int = 0
    seller_confirmed: bool = False
    buyer_confirmed: bool = False
    dispute_reason: Optional[str] = None

class IntermediarySystem:
    """Advanced intermediary/escrow management system"""
    
    def __init__(self, database: Database, security_manager: SecurityManager):
        self.db = database
        self.security = security_manager
        
        # Transaction states for conversation handler
        self.transaction_states = {}
        
        # Escrow storage (in production, use secure storage)
        self.escrow_accounts: Dict[str, EscrowTransaction] = {}
        
        # Auto-cancel timer
        self.auto_cancel_tasks: Dict[str, asyncio.Task] = {}
    
    async def start_selling_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start the selling process"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user:
            await update.callback_query.answer("❌ ابتدا باید در ربات ثبت‌نام کنید!", show_alert=True)
            return ConversationHandler.END
        
        if user.is_banned:
            await update.callback_query.answer("⛔ حساب شما مسدود است!", show_alert=True)
            return ConversationHandler.END
        
        # Check pending transactions limit
        pending_transactions = self.db.get_user_transactions(user_id, TransactionStatus.PENDING)
        if len(pending_transactions) >= Config.MAX_PENDING_TRANSACTIONS_PER_USER:
            await update.callback_query.answer(
                f"⚠️ حداکثر {Config.MAX_PENDING_TRANSACTIONS_PER_USER} معامله همزمان!", 
                show_alert=True
            )
            return ConversationHandler.END
        
        # Initialize transaction data
        transaction_id = self.security.generate_transaction_id()
        context.user_data['new_transaction'] = {
            'id': transaction_id,
            'seller_id': user_id,
            'step': TransactionStep.TITLE
        }
        
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 💰 ایجاد معامله جدید                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔸 مرحله 1 از 4: عنوان محصول/خدمات

📝 لطفاً عنوان محصول یا خدمات خود را وارد کنید:

💡 نکات مهم:
• عنوان باید واضح و مفهوم باشد
• حداکثر 100 کاراکتر
• از کلمات کلیدی مناسب استفاده کنید

✏️ مثال: "گوشی Samsung Galaxy S23 - نو و پلمپ"
"""
        
        keyboard = [[InlineKeyboardButton("❌ لغو", callback_data="cancel_transaction")]]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        return TransactionStep.TITLE
    
    async def handle_title_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle title input"""
        title = update.message.text
        
        # Validate input
        is_valid, error_msg = self.security.validate_user_input(title, max_length=100)
        if not is_valid:
            await update.message.reply_text(f"❌ {error_msg}\n\n📝 لطفاً مجدداً عنوان را وارد کنید:")
            return TransactionStep.TITLE
        
        # Save title
        context.user_data['new_transaction']['title'] = InputSanitizer.sanitize_text(title)
        
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 💰 ایجاد معامله جدید                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔸 مرحله 2 از 4: توضیحات تفصیلی

📋 لطفاً توضیحات کاملی از محصول/خدمات خود ارائه دهید:

💡 اطلاعات مهم:
• وضعیت محصول (نو، کارکرده، ...)
• مشخصات فنی
• شرایط تحویل
• گارانتی و ضمانت

✏️ حداکثر 500 کاراکتر
"""
        
        keyboard = [
            [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="previous_step")],
            [InlineKeyboardButton("❌ لغو", callback_data="cancel_transaction")]
        ]
        
        await update.message.reply_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        return TransactionStep.DESCRIPTION
    
    async def handle_description_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle description input"""
        description = update.message.text
        
        # Validate input
        is_valid, error_msg = self.security.validate_user_input(description, max_length=500)
        if not is_valid:
            await update.message.reply_text(f"❌ {error_msg}\n\n📋 لطفاً مجدداً توضیحات را وارد کنید:")
            return TransactionStep.DESCRIPTION
        
        # Save description
        context.user_data['new_transaction']['description'] = InputSanitizer.sanitize_text(description)
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 💰 ایجاد معامله جدید                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔸 مرحله 3 از 4: تعیین قیمت

💵 لطفاً قیمت محصول/خدمات را به تومان وارد کنید:

💡 محدودیت‌های قیمت:
• حداقل: {Config.MIN_TRANSACTION_AMOUNT:,} تومان
• حداکثر: {Config.MAX_TRANSACTION_AMOUNT:,} تومان
• کارمزد ربات: %{Config.COMMISSION_RATE*100}

📝 فرمت ورودی:
• فقط عدد وارد کنید
• از کاما (,) برای جداسازی استفاده کنید
• مثال: 1,500,000
"""
        
        keyboard = [
            [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="previous_step")],
            [InlineKeyboardButton("❌ لغو", callback_data="cancel_transaction")]
        ]
        
        await update.message.reply_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        return TransactionStep.AMOUNT
    
    async def handle_amount_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle amount input"""
        amount_text = update.message.text
        
        # Sanitize and validate amount
        amount = InputSanitizer.sanitize_amount(amount_text)
        if not amount:
            await update.message.reply_text("❌ قیمت وارد شده معتبر نیست!\n\n💵 لطفاً مبلغ را به درستی وارد کنید:")
            return TransactionStep.AMOUNT
        
        # Validate amount range
        is_valid, error_msg = self.security.validate_transaction_amount(amount)
        if not is_valid:
            await update.message.reply_text(f"❌ {error_msg}\n\n💵 لطفاً مبلغ مناسب وارد کنید:")
            return TransactionStep.AMOUNT
        
        # Calculate commission
        commission = int(amount * Config.COMMISSION_RATE)
        total_amount = amount + commission
        
        # Save amount data
        context.user_data['new_transaction']['amount'] = amount
        context.user_data['new_transaction']['commission'] = commission
        
        # Show confirmation
        transaction_data = context.user_data['new_transaction']
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                🔍 تایید نهایی معامله                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📋 مشخصات معامله:

🆔 شناسه: `{transaction_data['id']}`
📝 عنوان: {transaction_data['title']}
📋 توضیحات: {transaction_data['description'][:100]}{'...' if len(transaction_data['description']) > 100 else ''}

💰 قیمت اصلی: {amount:,} تومان
💳 کارمزد (%{Config.COMMISSION_RATE*100}): {commission:,} تومان
💎 مبلغ نهایی: {total_amount:,} تومان

⚠️ نکات مهم:
• معامله پس از تایید، 24 ساعت معتبر است
• خریدار باید کل مبلغ ({total_amount:,} تومان) را واریز کند
• پس از تایید خریدار، وجه در حساب امانت نگهداری می‌شود

✅ آیا اطلاعات صحیح است؟
"""
        
        keyboard = [
            [
                InlineKeyboardButton("✅ تایید و انتشار", callback_data="confirm_transaction"),
                InlineKeyboardButton("❌ لغو", callback_data="cancel_transaction")
            ],
            [InlineKeyboardButton("⬅️ مرحله قبل", callback_data="previous_step")]
        ]
        
        await update.message.reply_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        return TransactionStep.CONFIRMATION
    
    async def confirm_transaction(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Confirm and create transaction"""
        transaction_data = context.user_data.get('new_transaction')
        if not transaction_data:
            await update.callback_query.answer("❌ خطا در ایجاد معامله!", show_alert=True)
            return ConversationHandler.END
        
        # Create transaction object
        now = datetime.now()
        expires_at = now + timedelta(hours=Config.TRANSACTION_TIMEOUT_HOURS)
        
        transaction = Transaction(
            transaction_id=transaction_data['id'],
            seller_id=transaction_data['seller_id'],
            buyer_id=None,
            title=transaction_data['title'],
            description=transaction_data['description'],
            amount=transaction_data['amount'],
            commission=transaction_data['commission'],
            status=TransactionStatus.PENDING,
            created_at=now,
            updated_at=now,
            expires_at=expires_at
        )
        
        # Save to database
        if self.db.create_transaction(transaction):
            # Create escrow account
            escrow_transaction = EscrowTransaction(
                id=transaction.transaction_id,
                seller_id=transaction.seller_id,
                buyer_id=None,
                title=transaction.title,
                description=transaction.description,
                amount=transaction.amount,
                commission=transaction.commission,
                status=TransactionStatus.PENDING,
                created_at=transaction.created_at,
                expires_at=transaction.expires_at
            )
            self.escrow_accounts[transaction.transaction_id] = escrow_transaction
            
            # Schedule auto-cancel
            self.schedule_auto_cancel(transaction.transaction_id, expires_at)
            
            # Success message
            message = f"""
✅ معامله با موفقیت ایجاد شد!

🆔 شناسه معامله: `{transaction.transaction_id}`
⏰ اعتبار تا: {expires_at.strftime('%Y/%m/%d - %H:%M')}

📢 معامله شما منتشر شد و خریداران می‌توانند آن را مشاهده کنند.

🔔 اعلانات:
• هنگام پیدا کردن خریدار، اطلاع‌رسانی می‌شوید
• پیام‌های مربوط به معامله را دنبال کنید
• در صورت مشکل، با پشتیبانی تماس بگیرید

🎯 مراحل بعدی:
1️⃣ منتظر خریدار بمانید
2️⃣ پس از یافت خریدار، معامله را تایید کنید
3️⃣ محصول را ارسال کنید
4️⃣ پس از تایید خریدار، وجه به شما پرداخت می‌شود
"""
            
            keyboard = [
                [
                    InlineKeyboardButton("📊 مشاهده معامله", callback_data=f"view_transaction_{transaction.transaction_id}"),
                    InlineKeyboardButton("📋 معاملات من", callback_data="my_transactions")
                ],
                [InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")]
            ]
            
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
            
            # Log the creation
            self.security.log_security_event(
                "TRANSACTION_CREATED", 
                transaction.seller_id, 
                f"Transaction {transaction.transaction_id} created"
            )
            
        else:
            await update.callback_query.answer("❌ خطا در ایجاد معامله!", show_alert=True)
        
        # Clear user data
        context.user_data.pop('new_transaction', None)
        return ConversationHandler.END
    
    async def join_as_buyer(self, update: Update, context: ContextTypes.DEFAULT_TYPE, transaction_id: str):
        """Join transaction as buyer"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user or user.is_banned:
            await update.callback_query.answer("❌ شما مجاز به انجام این عمل نیستید!", show_alert=True)
            return
        
        # Get transaction
        transaction = self.db.get_transaction(transaction_id)
        if not transaction:
            await update.callback_query.answer("❌ معامله پیدا نشد!", show_alert=True)
            return
        
        # Check if user is the seller
        if transaction.seller_id == user_id:
            await update.callback_query.answer("❌ شما نمی‌توانید خریدار معامله خودتان باشید!", show_alert=True)
            return
        
        # Check if transaction is available
        if transaction.status != TransactionStatus.PENDING:
            await update.callback_query.answer("❌ این معامله دیگر در دسترس نیست!", show_alert=True)
            return
        
        # Update transaction with buyer
        transaction.buyer_id = user_id
        transaction.status = TransactionStatus.SELLER_CONFIRMED
        transaction.updated_at = datetime.now()
        
        if self.db.update_transaction_status(transaction_id, TransactionStatus.SELLER_CONFIRMED):
            # Update escrow
            if transaction_id in self.escrow_accounts:
                self.escrow_accounts[transaction_id].buyer_id = user_id
                self.escrow_accounts[transaction_id].status = TransactionStatus.SELLER_CONFIRMED
            
            # Notify both parties
            await self.notify_transaction_update(context, transaction, "خریدار یافت شد!")
            
            message = f"""
✅ شما با موفقیت وارد معامله شدید!

🆔 شناسه معامله: `{transaction_id}`
📝 عنوان: {transaction.title}
💰 مبلغ کل: {transaction.amount + transaction.commission:,} تومان

🔔 مرحله بعدی:
📱 لطفاً مبلغ {transaction.amount + transaction.commission:,} تومان را به حساب ربات واریز کنید.

💳 اطلاعات واریز:
[اطلاعات حساب ربات اینجا قرار می‌گیرد]

⚠️ نکات مهم:
• پس از واریز، تایید پرداخت کنید
• وجه تا تایید نهایی در حساب امانت نگهداری می‌شود
• در صورت مشکل، با پشتیبانی تماس بگیرید
"""
            
            keyboard = [
                [InlineKeyboardButton("💳 تایید پرداخت", callback_data=f"confirm_payment_{transaction_id}")],
                [InlineKeyboardButton("📞 تماس با فروشنده", callback_data=f"contact_seller_{transaction_id}")],
                [InlineKeyboardButton("❌ انصراف از معامله", callback_data=f"cancel_transaction_{transaction_id}")]
            ]
            
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
        else:
            await update.callback_query.answer("❌ خطا در به‌روزرسانی معامله!", show_alert=True)
    
    def schedule_auto_cancel(self, transaction_id: str, expires_at: datetime):
        """Schedule automatic transaction cancellation"""
        async def auto_cancel():
            await asyncio.sleep((expires_at - datetime.now()).total_seconds())
            
            transaction = self.db.get_transaction(transaction_id)
            if transaction and transaction.status in [TransactionStatus.PENDING, TransactionStatus.SELLER_CONFIRMED]:
                self.db.update_transaction_status(transaction_id, TransactionStatus.CANCELLED)
                
                # Remove from escrow
                self.escrow_accounts.pop(transaction_id, None)
                
                # Log cancellation
                self.security.log_security_event(
                    "TRANSACTION_AUTO_CANCELLED", 
                    transaction.seller_id, 
                    f"Transaction {transaction_id} auto-cancelled due to timeout"
                )
        
        # Create and store the task
        task = asyncio.create_task(auto_cancel())
        self.auto_cancel_tasks[transaction_id] = task
    
    async def notify_transaction_update(self, context: ContextTypes.DEFAULT_TYPE, transaction: Transaction, message: str):
        """Notify parties about transaction updates"""
        # This would send notifications to seller and buyer
        # Implementation depends on your notification system
        pass
    
    async def handle_intermediary_callbacks(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle intermediary system callbacks"""
        query = update.callback_query
        data = query.data
        
        if data.startswith("join_transaction_"):
            transaction_id = data.replace("join_transaction_", "")
            await self.join_as_buyer(update, context, transaction_id)
        elif data.startswith("confirm_payment_"):
            transaction_id = data.replace("confirm_payment_", "")
            await self.handle_payment_confirmation(update, context, transaction_id)
        elif data.startswith("mark_sent_"):
            transaction_id = data.replace("mark_sent_", "")
            await self.handle_shipment_confirmation(update, context, transaction_id)
        # Add more handlers as needed
    
    async def handle_payment_confirmation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, transaction_id: str):
        """Handle buyer payment confirmation"""
        # Implementation for payment confirmation
        pass
    
    async def handle_shipment_confirmation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, transaction_id: str):
        """Handle seller shipment confirmation"""
        # Implementation for shipment confirmation
        pass
