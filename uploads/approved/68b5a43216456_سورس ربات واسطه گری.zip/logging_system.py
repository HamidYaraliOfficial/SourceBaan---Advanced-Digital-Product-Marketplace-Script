# -*- coding: utf-8 -*-
"""
Advanced Logging and Monitoring System for Intermediary Bot
"""

import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from enum import Enum
from dataclasses import dataclass, asdict
import asyncio
from pathlib import Path

class LogLevel(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class LogCategory(Enum):
    SECURITY = "security"
    TRANSACTION = "transaction"
    USER_ACTION = "user_action"
    ADMIN_ACTION = "admin_action"
    SYSTEM = "system"
    ERROR = "error"
    PERFORMANCE = "performance"

@dataclass
class LogEntry:
    timestamp: datetime
    level: LogLevel
    category: LogCategory
    user_id: Optional[int]
    action: str
    details: Dict[str, Any]
    ip_address: Optional[str] = None
    session_id: Optional[str] = None

class AdvancedLogger:
    """Advanced logging system with categorization and monitoring"""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Setup Python logging
        self.setup_python_logging()
        
        # In-memory log storage for quick access
        self.recent_logs: List[LogEntry] = []
        self.max_recent_logs = 1000
        
        # Statistics tracking
        self.stats = {
            'total_logs': 0,
            'logs_by_level': {level.value: 0 for level in LogLevel},
            'logs_by_category': {cat.value: 0 for cat in LogCategory},
            'daily_stats': {}
        }
        
        # Alert thresholds
        self.alert_thresholds = {
            LogLevel.ERROR: 10,  # 10 errors per hour
            LogLevel.CRITICAL: 1,  # 1 critical per hour
        }
        self.last_alert_time = {}  # Track last alert time for each level
        
        # Performance metrics
        self.performance_metrics = {
            'response_times': [],
            'active_users': set(),
            'transaction_volume': 0
        }
    
    def setup_python_logging(self):
        """Setup Python logging configuration"""
        # Create formatters
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # File handlers for different log levels
        handlers = {
            'debug': self.log_dir / 'debug.log',
            'info': self.log_dir / 'info.log',
            'warning': self.log_dir / 'warning.log',
            'error': self.log_dir / 'error.log',
            'critical': self.log_dir / 'critical.log'
        }
        
        # Setup logger
        self.logger = logging.getLogger('intermediary_bot')
        self.logger.setLevel(logging.DEBUG)
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # Add file handlers
        for level, filepath in handlers.items():
            handler = logging.FileHandler(filepath, encoding='utf-8')
            handler.setFormatter(detailed_formatter)
            
            if level == 'debug':
                handler.setLevel(logging.DEBUG)
            elif level == 'info':
                handler.setLevel(logging.INFO)
            elif level == 'warning':
                handler.setLevel(logging.WARNING)
            elif level == 'error':
                handler.setLevel(logging.ERROR)
            elif level == 'critical':
                handler.setLevel(logging.CRITICAL)
            
            self.logger.addHandler(handler)
        
        # Console handler for development
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        self.logger.addHandler(console_handler)
    
    def log(self, level: LogLevel, category: LogCategory, action: str, 
            user_id: Optional[int] = None, details: Optional[Dict[str, Any]] = None,
            ip_address: Optional[str] = None, session_id: Optional[str] = None):
        """Log an event with categorization"""
        
        if details is None:
            details = {}
        
        # Create log entry
        log_entry = LogEntry(
            timestamp=datetime.now(),
            level=level,
            category=category,
            user_id=user_id,
            action=action,
            details=details,
            ip_address=ip_address,
            session_id=session_id
        )
        
        # Add to recent logs
        self.recent_logs.append(log_entry)
        if len(self.recent_logs) > self.max_recent_logs:
            self.recent_logs.pop(0)
        
        # Update statistics
        self.update_stats(log_entry)
        
        # Log to file
        self.write_to_file(log_entry)
        
        # Log to Python logger
        self.write_to_python_logger(log_entry)
        
        # Log to database if available
        self.write_to_database(log_entry)
        
        # Check for alerts
        self.check_alerts(log_entry)
    
    def update_stats(self, log_entry: LogEntry):
        """Update logging statistics"""
        self.stats['total_logs'] += 1
        self.stats['logs_by_level'][log_entry.level.value] += 1
        self.stats['logs_by_category'][log_entry.category.value] += 1
        
        # Daily stats
        date_key = log_entry.timestamp.date().isoformat()
        if date_key not in self.stats['daily_stats']:
            self.stats['daily_stats'][date_key] = {
                'total': 0,
                'levels': {level.value: 0 for level in LogLevel},
                'categories': {cat.value: 0 for cat in LogCategory}
            }
        
        self.stats['daily_stats'][date_key]['total'] += 1
        self.stats['daily_stats'][date_key]['levels'][log_entry.level.value] += 1
        self.stats['daily_stats'][date_key]['categories'][log_entry.category.value] += 1
    
    def write_to_file(self, log_entry: LogEntry):
        """Write log entry to JSON file"""
        log_file = self.log_dir / f"{log_entry.timestamp.date().isoformat()}.json"
        
        # Convert to dict
        entry_dict = asdict(log_entry)
        entry_dict['timestamp'] = log_entry.timestamp.isoformat()
        entry_dict['level'] = log_entry.level.value
        entry_dict['category'] = log_entry.category.value
        
        # Append to daily log file
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry_dict, ensure_ascii=False) + '\n')
    
    def write_to_python_logger(self, log_entry: LogEntry):
        """Write to Python logger"""
        message = f"[{log_entry.category.value.upper()}] {log_entry.action}"
        if log_entry.user_id:
            message += f" (User: {log_entry.user_id})"
        if log_entry.details:
            message += f" - Details: {json.dumps(log_entry.details, ensure_ascii=False)}"
        
        if log_entry.level == LogLevel.DEBUG:
            self.logger.debug(message)
        elif log_entry.level == LogLevel.INFO:
            self.logger.info(message)
        elif log_entry.level == LogLevel.WARNING:
            self.logger.warning(message)
        elif log_entry.level == LogLevel.ERROR:
            self.logger.error(message)
        elif log_entry.level == LogLevel.CRITICAL:
            self.logger.critical(message)
    
    def write_to_database(self, log_entry: LogEntry):
        """Write log entry to database if available"""
        try:
            if hasattr(self, 'database') and self.database:
                # In real implementation, you would save to database
                # For now, we just pass to avoid errors
                pass
        except Exception:
            # Database not available or error, skip silently
            pass
    
    def check_alerts(self, log_entry: LogEntry):
        """Check if log entry triggers any alerts"""
        # Prevent recursion by skipping alert checks for alert logs
        if log_entry.action == "HIGH_FREQUENCY_ALERT":
            return
            
        if log_entry.level in self.alert_thresholds:
            # Count recent logs of this level (excluding alert logs)
            one_hour_ago = datetime.now() - timedelta(hours=1)
            recent_count = sum(
                1 for log in self.recent_logs 
                if (log.level == log_entry.level and 
                    log.timestamp > one_hour_ago and 
                    log.action != "HIGH_FREQUENCY_ALERT")  # Exclude alert logs from count
            )
            
            if recent_count >= self.alert_thresholds[log_entry.level]:
                # Check if we haven't sent an alert for this level recently
                current_time = datetime.now()
                last_alert = self.last_alert_time.get(log_entry.level)
                
                if not last_alert or (current_time - last_alert).total_seconds() > 3600:  # 1 hour cooldown
                    self.trigger_alert(log_entry.level, recent_count)
                    self.last_alert_time[log_entry.level] = current_time
    
    def trigger_alert(self, level: LogLevel, count: int):
        """Trigger alert for high frequency errors"""
        alert_message = f"HIGH FREQUENCY ALERT: {count} {level.value} logs in the last hour"
        
        # Create alert log entry directly without triggering check_alerts again
        timestamp = datetime.now()
        alert_entry = LogEntry(
            timestamp=timestamp,
            level=LogLevel.CRITICAL,
            category=LogCategory.SYSTEM,
            action="HIGH_FREQUENCY_ALERT",
            user_id=None,
            details={'level': level.value, 'count': count}
        )
        
        # Add to recent logs and write to file/database without calling self.log()
        self.recent_logs.append(alert_entry)
        self.write_to_file(alert_entry)
        self.write_to_python_logger(alert_entry)
        
        # Save to database if available
        try:
            if hasattr(self, 'database') and self.database:
                self.database.log_entry(alert_entry)
        except Exception:
            # Database not available or error, skip
            pass
        
        # In a production environment, you might want to:
        # - Send email notifications
        # - Post to Slack/Discord
        # - Send SMS alerts
        # - Trigger automated responses
        print(f"🚨 ALERT: {alert_message}")
    
    # Convenience methods for different log levels and categories
    
    def debug(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log debug message"""
        self.log(LogLevel.DEBUG, LogCategory.SYSTEM, action, user_id, kwargs)
    
    def info(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log info message"""
        self.log(LogLevel.INFO, LogCategory.SYSTEM, action, user_id, kwargs)
    
    def warning(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log warning message"""
        self.log(LogLevel.WARNING, LogCategory.SYSTEM, action, user_id, kwargs)
    
    def error(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log error message"""
        self.log(LogLevel.ERROR, LogCategory.ERROR, action, user_id, kwargs)
    
    def critical(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log critical message"""
        self.log(LogLevel.CRITICAL, LogCategory.ERROR, action, user_id, kwargs)
    
    def security_event(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log security event"""
        self.log(LogLevel.WARNING, LogCategory.SECURITY, action, user_id, kwargs)
    
    def transaction_event(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log transaction event"""
        self.log(LogLevel.INFO, LogCategory.TRANSACTION, action, user_id, kwargs)
    
    def user_action(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log user action"""
        self.log(LogLevel.INFO, LogCategory.USER_ACTION, action, user_id, kwargs)
    
    def admin_action(self, action: str, user_id: Optional[int] = None, **kwargs):
        """Log admin action"""
        self.log(LogLevel.INFO, LogCategory.ADMIN_ACTION, action, user_id, kwargs)
    
    def performance_metric(self, action: str, duration: float, **kwargs):
        """Log performance metric"""
        kwargs['duration_ms'] = duration * 1000
        self.log(LogLevel.DEBUG, LogCategory.PERFORMANCE, action, details=kwargs)
        
        # Store for analysis
        self.performance_metrics['response_times'].append(duration)
        if len(self.performance_metrics['response_times']) > 1000:
            self.performance_metrics['response_times'].pop(0)
    
    def get_recent_logs(self, limit: int = 100, level: Optional[LogLevel] = None, 
                       category: Optional[LogCategory] = None) -> List[LogEntry]:
        """Get recent logs with optional filtering"""
        logs = self.recent_logs[-limit:]
        
        if level:
            logs = [log for log in logs if log.level == level]
        
        if category:
            logs = [log for log in logs if log.category == category]
        
        return logs
    
    def get_statistics(self, days: int = 7) -> Dict[str, Any]:
        """Get logging statistics"""
        # Performance metrics
        response_times = self.performance_metrics['response_times']
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        stats = {
            'total_logs': self.stats['total_logs'],
            'logs_by_level': self.stats['logs_by_level'].copy(),
            'logs_by_category': self.stats['logs_by_category'].copy(),
            'performance': {
                'avg_response_time_ms': avg_response_time * 1000,
                'active_users_count': len(self.performance_metrics['active_users']),
                'transaction_volume': self.performance_metrics['transaction_volume']
            }
        }
        
        # Daily stats for requested period
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=days-1)
        
        daily_stats = {}
        current_date = start_date
        while current_date <= end_date:
            date_key = current_date.isoformat()
            daily_stats[date_key] = self.stats['daily_stats'].get(date_key, {
                'total': 0,
                'levels': {level.value: 0 for level in LogLevel},
                'categories': {cat.value: 0 for cat in LogCategory}
            })
            current_date += timedelta(days=1)
        
        stats['daily_stats'] = daily_stats
        return stats
    
    def format_logs_for_admin(self, logs: List[LogEntry]) -> str:
        """Format logs for admin panel display"""
        if not logs:
            return "📋 هیچ لاگی پیدا نشد."
        
        message = "📋 لاگ‌های اخیر:\n\n"
        
        for log in logs[-20:]:  # Show last 20 logs
            level_emoji = {
                LogLevel.DEBUG: "🔍",
                LogLevel.INFO: "ℹ️",
                LogLevel.WARNING: "⚠️",
                LogLevel.ERROR: "❌",
                LogLevel.CRITICAL: "🚨"
            }
            
            category_emoji = {
                LogCategory.SECURITY: "🛡️",
                LogCategory.TRANSACTION: "💰",
                LogCategory.USER_ACTION: "👤",
                LogCategory.ADMIN_ACTION: "👑",
                LogCategory.SYSTEM: "⚙️",
                LogCategory.ERROR: "🐛",
                LogCategory.PERFORMANCE: "📊"
            }
            
            time_str = log.timestamp.strftime("%H:%M:%S")
            level_icon = level_emoji.get(log.level, "📝")
            category_icon = category_emoji.get(log.category, "📋")
            
            user_info = f" (User: {log.user_id})" if log.user_id else ""
            
            message += f"`{time_str}` {level_icon}{category_icon} {log.action}{user_info}\n"
        
        return message
    
    def cleanup_old_logs(self, days_to_keep: int = 30):
        """Clean up old log files"""
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        for log_file in self.log_dir.glob("*.json"):
            try:
                file_date = datetime.strptime(log_file.stem, "%Y-%m-%d").date()
                if file_date < cutoff_date.date():
                    log_file.unlink()
                    self.info("OLD_LOG_DELETED", details={'file': str(log_file)})
            except ValueError:
                # Skip files that don't match the date format
                continue
        
        # Clean up daily stats
        for date_key in list(self.stats['daily_stats'].keys()):
            try:
                log_date = datetime.strptime(date_key, "%Y-%m-%d").date()
                if log_date < cutoff_date.date():
                    del self.stats['daily_stats'][date_key]
            except ValueError:
                continue

class PerformanceMonitor:
    """Performance monitoring utilities"""
    
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        self.active_operations: Dict[str, datetime] = {}
    
    def start_operation(self, operation_id: str):
        """Start timing an operation"""
        self.active_operations[operation_id] = datetime.now()
    
    def end_operation(self, operation_id: str, action: str, user_id: Optional[int] = None, **kwargs):
        """End timing an operation and log performance"""
        if operation_id in self.active_operations:
            start_time = self.active_operations.pop(operation_id)
            duration = (datetime.now() - start_time).total_seconds()
            
            self.logger.performance_metric(action, duration, user_id=user_id, **kwargs)
            
            # Alert for slow operations (> 5 seconds)
            if duration > 5:
                self.logger.warning(
                    "SLOW_OPERATION",
                    user_id=user_id,
                    operation=action,
                    duration_seconds=duration
                )
    
    def track_user_activity(self, user_id: int):
        """Track active user"""
        self.logger.performance_metrics['active_users'].add(user_id)
    
    def record_transaction_volume(self, amount: int):
        """Record transaction volume"""
        self.logger.performance_metrics['transaction_volume'] += amount

# Global logger instance
logger = AdvancedLogger()
performance_monitor = PerformanceMonitor(logger)
