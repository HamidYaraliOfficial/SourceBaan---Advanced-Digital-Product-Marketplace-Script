# -*- coding: utf-8 -*-
"""
Glass-style UI Components for Advanced Intermediary Bot
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from typing import List, Optional, Dict, Any
from config import Config

class GlassUI:
    """Modern glass-style UI component generator"""
    
    @staticmethod
    def main_menu() -> InlineKeyboardMarkup:
        """Main menu for pure intermediary bot"""
        keyboard = [
            [
                InlineKeyboardButton("🤝 درخواست واسطه‌گری", callback_data="request_intermediary")
            ],
            [
                InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_intermediary_requests"),
                InlineKeyboardButton("📊 معاملات من", callback_data="my_transactions")
            ],
            [
                InlineKeyboardButton("👥 ساخت گروه معامله", callback_data="create_group"),
                InlineKeyboardButton("🔗 پیوستن به گروه", callback_data="join_group")
            ],
            [
                InlineKeyboardButton("⭐ نظرات و امتیازات", callback_data="ratings_reviews"),
                InlineKeyboardButton("👤 پروفایل من", callback_data="my_profile")
            ],
            [
                InlineKeyboardButton("📞 پشتیبانی", callback_data="support"),
                InlineKeyboardButton("📖 راهنمای واسطه‌گری", callback_data="help")
            ],
            [
                InlineKeyboardButton("📈 آمار ربات", callback_data="bot_stats")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def admin_menu(is_main_admin: bool = False) -> InlineKeyboardMarkup:
        """Admin panel with advanced controls"""
        keyboard = [
            [
                InlineKeyboardButton("👥 مدیریت کاربران", callback_data="admin_users"),
                InlineKeyboardButton("💼 مدیریت معاملات", callback_data="admin_transactions")
            ],
            [
                InlineKeyboardButton("📊 آمار کامل", callback_data="admin_stats"),
                InlineKeyboardButton("📋 گزارشات", callback_data="admin_reports")
            ],
            [
                InlineKeyboardButton("🔔 اعلانات", callback_data="admin_broadcast"),
                InlineKeyboardButton("⚙️ تنظیمات ربات", callback_data="admin_settings")
            ]
        ]
        
        if is_main_admin:
            keyboard.append([
                InlineKeyboardButton("👑 مدیریت ادمین‌ها", callback_data="admin_manage_admins"),
                InlineKeyboardButton("🤝 مدیریت واسطه‌گران", callback_data="admin_manage_mediators")
            ])
            keyboard.append([
                InlineKeyboardButton("🔧 تنظیمات پیشرفته", callback_data="admin_advanced")
            ])
        
        keyboard.append([
            InlineKeyboardButton("🔙 بازگشت به منوی اصلی", callback_data="main_menu")
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def mediator_menu() -> InlineKeyboardMarkup:
        """Mediator panel with specialized controls"""
        keyboard = [
            [
                InlineKeyboardButton("📋 درخواست‌های جدید", callback_data="new_mediation_requests"),
                InlineKeyboardButton("🔄 درخواست‌های فعال", callback_data="active_mediation_requests")
            ],
            [
                InlineKeyboardButton("✅ درخواست‌های حل شده", callback_data="resolved_mediation_requests"),
                InlineKeyboardButton("📊 آمار عملکرد", callback_data="mediator_performance")
            ],
            [
                InlineKeyboardButton("⚙️ تنظیمات واسطه‌گری", callback_data="mediator_settings"),
                InlineKeyboardButton("📖 راهنمای واسطه‌گری", callback_data="mediator_guide")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت به منوی اصلی", callback_data="main_menu")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def transaction_menu(transaction_id: str, user_role: str) -> InlineKeyboardMarkup:
        """Transaction management menu"""
        keyboard = []
        
        if user_role == "seller":
            keyboard.extend([
                [InlineKeyboardButton("✅ تایید فروش", callback_data=f"confirm_sale_{transaction_id}")],
                [InlineKeyboardButton("📦 ارسال شد", callback_data=f"mark_sent_{transaction_id}")],
                [InlineKeyboardButton("❌ لغو معامله", callback_data=f"cancel_transaction_{transaction_id}")]
            ])
        elif user_role == "buyer":
            keyboard.extend([
                [InlineKeyboardButton("💳 پرداخت انجام شد", callback_data=f"confirm_payment_{transaction_id}")],
                [InlineKeyboardButton("📬 دریافت شد", callback_data=f"confirm_received_{transaction_id}")],
                [InlineKeyboardButton("❌ لغو معامله", callback_data=f"cancel_transaction_{transaction_id}")]
            ])
        
        keyboard.extend([
            [InlineKeyboardButton("📞 تماس با پشتیبانی", callback_data=f"support_{transaction_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="my_transactions")]
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def transaction_status_menu() -> InlineKeyboardMarkup:
        """Filter transactions by status"""
        keyboard = [
            [
                InlineKeyboardButton("🟡 در انتظار", callback_data="filter_pending"),
                InlineKeyboardButton("🔵 در حال انجام", callback_data="filter_active")
            ],
            [
                InlineKeyboardButton("🟢 تکمیل شده", callback_data="filter_completed"),
                InlineKeyboardButton("🔴 لغو شده", callback_data="filter_cancelled")
            ],
            [
                InlineKeyboardButton("📋 همه معاملات", callback_data="filter_all"),
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def confirmation_menu(action: str, item_id: str) -> InlineKeyboardMarkup:
        """Confirmation dialog"""
        keyboard = [
            [
                InlineKeyboardButton("✅ تایید", callback_data=f"confirm_{action}_{item_id}"),
                InlineKeyboardButton("❌ انصراف", callback_data=f"cancel_{action}_{item_id}")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def pagination_menu(current_page: int, total_pages: int, prefix: str) -> InlineKeyboardMarkup:
        """Pagination controls"""
        keyboard = []
        
        nav_buttons = []
        if current_page > 1:
            nav_buttons.append(InlineKeyboardButton("⬅️", callback_data=f"{prefix}_page_{current_page-1}"))
        
        nav_buttons.append(InlineKeyboardButton(f"{current_page}/{total_pages}", callback_data="noop"))
        
        if current_page < total_pages:
            nav_buttons.append(InlineKeyboardButton("➡️", callback_data=f"{prefix}_page_{current_page+1}"))
        
        keyboard.append(nav_buttons)
        keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def back_button(callback_data: str = "main_menu") -> InlineKeyboardMarkup:
        """Simple back button"""
        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data=callback_data)]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def contact_keyboard() -> ReplyKeyboardMarkup:
        """Contact sharing keyboard"""
        keyboard = [[KeyboardButton("📱 اشتراک‌گذاری شماره تماس", request_contact=True)]]
        return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

class MessageFormatter:
    """Advanced message formatting with glass-style design"""
    
    @staticmethod
    def format_transaction_details(transaction: Any, user_role: str) -> str:
        """Format transaction details with beautiful design"""
        status_emoji = {
            "pending": "🟡",
            "seller_confirmed": "🔵", 
            "buyer_paid": "🟠",
            "completed": "🟢",
            "cancelled": "🔴",
            "disputed": "⚠️"
        }
        
        role_text = "فروشنده" if user_role == "seller" else "خریدار"
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    🔮 جزئیات معامله                     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 شناسه معامله: `{transaction.transaction_id}`
📝 عنوان: {transaction.title}
📋 توضیحات: {transaction.description}

💰 مبلغ: {transaction.amount:,} تومان
💳 کارمزد: {transaction.commission:,} تومان
💎 مبلغ نهایی: {transaction.amount + transaction.commission:,} تومان

{status_emoji.get(transaction.status.value, '🔘')} وضعیت: {transaction.status.value}
👤 نقش شما: {role_text}

📅 تاریخ ایجاد: {transaction.created_at.strftime('%Y/%m/%d - %H:%M')}
⏰ انقضا: {transaction.expires_at.strftime('%Y/%m/%d - %H:%M')}

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
"""
        return message
    
    @staticmethod
    def format_user_profile(user: Any, stats: Dict[str, Any]) -> str:
        """Format user profile with statistics"""
        role_emoji = {
            "user": "👤",
            "sub_admin": "👨‍💼", 
            "main_admin": "👑"
        }
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                     👤 پروفایل کاربری                    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

{role_emoji.get(user.role.value, '👤')} نام: {user.first_name} {user.last_name or ''}
📱 نام کاربری: @{user.username or 'تعین نشده'}
🆔 شناسه: `{user.user_id}`

📊 آمار معاملات:
┌─────────────────────────────────────────────────────────┐
│ 🔢 تعداد کل معاملات: {user.total_transactions}                     │
│ ✅ نرخ موفقیت: {user.success_rate:.1f}%                          │
│ 📈 امتیاز اعتماد: {'⭐' * min(5, int(user.success_rate/20))}     │
└─────────────────────────────────────────────────────────┘

📅 تاریخ عضویت: {user.registration_date.strftime('%Y/%m/%d')}
🏷️ نقش: {user.role.value}

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
"""
        return message
    
    @staticmethod
    def format_bot_statistics(stats: Dict[str, Any]) -> str:
        """Format bot statistics"""
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    📊 آمار ربات واسطه‌گری                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👥 تعداد کاربران: {stats['total_users']:,} نفر
💼 تعداد معاملات: {stats['total_transactions']:,} مورد
✅ معاملات موفق: {stats['completed_transactions']:,} مورد
📈 نرخ موفقیت: {stats['success_rate']:.1f}%

💰 حجم معاملات: {stats['total_volume']:,} تومان
💳 درآمد کارمزد: {stats['total_commission']:,} تومان

🔮 ربات واسطه‌گری پیشرفته
🛡️ امن، سریع، قابل اعتماد

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
"""
        return message
    
    @staticmethod
    def format_admin_panel(stats: Dict[str, Any]) -> str:
        """Format admin panel header"""
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   👑 پنل مدیریت ربات                    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📊 آمار سریع:
• کاربران: {stats.get('total_users', 0):,} نفر
• معاملات امروز: {stats.get('today_transactions', 0):,} مورد  
• درآمد امروز: {stats.get('today_commission', 0):,} تومان

🎛️ لطفاً گزینه مورد نظر را انتخاب کنید:
"""
        return message
