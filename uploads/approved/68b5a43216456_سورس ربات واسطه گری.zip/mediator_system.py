# -*- coding: utf-8 -*-
"""
Advanced Mediator System for Handling Intermediary Requests
سیستم پیشرفته واسطه‌گری برای مدیریت درخواست‌های واسطه‌گری
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import uuid
import asyncio
import sqlite3

from database import Database, User, UserRole
from ui_components import GlassUI, MessageFormatter
from security import SecurityManager
from logging_system import logger
from config import Config

class MediationRequestStatus(Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    REJECTED = "rejected"
    ESCALATED = "escalated"

class MediationRequestType(Enum):
    TRANSACTION_DISPUTE = "transaction_dispute"
    PAYMENT_ISSUE = "payment_issue"
    PRODUCT_ISSUE = "product_issue"
    COMMUNICATION_ISSUE = "communication_issue"
    GENERAL_MEDIATION = "general_mediation"

@dataclass
class MediationRequest:
    request_id: str
    requester_id: int
    requester_name: str
    request_type: MediationRequestType
    title: str
    description: str
    related_transaction_id: Optional[str]
    priority: int  # 1=Low, 2=Medium, 3=High, 4=Critical
    status: MediationRequestStatus
    assigned_mediator_id: Optional[int]
    created_at: datetime
    updated_at: datetime
    amount: Optional[int] = None  # اضافه شد برای قیمت درخواست
    files: Optional[List[str]] = None  # اضافه شد برای فایل‌ها
    mediator_notes: Optional[str] = None  # اضافه شد برای یادداشت واسطه‌گر
    resolution: Optional[str] = None  # اضافه شد برای راه‌حل
    estimated_time: Optional[int] = None  # اضافه شد برای زمان تخمینی
    urgency_level: Optional[int] = None  # اضافه شد برای سطح فوریت
    resolution_notes: Optional[str] = None
    escalation_reason: Optional[str] = None

class MediatorSystem:
    """Advanced mediator system for handling user requests"""
    
    def __init__(self, database: Database, security_manager: SecurityManager):
        self.db = database
        self.security = security_manager
        
        # Active mediation requests
        self.active_requests: Dict[str, MediationRequest] = {}
        
        # Mediator workload tracking
        self.mediator_workload: Dict[int, int] = {}
        
        # Request queue by priority
        self.request_queue: List[str] = []
        
        # Auto-escalation settings
        self.escalation_timeouts = {
            1: 24,  # Low priority: 24 hours
            2: 12,  # Medium priority: 12 hours
            3: 6,   # High priority: 6 hours
            4: 2    # Critical priority: 2 hours
        }
    
    def is_mediator(self, user_id: int) -> bool:
        """Check if user is a mediator admin"""
        return user_id in Config.MEDIATOR_ADMINS
    
    def get_available_mediators(self) -> List[int]:
        """Get list of available mediators sorted by workload"""
        mediator_loads = []
        
        for mediator_id in Config.MEDIATOR_ADMINS:
            workload = self.mediator_workload.get(mediator_id, 0)
            mediator_loads.append((mediator_id, workload))
        
        # Sort by workload (ascending)
        mediator_loads.sort(key=lambda x: x[1])
        return [mediator_id for mediator_id, _ in mediator_loads]
    
    def assign_mediator(self, request_id: str) -> Optional[int]:
        """Assign mediator to request using round-robin with workload balancing"""
        available_mediators = self.get_available_mediators()
        
        if not available_mediators:
            logger.error("NO_MEDIATORS_AVAILABLE", details={'request_id': request_id})
            return None
        
        # Assign to mediator with lowest workload
        assigned_mediator = available_mediators[0]
        
        # Update workload
        self.mediator_workload[assigned_mediator] = self.mediator_workload.get(assigned_mediator, 0) + 1
        
        # Update request
        if request_id in self.active_requests:
            self.active_requests[request_id].assigned_mediator_id = assigned_mediator
            self.active_requests[request_id].status = MediationRequestStatus.ASSIGNED
            self.active_requests[request_id].updated_at = datetime.now()
        
        logger.info("MEDIATOR_ASSIGNED", details={
            'request_id': request_id,
            'mediator_id': assigned_mediator,
            'workload': self.mediator_workload[assigned_mediator]
        })
        
        return assigned_mediator
    
    async def create_mediation_request(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Create new mediation request"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Show request type selection
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                🤝 درخواست واسطه‌گری جدید               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👋 سلام {user.first_name}!

🎯 لطفاً نوع مشکل خود را انتخاب کنید:

💡 تیم واسطه‌گری ما آماده کمک به شماست:
""".format(user=user)
        
        keyboard = [
            [
                InlineKeyboardButton("💰 مشکل معامله", callback_data="mediation_type_transaction_dispute"),
                InlineKeyboardButton("💳 مشکل پرداخت", callback_data="mediation_type_payment_issue")
            ],
            [
                InlineKeyboardButton("📦 مشکل محصول", callback_data="mediation_type_product_issue"),
                InlineKeyboardButton("💬 مشکل ارتباطی", callback_data="mediation_type_communication_issue")
            ],
            [
                InlineKeyboardButton("🤝 واسطه‌گری عمومی", callback_data="mediation_type_general_mediation")
            ],
            [
                InlineKeyboardButton("❌ لغو", callback_data="main_menu")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        # Set state for collecting request details
        context.user_data['mediation_request'] = {
            'step': 'select_type',
            'requester_id': user_id,
            'requester_name': f"{user.first_name} {user.last_name or ''}".strip()
        }
    
    async def handle_request_type_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle request type selection"""
        query = update.callback_query
        data = query.data
        
        type_map = {
            'mediation_type_transaction_dispute': MediationRequestType.TRANSACTION_DISPUTE,
            'mediation_type_payment_issue': MediationRequestType.PAYMENT_ISSUE,
            'mediation_type_product_issue': MediationRequestType.PRODUCT_ISSUE,
            'mediation_type_communication_issue': MediationRequestType.COMMUNICATION_ISSUE,
            'mediation_type_general_mediation': MediationRequestType.GENERAL_MEDIATION
        }
        
        if data not in type_map:
            return
        
        request_type = type_map[data]
        context.user_data['mediation_request']['type'] = request_type
        
        # Show title input
        type_names = {
            MediationRequestType.TRANSACTION_DISPUTE: "مشکل معامله",
            MediationRequestType.PAYMENT_ISSUE: "مشکل پرداخت",
            MediationRequestType.PRODUCT_ISSUE: "مشکل محصول",
            MediationRequestType.COMMUNICATION_ISSUE: "مشکل ارتباطی",
            MediationRequestType.GENERAL_MEDIATION: "واسطه‌گری عمومی"
        }
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              🤝 درخواست واسطه‌گری - مرحله 1/3           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📋 نوع انتخابی: {type_names[request_type]}

✏️ لطفاً عنوان کوتاه و مفهومی برای درخواست خود وارد کنید:

💡 مثال‌های خوب:
• "عدم تحویل کالا پس از پرداخت"
• "مشکل در کیفیت محصول دریافتی"
• "عدم پاسخگویی فروشنده"

📝 حداکثر 100 کاراکتر
"""
        
        keyboard = [[InlineKeyboardButton("❌ لغو", callback_data="main_menu")]]
        
        await query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        context.user_data['mediation_request']['step'] = 'title'
    
    async def handle_title_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle title input"""
        title = update.message.text
        
        # Validate title
        if not title or len(title.strip()) < 5:
            await update.message.reply_text("❌ عنوان باید حداقل 5 کاراکتر باشد. لطفاً مجدداً وارد کنید:")
            return
        
        if len(title) > 100:
            await update.message.reply_text("❌ عنوان نباید بیش از 100 کاراکتر باشد. لطفاً مجدداً وارد کنید:")
            return
        
        context.user_data['mediation_request']['title'] = title.strip()
        
        # Ask for description
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              🤝 درخواست واسطه‌گری - مرحله 2/3           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📝 لطفاً شرح کاملی از مشکل خود ارائه دهید:

💡 اطلاعات مفید:
• چه اتفاقی افتاده است؟
• چه انتظاری داشتید؟
• چه اقداماتی انجام داده‌اید؟
• شناسه معامله (در صورت وجود)

📋 حداکثر 1000 کاراکتر
✏️ هرچه دقیق‌تر توضیح دهید، سریع‌تر کمک خواهیم کرد.
"""
        
        await update.message.reply_text(message, parse_mode='Markdown')
        context.user_data['mediation_request']['step'] = 'description'
    
    async def handle_description_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle description input"""
        description = update.message.text
        
        # Validate description
        if not description or len(description.strip()) < 20:
            await update.message.reply_text("❌ توضیحات باید حداقل 20 کاراکتر باشد. لطفاً دقیق‌تر توضیح دهید:")
            return
        
        if len(description) > 1000:
            await update.message.reply_text("❌ توضیحات نباید بیش از 1000 کاراکتر باشد. لطفاً خلاصه‌تر بنویسید:")
            return
        
        context.user_data['mediation_request']['description'] = description.strip()
        
        # Show priority selection
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              🤝 درخواست واسطه‌گری - مرحله 3/3           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

⚡ اولویت درخواست خود را مشخص کنید:

🔴 فوری (2 ساعت): مسائل حساس و ضروری
🟠 بالا (6 ساعت): مسائل مهم نیاز به رسیدگی سریع
🟡 متوسط (12 ساعت): مسائل عادی
🟢 کم (24 ساعت): مسائل غیر ضروری

💡 لطفاً بر اساس واقعیت اولویت انتخاب کنید.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🔴 فوری", callback_data="priority_4"),
                InlineKeyboardButton("🟠 بالا", callback_data="priority_3")
            ],
            [
                InlineKeyboardButton("🟡 متوسط", callback_data="priority_2"),
                InlineKeyboardButton("🟢 کم", callback_data="priority_1")
            ],
            [
                InlineKeyboardButton("❌ لغو", callback_data="main_menu")
            ]
        ]
        
        await update.message.reply_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        context.user_data['mediation_request']['step'] = 'priority'
    
    async def handle_priority_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle priority selection and create request"""
        query = update.callback_query
        data = query.data
        
        if not data.startswith('priority_'):
            return
        
        priority = int(data.replace('priority_', ''))
        request_data = context.user_data.get('mediation_request', {})
        
        # Create mediation request
        request_id = f"MED_{int(datetime.now().timestamp())}_{uuid.uuid4().hex[:8]}".upper()
        
        mediation_request = MediationRequest(
            request_id=request_id,
            requester_id=request_data['requester_id'],
            requester_name=request_data['requester_name'],
            request_type=request_data['type'],
            title=request_data['title'],
            description=request_data['description'],
            related_transaction_id=None,  # Can be added later
            priority=priority,
            status=MediationRequestStatus.PENDING,
            assigned_mediator_id=None,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        # Store request in memory and database
        self.active_requests[request_id] = mediation_request
        
        # Save to database
        self._save_mediation_request_to_db(mediation_request)
        
        # Add to queue
        self.request_queue.append(request_id)
        self.request_queue.sort(key=lambda rid: self.active_requests[rid].priority, reverse=True)
        
        # Try to assign mediator
        assigned_mediator = self.assign_mediator(request_id)
        
        # Send confirmation to user
        priority_names = {1: "کم", 2: "متوسط", 3: "بالا", 4: "فوری"}
        priority_emojis = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}
        
        confirmation_message = f"""
✅ درخواست واسطه‌گری شما با موفقیت ثبت شد!

🆔 شناسه درخواست: `{request_id}`
📋 عنوان: {mediation_request.title}
{priority_emojis[priority]} اولویت: {priority_names[priority]}

⏰ زمان پاسخ مورد انتظار: {self.escalation_timeouts[priority]} ساعت

🔔 وضعیت فعلی:
{'✅ به واسطه‌گر اختصاص یافت' if assigned_mediator else '⏳ در صف انتظار'}

📱 اطلاع‌رسانی:
• از طریق همین ربات مطلع خواهید شد
• امکان پیگیری درخواست در هر زمان

🆘 در صورت ضرورت: /support
"""
        
        keyboard = [
            [InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediation_requests")],
            [InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")]
        ]
        
        await query.edit_message_text(
            confirmation_message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Notify assigned mediator
        if assigned_mediator:
            await self.notify_mediator_new_request(context, assigned_mediator, mediation_request)
        
        # Log the request
        logger.info("MEDIATION_REQUEST_CREATED", 
                   user_id=mediation_request.requester_id,
                   request_id=request_id,
                   priority=priority,
                   assigned_mediator=assigned_mediator)
        
        # Clear user data
        context.user_data.pop('mediation_request', None)
    
    async def notify_mediator_new_request(self, context: ContextTypes.DEFAULT_TYPE, 
                                        mediator_id: int, request: MediationRequest):
        """Notify mediator about new request"""
        try:
            priority_emojis = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}
            priority_names = {1: "کم", 2: "متوسط", 3: "بالا", 4: "فوری"}
            
            type_names = {
                MediationRequestType.TRANSACTION_DISPUTE: "مشکل معامله",
                MediationRequestType.PAYMENT_ISSUE: "مشکل پرداخت",
                MediationRequestType.PRODUCT_ISSUE: "مشکل محصول",
                MediationRequestType.COMMUNICATION_ISSUE: "مشکل ارتباطی",
                MediationRequestType.GENERAL_MEDIATION: "واسطه‌گری عمومی"
            }
            
            message = f"""
🚨 درخواست واسطه‌گری جدید!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 🤝 مأموریت واسطه‌گری جدید               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 شناسه: `{request.request_id}`
👤 درخواست‌کننده: {request.requester_name}
📋 نوع: {type_names[request.request_type]}
📝 عنوان: {request.title}

{priority_emojis[request.priority]} اولویت: {priority_names[request.priority]}
⏰ مهلت پاسخ: {self.escalation_timeouts[request.priority]} ساعت
📅 زمان ثبت: {request.created_at.strftime('%Y/%m/%d - %H:%M')}

📄 توضیحات:
{request.description[:200]}{'...' if len(request.description) > 200 else ''}

🎯 این درخواست به شما اختصاص یافته است.
"""
            
            keyboard = [
                [
                    InlineKeyboardButton("✅ قبول درخواست", callback_data=f"accept_mediation_{request.request_id}"),
                    InlineKeyboardButton("❌ رد درخواست", callback_data=f"reject_mediation_{request.request_id}")
                ],
                [
                    InlineKeyboardButton("👥 انتخاب کاربر برای چت", callback_data=f"contact_requester_{request.request_id}"),
                    InlineKeyboardButton("📋 جزئیات کامل", callback_data=f"mediation_details_{request.request_id}")
                ],
                [
                    InlineKeyboardButton("🔄 انتقال به دیگری", callback_data=f"transfer_mediation_{request.request_id}")
                ]
            ]
            
            await context.bot.send_message(
                chat_id=mediator_id,
                text=message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
            
            logger.info("MEDIATOR_NOTIFIED", 
                       mediator_id=mediator_id,
                       request_id=request.request_id)
            
        except Exception as e:
            logger.error("MEDIATOR_NOTIFICATION_FAILED", 
                        mediator_id=mediator_id,
                        request_id=request.request_id,
                        error=str(e))
    
    async def show_mediator_dashboard(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show mediator dashboard"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        # Get mediator's active requests
        active_requests = [
            req for req in self.active_requests.values() 
            if req.assigned_mediator_id == user_id and req.status in [
                MediationRequestStatus.ASSIGNED, 
                MediationRequestStatus.IN_PROGRESS
            ]
        ]
        
        pending_requests = [
            req for req in self.active_requests.values() 
            if req.status == MediationRequestStatus.PENDING
        ]
        
        # Get total intermediary requests (both assigned and unassigned)
        intermediary_requests = [
            req for req in self.active_requests.values()
            if hasattr(req, 'request_type') and str(req.request_type) == 'MediationRequestType.GENERAL_MEDIATION'
        ]
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  🤝 داشبورد واسطه‌گری                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👋 سلام واسطه‌گر محترم!

📊 آمار کلی:
• درخواست‌های فعال شما: {len(active_requests)}
• درخواست‌های در انتظار: {len(pending_requests)}
• درخواست‌های واسطه‌گری: {len(intermediary_requests)}
• بار کاری فعلی: {self.mediator_workload.get(user_id, 0)}

🔥 درخواست‌های با اولویت بالا:
{self._format_high_priority_requests(active_requests + pending_requests)}

💼 وضعیت درخواست‌های شما:
{self._format_mediator_requests(active_requests)}

🎯 آماده خدمت‌رسانی به کاربران عزیز!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediations"),
                InlineKeyboardButton("🆕 درخواست‌های جدید", callback_data="new_mediations")
            ],
            [
                InlineKeyboardButton("🤝 واسطه‌گری", callback_data="intermediary_requests"),
                InlineKeyboardButton("📊 آمار عملکرد", callback_data="mediator_stats")
            ],
            [
                InlineKeyboardButton("⚙️ تنظیمات واسطه‌گری", callback_data="mediator_settings"),
                InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")
            ]
        ]
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
    
    def _format_high_priority_requests(self, requests: List[MediationRequest]) -> str:
        """Format high priority requests"""
        high_priority = [req for req in requests if req.priority >= 3]
        
        if not high_priority:
            return "✅ هیچ درخواست فوری ندارید"
        
        result = ""
        for req in high_priority[:3]:  # Show top 3
            priority_emoji = "🔴" if req.priority == 4 else "🟠"
            result += f"{priority_emoji} {req.title[:30]}...\n"
        
        if len(high_priority) > 3:
            result += f"... و {len(high_priority) - 3} درخواست دیگر"
        
        return result
    
    async def show_intermediary_requests(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show intermediary requests for mediator"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        # Get all intermediary requests
        intermediary_requests = [
            req for req in self.active_requests.values()
            if hasattr(req, 'request_type') and str(req.request_type) == 'MediationRequestType.GENERAL_MEDIATION'
        ]
        
        if not intermediary_requests:
            message = """
🤝 درخواست‌های واسطه‌گری

📭 هیچ درخواست واسطه‌گری فعالی وجود ندارد.

💡 درخواست‌های واسطه‌گری زمانی که کاربران:
• گروه معامله می‌سازند
• پس از پیوستن طرف مقابل
• درخواست واسطه‌گری می‌دهند

به این بخش اضافه می‌شوند.

🔄 لطفاً بعداً مراجعه کنید.
"""
        else:
            message = f"""
🤝 درخواست‌های واسطه‌گری

📊 آمار:
• کل درخواست‌ها: {len(intermediary_requests)}
• در انتظار تایید: {len([r for r in intermediary_requests if r.status == MediationRequestStatus.PENDING])}
• در حال انجام: {len([r for r in intermediary_requests if r.status == MediationRequestStatus.IN_PROGRESS])}

📋 لیست درخواست‌ها:
"""
            
            status_emojis = {
                MediationRequestStatus.PENDING: '⏳',
                MediationRequestStatus.ASSIGNED: '✅',
                MediationRequestStatus.IN_PROGRESS: '🔄',
                MediationRequestStatus.RESOLVED: '🟢',
                MediationRequestStatus.REJECTED: '🔴'
            }
            
            for req in intermediary_requests[:10]:  # Show max 10
                emoji = status_emojis.get(req.status, '⚪')
                amount = getattr(req, 'amount', 0)
                message += f"\n{emoji} {req.title[:30]}... - {amount:,} تومان"
                message += f"\n   📝 {req.requester_name} - {req.created_at.strftime('%m/%d %H:%M')}"
        
        keyboard = [
            [
                InlineKeyboardButton("🔄 بروزرسانی", callback_data="intermediary_requests"),
                InlineKeyboardButton("📋 جزئیات", callback_data="intermediary_details")
            ],
            [InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    def _format_mediator_requests(self, requests: List[MediationRequest]) -> str:
        """Format mediator's requests"""
        if not requests:
            return "📭 درخواست فعالی ندارید"
        
        result = ""
        for req in requests[:5]:  # Show top 5
            status_emoji = "🔵" if req.status == MediationRequestStatus.ASSIGNED else "🟡"
            result += f"{status_emoji} {req.title[:25]}...\n"
        
        if len(requests) > 5:
            result += f"... و {len(requests) - 5} درخواست دیگر"
        
        return result
    
    async def handle_mediator_callbacks(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle mediator system callbacks"""
        query = update.callback_query
        data = query.data
        user_id = update.effective_user.id
        
        if data == "request_mediation":
            await self.create_mediation_request(update, context)
        elif data == "mediator_dashboard":
            await self.show_mediator_dashboard(update, context)
        elif data.startswith("mediation_type_"):
            await self.handle_request_type_selection(update, context)
        elif data.startswith("priority_"):
            await self.handle_priority_selection(update, context)
        elif data.startswith("accept_mediation_"):
            request_id = data.replace("accept_mediation_", "")
            await self.accept_mediation(update, context, request_id)
        elif data.startswith("reject_mediation_"):
            request_id = data.replace("reject_mediation_", "")
            await self.reject_mediation(update, context, request_id)
        elif data == "my_mediations":
            await self.show_my_mediations(update, context)
        elif data == "new_mediations":
            await self.show_new_mediations(update, context)
        elif data == "mediator_stats":
            await self.show_mediator_stats(update, context)
        elif data == "mediator_settings":
            await self.show_mediator_settings(update, context)
        elif data == "my_mediation_requests":
            await self.show_user_mediation_requests(update, context)
        elif data == "intermediary_requests":
            await self.show_intermediary_requests(update, context)
        elif data.startswith("mediation_details_"):
            request_id = data.replace("mediation_details_", "")
            await self.show_mediation_details(update, context, request_id)
        elif data.startswith("contact_requester_"):
            request_id = data.replace("contact_requester_", "")
            await self.contact_requester(update, context, request_id)
        elif data.startswith("transfer_mediation_"):
            request_id = data.replace("transfer_mediation_", "")
            await self.transfer_mediation(update, context, request_id)
        elif data.startswith("resolve_mediation_"):
            request_id = data.replace("resolve_mediation_", "")
            await self.resolve_mediation(update, context, request_id)
        elif data.startswith("escalate_mediation_"):
            request_id = data.replace("escalate_mediation_", "")
            await self.escalate_mediation(update, context, request_id)
        elif data.startswith("mediation_status_"):
            request_id = data.replace("mediation_status_", "")
            await self.show_mediation_status(update, context, request_id)
        elif data.startswith("message_user_"):
            user_id_to_message = int(data.replace("message_user_", ""))
            await self.start_user_conversation(update, context, user_id_to_message)
        elif data.startswith("user_contact_"):
            user_id_to_contact = int(data.replace("user_contact_", ""))
            await self.show_user_contact_info(update, context, user_id_to_contact)
        elif data == "intermediary_details":
            await self.show_intermediary_details(update, context)
        elif data.startswith("intermediary_detail_"):
            request_id = data.replace("intermediary_detail_", "")
            await self.show_intermediary_request_details(update, context, request_id)
        elif data.startswith("contact_buyer_"):
            request_id = data.replace("contact_buyer_", "")
            await self.contact_intermediary_buyer(update, context, request_id)
        elif data.startswith("choose_contact_user_"):
            request_id = data.replace("choose_contact_user_", "")
            await self.show_user_selection_menu(update, context, request_id)
        elif data.startswith("contact_seller_"):
            request_id = data.replace("contact_seller_", "")
            await self.contact_intermediary_seller(update, context, request_id)
    
    async def accept_mediation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Accept mediation request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ دسترسی محدود!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        if request.assigned_mediator_id != user_id:
            await update.callback_query.answer("❌ این درخواست به شما اختصاص نیافته!", show_alert=True)
            return
        
        # Update request status
        request.status = MediationRequestStatus.IN_PROGRESS
        request.updated_at = datetime.now()
        
        # Update in database
        self._update_mediation_request_in_db(request)
        
        # Notify user
        await self.notify_user_mediation_accepted(context, request)
        
        # Update mediator message
        message = f"""
✅ درخواست واسطه‌گری پذیرفته شد!

🆔 شناسه: `{request_id}`
👤 کاربر: {request.requester_name}
📝 عنوان: {request.title}

🎯 حالا می‌توانید با کاربر در ارتباط باشید و مشکل را حل کنید.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 پیام به کاربر", callback_data=f"message_user_{request.requester_id}"),
                InlineKeyboardButton("📞 اطلاعات تماس", callback_data=f"user_contact_{request.requester_id}")
            ],
            [
                InlineKeyboardButton("✅ حل شد", callback_data=f"resolve_mediation_{request_id}"),
                InlineKeyboardButton("⬆️ ارجاع به بالادست", callback_data=f"escalate_mediation_{request_id}")
            ],
            [
                InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        logger.info("MEDIATION_ACCEPTED", 
                   mediator_id=user_id,
                   request_id=request_id)
    
    async def reject_mediation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Reject mediation request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ دسترسی محدود!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        # Reduce mediator workload
        self.mediator_workload[user_id] = max(0, self.mediator_workload.get(user_id, 0) - 1)
        
        # Try to reassign to another mediator
        new_mediator = self.assign_mediator(request_id)
        
        if new_mediator:
            await self.notify_mediator_new_request(context, new_mediator, request)
            message = "✅ درخواست به واسطه‌گر دیگری منتقل شد."
        else:
            request.status = MediationRequestStatus.PENDING
            message = "⚠️ درخواست به صف انتظار بازگشت."
        
        await update.callback_query.edit_message_text(message)
        
        logger.info("MEDIATION_REJECTED", 
                   mediator_id=user_id,
                   request_id=request_id,
                   new_mediator=new_mediator)
    
    async def notify_user_mediation_accepted(self, context: ContextTypes.DEFAULT_TYPE, request: MediationRequest):
        """Notify user that their mediation request was accepted"""
        try:
            message = f"""
🎉 درخواست واسطه‌گری شما پذیرفته شد!

🆔 شناسه: `{request.request_id}`
📝 عنوان: {request.title}

🤝 واسطه‌گر اختصاص یافته و به زودی با شما تماس خواهد گرفت.

📱 لطفاً منتظر پیام واسطه‌گر باشید و همکاری لازم را داشته باشید.

🕐 زمان پاسخ: معمولاً کمتر از 30 دقیقه
"""
            
            keyboard = [
                [InlineKeyboardButton("📋 وضعیت درخواست", callback_data=f"mediation_status_{request.request_id}")],
                [InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")]
            ]
            
            await context.bot.send_message(
                chat_id=request.requester_id,
                text=message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
            
        except Exception as e:
            logger.error("USER_NOTIFICATION_FAILED", 
                        user_id=request.requester_id,
                        request_id=request.request_id,
                        error=str(e))
    
    async def show_my_mediations(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show mediator's assigned requests"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        # Get mediator's requests
        my_requests = [
            req for req in self.active_requests.values()
            if req.assigned_mediator_id == user_id
        ]
        
        if not my_requests:
            message = """
📋 درخواست‌های واسطه‌گری من

📭 شما درخواست فعالی ندارید.

🎯 برای دریافت درخواست‌های جدید:
• منتظر اختصاص خودکار باشید
• یا از بخش "درخواست‌های جدید" یکی را انتخاب کنید

✨ آماده خدمت‌رسانی!
"""
        else:
            message = f"""
📋 درخواست‌های واسطه‌گری من

📊 آمار:
• کل درخواست‌ها: {len(my_requests)}
• در انتظار: {len([r for r in my_requests if r.status == MediationRequestStatus.ASSIGNED])}
• در حال پردازش: {len([r for r in my_requests if r.status == MediationRequestStatus.IN_PROGRESS])}
• حل شده: {len([r for r in my_requests if r.status == MediationRequestStatus.RESOLVED])}

📋 لیست درخواست‌ها:
"""
            
            status_emojis = {
                MediationRequestStatus.ASSIGNED: "🔵",
                MediationRequestStatus.IN_PROGRESS: "🟡", 
                MediationRequestStatus.RESOLVED: "🟢",
                MediationRequestStatus.REJECTED: "🔴"
            }
            
            for req in my_requests[:10]:  # Show top 10
                emoji = status_emojis.get(req.status, "⚪")
                priority_emoji = ["", "🟢", "🟡", "🟠", "🔴"][req.priority]
                message += f"{emoji} {priority_emoji} {req.title[:30]}...\n"
        
        keyboard = []
        
        # Add action buttons for active requests
        if my_requests:
            active_requests = [r for r in my_requests if r.status in [MediationRequestStatus.ASSIGNED, MediationRequestStatus.IN_PROGRESS]]
            for req in active_requests[:5]:  # Show top 5 active
                keyboard.append([
                    InlineKeyboardButton(f"📝 {req.title[:25]}...", callback_data=f"mediation_details_{req.request_id}")
                ])
        
        keyboard.extend([
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="my_mediations")],
            [InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")]
        ])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_new_mediations(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show new/pending mediation requests"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        # Get pending requests
        pending_requests = [
            req for req in self.active_requests.values()
            if req.status == MediationRequestStatus.PENDING
        ]
        
        # Sort by priority and creation time
        pending_requests.sort(key=lambda r: (r.priority, r.created_at), reverse=True)
        
        if not pending_requests:
            message = """
🆕 درخواست‌های جدید

✅ هیچ درخواست جدیدی در انتظار نیست!

🎯 تمام درخواست‌ها پردازش شده‌اند.
🔄 برای بررسی مجدد روی "بروزرسانی" کلیک کنید.

💼 وضعیت شما: آماده دریافت درخواست جدید
"""
        else:
            message = f"""
🆕 درخواست‌های جدید در انتظار

📊 آمار:
• کل درخواست‌های انتظار: {len(pending_requests)}
• فوری: {len([r for r in pending_requests if r.priority == 4])}
• بالا: {len([r for r in pending_requests if r.priority == 3])}
• متوسط: {len([r for r in pending_requests if r.priority == 2])}
• کم: {len([r for r in pending_requests if r.priority == 1])}

🔥 درخواست‌های اولویت‌دار:
"""
            
            priority_emojis = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}
            for req in pending_requests[:8]:  # Show top 8
                emoji = priority_emojis[req.priority]
                time_ago = self._time_ago(req.created_at)
                message += f"{emoji} {req.title[:25]}... ({time_ago})\n"
        
        keyboard = []
        
        # Add buttons for taking requests
        if pending_requests:
            for req in pending_requests[:5]:  # Top 5 buttons
                priority_emoji = priority_emojis[req.priority]
                keyboard.append([
                    InlineKeyboardButton(
                        f"{priority_emoji} {req.title[:20]}...", 
                        callback_data=f"mediation_details_{req.request_id}"
                    )
                ])
        
        keyboard.extend([
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="new_mediations")],
            [InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")]
        ])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_mediator_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show mediator performance statistics"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        # Calculate stats
        my_requests = [req for req in self.active_requests.values() if req.assigned_mediator_id == user_id]
        
        total_requests = len(my_requests)
        resolved_requests = len([r for r in my_requests if r.status == MediationRequestStatus.RESOLVED])
        in_progress = len([r for r in my_requests if r.status == MediationRequestStatus.IN_PROGRESS])
        assigned = len([r for r in my_requests if r.status == MediationRequestStatus.ASSIGNED])
        
        success_rate = (resolved_requests / total_requests * 100) if total_requests > 0 else 0
        current_workload = self.mediator_workload.get(user_id, 0)
        
        # Time-based stats
        today_requests = len([r for r in my_requests if r.created_at.date() == datetime.now().date()])
        this_week_requests = len([r for r in my_requests if (datetime.now() - r.created_at).days <= 7])
        
        message = f"""
📊 آمار عملکرد واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    🏆 آمار کلی                     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📈 **عملکرد کلی:**
• کل درخواست‌ها: {total_requests}
• حل شده: {resolved_requests}
• در حال پردازش: {in_progress}
• تازه اختصاص یافته: {assigned}

🎯 **نرخ موفقیت:** {success_rate:.1f}%
💼 **بار کاری فعلی:** {current_workload}

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  📅 آمار زمانی                    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

• امروز: {today_requests} درخواست
• این هفته: {this_week_requests} درخواست

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  🏅 رتبه‌بندی                     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🥇 جایگاه شما در بین واسطه‌گران: {self._get_mediator_rank(user_id)}

🌟 کیفیت خدمات: {'⭐⭐⭐⭐⭐' if success_rate >= 90 else '⭐⭐⭐⭐' if success_rate >= 80 else '⭐⭐⭐' if success_rate >= 70 else '⭐⭐'}

✨ ادامه بدهید! شما واسطه‌گر فوق‌العاده‌ای هستید!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediations"),
                InlineKeyboardButton("🆕 درخواست‌های جدید", callback_data="new_mediations")
            ],
            [
                InlineKeyboardButton("🔄 بروزرسانی آمار", callback_data="mediator_stats"),
                InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_mediator_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show mediator settings and preferences"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گر ندارید!", show_alert=True)
            return
        
        message = """
⚙️ تنظیمات واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  🔧 تنظیمات فعلی                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔔 **اطلاع‌رسانی:**
• درخواست‌های جدید: ✅ فعال
• یادآوری پیگیری: ✅ فعال
• گزارش روزانه: ✅ فعال

🎯 **ترجیحات کاری:**
• حداکثر درخواست همزمان: 5
• ساعات کاری: 24/7
• تخصص: همه موارد

🔧 **تنظیمات پیشرفته:**
• تأیید خودکار: ❌ غیرفعال
• انتقال خودکار: ❌ غیرفعال
• پیام خوش‌آمدگویی: ✅ فعال

💡 برای تغییر هر کدام از این تنظیمات، روی دکمه مربوطه کلیک کنید.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🔔 تنظیمات اطلاع‌رسانی", callback_data="mediator_notifications"),
                InlineKeyboardButton("🎯 ترجیحات کاری", callback_data="mediator_preferences")
            ],
            [
                InlineKeyboardButton("⏰ ساعات کاری", callback_data="mediator_schedule"),
                InlineKeyboardButton("🔧 تنظیمات پیشرفته", callback_data="mediator_advanced")
            ],
            [
                InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_user_mediation_requests(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user's own mediation requests"""
        user_id = update.effective_user.id
        
        # Get user's requests
        user_requests = [
            req for req in self.active_requests.values()
            if req.requester_id == user_id
        ]
        
        if not user_requests:
            message = """
📋 درخواست‌های واسطه‌گری من

📭 شما هیچ درخواست واسطه‌گری ندارید.

🤝 برای ایجاد درخواست جدید:
• از منوی اصلی گزینه "درخواست واسطه‌گری" را انتخاب کنید
• مشکل خود را دقیق توضیح دهید
• اولویت مناسب انتخاب کنید

✨ تیم واسطه‌گری آماده کمک به شماست!
"""
        else:
            message = f"""
📋 درخواست‌های واسطه‌گری من

📊 آمار:
• کل درخواست‌ها: {len(user_requests)}
• در انتظار: {len([r for r in user_requests if r.status == MediationRequestStatus.PENDING])}
• اختصاص یافته: {len([r for r in user_requests if r.status == MediationRequestStatus.ASSIGNED])}
• در حال پردازش: {len([r for r in user_requests if r.status == MediationRequestStatus.IN_PROGRESS])}
• حل شده: {len([r for r in user_requests if r.status == MediationRequestStatus.RESOLVED])}

📋 لیست درخواست‌ها:
"""
            
            status_emojis = {
                MediationRequestStatus.PENDING: "⏳",
                MediationRequestStatus.ASSIGNED: "🔵",
                MediationRequestStatus.IN_PROGRESS: "🟡",
                MediationRequestStatus.RESOLVED: "🟢",
                MediationRequestStatus.REJECTED: "🔴"
            }
            
            for req in user_requests:
                emoji = status_emojis.get(req.status, "⚪")
                time_ago = self._time_ago(req.created_at)
                message += f"{emoji} {req.title[:30]}... ({time_ago})\n"
        
        keyboard = []
        
        # Add buttons for active requests
        if user_requests:
            for req in user_requests[:5]:  # Show top 5
                keyboard.append([
                    InlineKeyboardButton(
                        f"📝 {req.title[:25]}...", 
                        callback_data=f"mediation_status_{req.request_id}"
                    )
                ])
        
        keyboard.extend([
            [InlineKeyboardButton("🆕 درخواست جدید", callback_data="request_mediation")],
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="my_mediation_requests")],
            [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
        ])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    def _time_ago(self, dt: datetime) -> str:
        """Calculate time ago string"""
        now = datetime.now()
        diff = now - dt
        
        if diff.days > 0:
            return f"{diff.days} روز پیش"
        elif diff.seconds > 3600:
            hours = diff.seconds // 3600
            return f"{hours} ساعت پیش"
        elif diff.seconds > 60:
            minutes = diff.seconds // 60
            return f"{minutes} دقیقه پیش"
        else:
            return "همین الان"
    
    def _get_mediator_rank(self, mediator_id: int) -> str:
        """Get mediator's rank among all mediators"""
        # Simple ranking based on resolved requests
        all_mediators = Config.MEDIATOR_ADMINS
        if not all_mediators:
            return "1"
        
        # In real implementation, you'd calculate actual rankings
        return f"{(mediator_id % len(all_mediators)) + 1} از {len(all_mediators)}"
    
    async def show_mediation_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Show detailed information about a mediation request"""
        user_id = update.effective_user.id
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        # Check access rights
        is_mediator = self.is_mediator(user_id)
        is_requester = user_id == request.requester_id
        
        if not (is_mediator or is_requester):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        # Format request details
        type_names = {
            MediationRequestType.TRANSACTION_DISPUTE: "مشکل معامله",
            MediationRequestType.PAYMENT_ISSUE: "مشکل پرداخت",
            MediationRequestType.PRODUCT_ISSUE: "مشکل محصول",
            MediationRequestType.COMMUNICATION_ISSUE: "مشکل ارتباطی",
            MediationRequestType.GENERAL_MEDIATION: "واسطه‌گری عمومی"
        }
        
        status_names = {
            MediationRequestStatus.PENDING: "در انتظار",
            MediationRequestStatus.ASSIGNED: "اختصاص یافته",
            MediationRequestStatus.IN_PROGRESS: "در حال پردازش",
            MediationRequestStatus.RESOLVED: "حل شده",
            MediationRequestStatus.REJECTED: "رد شده"
        }
        
        priority_names = {1: "کم", 2: "متوسط", 3: "بالا", 4: "فوری"}
        priority_emojis = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}
        
        mediator_name = "تعیین نشده"
        if request.assigned_mediator_id:
            mediator_user = self.db.get_user(request.assigned_mediator_id)
            if mediator_user:
                mediator_name = f"{mediator_user.first_name} {mediator_user.last_name or ''}".strip()
        
        message = f"""
📋 جزئیات درخواست واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   📝 اطلاعات کلی                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request.request_id}`
👤 **درخواست‌کننده:** {request.requester_name}
📋 **نوع:** {type_names[request.request_type]}
📝 **عنوان:** {request.title}

{priority_emojis[request.priority]} **اولویت:** {priority_names[request.priority]}
🔄 **وضعیت:** {status_names[request.status]}
🤝 **واسطه‌گر:** {mediator_name}

📅 **تاریخ ثبت:** {request.created_at.strftime('%Y/%m/%d - %H:%M')}
🔄 **آخرین بروزرسانی:** {request.updated_at.strftime('%Y/%m/%d - %H:%M')}

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    📄 شرح مشکل                    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

{request.description}
"""
        
        if request.resolution_notes:
            message += f"""

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  💬 یادداشت حل                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

{request.resolution_notes}
"""
        
        # Create appropriate keyboard based on user role and request status
        keyboard = []
        
        if is_mediator and request.assigned_mediator_id == user_id:
            if request.status == MediationRequestStatus.ASSIGNED:
                keyboard.extend([
                    [
                        InlineKeyboardButton("✅ قبول درخواست", callback_data=f"accept_mediation_{request_id}"),
                        InlineKeyboardButton("❌ رد درخواست", callback_data=f"reject_mediation_{request_id}")
                    ],
                    [
                        InlineKeyboardButton("👥 انتخاب کاربر برای چت", callback_data=f"contact_requester_{request_id}")
                    ]
                ])
            elif request.status == MediationRequestStatus.IN_PROGRESS:
                keyboard.extend([
                    [
                        InlineKeyboardButton("✅ حل شد", callback_data=f"resolve_mediation_{request_id}"),
                        InlineKeyboardButton("⬆️ ارجاع به بالادست", callback_data=f"escalate_mediation_{request_id}")
                    ],
                    [
                        InlineKeyboardButton("👥 انتخاب کاربر برای چت", callback_data=f"contact_requester_{request_id}"),
                        InlineKeyboardButton("🔄 انتقال", callback_data=f"transfer_mediation_{request_id}")
                    ]
                ])
        
        if is_mediator:
            keyboard.append([InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")])
        else:
            keyboard.append([InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediation_requests")])
        
        keyboard.append([InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"mediation_details_{request_id}")])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def contact_requester(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Show user selection menu for contacting users in this request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Direct to user selection menu instead of showing requester info directly
        await self.show_user_selection_menu(update, context, request_id)
    
    async def transfer_mediation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Transfer mediation to another mediator"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        if request.assigned_mediator_id != user_id:
            await update.callback_query.answer("❌ این درخواست به شما اختصاص نیافته!", show_alert=True)
            return
        
        # Get available mediators
        available_mediators = [mid for mid in Config.MEDIATOR_ADMINS if mid != user_id]
        
        if not available_mediators:
            await update.callback_query.answer("❌ واسطه‌گر دیگری موجود نیست!", show_alert=True)
            return
        
        # Reduce current mediator's workload
        self.mediator_workload[user_id] = max(0, self.mediator_workload.get(user_id, 0) - 1)
        
        # Assign to another mediator
        new_mediator = self.assign_mediator(request_id)
        
        if new_mediator:
            await self.notify_mediator_new_request(context, new_mediator, request)
            
            message = f"""
✅ درخواست با موفقیت منتقل شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}

🔄 **انتقال به:** واسطه‌گر جدید
📅 **زمان انتقال:** {datetime.now().strftime('%Y/%m/%d - %H:%M')}

💬 **دلیل انتقال:** درخواست کاربر
🎯 **وضعیت:** واسطه‌گر جدید مطلع شد

✨ از همکاری شما سپاسگزاریم!
"""
            
            keyboard = [
                [InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediations")],
                [InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")]
            ]
            
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
            
            logger.info("MEDIATION_TRANSFERRED", 
                       from_mediator=user_id,
                       to_mediator=new_mediator,
                       request_id=request_id)
        else:
            await update.callback_query.answer("❌ خطا در انتقال! مجدداً تلاش کنید.", show_alert=True)
    
    async def resolve_mediation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Mark mediation as resolved"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        if request.assigned_mediator_id != user_id:
            await update.callback_query.answer("❌ این درخواست به شما اختصاص نیافته!", show_alert=True)
            return
        
        # Update request status
        request.status = MediationRequestStatus.RESOLVED
        request.updated_at = datetime.now()
        request.resolution_notes = f"حل شده توسط واسطه‌گر در تاریخ {datetime.now().strftime('%Y/%m/%d - %H:%M')}"
        
        # Update in database
        self._update_mediation_request_in_db(request)
        
        # Reduce mediator workload
        self.mediator_workload[user_id] = max(0, self.mediator_workload.get(user_id, 0) - 1)
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=request.requester_id,
                text=f"""
🎉 درخواست واسطه‌گری شما حل شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}

✅ **وضعیت:** حل شده
📅 **زمان حل:** {datetime.now().strftime('%Y/%m/%d - %H:%M')}

💬 مشکل شما توسط تیم واسطه‌گری بررسی و حل شد.

🙏 از صبر و همکاری شما سپاسگزاریم!
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("USER_RESOLUTION_NOTIFICATION_FAILED", 
                        user_id=request.requester_id,
                        request_id=request_id,
                        error=str(e))
        
        message = f"""
✅ درخواست با موفقیت حل شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}
👤 **کاربر:** {request.requester_name}

🎯 **نتیجه:** حل موفق
📅 **زمان حل:** {datetime.now().strftime('%Y/%m/%d - %H:%M')}

📊 کاربر از حل مشکل مطلع شد.

🏆 عالی! یک درخواست دیگر با موفقیت حل شد.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediations"),
                InlineKeyboardButton("🆕 درخواست‌های جدید", callback_data="new_mediations")
            ],
            [
                InlineKeyboardButton("📊 آمار عملکرد", callback_data="mediator_stats"),
                InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        logger.info("MEDIATION_RESOLVED", 
                   mediator_id=user_id,
                   request_id=request_id,
                   requester_id=request.requester_id)
    
    async def escalate_mediation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Escalate mediation to higher level"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        if request.assigned_mediator_id != user_id:
            await update.callback_query.answer("❌ این درخواست به شما اختصاص نیافته!", show_alert=True)
            return
        
        # Update request status
        request.status = MediationRequestStatus.ESCALATED
        request.updated_at = datetime.now()
        request.escalation_reason = f"ارجاع به بالادست توسط واسطه‌گر در تاریخ {datetime.now().strftime('%Y/%m/%d - %H:%M')}"
        
        # Update in database
        self._update_mediation_request_in_db(request)
        
        # Notify main admin
        try:
            await context.bot.send_message(
                chat_id=Config.MAIN_ADMIN_ID,
                text=f"""
🚨 درخواست واسطه‌گری ارجاع شد!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  ⬆️ ارجاع به بالادست                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}
👤 **درخواست‌کننده:** {request.requester_name}

🤝 **واسطه‌گر:** {user_id}
📅 **زمان ارجاع:** {datetime.now().strftime('%Y/%m/%d - %H:%M')}

📄 **شرح مشکل:**
{request.description[:300]}

⚠️ این درخواست نیاز به بررسی بیشتر دارد.
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("ADMIN_ESCALATION_NOTIFICATION_FAILED", 
                        admin_id=Config.MAIN_ADMIN_ID,
                        request_id=request_id,
                        error=str(e))
        
        message = f"""
⬆️ درخواست به بالادست ارجاع شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}

🎯 **ارجاع به:** مدیریت کل
📅 **زمان ارجاع:** {datetime.now().strftime('%Y/%m/%d - %H:%M')}

📊 مدیریت از ارجاع مطلع شد و به زودی پیگیری خواهد کرد.

✨ از تلاش شما برای حل مشکل سپاسگزاریم!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediations"),
                InlineKeyboardButton("🆕 درخواست‌های جدید", callback_data="new_mediations")
            ],
            [
                InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        logger.info("MEDIATION_ESCALATED", 
                   mediator_id=user_id,
                   request_id=request_id,
                   requester_id=request.requester_id)
    
    async def show_mediation_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Show mediation status for user"""
        user_id = update.effective_user.id
        
        if request_id not in self.active_requests:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        request = self.active_requests[request_id]
        
        if request.requester_id != user_id:
            await update.callback_query.answer("⛔ این درخواست متعلق به شما نیست!", show_alert=True)
            return
        
        # Format status information
        status_names = {
            MediationRequestStatus.PENDING: "در انتظار اختصاص",
            MediationRequestStatus.ASSIGNED: "اختصاص یافته",
            MediationRequestStatus.IN_PROGRESS: "در حال پردازش",
            MediationRequestStatus.RESOLVED: "حل شده",
            MediationRequestStatus.REJECTED: "رد شده",
            MediationRequestStatus.ESCALATED: "ارجاع شده"
        }
        
        status_descriptions = {
            MediationRequestStatus.PENDING: "درخواست شما در صف انتظار قرار دارد",
            MediationRequestStatus.ASSIGNED: "واسطه‌گر به درخواست شما اختصاص یافت",
            MediationRequestStatus.IN_PROGRESS: "واسطه‌گر در حال بررسی مشکل شماست",
            MediationRequestStatus.RESOLVED: "مشکل شما حل شده است",
            MediationRequestStatus.REJECTED: "درخواست رد شده است",
            MediationRequestStatus.ESCALATED: "درخواست به مدیریت ارجاع شده"
        }
        
        priority_names = {1: "کم", 2: "متوسط", 3: "بالا", 4: "فوری"}
        priority_emojis = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}
        
        message = f"""
📊 وضعیت درخواست واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   📋 اطلاعات کلی                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request.request_id}`
📝 **عنوان:** {request.title}
{priority_emojis[request.priority]} **اولویت:** {priority_names[request.priority]}

📅 **تاریخ ثبت:** {request.created_at.strftime('%Y/%m/%d - %H:%M')}
🔄 **آخرین بروزرسانی:** {request.updated_at.strftime('%Y/%m/%d - %H:%M')}

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   🔄 وضعیت فعلی                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🎯 **وضعیت:** {status_names[request.status]}
💬 **توضیح:** {status_descriptions[request.status]}

⏰ **زمان تخمینی:** {self._get_estimated_time(request)}
"""
        
        if request.assigned_mediator_id:
            mediator = self.db.get_user(request.assigned_mediator_id)
            mediator_name = f"{mediator.first_name} {mediator.last_name or ''}".strip() if mediator else "نامشخص"
            message += f"\n🤝 **واسطه‌گر:** {mediator_name}"
        
        if request.resolution_notes:
            message += f"""

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    💬 یادداشت                     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

{request.resolution_notes}
"""
        
        keyboard = [
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"mediation_status_{request_id}")],
            [InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_mediation_requests")],
            [InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    def _get_estimated_time(self, request: MediationRequest) -> str:
        """Get estimated time for request resolution"""
        if request.status == MediationRequestStatus.RESOLVED:
            return "✅ حل شده"
        elif request.status == MediationRequestStatus.REJECTED:
            return "❌ رد شده"
        else:
            timeout = self.escalation_timeouts.get(request.priority, 24)
            elapsed = (datetime.now() - request.created_at).total_seconds() / 3600
            remaining = max(0, timeout - elapsed)
            
            if remaining > 1:
                return f"⏰ حداکثر {remaining:.0f} ساعت"
            else:
                return "⚡ به زودی"
    
    def _save_mediation_request_to_db(self, request: MediationRequest):
        """Save mediation request to database"""
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO mediation_requests (
                        request_id, requester_id, requester_name, request_type,
                        title, description, related_transaction_id, priority,
                        status, assigned_mediator_id, created_at, updated_at,
                        amount, files, mediator_notes, resolution, estimated_time, urgency_level,
                        resolution_notes, escalation_reason
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    request.request_id, request.requester_id, request.requester_name,
                    request.request_type.value, request.title, request.description,
                    request.related_transaction_id, request.priority, request.status.value,
                    request.assigned_mediator_id, request.created_at.isoformat(),
                    request.updated_at.isoformat(), request.amount,
                    str(request.files) if request.files else None, request.mediator_notes,
                    request.resolution, request.estimated_time, request.urgency_level,
                    request.resolution_notes, request.escalation_reason
                ))
                conn.commit()
                logger.info("MEDIATION_REQUEST_SAVED_TO_DB", request_id=request.request_id)
        except Exception as e:
            logger.error("MEDIATION_REQUEST_DB_SAVE_FAILED", 
                        request_id=request.request_id, error=str(e))
    
    def _update_mediation_request_in_db(self, request: MediationRequest):
        """Update mediation request in database"""
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE mediation_requests SET
                        status = ?, assigned_mediator_id = ?, updated_at = ?,
                        amount = ?, files = ?, mediator_notes = ?, resolution = ?, 
                        estimated_time = ?, urgency_level = ?, resolution_notes = ?, escalation_reason = ?
                    WHERE request_id = ?
                """, (
                    request.status.value, request.assigned_mediator_id,
                    request.updated_at.isoformat(), request.amount,
                    str(request.files) if request.files else None, request.mediator_notes,
                    request.resolution, request.estimated_time, request.urgency_level,
                    request.resolution_notes, request.escalation_reason, request.request_id
                ))
                conn.commit()
                logger.info("MEDIATION_REQUEST_UPDATED_IN_DB", request_id=request.request_id)
        except Exception as e:
            logger.error("MEDIATION_REQUEST_DB_UPDATE_FAILED", 
                        request_id=request.request_id, error=str(e))
    
    def load_active_requests_from_db(self):
        """Load active mediation requests from database on startup"""
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM mediation_requests 
                    WHERE status NOT IN ('resolved', 'rejected')
                    ORDER BY created_at DESC
                """)
                
                for row in cursor.fetchall():
                    # Handle both old and new database schema
                    try:
                        request = MediationRequest(
                            request_id=row[0],
                            requester_id=row[1],
                            requester_name=row[2],
                            request_type=MediationRequestType(row[3]),
                            title=row[4],
                            description=row[5],
                            related_transaction_id=row[6],
                            priority=row[7],
                            status=MediationRequestStatus(row[8]),
                            assigned_mediator_id=row[9],
                            created_at=datetime.fromisoformat(row[10]),
                            updated_at=datetime.fromisoformat(row[11]),
                            amount=row[12] if len(row) > 12 and row[12] is not None else None,
                            files=eval(row[13]) if len(row) > 13 and row[13] else None,
                            mediator_notes=row[14] if len(row) > 14 else None,
                            resolution=row[15] if len(row) > 15 else None,
                            estimated_time=row[16] if len(row) > 16 else None,
                            urgency_level=row[17] if len(row) > 17 else None,
                            resolution_notes=row[18] if len(row) > 18 else None,
                            escalation_reason=row[19] if len(row) > 19 else None
                        )
                    except (IndexError, ValueError):
                        # Fallback for old schema
                        request = MediationRequest(
                            request_id=row[0],
                            requester_id=row[1],
                            requester_name=row[2],
                            request_type=MediationRequestType(row[3]),
                            title=row[4],
                            description=row[5],
                            related_transaction_id=row[6],
                            priority=row[7],
                            status=MediationRequestStatus(row[8]),
                            assigned_mediator_id=row[9],
                            created_at=datetime.fromisoformat(row[10]),
                            updated_at=datetime.fromisoformat(row[11]),
                            resolution_notes=row[12] if len(row) > 12 else None,
                            escalation_reason=row[13] if len(row) > 13 else None
                        )
                    
                    self.active_requests[request.request_id] = request
                    
                    # Update mediator workload
                    if request.assigned_mediator_id:
                        self.mediator_workload[request.assigned_mediator_id] = \
                            self.mediator_workload.get(request.assigned_mediator_id, 0) + 1
                
                logger.info("ACTIVE_REQUESTS_LOADED_FROM_DB", 
                           count=len(self.active_requests))
        except Exception as e:
            logger.error("LOAD_REQUESTS_FROM_DB_FAILED", error=str(e))
    
    async def start_user_conversation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, target_user_id: int):
        """Start conversation with a user"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        # Get target user info
        target_user = self.db.get_user(target_user_id)
        if not target_user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Get mediator info
        mediator = self.db.get_user(user_id)
        mediator_name = mediator.first_name if mediator else "واسطه‌گر"
        
        # Safely format user information to prevent entity parsing errors
        target_name = f"{target_user.first_name} {target_user.last_name or ''}".strip()
        target_username = target_user.username or 'ندارد'
        
        # Escape special characters that cause parsing issues
        target_name_safe = target_name.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace('`', '\\`').replace('(', '\\(').replace(')', '\\)')
        target_username_safe = target_username.replace('_', '\\_').replace('*', '\\*')
        
        message = f"""
💬 شروع گفت‌وگو با کاربر

👤 گیرنده: {target_name_safe}
🆔 شناسه: `{target_user_id}`
📱 نام کاربری: @{target_username_safe}

📝 دستورالعمل:
• پیام خود را در همین چت بنویسید
• پیام شما به کاربر ارسال خواهد شد
• برای لغو /cancel بزنید

🔒 نکات مهم:
• پیام‌ها باید مؤدبانه و حرفه‌ای باشند
• شناسه واسطه‌گر در پیام نمایش داده می‌شود
• کاربر می‌تواند پاسخ دهد
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data="mediator_dashboard")]
        ]
        
        # Store conversation state in user_data
        context.user_data['mediator_conversation'] = {
            'target_user_id': target_user_id,
            'target_name': f"{target_user.first_name} {target_user.last_name or ''}".strip(),
            'mediator_name': mediator_name
        }
        
        # Store in global conversation tracking (get main bot instance)
        bot_instance = context.bot_data.get('main_bot')
        if bot_instance and hasattr(bot_instance, 'active_mediator_conversations'):
            if user_id not in bot_instance.active_mediator_conversations:
                bot_instance.active_mediator_conversations[user_id] = {}
            
            bot_instance.active_mediator_conversations[user_id][target_user_id] = {
                'target_name': f"{target_user.first_name} {target_user.last_name or ''}".strip(),
                'mediator_name': mediator_name,
                'start_time': datetime.now(),
                'last_activity': datetime.now()
            }
        
        try:
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
        except Exception as e:
            # If markdown parsing fails, try without markdown
            logger.error("MEDIATOR_CONVERSATION_START_MARKDOWN_ERROR", 
                        mediator_id=user_id, 
                        target_user_id=target_user_id, 
                        error=str(e))
            
            # Fallback message without markdown formatting
            simple_message = f"""
💬 شروع گفت‌وگو با کاربر

👤 گیرنده: {target_name}
🆔 شناسه: {target_user_id}
📱 نام کاربری: @{target_username}

📝 پیام خود را در همین چت بنویسید
برای لغو /cancel بزنید

🔒 پیام‌ها باید مؤدبانه و حرفه‌ای باشند
"""
            
            await update.callback_query.edit_message_text(
                simple_message, reply_markup=InlineKeyboardMarkup(keyboard)
            )
        
        logger.info("MEDIATOR_CONVERSATION_STARTED", 
                   mediator_id=user_id, 
                   target_user_id=target_user_id)
    
    async def show_user_contact_info(self, update: Update, context: ContextTypes.DEFAULT_TYPE, target_user_id: int):
        """Show user contact information"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        target_user = self.db.get_user(target_user_id)
        if not target_user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Safely format user information to prevent entity parsing errors
        user_name = f"{target_user.first_name} {target_user.last_name or ''}".strip()
        user_username = target_user.username or 'ندارد'
        
        # Escape special characters that cause parsing issues
        user_name_safe = user_name.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace('`', '\\`').replace('(', '\\(').replace(')', '\\)')
        user_username_safe = user_username.replace('_', '\\_').replace('*', '\\*')
        
        message = f"""
👤 اطلاعات تماس کاربر

👤 نام: {user_name_safe}
🆔 شناسه: `{target_user.user_id}`
📱 نام کاربری: @{user_username_safe}
📅 عضویت: {target_user.registration_date.strftime('%Y/%m/%d')}
🏷️ نقش: {target_user.role.value}

💬 راه‌های تماس:
• پیام مستقیم در ربات
• منشن کردن در گروه‌ها
• تماس تلفنی (در صورت لزوم)

🔒 نکات امنیتی:
• اطلاعات شخصی کاربر محرمانه است
• از این اطلاعات فقط برای حل مشکل استفاده کنید
• گفتگوها باید مؤدبانه و حرفه‌ای باشد
• تمام تماس‌ها لاگ می‌شوند
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 ارسال پیام", callback_data=f"message_user_{target_user_id}"),
                InlineKeyboardButton("🔙 بازگشت", callback_data="mediator_dashboard")
            ]
        ]
        
        try:
            await update.callback_query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
        except Exception as e:
            # If markdown parsing fails, try without markdown
            logger.error("USER_CONTACT_INFO_MARKDOWN_ERROR", 
                        mediator_id=user_id, 
                        target_user_id=target_user_id, 
                        error=str(e))
            
            # Fallback message without markdown formatting
            simple_message = f"""
👤 اطلاعات تماس کاربر

👤 نام: {user_name}
🆔 شناسه: {target_user.user_id}
📱 نام کاربری: @{user_username}
📅 عضویت: {target_user.registration_date.strftime('%Y/%m/%d')}
🏷️ نقش: {target_user.role.value}

💬 راه‌های تماس:
• پیام مستقیم در ربات
• منشن کردن در گروه‌ها

🔒 نکات امنیتی:
• اطلاعات شخصی کاربر محرمانه است
• از این اطلاعات فقط برای حل مشکل استفاده کنید
"""
            
            await update.callback_query.edit_message_text(
                simple_message, reply_markup=InlineKeyboardMarkup(keyboard)
            )
        
        logger.info("USER_CONTACT_INFO_VIEWED", 
                   mediator_id=user_id, 
                   target_user_id=target_user_id)
    
    async def show_intermediary_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed list of intermediary requests"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        # Get intermediary requests from main bot
        bot_instance = context.bot_data.get('bot_instance')
        if not bot_instance:
            await update.callback_query.answer("❌ خطا در دسترسی به درخواست‌ها!", show_alert=True)
            return
        
        intermediary_requests = [req for req in self.active_requests.values() 
                               if req.request_type.value == 'general_mediation']
        
        if not intermediary_requests:
            message = """
🤝 جزئیات درخواست‌های واسطه‌گری

📭 هیچ درخواست واسطه‌گری فعالی وجود ندارد.

💡 درخواست‌های واسطه‌گری شامل:
• گروه‌های معامله
• درخواست‌های کمک کاربران
• مشکلات پرداخت و تحویل

🔄 لطفاً بعداً مراجعه کنید.
"""
        else:
            message = f"""
🤝 جزئیات درخواست‌های واسطه‌گری

📊 **آمار کلی:**
• کل درخواست‌ها: {len(intermediary_requests)}
• در انتظار: {len([r for r in intermediary_requests if r.status.value == 'pending'])}
• در حال انجام: {len([r for r in intermediary_requests if r.status.value == 'in_progress'])}

📋 **فهرست درخواست‌ها:**
"""
            
            status_emojis = {
                'pending': '⏳',
                'assigned': '✅', 
                'in_progress': '🔄',
                'resolved': '🟢',
                'rejected': '🔴'
            }
            
            # Show up to 5 requests with details
            for i, req in enumerate(intermediary_requests[:5]):
                emoji = status_emojis.get(req.status.value, '⚪')
                amount = getattr(req, 'amount', 0)
                message += f"""

{i+1}. {emoji} **{req.title[:40]}**
   💰 مبلغ: {amount:,} تومان
   👤 درخواست‌کننده: {req.requester_name}
   📅 تاریخ: {req.created_at.strftime('%Y/%m/%d %H:%M')}
   🔗 شناسه: `{req.request_id}`
"""
        
        keyboard = []
        
        # Add buttons for individual requests
        if intermediary_requests:
            for i, req in enumerate(intermediary_requests[:3]):  # Max 3 buttons
                keyboard.append([
                    InlineKeyboardButton(
                        f"📋 درخواست {i+1}: {req.title[:20]}...", 
                        callback_data=f"intermediary_detail_{req.request_id}"
                    )
                ])
        
        keyboard.extend([
            [
                InlineKeyboardButton("🔄 بروزرسانی", callback_data="intermediary_details"),
                InlineKeyboardButton("📊 آمار", callback_data="intermediary_requests")
            ],
            [InlineKeyboardButton("🔙 داشبورد", callback_data="mediator_dashboard")]
        ])
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def show_intermediary_request_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Show details of a specific intermediary request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        # Find the request
        request = self.active_requests.get(request_id)
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Get additional info from intermediary system and groups
        bot_instance = context.bot_data.get('main_bot')
        intermediary_data = None
        group_data = None
        
        if bot_instance:
            # Check intermediary requests
            if hasattr(bot_instance, 'intermediary_requests'):
                intermediary_data = bot_instance.intermediary_requests.get(request_id)
            
            # Check intermediary groups for buyer info
            if hasattr(bot_instance, 'intermediary_groups'):
                for group_id, group in bot_instance.intermediary_groups.items():
                    if group.get('request_id') == request_id:
                        group_data = group
                        break
        
        status_emoji = {
            'pending': '⏳ در انتظار',
            'assigned': '✅ تخصیص یافته', 
            'in_progress': '🔄 در حال انجام',
            'resolved': '🟢 حل شده',
            'rejected': '🔴 رد شده'
        }.get(request.status.value, '⚪ نامشخص')
        
        priority_emoji = {
            1: '🟢 کم',
            2: '🟡 متوسط', 
            3: '🟠 بالا',
            4: '🔴 فوری'
        }.get(request.priority, '⚪ نامشخص')
        
        message = f"""
🤝 جزئیات درخواست واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  📋 اطلاعات درخواست                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request.title}
📄 **توضیحات:** {request.description[:200]}{'...' if len(request.description) > 200 else ''}

👤 **درخواست‌کننده (فروشنده):**
   • نام: {request.requester_name}
   • شناسه: `{request.requester_id}`

💰 **مبلغ:** {getattr(request, 'amount', 0):,} تومان
🏷️ **وضعیت:** {status_emoji}
⚡ **اولویت:** {priority_emoji}

📅 **زمان‌بندی:**
   • ایجاد: {request.created_at.strftime('%Y/%m/%d %H:%M')}
   • آپدیت: {request.updated_at.strftime('%Y/%m/%d %H:%M')}
"""
        
        # Add buyer info if available (check both sources)
        buyer_id = None
        buyer_name = None
        
        # First check group data (primary source for intermediary groups)
        if group_data and group_data.get('participant_id'):
            buyer_id = group_data['participant_id'] 
            buyer_name = group_data.get('participant_name', 'نامشخص')
        # Fallback to intermediary_data
        elif intermediary_data and intermediary_data.get('buyer_id'):
            buyer_id = intermediary_data['buyer_id']
            buyer_name = intermediary_data.get('buyer_name', 'نامشخص')
        
        if buyer_id:
            buyer_user = self.db.get_user(buyer_id)
            if buyer_user:
                message += f"""
👥 **خریدار:**
   • نام: {buyer_user.first_name} {buyer_user.last_name or ''}
   • شناسه: `{buyer_user.user_id}`
   • نام کاربری: @{buyer_user.username or 'ندارد'}
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 تماس با کاربران", callback_data=f"choose_contact_user_{request_id}"),
            ]
        ]
        
        keyboard.extend([
            [
                InlineKeyboardButton("✅ حل شد", callback_data=f"resolve_mediation_{request_id}"),
                InlineKeyboardButton("⬆️ ارجاع", callback_data=f"escalate_mediation_{request_id}")
            ],
            [
                InlineKeyboardButton("🔙 لیست درخواست‌ها", callback_data="intermediary_details"),
                InlineKeyboardButton("🏠 داشبورد", callback_data="mediator_dashboard")
            ]
        ])
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def contact_intermediary_seller(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Contact the seller in an intermediary request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        request = self.active_requests.get(request_id)
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Start conversation with seller (requester)
        await self.start_user_conversation(update, context, request.requester_id)
    
    async def contact_intermediary_buyer(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Contact the buyer in an intermediary request"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        # Get buyer ID from multiple sources - enhanced search
        buyer_id = None
        bot_instance = context.bot_data.get('main_bot')
        request = self.active_requests.get(request_id)
        
        if bot_instance:
            # Method 1: Check intermediary groups (primary source)
            if hasattr(bot_instance, 'intermediary_groups'):
                for group_id, group in bot_instance.intermediary_groups.items():
                    # Try multiple matching strategies
                    if (group.get('request_id') == request_id or 
                        (request and group.get('creator_id') == request.requester_id)):
                        if group.get('participant_id'):
                            buyer_id = group['participant_id']
                            break
            
            # Method 2: Check intermediary requests
            if not buyer_id and hasattr(bot_instance, 'intermediary_requests'):
                intermediary_data = bot_instance.intermediary_requests.get(request_id)
                if intermediary_data:
                    if intermediary_data.get('buyer_id'):
                        buyer_id = intermediary_data['buyer_id']
                    elif intermediary_data.get('participant_id'):
                        buyer_id = intermediary_data['participant_id']
            
            # Method 3: Search all groups by creator ID if we have the request
            if not buyer_id and request and hasattr(bot_instance, 'intermediary_groups'):
                for group_id, group in bot_instance.intermediary_groups.items():
                    if group.get('creator_id') == request.requester_id and group.get('participant_id'):
                        buyer_id = group['participant_id']
                        break
        
        if not buyer_id:
            await update.callback_query.answer("❌ خریدار هنوز به گروه نپیوسته است!", show_alert=True)
            return
        
        await self.start_user_conversation(update, context, buyer_id)
    
    async def show_user_selection_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Show menu to select which user to contact"""
        user_id = update.effective_user.id
        
        if not self.is_mediator(user_id):
            await update.callback_query.answer("⛔ فقط واسطه‌گران دسترسی دارند!", show_alert=True)
            return
        
        # Find the request
        request = self.active_requests.get(request_id)
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Get user info from multiple sources - improved logic
        bot_instance = context.bot_data.get('main_bot')
        if not bot_instance:
            # Fallback to getting main bot from context
            bot_instance = getattr(context, 'bot_instance', None)
        
        seller_id = request.requester_id
        seller_name = request.requester_name
        buyer_id = None
        buyer_name = None
        group_data = None
        
        # Enhanced search for buyer info
        if bot_instance:
            # Method 1: Check intermediary groups for buyer info
            if hasattr(bot_instance, 'intermediary_groups'):
                for group_id, group in bot_instance.intermediary_groups.items():
                    # Match by request_id or creator_id
                    if (group.get('request_id') == request_id or 
                        group.get('creator_id') == seller_id):
                        group_data = group
                        if group.get('participant_id'):
                            buyer_id = group['participant_id']
                            buyer_name = group.get('participant_name', 'نامشخص')
                        break
            
            # Method 2: Check intermediary requests
            if not buyer_id and hasattr(bot_instance, 'intermediary_requests'):
                intermediary_data = bot_instance.intermediary_requests.get(request_id)
                if intermediary_data:
                    if intermediary_data.get('buyer_id'):
                        buyer_id = intermediary_data['buyer_id']
                        buyer_name = intermediary_data.get('buyer_name', 'نامشخص')
                    elif intermediary_data.get('participant_id'):
                        buyer_id = intermediary_data['participant_id']
                        buyer_name = intermediary_data.get('participant_name', 'نامشخص')
        
        # Get detailed user info
        seller_user = self.db.get_user(seller_id)
        seller_display_name = f"{seller_user.first_name} {seller_user.last_name or ''}".strip() if seller_user else seller_name
        
        # Determine request type for better labeling
        request_type_name = "درخواست واسطه‌گری"
        user1_label = "درخواست‌کننده"
        user2_label = "طرف مقابل"
        
        if hasattr(request, 'request_type') and str(request.request_type) == 'MediationRequestType.GENERAL_MEDIATION':
            request_type_name = "درخواست واسطه‌گری (گروه معامله)"
            user1_label = "فروشنده (سازنده گروه)"
            user2_label = "خریدار (عضو جدید)"
        
        message = f"""
👥 انتخاب کاربر برای گفت‌وگو

🆔 درخواست: `{request_id}`
📝 عنوان: {request.title[:40]}...
📋 نوع: {request_type_name}

👤 کاربر اول ({user1_label}):
   • نام: {seller_display_name}
   • شناسه: `{seller_id}`

"""
        
        keyboard = [
            [InlineKeyboardButton(f"💬 چت با {seller_display_name[:12]}... ({user1_label[:10]})", 
                                callback_data=f"contact_seller_{request_id}")]
        ]
        
        if buyer_id:
            buyer_user = self.db.get_user(buyer_id)
            buyer_display_name = f"{buyer_user.first_name} {buyer_user.last_name or ''}".strip() if buyer_user else buyer_name
            
            message += f"""👥 کاربر دوم ({user2_label}):
   • نام: {buyer_display_name}
   • شناسه: `{buyer_id}`

💡 با کدام کاربر می‌خواهید گفت‌وگو کنید؟
"""
            
            keyboard.append([
                InlineKeyboardButton(f"💬 چت با {buyer_display_name[:12]}... ({user2_label[:10]})", 
                                   callback_data=f"contact_buyer_{request_id}")
            ])
        else:
            message += f"""👥 کاربر دوم ({user2_label}):
   ❌ هنوز در دسترس نیست

⚠️ توجه: فعلاً فقط می‌توانید با {user1_label} صحبت کنید.
"""
        
        # Add appropriate back button based on request type
        if hasattr(request, 'request_type') and str(request.request_type) == 'MediationRequestType.GENERAL_MEDIATION':
            keyboard.append([
                InlineKeyboardButton("🔙 بازگشت به جزئیات", callback_data=f"intermediary_detail_{request_id}")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🔙 بازگشت به جزئیات", callback_data=f"mediation_details_{request_id}")
            ])
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        logger.info("USER_SELECTION_MENU_SHOWN", 
                   mediator_id=user_id,
                   request_id=request_id,
                   has_buyer=buyer_id is not None)
