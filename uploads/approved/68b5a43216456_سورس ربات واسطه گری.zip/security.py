# -*- coding: utf-8 -*-
"""
Advanced Security Features for Intermediary Bot
"""

import hashlib
import secrets
import time
from datetime import datetime, timedelta
from typing import Dict, Set, Optional, List
from functools import wraps
import re

class SecurityManager:
    """Comprehensive security management system"""
    
    def __init__(self):
        # Rate limiting storage
        self.user_requests: Dict[int, List[float]] = {}
        self.blocked_users: Set[int] = set()
        self.suspicious_activities: Dict[int, int] = {}
        
        # Anti-spam settings
        self.max_requests_per_minute = 10
        self.max_requests_per_hour = 100
        self.block_duration = 3600  # 1 hour
        
        # Pattern detection
        self.spam_patterns = [
            r'(?i)(خرید|فروش|ارز|بیت\s*کوین|bitcoin|crypto)',
            r'(?i)(تلگرام|telegram|@\w+)',
            r'(?i)(پیام\s*رسان|channel|کانال)',
            r'(?i)(پول\s*سازی|درآمد|investment)',
        ]
        
        # Transaction security
        self.transaction_limits = {
            'new_user_max': 1000000,  # 1M Toman for new users
            'verified_user_max': 10000000,  # 10M Toman for verified users
            'daily_limit': 50000000,  # 50M Toman daily limit
        }
    
    def generate_transaction_id(self) -> str:
        """Generate secure transaction ID"""
        timestamp = str(int(time.time()))
        random_part = secrets.token_hex(8)
        return f"TXN_{timestamp}_{random_part}".upper()
    
    def hash_sensitive_data(self, data: str) -> str:
        """Hash sensitive data with salt"""
        salt = secrets.token_hex(16)
        return hashlib.sha256((data + salt).encode()).hexdigest()
    
    def is_rate_limited(self, user_id: int) -> bool:
        """Check if user is rate limited"""
        now = time.time()
        
        # Initialize user if not exists
        if user_id not in self.user_requests:
            self.user_requests[user_id] = []
        
        # Clean old requests (older than 1 hour)
        self.user_requests[user_id] = [
            req_time for req_time in self.user_requests[user_id]
            if now - req_time < 3600
        ]
        
        # Check minute limit
        minute_requests = [
            req_time for req_time in self.user_requests[user_id]
            if now - req_time < 60
        ]
        
        if len(minute_requests) >= self.max_requests_per_minute:
            self.suspicious_activities[user_id] = self.suspicious_activities.get(user_id, 0) + 1
            return True
        
        # Check hour limit
        if len(self.user_requests[user_id]) >= self.max_requests_per_hour:
            self.suspicious_activities[user_id] = self.suspicious_activities.get(user_id, 0) + 1
            return True
        
        # Add current request
        self.user_requests[user_id].append(now)
        return False
    
    def is_user_blocked(self, user_id: int) -> bool:
        """Check if user is blocked"""
        return user_id in self.blocked_users
    
    def block_user_temporarily(self, user_id: int, duration: Optional[int] = None):
        """Block user temporarily"""
        if duration is None:
            duration = self.block_duration
        
        self.blocked_users.add(user_id)
        # In a real implementation, you'd want to store this in database with expiration
    
    def unblock_user(self, user_id: int):
        """Unblock user"""
        self.blocked_users.discard(user_id)
        if user_id in self.suspicious_activities:
            del self.suspicious_activities[user_id]
    
    def detect_spam_content(self, message: str) -> bool:
        """Detect spam content using patterns"""
        for pattern in self.spam_patterns:
            if re.search(pattern, message):
                return True
        return False
    
    def validate_transaction_amount(self, amount: int, user_verified: bool = False) -> tuple[bool, str]:
        """Validate transaction amount"""
        if amount <= 0:
            return False, "مبلغ باید مثبت باشد"
        
        max_amount = self.transaction_limits['verified_user_max'] if user_verified else self.transaction_limits['new_user_max']
        
        if amount > max_amount:
            return False, f"حداکثر مبلغ مجاز: {max_amount:,} تومان"
        
        if amount > self.transaction_limits['daily_limit']:
            return False, f"حداکثر مبلغ روزانه: {self.transaction_limits['daily_limit']:,} تومان"
        
        return True, "مبلغ معتبر است"
    
    def validate_user_input(self, text: str, max_length: int = 500) -> tuple[bool, str]:
        """Validate user input"""
        if not text or not text.strip():
            return False, "متن نمی‌تواند خالی باشد"
        
        if len(text) > max_length:
            return False, f"حداکثر طول مجاز: {max_length} کاراکتر"
        
        # Check for suspicious patterns
        if self.detect_spam_content(text):
            return False, "محتوای مشکوک تشخیص داده شد"
        
        # Check for excessive special characters
        special_char_ratio = sum(1 for c in text if not c.isalnum() and not c.isspace()) / len(text)
        if special_char_ratio > 0.3:
            return False, "تعداد کاراکترهای خاص زیاد است"
        
        return True, "متن معتبر است"
    
    def log_security_event(self, event_type: str, user_id: int, details: str):
        """Log security events"""
        timestamp = datetime.now().isoformat()
        print(f"[SECURITY] {timestamp} - {event_type} - User {user_id}: {details}")
        # In a real implementation, save to database or external logging service

def security_check(require_auth: bool = True):
    """Decorator for security checks"""
    def decorator(func):
        @wraps(func)
        def wrapper(update, context, *args, **kwargs):
            user_id = update.effective_user.id
            security_manager = context.bot_data.get('security_manager')
            
            if not security_manager:
                return
            
            # Check if user is blocked
            if security_manager.is_user_blocked(user_id):
                update.message.reply_text("⛔ شما موقتاً مسدود شده‌اید. لطفاً بعداً تلاش کنید.")
                return
            
            # Check rate limiting
            if security_manager.is_rate_limited(user_id):
                update.message.reply_text("⚠️ تعداد درخواست‌های شما زیاد است. لطفاً کمی صبر کنید.")
                security_manager.log_security_event("RATE_LIMITED", user_id, "Too many requests")
                return
            
            # Check if user exists in database (if auth required)
            if require_auth:
                db = context.bot_data.get('database')
                user = db.get_user(user_id) if db else None
                if not user:
                    update.message.reply_text("❌ ابتدا باید در ربات ثبت‌نام کنید. /start را فشار دهید.")
                    return
                
                if user.is_banned:
                    update.message.reply_text("⛔ حساب کاربری شما مسدود شده است.")
                    security_manager.log_security_event("BANNED_USER_ACCESS", user_id, "Banned user tried to access")
                    return
            
            return func(update, context, *args, **kwargs)
        return wrapper
    return decorator

class InputSanitizer:
    """Input sanitization utilities"""
    
    @staticmethod
    def sanitize_text(text: str) -> str:
        """Sanitize text input"""
        if not text:
            return ""
        
        # Remove potentially dangerous characters
        text = re.sub(r'[<>{}[\]\\]', '', text)
        
        # Normalize whitespace
        text = ' '.join(text.split())
        
        # Limit length
        return text[:1000]
    
    @staticmethod
    def sanitize_amount(amount_str: str) -> Optional[int]:
        """Sanitize and validate amount input"""
        if not amount_str:
            return None
        
        # Remove non-numeric characters except comma and period
        amount_str = re.sub(r'[^\d,.]', '', amount_str)
        
        # Replace comma with empty string (Persian number format)
        amount_str = amount_str.replace(',', '')
        
        try:
            amount = int(float(amount_str))
            return amount if amount > 0 else None
        except (ValueError, TypeError):
            return None
    
    @staticmethod
    def validate_username(username: str) -> bool:
        """Validate username format"""
        if not username:
            return False
        
        # Remove @ if present
        username = username.lstrip('@')
        
        # Check format: 5-32 characters, alphanumeric and underscores
        pattern = r'^[a-zA-Z0-9_]{5,32}$'
        return bool(re.match(pattern, username))

class EncryptionManager:
    """Simple encryption for sensitive data"""
    
    def __init__(self, key: Optional[str] = None):
        self.key = key or secrets.token_urlsafe(32)
    
    def encrypt_data(self, data: str) -> str:
        """Simple XOR encryption (for demo purposes - use proper encryption in production)"""
        key_bytes = self.key.encode()
        data_bytes = data.encode()
        
        encrypted = bytearray()
        for i, byte in enumerate(data_bytes):
            encrypted.append(byte ^ key_bytes[i % len(key_bytes)])
        
        return encrypted.hex()
    
    def decrypt_data(self, encrypted_hex: str) -> str:
        """Simple XOR decryption"""
        try:
            encrypted_bytes = bytes.fromhex(encrypted_hex)
            key_bytes = self.key.encode()
            
            decrypted = bytearray()
            for i, byte in enumerate(encrypted_bytes):
                decrypted.append(byte ^ key_bytes[i % len(key_bytes)])
            
            return decrypted.decode()
        except Exception:
            return ""
