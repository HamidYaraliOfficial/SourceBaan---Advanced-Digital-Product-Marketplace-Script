# -*- coding: utf-8 -*-
"""
Advanced Intermediary Bot Configuration
"""

import os
from typing import List, Dict

class Config:
    # Bot Configuration
    BOT_TOKEN = "8406601899:AAFTqN0Euk5xhtCdncpxjrJRgyK7YYCIYYI"  # Replace with your bot token
    BOT_USERNAME = "VaseteGarbot"
    
    # Admin Configuration
    MAIN_ADMIN_ID = 7135477742  # Replace with main admin's Telegram user ID
    SUB_ADMINS = [
        # Add sub-admin IDs here
        # 987654321,
        # 111222333,
    ]
    
    # Mediator Configuration
    MEDIATOR_ADMINS = [
        # Add mediator admin IDs here - these admins handle intermediary requests
        7135477742,  # Main admin is also a mediator
        # 444555666,
        # 777888999,
    ]
    
    # Database Configuration
    DATABASE_PATH = "intermediary_bot.db"
    
    # Bot Settings
    COMMISSION_RATE = 0.03  # 3% commission
    MIN_TRANSACTION_AMOUNT = 10000  # Minimum transaction amount (in Toman)
    MAX_TRANSACTION_AMOUNT = 100000000  # Maximum transaction amount (in Toman)
    
    # Security Settings
    MAX_PENDING_TRANSACTIONS_PER_USER = 3
    TRANSACTION_TIMEOUT_HOURS = 24
    
    # Channels and Groups
    CHANNEL_ID = None  # Optional: Channel for announcements
    LOG_GROUP_ID = None  # Optional: Group for logging
    
    # Glass UI Theme Colors (Hex)
    GLASS_THEME = {
        'primary': '#6366f1',
        'secondary': '#8b5cf6',
        'success': '#10b981',
        'warning': '#f59e0b',
        'danger': '#ef4444',
        'info': '#06b6d4'
    }
    
    # Messages Configuration
    WELCOME_MESSAGE = """
🤝 به ربات واسطه‌گری خالص خوش آمدید!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                🛡️ ربات واسطه‌گری امن                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔮 **چگونه کار می‌کنیم:**
1️⃣ شما درخواست واسطه‌گری می‌دهید
2️⃣ ادمین فایل/محصول را بررسی می‌کند
3️⃣ خریدار معرفی و قیمت تعیین می‌شود
4️⃣ خریدار وجه را پرداخت می‌کند
5️⃣ شما محصول را تحویل می‌دهید
6️⃣ نظرسنجی و امتیازدهی انجام می‌شود

🛡️ **تضمینات ما:**
• 💰 نگهداری امن وجه تا تحویل کامل
• ✅ تضمین 100% برگشت در صورت مشکل
• 🤝 واسطه‌گری حرفه‌ای توسط ادمین
• 🔒 حفاظت کامل از اطلاعات طرفین
• ⚡ پردازش سریع و شفاف

💎 **ویژگی‌های خاص:**
• 🎯 کارمزد منصفانه 3%
• ⭐ سیستم امتیازدهی شیشه‌ای
• 📞 پشتیبانی 24 ساعته
• 🔄 فرآیند کاملاً شفاف

🚀 برای شروع واسطه‌گری، دکمه زیر را بزنید!
"""
    
    HELP_MESSAGE = """
🤝 راهنمای کامل ربات واسطه‌گری خالص

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                📖 راهنمای کامل سیستم                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🎯 **هدف ربات:**
این ربات صرفاً برای واسطه‌گری امن بین فروشنده و خریدار طراحی شده است.

📋 **فرآیند کامل واسطه‌گری:**

👤 **برای فروشندگان:**
1️⃣ کلیک روی "🤝 درخواست واسطه‌گری"
2️⃣ وارد کردن عنوان محصول (حداقل 5 کاراکتر)
3️⃣ نوشتن توضیحات کامل (20-500 کاراکتر)
4️⃣ تعیین قیمت پیشنهادی (حداقل {Config.MIN_TRANSACTION_AMOUNT:,} تومان)
5️⃣ تایید نهایی و ارسال درخواست
6️⃣ انتظار بررسی توسط ادمین

👨‍💼 **نقش ادمین:**
• بررسی دقیق محصولات و درخواست‌ها
• تایید یا رد درخواست‌ها
• جستجو و پیدا کردن خریدار مناسب
• تعیین قیمت نهایی
• نظارت بر تمام مراحل معامله

💰 **سیستم پرداخت:**
• خریدار ابتدا وجه را به ادمین پرداخت می‌کند
• ادمین وجه را نگهداری می‌کند
• پس از تحویل کامل، وجه به فروشنده پرداخت می‌شود
• کارمزد: {Config.COMMISSION_RATE*100}% از مبلغ کل

🛡️ **تضمینات امنیتی:**
✅ بررسی دقیق توسط ادمین
✅ نگهداری امن وجه
✅ تضمین تحویل یا برگشت وجه
✅ پیگیری کامل فرآیند
✅ حل اختلافات

⭐ **سیستم امتیازدهی:**
• پس از هر معامله، امتیازدهی متقابل
• ایجاد اعتبار برای کاربران
• شفافیت کامل در نظرات

📞 **پشتیبانی:**
• پاسخگویی 24 ساعته
• حل سریع مشکلات
• راهنمایی در تمام مراحل

💡 **نکات مهم:**
• فقط محصولات قانونی قابل فروش است
• قیمت‌گذاری منطقی ضروری است
• توضیحات کامل و صادقانه ارائه دهید
• از سوءاستفاده خودداری کنید

🚀 **شروع کار:**
برای شروع، روی "🤝 درخواست واسطه‌گری" کلیک کنید!
"""

# Environment variables override
if os.getenv('BOT_TOKEN'):
    Config.BOT_TOKEN = os.getenv('BOT_TOKEN')
if os.getenv('MAIN_ADMIN_ID'):
    Config.MAIN_ADMIN_ID = int(os.getenv('MAIN_ADMIN_ID'))
