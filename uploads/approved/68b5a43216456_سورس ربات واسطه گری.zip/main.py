# -*- coding: utf-8 -*-
"""
Advanced Intermediary Bot - Main Application
ربات واسطه‌گری پیشرفته
"""

import asyncio
import signal
import sys
from datetime import datetime
from telegram import Update, BotCommand, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, 
    CommandHandler, 
    CallbackQueryHandler, 
    MessageHandler, 
    ConversationHandler,
    filters
)
from telegram.ext import ContextTypes

# Import our modules
from config import Config
from database import Database, UserRole
from security import SecurityManager, security_check
from ui_components import GlassUI, MessageFormatter
from admin_system import AdminSystem
from intermediary_system import IntermediarySystem, TransactionStep
from mediator_system import MediatorSystem
# from intermediary_flow import IntermediaryFlow  # Removed - implementing directly
from logging_system import logger, performance_monitor

class IntermediaryBot:
    """Main bot application class"""
    
    def __init__(self):
        self.db = Database(Config.DATABASE_PATH)
        self.security = SecurityManager()
        self.admin_system = AdminSystem(self.db, self.security)
        self.intermediary = IntermediarySystem(self.db, self.security)
        self.mediator_system = MediatorSystem(self.db, self.security)
        # Initialize intermediary requests storage
        self.intermediary_requests = {}
        
        # Initialize intermediary groups storage
        self.intermediary_groups = {}
        
        # Initialize active mediator conversations
        self.active_mediator_conversations = {}
        # Format: {mediator_id: {target_user_id: conversation_data}}
        
        # Bot application
        self.application = None
        
        # Startup time
        self.startup_time = datetime.now()
        
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        user_id = user.id
        
        # Track performance
        operation_id = f"start_{user_id}_{datetime.now().timestamp()}"
        performance_monitor.start_operation(operation_id)
        performance_monitor.track_user_activity(user_id)
        
        # Check if user exists
        db_user = self.db.get_user(user_id)
        
        if not db_user:
            # Create new user
            role = UserRole.MAIN_ADMIN if self.admin_system.is_main_admin(user_id) else \
                   UserRole.SUB_ADMIN if self.admin_system.is_sub_admin(user_id) else \
                   UserRole.USER
            
            success = self.db.create_user(
                user_id=user_id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                role=role
            )
            
            if success:
                logger.user_action("USER_REGISTERED", user_id, username=user.username, role=role.value)
                welcome_type = "new_user"
            else:
                logger.error("USER_REGISTRATION_FAILED", user_id)
                await update.message.reply_text("❌ خطا در ثبت‌نام! لطفاً مجدداً تلاش کنید.")
                return
        else:
            # Update user info if changed
            if (db_user.username != user.username or 
                db_user.first_name != user.first_name or 
                db_user.last_name != user.last_name):
                # In a real implementation, you'd update user info here
                pass
            
            logger.user_action("USER_START", user_id, username=user.username)
            welcome_type = "returning_user"
        
        # Send welcome message
        welcome_message = self.get_welcome_message(welcome_type, user.first_name)
        keyboard = GlassUI.main_menu()
        
        await update.message.reply_text(
            welcome_message,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
        
        performance_monitor.end_operation(operation_id, "START_COMMAND", user_id)
    
    def get_welcome_message(self, welcome_type: str, first_name: str) -> str:
        """Get personalized welcome message"""
        if welcome_type == "new_user":
            return f"""
🎉 سلام {first_name} عزیز!

{Config.WELCOME_MESSAGE}

🔰 حساب شما با موفقیت ایجاد شد!
"""
        else:
            return f"""
👋 سلام مجدد {first_name}!

🔮 به ربات واسطه‌گری پیشرفته خوش برگشتید!

📊 وضعیت حساب شما:
• ✅ فعال و تایید شده
• 🛡️ سطح امنیت: بالا
• ⭐ آماده انجام معاملات امن

👇 لطفاً گزینه مورد نظر را انتخاب کنید:
"""
    
    @security_check(require_auth=True)
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        user_id = update.effective_user.id
        logger.user_action("HELP_REQUESTED", user_id)
        
        keyboard = GlassUI.back_button()
        
        await update.message.reply_text(
            Config.HELP_MESSAGE,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    @security_check(require_auth=True)
    async def profile_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /profile command"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if user:
            # Get user statistics (placeholder)
            stats = {'transactions': 0, 'success_rate': 0}
            
            message = MessageFormatter.format_user_profile(user, stats)
            keyboard = GlassUI.back_button()
            
            await update.message.reply_text(
                message,
                reply_markup=keyboard,
                parse_mode='Markdown'
            )
            
            logger.user_action("PROFILE_VIEWED", user_id)
    
    async def admin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /admin command"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.message.reply_text("⛔ شما دسترسی ادمین ندارید!")
            logger.security_event("UNAUTHORIZED_ADMIN_ACCESS", user_id)
            return
        
        logger.admin_action("ADMIN_PANEL_ACCESSED", user_id)
        await self.admin_system.show_admin_panel(update, context)
    
    async def mediator_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /mediator command"""
        user_id = update.effective_user.id
        
        if not self.mediator_system.is_mediator(user_id):
            await update.message.reply_text("⛔ شما دسترسی واسطه‌گر ندارید!")
            logger.security_event("UNAUTHORIZED_MEDIATOR_ACCESS", user_id)
            return
        
        logger.admin_action("MEDIATOR_DASHBOARD_ACCESSED", user_id)
        await self.mediator_system.show_mediator_dashboard(update, context)
    
    async def join_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /join command"""
        if not context.args:
            await update.message.reply_text("""
❌ نحوه استفاده صحیح:
`/join کد_عضویت`

💡 مثال:
`/join ABC12345`

🔑 کد عضویت را از فروشنده دریافت کنید.
""", parse_mode='Markdown')
            return
        
        join_code = context.args[0].strip().upper()
        await self.handle_join_command(update, context, join_code)
    
    async def handle_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries with timeout protection"""
        query = update.callback_query
        user_id = update.effective_user.id
        data = query.data
        
        # Track performance
        operation_id = f"callback_{user_id}_{datetime.now().timestamp()}"
        performance_monitor.start_operation(operation_id)
        
        logger.user_action("CALLBACK_QUERY", user_id, callback_data=data)
        
        # Answer the callback query immediately to prevent timeout
        try:
            await query.answer()
        except Exception as e:
            logger.error("CALLBACK_ANSWER_FAILED", user_id=user_id, error=str(e))
        
        try:
            # Route to appropriate handler
            if data == "main_menu":
                await self.show_main_menu(update, context)
            elif data == "sell_product":
                await self.intermediary.start_selling_process(update, context)
            elif data == "buy_product":
                await self.show_available_products(update, context)
            elif data == "my_transactions":
                await self.show_user_transactions(update, context)
            elif data == "my_profile":
                await self.show_user_profile(update, context)
            elif data == "help":
                await self.show_help(update, context)
            elif data == "support":
                await self.show_support_info(update, context)
            elif data == "bot_stats":
                await self.show_bot_statistics(update, context)
            # Handle intermediary admin callbacks first (more specific)
            elif data.startswith("admin_review_"):
                await self.handle_admin_review(update, context, data)
            elif data.startswith("admin_files_"):
                await self.handle_admin_files(update, context, data)
            elif data.startswith("admin_approve_"):
                await self.handle_admin_approve(update, context, data)
            elif data.startswith("admin_reject_"):
                await self.handle_admin_reject(update, context, data)
            elif data.startswith("admin_chat_creator_"):
                await self.handle_admin_chat_creator(update, context, data)
            elif data.startswith("admin_chat_participant_"):
                await self.handle_admin_chat_participant(update, context, data)
            elif data.startswith("admin_join_group_"):
                await self.handle_admin_join_group(update, context, data)
            elif data.startswith("admin_get_files_"):
                await self.handle_admin_get_files(update, context, data)
            elif data.startswith("admin_group_details_"):
                await self.handle_admin_group_details(update, context, data)
            elif data.startswith("admin_payment_manage_"):
                await self.handle_admin_payment_manage(update, context, data)
            elif data.startswith("admin_complete_transaction_"):
                await self.handle_admin_complete_transaction(update, context, data)
            elif data.startswith("admin_cancel_transaction_"):
                await self.handle_admin_cancel_transaction(update, context, data)
            # General admin callbacks (less specific)
            elif data.startswith("admin_"):
                await self.admin_system.handle_admin_callback(update, context)
            elif data.startswith(("join_transaction_", "confirm_payment_", "mark_sent_")):
                await self.intermediary.handle_intermediary_callbacks(update, context)
            elif data in ["request_mediation", "mediator_dashboard", "my_mediations", "new_mediations", "mediator_stats", "mediator_settings", "my_mediation_requests", "intermediary_requests", "intermediary_details"] or data.startswith(("mediation_", "priority_", "accept_mediation_", "reject_mediation_", "mediation_type_", "mediation_details_", "contact_requester_", "transfer_mediation_", "resolve_mediation_", "escalate_mediation_", "message_user_", "user_contact_", "mediation_status_", "intermediary_detail_", "contact_buyer_", "contact_seller_", "choose_contact_user_")):
                # Check if mediator is ending a conversation by clicking dashboard
                if data == "mediator_dashboard" and 'mediator_conversation' in context.user_data:
                    await self.end_mediator_conversation_via_callback(update, context)
                else:
                    # Ensure the mediator system has access to the main bot instance
                    context.bot_data['main_bot'] = self
                    await self.mediator_system.handle_mediator_callbacks(update, context)
            elif data.startswith(("broadcast_", "confirm_broadcast_")):
                await self.handle_broadcast_callbacks(update, context)
            elif data.startswith("confirm_remove_mediator_"):
                await self.handle_remove_mediator(update, context)
            elif data in ["gaming_accounts", "premium_accounts", "charge_codes", "gift_cards", "virtual_services", "crypto_vouchers", "irancell_charge"]:
                await self.handle_product_category(update, context, data)
            elif data.startswith("buy_"):
                await self.handle_product_purchase(update, context, data)
            elif data == "request_intermediary":
                await self.start_intermediary_request(update, context)
            elif data == "continue_intermediary_request":
                await self.continue_intermediary_request(update, context)
            elif data == "my_intermediary_requests":
                await self.show_my_intermediary_requests(update, context)
            elif data == "no_files":
                await self.handle_no_files(update, context)
            elif data == "files_complete":
                await self.handle_files_complete(update, context)
            elif data == "confirm_intermediary_request":
                await self.confirm_intermediary_request(update, context)
            elif data == "ratings_reviews":
                await self.show_ratings_reviews(update, context)
            elif data == "create_group":
                await self.create_intermediary_group(update, context)
            elif data == "join_group":
                await self.show_join_group(update, context)
            elif data.startswith("join_group_"):
                await self.join_intermediary_group(update, context, data)
            else:
                await query.answer("🔄 در حال پردازش...", show_alert=False)
                return
            
            # Only answer if we haven't already answered in the handler
            try:
                await query.answer()
            except Exception:
                pass  # Already answered
            
        except Exception as e:
            logger.error("CALLBACK_QUERY_ERROR", user_id, error=str(e), callback_data=data)
            await query.answer("❌ خطایی رخ داد! لطفاً مجدداً تلاش کنید.", show_alert=True)
        
        performance_monitor.end_operation(operation_id, "CALLBACK_QUERY", user_id)
    
    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show main menu"""
        keyboard = GlassUI.main_menu()
        
        message = """
🔮 منوی اصلی ربات واسطه‌گری

✨ خدمات ما:
• 🛡️ واسطه‌گری کاملاً امن
• ⚡ پردازش سریع معاملات  
• 💰 کارمزد منصفانه
• 📞 پشتیبانی 24 ساعته

👇 لطفاً گزینه مورد نظر را انتخاب کنید:
"""
        
        await update.callback_query.edit_message_text(
            message, reply_markup=keyboard, parse_mode='Markdown'
        )
    
    async def show_available_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show available products for purchase"""
        # Get pending transactions
        # This is a simplified implementation
        message = """
🛒 محصولات موجود برای خرید

🔍 در حال جستجو برای معاملات موجود...

⚠️ این بخش در حال توسعه است.
به زودی لیست کامل محصولات و خدمات در دسترس قرار می‌گیرد.

📞 برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.
"""
        
        keyboard = GlassUI.back_button()
        
        await update.callback_query.edit_message_text(
            message, reply_markup=keyboard, parse_mode='Markdown'
        )
    
    async def show_user_transactions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user's transactions"""
        user_id = update.effective_user.id
        transactions = self.db.get_user_transactions(user_id)
        
        if not transactions:
            message = """
📊 معاملات شما

📋 شما هنوز هیچ معامله‌ای ندارید.

💡 برای شروع:
• روی "💰 فروش محصول" کلیک کنید تا معامله جدید ایجاد کنید
• یا از بخش "🛒 خرید محصول" محصولی انتخاب کنید

🎯 ربات آماده خدمت‌رسانی به شماست!
"""
        else:
            message = f"""
📊 معاملات شما

📈 آمار کلی:
• کل معاملات: {len(transactions)}
• معاملات فعال: {len([t for t in transactions if t.status.value in ['pending', 'seller_confirmed', 'buyer_paid']])}
• معاملات تکمیل شده: {len([t for t in transactions if t.status.value == 'completed'])}

📋 معاملات اخیر:
"""
            
            # Show recent transactions (simplified)
            for i, transaction in enumerate(transactions[:5]):
                status_emoji = {
                    'pending': '🟡',
                    'seller_confirmed': '🔵', 
                    'buyer_paid': '🟠',
                    'completed': '🟢',
                    'cancelled': '🔴'
                }
                
                emoji = status_emoji.get(transaction.status.value, '🔘')
                message += f"\n{emoji} {transaction.title[:30]}... - {transaction.amount:,} تومان"
        
        keyboard = [
            [InlineKeyboardButton("🔍 جزئیات معاملات", callback_data="transaction_details")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_user_profile(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user profile"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if user:
            stats = {}  # Placeholder for user stats
            message = MessageFormatter.format_user_profile(user, stats)
            keyboard = GlassUI.back_button()
            
            await update.callback_query.edit_message_text(
                message, reply_markup=keyboard, parse_mode='Markdown'
            )
    
    async def show_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show help information"""
        keyboard = GlassUI.back_button()
        
        await update.callback_query.edit_message_text(
            Config.HELP_MESSAGE, reply_markup=keyboard, parse_mode='Markdown'
        )
    
    async def show_support_info(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show support information"""
        message = """
📞 اطلاعات پشتیبانی

🛠️ راه‌های تماس:
• 📱 تلگرام: @support_username
• 📧 ایمیل: support@example.com
• ☎️ تلفن: 021-12345678

⏰ ساعات پاسخگویی:
• شنبه تا چهارشنبه: 9:00 - 18:00
• پنج‌شنبه: 9:00 - 13:00
• جمعه: تعطیل

🚀 پاسخگویی سریع:
• چت آنلاین: کمتر از 5 دقیقه
• ایمیل: حداکثر 2 ساعت
• تلفن: فوری

💡 قبل از تماس:
• کد معامله را آماده داشته باشید
• توضیح کاملی از مشکل ارائه دهید
• اسکرین‌شات مفید را ضمیمه کنید
"""
        
        keyboard = GlassUI.back_button()
        
        await update.callback_query.edit_message_text(
            message, reply_markup=keyboard, parse_mode='Markdown'
        )
    
    async def show_bot_statistics(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show bot statistics"""
        stats = self.db.get_statistics()
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                📊 آمار ربات واسطه‌گری                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👥 **کاربران:** {stats['total_users']:,} نفر
💼 **معاملات:** {stats['total_transactions']:,} مورد
✅ **معاملات موفق:** {stats['completed_transactions']:,} مورد
📈 **نرخ موفقیت:** {stats['success_rate']:.1f}%

💰 **حجم معاملات:** {stats['total_volume']:,} تومان
💳 **درآمد کارمزد:** {stats['total_commission']:,} تومان

🛒 **محصولات فعال:** {stats.get('total_products', 0):,} مورد
📦 **سفارشات:** {stats.get('total_orders', 0):,} مورد
🤝 **درخواست‌های واسطه‌گری:** {stats.get('total_mediation_requests', 0):,} مورد

🔮 ربات واسطه‌گری پیشرفته
🛡️ امن • سریع • قابل اعتماد

زمان آنلاین: {(datetime.now() - self.startup_time).total_seconds() / 3600:.1f} ساعت

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
"""
        
        keyboard = [
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="bot_stats")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        logger.user_action("MESSAGE_RECEIVED", user_id, message=message_text[:100])
        
        # /join command is now handled by CommandHandler
        
        # Check if user is in intermediary request flow
        if 'intermediary_request' in context.user_data:
            step = context.user_data['intermediary_request'].get('step')
            
            if step == 'title':
                return await self.handle_title_input(update, context)
            elif step == 'description':
                return await self.handle_description_input(update, context)
            elif step == 'price':
                return await self.handle_price_input(update, context)
            elif step == 'files':
                return await self.handle_file_input(update, context)
        
        # Check if user is in a conversation state
        if 'new_transaction' in context.user_data:
            # Handle transaction creation flow
            step = context.user_data['new_transaction'].get('step')
            
            if step == TransactionStep.TITLE:
                return await self.intermediary.handle_title_input(update, context)
            elif step == TransactionStep.DESCRIPTION:
                return await self.intermediary.handle_description_input(update, context)
            elif step == TransactionStep.AMOUNT:
                return await self.intermediary.handle_amount_input(update, context)
        
        # Check if user is in mediation request flow
        if 'mediation_request' in context.user_data:
            step = context.user_data['mediation_request'].get('step')
            
            if step == 'title':
                return await self.mediator_system.handle_title_input(update, context)
            elif step == 'description':
                return await self.mediator_system.handle_description_input(update, context)
        
        # Check if admin is in chat mode
        if 'admin_chat_target' in context.user_data:
            return await self.handle_admin_chat_message(update, context)
        
        # Check for /cancel command to end mediator conversation
        if message_text == '/cancel' and 'mediator_conversation' in context.user_data:
            return await self.end_mediator_conversation(update, context)
        
        # Check if mediator is in conversation mode
        if 'mediator_conversation' in context.user_data:
            return await self.handle_mediator_chat_message(update, context)
        
        # Check if user is replying to mediator
        if self.is_user_in_mediator_conversation(user_id, message_text):
            return await self.handle_user_reply_to_mediator(update, context)
        
        # Check if admin is in management flow
        if 'admin_action' in context.user_data:
            action = context.user_data['admin_action']
            
            if action == 'add_mediator':
                return await self.handle_add_mediator_input(update, context)
            elif action == 'broadcast_message':
                return await self.handle_broadcast_input(update, context)
        
        # Default response for unhandled messages
        await update.message.reply_text(
            "🤖 لطفاً از منوی ربات استفاده کنید.\n\n" +
            "برای مشاهده منو: /start\n" +
            "برای راهنما: /help"
        )
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors"""
        error = context.error
        user_id = update.effective_user.id if update and update.effective_user else None
        
        logger.error(
            "BOT_ERROR",
            user_id=user_id,
            error_type=type(error).__name__,
            error_message=str(error),
            update_type=type(update).__name__ if update else None
        )
        
        # Send user-friendly error message
        if update and update.effective_message:
            try:
                await update.effective_message.reply_text(
                    "❌ متأسفانه خطایی رخ داد! \n\n" +
                    "🔄 لطفاً مجدداً تلاش کنید یا با پشتیبانی تماس بگیرید.\n\n" +
                    "📞 پشتیبانی: /support"
                )
            except Exception:
                pass  # Ignore if we can't send error message
    
    def setup_handlers(self):
        """Setup bot handlers"""
        # Create conversation handler for selling process
        selling_conversation = ConversationHandler(
            per_message=False,
            per_chat=True,
            entry_points=[CallbackQueryHandler(
                self.intermediary.start_selling_process, 
                pattern="^sell_product$"
            )],
            states={
                TransactionStep.TITLE: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, self.intermediary.handle_title_input)
                ],
                TransactionStep.DESCRIPTION: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, self.intermediary.handle_description_input)
                ],
                TransactionStep.AMOUNT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, self.intermediary.handle_amount_input)
                ],
                TransactionStep.CONFIRMATION: [
                    CallbackQueryHandler(self.intermediary.confirm_transaction, pattern="^confirm_transaction$")
                ]
            },
            fallbacks=[
                CallbackQueryHandler(self.handle_callback_query, pattern="^cancel_transaction$"),
                CommandHandler("cancel", self.cancel_operation)
            ]
        )
        
        # Add handlers
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("profile", self.profile_command))
        self.application.add_handler(CommandHandler("admin", self.admin_command))
        self.application.add_handler(CommandHandler("mediator", self.mediator_command))
        self.application.add_handler(CommandHandler("join", self.join_command))
        
        # Add conversation handler
        self.application.add_handler(selling_conversation)
        
        # Callback query handler (should be after conversation handlers)
        self.application.add_handler(CallbackQueryHandler(self.handle_callback_query))
        
        # Message handler (should be last)
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
    
    async def cancel_operation(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel current operation"""
        user_id = update.effective_user.id
        logger.user_action("OPERATION_CANCELLED", user_id)
        
        # Check if admin was in chat mode
        if 'admin_chat_target' in context.user_data:
            group_id = context.user_data.get('admin_chat_group')
            target_name = context.user_data.get('admin_chat_name', 'کاربر')
            
            # Clear chat data
            context.user_data.pop('admin_chat_target', None)
            context.user_data.pop('admin_chat_name', None)
            context.user_data.pop('admin_chat_group', None)
            
            await update.message.reply_text(
                f"💬 چت با {target_name} پایان یافت.\n\n"
                f"🔙 بازگشت به مدیریت گروه...",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📋 جزئیات گروه", callback_data=f"admin_group_details_{group_id}")],
                    [InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")]
                ])
            )
            return
        
        # Clear user data
        context.user_data.clear()
        
        await update.message.reply_text(
            "❌ عملیات لغو شد.\n\n🏠 بازگشت به منوی اصلی...",
            reply_markup=GlassUI.main_menu()
        )
        
        return ConversationHandler.END
    
    async def handle_add_mediator_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle mediator ID input from admin"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Check if user is main admin
        if not self.admin_system.is_main_admin(user_id):
            await update.message.reply_text("⛔ شما دسترسی لازم ندارید!")
            context.user_data.pop('admin_action', None)
            return
        
        # Validate input
        try:
            mediator_id = int(message_text.strip())
        except ValueError:
            await update.message.reply_text("❌ لطفاً شناسه عددی معتبر وارد کنید:")
            return
        
        # Check if user exists in database
        user = self.db.get_user(mediator_id)
        if not user:
            await update.message.reply_text(
                f"❌ کاربری با شناسه {mediator_id} در ربات یافت نشد!\n\n" +
                "ابتدا کاربر باید از ربات استفاده کرده باشد."
            )
            return
        
        # Check if already a mediator
        from config import Config
        if mediator_id in Config.MEDIATOR_ADMINS:
            await update.message.reply_text(f"⚠️ {user.first_name} قبلاً واسطه‌گر است!")
            return
        
        # Add to mediators list (in real implementation, save to database/config)
        Config.MEDIATOR_ADMINS.append(mediator_id)
        
        # Update user role in database
        self.db.update_user_role(mediator_id, UserRole.USER)  # In real implementation, add MEDIATOR role
        
        # Send success message
        await update.message.reply_text(
            f"✅ {user.first_name} با موفقیت به عنوان واسطه‌گر اضافه شد!\n\n" +
            f"📋 اطلاعات:\n" +
            f"• نام: {user.first_name} {user.last_name or ''}\n" +
            f"• نام کاربری: @{user.username or 'ندارد'}\n" +
            f"• شناسه: {mediator_id}\n\n" +
            f"🎯 کاربر می‌تواند از دستور /mediator استفاده کند.",
            reply_markup=GlassUI.admin_menu(True)
        )
        
        # Notify the new mediator
        try:
            await context.bot.send_message(
                chat_id=mediator_id,
                text=f"🎉 تبریک! شما به عنوان واسطه‌گر ربات انتخاب شدید!\n\n" +
                     f"✨ دسترسی‌های جدید شما:\n" +
                     f"• استفاده از دستور /mediator\n" +
                     f"• دریافت درخواست‌های واسطه‌گری\n" +
                     f"• دسترسی به داشبورد واسطه‌گری\n\n" +
                     f"📖 برای راهنمای کامل: /help"
            )
        except Exception as e:
            logger.error("MEDIATOR_NOTIFICATION_FAILED", mediator_id=mediator_id, error=str(e))
        
        # Log the action
        logger.admin_action("MEDIATOR_ADDED", user_id, new_mediator_id=mediator_id, mediator_name=user.first_name)
        
        # Clear admin action
        context.user_data.pop('admin_action', None)
    
    async def handle_broadcast_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle broadcast message input from admin"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Check admin permission
        if not self.admin_system.has_permission(user_id, 'broadcast_messages'):
            await update.message.reply_text("⛔ شما دسترسی لازم ندارید!")
            context.user_data.pop('admin_action', None)
            return
        
        # Validate message
        if not message_text or len(message_text.strip()) < 10:
            await update.message.reply_text("❌ پیام باید حداقل 10 کاراکتر باشد. مجدداً ارسال کنید:")
            return
        
        if len(message_text) > 1000:
            await update.message.reply_text("❌ پیام نباید بیش از 1000 کاراکتر باشد. مجدداً ارسال کنید:")
            return
        
        # Get broadcast type from context
        broadcast_type = context.user_data.get('broadcast_type', 'all_users')
        
        # Show confirmation
        preview_message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                📢 پیش‌نمایش پیام همگانی                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📋 **مخاطبان:** {self.get_broadcast_audience_name(broadcast_type)}
📊 **تعداد:** {self.get_broadcast_audience_count(broadcast_type)} نفر

📝 **پیام:**
{message_text}

⚠️ آیا می‌خواهید این پیام ارسال شود؟
"""
        
        keyboard = [
            [
                InlineKeyboardButton("✅ تایید و ارسال", callback_data=f"confirm_broadcast_{broadcast_type}"),
                InlineKeyboardButton("❌ لغو", callback_data="admin_panel")
            ],
            [InlineKeyboardButton("✏️ ویرایش پیام", callback_data="edit_broadcast")]
        ]
        
        await update.message.reply_text(
            preview_message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
        
        # Store message for later use
        context.user_data['broadcast_message'] = message_text
    
    def get_broadcast_audience_name(self, broadcast_type: str) -> str:
        """Get audience name for broadcast"""
        names = {
            'all_users': 'همه کاربران',
            'admins': 'ادمین‌ها',
            'mediators': 'واسطه‌گران',
            'active_users': 'کاربران فعال',
            'targeted': 'کاربران هدف'
        }
        return names.get(broadcast_type, 'نامشخص')
    
    def get_broadcast_audience_count(self, broadcast_type: str) -> int:
        """Get audience count for broadcast"""
        if broadcast_type == 'all_users':
            stats = self.db.get_statistics()
            return stats['total_users']
        elif broadcast_type == 'admins':
            from config import Config
            return len(Config.SUB_ADMINS) + 1
        elif broadcast_type == 'mediators':
            from config import Config
            return len(Config.MEDIATOR_ADMINS)
        else:
            return 0
    
    async def handle_broadcast_callbacks(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle broadcast-related callbacks"""
        query = update.callback_query
        data = query.data
        user_id = update.effective_user.id
        
        if not self.admin_system.has_permission(user_id, 'broadcast_messages'):
            await query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        if data.startswith("broadcast_"):
            broadcast_type = data.replace("broadcast_", "")
            
            # Set broadcast type and ask for message
            context.user_data['broadcast_type'] = broadcast_type
            context.user_data['admin_action'] = 'broadcast_message'
            
            audience_name = self.get_broadcast_audience_name(broadcast_type)
            audience_count = self.get_broadcast_audience_count(broadcast_type)
            
            message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃               📝 ارسال پیام به {audience_name}               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👥 **مخاطبان:** {audience_name}
📊 **تعداد:** {audience_count} نفر

📝 لطفاً پیام مورد نظر خود را ارسال کنید:

💡 **نکات مهم:**
• حداقل 10 کاراکتر
• حداکثر 1000 کاراکتر
• از متن واضح و مفهوم استفاده کنید
• امکان پیش‌نمایش قبل از ارسال

✏️ پیام خود را بنویسید:
"""
            
            keyboard = [[InlineKeyboardButton("❌ لغو", callback_data="admin_panel")]]
            
            await query.edit_message_text(
                message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
            
        elif data.startswith("confirm_broadcast_"):
            broadcast_type = data.replace("confirm_broadcast_", "")
            message_text = context.user_data.get('broadcast_message')
            
            if not message_text:
                await query.answer("❌ پیام یافت نشد!", show_alert=True)
                return
            
            # Execute broadcast
            success_count = await self.execute_broadcast(context, broadcast_type, message_text)
            
            # Show result
            audience_name = self.get_broadcast_audience_name(broadcast_type)
            
            result_message = f"""
✅ پیام با موفقیت ارسال شد!

📊 **نتایج ارسال:**
• مخاطبان: {audience_name}
• ارسال موفق: {success_count} نفر
• زمان ارسال: {datetime.now().strftime('%Y/%m/%d - %H:%M')}

📝 **پیام ارسال شده:**
{message_text[:100]}{'...' if len(message_text) > 100 else ''}

📈 پیام در لاگ‌های سیستم ثبت شد.
"""
            
            keyboard = [
                [InlineKeyboardButton("📊 آمار ارسال", callback_data="broadcast_statistics")],
                [InlineKeyboardButton("🏠 منوی اصلی", callback_data="admin_panel")]
            ]
            
            await query.edit_message_text(
                result_message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
            )
            
            # Clear user data
            context.user_data.pop('broadcast_message', None)
            context.user_data.pop('broadcast_type', None)
            context.user_data.pop('admin_action', None)
            
            # Log the broadcast
            logger.admin_action("BROADCAST_SENT", user_id, 
                               broadcast_type=broadcast_type, 
                               recipients=success_count,
                               message_length=len(message_text))
    
    async def execute_broadcast(self, context: ContextTypes.DEFAULT_TYPE, broadcast_type: str, message_text: str) -> int:
        """Execute the broadcast and return success count"""
        success_count = 0
        
        # Get target user IDs based on broadcast type
        if broadcast_type == 'all_users':
            # In real implementation, get all user IDs from database
            target_users = []  # Placeholder
        elif broadcast_type == 'admins':
            from config import Config
            target_users = [Config.MAIN_ADMIN_ID] + Config.SUB_ADMINS
        elif broadcast_type == 'mediators':
            from config import Config
            target_users = Config.MEDIATOR_ADMINS
        else:
            target_users = []
        
        # Format message with header
        formatted_message = f"""
📢 **پیام از مدیریت ربات**

{message_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 ربات واسطه‌گری پیشرفته
"""
        
        # Send to each user
        for user_id in target_users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=formatted_message,
                    parse_mode='Markdown'
                )
                success_count += 1
                
                # Small delay to avoid rate limiting
                await asyncio.sleep(0.1)
                
            except Exception as e:
                logger.error("BROADCAST_FAILED", user_id=user_id, error=str(e))
        
        return success_count
    
    async def handle_remove_mediator(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle mediator removal confirmation"""
        query = update.callback_query
        data = query.data
        user_id = update.effective_user.id
        
        if not self.admin_system.is_main_admin(user_id):
            await query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        # Extract mediator ID
        mediator_id = int(data.replace("confirm_remove_mediator_", ""))
        
        # Get mediator info
        user = self.db.get_user(mediator_id)
        mediator_name = user.first_name if user else "نامشخص"
        
        # Remove from mediators list
        from config import Config
        if mediator_id in Config.MEDIATOR_ADMINS:
            Config.MEDIATOR_ADMINS.remove(mediator_id)
            
            # Send success message
            await query.edit_message_text(
                f"✅ {mediator_name} از لیست واسطه‌گران حذف شد!\n\n" +
                f"📋 اطلاعات حذف شده:\n" +
                f"• نام: {mediator_name}\n" +
                f"• شناسه: {mediator_id}\n\n" +
                f"⚠️ کاربر دیگر دسترسی به داشبورد واسطه‌گری ندارد.",
                reply_markup=GlassUI.admin_menu(True)
            )
            
            # Notify the removed mediator
            try:
                await context.bot.send_message(
                    chat_id=mediator_id,
                    text=f"📢 اطلاعیه: دسترسی واسطه‌گری شما لغو شد.\n\n" +
                         f"🔒 دیگر نمی‌توانید از دستور /mediator استفاده کنید.\n" +
                         f"📞 برای اطلاعات بیشتر با مدیریت تماس بگیرید."
                )
            except Exception as e:
                logger.error("MEDIATOR_REMOVAL_NOTIFICATION_FAILED", mediator_id=mediator_id, error=str(e))
            
            # Log the action
            logger.admin_action("MEDIATOR_REMOVED", user_id, 
                               removed_mediator_id=mediator_id, 
                               mediator_name=mediator_name)
        else:
            await query.answer("❌ واسطه‌گر یافت نشد!", show_alert=True)
    
    async def handle_product_category(self, update: Update, context: ContextTypes.DEFAULT_TYPE, category: str):
        """Handle product category selection"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        # Category information
        categories = {
            "gaming_accounts": {
                "title": "🎮 اکانت‌های بازی",
                "description": "خرید اکانت‌های بازی معتبر و فعال",
                "products": [
                    "🎯 اکانت PUBG Mobile",
                    "⚔️ اکانت Call of Duty",
                    "🏎️ اکانت Asphalt 9",
                    "⚽ اکانت FIFA Mobile",
                    "🎪 اکانت Clash Royale",
                    "🏰 اکانت Clash of Clans"
                ]
            },
            "premium_accounts": {
                "title": "📧 اکانت‌های پریمیوم",
                "description": "اکانت‌های پریمیوم سرویس‌های مختلف",
                "products": [
                    "🎵 Spotify Premium",
                    "📺 Netflix Premium",
                    "📹 YouTube Premium",
                    "☁️ Google Drive Unlimited",
                    "💼 Office 365",
                    "🎨 Adobe Creative Cloud"
                ]
            },
            "charge_codes": {
                "title": "💳 کد شارژ",
                "description": "کد شارژ اپراتورهای مختلف",
                "products": [
                    "📱 ایرانسل",
                    "📞 همراه اول",
                    "📲 رایتل",
                    "📟 تله کیش",
                    "🌐 شارژ اینترنت",
                    "💸 شارژ رایگان"
                ]
            },
            "gift_cards": {
                "title": "🎁 گیفت کارت",
                "description": "گیفت کارت پلتفرم‌های مختلف",
                "products": [
                    "🍎 iTunes Gift Card",
                    "🎮 Google Play Card",
                    "🛒 Amazon Gift Card",
                    "🎯 Steam Gift Card",
                    "🎪 PlayStation Card",
                    "🎮 Xbox Gift Card"
                ]
            },
            "virtual_services": {
                "title": "🌐 خدمات مجازی",
                "description": "انواع خدمات مجازی و سرور",
                "products": [
                    "🔒 VPN Premium",
                    "🌐 SSL Certificate",
                    "☁️ Virtual Server",
                    "📧 Email Marketing",
                    "📊 Analytics Tools",
                    "💻 Web Hosting"
                ]
            },
            "crypto_vouchers": {
                "title": "💰 رمزارز و ووچر",
                "description": "خرید رمزارز و ووچرهای مختلف",
                "products": [
                    "₿ Bitcoin Voucher",
                    "💎 Ethereum Voucher",
                    "🪙 USDT Voucher",
                    "🎫 Perfect Money",
                    "💳 WebMoney",
                    "🏦 Payeer Voucher"
                ]
            },
            "irancell_charge": {
                "title": "📱 شارژ ایرانسل",
                "description": "شارژ مستقیم ایرانسل با تخفیف ویژه",
                "products": [
                    "📞 شارژ ۱۰ هزار تومان",
                    "📱 شارژ ۲۰ هزار تومان",
                    "📲 شارژ ۵۰ هزار تومان",
                    "🌐 بسته اینترنت ۱ گیگ",
                    "📊 بسته اینترنت ۵ گیگ",
                    "🚀 بسته اینترنت ۱۰ گیگ"
                ]
            }
        }
        
        cat_info = categories.get(category)
        if not cat_info:
            await query.answer("❌ دسته‌بندی یافت نشد!", show_alert=True)
            return
        
        # Create product list message
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              {cat_info['title']}              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📝 **توضیحات:** {cat_info['description']}

🛒 **محصولات موجود:**
"""
        
        # Add products to message
        for i, product in enumerate(cat_info['products'], 1):
            message += f"{i}️⃣ {product}\n"
        
        message += f"""
💰 **قیمت‌ها:** تماس بگیرید
⚡ **تحویل:** فوری تا ۲ ساعت
🛡️ **گارانتی:** تضمین اصالت ۱۰۰%

💎 برای خرید، روی محصول مورد نظر کلیک کنید:
"""
        
        # Create keyboard with products
        keyboard = []
        for i, product in enumerate(cat_info['products']):
            keyboard.append([InlineKeyboardButton(
                f"{i+1}️⃣ {product}", 
                callback_data=f"buy_{category}_{i}"
            )])
        
        keyboard.append([
            InlineKeyboardButton("🔙 بازگشت به منو", callback_data="main_menu")
        ])
        
        await query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Log the category view
        logger.user_action("CATEGORY_VIEWED", user_id, category=category)
    
    async def handle_product_purchase(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle product purchase"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        # Parse the callback data: buy_category_index
        try:
            parts = data.split("_")
            category = parts[1]
            product_index = int(parts[2])
        except (IndexError, ValueError):
            await query.answer("❌ خطا در پردازش درخواست!", show_alert=True)
            return
        
        # Get product info (this would be from database in real implementation)
        product_prices = {
            "gaming_accounts": [50000, 75000, 100000, 60000, 40000, 80000],
            "premium_accounts": [25000, 45000, 30000, 80000, 120000, 200000],
            "charge_codes": [10000, 20000, 50000, 15000, 30000, 0],
            "gift_cards": [100000, 50000, 200000, 150000, 180000, 220000],
            "virtual_services": [35000, 150000, 250000, 80000, 120000, 100000],
            "crypto_vouchers": [500000, 800000, 300000, 400000, 350000, 450000],
            "irancell_charge": [9500, 19000, 47500, 8000, 35000, 78000]
        }
        
        category_names = {
            "gaming_accounts": "🎮 اکانت‌های بازی",
            "premium_accounts": "📧 اکانت‌های پریمیوم", 
            "charge_codes": "💳 کد شارژ",
            "gift_cards": "🎁 گیفت کارت",
            "virtual_services": "🌐 خدمات مجازی",
            "crypto_vouchers": "💰 رمزارز و ووچر",
            "irancell_charge": "📱 شارژ ایرانسل"
        }
        
        prices = product_prices.get(category, [])
        if product_index >= len(prices):
            await query.answer("❌ محصول یافت نشد!", show_alert=True)
            return
        
        price = prices[product_index]
        if price == 0:
            price = "تماس بگیرید"
        else:
            price = f"{price:,} تومان"
        
        # Create purchase confirmation message
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 🛒 تأیید خرید                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📦 **محصول:** {category_names.get(category, 'نامشخص')}
💰 **قیمت:** {price}
🕐 **زمان تحویل:** فوری تا 2 ساعت
🛡️ **گارانتی:** تضمین اصالت 100%

📝 **توضیحات:**
• پس از پرداخت، محصول در حداکثر 2 ساعت تحویل داده می‌شود
• در صورت بروز مشکل، کارمزد 3% اعمال می‌شود
• تمام محصولات دارای گارانتی تعویض هستند

💳 **روش‌های پرداخت:**
• کارت به کارت
• درگاه پرداخت آنلاین
• رمزارز (تخفیف 5%)

⚠️ آیا از خرید این محصول اطمینان دارید؟
"""
        
        keyboard = [
            [
                InlineKeyboardButton("✅ تأیید و خرید", callback_data=f"confirm_purchase_{category}_{product_index}"),
                InlineKeyboardButton("❌ انصراف", callback_data=f"{category}")
            ],
            [
                InlineKeyboardButton("📞 تماس با پشتیبانی", callback_data="support"),
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]
        ]
        
        await query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Log the purchase intent
        logger.user_action("PURCHASE_INTENT", user_id, category=category, product_index=product_index, price=str(price))
    
    async def show_my_intermediary_requests(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user's intermediary requests"""
        user_id = update.effective_user.id
        
        # Get user's requests 
        user_requests = [
            req for req in self.intermediary_requests.values()
            if req['seller_id'] == user_id
        ]
        
        if not user_requests:
            message = """
📋 درخواست‌های واسطه‌گری من

📭 شما هیچ درخواست واسطه‌گری ندارید.

🤝 برای ایجاد درخواست جدید:
• روی دکمه "🤝 درخواست واسطه‌گری" کلیک کنید
• محصول خود را معرفی کنید
• منتظر پیدا شدن خریدار باشید

✨ ما آماده کمک به شما هستیم!
"""
        else:
            message = f"""
📋 درخواست‌های واسطه‌گری من

📊 آمار:
• کل درخواست‌ها: {len(user_requests)}
• در انتظار: {len([r for r in user_requests if r['status'] in ['pending', 'admin_reviewing']])}
• فعال: {len([r for r in user_requests if r['status'] in ['approved', 'looking_for_buyer']])}
• تکمیل شده: {len([r for r in user_requests if r['status'] == 'completed'])}

📋 لیست درخواست‌ها:
"""
            
            status_emojis = {
                'pending': '⏳',
                'approved': '✅',
                'looking_for_buyer': '🔍',
                'buyer_found': '🎯',
                'payment_pending': '💳',
                'payment_received': '✅',
                'delivery_pending': '📦',
                'completed': '🟢',
                'rejected': '🔴',
                'cancelled': '🔴',
                'disputed': '⚠️'
            }
            
            for req in user_requests:
                emoji = status_emojis.get(req['status'], '⚪')
                message += f"{emoji} {req['title'][:25]}... - {req['requested_price']:,} تومان\n"
        
        keyboard = [
            [InlineKeyboardButton("🆕 درخواست جدید", callback_data="request_intermediary")],
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="my_intermediary_requests")],
            [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_ratings_reviews(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show ratings and reviews system"""
        user_id = update.effective_user.id
        
        message = """
⭐ سیستم نظرسنجی و امتیازدهی

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 🌟 امتیازدهی شیشه‌ای                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🔮 **نظام امتیازدهی ما:**
• ⭐⭐⭐⭐⭐ عالی (5 ستاره)
• ⭐⭐⭐⭐ خوب (4 ستاره)  
• ⭐⭐⭐ متوسط (3 ستاره)
• ⭐⭐ ضعیف (2 ستاره)
• ⭐ بسیار ضعیف (1 ستاره)

💎 **ویژگی‌های شیشه‌ای:**
• شفافیت کامل در نظرات
• امتیازدهی دو طرفه (خریدار و فروشنده)
• قابلیت مشاهده تاریخچه امتیازات
• تأثیر بر اعتبار کاربران

📊 **آمار شما:**
• امتیاز کلی: ⭐⭐⭐⭐⭐ (جدید)
• تعداد نظرات: 0
• وضعیت اعتبار: تازه‌کار

🎯 پس از هر معامله، هر دو طرف می‌توانند به یکدیگر امتیاز دهند.
"""
        
        keyboard = [
            [InlineKeyboardButton("📊 نظرات درباره من", callback_data="my_reviews")],
            [InlineKeyboardButton("✍️ نظرات داده شده", callback_data="given_reviews")],
            [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def handle_admin_review(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin review of intermediary request"""
        user_id = update.effective_user.id
        
        # Debug removed
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        request_id = data.replace("admin_review_", "")
        request = self.intermediary_requests.get(request_id)
        
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        files_info = "📁 بدون فایل\n"  # Simplified for now
        
        commission = int(request['requested_price'] * Config.COMMISSION_RATE)
        seller_amount = request['requested_price'] - commission
        
        message = f"""
📋 بررسی درخواست واسطه‌گری

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 👨‍💼 پنل بررسی ادمین                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request['request_id']}`
👤 **فروشنده:** {request['seller_name']}
📝 **عنوان:** {request['title']}

📄 **توضیحات کامل:**
{request['description']}

{files_info}

💰 **محاسبات مالی:**
• قیمت پیشنهادی: {request['requested_price']:,} تومان
• کارمزد ({Config.COMMISSION_RATE*100}%): {commission:,} تومان
• مبلغ فروشنده: {seller_amount:,} تومان

🔄 **وضعیت فعلی:** {request['status']}
📅 **زمان ثبت:** {request['created_at'].strftime('%Y/%m/%d - %H:%M')}

💡 **اقدامات مورد نیاز:**
1️⃣ بررسی محتوا
2️⃣ تعیین قیمت نهایی
3️⃣ جستجو برای خریدار
"""
        
        keyboard = [
            [
                InlineKeyboardButton("✅ تایید", callback_data=f"admin_approve_{request_id}"),
                InlineKeyboardButton("❌ رد", callback_data=f"admin_reject_{request_id}")
            ],
            [
                InlineKeyboardButton("📁 مشاهده فایل‌ها", callback_data=f"admin_files_{request_id}"),
                InlineKeyboardButton("💰 تعیین قیمت", callback_data=f"admin_price_{request_id}")
            ],
            [
                InlineKeyboardButton("🔍 جستجوی خریدار", callback_data=f"admin_find_buyer_{request_id}"),
                InlineKeyboardButton("📝 یادداشت", callback_data=f"admin_note_{request_id}")
            ],
            [
                InlineKeyboardButton("🔙 پنل ادمین", callback_data="admin_panel")
            ]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def handle_admin_files(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle viewing files by admin"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        request_id = data.replace("admin_files_", "")
        request = self.intermediary_requests.get(request_id)
        
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # For now, just show a message that files are not implemented yet
        await update.callback_query.answer("📁 سیستم فایل هنوز پیاده‌سازی نشده است.", show_alert=True)
        return
        
        # Send files to admin
        await update.callback_query.answer("📁 ارسال فایل‌ها...")
        
        for i, file_id in enumerate(request.files, 1):
            try:
                await context.bot.send_document(
                    chat_id=user_id,
                    document=file_id,
                    caption=f"📁 فایل {i} از درخواست {request_id}\n📝 {request.title}"
                )
            except Exception as e:
                logger.error("ADMIN_FILE_SEND_FAILED", 
                           admin_id=user_id, 
                           request_id=request_id, 
                           file_index=i, 
                           error=str(e))
        
        # Send summary message
        message = f"""
📁 فایل‌های درخواست ارسال شد

🆔 **درخواست:** `{request_id}`
📝 **عنوان:** {request.title}
📂 **تعداد فایل:** {len(request.files)}

✅ تمام فایل‌ها در بالا ارسال شدند.
"""
        
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت به بررسی", callback_data=f"admin_review_{request_id}")]
        ]
        
        await context.bot.send_message(
            chat_id=user_id,
            text=message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
    
    async def handle_admin_approve(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin approval of request"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        request_id = data.replace("admin_approve_", "")
        request = self.intermediary_requests.get(request_id)
        
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Update request status
        request['status'] = 'approved'
        request['admin_id'] = user_id
        request['updated_at'] = datetime.now()
        
        # Find and link the group to this request
        seller_group = None
        for group in self.intermediary_groups.values():
            if (group['creator_id'] == request['seller_id'] and 
                group['status'] == 'active'):
                seller_group = group
                group['request_id'] = request_id
                self._update_group_in_db(group)
                break
        
        # Save to database immediately
        self._update_intermediary_request_in_db(request)
        
        # Update in mediator system
        if request_id in self.mediator_system.active_requests:
            from mediator_system import MediationRequestStatus
            mediation_req = self.mediator_system.active_requests[request_id]
            mediation_req.status = MediationRequestStatus.ASSIGNED
            mediation_req.assigned_mediator_id = user_id
            mediation_req.updated_at = datetime.now()
        
        group_info = ""
        if seller_group:
            group_info = f"""
📱 **گروه مرتبط:**
• شناسه گروه: `{seller_group['group_id']}`  
• خریدار: {seller_group['participant_name']}
• وضعیت: فعال و آماده واسطه‌گری
"""
        
        message = f"""
✅ درخواست واسطه‌گری تایید شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request['title']}
👤 **فروشنده:** {request['seller_name']}
{group_info}
🔍 **وضعیت جدید:** تایید شده - آماده واسطه‌گری

📋 **مراحل بعدی:**
1️⃣ چت با فروشنده و خریدار
2️⃣ دریافت فایل‌ها از فروشنده
3️⃣ هماهنگی پرداخت
4️⃣ نظارت بر تحویل

🎯 حالا می‌توانید با هر دو طرف ارتباط برقرار کنید.
"""
        
        keyboard = []
        
        if seller_group:
            keyboard.extend([
                [
                    InlineKeyboardButton("💬 چت با فروشنده", callback_data=f"admin_chat_creator_{seller_group['group_id']}"),
                    InlineKeyboardButton("💬 چت با خریدار", callback_data=f"admin_chat_participant_{seller_group['group_id']}")
                ],
                [
                    InlineKeyboardButton("📁 دریافت فایل‌ها", callback_data=f"admin_get_files_{seller_group['group_id']}"),
                    InlineKeyboardButton("📋 جزئیات گروه", callback_data=f"admin_group_details_{seller_group['group_id']}")
                ]
            ])
        else:
            keyboard.extend([
                [
                    InlineKeyboardButton("🔍 جستجوی خریدار", callback_data=f"admin_find_buyer_{request_id}"),
                    InlineKeyboardButton("👤 معرفی خریدار", callback_data=f"admin_add_buyer_{request_id}")
                ],
                [
                    InlineKeyboardButton("💰 تعیین قیمت نهایی", callback_data=f"admin_final_price_{request_id}"),
                    InlineKeyboardButton("📋 مشاهده درخواست", callback_data=f"admin_review_{request_id}")
                ]
            ])
        
        keyboard.append([InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        # Notify seller
        try:
            await context.bot.send_message(
                chat_id=request['seller_id'],
                text=f"""
🎉 درخواست واسطه‌گری شما تایید شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request['title']}

✅ **وضعیت:** تایید شده توسط ادمین
🔍 **مرحله بعدی:** جستجو برای خریدار مناسب

⏰ **زمان تخمینی:** معمولاً کمتر از 48 ساعت

🔔 از تمام مراحل مطلع خواهید شد.
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("SELLER_NOTIFICATION_FAILED", 
                        seller_id=request['seller_id'], 
                        request_id=request_id, 
                        error=str(e))
        
        logger.admin_action("REQUEST_APPROVED", user_id, request_id=request_id)
    
    async def handle_admin_reject(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin rejection of request"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        request_id = data.replace("admin_reject_", "")
        request = self.intermediary_requests.get(request_id)
        
        if not request:
            await update.callback_query.answer("❌ درخواست یافت نشد!", show_alert=True)
            return
        
        # Update request status
        request['status'] = 'rejected'
        request['admin_id'] = user_id
        request['updated_at'] = datetime.now()
        request['admin_notes'] = "رد شده توسط ادمین"
        
        # Save to database immediately
        self._update_intermediary_request_in_db(request)
        
        message = f"""
❌ درخواست رد شد!

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request['title']}
👤 **فروشنده:** {request['seller_name']}

📋 **دلایل احتمالی رد:**
• محتوا مناسب نیست
• قیمت غیرمنطقی
• فایل‌های ناقص
• نقض قوانین

📞 فروشنده مطلع خواهد شد.
"""
        
        keyboard = [
            [InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        # Notify seller
        try:
            await context.bot.send_message(
                chat_id=request['seller_id'],
                text=f"""
❌ درخواست واسطه‌گری شما رد شد

🆔 **شناسه:** `{request_id}`
📝 **عنوان:** {request['title']}

📋 **دلایل احتمالی:**
• محتوا یا فایل‌ها مناسب نیست
• قیمت غیرمنطقی است
• نقض قوانین سایت

💡 **توصیه:**
• درخواست جدید با محتوای بهتر ارسال کنید
• قیمت منطقی‌تر تعیین کنید
• فایل‌های کامل‌تر ارائه دهید

📞 برای اطلاعات بیشتر: /support
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("SELLER_REJECTION_NOTIFICATION_FAILED", 
                        seller_id=request['seller_id'], 
                        request_id=request_id, 
                        error=str(e))
        
        logger.admin_action("REQUEST_REJECTED", user_id, request_id=request_id)
    
    async def handle_admin_chat_creator(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin chat with group creator"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_chat_creator_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        creator_user = self.db.get_user(group['creator_id'])
        creator_name = creator_user.first_name if creator_user else "نامشخص"
        
        message = f"""
💬 چت با فروشنده

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              💬 آماده ارسال پیام به فروشنده           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👤 **فروشنده:** {creator_name}
🆔 **شناسه کاربر:** {group['creator_id']}
🆔 **شناسه گروه:** `{group_id}`

📝 **پیام خود را تایپ کنید و ارسال کنید:**

نکته: پیام بعدی شما مستقیماً به این کاربر ارسال خواهد شد.
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data=f"admin_group_details_{group_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Set admin in chat mode
        context.user_data['admin_chat_target'] = group['creator_id']
        context.user_data['admin_chat_name'] = creator_name
        context.user_data['admin_chat_group'] = group_id
    
    async def handle_admin_chat_participant(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin chat with group participant"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_chat_participant_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        participant_user = self.db.get_user(group['participant_id'])
        participant_name = participant_user.first_name if participant_user else "نامشخص"
        
        message = f"""
💬 چت با خریدار

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              💬 آماده ارسال پیام به خریدار            ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👤 **خریدار:** {participant_name}
🆔 **شناسه کاربر:** {group['participant_id']}
🆔 **شناسه گروه:** `{group_id}`

📝 **پیام خود را تایپ کنید و ارسال کنید:**

نکته: پیام بعدی شما مستقیماً به این کاربر ارسال خواهد شد.
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data=f"admin_group_details_{group_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Set admin in chat mode
        context.user_data['admin_chat_target'] = group['participant_id']
        context.user_data['admin_chat_name'] = participant_name
        context.user_data['admin_chat_group'] = group_id
    
    async def handle_admin_join_group(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin joining group"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_join_group_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        message = f"""
👥 ورود به گروه معامله

🆔 **شناسه گروه:** `{group_id}`
💬 **چت گروه:** {group.get('chat_id', 'virtual')}

✅ شما به عنوان ادمین واسطه وارد شده‌اید.

📋 **اطلاعات گروه:**
• فروشنده: {group['creator_name']}
• خریدار: {group['participant_name']}
• وضعیت: {group['status']}

🔧 **اقدامات ادمین:**
• نظارت بر مکالمات
• دریافت فایل‌ها از فروشنده
• هماهنگی پرداخت
• تحویل محصول

💡 این گروه virtual است و تمام ارتباطات از طریق پیام‌های خصوصی انجام می‌شود.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 چت با فروشنده", callback_data=f"admin_chat_creator_{group_id}"),
                InlineKeyboardButton("💬 چت با خریدار", callback_data=f"admin_chat_participant_{group_id}")
            ],
            [
                InlineKeyboardButton("📁 دریافت فایل‌ها", callback_data=f"admin_get_files_{group_id}"),
                InlineKeyboardButton("📋 جزئیات گروه", callback_data=f"admin_group_details_{group_id}")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def handle_admin_get_files(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin getting files from group"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_get_files_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        message = f"""
📁 دریافت فایل‌ها از فروشنده

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}

📋 **دستورالعمل:**
1️⃣ به فروشنده پیام دهید که فایل‌ها را خصوصی به شما ارسال کند
2️⃣ فایل‌ها را بررسی کنید
3️⃣ تایید یا رد نهایی را اعلام کنید

💡 **نکته مهم:** فایل‌ها نباید در گروه ارسال شود، فقط خصوصی به ادمین.

🔄 برای پیام به فروشنده، دکمه چت کلیک کنید.
"""
        
        keyboard = [
            [InlineKeyboardButton("💬 پیام به فروشنده", callback_data=f"admin_chat_creator_{group_id}")],
            [InlineKeyboardButton("📋 جزئیات گروه", callback_data=f"admin_group_details_{group_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def handle_admin_group_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle showing group details to admin"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_group_details_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        try:
            # Get user details safely
            creator_user = self.db.get_user(group['creator_id'])
            participant_user = self.db.get_user(group['participant_id']) if group.get('participant_id') else None
            
            status_emoji = {
                'waiting_participant': '⏳',
                'active': '✅',
                'completed': '🟢',
                'cancelled': '🔴'
            }
            
            # Safely format user information to prevent entity parsing errors
            creator_name = "نامشخص"
            creator_username = "ندارد"
            if creator_user:
                creator_name = f"{creator_user.first_name} {creator_user.last_name or ''}".strip()
                creator_username = creator_user.username or "ندارد"
                # Escape special characters that cause parsing issues
                creator_name = creator_name.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace('`', '\\`')
                creator_username = creator_username.replace('_', '\\_').replace('*', '\\*')
            
            participant_name = "نامشخص"
            participant_username = "ندارد"
            participant_id_display = group.get('participant_id', 'نامشخص')
            if participant_user:
                participant_name = f"{participant_user.first_name} {participant_user.last_name or ''}".strip()
                participant_username = participant_user.username or "ندارد"
                # Escape special characters
                participant_name = participant_name.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace('`', '\\`')
                participant_username = participant_username.replace('_', '\\_').replace('*', '\\*')
            
            # Create shorter, safer message to prevent timeouts and parsing errors
            message = f"""
📋 جزئیات گروه معامله

🆔 شناسه: `{group_id}`
🔑 کد: `{group['join_code']}`
{status_emoji.get(group['status'], '⚪')} وضعیت: {group['status']}

👤 **فروشنده:**
• نام: {creator_name}
• ID: {group['creator_id']}
• username: @{creator_username}

👥 **خریدار:**
• نام: {participant_name}
• ID: {participant_id_display}
• username: @{participant_username}

📅 ایجاد: {group['created_at'].strftime('%Y/%m/%d - %H:%M')}
"""
            
            keyboard = [
                [
                    InlineKeyboardButton("💬 چت با فروشنده", callback_data=f"admin_chat_creator_{group_id}"),
                    InlineKeyboardButton("💬 چت با خریدار", callback_data=f"admin_chat_participant_{group_id}")
                ],
                [
                    InlineKeyboardButton("📁 دریافت فایل‌ها", callback_data=f"admin_get_files_{group_id}"),
                    InlineKeyboardButton("💰 مدیریت پرداخت", callback_data=f"admin_payment_manage_{group_id}")
                ],
                [
                    InlineKeyboardButton("✅ تکمیل معامله", callback_data=f"admin_complete_transaction_{group_id}"),
                    InlineKeyboardButton("❌ لغو معامله", callback_data=f"admin_cancel_transaction_{group_id}")
                ],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
            ]
            
            await update.callback_query.edit_message_text(
                message, 
                reply_markup=InlineKeyboardMarkup(keyboard), 
                parse_mode='Markdown'
            )
            
        except Exception as e:
            logger.error("ADMIN_GROUP_DETAILS_ERROR", 
                        admin_id=user_id, 
                        group_id=group_id, 
                        error=str(e))
            
            # Fallback to simple message without formatting
            simple_message = f"""
❌ خطا در نمایش جزئیات گروه

گروه: {group_id}
وضعیت: {group.get('status', 'نامشخص')}

لطفاً مجدداً تلاش کنید.
"""
            
            keyboard = [
                [InlineKeyboardButton("🔄 تلاش مجدد", callback_data=f"admin_group_details_{group_id}")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
            ]
            
            await update.callback_query.edit_message_text(
                simple_message, 
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
    
    async def handle_admin_chat_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin chat message to user"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        if not self.admin_system.is_admin(user_id):
            await update.message.reply_text("⛔ شما دسترسی ادمین ندارید!")
            context.user_data.clear()
            return
        
        target_user_id = context.user_data.get('admin_chat_target')
        target_name = context.user_data.get('admin_chat_name', 'کاربر')
        group_id = context.user_data.get('admin_chat_group')
        
        if not target_user_id:
            await update.message.reply_text("❌ هدف پیام یافت نشد!")
            context.user_data.clear()
            return
        
        try:
            # Send message to target user
            admin_user = self.db.get_user(user_id)
            admin_name = admin_user.first_name if admin_user else "ادمین"
            
            formatted_message = f"""
💬 **پیام از ادمین ({admin_name}):**

{message_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 گروه: `{group_id}`
🤖 ربات واسطه‌گری
"""
            
            await context.bot.send_message(
                chat_id=target_user_id,
                text=formatted_message,
                parse_mode='Markdown'
            )
            
            # Confirm to admin
            await update.message.reply_text(
                f"✅ پیام شما به {target_name} ارسال شد!\n\n"
                f"📝 **پیام ارسال شده:**\n{message_text}\n\n"
                f"💡 برای ادامه گفت‌وگو، پیام بعدی را بنویسید یا /cancel بزنید.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ پایان چت", callback_data=f"admin_group_details_{group_id}")]
                ])
            )
            
            logger.admin_action("ADMIN_MESSAGE_SENT", user_id, 
                              target_user=target_user_id, 
                              group_id=group_id,
                              message_length=len(message_text))
            
        except Exception as e:
            logger.error("ADMIN_MESSAGE_FAILED", 
                        admin_id=user_id, 
                        target_user=target_user_id, 
                        error=str(e))
            
            await update.message.reply_text(
                f"❌ خطا در ارسال پیام به {target_name}!\n\n"
                f"🔍 دلیل: {str(e)}\n\n"
                f"💡 لطفاً مجدداً تلاش کنید."
            )
    
    async def handle_mediator_chat_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle mediator chat message to user"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        if not self.mediator_system.is_mediator(user_id):
            await update.message.reply_text("⛔ شما دسترسی واسطه‌گری ندارید!")
            context.user_data.clear()
            return
        
        conversation_data = context.user_data.get('mediator_conversation')
        if not conversation_data:
            await update.message.reply_text("❌ اطلاعات گفت‌وگو یافت نشد!")
            context.user_data.clear()
            return
        
        target_user_id = conversation_data.get('target_user_id')
        target_name = conversation_data.get('target_name', 'کاربر')
        mediator_name = conversation_data.get('mediator_name', 'واسطه‌گر')
        
        if not target_user_id:
            await update.message.reply_text("❌ هدف پیام یافت نشد!")
            context.user_data.clear()
            return
        
        try:
            # Send message to target user
            formatted_message = f"""
💬 **پیام از واسطه‌گر ({mediator_name}):**

{message_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🤝 سیستم واسطه‌گری
🤖 ربات واسطه‌گری

💡 برای پاسخ، پیام خود را بنویسید.
"""
            
            await context.bot.send_message(
                chat_id=target_user_id,
                text=formatted_message,
                parse_mode='Markdown'
            )
            
            # Confirm to mediator
            await update.message.reply_text(
                f"✅ پیام شما به {target_name} ارسال شد!\n\n"
                f"📝 **پیام ارسال شده:**\n{message_text}\n\n"
                f"💡 برای ادامه گفت‌وگو، پیام بعدی را بنویسید یا /cancel بزنید.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ پایان گفت‌وگو", callback_data="mediator_dashboard")]
                ])
            )
            
            # Update global conversation tracking
            if user_id in self.active_mediator_conversations and target_user_id in self.active_mediator_conversations[user_id]:
                self.active_mediator_conversations[user_id][target_user_id]['last_activity'] = datetime.now()
            
            logger.info("MEDIATOR_MESSAGE_SENT", 
                       mediator_id=user_id,
                       target_user=target_user_id, 
                       message_length=len(message_text))
            
        except Exception as e:
            logger.error("MEDIATOR_MESSAGE_FAILED", 
                        mediator_id=user_id, 
                        target_user=target_user_id, 
                        error=str(e))
            
            await update.message.reply_text(
                f"❌ خطا در ارسال پیام به {target_name}!\n\n"
                f"🔍 دلیل: {str(e)}\n\n"
                f"💡 لطفاً مجدداً تلاش کنید."
            )
    
    def is_user_in_mediator_conversation(self, user_id: int, message_text: str) -> bool:
        """Check if user is in an active conversation with a mediator"""
        # Check if any mediator has an active conversation with this user
        for mediator_id, conversations in self.active_mediator_conversations.items():
            if user_id in conversations:
                return True
        return False
    
    async def handle_user_reply_to_mediator(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle user replies to mediator messages"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Find the mediator this user is talking to
        mediator_id = None
        conversation_data = None
        
        for med_id, conversations in self.active_mediator_conversations.items():
            if user_id in conversations:
                mediator_id = med_id
                conversation_data = conversations[user_id]
                break
        
        if not mediator_id or not conversation_data:
            await update.message.reply_text("❌ گفت‌وگوی فعالی با واسطه‌گر یافت نشد!")
            return
        
        try:
            # Get user info
            user = self.db.get_user(user_id)
            user_name = f"{user.first_name} {user.last_name or ''}".strip() if user else "کاربر"
            
            # Get mediator info
            mediator = self.db.get_user(mediator_id)
            mediator_name = mediator.first_name if mediator else "واسطه‌گر"
            
            # Format reply message to mediator
            reply_message = f"""
💬 **پاسخ از {user_name}:**

{message_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 کاربر: `{user_id}`
🤝 سیستم واسطه‌گری

💡 برای پاسخ، پیام خود را بنویسید یا برای پایان /cancel بزنید.
"""
            
            # Send to mediator
            await context.bot.send_message(
                chat_id=mediator_id,
                text=reply_message,
                parse_mode='Markdown'
            )
            
            # Confirm to user
            await update.message.reply_text(
                f"✅ پیام شما به واسطه‌گر ({mediator_name}) ارسال شد!\n\n"
                f"📝 **پیام شما:**\n{message_text}\n\n"
                f"💡 واسطه‌گر می‌تواند پاسخ دهد یا گفت‌وگو را پایان دهد."
            )
            
            # Update conversation timestamp
            conversation_data['last_activity'] = datetime.now()
            
            logger.info("USER_REPLY_TO_MEDIATOR", 
                       user_id=user_id,
                       mediator_id=mediator_id, 
                       message_length=len(message_text))
            
        except Exception as e:
            logger.error("USER_REPLY_TO_MEDIATOR_FAILED", 
                        user_id=user_id, 
                        mediator_id=mediator_id, 
                        error=str(e))
            
            await update.message.reply_text(
                f"❌ خطا در ارسال پیام به واسطه‌گر!\n\n"
                f"🔍 دلیل: {str(e)}\n\n"
                f"💡 لطفاً مجدداً تلاش کنید."
            )
    
    async def end_mediator_conversation(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """End mediator conversation"""
        user_id = update.effective_user.id
        
        if not self.mediator_system.is_mediator(user_id):
            await update.message.reply_text("⛔ شما دسترسی واسطه‌گری ندارید!")
            return
        
        conversation_data = context.user_data.get('mediator_conversation')
        if not conversation_data:
            await update.message.reply_text("❌ گفت‌وگوی فعالی یافت نشد!")
            return
        
        target_user_id = conversation_data.get('target_user_id')
        target_name = conversation_data.get('target_name', 'کاربر')
        
        # Remove from context
        context.user_data.clear()
        
        # Remove from global conversation tracking
        if user_id in self.active_mediator_conversations and target_user_id in self.active_mediator_conversations[user_id]:
            del self.active_mediator_conversations[user_id][target_user_id]
            
            # Remove mediator entry if no more conversations
            if not self.active_mediator_conversations[user_id]:
                del self.active_mediator_conversations[user_id]
        
        # Notify user that conversation ended
        try:
            mediator = self.db.get_user(user_id)
            mediator_name = mediator.first_name if mediator else "واسطه‌گر"
            
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"""
🔚 **گفت‌وگو با واسطه‌گر خاتمه یافت**

واسطه‌گر {mediator_name} گفت‌وگو را پایان داد.

💡 اگر نیاز به کمک بیشتری دارید، می‌توانید:
• از منوی اصلی ربات استفاده کنید
• با پشتیبانی تماس بگیرید: /support
• درخواست واسطه‌گری جدید ایجاد کنید

🤖 ربات واسطه‌گری
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("NOTIFY_USER_CONVERSATION_END_FAILED", 
                        mediator_id=user_id, 
                        target_user=target_user_id, 
                        error=str(e))
        
        # Confirm to mediator
        await update.message.reply_text(
            f"✅ گفت‌وگو با {target_name} پایان یافت!\n\n"
            f"📊 می‌توانید از داشبورد واسطه‌گری استفاده کنید.\n\n"
            f"💡 برای بازگشت به داشبورد: /mediator",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 داشبورد واسطه‌گری", callback_data="mediator_dashboard")]
            ])
        )
        
        logger.info("MEDIATOR_CONVERSATION_ENDED", 
                   mediator_id=user_id,
                   target_user=target_user_id)
    
    async def end_mediator_conversation_via_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """End mediator conversation via callback (button click)"""
        user_id = update.effective_user.id
        
        if not self.mediator_system.is_mediator(user_id):
            await update.callback_query.answer("⛔ شما دسترسی واسطه‌گری ندارید!", show_alert=True)
            return
        
        conversation_data = context.user_data.get('mediator_conversation')
        if not conversation_data:
            # If no conversation, just go to dashboard
            await self.mediator_system.handle_mediator_callbacks(update, context)
            return
        
        target_user_id = conversation_data.get('target_user_id')
        target_name = conversation_data.get('target_name', 'کاربر')
        
        # Remove from context
        context.user_data.clear()
        
        # Remove from global conversation tracking
        if user_id in self.active_mediator_conversations and target_user_id in self.active_mediator_conversations[user_id]:
            del self.active_mediator_conversations[user_id][target_user_id]
            
            # Remove mediator entry if no more conversations
            if not self.active_mediator_conversations[user_id]:
                del self.active_mediator_conversations[user_id]
        
        # Notify user that conversation ended
        try:
            mediator = self.db.get_user(user_id)
            mediator_name = mediator.first_name if mediator else "واسطه‌گر"
            
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"""
🔚 **گفت‌وگو با واسطه‌گر خاتمه یافت**

واسطه‌گر {mediator_name} گفت‌وگو را پایان داد.

💡 اگر نیاز به کمک بیشتری دارید، می‌توانید:
• از منوی اصلی ربات استفاده کنید
• با پشتیبانی تماس بگیرید: /support
• درخواست واسطه‌گری جدید ایجاد کنید

🤖 ربات واسطه‌گری
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("NOTIFY_USER_CONVERSATION_END_FAILED", 
                        mediator_id=user_id, 
                        target_user=target_user_id, 
                        error=str(e))
        
        logger.info("MEDIATOR_CONVERSATION_ENDED_VIA_CALLBACK", 
                   mediator_id=user_id,
                   target_user=target_user_id)
        
        # Show confirmation and go to dashboard
        await update.callback_query.answer(f"✅ گفت‌وگو با {target_name} پایان یافت!", show_alert=False)
        await self.mediator_system.handle_mediator_callbacks(update, context)
    
    async def handle_admin_payment_manage(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin payment management"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_payment_manage_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        message = f"""
💰 مدیریت پرداخت

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 💰 مدیریت پرداخت معامله              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}
👤 **خریدار:** {group['participant_name']}

📋 **مراحل پرداخت:**
1️⃣ خریدار اطلاعات پرداخت را ارائه می‌دهد
2️⃣ ادمین پرداخت را تایید می‌کند
3️⃣ محصول به خریدار تحویل داده می‌شود
4️⃣ وجه به فروشنده پرداخت می‌شود

💡 **اقدامات ادمین:**
• راهنمایی خریدار برای پرداخت
• تایید دریافت وجه
• هماهنگی تحویل محصول
• پرداخت به فروشنده

🔧 برای هماهنگی با طرفین از دکمه‌های چت استفاده کنید.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 راهنمایی خریدار", callback_data=f"admin_chat_participant_{group_id}"),
                InlineKeyboardButton("💬 اطلاع فروشنده", callback_data=f"admin_chat_creator_{group_id}")
            ],
            [
                InlineKeyboardButton("✅ تایید پرداخت", callback_data=f"admin_confirm_payment_{group_id}"),
                InlineKeyboardButton("📦 تحویل محصول", callback_data=f"admin_deliver_product_{group_id}")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_group_details_{group_id}")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def handle_admin_complete_transaction(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin completing transaction"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_complete_transaction_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        # Update group status
        group['status'] = 'completed'
        group['updated_at'] = datetime.now()
        
        # Update in database
        self._update_group_in_db(group)
        
        message = f"""
✅ معامله با موفقیت تکمیل شد!

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}
👤 **خریدار:** {group['participant_name']}

📊 **خلاصه معامله:**
• ✅ فایل‌ها تحویل داده شد
• ✅ پرداخت انجام شد
• ✅ هر دو طرف راضی هستند
• ✅ معامله با موفقیت پایان یافت

🎉 **اقدامات بعدی:**
• ارسال پیام تشکر به طرفین
• درخواست امتیازدهی
• بستن پرونده معامله

⭐ معامله موفق دیگری به ثبت رسید!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🎉 پیام تبریک به فروشنده", callback_data=f"admin_chat_creator_{group_id}"),
                InlineKeyboardButton("🎉 پیام تبریک به خریدار", callback_data=f"admin_chat_participant_{group_id}")
            ],
            [InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Notify both parties
        try:
            # Notify seller
            await context.bot.send_message(
                chat_id=group['creator_id'],
                text=f"""
🎉 معامله شما با موفقیت تکمیل شد!

🆔 **شناسه گروه:** `{group_id}`
👤 **خریدار:** {group['participant_name']}

✅ **نتیجه:**
• محصول شما با موفقیت تحویل داده شد
• پرداخت انجام شد
• معامله با موفقیت پایان یافت

⭐ لطفاً به خریدار امتیاز دهید
📞 از همکاری شما متشکریم!
""",
                parse_mode='Markdown'
            )
            
            # Notify buyer
            await context.bot.send_message(
                chat_id=group['participant_id'],
                text=f"""
🎉 معامله شما با موفقیت تکمیل شد!

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}

✅ **نتیجه:**
• محصول با موفقیت دریافت شد
• پرداخت انجام شد
• معامله با موفقیت پایان یافت

⭐ لطفاً به فروشنده امتیاز دهید
📞 از اعتماد شما متشکریم!
""",
                parse_mode='Markdown'
            )
            
        except Exception as e:
            logger.error("TRANSACTION_COMPLETION_NOTIFICATION_FAILED", 
                        group_id=group_id, error=str(e))
        
        logger.admin_action("TRANSACTION_COMPLETED", user_id, group_id=group_id)
    
    async def handle_admin_cancel_transaction(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Handle admin canceling transaction"""
        user_id = update.effective_user.id
        
        if not self.admin_system.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        group_id = data.replace("admin_cancel_transaction_", "")
        group = self.intermediary_groups.get(group_id)
        
        if not group:
            await update.callback_query.answer("❌ گروه یافت نشد!", show_alert=True)
            return
        
        # Update group status
        group['status'] = 'cancelled'
        group['updated_at'] = datetime.now()
        
        # Update in database
        self._update_group_in_db(group)
        
        message = f"""
❌ معامله لغو شد

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}
👤 **خریدار:** {group['participant_name']}

📋 **دلایل احتمالی لغو:**
• عدم توافق طرفین
• مشکل در محصول یا خدمت
• عدم پرداخت
• درخواست یکی از طرفین

⚠️ **اقدامات انجام شده:**
• وضعیت گروه به "لغو شده" تغییر یافت
• طرفین مطلع خواهند شد
• هیچ پرداختی انجام نشد

📞 در صورت نیاز، می‌توانید با طرفین ارتباط برقرار کنید.
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 پیام به فروشنده", callback_data=f"admin_chat_creator_{group_id}"),
                InlineKeyboardButton("💬 پیام به خریدار", callback_data=f"admin_chat_participant_{group_id}")
            ],
            [InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Notify both parties
        try:
            # Notify seller
            await context.bot.send_message(
                chat_id=group['creator_id'],
                text=f"""
❌ معامله شما لغو شد

🆔 **شناسه گروه:** `{group_id}`
👤 **خریدار:** {group['participant_name']}

📋 **توضیح:**
معامله به دلایل مختلف لغو شد.
هیچ پرداختی انجام نشده است.

💡 **اقدام بعدی:**
می‌توانید معامله جدیدی شروع کنید.

📞 برای اطلاعات بیشتر: /support
""",
                parse_mode='Markdown'
            )
            
            # Notify buyer
            await context.bot.send_message(
                chat_id=group['participant_id'],
                text=f"""
❌ معامله شما لغو شد

🆔 **شناسه گروه:** `{group_id}`
👤 **فروشنده:** {group['creator_name']}

📋 **توضیح:**
معامله به دلایل مختلف لغو شد.
هیچ پرداختی انجام نشده است.

💡 **اقدام بعدی:**
می‌توانید معامله جدیدی شروع کنید.

📞 برای اطلاعات بیشتر: /support
""",
                parse_mode='Markdown'
            )
            
        except Exception as e:
            logger.error("TRANSACTION_CANCELLATION_NOTIFICATION_FAILED", 
                        group_id=group_id, error=str(e))
        
        logger.admin_action("TRANSACTION_CANCELLED", user_id, group_id=group_id)
    
    def _save_intermediary_request_to_db(self, request_obj):
        """Save intermediary request to database"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                
                # Convert files list to string
                files_str = ""
                if request_obj.get('files'):
                    files_str = ','.join([f['file_id'] for f in request_obj['files']])
                
                cursor.execute("""
                    INSERT INTO intermediary_requests (
                        request_id, seller_id, seller_name, title, description, files,
                        requested_price, final_price, buyer_id, buyer_name, admin_id,
                        status, payment_method, payment_info, created_at, updated_at,
                        admin_notes, buyer_rating, seller_rating, buyer_review, seller_review
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    request_obj['request_id'],
                    request_obj['seller_id'],
                    request_obj['seller_name'],
                    request_obj['title'],
                    request_obj['description'],
                    files_str,
                    request_obj['requested_price'],
                    request_obj.get('final_price'),
                    request_obj.get('buyer_id'),
                    request_obj.get('buyer_name'),
                    request_obj.get('admin_id'),
                    request_obj['status'],
                    request_obj.get('payment_method'),
                    request_obj.get('payment_info'),
                    request_obj['created_at'].isoformat(),
                    request_obj['updated_at'].isoformat(),
                    request_obj.get('admin_notes'),
                    request_obj.get('buyer_rating'),
                    request_obj.get('seller_rating'),
                    request_obj.get('buyer_review'),
                    request_obj.get('seller_review')
                ))
                
                conn.commit()
                logger.info("INTERMEDIARY_REQUEST_SAVED_TO_DB", request_id=request_obj['request_id'])
                print(f"✅ Request {request_obj['request_id']} saved to database")
                
        except Exception as e:
            logger.error("INTERMEDIARY_REQUEST_DB_SAVE_FAILED", 
                        request_id=request_obj['request_id'], error=str(e))
            print(f"❌ Failed to save request to database: {e}")
    
    def _update_intermediary_request_in_db(self, request_obj):
        """Update intermediary request in database"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                
                # Convert files list to string
                files_str = ""
                if request_obj.get('files'):
                    files_str = ','.join([f['file_id'] for f in request_obj['files']])
                
                cursor.execute("""
                    UPDATE intermediary_requests SET
                        seller_name = ?, title = ?, description = ?, files = ?,
                        requested_price = ?, final_price = ?, buyer_id = ?, buyer_name = ?,
                        admin_id = ?, status = ?, payment_method = ?, payment_info = ?,
                        updated_at = ?, admin_notes = ?, buyer_rating = ?, seller_rating = ?,
                        buyer_review = ?, seller_review = ?
                    WHERE request_id = ?
                """, (
                    request_obj['seller_name'],
                    request_obj['title'],
                    request_obj['description'],
                    files_str,
                    request_obj['requested_price'],
                    request_obj.get('final_price'),
                    request_obj.get('buyer_id'),
                    request_obj.get('buyer_name'),
                    request_obj.get('admin_id'),
                    request_obj['status'],
                    request_obj.get('payment_method'),
                    request_obj.get('payment_info'),
                    request_obj['updated_at'].isoformat(),
                    request_obj.get('admin_notes'),
                    request_obj.get('buyer_rating'),
                    request_obj.get('seller_rating'),
                    request_obj.get('buyer_review'),
                    request_obj.get('seller_review'),
                    request_obj['request_id']
                ))
                
                conn.commit()
                logger.info("INTERMEDIARY_REQUEST_UPDATED_IN_DB", request_id=request_obj['request_id'])
                
        except Exception as e:
            logger.error("INTERMEDIARY_REQUEST_DB_UPDATE_FAILED", 
                        request_id=request_obj['request_id'], error=str(e))
    
    def load_intermediary_requests_from_db(self):
        """Load intermediary requests from database on startup"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT request_id, seller_id, seller_name, title, description, files,
                           requested_price, final_price, buyer_id, buyer_name, admin_id,
                           status, payment_method, payment_info, created_at, updated_at,
                           admin_notes, buyer_rating, seller_rating, buyer_review, seller_review
                    FROM intermediary_requests
                    WHERE status NOT IN ('completed', 'cancelled', 'rejected')
                """)
                
                rows = cursor.fetchall()
                for row in rows:
                    request_obj = {
                        'request_id': row[0],
                        'seller_id': row[1],
                        'seller_name': row[2],
                        'title': row[3],
                        'description': row[4],
                        'files': row[5].split(',') if row[5] else [],
                        'requested_price': row[6],
                        'final_price': row[7],
                        'buyer_id': row[8],
                        'buyer_name': row[9],
                        'admin_id': row[10],
                        'status': row[11],
                        'payment_method': row[12],
                        'payment_info': row[13],
                        'created_at': datetime.fromisoformat(row[14]),
                        'updated_at': datetime.fromisoformat(row[15]),
                        'admin_notes': row[16],
                        'buyer_rating': row[17],
                        'seller_rating': row[18],
                        'buyer_review': row[19],
                        'seller_review': row[20]
                    }
                    
                    self.intermediary_requests[row[0]] = request_obj
                
                logger.info("INTERMEDIARY_REQUESTS_LOADED_FROM_DB", count=len(rows))
                print(f"✅ Loaded {len(rows)} intermediary requests from database")
                
        except Exception as e:
            logger.error("INTERMEDIARY_REQUESTS_DB_LOAD_FAILED", error=str(e))
            print(f"❌ Failed to load requests from database: {e}")
    
    def load_intermediary_groups_from_db(self):
        """Load intermediary groups from database on startup"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT group_id, creator_id, creator_name, participant_id, participant_name,
                           admin_id, join_code, chat_id, status, request_id, created_at, updated_at
                    FROM intermediary_groups
                    WHERE status IN ('waiting_participant', 'active')
                """)
                
                rows = cursor.fetchall()
                for row in rows:
                    group_obj = {
                        'group_id': row[0],
                        'creator_id': row[1],
                        'creator_name': row[2],
                        'participant_id': row[3],
                        'participant_name': row[4],
                        'admin_id': row[5],
                        'join_code': row[6],
                        'chat_id': row[7],
                        'status': row[8],
                        'request_id': row[9],
                        'created_at': datetime.fromisoformat(row[10]),
                        'updated_at': datetime.fromisoformat(row[11])
                    }
                    
                    self.intermediary_groups[row[0]] = group_obj
                
                logger.info("INTERMEDIARY_GROUPS_LOADED_FROM_DB", count=len(rows))
                print(f"✅ Loaded {len(rows)} intermediary groups from database")
                
        except Exception as e:
            logger.error("INTERMEDIARY_GROUPS_DB_LOAD_FAILED", error=str(e))
            print(f"❌ Failed to load groups from database: {e}")
    
    def load_intermediary_requests_to_mediator_system(self):
        """Load intermediary requests into mediator system"""
        try:
            from mediator_system import MediationRequest, MediationRequestStatus, MediationRequestType
            
            count = 0
            for request_obj in self.intermediary_requests.values():
                # Convert to mediation request format
                mediation_request = MediationRequest(
                    request_id=request_obj['request_id'],
                    requester_id=request_obj['seller_id'],
                    requester_name=request_obj['seller_name'],
                    request_type=MediationRequestType.GENERAL_MEDIATION,
                    title=request_obj['title'],
                    description=request_obj['description'],
                    related_transaction_id=None,
                    priority=2,  # Medium priority
                    status=MediationRequestStatus.PENDING if request_obj['status'] == 'pending' else MediationRequestStatus.ASSIGNED,
                    assigned_mediator_id=request_obj.get('admin_id'),
                    created_at=request_obj['created_at'],
                    updated_at=request_obj['updated_at'],
                    amount=request_obj['requested_price'],
                    files=request_obj.get('files', []),
                    mediator_notes=request_obj.get('admin_notes'),
                    resolution=None,
                    estimated_time=None,
                    urgency_level=2
                )
                
                # Add to mediator system
                self.mediator_system.active_requests[request_obj['request_id']] = mediation_request
                count += 1
            
            logger.info("INTERMEDIARY_REQUESTS_LOADED_TO_MEDIATOR", count=count)
            print(f"✅ Loaded {count} intermediary requests to mediator system")
            
        except Exception as e:
            logger.error("INTERMEDIARY_REQUESTS_MEDIATOR_LOAD_FAILED", error=str(e))
            print(f"❌ Failed to load intermediary requests to mediator system: {e}")
    
    # Group management methods
    async def create_intermediary_group(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Create a new intermediary group"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Generate unique group code
        import random
        import string
        join_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        group_id = f"GRP_{int(datetime.now().timestamp())}_{join_code}"
        
        # Create group object
        group_obj = {
            'group_id': group_id,
            'creator_id': user_id,
            'creator_name': f"{user.first_name} {user.last_name or ''}".strip(),
            'participant_id': None,
            'participant_name': None,
            'admin_id': None,
            'join_code': join_code,
            'chat_id': None,
            'status': 'waiting_participant',
            'request_id': None,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        # Store in memory and database
        self.intermediary_groups[group_id] = group_obj
        self._save_group_to_db(group_obj)
        
        message = f"""
🎉 گروه معامله با موفقیت ایجاد شد!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 👥 گروه معامله جدید                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه گروه:** `{group_id}`
🔑 **کد عضویت:** `{join_code}`
👤 **سازنده:** {group_obj['creator_name']}

📋 **نحوه استفاده:**
1️⃣ این کد را به خریدار بدهید: `{join_code}`
2️⃣ خریدار باید دستور زیر را ارسال کند:
   `/join {join_code}`
3️⃣ پس از پیوستن، گروه خصوصی ایجاد می‌شود
4️⃣ ادمین به گروه اضافه شده و واسطه‌گری شروع می‌شود

⚠️ **نکات مهم:**
• کد عضویت یکبار مصرف است
• گروه بعد از 24 ساعت منقضی می‌شود
• تمام مکالمات با نظارت ادمین انجام می‌شود

📞 **پشتیبانی:** در صورت مشکل با /support تماس بگیرید
"""
        
        keyboard = [
            [InlineKeyboardButton("👥 گروه‌های من", callback_data="my_groups")],
            [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        logger.info("INTERMEDIARY_GROUP_CREATED", 
                   user_id=user_id, group_id=group_id, join_code=join_code)
    
    async def show_join_group(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show join group interface"""
        message = """
🔗 پیوستن به گروه معامله

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃               👥 پیوستن به گروه معامله                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📋 **نحوه پیوستن:**
• اگر کد عضویت دارید، دستور زیر را ارسال کنید:
  `/join کد_عضویت`

💡 **مثال:**
  `/join ABC12345`

🔑 **دریافت کد عضویت:**
• کد عضویت را از فروشنده دریافت کنید
• هر کد فقط یکبار قابل استفاده است
• کدها 24 ساعت اعتبار دارند

⚠️ **نکات مهم:**
• پس از پیوستن، گروه خصوصی ایجاد می‌شود
• ادمین به گروه اضافه شده و واسطه‌گری شروع می‌شود
• تمام معاملات تحت نظارت ادمین انجام می‌شود

📞 **کمک نیاز دارید؟** با /support تماس بگیرید
"""
        
        keyboard = [
            [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
    
    async def join_intermediary_group(self, update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
        """Join an intermediary group"""
        # This will be handled by message handler when user sends /join command
        pass
    
    def _save_group_to_db(self, group_obj):
        """Save group to database"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO intermediary_groups (
                        group_id, creator_id, creator_name, participant_id, participant_name,
                        admin_id, join_code, chat_id, status, request_id, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    group_obj['group_id'],
                    group_obj['creator_id'],
                    group_obj['creator_name'],
                    group_obj['participant_id'],
                    group_obj['participant_name'],
                    group_obj['admin_id'],
                    group_obj['join_code'],
                    group_obj['chat_id'],
                    group_obj['status'],
                    group_obj['request_id'],
                    group_obj['created_at'].isoformat(),
                    group_obj['updated_at'].isoformat()
                ))
                conn.commit()
                logger.info("GROUP_SAVED_TO_DB", group_id=group_obj['group_id'])
        except Exception as e:
            logger.error("GROUP_DB_SAVE_FAILED", 
                        group_id=group_obj['group_id'], error=str(e))
    
    async def handle_join_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE, join_code: str):
        """Handle /join command for joining groups"""
        user_id = update.effective_user.id
        telegram_user = update.effective_user
        user = self.db.get_user(user_id)
        
        if not user:
            # Auto-register the user if they don't exist (same logic as start_command)
            role = UserRole.MAIN_ADMIN if self.admin_system.is_main_admin(user_id) else \
                   UserRole.SUB_ADMIN if self.admin_system.is_sub_admin(user_id) else \
                   UserRole.USER
            
            success = self.db.create_user(
                user_id=user_id,
                username=telegram_user.username,
                first_name=telegram_user.first_name,
                last_name=telegram_user.last_name,
                role=role
            )
            
            if success:
                logger.user_action("USER_REGISTERED_VIA_JOIN", user_id, username=telegram_user.username, role=role.value)
                user = self.db.get_user(user_id)  # Get the newly created user
            else:
                logger.error("USER_REGISTRATION_FAILED_ON_JOIN", user_id)
                await update.message.reply_text("❌ خطا در ثبت‌نام! لطفاً ابتدا /start کنید.")
                return
        
        # Find group by join code
        target_group = None
        for group in self.intermediary_groups.values():
            if group['join_code'] == join_code and group['status'] == 'waiting_participant':
                target_group = group
                break
        
        if not target_group:
            await update.message.reply_text("""
❌ کد عضویت نامعتبر یا منقضی شده!

🔍 **دلایل احتمالی:**
• کد وارد شده اشتباه است
• کد قبلاً استفاده شده
• کد منقضی شده (بیش از 24 ساعت)
• گروه لغو شده

💡 **راه‌حل:**
• کد را دوباره بررسی کنید
• از فروشنده کد جدید بخواهید
• با /support تماس بگیرید
""")
            return
        
        # Check if user is trying to join their own group
        if target_group['creator_id'] == user_id:
            await update.message.reply_text("❌ شما نمی‌توانید به گروه خود بپیوندید!")
            return
        
        # Update group with participant info
        target_group['participant_id'] = user_id
        target_group['participant_name'] = f"{user.first_name} {user.last_name or ''}".strip()
        target_group['status'] = 'active'
        target_group['updated_at'] = datetime.now()
        
        # Create a "virtual" group chat (for now just notify both users)
        success_message = f"""
🎉 با موفقیت به گروه معامله پیوستید!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 👥 پیوستن موفق به گروه                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه گروه:** `{target_group['group_id']}`
👤 **فروشنده:** {target_group['creator_name']}
👤 **خریدار:** {target_group['participant_name']}

📋 **مراحل بعدی:**
1️⃣ ادمین به گروه اضافه می‌شود
2️⃣ مذاکرات شروع می‌شود
3️⃣ ادمین فایل‌ها را بررسی می‌کند
4️⃣ پرداخت انجام می‌شود
5️⃣ محصول تحویل داده می‌شود

⚠️ **قوانین گروه:**
• از ادب و احترام استفاده کنید
• فقط در مورد معامله صحبت کنید
• از ارسال اطلاعات شخصی خودداری کنید
• تمام مکالمات ضبط می‌شود

✅ گروه فعال شد. منتظر ورود ادمین باشید...
"""
        
        await update.message.reply_text(success_message, parse_mode='Markdown')
        
        # Notify creator
        try:
            await context.bot.send_message(
                chat_id=target_group['creator_id'],
                text=f"""
🎉 خریدار به گروه شما پیوست!

👤 **خریدار:** {target_group['participant_name']}
🆔 **شناسه گروه:** `{target_group['group_id']}`

✅ گروه فعال شد. ادمین به زودی اضافه می‌شود.
""",
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error("CREATOR_NOTIFICATION_FAILED", error=str(e))
        
        # Create actual Telegram group
        await self.create_telegram_group(context, target_group)
        
        # Notify admins about active group
        await self.notify_admins_group_active(context, target_group)
        
        # Update in database
        self._update_group_in_db(target_group)
        
        logger.info("GROUP_JOINED", 
                   user_id=user_id, 
                   group_id=target_group['group_id'], 
                   join_code=join_code)
    
    async def notify_admins_group_active(self, context: ContextTypes.DEFAULT_TYPE, group: dict):
        """Notify admins about active group"""
        admin_ids = [Config.MAIN_ADMIN_ID] + Config.SUB_ADMINS
        
        # Get detailed user info
        creator_user = self.db.get_user(group['creator_id'])
        participant_user = self.db.get_user(group['participant_id'])
        
        creator_info = f"""
📝 **نام:** {creator_user.first_name if creator_user else 'نامشخص'} {creator_user.last_name if creator_user and creator_user.last_name else ''}
🆔 **ID:** {group['creator_id']}
👤 **نام کاربری:** @{creator_user.username if creator_user and creator_user.username else 'ندارد'}
📱 **شماره:** {getattr(creator_user, 'phone_number', 'ندارد') if creator_user else 'ندارد'}
📊 **امتیاز:** {getattr(creator_user, 'rating', 'جدید') if creator_user else 'جدید'}
"""

        participant_info = f"""
📝 **نام:** {participant_user.first_name if participant_user else 'نامشخص'} {participant_user.last_name if participant_user and participant_user.last_name else ''}
🆔 **ID:** {group['participant_id']}
👤 **نام کاربری:** @{participant_user.username if participant_user and participant_user.username else 'ندارد'}
📱 **شماره:** {getattr(participant_user, 'phone_number', 'ندارد') if participant_user else 'ندارد'}
📊 **امتیاز:** {getattr(participant_user, 'rating', 'جدید') if participant_user else 'جدید'}
"""
        
        message = f"""
🚨 گروه معامله فعال شد!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                👥 گروه معامله آماده واسطه‌گری           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه گروه:** `{group['group_id']}`
💬 **چت گروه:** {f"`{group['chat_id']}`" if group.get('chat_id') else "در حال ایجاد..."}

👤 **فروشنده:**
{creator_info}

🛒 **خریدار:**
{participant_info}

📅 **زمان ایجاد:** {group['created_at'].strftime('%Y/%m/%d - %H:%M')}
🔄 **وضعیت:** فعال و آماده واسطه‌گری

🎯 **اقدامات مورد نیاز:**
• ✅ گروه ایجاد شده - ادمین اضافه شده
• 📁 دریافت فایل‌ها از فروشنده (خصوصی)
• 💰 هماهنگی پرداخت با خریدار
• 📦 نظارت بر تحویل محصول
• ⭐ امتیازدهی پس از تکمیل

⚠️ **نکته مهم:** فایل‌ها باید بصورت خصوصی از فروشنده دریافت شوند!
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💬 چت با فروشنده", callback_data=f"admin_chat_creator_{group['group_id']}"),
                InlineKeyboardButton("💬 چت با خریدار", callback_data=f"admin_chat_participant_{group['group_id']}")
            ],
            [
                InlineKeyboardButton("👥 ورود به گروه", callback_data=f"admin_join_group_{group['group_id']}"),
                InlineKeyboardButton("📁 دریافت فایل‌ها", callback_data=f"admin_get_files_{group['group_id']}")
            ],
            [
                InlineKeyboardButton("📋 جزئیات گروه", callback_data=f"admin_group_details_{group['group_id']}")
            ]
        ]
        
        for admin_id in admin_ids:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=message,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='Markdown'
                )
                logger.info("ADMIN_GROUP_NOTIFIED", admin_id=admin_id, group_id=group['group_id'])
            except Exception as e:
                logger.error("ADMIN_GROUP_NOTIFICATION_FAILED", 
                           admin_id=admin_id, 
                           group_id=group['group_id'], 
                           error=str(e))
    
    def _update_group_in_db(self, group_obj):
        """Update group in database"""
        try:
            import sqlite3
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE intermediary_groups SET
                        participant_id = ?, participant_name = ?, admin_id = ?,
                        chat_id = ?, status = ?, request_id = ?, updated_at = ?
                    WHERE group_id = ?
                """, (
                    group_obj['participant_id'],
                    group_obj['participant_name'],
                    group_obj['admin_id'],
                    group_obj['chat_id'],
                    group_obj['status'],
                    group_obj['request_id'],
                    group_obj['updated_at'].isoformat(),
                    group_obj['group_id']
                ))
                conn.commit()
                logger.info("GROUP_UPDATED_IN_DB", group_id=group_obj['group_id'])
        except Exception as e:
            logger.error("GROUP_DB_UPDATE_FAILED", 
                        group_id=group_obj['group_id'], error=str(e))
    
    async def create_telegram_group(self, context: ContextTypes.DEFAULT_TYPE, group: dict):
        """Create virtual group communication"""
        try:
            from config import Config
            
            # For simplicity, we use private message coordination instead of actual groups
            # This avoids complex Telegram group creation permissions
            
            group['chat_id'] = f"virtual_{group['group_id']}"
            group['admin_id'] = Config.MAIN_ADMIN_ID
            
            # Send coordination message to both users
            coordination_message = f"""
✅ معامله فعال شد!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 🤝 معامله با واسطه امن                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه معامله:** `{group['group_id']}`
👤 **فروشنده:** {group['creator_name']}
👤 **خریدار:** {group['participant_name']}
👨‍💼 **ادمین واسطه:** فعال

📋 **مراحل معامله:**
1️⃣ فروشنده فایل‌ها را خصوصی به ادمین می‌فرستد
2️⃣ ادمین فایل‌ها را بررسی می‌کند  
3️⃣ خریدار وجه را پرداخت می‌کند
4️⃣ ادمین فایل‌ها را به خریدار تحویل می‌دهد
5️⃣ وجه به فروشنده پرداخت می‌شود

⚠️ **نکات مهم:**
• فایل‌ها را فقط خصوصی به ادمین بفرستید
• برای هماهنگی با طرف مقابل، از ادمین کمک بگیرید
• تمام مراحل توسط ادمین نظارت می‌شود

🛡️ معامله شما تحت نظارت و تضمین ادمین است
📞 **پشتیبانی:** /support
"""
            
            # Send to both users
            for user_id in [group['creator_id'], group['participant_id']]:
                try:
                    await context.bot.send_message(
                        user_id, 
                        coordination_message, 
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    logger.error("USER_COORDINATION_MESSAGE_FAILED", 
                               user_id=user_id, error=str(e))
            
            logger.info("VIRTUAL_GROUP_CREATED", 
                       group_id=group['group_id'], 
                       virtual_chat_id=group['chat_id'])
            
            return group['chat_id']
            
        except Exception as e:
            logger.error("VIRTUAL_GROUP_CREATION_FAILED", 
                        group_id=group['group_id'], error=str(e))
            return None
    
    # Intermediary flow methods
    async def start_intermediary_request(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start new intermediary request"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Check user's group status for better guidance
        user_has_active_group = False
        user_has_group_with_participant = False
        user_group_info = None
        
        for group in self.intermediary_groups.values():
            if group['creator_id'] == user_id and group['status'] == 'active':
                user_has_active_group = True
                user_group_info = group
                if group['participant_id'] is not None:
                    user_has_group_with_participant = True
                break
        
        # تغییر منطق: اجازه درخواست واسطه‌گری بدون شرط سخت گروه
        # اما راهنمایی مناسب ارائه دهیم
        show_group_guidance = not user_has_group_with_participant
        
        # اگر کاربر گروه با شرکت‌کننده ندارد، راهنمایی نشان بده اما اجازه ادامه بده
        if show_group_guidance:
            guidance_message = """
💡 **توصیه مهم:** برای بهترین تجربه واسطه‌گری

🔄 **مراحل پیشنهادی:**
1️⃣ **ساخت گروه:** "👥 ساخت گروه معامله" کلیک کنید
2️⃣ **اشتراک کد:** کد عضویت به خریدار بدهید 
3️⃣ **پیوستن خریدار:** خریدار `/join کد` بزند
4️⃣ **درخواست واسطه:** درخواست واسطه‌گری دهید

⚠️ **وضعیت فعلی شما:**"""
            
            if not user_has_active_group:
                guidance_message += "\n• گروه معامله ای نداخته‌اید"
            elif not user_has_group_with_participant:
                guidance_message += f"\n• گروه شما ساخته شده (کد: {user_group_info['group_code']}) اما خریدار هنوز نپیوسته"
            
            guidance_message += """

✅ **می‌توانید همین الان درخواست واسطه‌گری کنید**
💡 **اما:** داشتن گروه فعال با خریدار، فرآیند را سریع‌تر می‌کند

❓ **ادامه می‌دهید یا ابتدا گروه می‌سازید؟**
"""
            
            keyboard = [
                [
                    InlineKeyboardButton("✅ ادامه درخواست", callback_data="continue_intermediary_request"),
                ],
                [
                    InlineKeyboardButton("👥 ساخت گروه", callback_data="create_group"),
                    InlineKeyboardButton("🔗 پیوستن به گروه", callback_data="join_group")
                ],
                [InlineKeyboardButton("🔙 منوی اصلی", callback_data="main_menu")]
            ]
            
            await update.callback_query.edit_message_text(
                guidance_message, 
                reply_markup=InlineKeyboardMarkup(keyboard), 
                parse_mode='Markdown'
            )
            return
        
        # Clear any previous request data
        context.user_data.pop('intermediary_request', None)
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              🤝 درخواست واسطه‌گری جدید               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

سلام {user.first_name}! 👋

📝 برای شروع واسطه‌گری، لطفاً عنوان محصول یا خدمت خود را وارد کنید:

💡 **مثال‌های خوب:**
• سورس کد اپلیکیشن اندروید
• اکانت پریمیوم نتفلیکس
• فایل پروژه آماده وب‌سایت
• کد شارژ ایرانسل
• اکانت بازی PUBG

✏️ عنوان محصول خود را بنویسید:
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Set state
        context.user_data['intermediary_request'] = {
            'step': 'title',
            'seller_id': user_id,
            'seller_name': f"{user.first_name} {user.last_name or ''}".strip()
        }
    
    async def continue_intermediary_request(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Continue with intermediary request after guidance"""
        user_id = update.effective_user.id
        user = self.db.get_user(user_id)
        
        if not user:
            await update.callback_query.answer("❌ کاربر یافت نشد!", show_alert=True)
            return
        
        # Clear any previous request data
        context.user_data.pop('intermediary_request', None)
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              🤝 درخواست واسطه‌گری جدید               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

سلام {user.first_name}! 👋

📝 برای شروع واسطه‌گری، لطفاً عنوان محصول یا خدمت خود را وارد کنید:

💡 **مثال‌های خوب:**
• سورس کد اپلیکیشن اندروید
• اکانت پریمیوم نتفلیکس
• فایل پروژه آماده وب‌سایت
• کد شارژ ایرانسل
• اکانت بازی PUBG

✏️ عنوان محصول خود را بنویسید:
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Set state
        context.user_data['intermediary_request'] = {
            'step': 'title',
            'seller_id': user_id,
            'seller_name': f"{user.first_name} {user.last_name or ''}".strip()
        }
    
    async def handle_title_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle title input"""
        title = update.message.text
        
        # Validate title
        if not title or len(title.strip()) < 5:
            await update.message.reply_text("❌ عنوان باید حداقل 5 کاراکتر باشد. لطفاً مجدداً وارد کنید:")
            return
        
        if len(title) > 100:
            await update.message.reply_text("❌ عنوان نباید بیش از 100 کاراکتر باشد. لطفاً مجدداً وارد کنید:")
            return
        
        context.user_data['intermediary_request']['title'] = title.strip()
        
        # Ask for description
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              📝 توضیحات محصول - مرحله 2/4           ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

عنوان ثبت شد: ✅ {title}

📋 حالا توضیحات کاملی از محصول خود ارائه دهید:

💡 **چه اطلاعاتی مهم است:**
• ویژگی‌های دقیق محصول
• نحوه استفاده یا نصب
• قابلیت‌ها و امکانات
• سیستم مورد نیاز (در صورت لزوم)
• ضمانت یا پشتیبانی ارائه شده

📝 حداکثر 500 کاراکتر - دقیق و کامل بنویسید:
"""
        
        await update.message.reply_text(message, parse_mode='Markdown')
        context.user_data['intermediary_request']['step'] = 'description'
    
    async def handle_description_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle description input"""
        description = update.message.text
        
        # Validate description
        if not description or len(description.strip()) < 20:
            await update.message.reply_text("❌ توضیحات باید حداقل 20 کاراکتر باشد. لطفاً دقیق‌تر توضیح دهید:")
            return
        
        if len(description) > 500:
            await update.message.reply_text("❌ توضیحات نباید بیش از 500 کاراکتر باشد. لطفاً خلاصه‌تر بنویسید:")
            return
        
        context.user_data['intermediary_request']['description'] = description.strip()
        
        # Ask for files first
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃            📁 ارسال فایل‌ها - مرحله 3/4            ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

توضیحات ثبت شد! ✅

📂 آیا فایلی برای ارسال دارید؟

💡 **انواع فایل مجاز:**
• تصاویر (PNG, JPG)
• فایل‌های فشرده (ZIP, RAR)
• اسناد (PDF, DOC)
• فایل‌های کد (متنی)

📁 **نکات مهم:**
• حداکثر 10 فایل
• حداکثر حجم هر فایل: 20 مگابایت
• می‌توانید فایل‌ها را یکی یکی ارسال کنید

🔄 فایل اول را ارسال کنید یا "بدون فایل" بزنید:
"""
        
        keyboard = [
            [InlineKeyboardButton("📁 بدون فایل", callback_data="no_files")],
            [InlineKeyboardButton("❌ لغو", callback_data="main_menu")]
        ]
        
        await update.message.reply_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        context.user_data['intermediary_request']['step'] = 'files'
        context.user_data['intermediary_request']['files'] = []
    
    async def handle_price_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle price input"""
        price_text = update.message.text.strip()
        
        # Validate price
        try:
            price = int(price_text.replace(',', '').replace(' ', ''))
        except ValueError:
            await update.message.reply_text(
                "❌ لطفاً قیمت را به صورت عدد صحیح وارد کنید:\n"
                "مثال: 50000"
            )
            return
        
        if price < Config.MIN_TRANSACTION_AMOUNT:
            await update.message.reply_text(
                f"❌ حداقل قیمت {Config.MIN_TRANSACTION_AMOUNT:,} تومان است!"
            )
            return
        
        if price > Config.MAX_TRANSACTION_AMOUNT:
            await update.message.reply_text(
                f"❌ حداکثر قیمت {Config.MAX_TRANSACTION_AMOUNT:,} تومان است!"
            )
            return
        
        context.user_data['intermediary_request']['requested_price'] = price
        
        # Show confirmation
        await self.show_request_confirmation(update, context)
    
    async def handle_file_input(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle file uploads"""
        if 'intermediary_request' not in context.user_data:
            return
        
        files_list = context.user_data['intermediary_request'].get('files', [])
        
        # Check file limit
        if len(files_list) >= 10:
            await update.message.reply_text(
                "❌ حداکثر 10 فایل مجاز است. لطفاً 'تمام شد' بزنید:"
            )
            return
        
        # Handle file
        file_info = None
        if update.message.document:
            file_info = update.message.document
        elif update.message.photo:
            file_info = update.message.photo[-1]  # largest size
        elif update.message.video:
            file_info = update.message.video
        
        if file_info:
            # Check file size (20MB limit)
            if file_info.file_size > 20 * 1024 * 1024:
                await update.message.reply_text(
                    "❌ حجم فایل نباید بیش از 20 مگابایت باشد!"
                )
                return
            
            # Store file info
            files_list.append({
                'file_id': file_info.file_id,
                'file_name': getattr(file_info, 'file_name', f'file_{len(files_list)+1}'),
                'file_size': file_info.file_size,
                'mime_type': getattr(file_info, 'mime_type', 'application/octet-stream')
            })
            
            context.user_data['intermediary_request']['files'] = files_list
            
            # Show progress
            message = f"""
✅ فایل {len(files_list)} دریافت شد!

📁 **فایل‌های دریافت شده:**
"""
            for i, file_data in enumerate(files_list, 1):
                size_mb = file_data['file_size'] / (1024 * 1024)
                message += f"{i}. {file_data['file_name']} ({size_mb:.1f} MB)\n"
            
            message += f"""
🔄 می‌توانید فایل‌های بیشتری ارسال کنید یا "تمام شد" بزنید:
"""
            
            keyboard = [
                [InlineKeyboardButton("✅ تمام شد", callback_data="files_complete")],
                [InlineKeyboardButton("❌ لغو", callback_data="main_menu")]
            ]
            
            await update.message.reply_text(
                message, 
                reply_markup=InlineKeyboardMarkup(keyboard), 
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                "❌ لطفاً یک فایل معتبر ارسال کنید یا 'بدون فایل' را انتخاب کنید."
            )
    
    async def handle_no_files(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle when user has no files to upload"""
        context.user_data['intermediary_request']['files'] = []
        await self.ask_for_price(update, context)
    
    async def handle_files_complete(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle when file upload is complete"""
        await self.ask_for_price(update, context)
    
    async def ask_for_price(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Ask for requested price"""
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃              💰 قیمت پیشنهادی - مرحله 3/4          ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

💰 قیمت پیشنهادی خود را به تومان وارد کنید:

💡 **نکات مهم:**
• حداقل مبلغ: {Config.MIN_TRANSACTION_AMOUNT:,} تومان
• حداکثر مبلغ: {Config.MAX_TRANSACTION_AMOUNT:,} تومان
• کارمزد واسطه‌گری: {Config.COMMISSION_RATE*100}%

🔢 قیمت را به تومان وارد کنید:
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data="main_menu")]
        ]
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                message, 
                reply_markup=InlineKeyboardMarkup(keyboard), 
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                message, 
                reply_markup=InlineKeyboardMarkup(keyboard), 
                parse_mode='Markdown'
            )
        
        context.user_data['intermediary_request']['step'] = 'price'
    
    async def show_request_confirmation(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show final confirmation"""
        request_data = context.user_data['intermediary_request']
        
        commission = int(request_data['requested_price'] * Config.COMMISSION_RATE)
        seller_amount = request_data['requested_price'] - commission
        
        # Files info
        files_info = ""
        files_list = request_data.get('files', [])
        if files_list:
            files_info = f"📁 **فایل‌های ضمیمه:** {len(files_list)} فایل\n"
            for i, file_data in enumerate(files_list, 1):
                size_mb = file_data['file_size'] / (1024 * 1024)
                files_info += f"  {i}. {file_data['file_name']} ({size_mb:.1f} MB)\n"
        else:
            files_info = "📁 **فایل‌های ضمیمه:** بدون فایل\n"
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃            ✅ تایید نهایی درخواست - مرحله 4/4         ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📋 **خلاصه درخواست شما:**

📝 **عنوان:** {request_data['title']}

📄 **توضیحات:**
{request_data['description'][:200]}{'...' if len(request_data['description']) > 200 else ''}

{files_info}

💰 **محاسبات مالی:**
• قیمت پیشنهادی: {request_data['requested_price']:,} تومان
• کارمزد واسطه‌گری: {commission:,} تومان ({Config.COMMISSION_RATE*100}%)
• مبلغ دریافتی شما: {seller_amount:,} تومان

⚠️ **مراحل بعدی:**
1️⃣ ادمین درخواست را بررسی خواهد کرد
2️⃣ خریدار مناسب پیدا می‌شود
3️⃣ قیمت نهایی توسط ادمین تعیین می‌شود
4️⃣ پس از پرداخت خریدار، محصول تحویل دهید

✅ آیا تایید می‌کنید؟
"""
        
        keyboard = [
            [
                InlineKeyboardButton("✅ تایید و ارسال", callback_data="confirm_intermediary_request"),
                InlineKeyboardButton("❌ لغو", callback_data="main_menu")
            ]
        ]
        
        await update.message.reply_text(
            message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        context.user_data['intermediary_request']['step'] = 'confirmation'
    
    async def confirm_intermediary_request(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Confirm and create intermediary request"""
        user_id = update.effective_user.id
        request_data = context.user_data.get('intermediary_request')
        
        if not request_data:
            await update.callback_query.answer("❌ خطا در پردازش درخواست!", show_alert=True)
            return
        
        # Generate request ID
        import uuid
        request_id = f"INT_{int(datetime.now().timestamp())}_{uuid.uuid4().hex[:8]}".upper()
        
        # Store request
        request_obj = {
            'request_id': request_id,
            'seller_id': request_data['seller_id'],
            'seller_name': request_data['seller_name'],
            'title': request_data['title'],
            'description': request_data['description'],
            'requested_price': request_data['requested_price'],
            'files': request_data.get('files', []),
            'status': 'pending',
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        self.intermediary_requests[request_id] = request_obj
        
        # Save to database immediately
        self._save_intermediary_request_to_db(request_obj)
        
        # Also add to mediator system for compatibility
        try:
            from mediator_system import MediationRequest, MediationRequestStatus, MediationRequestType
            
            # Convert to mediation request format
            mediation_request = MediationRequest(
                request_id=request_id,
                requester_id=request_data['seller_id'],
                requester_name=request_data['seller_name'],
                request_type=MediationRequestType.GENERAL_MEDIATION,
                title=request_data['title'],
                description=request_data['description'],
                related_transaction_id=None,
                priority=2,  # Medium priority
                status=MediationRequestStatus.PENDING,
                assigned_mediator_id=None,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                amount=request_data['requested_price'],
                files=request_data.get('files', []),
                mediator_notes=None,
                resolution=None,
                estimated_time=None,
                urgency_level=2
            )
            
            # Add to mediator system
            self.mediator_system.active_requests[request_id] = mediation_request
            logger.info("ADDED_TO_MEDIATOR_SYSTEM", request_id=request_id)
            
            # Try to assign a mediator automatically
            assigned_mediator = self.mediator_system.assign_mediator(request_id)
            if assigned_mediator:
                # Notify the assigned mediator
                await self.mediator_system.notify_mediator_new_request(context, assigned_mediator, mediation_request)
                logger.info("AUTO_ASSIGNED_TO_MEDIATOR", request_id=request_id, mediator_id=assigned_mediator)
            else:
                # No mediator available, add to queue
                logger.warning("NO_MEDIATOR_AVAILABLE", request_id=request_id)
            
        except Exception as e:
            logger.error("MEDIATOR_SYSTEM_ADD_FAILED", request_id=request_id, error=str(e))
            print(f"Warning: Could not add to mediator system: {e}")
        
        # Send success message to user
        success_message = f"""
🎉 درخواست واسطه‌گری شما با موفقیت ثبت شد!

🆔 **شناسه درخواست:** `{request_id}`
📝 **عنوان:** {request_data['title']}
💰 **قیمت پیشنهادی:** {request_data['requested_price']:,} تومان

📊 **وضعیت فعلی:** در انتظار بررسی ادمین

⏰ **زمان پردازش:** معمولاً کمتر از 24 ساعت

🔔 **اطلاع‌رسانی:**
• از تمام مراحل مطلع خواهید شد
• می‌توانید در هر زمان وضعیت را پیگیری کنید

📞 **پشتیبانی:** در صورت سوال با /support تماس بگیرید

✨ از اعتماد شما سپاسگزاریم!
"""
        
        keyboard = [
            [InlineKeyboardButton("📋 درخواست‌های من", callback_data="my_intermediary_requests")],
            [InlineKeyboardButton("🏠 منوی اصلی", callback_data="main_menu")]
        ]
        
        await update.callback_query.edit_message_text(
            success_message, 
            reply_markup=InlineKeyboardMarkup(keyboard), 
            parse_mode='Markdown'
        )
        
        # Notify all admins
        await self.notify_admins_new_request(context, request_id)
        
        # Log the action
        logger.info("INTERMEDIARY_REQUEST_CREATED", 
                   user_id=user_id, 
                   request_id=request_id, 
                   price=request_data['requested_price'])
        
        # Clear user data
        context.user_data.pop('intermediary_request', None)
    
    async def notify_admins_new_request(self, context: ContextTypes.DEFAULT_TYPE, request_id: str):
        """Notify all admins about new intermediary request"""
        admin_ids = [Config.MAIN_ADMIN_ID] + Config.SUB_ADMINS
        request = self.intermediary_requests.get(request_id)
        
        if not request:
            return
        
        commission = int(request['requested_price'] * Config.COMMISSION_RATE)
        
        message = f"""
🚨 درخواست واسطه‌گری جدید!

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                🤝 درخواست واسطه‌گری جدید             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

🆔 **شناسه:** `{request['request_id']}`
👤 **فروشنده:** {request['seller_name']}
📝 **عنوان:** {request['title']}

📄 **توضیحات:**
{request['description'][:300]}{'...' if len(request['description']) > 300 else ''}

💰 **قیمت پیشنهادی:** {request['requested_price']:,} تومان
💳 **کارمزد پیش‌بینی:** {commission:,} تومان

📅 **زمان ثبت:** {request['created_at'].strftime('%Y/%m/%d - %H:%M')}

🎯 **اقدامات مورد نیاز:**
• بررسی محصول 
• تعیین قیمت نهایی
• جستجو برای خریدار مناسب
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📋 بررسی درخواست", callback_data=f"admin_review_{request['request_id']}"),
                InlineKeyboardButton("📁 مشاهده فایل‌ها", callback_data=f"admin_files_{request['request_id']}")
            ],
            [
                InlineKeyboardButton("✅ تایید", callback_data=f"admin_approve_{request['request_id']}"),
                InlineKeyboardButton("❌ رد", callback_data=f"admin_reject_{request['request_id']}")
            ],
            [
                InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_panel")
            ]
        ]
        
        for admin_id in admin_ids:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=message,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='Markdown'
                )
                logger.info("ADMIN_NOTIFIED", admin_id=admin_id, request_id=request_id)
            except Exception as e:
                logger.error("ADMIN_NOTIFICATION_FAILED", 
                           admin_id=admin_id, 
                           request_id=request_id, 
                           error=str(e))
    
    async def setup_bot_commands(self):
        """Setup bot commands for menu"""
        commands = [
            BotCommand("start", "شروع کار با ربات"),
            BotCommand("help", "راهنمای استفاده"),
            BotCommand("profile", "مشاهده پروفایل"),
            BotCommand("admin", "پنل مدیریت (ادمین‌ها)"),
            BotCommand("mediator", "داشبورد واسطه‌گری"),
        ]
        
        # Add admin commands
        admin_commands = self.admin_system.get_admin_commands()
        for cmd, desc in admin_commands:
            commands.append(BotCommand(cmd, desc))
        
        await self.application.bot.set_my_commands(commands)
        logger.info("BOT_COMMANDS_SETUP", details={'commands_count': len(commands)})
    
    async def startup_tasks(self, application):
        """Run startup tasks"""
        logger.info("BOT_STARTING", details={'startup_time': self.startup_time.isoformat()})
        
        # Setup bot commands
        await self.setup_bot_commands()
        
        # Load active mediation requests from database
        self.mediator_system.load_active_requests_from_db()
        
        # Load intermediary requests from database
        self.load_intermediary_requests_from_db()
        
        # Load intermediary requests into mediator system
        self.load_intermediary_requests_to_mediator_system()
        
        # Load intermediary groups from database
        self.load_intermediary_groups_from_db()
        
        # Initialize admin users in database
        from config import Config
        
        # Ensure main admin exists
        main_admin = self.db.get_user(Config.MAIN_ADMIN_ID)
        if not main_admin:
            self.db.create_user(
                user_id=Config.MAIN_ADMIN_ID,
                username="main_admin",
                first_name="Main Admin",
                last_name="",
                role=UserRole.MAIN_ADMIN
            )
            logger.admin_action("MAIN_ADMIN_CREATED", Config.MAIN_ADMIN_ID)
        
        # Ensure sub-admins exist
        for admin_id in Config.SUB_ADMINS:
            admin_user = self.db.get_user(admin_id)
            if not admin_user:
                self.db.create_user(
                    user_id=admin_id,
                    username=f"sub_admin_{admin_id}",
                    first_name="Sub Admin",
                    last_name="",
                    role=UserRole.SUB_ADMIN
                )
                logger.admin_action("SUB_ADMIN_CREATED", admin_id)
        
        logger.info("BOT_STARTED_SUCCESSFULLY")
    
    async def shutdown_tasks(self, application):
        """Run shutdown tasks"""
        logger.info("BOT_SHUTTING_DOWN")
        
        # Cancel any pending tasks
        for task in self.intermediary.auto_cancel_tasks.values():
            task.cancel()
        
        # Cleanup logs
        logger.cleanup_old_logs()
        
        logger.info("BOT_SHUTDOWN_COMPLETE")
    
    def run(self):
        """Run the bot"""
        # Create application
        self.application = Application.builder().token(Config.BOT_TOKEN).build()
        
        # Store references in bot_data
        self.application.bot_data['database'] = self.db
        self.application.bot_data['security_manager'] = self.security
        self.application.bot_data['admin_system'] = self.admin_system
        self.application.bot_data['intermediary_system'] = self.intermediary
        self.application.bot_data['mediator_system'] = self.mediator_system
        self.application.bot_data['logger'] = logger
        self.application.bot_data['main_bot'] = self
        
        # Setup handlers
        self.setup_handlers()
        
        # Add startup and shutdown tasks
        self.application.post_init = self.startup_tasks
        self.application.post_shutdown = self.shutdown_tasks
        
        # Setup graceful shutdown
        def signal_handler(signum, frame):
            logger.info("SHUTDOWN_SIGNAL_RECEIVED", details={'signal': signum})
            self.application.stop()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Run bot
        logger.info("BOT_INITIALIZATION_COMPLETE")
        print("🔮 ربات واسطه‌گری پیشرفته در حال اجرا...")
        print("💎 برای توقف: Ctrl+C")
        
        self.application.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )

if __name__ == "__main__":
    # Check if token is configured
    if Config.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ خطا: لطفاً ابتدا توکن ربات را در فایل config.py تنظیم کنید!")
        print("🔧 مراحل تنظیم:")
        print("1. با @BotFather در تلگرام ربات بسازید")
        print("2. توکن دریافتی را در config.py قرار دهید")
        print("3. شناسه ادمین اصلی را تنظیم کنید")
        sys.exit(1)
    
    # Run bot
    bot = IntermediaryBot()
    try:
        bot.run()
    except KeyboardInterrupt:
        print("\n👋 ربات متوقف شد.")
    except Exception as e:
        logger.critical("BOT_STARTUP_FAILED", details={'error': str(e)})
        print(f"❌ خطا در راه‌اندازی ربات: {e}")
        sys.exit(1)
