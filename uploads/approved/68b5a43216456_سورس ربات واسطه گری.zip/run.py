#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Advanced Intermediary Bot - Easy Run Script
اسکریپت اجرای آسان ربات واسطه‌گری پیشرفته
"""

import os
import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ خطا: Python 3.8 یا بالاتر مورد نیاز است!")
        print(f"نسخه فعلی: {sys.version}")
        return False
    return True

def check_requirements():
    """Check if required packages are installed"""
    required_packages = [
        'python-telegram-bot',
        'python-dateutil',
        'cryptography',
        'aiohttp'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ بسته‌های زیر نصب نیستند:")
        for package in missing_packages:
            print(f"  - {package}")
        
        print("\n🔧 برای نصب:")
        print("pip install -r requirements.txt")
        return False
    
    return True

def check_config():
    """Check if configuration is properly set"""
    try:
        from config import Config
        
        if Config.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
            print("❌ خطا: توکن ربات تنظیم نشده است!")
            print("\n🔧 مراحل تنظیم:")
            print("1. با @BotFather در تلگرام ربات بسازید")
            print("2. توکن دریافتی را در config.py قرار دهید")
            print("3. شناسه ادمین اصلی را تنظیم کنید")
            return False
        
        if Config.MAIN_ADMIN_ID == 123456789:
            print("⚠️ هشدار: شناسه ادمین اصلی تنظیم نشده است!")
            print("لطفاً شناسه تلگرام خود را در config.py قرار دهید")
            choice = input("آیا با این تنظیمات ادامه می‌دهید؟ (y/N): ")
            if choice.lower() != 'y':
                return False
        
        return True
        
    except ImportError as e:
        print(f"❌ خطا در بارگذاری تنظیمات: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    directories = ['logs', 'backups', 'temp']
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
    
    print("✅ پوشه‌های لازم ایجاد شدند")

def run_bot():
    """Run the bot"""
    try:
        print("🔮 در حال راه‌اندازی ربات واسطه‌گری پیشرفته...")
        print("💎 برای توقف: Ctrl+C")
        print("-" * 50)
        
        # Import and run the bot
        from main import IntermediaryBot
        bot = IntermediaryBot()
        bot.run()
        
    except KeyboardInterrupt:
        print("\n👋 ربات متوقف شد.")
    except Exception as e:
        print(f"❌ خطا در اجرای ربات: {e}")
        print("\n🔧 راه‌حل‌های ممکن:")
        print("1. بررسی اتصال اینترنت")
        print("2. تایید صحت توکن ربات")
        print("3. مطالعه فایل README.md")

def main():
    """Main function"""
    print("🚀 سیستم بررسی پیش‌نیازها...")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    print("✅ نسخه Python مناسب است")
    
    # Check requirements
    if not check_requirements():
        sys.exit(1)
    print("✅ تمام بسته‌های مورد نیاز نصب شده‌اند")
    
    # Check configuration
    if not check_config():
        sys.exit(1)
    print("✅ تنظیمات بررسی شد")
    
    # Create directories
    create_directories()
    
    print("\n" + "=" * 50)
    print("🎉 تمام بررسی‌ها موفقیت‌آمیز بود!")
    print("=" * 50)
    
    # Run the bot
    run_bot()

if __name__ == "__main__":
    main()
