# -*- coding: utf-8 -*-
"""
Advanced Database Management for Intermediary Bot
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from enum import Enum

from logging_system import logger

class TransactionStatus(Enum):
    PENDING = "pending"
    SELLER_CONFIRMED = "seller_confirmed"
    BUYER_PAID = "buyer_paid"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    DISPUTED = "disputed"

class UserRole(Enum):
    USER = "user"
    SUB_ADMIN = "sub_admin"
    MAIN_ADMIN = "main_admin"

@dataclass
class User:
    user_id: int
    username: Optional[str]
    first_name: str
    last_name: Optional[str]
    role: UserRole
    registration_date: datetime
    is_banned: bool = False
    total_transactions: int = 0
    success_rate: float = 0.0

@dataclass
class Transaction:
    transaction_id: str
    seller_id: int
    buyer_id: Optional[int]
    title: str
    description: str
    amount: int
    commission: int
    status: TransactionStatus
    created_at: datetime
    updated_at: datetime
    expires_at: datetime
    seller_confirmation: bool = False
    buyer_confirmation: bool = False
    admin_notes: Optional[str] = None

class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT NOT NULL,
                    last_name TEXT,
                    role TEXT DEFAULT 'user',
                    registration_date TEXT NOT NULL,
                    is_banned INTEGER DEFAULT 0,
                    total_transactions INTEGER DEFAULT 0,
                    success_rate REAL DEFAULT 0.0
                )
            """)
            
            # Transactions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS transactions (
                    transaction_id TEXT PRIMARY KEY,
                    seller_id INTEGER NOT NULL,
                    buyer_id INTEGER,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    amount INTEGER NOT NULL,
                    commission INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    seller_confirmation INTEGER DEFAULT 0,
                    buyer_confirmation INTEGER DEFAULT 0,
                    admin_notes TEXT,
                    FOREIGN KEY (seller_id) REFERENCES users (user_id),
                    FOREIGN KEY (buyer_id) REFERENCES users (user_id)
                )
            """)
            
            # Messages log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS message_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    message_type TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Settings table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS bot_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Mediation requests table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS mediation_requests (
                    request_id TEXT PRIMARY KEY,
                    requester_id INTEGER NOT NULL,
                    requester_name TEXT NOT NULL,
                    request_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    related_transaction_id TEXT,
                    priority INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    assigned_mediator_id INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    amount INTEGER,
                    files TEXT,
                    mediator_notes TEXT,
                    resolution TEXT,
                    estimated_time INTEGER,
                    urgency_level INTEGER,
                    resolution_notes TEXT,
                    escalation_reason TEXT,
                    FOREIGN KEY (requester_id) REFERENCES users (user_id),
                    FOREIGN KEY (assigned_mediator_id) REFERENCES users (user_id),
                    FOREIGN KEY (related_transaction_id) REFERENCES transactions (transaction_id)
                )
            """)
            
            # Products table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    product_id TEXT PRIMARY KEY,
                    seller_id INTEGER NOT NULL,
                    category TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    price INTEGER NOT NULL,
                    original_price INTEGER,
                    discount_percent INTEGER DEFAULT 0,
                    quantity INTEGER DEFAULT 1,
                    product_type TEXT NOT NULL,
                    specifications TEXT,
                    images TEXT,
                    status TEXT DEFAULT 'active',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    expires_at TEXT,
                    sold_count INTEGER DEFAULT 0,
                    views_count INTEGER DEFAULT 0,
                    is_featured INTEGER DEFAULT 0,
                    warranty_period INTEGER DEFAULT 0,
                    delivery_method TEXT DEFAULT 'instant',
                    FOREIGN KEY (seller_id) REFERENCES users (user_id)
                )
            """)
            
            # Product categories table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS product_categories (
                    category_id TEXT PRIMARY KEY,
                    parent_category_id TEXT,
                    name TEXT NOT NULL,
                    name_fa TEXT NOT NULL,
                    description TEXT,
                    icon_emoji TEXT,
                    is_active INTEGER DEFAULT 1,
                    sort_order INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (parent_category_id) REFERENCES product_categories (category_id)
                )
            """)
            
            # Orders table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    order_id TEXT PRIMARY KEY,
                    buyer_id INTEGER NOT NULL,
                    seller_id INTEGER NOT NULL,
                    product_id TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    unit_price INTEGER NOT NULL,
                    total_amount INTEGER NOT NULL,
                    commission_amount INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    payment_method TEXT,
                    payment_status TEXT DEFAULT 'pending',
                    delivery_info TEXT,
                    buyer_notes TEXT,
                    seller_notes TEXT,
                    admin_notes TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT,
                    cancelled_at TEXT,
                    refund_amount INTEGER DEFAULT 0,
                    rating INTEGER DEFAULT 0,
                    review_text TEXT,
                    FOREIGN KEY (buyer_id) REFERENCES users (user_id),
                    FOREIGN KEY (seller_id) REFERENCES users (user_id),
                    FOREIGN KEY (product_id) REFERENCES products (product_id)
                )
            """)
            
            # User favorites table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_favorites (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    product_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(user_id, product_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (product_id) REFERENCES products (product_id)
                )
            """)
            
            # User wallet table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_wallets (
                    user_id INTEGER PRIMARY KEY,
                    balance INTEGER DEFAULT 0,
                    frozen_balance INTEGER DEFAULT 0,
                    total_earned INTEGER DEFAULT 0,
                    total_spent INTEGER DEFAULT 0,
                    last_transaction_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Wallet transactions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wallet_transactions (
                    transaction_id TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    transaction_type TEXT NOT NULL,
                    amount INTEGER NOT NULL,
                    description TEXT NOT NULL,
                    reference_id TEXT,
                    balance_before INTEGER NOT NULL,
                    balance_after INTEGER NOT NULL,
                    status TEXT DEFAULT 'completed',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Reviews and ratings table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    review_id TEXT PRIMARY KEY,
                    reviewer_id INTEGER NOT NULL,
                    reviewed_user_id INTEGER NOT NULL,
                    order_id TEXT,
                    product_id TEXT,
                    rating INTEGER NOT NULL,
                    review_text TEXT,
                    review_type TEXT NOT NULL,
                    is_anonymous INTEGER DEFAULT 0,
                    admin_approved INTEGER DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (reviewer_id) REFERENCES users (user_id),
                    FOREIGN KEY (reviewed_user_id) REFERENCES users (user_id),
                    FOREIGN KEY (order_id) REFERENCES orders (order_id),
                    FOREIGN KEY (product_id) REFERENCES products (product_id)
                )
            """)
            
            # Notifications table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS notifications (
                    notification_id TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    message TEXT NOT NULL,
                    notification_type TEXT NOT NULL,
                    is_read INTEGER DEFAULT 0,
                    action_url TEXT,
                    reference_id TEXT,
                    created_at TEXT NOT NULL,
                    read_at TEXT,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # System analytics table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analytics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    user_id INTEGER,
                    data TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Bot configuration table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS bot_config (
                    config_key TEXT PRIMARY KEY,
                    config_value TEXT NOT NULL,
                    config_type TEXT DEFAULT 'string',
                    description TEXT,
                    is_system INTEGER DEFAULT 0,
                    updated_by INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (updated_by) REFERENCES users (user_id)
                )
            """)
            
            # Intermediary requests table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS intermediary_requests (
                    request_id TEXT PRIMARY KEY,
                    seller_id INTEGER NOT NULL,
                    seller_name TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    files TEXT,
                    requested_price INTEGER NOT NULL,
                    final_price INTEGER,
                    buyer_id INTEGER,
                    buyer_name TEXT,
                    admin_id INTEGER,
                    status TEXT NOT NULL,
                    payment_method TEXT,
                    payment_info TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    admin_notes TEXT,
                    buyer_rating INTEGER,
                    seller_rating INTEGER,
                    buyer_review TEXT,
                    seller_review TEXT,
                    FOREIGN KEY (seller_id) REFERENCES users (user_id),
                    FOREIGN KEY (buyer_id) REFERENCES users (user_id),
                    FOREIGN KEY (admin_id) REFERENCES users (user_id)
                )
            """)
            
            # Intermediary groups table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS intermediary_groups (
                    group_id TEXT PRIMARY KEY,
                    creator_id INTEGER NOT NULL,
                    creator_name TEXT NOT NULL,
                    participant_id INTEGER,
                    participant_name TEXT,
                    admin_id INTEGER,
                    join_code TEXT UNIQUE NOT NULL,
                    chat_id INTEGER UNIQUE,
                    status TEXT NOT NULL DEFAULT 'active',
                    request_id TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (creator_id) REFERENCES users (user_id),
                    FOREIGN KEY (participant_id) REFERENCES users (user_id),
                    FOREIGN KEY (admin_id) REFERENCES users (user_id),
                    FOREIGN KEY (request_id) REFERENCES intermediary_requests (request_id)
                )
            """)
            
            conn.commit()
            
            # Migrate database schema for new mediation_requests fields
            self._migrate_mediation_requests_table(cursor)
    
    def _migrate_mediation_requests_table(self, cursor):
        """Add new columns to mediation_requests table if they don't exist"""
        try:
            # Check if table exists first
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='mediation_requests'")
            if not cursor.fetchone():
                logger.info("MEDIATION_REQUESTS_TABLE_NOT_FOUND", message="Table doesn't exist yet, skipping migration")
                return
                
            # Get existing columns
            cursor.execute("PRAGMA table_info(mediation_requests)")
            existing_columns = {row[1] for row in cursor.fetchall()}
            
            # Add missing columns
            new_columns = [
                ('amount', 'INTEGER'),
                ('files', 'TEXT'),
                ('mediator_notes', 'TEXT'),
                ('resolution', 'TEXT'),
                ('estimated_time', 'INTEGER'),
                ('urgency_level', 'INTEGER')
            ]
            
            for column_name, column_type in new_columns:
                if column_name not in existing_columns:
                    cursor.execute(f"ALTER TABLE mediation_requests ADD COLUMN {column_name} {column_type}")
                    logger.info(f"COLUMN_ADDED", table="mediation_requests", column=column_name)
                    
        except Exception as e:
            logger.error("MEDIATION_REQUESTS_MIGRATION_FAILED", error=str(e))
    
    def get_user(self, user_id: int) -> Optional[User]:
        """Get user by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            
            if row:
                return User(
                    user_id=row[0],
                    username=row[1],
                    first_name=row[2],
                    last_name=row[3],
                    role=UserRole(row[4]),
                    registration_date=datetime.fromisoformat(row[5]),
                    is_banned=bool(row[6]),
                    total_transactions=row[7],
                    success_rate=row[8]
                )
            return None
    
    def create_user(self, user_id: int, username: Optional[str], first_name: str, 
                   last_name: Optional[str], role: UserRole = UserRole.USER) -> bool:
        """Create new user"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO users (user_id, username, first_name, last_name, role, registration_date)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (user_id, username, first_name, last_name, role.value, datetime.now().isoformat()))
                conn.commit()
                return True
        except sqlite3.IntegrityError:
            return False
    
    def update_user_role(self, user_id: int, role: UserRole) -> bool:
        """Update user role"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET role = ? WHERE user_id = ?", (role.value, user_id))
            conn.commit()
            return cursor.rowcount > 0
    
    def ban_user(self, user_id: int, banned: bool = True) -> bool:
        """Ban or unban user"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (int(banned), user_id))
            conn.commit()
            return cursor.rowcount > 0
    
    def create_transaction(self, transaction: Transaction) -> bool:
        """Create new transaction"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO transactions (
                        transaction_id, seller_id, buyer_id, title, description, 
                        amount, commission, status, created_at, updated_at, expires_at,
                        seller_confirmation, buyer_confirmation, admin_notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    transaction.transaction_id, transaction.seller_id, transaction.buyer_id,
                    transaction.title, transaction.description, transaction.amount,
                    transaction.commission, transaction.status.value,
                    transaction.created_at.isoformat(), transaction.updated_at.isoformat(),
                    transaction.expires_at.isoformat(), int(transaction.seller_confirmation),
                    int(transaction.buyer_confirmation), transaction.admin_notes
                ))
                conn.commit()
                return True
        except sqlite3.IntegrityError:
            return False
    
    def get_transaction(self, transaction_id: str) -> Optional[Transaction]:
        """Get transaction by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM transactions WHERE transaction_id = ?", (transaction_id,))
            row = cursor.fetchone()
            
            if row:
                return Transaction(
                    transaction_id=row[0],
                    seller_id=row[1],
                    buyer_id=row[2],
                    title=row[3],
                    description=row[4],
                    amount=row[5],
                    commission=row[6],
                    status=TransactionStatus(row[7]),
                    created_at=datetime.fromisoformat(row[8]),
                    updated_at=datetime.fromisoformat(row[9]),
                    expires_at=datetime.fromisoformat(row[10]),
                    seller_confirmation=bool(row[11]),
                    buyer_confirmation=bool(row[12]),
                    admin_notes=row[13]
                )
            return None
    
    def update_transaction_status(self, transaction_id: str, status: TransactionStatus) -> bool:
        """Update transaction status"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE transactions 
                SET status = ?, updated_at = ? 
                WHERE transaction_id = ?
            """, (status.value, datetime.now().isoformat(), transaction_id))
            conn.commit()
            return cursor.rowcount > 0
    
    def get_user_transactions(self, user_id: int, status: Optional[TransactionStatus] = None) -> List[Transaction]:
        """Get user transactions"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if status:
                cursor.execute("""
                    SELECT * FROM transactions 
                    WHERE (seller_id = ? OR buyer_id = ?) AND status = ?
                    ORDER BY created_at DESC
                """, (user_id, user_id, status.value))
            else:
                cursor.execute("""
                    SELECT * FROM transactions 
                    WHERE seller_id = ? OR buyer_id = ?
                    ORDER BY created_at DESC
                """, (user_id, user_id))
            
            transactions = []
            for row in cursor.fetchall():
                transactions.append(Transaction(
                    transaction_id=row[0],
                    seller_id=row[1],
                    buyer_id=row[2],
                    title=row[3],
                    description=row[4],
                    amount=row[5],
                    commission=row[6],
                    status=TransactionStatus(row[7]),
                    created_at=datetime.fromisoformat(row[8]),
                    updated_at=datetime.fromisoformat(row[9]),
                    expires_at=datetime.fromisoformat(row[10]),
                    seller_confirmation=bool(row[11]),
                    buyer_confirmation=bool(row[12]),
                    admin_notes=row[13]
                ))
            
            return transactions
    
    def log_message(self, user_id: int, message_type: str, content: str):
        """Log user message"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO message_logs (user_id, message_type, content, timestamp)
                VALUES (?, ?, ?, ?)
            """, (user_id, message_type, content, datetime.now().isoformat()))
            conn.commit()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive bot statistics"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Current date calculations
            today = datetime.now()
            week_ago = today - timedelta(days=7)
            month_ago = today - timedelta(days=30)
            
            # Total users
            cursor.execute("SELECT COUNT(*) FROM users")
            total_users = cursor.fetchone()[0]
            
            # New users (weekly)
            cursor.execute("SELECT COUNT(*) FROM users WHERE registration_date >= ?", (week_ago.isoformat(),))
            weekly_new_users = cursor.fetchone()[0]
            
            # New users (monthly)
            cursor.execute("SELECT COUNT(*) FROM users WHERE registration_date >= ?", (month_ago.isoformat(),))
            monthly_new_users = cursor.fetchone()[0]
            
            # Active users (users with activity in last 7 days)
            try:
                cursor.execute("SELECT COUNT(DISTINCT user_id) FROM message_logs WHERE timestamp >= ?", (week_ago.isoformat(),))
                active_users = cursor.fetchone()[0] or 0
            except:
                active_users = 0
            
            # Total transactions
            cursor.execute("SELECT COUNT(*) FROM transactions")
            total_transactions = cursor.fetchone()[0]
            
            # Completed transactions
            cursor.execute("SELECT COUNT(*) FROM transactions WHERE status = ?", (TransactionStatus.COMPLETED.value,))
            completed_transactions = cursor.fetchone()[0]
            
            # Transactions today
            cursor.execute("SELECT COUNT(*) FROM transactions WHERE date(created_at) = date('now')")
            transactions_today = cursor.fetchone()[0]
            
            # Transactions this week
            cursor.execute("SELECT COUNT(*) FROM transactions WHERE created_at >= ?", (week_ago.isoformat(),))
            transactions_week = cursor.fetchone()[0]
            
            # Transactions this month
            cursor.execute("SELECT COUNT(*) FROM transactions WHERE created_at >= ?", (month_ago.isoformat(),))
            transactions_month = cursor.fetchone()[0]
            
            # Total volume
            cursor.execute("SELECT SUM(amount) FROM transactions WHERE status = ?", (TransactionStatus.COMPLETED.value,))
            total_volume = cursor.fetchone()[0] or 0
            
            # Total commission
            cursor.execute("SELECT SUM(commission) FROM transactions WHERE status = ?", (TransactionStatus.COMPLETED.value,))
            total_commission = cursor.fetchone()[0] or 0
            
            # Intermediary groups stats
            try:
                cursor.execute("SELECT COUNT(*) FROM intermediary_groups")
                total_groups = cursor.fetchone()[0] or 0
                
                cursor.execute("SELECT COUNT(*) FROM intermediary_groups WHERE status = 'active'")
                active_groups = cursor.fetchone()[0] or 0
                
                cursor.execute("SELECT COUNT(*) FROM intermediary_groups WHERE status = 'completed'")
                completed_groups = cursor.fetchone()[0] or 0
                
                cursor.execute("SELECT COUNT(*) FROM intermediary_groups WHERE status = 'waiting_participant'")
                waiting_groups = cursor.fetchone()[0] or 0
                
                cursor.execute("SELECT COUNT(*) FROM intermediary_groups WHERE status = 'cancelled'")
                cancelled_groups = cursor.fetchone()[0] or 0
            except:
                total_groups = active_groups = completed_groups = waiting_groups = cancelled_groups = 0
            
            # Total mediation requests
            try:
                cursor.execute("SELECT COUNT(*) FROM mediation_requests")
                total_mediation_requests = cursor.fetchone()[0] or 0
                
                cursor.execute("SELECT COUNT(*) FROM mediation_requests WHERE status = 'resolved'")
                resolved_mediation_requests = cursor.fetchone()[0] or 0
            except:
                total_mediation_requests = resolved_mediation_requests = 0
            
            # Calculate averages
            avg_daily_transactions = transactions_month / 30 if transactions_month > 0 else 0
            
            return {
                'total_users': total_users,
                'weekly_new_users': weekly_new_users,
                'monthly_new_users': monthly_new_users,
                'active_users': active_users,
                'total_transactions': total_transactions,
                'completed_transactions': completed_transactions,
                'transactions_today': transactions_today,
                'transactions_week': transactions_week,
                'transactions_month': transactions_month,
                'avg_daily_transactions': avg_daily_transactions,
                'success_rate': (completed_transactions / total_transactions * 100) if total_transactions > 0 else 0,
                'total_volume': total_volume,
                'total_commission': total_commission,
                'total_groups': total_groups,
                'active_groups': active_groups,
                'completed_groups': completed_groups,
                'waiting_groups': waiting_groups,
                'cancelled_groups': cancelled_groups,
                'group_success_rate': (completed_groups / total_groups * 100) if total_groups > 0 else 0,
                'total_mediation_requests': total_mediation_requests,
                'resolved_mediation_requests': resolved_mediation_requests,
                'mediation_success_rate': (resolved_mediation_requests / total_mediation_requests * 100) if total_mediation_requests > 0 else 0
            }
