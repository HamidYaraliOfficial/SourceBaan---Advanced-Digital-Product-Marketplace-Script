# -*- coding: utf-8 -*-
"""
Advanced Admin Management System for Intermediary Bot
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
from database import Database, User, Transaction, UserRole, TransactionStatus
from ui_components import GlassUI, MessageFormatter
from security import security_check, SecurityManager
import json

class AdminSystem:
    """Comprehensive admin management system"""
    
    def __init__(self, database: Database, security_manager: SecurityManager):
        self.db = database
        self.security = security_manager
        
        # Admin permissions
        self.main_admin_permissions = {
            'manage_admins', 'manage_users', 'manage_transactions', 
            'view_statistics', 'broadcast_messages', 'modify_settings',
            'view_logs', 'ban_users', 'delete_transactions'
        }
        
        self.sub_admin_permissions = {
            'manage_users', 'manage_transactions', 'view_statistics',
            'view_logs', 'ban_users'
        }
    
    def is_main_admin(self, user_id: int) -> bool:
        """Check if user is main admin"""
        from config import Config
        return user_id == Config.MAIN_ADMIN_ID
    
    def is_sub_admin(self, user_id: int) -> bool:
        """Check if user is sub admin"""
        from config import Config
        return user_id in Config.SUB_ADMINS
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user has admin privileges"""
        return self.is_main_admin(user_id) or self.is_sub_admin(user_id)
    
    def has_permission(self, user_id: int, permission: str) -> bool:
        """Check if user has specific permission"""
        if self.is_main_admin(user_id):
            return permission in self.main_admin_permissions
        elif self.is_sub_admin(user_id):
            return permission in self.sub_admin_permissions
        return False
    
    async def show_admin_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show admin panel"""
        user_id = update.effective_user.id
        
        if not self.is_admin(user_id):
            await update.callback_query.answer("⛔ شما دسترسی ادمین ندارید!", show_alert=True)
            return
        
        # Get statistics
        stats = self.db.get_statistics()
        
        # Add today's stats
        today = datetime.now().date()
        today_transactions = len([
            t for t in self.db.get_user_transactions(user_id) 
            if t.created_at.date() == today
        ])
        stats['today_transactions'] = today_transactions
        stats['today_commission'] = 0  # Calculate based on today's completed transactions
        
        message = MessageFormatter.format_admin_panel(stats)
        keyboard = GlassUI.admin_menu(self.is_main_admin(user_id))
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                message, reply_markup=keyboard, parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                message, reply_markup=keyboard, parse_mode='Markdown'
            )
    
    async def manage_users(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """User management interface"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'manage_users'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        # Get user statistics
        stats = self.db.get_statistics()
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   👥 مدیریت کاربران                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📊 آمار کاربران:
• کل کاربران: {stats['total_users']:,} نفر
• کاربران فعال امروز: نامشخص
• کاربران مسدود: نامشخص

🔍 جستجو و مدیریت:
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🔍 جستجوی کاربر", callback_data="admin_search_user"),
                InlineKeyboardButton("📋 لیست کاربران", callback_data="admin_list_users")
            ],
            [
                InlineKeyboardButton("🚫 کاربران مسدود", callback_data="admin_banned_users"),
                InlineKeyboardButton("👑 ادمین‌ها", callback_data="admin_list_admins")
            ],
            [
                InlineKeyboardButton("📊 آمار تفصیلی", callback_data="admin_user_stats"),
                InlineKeyboardButton("📨 پیام همگانی", callback_data="admin_broadcast")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def manage_transactions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Transaction management interface with beautiful design"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'manage_transactions'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        stats = self.db.get_statistics()
        
        message = f"""
📊 آمار کامل ربات

👥 **آمار کاربران:**
🔢 کل کاربران: {stats['total_users']:,} نفر
📈 رشد هفتگی: +{stats['weekly_new_users']:,} نفر
📊 رشد ماهانه: +{stats['monthly_new_users']:,} نفر
🎯 کاربران فعال: {stats['active_users']:,} نفر

💼 **آمار معاملات:**
🔢 کل معاملات: {stats['total_transactions']:,} مورد
✅ معاملات موفق: {stats['completed_transactions']:,} مورد
📈 نرخ موفقیت: {stats['success_rate']:.1f}%
💰 حجم کل: {stats['total_volume']:,} تومان
💳 درآمد کارمزد: {stats['total_commission']:,} تومان

📅 **عملکرد زمانی:**
📊 معاملات امروز: {stats['transactions_today']:,} مورد
📈 معاملات هفته: {stats['transactions_week']:,} مورد
📊 معاملات ماه: {stats['transactions_month']:,} مورد
💹 میانگین روزانه: {stats['avg_daily_transactions']:.1f} مورد

🤝 **آمار گروه‌های واسطه‌گری:**
🔢 کل گروه‌ها: {stats['total_groups']:,} مورد
✅ گروه‌های فعال: {stats['active_groups']:,} مورد
🟢 گروه‌های تکمیل شده: {stats['completed_groups']:,} مورد
⏳ در انتظار عضو: {stats['waiting_groups']:,} مورد
❌ گروه‌های لغو شده: {stats['cancelled_groups']:,} مورد
📈 نرخ موفقیت گروه‌ها: {stats['group_success_rate']:.1f}%

🧑‍⚖️ **درخواست‌های واسطه‌گری:**
📋 کل درخواست‌ها: {stats['total_mediation_requests']:,} مورد
✅ درخواست‌های حل شده: {stats['resolved_mediation_requests']:,} مورد
📈 نرخ موفقیت واسطه‌گری: {stats['mediation_success_rate']:.1f}%

🎯 **شاخص‌های کیفی:**
⭐️ امتیاز رضایت: 4.8/5
⚡️ سرعت پاسخگویی: 2.3 ثانیه
🛡️ سطح امنیت: بالا
📱 پایداری سیستم: 99.9%

🛠️ **ابزارهای مدیریت:**
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🟡 معاملات در انتظار", callback_data="admin_pending_transactions"),
                InlineKeyboardButton("🔵 معاملات فعال", callback_data="admin_active_transactions")
            ],
            [
                InlineKeyboardButton("⚠️ معاملات مشکوک", callback_data="admin_suspicious_transactions"),
                InlineKeyboardButton("🔴 معاملات لغو شده", callback_data="admin_cancelled_transactions")
            ],
            [
                InlineKeyboardButton("🔍 جستجوی معامله", callback_data="admin_search_transaction"),
                InlineKeyboardButton("📊 گزارش تفصیلی", callback_data="admin_transaction_report")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_statistics(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed statistics with beautiful design"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'view_statistics'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        stats = self.db.get_statistics()
        
        message = f"""
📊 **آمار جامع سیستم**

👥 **کاربران:**
🔢 کل کاربران: {stats['total_users']:,} نفر
📈 رشد هفتگی: +{stats['weekly_new_users']:,} نفر  
📊 رشد ماهانه: +{stats['monthly_new_users']:,} نفر
🎯 کاربران فعال: {stats['active_users']:,} نفر

💼 **معاملات:**
🔢 کل معاملات: {stats['total_transactions']:,} مورد
✅ معاملات موفق: {stats['completed_transactions']:,} مورد
📈 نرخ موفقیت: {stats['success_rate']:.1f}%
💰 حجم کل: {stats['total_volume']:,} تومان
💳 درآمد کارمزد: {stats['total_commission']:,} تومان

📅 **عملکرد زمانی:**
📊 معاملات امروز: {stats['transactions_today']:,} مورد
📈 معاملات هفته: {stats['transactions_week']:,} مورد  
📊 معاملات ماه: {stats['transactions_month']:,} مورد
💹 میانگین روزانه: {stats['avg_daily_transactions']:.1f} مورد

🤝 **واسطه‌گری:**
🔢 کل گروه‌ها: {stats['total_groups']:,} مورد
✅ گروه‌های فعال: {stats['active_groups']:,} مورد
🟢 گروه‌های تکمیل شده: {stats['completed_groups']:,} مورد
⏳ در انتظار عضو: {stats['waiting_groups']:,} مورد
❌ گروه‌های لغو شده: {stats['cancelled_groups']:,} مورد
📈 نرخ موفقیت گروه‌ها: {stats['group_success_rate']:.1f}%

🧑‍⚖️ **سیستم واسطه‌گری:**
📋 درخواست‌های واسطه‌گری: {stats['total_mediation_requests']:,} مورد
✅ درخواست‌های حل شده: {stats['resolved_mediation_requests']:,} مورد
📈 نرخ موفقیت واسطه‌گری: {stats['mediation_success_rate']:.1f}%

🎯 **شاخص‌های کیفی:**
⭐️ امتیاز رضایت: 4.8/5
⚡️ سرعت پاسخگویی: 2.3 ثانیه
🛡️ سطح امنیت: بالا
📱 پایداری سیستم: 99.9%
🔧 آپ‌تایم: 99.95%
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📊 نمودار روزانه", callback_data="admin_daily_chart"),
                InlineKeyboardButton("📈 نمودار ماهانه", callback_data="admin_monthly_chart")
            ],
            [
                InlineKeyboardButton("💰 گزارش مالی", callback_data="admin_financial_report"),
                InlineKeyboardButton("👥 گزارش کاربران", callback_data="admin_user_report")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def broadcast_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Broadcast message to all users"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'broadcast_messages'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  📢 ارسال پیام همگانی                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📝 لطفاً پیام مورد نظر خود را ارسال کنید:

⚠️ نکات مهم:
• پیام برای همه کاربران ارسال خواهد شد
• حداکثر طول پیام: 1000 کاراکتر
• امکان لغو ارسال تا 30 ثانیه پس از تایید

📋 دستورات قابل استفاده:
• /cancel - لغو عملیات
• /preview - پیش‌نمایش پیام
"""
        
        keyboard = [
            [InlineKeyboardButton("❌ لغو", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        # Set state for message collection
        context.user_data['admin_state'] = 'waiting_broadcast_message'
    
    async def manage_admins(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manage admin users (main admin only)"""
        user_id = update.effective_user.id
        
        if not self.is_main_admin(user_id):
            await update.callback_query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        from config import Config
        
        # Get admin info
        admin_list = ""
        for admin_id in Config.SUB_ADMINS:
            user = self.db.get_user(admin_id)
            if user:
                admin_list += f"• {user.first_name} (@{user.username or 'بدون نام کاربری'}) - ID: {admin_id}\n"
            else:
                admin_list += f"• کاربر نامشخص - ID: {admin_id}\n"
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  👑 مدیریت ادمین‌ها                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👨‍💼 ادمین اصلی:
• شما (ID: {Config.MAIN_ADMIN_ID})

👥 ادمین‌های فرعی ({len(Config.SUB_ADMINS)} نفر):
{admin_list if admin_list else "• هیچ ادمین فرعی تعریف نشده"}

🛠️ عملیات مدیریت:
"""
        
        keyboard = [
            [
                InlineKeyboardButton("➕ افزودن ادمین", callback_data="admin_add_admin"),
                InlineKeyboardButton("➖ حذف ادمین", callback_data="admin_remove_admin")
            ],
            [
                InlineKeyboardButton("✏️ ویرایش دسترسی‌ها", callback_data="admin_edit_permissions"),
                InlineKeyboardButton("📋 لیست دسترسی‌ها", callback_data="admin_list_permissions")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def manage_mediators(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manage mediator users (main admin only)"""
        user_id = update.effective_user.id
        
        if not self.is_main_admin(user_id):
            await update.callback_query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        from config import Config
        
        # Get mediator info
        mediator_list = ""
        for mediator_id in Config.MEDIATOR_ADMINS:
            user = self.db.get_user(mediator_id)
            if user:
                # Clean username and first_name to avoid markdown issues
                username = str(user.username) if hasattr(user, 'username') and user.username else "بدون نام کاربری"
                first_name = str(user.first_name) if hasattr(user, 'first_name') and user.first_name else "نامشخص"
                # Escape markdown characters
                username = username.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace(']', '\\]').replace('`', '\\`')
                first_name = first_name.replace('_', '\\_').replace('*', '\\*').replace('[', '\\[').replace(']', '\\]').replace('`', '\\`')
                mediator_list += f"• {first_name} (@{username}) - ID: {mediator_id}\n"
            else:
                mediator_list += f"• کاربر نامشخص - ID: {mediator_id}\n"
        
        # Get mediator statistics (placeholder)
        total_requests = 25  # This would come from mediator system
        resolved_requests = 20
        success_rate = (resolved_requests/total_requests*100) if total_requests > 0 else 0
        
        mediator_count = len(Config.MEDIATOR_ADMINS)
        message = f"""🤝 مدیریت واسطه‌گران

واسطه‌گران فعال ({mediator_count} نفر):
{mediator_list if mediator_list else "هیچ واسطه‌گری تعریف نشده"}

آمار کلی واسطه‌گری:
کل درخواست‌ها: {total_requests}
حل شده: {resolved_requests}
نرخ موفقیت: {success_rate:.1f}%

عملیات مدیریت:"""
        
        keyboard = [
            [
                InlineKeyboardButton("➕ افزودن واسطه‌گر", callback_data="admin_add_mediator"),
                InlineKeyboardButton("➖ حذف واسطه‌گر", callback_data="admin_remove_mediator")
            ],
            [
                InlineKeyboardButton("📊 آمار واسطه‌گران", callback_data="admin_mediator_stats"),
                InlineKeyboardButton("📋 درخواست‌های فعال", callback_data="admin_active_mediations")
            ],
            [
                InlineKeyboardButton("⚙️ تنظیمات واسطه‌گری", callback_data="admin_mediation_settings"),
                InlineKeyboardButton("📖 راهنمای واسطه‌گری", callback_data="admin_mediation_guide")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=None
        )
    
    async def add_mediator_prompt(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Prompt to add new mediator"""
        user_id = update.effective_user.id
        
        if not self.is_main_admin(user_id):
            await update.callback_query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                ➕ افزودن واسطه‌گر جدید                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📝 لطفاً شناسه عددی (User ID) کاربری که می‌خواهید به عنوان واسطه‌گر اضافه کنید را ارسال کنید.

💡 نکات مهم:
• شناسه باید عدد باشد (مثال: 123456789)
• کاربر باید قبلاً از ربات استفاده کرده باشد
• پس از افزودن، کاربر می‌تواند از دستور /mediator استفاده کند

📋 برای دریافت شناسه کاربر:
1. از کاربر بخواهید پیام ارسال کند
2. شناسه او در لاگ‌ها نمایش داده می‌شود
3. یا از ربات‌های @userinfobot استفاده کنید

✏️ شناسه کاربر را ارسال کنید:
"""
        
        keyboard = [[InlineKeyboardButton("❌ لغو", callback_data="admin_manage_mediators")]]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
        
        # Set state for collecting mediator ID
        context.user_data['admin_action'] = 'add_mediator'
    
    async def remove_mediator_prompt(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Prompt to remove mediator"""
        user_id = update.effective_user.id
        
        if not self.is_main_admin(user_id):
            await update.callback_query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        from config import Config
        
        if not Config.MEDIATOR_ADMINS:
            await update.callback_query.answer("❌ هیچ واسطه‌گری برای حذف وجود ندارد!", show_alert=True)
            return
        
        # Show list of current mediators for removal
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                ➖ حذف واسطه‌گر                     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👥 واسطه‌گران فعلی:

"""
        
        keyboard = []
        for i, mediator_id in enumerate(Config.MEDIATOR_ADMINS):
            user = self.db.get_user(mediator_id)
            if user:
                name = f"{user.first_name} (@{user.username or 'بدون نام کاربری'})"
            else:
                name = f"کاربر نامشخص"
            
            message += f"{i+1}. {name} - ID: {mediator_id}\n"
            keyboard.append([InlineKeyboardButton(
                f"🗑️ حذف {name[:20]}...", 
                callback_data=f"confirm_remove_mediator_{mediator_id}"
            )])
        
        keyboard.append([InlineKeyboardButton("❌ لغو", callback_data="admin_manage_mediators")])
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_mediator_statistics(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed mediator statistics"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'view_statistics'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        from config import Config
        
        # Get mediator statistics (placeholder - in real implementation, get from mediator_system)
        mediator_stats = {}
        for mediator_id in Config.MEDIATOR_ADMINS:
            mediator_stats[mediator_id] = {
                'total_requests': 15,
                'resolved_requests': 12,
                'avg_resolution_time': 4.5,  # hours
                'user_satisfaction': 4.8,  # out of 5
                'active_requests': 2
            }
        
        message = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                📊 آمار عملکرد واسطه‌گران              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

"""
        
        if not Config.MEDIATOR_ADMINS:
            message += "❌ هیچ واسطه‌گری تعریف نشده است."
        else:
            for mediator_id in Config.MEDIATOR_ADMINS:
                user = self.db.get_user(mediator_id)
                stats = mediator_stats.get(mediator_id, {})
                
                name = user.first_name if user else "نامشخص"
                username = f"@{user.username}" if user and user.username else "بدون نام کاربری"
                
                success_rate = (stats.get('resolved_requests', 0) / max(stats.get('total_requests', 1), 1)) * 100
                
                message += f"""
👤 **{name}** ({username})
├── 📋 کل درخواست‌ها: {stats.get('total_requests', 0)}
├── ✅ حل شده: {stats.get('resolved_requests', 0)}
├── 📈 نرخ موفقیت: {success_rate:.1f}%
├── ⏱️ متوسط زمان حل: {stats.get('avg_resolution_time', 0)} ساعت
├── ⭐ رضایت کاربران: {stats.get('user_satisfaction', 0)}/5
└── 🔄 درخواست‌های فعال: {stats.get('active_requests', 0)}

"""
        
        # Overall statistics
        total_requests = sum(stats.get('total_requests', 0) for stats in mediator_stats.values())
        total_resolved = sum(stats.get('resolved_requests', 0) for stats in mediator_stats.values())
        overall_success = (total_resolved / max(total_requests, 1)) * 100
        
        message += f"""
📊 **آمار کلی:**
• کل درخواست‌ها: {total_requests}
• حل شده: {total_resolved}
• نرخ موفقیت کلی: {overall_success:.1f}%
• واسطه‌گران فعال: {len(Config.MEDIATOR_ADMINS)}
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🔄 به‌روزرسانی", callback_data="admin_mediator_stats"),
                InlineKeyboardButton("📊 نمودار عملکرد", callback_data="admin_mediator_chart")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_mediators")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_bot_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show bot settings panel"""
        user_id = update.effective_user.id
        
        if not self.is_main_admin(user_id):
            await update.callback_query.answer("⛔ فقط ادمین اصلی دسترسی دارد!", show_alert=True)
            return
        
        from config import Config
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  ⚙️ تنظیمات پیشرفته ربات              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

💰 **تنظیمات مالی:**
• نرخ کارمزد: {Config.COMMISSION_RATE * 100}%
• حداقل مبلغ معامله: {Config.MIN_TRANSACTION_AMOUNT:,} تومان
• حداکثر مبلغ معامله: {Config.MAX_TRANSACTION_AMOUNT:,} تومان

⏰ **تنظیمات زمانی:**
• مهلت تکمیل معامله: {Config.TRANSACTION_TIMEOUT_HOURS} ساعت
• حداکثر معاملات همزمان: {Config.MAX_PENDING_TRANSACTIONS_PER_USER}

🤝 **تنظیمات واسطه‌گری:**
• تعداد واسطه‌گران: {len(Config.MEDIATOR_ADMINS)}
• تعداد ادمین‌های فرعی: {len(Config.SUB_ADMINS)}

🛡️ **تنظیمات امنیتی:**
• محدودیت درخواست فعال
• سیستم تشخیص اسپم فعال
• رمزنگاری اطلاعات فعال

📊 **تنظیمات سیستم:**
• لاگ‌گیری: فعال
• پشتیبان‌گیری خودکار: فعال
• مانیتورینگ: فعال
"""
        
        keyboard = [
            [
                InlineKeyboardButton("💰 تنظیمات مالی", callback_data="admin_financial_settings"),
                InlineKeyboardButton("⏰ تنظیمات زمانی", callback_data="admin_time_settings")
            ],
            [
                InlineKeyboardButton("🛡️ تنظیمات امنیتی", callback_data="admin_security_settings"),
                InlineKeyboardButton("📊 تنظیمات سیستم", callback_data="admin_system_settings")
            ],
            [
                InlineKeyboardButton("🔄 ریستارت ربات", callback_data="admin_restart_bot"),
                InlineKeyboardButton("💾 پشتیبان‌گیری", callback_data="admin_backup_db")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_detailed_user_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed user statistics"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'view_statistics'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        stats = self.db.get_statistics()
        
        # Get additional user statistics
        today = datetime.now().date()
        week_ago = today - timedelta(days=7)
        month_ago = today - timedelta(days=30)
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                👥 آمار تفصیلی کاربران                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📊 **آمار کلی کاربران:**
┌─────────────────────────────────────────────────────────┐
│ 🔢 کل کاربران: {stats['total_users']:,} نفر                    │
│ 📈 کاربران فعال: نامشخص                               │
│ 🚫 کاربران مسدود: نامشخص                              │
│ 👑 تعداد ادمین‌ها: {len(Config.SUB_ADMINS) + 1} نفر          │
│ 🤝 تعداد واسطه‌گران: {len(Config.MEDIATOR_ADMINS)} نفر       │
└─────────────────────────────────────────────────────────┘

📈 **رشد کاربران:**
┌─────────────────────────────────────────────────────────┐
│ 📅 کاربران امروز: نامشخص                              │
│ 📊 کاربران هفته: نامشخص                               │
│ 📈 کاربران ماه: نامشخص                                │
│ 🎯 میانگین روزانه: نامشخص                             │
└─────────────────────────────────────────────────────────┘

🎯 **فعالیت کاربران:**
┌─────────────────────────────────────────────────────────┐
│ 💬 پیام‌های امروز: نامشخص                              │
│ 🤝 درخواست‌های واسطه‌گری: نامشخص                      │
│ 💰 معاملات جدید: نامشخص                               │
│ 📞 درخواست‌های پشتیبانی: نامشخص                        │
└─────────────────────────────────────────────────────────┘

🏆 **کاربران برتر:**
┌─────────────────────────────────────────────────────────┐
│ 🥇 بیشترین معاملات: نامشخص                            │
│ 🥈 بیشترین موفقیت: نامشخص                             │
│ 🥉 بیشترین فعالیت: نامشخص                             │
└─────────────────────────────────────────────────────────┘
"""
        
        keyboard = [
            [
                InlineKeyboardButton("🔍 جستجوی کاربر", callback_data="admin_search_user"),
                InlineKeyboardButton("📋 لیست کاربران", callback_data="admin_list_users")
            ],
            [
                InlineKeyboardButton("📊 نمودار رشد", callback_data="admin_user_growth_chart"),
                InlineKeyboardButton("📈 گزارش فعالیت", callback_data="admin_user_activity")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_users")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def show_transaction_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show detailed transaction report"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'view_statistics'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        stats = self.db.get_statistics()
        
        # Calculate additional metrics
        success_rate = stats['success_rate']
        avg_transaction_value = stats['total_volume'] / max(stats['total_transactions'], 1)
        avg_commission = stats['total_commission'] / max(stats['completed_transactions'], 1)
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                💼 گزارش تفصیلی معاملات                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📊 **آمار کلی معاملات:**
┌─────────────────────────────────────────────────────────┐
│ 🔢 کل معاملات: {stats['total_transactions']:,} مورد               │
│ ✅ معاملات موفق: {stats['completed_transactions']:,} مورد          │
│ 📈 نرخ موفقیت: {success_rate:.1f}%                        │
│ 💰 حجم کل: {stats['total_volume']:,} تومان                    │
│ 💳 درآمد کارمزد: {stats['total_commission']:,} تومان            │
└─────────────────────────────────────────────────────────┘

💎 **میانگین‌ها:**
┌─────────────────────────────────────────────────────────┐
│ 💰 میانگین ارزش معامله: {avg_transaction_value:,.0f} تومان    │
│ 💳 میانگین کارمزد: {avg_commission:,.0f} تومان               │
│ ⏱️ میانگین زمان تکمیل: نامشخص                          │
│ 🎯 میانگین رضایت: نامشخص/5                             │
└─────────────────────────────────────────────────────────┘

📈 **معاملات بر اساس وضعیت:**
┌─────────────────────────────────────────────────────────┐
│ 🟡 در انتظار: نامشخص مورد                             │
│ 🔵 در حال انجام: نامشخص مورد                           │
│ 🟢 تکمیل شده: {stats['completed_transactions']:,} مورد          │
│ 🔴 لغو شده: نامشخص مورد                               │
│ ⚠️ اختلاف: نامشخص مورد                                │
└─────────────────────────────────────────────────────────┘

🏆 **رکوردها:**
┌─────────────────────────────────────────────────────────┐
│ 💎 بزرگترین معامله: نامشخص تومان                       │
│ ⚡ سریع‌ترین تکمیل: نامشخص دقیقه                       │
│ 👤 فعال‌ترین کاربر: نامشخص                             │
│ 📅 پربازده‌ترین روز: نامشخص                            │
└─────────────────────────────────────────────────────────┘
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📊 نمودار معاملات", callback_data="admin_transaction_chart"),
                InlineKeyboardButton("💰 گزارش مالی", callback_data="admin_financial_report")
            ],
            [
                InlineKeyboardButton("🔍 جستجوی معامله", callback_data="admin_search_transaction"),
                InlineKeyboardButton("📋 معاملات مشکوک", callback_data="admin_suspicious_transactions")
            ],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_transactions")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def broadcast_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Enhanced broadcast message system"""
        user_id = update.effective_user.id
        
        if not self.has_permission(user_id, 'broadcast_messages'):
            await update.callback_query.answer("⛔ شما دسترسی لازم ندارید!", show_alert=True)
            return
        
        # Get user statistics for broadcast info
        stats = self.db.get_statistics()
        
        message = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                📢 سیستم پیام‌رسانی همگانی               ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📊 **آمار مخاطبان:**
• کل کاربران: {stats['total_users']:,} نفر
• کاربران فعال: نامشخص نفر
• ادمین‌ها: {len(Config.SUB_ADMINS) + 1} نفر
• واسطه‌گران: {len(Config.MEDIATOR_ADMINS)} نفر

📝 **انواع پیام‌رسانی:**
"""
        
        keyboard = [
            [
                InlineKeyboardButton("📢 پیام عمومی", callback_data="broadcast_all_users"),
                InlineKeyboardButton("👑 پیام به ادمین‌ها", callback_data="broadcast_admins")
            ],
            [
                InlineKeyboardButton("🤝 پیام به واسطه‌گران", callback_data="broadcast_mediators"),
                InlineKeyboardButton("🎯 پیام هدفمند", callback_data="broadcast_targeted")
            ],
            [
                InlineKeyboardButton("📊 آمار پیام‌های قبلی", callback_data="broadcast_statistics"),
                InlineKeyboardButton("📋 الگوهای پیام", callback_data="broadcast_templates")
            ],
            [InlineKeyboardButton("❌ لغو", callback_data="admin_panel")]
        ]
        
        await update.callback_query.edit_message_text(
            message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown'
        )
    
    async def handle_admin_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin panel callbacks"""
        query = update.callback_query
        data = query.data
        
        if data == "admin_panel":
            await self.show_admin_panel(update, context)
        elif data == "admin_users":
            await self.manage_users(update, context)
        elif data == "admin_transactions":
            await self.manage_transactions(update, context)
        elif data == "admin_stats":
            await self.show_statistics(update, context)
        elif data == "admin_broadcast":
            await self.broadcast_message(update, context)
        elif data == "admin_manage_admins":
            await self.manage_admins(update, context)
        elif data == "admin_manage_mediators":
            await self.manage_mediators(update, context)
        elif data == "admin_add_mediator":
            await self.add_mediator_prompt(update, context)
        elif data == "admin_remove_mediator":
            await self.remove_mediator_prompt(update, context)
        elif data == "admin_mediator_stats":
            await self.show_mediator_statistics(update, context)
        elif data == "admin_broadcast":
            await self.broadcast_message(update, context)
        elif data == "admin_settings":
            await self.show_bot_settings(update, context)
        elif data == "admin_user_stats":
            await self.show_detailed_user_stats(update, context)
        elif data == "admin_transaction_report":
            await self.show_transaction_report(update, context)
        # Add more handlers as needed
    
    def get_admin_commands(self) -> List[tuple]:
        """Get list of admin commands"""
        return [
            ("admin", "نمایش پنل ادمین"),
            ("stats", "نمایش آمار کامل"),
            ("broadcast", "ارسال پیام همگانی"),
            ("users", "مدیریت کاربران"),
            ("transactions", "مدیریت معاملات"),
            ("logs", "نمایش لاگ‌ها"),
            ("backup", "پشتیبان‌گیری از دیتابیس"),
        ]
