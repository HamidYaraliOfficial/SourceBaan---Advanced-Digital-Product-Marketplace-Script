<?php
require_once __DIR__.'/init.php';
require_auth();
$user = current_user();


if (!isset($_SESSION['welcome_shown']) || $_SESSION['welcome_shown'] === false) {
    $welcomeMessage = "سلام " . htmlspecialchars($user['name']) . "، به چتروم پرفکت خوش آمدی 🎉";
    $_SESSION['welcome_shown'] = true;
} else {
    $welcomeMessage = null;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>گفتگو | <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="assets/style.css">
  <script>const CURRENT_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE) ?>;</script>
  <script defer src="assets/theme.js"></script>
  <script defer src="assets/chat.js"></script>
</head>
<body>
<header class="topbar">
  <div class="left">
    <button id="themeToggle" class="btn secondary">
      <span id="themeIcon">☀️</span>
    </button>
  </div>
  <div class="center">
    <strong><?= APP_NAME ?></strong>
  </div>
  <div class="right">
    <?php if ($user['role'] === 'admin'): ?>
      <a class="btn secondary" href="admin.php">پنل ادمین</a>
    <?php endif; ?>
    <a class="btn" href="logout.php">خروج</a>
  </div>
</header>

<main class="chat-container">
  <aside class="usercard">
    <div class="title">کاربر</div>
    <div class="name"><?= htmlspecialchars($user['nickname'] ?: $user['name']) ?></div>
    <div class="email"><?= htmlspecialchars($user['email']) ?></div>
    <div class="role"><?= $user['role']==='admin' ? 'ادمین' : 'کاربر' ?></div>
  </aside>

  <section class="chatbox">
    <div id="messages" class="messages" aria-live="polite">
      <?php if ($welcomeMessage): ?>
        <div class="message system"><?= $welcomeMessage ?></div>
      <?php endif; ?>
    </div>
    <form id="sendForm" class="sendbar">
      <input type="text" id="msg" name="body" placeholder="پیام خود را بنویسید..." autocomplete="off" required>
      <button class="btn" type="submit">ارسال</button>
    </form>
  </section>
</main>
</body>
</html>