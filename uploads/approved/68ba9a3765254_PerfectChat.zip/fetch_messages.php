<?php
require_once __DIR__.'/init.php';
require_auth();
header('Content-Type: application/json; charset=utf-8');

$after = isset($_GET['after']) ? intval($_GET['after']) : 0;

if ($after > 0) {
    $stmt = $pdo->prepare('
        SELECT m.id, m.body, m.created_at, m.type,
               COALESCE(u.nickname, u.name) AS display_name,
               u.role
        FROM messages m
        JOIN users u ON u.id = m.user_id
        WHERE m.id > ?
        ORDER BY m.id ASC
        LIMIT 200
    ');
    $stmt->execute([$after]);
    $rows = $stmt->fetchAll();
    $latest = 0;
    if (!empty($rows)) $latest = end($rows)['id'];
    echo json_encode(['ok'=>true,'messages'=>$rows, 'latest'=>$latest], JSON_UNESCAPED_UNICODE);
    exit;
} else {
    $stmt = $pdo->query('
        SELECT m.id, m.body, m.created_at, m.type,
               COALESCE(u.nickname, u.name) AS display_name,
               u.role
        FROM messages m
        JOIN users u ON u.id = m.user_id
        ORDER BY m.id DESC
        LIMIT 100
    ');
    $rows = $stmt->fetchAll();
    $rows = array_reverse($rows);
    echo json_encode(['ok'=>true,'messages'=>$rows, 'latest'=> end($rows)['id'] ?? 0], JSON_UNESCAPED_UNICODE);
    exit;
}
?>