// assets/chat.js
const POLL_MS = 2000;
let latestId = 0;
let polling = null;

function el(tag, attrs = {}, text = '') {
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
  if (text) e.textContent = text;
  return e;
}

function createBlueTick() {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  svg.style.width = '14px';
  svg.style.height = '14px';
  svg.style.display = 'inline-block';
  svg.style.marginLeft = '6px';

  const circle = document.createElementNS(ns, 'circle');
  circle.setAttribute('cx', '12');
  circle.setAttribute('cy', '12');
  circle.setAttribute('r', '11');
  circle.setAttribute('fill', '#1DA1F2');

  const check = document.createElementNS(ns, 'path');
  check.setAttribute('d', 'M7 12.5l3.2 3.2L17.5 8.5');
  check.setAttribute('fill', 'none');
  check.setAttribute('stroke', '#FFFFFF');
  check.setAttribute('stroke-width', '2.4');
  check.setAttribute('stroke-linecap', 'round');
  check.setAttribute('stroke-linejoin', 'round');

  svg.appendChild(circle);
  svg.appendChild(check);
  return svg;
}

async function fetchInitial() {
  try {
    const r = await fetch('fetch_messages.php');
    const j = await r.json();
    if (!j.ok) return;
    latestId = j.latest || 0;
    renderMessages(j.messages);
  } catch (err) {
    console.error('fetchInitial error', err);
  }
}

async function poll() {
  try {
    const r = await fetch('fetch_messages.php?after=' + encodeURIComponent(latestId));
    const j = await r.json();
    if (!j.ok) return;
    if (j.messages && j.messages.length) {
      latestId = j.latest || latestId;
      appendMessages(j.messages);
    }
  } catch (e) {
    console.error('poll error', e);
  }
}

function renderMessages(list) {
  const box = document.getElementById('messages');
  box.innerHTML = '';
  list.forEach(m => box.appendChild(renderMessage(m)));
  box.scrollTop = box.scrollHeight;
}

function appendMessages(list) {
  const box = document.getElementById('messages');
  list.forEach(m => box.appendChild(renderMessage(m)));
  box.scrollTop = box.scrollHeight;
}


function renderMessage(m) {
  if (m.type === 'system') {
    const div = el('div', { class: 'msg system' });
    const body = el('div', { class: 'body' }, m.body);
    div.appendChild(body);
    return div;
  }

  const div = el('div', { class: 'msg' });
  const meta = el('div', { class: 'meta' });

  const name = el('span', { class: 'username' }, m.display_name);
  if (m.role === 'admin') {
    const tick = createBlueTick();
    name.appendChild(tick);
  }

  let timeStr = '';
  try {
    const t = new Date(m.created_at.replace(' ', 'T'));
    timeStr = t.toLocaleString('fa-IR');
  } catch (e) {
    timeStr = m.created_at;
  }
  const time = el('span', { class: 'time' }, timeStr);

  meta.appendChild(name);
  meta.appendChild(time);

  const body = el('div', { class: 'body' }, m.body);

  div.appendChild(meta);
  div.appendChild(body);
  return div;
}

async function sendMessage(e) {
  e.preventDefault();
  const inp = document.getElementById('msg');
  const body = inp.value.trim();
  if (!body) return;
  inp.value = '';

  try {
    const fd = new FormData();
    fd.append('body', body);
    const r = await fetch('post_message.php', { method: 'POST', body: fd });
    const j = await r.json();

    if (!j.ok) {
      console.error('post_message failed', j);
      return;
    }


    const tmpId = j.id || (latestId + 1);
    const msg = {
      id: tmpId,
      body: body,
      created_at: new Date().toISOString().slice(0,19).replace('T',' '),
      display_name: (window.CURRENT_USER && (window.CURRENT_USER.nickname || window.CURRENT_USER.name)) || 'شما',
      role: (window.CURRENT_USER && window.CURRENT_USER.role) || 'user',
      type: 'user'
    };
    appendMessages([msg]);


    if (j.id) latestId = Math.max(latestId, j.id);

  } catch (err) {
    console.error('sendMessage error', err);
  }
}

document.addEventListener('DOMContentLoaded', function () {
  fetchInitial().then(() => {
    polling = setInterval(poll, POLL_MS);
  });

  const f = document.getElementById('sendForm');
  if (f) {
    f.addEventListener('submit', sendMessage);
  } else {
    console.warn('sendForm not found');
  }

  const themeBtn = document.getElementById('themeToggle');
  if (themeBtn) {
    const icon = document.getElementById('themeIcon');
    if (document.documentElement.classList.contains('light')) {
      if (icon) icon.textContent = '☀️';
    } else {
      if (icon) icon.textContent = '🌙';
    }
  }
});