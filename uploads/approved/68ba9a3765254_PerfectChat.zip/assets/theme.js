(function(){
  const root = document.documentElement;
  const themeIcon = document.getElementById('themeIcon');

  const saved = localStorage.getItem('theme');
  if (saved === 'light') {
    root.classList.add('light');
    if(themeIcon) themeIcon.textContent = '☀️';
  } else {
    if(themeIcon) themeIcon.textContent = '🌙';
  }

  document.addEventListener('DOMContentLoaded', function(){
    const btn = document.getElementById('themeToggle');
    if (btn && themeIcon) {
      btn.addEventListener('click', function(){
        btn.classList.add('animate');
        setTimeout(() => btn.classList.remove('animate'), 300);

        root.classList.toggle('light');
        const isLight = root.classList.contains('light');
        localStorage.setItem('theme', isLight ? 'light' : 'dark');

        themeIcon.textContent = isLight ? '☀️' : '🌙';
      });
    }
  });
})();