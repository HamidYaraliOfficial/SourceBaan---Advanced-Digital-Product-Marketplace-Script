<?php
require_once __DIR__ . '/init.php';

$message = "";
$tab = isset($_GET['tab']) && $_GET['tab'] === "register" ? "register" : "login";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password !== $confirm) {
        $message = "رمز عبور و تکرار آن یکسان نیستند.";
        $tab = "register";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $hash]);


            $user_id = $pdo->lastInsertId();


            $user = [
                'id' => $user_id,
                'name' => $name,
                'email' => $email
            ];

            $_SESSION['user'] = $user;
            $_SESSION['welcome_shown'] = false;


            $stmt = $pdo->prepare("INSERT INTO messages (user_id, body, type) VALUES (?, ?, 'system')");
            $stmt->execute([$user['id'], "سلام {$user['name']}، به چتروم پرفکت خوش آمدی 🎉"]);

            header("Location: chat.php");
            exit;
        } catch (Exception $e) {
            $message = "ایمیل تکراری است یا خطایی رخ داد.";
            $tab = "register";
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR name = ?");
    $stmt->execute([$email, $email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = $user;
        $_SESSION['welcome_shown'] = false;

        header("Location: chat.php");
        exit;
    } else {
        $message = "ایمیل/نام کاربری یا رمز عبور اشتباه است.";
        $tab = "login";
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ورود / ثبت نام - Perfect Chat</title>
  <style>
    :root {
      --bg: #f8f9fd;
      --text: #000;
      --card-bg: #fff;
    }
    body.dark {
      --bg: #121212;
      --text: #f1f1f1;
      --card-bg: #1e1e1e;
    }
    body {
      font-family: Vazir, Tahoma, sans-serif;
      background: var(--bg);
      color: var(--text);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      transition: background 0.3s, color 0.3s;
    }
    .auth-container {
      background: var(--card-bg);
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      padding: 30px;
      width: 100%;
      max-width: 400px;
      transition: background 0.3s;
      position: relative;
    }
    .theme-toggle {
      position: absolute;
      top: 10px;
      left: 10px;
      background: #4f46e5;
      border: none;
      border-radius: 50%;
      width: 36px;
      height: 36px;
      color: #fff;
      font-size: 18px;
      cursor: pointer;
    }
    .logo {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: linear-gradient(135deg,#4f46e5,#3b82f6);
      margin: 0 auto 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 36px;
    }
    h2 {
      text-align: center;
      margin: 0 0 20px;
    }
    .tabs {
      display: flex;
      margin-bottom: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      overflow: hidden;
    }
    .tabs a {
      flex: 1;
      text-align: center;
      padding: 10px;
      text-decoration: none;
      color: var(--text);
      background: #f1f1f1;
    }
    .tabs a.active {
      background: #4f46e5;
      color: #fff;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    input {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }
    button.submit-btn {
      background: linear-gradient(135deg,#4f46e5,#3b82f6);
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 12px;
      cursor: pointer;
      font-size: 16px;
    }
    footer {
      text-align: center;
    }
    .message {
      text-align: center;
      color: red;
      margin-bottom: 10px;
    }
    @media (max-width: 500px) {
      .auth-container {
        margin: 10px;
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="auth-container">
    <button class="theme-toggle" onclick="toggleTheme()">🌙</button>
    <div>
      <img class="logo" src="assets/logo.png">
    </div>
    <h2>به پرفکت چت خوش آمدید</h2>
    <?php if ($message): ?>
      <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="tabs">
      <a href="?tab=login" class="<?= $tab==='login'?'active':'' ?>">ورود</a>
      <a href="?tab=register" class="<?= $tab==='register'?'active':'' ?>">ثبت نام</a>
    </div>

    <?php if ($tab === "login"): ?>
      <form method="post">
        <input type="text" name="email" placeholder="ایمیل یا نام کاربری" required>
        <input type="password" name="password" placeholder="رمز عبور" required>
        <button type="submit" name="login" class="submit-btn">ورود به حساب</button>
      </form>
      <footer>
        <a href="https://t.me/Maniawma">جهت ارتباط با پشتیبانی کلیک کنید.</a>
      </footer>
    <?php else: ?>
      <form method="post">
        <input type="text" name="name" placeholder="نام کاربری" required>
        <input type="email" name="email" placeholder="ایمیل" required>
        <input type="password" name="password" placeholder="رمز عبور" required>
        <input type="password" name="confirm" placeholder="تکرار رمز عبور" required>
        <button type="submit" name="register" class="submit-btn">ثبت نام</button>
      </form>
      <footer>
        <a href="https://t.me/Maniawma">جهت ارتباط با پشتیبانی کلیک کنید.</a>
      </footer>
    <?php endif; ?>
  </div>

  <script>
    function toggleTheme() {
      document.body.classList.toggle("dark");
      localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
      document.querySelector(".theme-toggle").textContent =
        document.body.classList.contains("dark") ? "☀️" : "🌙";
    }
    (function() {
      if (localStorage.getItem("theme") === "dark") {
        document.body.classList.add("dark");
        document.querySelector(".theme-toggle").textContent = "☀️";
      }
    })();
  </script>
</body>
</html>