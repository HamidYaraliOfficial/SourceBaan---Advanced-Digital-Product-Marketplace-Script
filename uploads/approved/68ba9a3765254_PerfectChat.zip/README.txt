Perfect Chat — quick install (cPanel)
------------------------------------

راهنمای فایلا:
- config.php (ست کردن اطلاعات دیتابیس و ادمین)
- db.sql (ساخت جدول با utf8mb4)
- init.php (PDO utf8mb4)
- register.php, login.php, logout.php
- chat.php (صفحه چت)
- post_message.php, fetch_messages.php (API)
- admin.php (پنل ادمین)
- profanity.php (فایل فیلتر فحش)
- assets/style.css, assets/theme.js, assets/chat.js
- assets/logo.png (لوگوی سایت رو تغییر بدید)
- .htaccess

موارد لازم جهت اشپزی:
- تو سیپنل دیتابیس بسازید
-تو PhpMyAdmin فایل db.sql رو ایمپورت کنید.
- تو config.php اطلاعات دیتابیس و ایمیل ادمین رو ست کنید
ـ فایلا رو توی هاست اپلود کنین
ـ تمامه حالا برین تو سایتتون ریجستر کنین و وارد اکانتتون شید

------------------------------------
Dev: t.me/Maniawma