<?php
require_once __DIR__.'/config.php';
if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

mb_internal_encoding('UTF-8');
date_default_timezone_set(TIMEZONE);

try {
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
$pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
$pdo->exec("SET NAMES utf8mb4");
$pdo->exec("SET CHARACTER SET utf8mb4");
} catch (Exception $e) {
    http_response_code(500);
    die('Database connection failed.');
}

session_name('perfect_chat_sid');
session_set_cookie_params([
    'lifetime' => 60*60*24*30,
    'path' => '/',
    'domain' => '',
    'secure' => COOKIE_SECURE,
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

function ensure_admin_role($pdo) {
    if (!defined('ADMIN_EMAIL') || !ADMIN_EMAIL) return;
    $stmt = $pdo->prepare('UPDATE users SET role = "admin" WHERE email = ?');
    $stmt->execute([ADMIN_EMAIL]);
}
ensure_admin_role($pdo);

function current_user() {
    return $_SESSION['user'] ?? null;
}
function require_auth() {
    if (!current_user()) {
        header('Location: login.php');
        exit;
    }
}
function require_admin() {
    if (!current_user() || current_user()['role'] !== 'admin') {
        http_response_code(403);
        die('Forbidden');
    }
}
?>
