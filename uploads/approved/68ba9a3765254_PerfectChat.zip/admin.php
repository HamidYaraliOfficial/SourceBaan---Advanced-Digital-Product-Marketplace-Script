<?php
require_once __DIR__.'/init.php';
require_admin();
$alert = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['clear'])) {
        $pdo->exec('TRUNCATE TABLE messages');
        $alert = 'تمام پیام‌ها پاک شد.';
    } elseif (isset($_POST['set_nickname'])) {
        $email = trim($_POST['email'] ?? '');
        $nick  = trim($_POST['nickname'] ?? '');
        if ($email && $nick) {
            $stmt = $pdo->prepare('UPDATE users SET nickname = ? WHERE email = ?');
            $stmt->execute([$nick, $email]);
            $alert = 'لقب کاربر بروز شد.';
        } else {
            $alert = 'ایمیل و لقب را وارد کنید.';
        }
    }
}
?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>پنل ادمین | <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="assets/style.css">
  <script defer src="assets/theme.js"></script>
</head>
<body>
<header class="topbar"><div class="left"><a class="btn secondary" href="chat.php">بازگشت به چت</a></div><div class="center"><strong>پنل ادمین</strong></div><div class="right"><a class="btn" href="logout.php">خروج</a></div></header>
<div class="container">
  <?php if ($alert): ?><div class="alert success"><?= htmlspecialchars($alert) ?></div><?php endif; ?>
  <div class="card">
    <h3>پاک کردن تمام پیام‌ها</h3>
    <form method="post"><button class="btn danger" name="clear" value="1" onclick="return confirm('مطمئن هستید؟')">پاک کردن</button></form>
  </div>
  <div class="card">
    <h3>تنظیم لقب کاربر</h3>
    <form method="post">
      <label>ایمیل کاربر</label><input type="email" name="email" required>
      <label>لقب جدید</label><input type="text" name="nickname" required>
      <button class="btn" name="set_nickname" value="1">ثبت</button>
    </form>
  </div>
</div>
</body>
</html>
