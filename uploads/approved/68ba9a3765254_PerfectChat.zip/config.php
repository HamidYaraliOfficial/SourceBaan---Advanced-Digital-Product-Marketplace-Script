<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'name');
define('DB_USER', 'user');
define('DB_PASS', 'pass');

define('DISPLAY_ERRORS', false);
define('COOKIE_SECURE', false);
define('ADMIN_EMAIL', 'Email@gmail.com');

define('APP_NAME', 'Perfect Chat');
define('APP_LOCALE', 'fa_IR');
define('TIMEZONE', 'Asia/Tehran');
?>
