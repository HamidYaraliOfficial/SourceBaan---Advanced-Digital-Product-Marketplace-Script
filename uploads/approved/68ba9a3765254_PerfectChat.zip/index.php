<?php
header('Location: chat.php');
exit;
?>
