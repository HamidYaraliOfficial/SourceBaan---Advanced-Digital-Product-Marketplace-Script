<?php
require_once __DIR__.'/init.php';
require_once __DIR__.'/profanity.php';
require_auth();
header('Content-Type: application/json; charset=utf-8');

$body = trim($_POST['body'] ?? '');
if ($body === '') {
    http_response_code(422);
    echo json_encode(['ok'=>false,'error'=>'empty'], JSON_UNESCAPED_UNICODE);
    exit;
}
$body = mb_substr($body, 0, 1000, 'UTF-8'); // limit
$body = censor_text($body);

$user = current_user();
$stmt = $pdo->prepare('INSERT INTO messages (user_id, body, type) VALUES (?, ?, ?)');
$stmt->execute([$user['id'], $body, 'user']);

echo json_encode(['ok'=>true,'id'=>$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
?>