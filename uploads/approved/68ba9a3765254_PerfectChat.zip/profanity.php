<?php
function censor_text($text) {
    $bad = [
        'fuck','shit','bitch','asshole',
        'کص','کس','جنده','حرومزاده','کیر','گایید',
    ];
    $pattern = '/(' . implode('|', array_map(function($w){
        return preg_quote($w, '/');
    }, $bad)) . ')/iu';
    return preg_replace_callback($pattern, function($m){
        $len = mb_strlen($m[0], 'UTF-8');
        return str_repeat('*', max(3, $len));
    }, $text);
}
?>
