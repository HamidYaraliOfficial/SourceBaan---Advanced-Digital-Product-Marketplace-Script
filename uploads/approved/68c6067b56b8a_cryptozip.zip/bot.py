from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    ContextTypes, filters, ConversationHandler, CallbackContext,
    CallbackQueryHandler
)
from datetime import datetime
import pytz
import requests
import re
import logging
import json
import os

TOKEN = "7592434489:AAHyYkqJohkDYJEuWEdudVCl55vn8BnPZl8" #توکن
ADMIN_ID = 5606633984 #ایدی عددی
CHANNELS = ["@Trooneic", "چنل دوم"] # ایدی چنل خود را در این قسمت قرار دهید اگر تعداد چنل هاتون بیشتر بود با , جدا کنید

API_CRYPTO = "https://api.fast-creat.ir/nobitex/v2?apikey=5606633984:Jbg2HEOfVT3y8r1@Api_ManagerRoBot"
API_CHART = "https://api.fast-creat.ir/chart?apikey=5606633984:1Bne3WFpkM0SoAv@Api_ManagerRoBot&interval=30m&symbol={symbol}&id=GFw"

crypto_aliases = {
    "trx": "TRX", "ترون": "TRX", "tron": "TRX",
    "btc": "BTC", "بیتکوین": "BTC", "بیت کوین": "BTC", "bitcoin": "BTC",
    "eth": "ETH", "اتریوم": "ETH", "ethereum": "ETH",
    "bnb": "BNB", "بایننس کوین": "BNB", "binance": "BNB",
    "usdt": "USDT", "تتر": "USDT", "دلار": "USDT", "tether": "USDT",
    "xrp": "XRP", "ریپل": "XRP", "ripple": "XRP",
    "doge": "DOGE", "دوج کوین": "DOGE", "دوج": "DOGE", "dogecoin": "DOGE",
    "ton": "TON", "تون کوین": "TON", "تون": "TON",
    "ada": "ADA", "کاردانو": "ADA", "cardano": "ADA",
    "sol": "SOL", "سولانا": "SOL", "solana": "SOL",
    "dot": "DOT", "پولکادات": "DOT", "polkadot": "DOT",
    "ltc": "LTC", "لایتکوین": "LTC", "litecoin": "LTC",
    "shib": "SHIB", "شیبا": "SHIB", "shiba": "SHIB",
    "etc": "ETC", "اتریوم کلاسیک": "ETC",
    "bch": "BCH", "بیتکوین کش": "BCH",
    "uni": "UNI", "یونی سواپ": "UNI",
    "link": "LINK", "چین لینک": "LINK",
    "xlm": "XLM", "استلار": "XLM",
    "axs": "AXS", "اکسی": "AXS",
    "mana": "MANA", "دیسنترالند": "MANA",
    "sand": "SAND", "سندباکس": "SAND",
    "avax": "AVAX", "آوالانچ": "AVAX",
    "usdc": "USDC", "یو اس دی کوین": "USDC",
    "gmt": "GMT", "استپن": "GMT",
    "mkr": "MKR", "میکر": "MKR",
    "atom": "ATOM", "اتم": "ATOM",
    "grt": "GRT", "گراف": "GRT",
    "bat": "BAT", "بت": "BAT",
    "near": "NEAR", "نیر پروتکل": "NEAR",
    "ape": "APE", "ایپ کوین": "APE",
    "qnt": "QNT", "کوانت": "QNT",
    "chz": "CHZ", "چیلیز": "CHZ",
    "xmr": "XMR", "مونرو": "XMR",
    "gala": "GALA", "گالا": "GALA",
    "algo": "ALGO", "الگورند": "ALGO",
    "hbar": "HBAR", "هدرا": "HBAR",
    "celr": "CELR", "سلر نتورک": "CELR",
    "arb": "ARB", "ارбиتروم": "ARB",
    "magic": "MAGIC", "مجیک": "MAGIC",
    "gmx": "GMX", "جی ام اکس": "GMX",
    "band": "BAND", "بند": "BAND",
    "cvx": "CVX", "کانوکس فایننس": "CVX",
    "ssv": "SSV", "اس اس وی نتوورک": "SSV",
    "mdt": "MDT", "مرژبل دیتا": "MDT",
    "wld": "WLD", "ورلد کوین": "WLD",
    "rdnt": "RDNT", "رادیانت کپیتال": "RDNT",
    "jst": "JST", "جاست": "JST",
    "bico": "BICO", "بیکو": "BICO",
    "woo": "WOO", "وو نتورک": "WOO",
    "skl": "SKL", "اسکیل": "SKL",
    "fet": "FET", "فچ ای آی": "FET",
    "ftm": "FTM", "فانتوم": "FTM",
    "comp": "COMP", "کامپاند": "COMP",
}

crypto_symbols = [
    "USDT", "TRX", "BTC", "ETH", "BNB",
    "XRP", "DOGE", "TON", "ADA", "SOL",
    "DOT", "LTC", "SHIB"
]

crypto_names_display = {
    "USDT": "🔰USDT", "TRX": "🔰TRX", "BTC": "🔰BTC", "ETH": "🔰ETH",
    "BNB": "🔰BNB", "XRP": "🔰XRP", "DOGE": "🔰DOGE", "TON": "🔰TON",
    "ADA": "🔰ADA", "SOL": "🔰SOL", "DOT": "🔰DOT", "LTC": "🔰LTC", "SHIB": "🔰SHIB"
}

WAITING_INTERVAL = 1
MANAGE_GROUPS = 2
SUPPORT_TICKET = 3
ADMIN_REPLY = 4
BROADCAST_MESSAGE = 5
SEND_TO_USER = 6
BOT_STATUS = 7
BOT_ACTIVE = True 

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)
logger = logging.getLogger(__name__)


GROUPS_FILE = "groups.json"
TICKETS_FILE = "tickets.json"
BANNED_USERS_FILE = "banned_users.json"

def load_banned_users():
    if os.path.exists(BANNED_USERS_FILE):
        try:
            with open(BANNED_USERS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_banned_users(banned_users):
    with open(BANNED_USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(banned_users, f, ensure_ascii=False, indent=4)

def ban_user_global(user_id, reason="بدون دلیل"):
    banned_users = load_banned_users()
    banned_users[str(user_id)] = {
        "banned_at": datetime.now().isoformat(),
        "reason": reason
    }
    save_banned_users(banned_users)
    return True

def unban_user_global(user_id):
    banned_users = load_banned_users()
    if str(user_id) in banned_users:
        del banned_users[str(user_id)]
        save_banned_users(banned_users)
        return True
    return False

def is_user_banned(user_id):
    banned_users = load_banned_users()
    return str(user_id) in banned_users

def load_groups():
    if os.path.exists(GROUPS_FILE):
        try:
            with open(GROUPS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_groups(groups_data):
    with open(GROUPS_FILE, 'w', encoding='utf-8') as f:
        json.dump(groups_data, f, ensure_ascii=False, indent=4)

def add_group(chat_id, admin_id, admin_username):
    groups_data = load_groups()
    groups_data[str(chat_id)] = {
        "chat_id": chat_id,
        "admin": {"id": admin_id, "username": admin_username},
        "additional_admins": []
    }
    save_groups(groups_data)

def get_group(chat_id):
    groups_data = load_groups()
    return groups_data.get(str(chat_id))

def get_user_groups(user_id):
    groups_data = load_groups()
    user_groups = []
    for chat_id, group_data in groups_data.items():
        if group_data["admin"]["id"] == user_id or any(admin["id"] == user_id for admin in group_data.get("additional_admins", [])):
            user_groups.append(group_data)
    return user_groups

def remove_group(chat_id):
    groups_data = load_groups()
    if str(chat_id) in groups_data:
        del groups_data[str(chat_id)]
        save_groups(groups_data)
        return True
    return False

def add_additional_admin(chat_id, new_admin_id, new_admin_username):
    groups_data = load_groups()
    group_data = groups_data.get(str(chat_id))
    if group_data:

        if new_admin_id not in [admin["id"] for admin in group_data.get("additional_admins", [])]:
            group_data.setdefault("additional_admins", []).append({
                "id": new_admin_id,
                "username": new_admin_username
            })
            save_groups(groups_data)
            return True
    return False


def load_tickets():
    if os.path.exists(TICKETS_FILE):
        try:
            with open(TICKETS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_tickets(tickets_data):
    with open(TICKETS_FILE, 'w', encoding='utf-8') as f:
        json.dump(tickets_data, f, ensure_ascii=False, indent=4)

def create_ticket(user_id, username, message):
    tickets_data = load_tickets()
    ticket_id = len(tickets_data) + 1

    tickets_data[str(ticket_id)] = {
        "user_id": user_id,
        "username": username,
        "message": message,
        "status": "open",
        "replies": [],
        "created_at": datetime.now().isoformat()
    }
    save_tickets(tickets_data)
    return ticket_id

def get_user_tickets(user_id):
    tickets_data = load_tickets()
    user_tickets = []
    for ticket_id, ticket_data in tickets_data.items():
        if ticket_data["user_id"] == user_id:
            user_tickets.append({"ticket_id": ticket_id, **ticket_data})
    return user_tickets


def is_admin(user_id, chat_id=None):

    if user_id == ADMIN_ID:
        return True

    if chat_id:
        group_data = get_group(chat_id)
        if group_data:
            if group_data["admin"]["id"] == user_id:
                return True

            if any(admin["id"] == user_id for admin in group_data.get("additional_admins", [])):
                return True
    return False

def get_all_tickets():
    return load_tickets()

def add_reply_to_ticket(ticket_id, user_id, username, message, is_admin=False):
    tickets_data = load_tickets()

    ticket_id_str = str(ticket_id)
    if ticket_id_str in tickets_data:
        tickets_data[ticket_id_str]["replies"].append({
            "user_id": user_id,
            "username": username,
            "message": message,
            "is_admin": is_admin,
            "timestamp": datetime.now().isoformat()
        })
        save_tickets(tickets_data)
        return True
    return False

def close_ticket(ticket_id):
    tickets_data = load_tickets()
    ticket_id_str = str(ticket_id)
    if ticket_id_str in tickets_data:
        tickets_data[ticket_id_str]["status"] = "closed"
        save_tickets(tickets_data)
        return True
    return False

def reopen_ticket(ticket_id):
    tickets_data = load_tickets()
    ticket_id_str = str(ticket_id)
    if ticket_id_str in tickets_data:
        tickets_data[ticket_id_str]["status"] = "open"
        save_tickets(tickets_data)
        return True
    return False


def fa_to_en_digits(s: str) -> str:
    persian = "۰۱۲۳۴۵۶۷۸۹"
    english = "0123456789"
    trans = str.maketrans(persian, english)
    return s.translate(trans)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global BOT_ACTIVE
    if not BOT_ACTIVE:
        await update.message.reply_text("❌ ربات موقتا غیرفعال است.")
        return
    if update.effective_chat.type != "private":
        return
    if not await force_sub(update, context):
        return
    if is_user_banned(update.effective_user.id):
        await update.message.reply_text("❌ شما از استفاده از ربات محروم شده‌اید.")
        return
        
    if not await force_sub(update, context):
        return

    bot_username = (await context.bot.get_me()).username
    link = f"https://t.me/{bot_username}?startgroup=true"

    keyboard = [
        [
            InlineKeyboardButton("📚 آموزش استفاده از ربات", callback_data="tutorial")
        ],

        [
            InlineKeyboardButton("➕ افزودن ربات در گپ", url=link),
            InlineKeyboardButton("👥 گروه های من", callback_data="my_groups")
        ],
        [
            InlineKeyboardButton("📞 پشتیبانی", callback_data="support"),
            InlineKeyboardButton("ℹ️ درباره ربات", callback_data="about")
        ]
    ]

    markup = InlineKeyboardMarkup(keyboard)


    if update.callback_query:
        await update.callback_query.message.edit_text(
            "📌 از طریق دکمه زیر ربات را در کانال یا گروه خود قرار دهید.\n\n"
            "⚠️ حتما هنگام افزودن، دسترسی *ادمین* را به ربات بدهید.",
            reply_markup=markup,
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
                    """<b>🤖 به ربات هوشمند کریپتو خوش اومدی!  

📌 از اینجا می‌تونی ربات رو به گروه یا کانال خودت اضافه کنی و به صورت لحظه‌ای قیمت‌ها و نمودار ارزهای دیجیتال رو داشته باشی.  


🔥 فراموش نکن: برای عملکرد درست، ربات باید حتماً دسترسی ادمین داشته باشه.  

👇 از منوی زیر شروع کن:</b>""",
            reply_markup=markup,
            parse_mode="HTML",
        )


async def check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    not_subscribed = []

    for channel in CHANNELS:
        try:
            member = await context.bot.get_chat_member(channel, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                not_subscribed.append(channel)
        except:
            not_subscribed.append(channel)

    return not_subscribed

async def force_sub(update: Update, context: ContextTypes.DEFAULT_TYPE):
    not_subscribed = await check_subscription(update, context)

    if not_subscribed:
        keyboard = []
        for ch in not_subscribed:
            keyboard.append([InlineKeyboardButton(f"📢جنل اسپانسر عضویت در", url=f"https://t.me/{ch.replace('@', '')}")])
        keyboard.append([InlineKeyboardButton("✅ بررسی عضویت", callback_data="check_sub")])
        markup = InlineKeyboardMarkup(keyboard)

        if update.callback_query:
            await update.callback_query.message.edit_text(
                "<b>❌ برای استفاده از ربات حتما باید در کانال‌های زیر عضو شوید:</b>",
                reply_markup=markup,
                parse_mode= "HTML"
            )
        else:
            await update.message.reply_text(
                "<b>❌ برای استفاده از ربات باید در کانال‌های زیر عضو شوید:</b>",
                reply_markup=markup,
                parse_mode= "HTML"
            )
        return False
    return True

async def check_sub_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await force_sub(update, context):
        await back_to_start(update, context)


async def my_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    user_groups = get_user_groups(user_id)

    if not user_groups:
        await query.message.edit_text("❌ شما هیچ گروهی ندارید.")
        return

    keyboard = []
    for group in user_groups:
        chat_id = group["chat_id"]
        keyboard.append([InlineKeyboardButton(f"گروه {chat_id}", callback_data=f"group_{chat_id}")])

    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_start")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "👥 گروه های شما:\n\n"
        "برای مدیریت هر گروه، روی آن کلیک کنید.",
        reply_markup=markup
    )


async def manage_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    chat_id = int(data.split("_")[1])

    group_data = get_group(chat_id)
    if not group_data:
        await query.message.edit_text("❌ گروه پیدا نشد.")
        return


    admins_list = ""
    if group_data.get("additional_admins"):
        admins_list = "\nادمین‌های اضافی:\n"
        for admin in group_data["additional_admins"]:
            admins_list += f"• @{admin['username']} (ID: {admin['id']})\n"

    keyboard = [
        [InlineKeyboardButton("🗑 حذف ربات از گروه", callback_data=f"remove_{chat_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="my_groups")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        f"🛠 مدیریت گروه:\n"
        f"شناسه گروه: {chat_id}\n"
        f"ادمین اصلی: @{group_data['admin']['username']}"
        f"{admins_list}",
        reply_markup=markup
    )


async def remove_from_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    chat_id = int(data.split("_")[1])

    try:

        await context.bot.leave_chat(chat_id)
        remove_group(chat_id)
        await query.message.edit_text("✅ ربات با موفقیت از گروه حذف شد.")
    except Exception as e:
        logger.error(f"Error leaving group: {e}")
        await query.message.edit_text("❌ خطا در حذف ربات از گروه.")


async def support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    keyboard = [
        [InlineKeyboardButton("📩 ایجاد تیکت جدید", callback_data="create_ticket")],
        [InlineKeyboardButton("📋 مشاهده تیکت‌ها", callback_data="view_tickets")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_start")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "<b>📞 پشتیبانی\n\n</b>"
        "<b>برای ایجاد تیکت جدید یا مشاهده تیکت‌های خود از گزینه‌های زیر استفاده کنید:</b>",
        reply_markup=markup,
        parse_mode="HTML"
    )


async def tutorial(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_start")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        """<b>📚 آموزش استفاده از ربات  

🔹 افزودن ربات به گروه:
برای شروع، از دکمه <b>➕ افزودن ربات در گپ</b> استفاده کنید.  
حتماً دسترسی <b>ادمین</b> را به ربات بدهید تا بتواند قیمت‌ها را ارسال کند.  

🔹 مشاهده گروه‌های شما:
با دکمه <b>👥 گروه‌های من</b> می‌توانید گروه‌هایی که ربات در آنهاست را مدیریت کنید.  

🔹 دریافت قیمت لحظه‌ای:
در گروه کافیست اسم ارز را بنویسید (مثل: بیتکوین یا BTC)  
یا مقدار مشخصی را وارد کنید (مثل: 2 ترون یا ترون 2).  

🔹 تنظیم بازه برای ارسال مکرر قیمت ها:
در گروه کافیست کلمه تنظیم بازه رو ارسال کنید و بعد توضیحات تنظیم بازه ارسال میشود.

🔹 پشتیبانی:
در صورت مشکل می‌توانید از بخش <b>📞 پشتیبانی</b> تیکت ثبت کنید.  

🔹 درباره ربات:
از بخش <b>ℹ️ درباره ربات</b> اطلاعات نسخه و توسعه‌دهنده را ببینید.  

⚡️ با این آموزش ساده می‌توانید به راحتی از همه امکانات ربات استفاده کنید.</b>""",
        reply_markup=markup,
        parse_mode="HTML"
    )


async def create_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data="support")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "<b>لطفا پیام خود را برای پشتیبانی ارسال کنید:</b>",
        reply_markup=markup,
        parse_mode="HTML"
    )
    return SUPPORT_TICKET

async def view_tickets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    user_tickets = get_user_tickets(user_id)

    if not user_tickets:
        keyboard = [
            [InlineKeyboardButton("📩 ایجاد تیکت جدید", callback_data="create_ticket")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="support")]
        ]
        markup = InlineKeyboardMarkup(keyboard)

        await query.message.edit_text(
            "<b>❌ شما هیچ تیکتی ندارید.<>",
            reply_markup=markup,
            parse_mode="HTML"
        )
        return

    keyboard = []
    for ticket in user_tickets:
        status_emoji = "✅" if ticket["status"] == "closed" else "🟡"
        keyboard.append([InlineKeyboardButton(
            f"{status_emoji} تیکت #{ticket['ticket_id']} - وضعیت: {ticket['status']}", 
            callback_data=f"view_ticket_{ticket['ticket_id']}"
        )])
    
    keyboard.append([InlineKeyboardButton("📩 ایجاد تیکت جدید", callback_data="create_ticket")])
    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="support")])
    markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
        "<b>📋 تیکت‌های شما:\n\n</b>"
        "<b>برای مشاهده جزئیات هر تیکت، روی آن کلیک کنید:</b>",
        reply_markup=markup,
        parse_mode="HTML"
    )

async def about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data="back_to_start")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
                """<b>🤖 نام ربات: 𝐜𝐫𝐲𝐩𝐭𝐨𝐆𝐅𝐰
📊 وظیفه: نمایش قیمت‌های لحظه‌ای ارزهای دیجیتال
💻 توسعه‌دهنده: @tronieck
🔄 نسخه فعلی: <u>v1.2.0</u>

⚡️ قابلیت‌ها:
• 📈 نمایش قیمت لحظه‌ای ارزهای محبوب  
• 🔔 ارسال خودکار قیمت‌ها در گروه/کانال  
• 🖼 نمایش نمودار (چارت) ارز انتخابی  
• 🎯 پشتیبانی از چندین ارز با نام فارسی و انگلیسی  
• 🛠 سیستم پشتیبانی و تیکت برای رفع مشکلات  

🚀 همیشه در حال به‌روزرسانی برای تجربه بهتر شما!
</b>""",
        reply_markup=markup,
        parse_mode="HTML"
    )

async def view_ticket_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    ticket_id = int(data.split("_")[2])

    tickets_data = load_tickets()
    ticket = tickets_data.get(str(ticket_id))

    if not ticket:
        await query.message.edit_text("❌ تیکت پیدا نشد.")
        return

    user_id = query.from_user.id
    if user_id != ticket["user_id"] and user_id != ADMIN_ID:
        await query.message.edit_text("❌ شما دسترسی به این تیکت ندارید.")
        return

    if ticket["status"] == "closed" and user_id != ADMIN_ID:
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت به تیکت‌ها", callback_data="view_tickets")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text(
            "❌ این تیکت بسته شده است و نمی‌توانید آن را مشاهده کنید.",
            reply_markup=markup
        )
        return

    if "replies" not in ticket:
        ticket["replies"] = []
    
    ticket_text = f"📋 تیکت #{ticket_id}\n"
    ticket_text += f"📝 پیام: {ticket['message']}\n"
    ticket_text += f"📊 وضعیت: {ticket['status']}\n\n"
    
    if ticket["replies"]:
        ticket_text += "📨 پاسخ‌ها:\n"
        for reply in ticket["replies"]:
            sender = "👤 کاربر" if not reply["is_admin"] else "🛡 ادمین"
            ticket_text += f"{sender}: {reply['message']}\n\n"

    keyboard = []
    if user_id == ADMIN_ID:
        if ticket["status"] == "open":
            keyboard.append([InlineKeyboardButton("❌ بستن تیکت", callback_data=f"admin_close_ticket_{ticket_id}")])
        else:
            keyboard.append([InlineKeyboardButton("🔓 بازگشایی تیکت", callback_data=f"admin_reopen_ticket_{ticket_id}")])
        keyboard.append([InlineKeyboardButton("🗑 حذف تیکت", callback_data=f"admin_delete_ticket_{ticket_id}")])
    else:
        if ticket["status"] == "open":
            keyboard.append([InlineKeyboardButton("❌ بستن تیکت", callback_data=f"close_ticket_{ticket_id}")])

        keyboard.append([InlineKeyboardButton("🗑 حذف تیکت", callback_data=f"delete_ticket_{ticket_id}")])

    keyboard.append([InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"reply_ticket_{ticket_id}")])
    keyboard.append([InlineKeyboardButton("🔙 بازگشت به تیکت‌ها", callback_data="view_tickets")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(ticket_text, reply_markup=markup)

async def close_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    ticket_id = int(data.split("_")[2])

    if close_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت بسته شد.")
        
        tickets_data = load_tickets()
        ticket = tickets_data.get(str(ticket_id))
        if ticket:
            try:
                await context.bot.send_message(
                    chat_id=ticket["user_id"],
                    text=f"✅ تیکت #{ticket_id} شما بسته شد.\n\n"
                         f"در صورت نیاز می‌توانید تیکت جدید ایجاد کنید."
                )
            except Exception as e:
                logger.error(f"Error notifying user: {e}")
    else:
        await query.message.edit_text("❌ خطا در بستن تیکت.")

async def reopen_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data = query.data
    ticket_id = int(data.split("_")[2])
    
    if reopen_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت بازگشایی شد.")
    else:
        await query.message.edit_text("❌ خطا در بازگشایی تیکت.")

async def reply_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    ticket_id = int(data.split("_")[2])

    tickets_data = load_tickets()
    ticket = tickets_data.get(str(ticket_id))
    
    if not ticket:
        await query.message.edit_text("❌ تیکت پیدا نشد.")
        return ConversationHandler.END

    if ticket["status"] == "closed" and query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ این تیکت بسته شده است و نمی‌توانید به آن پاسخ دهید.")
        return ConversationHandler.END

    context.user_data["replying_to_ticket"] = ticket_id

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"view_ticket_{ticket_id}")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "لطفا پاسخ خود را ارسال کنید:",
        reply_markup=markup
    )
    return SUPPORT_TICKET

async def receive_ticket_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "بدون یوزرنیم"
    message = update.message.text


    if "replying_to_ticket" in context.user_data:
        ticket_id = context.user_data["replying_to_ticket"]
        is_admin = user_id == ADMIN_ID


        if add_reply_to_ticket(ticket_id, user_id, username, message, is_admin):
            tickets_data = load_tickets()
            ticket = tickets_data.get(str(ticket_id))

            if ticket:

                if not is_admin:
                    try:

                        text = f"📨 پاسخ جدید به تیکت #{ticket_id}\n\n"
                        text += f"👤 کاربر: @{username}\n\n"
                        text += f"📝 پیام اولیه: {ticket['message']}\n\n"

                        if ticket["replies"]:
                            text += "📨 تاریخچه گفتگو:\n"
                            for reply in ticket["replies"]:
                                sender = "👤 کاربر" if not reply["is_admin"] else "🛡 ادمین"
                                text += f"{sender}: {reply['message']}\n\n"

                        await context.bot.send_message(
                            chat_id=ADMIN_ID,
                            text=text,
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"admin_reply_{ticket_id}")]
                            ])
                        )
                    except Exception as e:
                        logger.error(f"Error sending reply to admin: {e}")

                keyboard = [
                    [InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"reply_ticket_{ticket_id}")],
                    [InlineKeyboardButton("🔙 بازگشت به تیکت‌ها", callback_data="view_tickets")]
                ]
                markup = InlineKeyboardMarkup(keyboard)

                await update.message.reply_text(
                    f"✅ پاسخ شما ارسال شد.",
                    reply_markup=markup
                )
            else:
                await update.message.reply_text("❌ تیکت پیدا نشد.")
        else:
            await update.message.reply_text("❌ خطا در ارسال پاسخ.")


        del context.user_data["replying_to_ticket"]

    else:

        ticket_id = create_ticket(user_id, username, message)

        keyboard = [
            [InlineKeyboardButton("📋 مشاهده تیکت‌ها", callback_data="view_tickets")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="support")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"<b>✅ تیکت شما با شماره #{ticket_id} ثبت شد.\n</b>"
            f"<b>پشتیبانی به زودی با شما تماس خواهد گرفت.</b>",
            reply_markup=markup,
            parse_mode="HTML"
        )


        try:
            tickets_data = load_tickets()
            ticket = tickets_data.get(str(ticket_id))
            
            text = f"📩 تیکت جدید\n"
            text += f"شماره تیکت: #{ticket_id}\n"
            text += f"کاربر: @{username} (ID: {user_id})\n\n"
            text += f"📝 پیام اولیه: {ticket['message']}\n\n"

            if ticket["replies"]:
                text += "📨 تاریخچه گفتگو:\n"
                for reply in ticket["replies"]:
                    sender = "👤 کاربر" if not reply["is_admin"] else "🛡 ادمین"
                    text += f"{sender}: {reply['message']}\n\n"

            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"admin_reply_{ticket_id}")]
                ])
            )
        except Exception as e:
            logger.error(f"Error notifying admin: {e}")

    return ConversationHandler.END


async def admin_view_tickets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    tickets_data = get_all_tickets()

    if not tickets_data:
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("❌ هیچ تیکتی وجود ندارد.", reply_markup=markup)
        return

    keyboard = []
    for ticket_id, ticket in tickets_data.items():
        status_emoji = "✅" if ticket["status"] == "closed" else "🟡"
        keyboard.append([InlineKeyboardButton(
            f"{status_emoji} تیکت #{ticket_id} - کاربر: @{ticket['username']}", 
            callback_data=f"admin_view_ticket_{ticket_id}"
        )])

    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "🛡 پنل مدیریت تیکت‌ها:\n\n"
        "برای مشاهده و مدیریت هر تیکت، روی آن کلیک کنید:",
        reply_markup=markup
    )

async def admin_view_ticket(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    data = query.data
    ticket_id = int(data.split("_")[3])

    tickets_data = load_tickets()
    ticket = tickets_data.get(str(ticket_id))

    if not ticket:
        await query.message.edit_text("❌ تیکت پیدا نشد.")
        return

    if "replies" not in ticket:
        ticket["replies"] = []
    
    ticket_text = f"🛡 تیکت #{ticket_id}\n"
    ticket_text += f"👤 کاربر: @{ticket['username']} (ID: {ticket['user_id']})\n"
    ticket_text += f"📝 پیام: {ticket['message']}\n"
    ticket_text += f"📊 وضعیت: {ticket['status']}\n\n"

    if ticket["replies"]:
        ticket_text += "📨 تاریخچه مکاتبات:\n"
        for reply in ticket["replies"]:
            sender = "👤 کاربر" if not reply["is_admin"] else "🛡 ادمین"
            ticket_text += f"{sender}: {reply['message']}\n\n"

    keyboard = []
    if ticket["status"] == "open":
        keyboard.append([InlineKeyboardButton("❌ بستن تیکت", callback_data=f"admin_close_ticket_{ticket_id}")])
    else:
        keyboard.append([InlineKeyboardButton("🔓 بازگشایی تیکت", callback_data=f"admin_reopen_ticket_{ticket_id}")])

    keyboard.append([InlineKeyboardButton("🗑 حذف تیکت", callback_data=f"admin_delete_ticket_{ticket_id}")])
    keyboard.append([InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"admin_reply_{ticket_id}")])
    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_tickets_back")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(ticket_text, reply_markup=markup)

async def admin_receive_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("❌ دسترسی denied.")
        return ConversationHandler.END

    if "admin_replying_to_ticket" not in context.user_data:
        await update.message.reply_text("❌ خطا در پاسخ دادن.")
        return ConversationHandler.END

    ticket_id = context.user_data["admin_replying_to_ticket"]
    message = update.message.text


    if add_reply_to_ticket(ticket_id, ADMIN_ID, "Admin", message, is_admin=True):
        tickets_data = load_tickets()
        ticket = tickets_data.get(str(ticket_id))

        if ticket:

            try:
                await context.bot.send_message(
                    chat_id=ticket["user_id"],
                    text=f"📨 پاسخ جدید به تیکت #{ticket_id}\n\n"
                         f"🛡 ادمین: {message}\n\n"
                         f"برای پاسخ دادن روی دکمه زیر کلیک کنید:",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📩 پاسخ دادن", callback_data=f"reply_ticket_{ticket_id}")]
                    ])
                )
            except Exception as e:
                logger.error(f"Error sending reply to user: {e}")

            await update.message.reply_text("✅ پاسخ شما ارسال شد.")
        else:
            await update.message.reply_text("❌ تیکت پیدا نشد.")
    else:
        await update.message.reply_text("❌ خطا در ارسال پاسخ.")


    del context.user_data["admin_replying_to_ticket"]
    return ConversationHandler.END

async def delete_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    ticket_id = int(data.split("_")[2])

    tickets_data = load_tickets()
    ticket = tickets_data.get(str(ticket_id))

    if not ticket:
        await query.message.edit_text("❌ تیکت پیدا نشد.")
        return

    user_id = query.from_user.id
    if user_id != ticket["user_id"] and user_id != ADMIN_ID:
        await query.message.edit_text("❌ شما دسترسی به این تیکت ندارید.")
        return

    if delete_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت حذف شد.")
    else:
        await query.message.edit_text("❌ خطا در حذف تیکت.")

async def admin_tickets_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    tickets_data = get_all_tickets()

    if not tickets_data:
        await query.message.edit_text("❌ هیچ تیکتی وجود ندارد.")
        return

    keyboard = []
    for ticket_id, ticket in tickets_data.items():
        status_emoji = "✅" if ticket["status"] == "closed" else "🟡"
        keyboard.append([InlineKeyboardButton(
            f"{status_emoji} تیکت #{ticket_id} - کاربر: @{ticket['username']}", 
            callback_data=f"admin_view_ticket_{ticket_id}"
        )])

    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "🛡 پنل مدیریت تیکت‌ها:\n\n"
        "برای مشاهده و مدیریت هر تیکت، روی آن کلیک کنید:",
        reply_markup=markup
    )

async def admin_close_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    data = query.data
    ticket_id = int(data.split("_")[3])

    if close_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت بسته شد.")
        
        tickets_data = load_tickets()
        ticket = tickets_data.get(str(ticket_id))
        if ticket:
            try:
                await context.bot.send_message(
                    chat_id=ticket["user_id"],
                    text=f"✅ تیکت #{ticket_id} شما بسته شد.\n\n"
                         f"در صورت نیاز می‌توانید تیکت جدید ایجاد کنید."
                )
            except Exception as e:
                logger.error(f"Error notifying user: {e}")
    else:
        await query.message.edit_text("❌ خطا در بستن تیکت.")

async def admin_reopen_ticket_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return
    
    data = query.data
    ticket_id = int(data.split("_")[3])
    
    if reopen_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت بازگشایی شد.")
    else:
        await query.message.edit_text("❌ خطا در بازگشایی تیکت.")

async def admin_reply_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return


    if query.data.startswith("admin_reply_"):
        ticket_id = int(query.data.split("_")[2])
    else:
        return

    context.user_data["admin_replying_to_ticket"] = ticket_id

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_view_ticket_{ticket_id}")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "لطفا پاسخ خود را به عنوان ادمین ارسال کنید:",
        reply_markup=markup
    )
    return ADMIN_REPLY


async def back_to_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not await force_sub(update, context):
        return

    bot_username = (await context.bot.get_me()).username
    link = f"https://t.me/{bot_username}?startgroup=true"

    keyboard = [
        [
            InlineKeyboardButton("📚 آموزش استفاده از ربات", callback_data="tutorial")
        ],
        [
            InlineKeyboardButton("➕ افزودن ربات در گپ", url=link),
            InlineKeyboardButton("👥 گروه های من", callback_data="my_groups")
        ],
        [
            InlineKeyboardButton("📞 پشتیبانی", callback_data="support"),
            InlineKeyboardButton("ℹ️ درباره ربات", callback_data="about")
        ]
    ]

    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
                    """<b>🤖 به ربات هوشمند کریپتو خوش اومدی!  

📌 از اینجا می‌تونی ربات رو به گروه یا کانال خودت اضافه کنی و به صورت لحظه‌ای قیمت‌ها و نمودار ارزهای دیجیتال رو داشته باشی.  


🔥 فراموش نکن: برای عملکرد درست، ربات باید حتماً دسترسی ادمین داشته باشه.  

👇 از منوی زیر شروع کن:</b>""",
            reply_markup=markup,
            parse_mode="HTML",
        )

def iran_time():
    tz = pytz.timezone('Asia/Tehran')
    now = datetime.now(tz)
    return now.strftime("🕰 %H:%M:%S"), now.strftime("📆 %Y/%m/%d")


def get_crypto_prices():
    try:
        data = requests.get(API_CRYPTO).json()
        prices = []
        if data.get("ok") and "result" in data:
            for s in crypto_symbols:
                if s in data['result']:
                    c = data['result'][s]
                    prices.append((s, c['irr']))
        return prices
    except Exception as e:
        logger.error(f"Error get_crypto_prices: {e}")
        return []

def get_all_crypto():
    try:
        data = requests.get(API_CRYPTO).json()
        if data.get("ok") and "result" in data:
            return data["result"]
        return {}
    except Exception as e:
        logger.error(f"Error get_all_crypto: {e}")
        return {}

def get_chart_image(symbol):
    try:
        url = API_CHART.format(symbol=symbol)
        data = requests.get(url).json()
        if data.get("ok") and "result" in data:
            return data["result"].get("image")
    except Exception as e:
        logger.error(f"Error get_chart_image: {e}")
    return None


async def send_prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        await update.message.reply_text("❌ این دستور فقط داخل گروه‌ها قابل استفاده است.")
        return

    crypto_prices = get_crypto_prices()
    keyboard = [
        [InlineKeyboardButton("💲نماد ارز💲", callback_data="ignore"),
         InlineKeyboardButton("💰قیمت (تومان)💰", callback_data="ignore")]
    ]
    for symbol, price in crypto_prices:
        formatted_price = f"{float(price):,.0f}"
        display_name = crypto_names_display.get(symbol, symbol)
        keyboard.append([InlineKeyboardButton(display_name, callback_data="ignore"),
                         InlineKeyboardButton(f"🪙{formatted_price}", callback_data="ignore")])
    markup = InlineKeyboardMarkup(keyboard)
    time_str, date_str = iran_time()
    await update.effective_chat.send_message(
        f"<b>📈 قیمت‌های لحظه‌ای بازار کریپتو – آخرین تغییرات و روندها!\n\n"
        f"💲قیمت‌ها برحسب تومان هستند.\n\n"
        f"{time_str}\n{date_str}\nDev: @tronieck</b>",
        reply_markup=markup,
        parse_mode="HTML"
    )

async def send_prices_job(context: CallbackContext):
    chat_id = context.job.chat_id

    chat = await context.bot.get_chat(chat_id)
    if chat.type == "private":
        return

    crypto_prices = get_crypto_prices()
    keyboard = [
        [InlineKeyboardButton("💲نماد ارز💲", callback_data="ignore"),
         InlineKeyboardButton("💰قیمت (تومان)💰", callback_data="ignore")]
    ]
    for symbol, price in crypto_prices:
        formatted_price = f"{float(price):,.0f}"
        display_name = crypto_names_display.get(symbol, symbol)
        keyboard.append([InlineKeyboardButton(display_name, callback_data="ignore"),
                         InlineKeyboardButton(f"🪙{formatted_price}", callback_data="ignore")])
    markup = InlineKeyboardMarkup(keyboard)
    time_str, date_str = iran_time()
    await context.bot.send_message(
        chat_id=chat_id,
        text=f"<b>📈 قیمت‌های لحظه‌ای بازار کریپتو – آخرین تغییرات و روندها!\n\n"
             f"💲قیمت‌ها برحسب تومان هستند.\n\n"
             f"{time_str}\n{date_str}\nDev: @tronieck</b>",
        reply_markup=markup,
        parse_mode="HTML"
    )

async def crypto_listener(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    if not update.message or not update.message.text:
        return

    text = update.message.text.lower().strip()
    if not text:
        return

    all_crypto = get_all_crypto()
    amount = 1
    crypto_input = None



    match = re.fullmatch(
        r"([0-9۰-۹]+(?:\.[0-9۰-۹]+)?)\s*([\wآ-ی]+)|([\wآ-ی]+)\s*([0-9۰-۹]+(?:\.[0-9۰-۹]+)?)",
        text
    )
    if match:
        if match.group(1) and match.group(2):
            amount = float(fa_to_en_digits(match.group(1)).replace("٫", ".").replace("٬", ""))
            crypto_input = match.group(2)
        elif match.group(3) and match.group(4):
            crypto_input = match.group(3)
            amount = float(fa_to_en_digits(match.group(4)).replace("٫", ".").replace("٬", ""))

    else:

        if text in crypto_aliases:
            crypto_input = text
        else:
            return

    if not crypto_input:
        return
    symbol = crypto_aliases.get(crypto_input.lower(), crypto_input.upper())

    if symbol not in all_crypto:




        return

    data = all_crypto[symbol]
    price_irr = float(data['irr']) * amount
    price_usd = float(data['usdt']) * amount
    time_str, date_str = iran_time()
    msg = (f"<b>💲 نرخ ارز برای {amount} واحد {data['name']}\n\n"
           f"╕ {amount} {data['name']}\n"
           f"╡ {price_usd:,.2f} دلار\n"
           f"╛ {price_irr:,.0f} تومان\n"
           f"{time_str}\n{date_str}</b>")

    chart_url = get_chart_image(symbol)
    if chart_url:
        await update.effective_chat.send_photo(photo=chart_url, caption=msg, parse_mode="HTML")
    else:
        await update.effective_chat.send_message(msg, parse_mode="HTML")


async def set_interval_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id


    if not is_admin(user_id, chat_id):
        await update.message.reply_text("❌ شما ادمین نیستید!")
        return ConversationHandler.END

    await update.message.reply_text(
        "<b>📌 لطفا بازه زمانی ارسال خودکار قیمت‌ها را وارد کنید:\n"
        "- هر n ساعت: مثال '24 ساعت'\n"
        "- هر n دقیقه: مثال '5 دقیقه'\n"
        "- هر n ثانیه: مثال '10 ثانیه'\n"
        "- برای توقف ارسال: بنویس 'متوقف'</b>",
        parse_mode="HTML"
    )
    return WAITING_INTERVAL

async def set_interval_receive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id


    if not is_admin(user_id, chat_id):
        await update.message.reply_text("❌ شما ادمین نیستید!")
        return ConversationHandler.END

    text = update.message.text.strip()
    if text == "متوقف":
        if "job" in context.chat_data:
            context.chat_data["job"].schedule_removal()
            del context.chat_data["job"]
        await update.message.reply_text("✅ ارسال خودکار قیمت‌ها متوقف شد.")
        return ConversationHandler.END

    try:
        parts = text.split()
        number = int(parts[0])
        unit = parts[1] if len(parts) > 1 else "ثانیه"
        if "ساعت" in unit:
            interval_seconds = number * 3600
        elif "دقیقه" in unit:
            interval_seconds = number * 60
        else:
            interval_seconds = number
        if interval_seconds < 1:
            raise ValueError()
    except:
        await update.message.reply_text("⚠ لطفا یک متن معتبر وارد کنید یا 'متوقف'.")
        return WAITING_INTERVAL

    if "job" in context.chat_data:
        context.chat_data["job"].schedule_removal()

    job = context.job_queue.run_repeating(
        send_prices_job, interval=interval_seconds, first=0, chat_id=update.effective_chat.id
    )
    context.chat_data["job"] = job
    await update.message.reply_text(f"✅ ارسال خودکار قیمت‌ها هر {text} یکبار تنظیم شد.")
    return ConversationHandler.END


async def on_group_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for member in update.message.new_chat_members:
        if member.id == context.bot.id:
            chat_id = update.effective_chat.id
            added_by = update.message.from_user


            add_group(chat_id, added_by.id, added_by.username)


            welcome_message = await update.message.reply_text(
                "✅ ربات اضافه شد و گروه ثبت گردید.\n"
                "⚠️ مطمئن شوید به ربات دسترسی ادمین داده‌اید."
            )


            try:
                await context.bot.send_message(
                    chat_id=added_by.id,
                    text=f"✅ ربات با موفقیت به گروه اضافه شد.\n"
                         f"شناسه گروه: {chat_id}\n"
                         f"برای مدیریت گروه از دکمه 'گروه های من' در ربات استفاده کنید."
                )
            except Exception as e:
                logger.error(f"Error sending PM: {e}")

            logger.info(f"ربات به گروه {chat_id} اضافه شد. ادمین: {added_by.id} ({added_by.username})")

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("❌ دسترسی denied.")
        return

    groups_data = load_groups()
    total_groups = len(groups_data)
    
    tickets_data = load_tickets()
    total_tickets = len(tickets_data)
    open_tickets = sum(1 for t in tickets_data.values() if t["status"] == "open")
    
    banned_users = load_banned_users()
    total_banned = len(banned_users)

    keyboard = [
        [InlineKeyboardButton("👥 مدیریت گروه ها", callback_data="admin_manage_groups")],
        [InlineKeyboardButton("📋 مشاهده تیکت ها", callback_data="admin_view_tickets")],
        [InlineKeyboardButton("🚫 مدیریت بن کاربران", callback_data="admin_manage_bans")],
        [InlineKeyboardButton("📨 ارسال پیام", callback_data="admin_send_message")],  # جدید
        [InlineKeyboardButton("🔌 وضعیت ربات", callback_data="admin_bot_status")],  # جدید
        [InlineKeyboardButton("📊 آمار ربات", callback_data="admin_stats")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        f"🛡 پنل مدیریت ادمین\n\n"
        f"📊 تعداد گروه های متصل: {total_groups}\n"
        f"🎫 تعداد تیکت ها: {total_tickets} (باز: {open_tickets})\n"
        f"🚫 کاربران بن شده: {total_banned}\n\n"
        f"🔧 برای مدیریت از گزینه های زیر استفاده کنید:",
        reply_markup=markup
    )

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    groups_data = load_groups()
    total_groups = len(groups_data)
    
    tickets_data = load_tickets()
    total_tickets = len(tickets_data)
    open_tickets = sum(1 for t in tickets_data.values() if t["status"] == "open")
    closed_tickets = total_tickets - open_tickets

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    stats_text = (
        f"📊 آمار کامل ربات:\n\n"
        f"👥 گروه های متصل: {total_groups}\n"
        f"🎫 تیکت های کل: {total_tickets}\n"
        f"🟢 تیکت های باز: {open_tickets}\n"
        f"🔴 تیکت های بسته: {closed_tickets}\n\n"
        f"🔄 آخرین بروزرسانی: {datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"
    )

    await query.message.edit_text(stats_text, reply_markup=markup)

async def admin_manage_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    groups_data = load_groups()
    
    if not groups_data:
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("❌ هیچ گروهی ثبت نشده است.", reply_markup=markup)
        return

    keyboard = []
    for chat_id, group_data in groups_data.items():
        keyboard.append([InlineKeyboardButton(
            f"گروه {chat_id} - ادمین: @{group_data['admin']['username']}",
            callback_data=f"admin_group_detail_{chat_id}"
        )])
    
    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "👥 مدیریت گروه های متصل:\n\n"
        "برای مشاهده جزئیات هر گروه، روی آن کلیک کنید:",
        reply_markup=markup
    )

async def admin_group_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    data = query.data
    chat_id = int(data.split("_")[3])

    group_data = get_group(chat_id)
    if not group_data:
        await query.message.edit_text("❌ گروه پیدا نشد.")
        return

    keyboard = [
        [InlineKeyboardButton("🗑 حذف گروه", callback_data=f"admin_remove_group_{chat_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_groups")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        f"📋 جزئیات گروه:\n"
        f"شناسه گروه: {chat_id}\n"
        f"ادمین اصلی: @{group_data['admin']['username']} (ID: {group_data['admin']['id']})\n"
        f"تعداد ادمین های اضافی: {len(group_data.get('additional_admins', []))}",
        reply_markup=markup
    )

async def admin_remove_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    data = query.data
    chat_id = int(data.split("_")[3])

    try:
        await context.bot.leave_chat(chat_id)
        remove_group(chat_id)
        await query.message.edit_text("✅ گروه با موفقیت حذف شد.")
    except Exception as e:
        logger.error(f"Error removing group: {e}")
        await query.message.edit_text("❌ خطا در حذف گروه.")

async def admin_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    groups_data = load_groups()
    total_groups = len(groups_data)
    
    tickets_data = load_tickets()
    total_tickets = len(tickets_data)
    open_tickets = sum(1 for t in tickets_data.values() if t["status"] == "open")
    
    banned_users = load_banned_users()
    total_banned = len(banned_users)

    keyboard = [
        [InlineKeyboardButton("👥 مدیریت گروه ها", callback_data="admin_manage_groups")],
        [InlineKeyboardButton("📋 مشاهده تیکت ها", callback_data="admin_view_tickets")],
        [InlineKeyboardButton("🚫 مدیریت بن کاربران", callback_data="admin_manage_bans")],
        [InlineKeyboardButton("📨 ارسال پیام", callback_data="admin_send_message")],  # جدید
        [InlineKeyboardButton("🔌 وضعیت ربات", callback_data="admin_bot_status")],  # جدید
        [InlineKeyboardButton("📊 آمار ربات", callback_data="admin_stats")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        f"🛡 پنل مدیریت ادمین\n\n"
        f"📊 تعداد گروه های متصل: {total_groups}\n"
        f"🎫 تعداد تیکت ها: {total_tickets} (باز: {open_tickets})\n"
        f"🚫 کاربران بن شده: {total_banned}\n\n"
        f"🔧 برای مدیریت از گزینه های زیر استفاده کنید:",
        reply_markup=markup
    )

async def admin_list_banned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    banned_users = load_banned_users()
    
    if not banned_users:
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_bans")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("❌ هیچ کاربر بن شده‌ای وجود ندارد.", reply_markup=markup)
        return

    banned_list = "🚫 لیست کاربران بن شده:\n\n"
    for user_id, ban_data in banned_users.items():
        banned_list += f"👤 کاربر: {user_id}\n"
        banned_list += f"📅 تاریخ بن: {ban_data['banned_at'][:10]}\n"
        banned_list += f"📝 دلیل: {ban_data['reason']}\n"
        banned_list += "─" * 20 + "\n"

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_bans")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(banned_list, reply_markup=markup)

def delete_ticket(ticket_id):
    tickets_data = load_tickets()
    ticket_id_str = str(ticket_id)
    if ticket_id_str in tickets_data:
        del tickets_data[ticket_id_str]
        save_tickets(tickets_data)
        return True
    return False

async def admin_delete_ticket(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    data = query.data
    ticket_id = int(data.split("_")[3])

    if delete_ticket(ticket_id):
        await query.message.edit_text(f"✅ تیکت #{ticket_id} با موفقیت حذف شد.")
    else:
        await query.message.edit_text("❌ تیکت پیدا نشد.")

async def admin_manage_bans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """منوی اصلی مدیریت بن"""
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    keyboard = [
        [InlineKeyboardButton("📋 لیست کاربران", callback_data="admin_list_users")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "🚫 مدیریت کاربران\n\n"
        "از دکمه‌های زیر استفاده کنید:",
        reply_markup=markup
    )


async def admin_list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """لیست همه کاربران + وضعیت بن"""
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    banned_users = load_banned_users()
    all_users = load_all_users()

    if not all_users:
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_bans")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("❌ هیچ کاربری ثبت نشده است.", reply_markup=markup)
        return

    keyboard = []
    for user_id, user_info in all_users.items():
        username = user_info.get("username", "بدون یوزرنیم")
        if user_id in banned_users:
            btn_text = f"🔓 آن‌بن {username} ({user_id})"
            callback = f"admin_unban_{user_id}"
        else:
            btn_text = f"🚫 بن {username} ({user_id})"
            callback = f"admin_ban_{user_id}"
        keyboard.append([InlineKeyboardButton(btn_text, callback_data=callback)])

    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_manage_bans")])
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text("📋 لیست کاربران:", reply_markup=markup)


async def admin_ban_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """کلیک روی دکمه بن"""
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    user_id = int(query.data.split("_")[2])
    if ban_user_global(user_id, "بدون دلیل"):
        await query.message.edit_text(f"✅ کاربر {user_id} بن شد.")
    else:
        await query.message.edit_text("❌ خطا در بن کاربر.")


async def admin_unban_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """کلیک روی دکمه آن‌بن"""
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    user_id = int(query.data.split("_")[2])
    if unban_user_global(user_id):
        await query.message.edit_text(f"✅ کاربر {user_id} آن‌بن شد.")
    else:
        await query.message.edit_text("❌ خطا در آن‌بن کاربر.")

def load_all_users():
    """بارگذاری تمام کاربران از تیکت‌ها و گروه‌ها"""
    users = {}
    
    tickets_data = load_tickets()
    for ticket_id, ticket in tickets_data.items():
        user_id = ticket["user_id"]
        users[str(user_id)] = {
            "username": ticket.get("username", "بدون یوزرنیم"),
            "source": "ticket"
        }

    groups_data = load_groups()
    for chat_id, group in groups_data.items():

        admin_id = group["admin"]["id"]
        users[str(admin_id)] = {
            "username": group["admin"]["username"],
            "source": "group_admin"
        }
        
        for admin in group.get("additional_admins", []):
            users[str(admin["id"])] = {
                "username": admin["username"],
                "source": "group_additional_admin"
            }
    
    return users

async def admin_send_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    logger.info(f"admin_send_message called with query: {query.data}")

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    keyboard = [
        [InlineKeyboardButton("📨 ارسال همگانی", callback_data="admin_broadcast")],
        [InlineKeyboardButton("👤 ارسال به کاربر", callback_data="admin_send_to_user")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        "📨 ارسال پیام\n\n"
        "لطفا نوع ارسال را انتخاب کنید:",
        reply_markup=markup
    )

async def admin_broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    logger.info("admin_broadcast_start called")

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    await query.message.edit_text("📨 لطفا پیام خود را برای ارسال همگانی وارد کنید:")
    return BROADCAST_MESSAGE

async def admin_send_to_user_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    logger.info("admin_send_to_user_start called")

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    await query.message.edit_text("👤 لطفا آیدی عددی کاربر را وارد کنید:")
    return SEND_TO_USER

async def admin_receive_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.effective_message.reply_text("❌ دسترسی denied.")
        return ConversationHandler.END

    if not update.message or not update.message.text:
        await update.effective_message.reply_text("❌ پیامی دریافت نشد.")
        return ConversationHandler.END

    user_id = update.message.text.strip()
    
    if not user_id.isdigit():
        await update.effective_message.reply_text("❌ آیدی باید عددی باشد. لطفا مجددا وارد کنید:")
        return SEND_TO_USER

    context.user_data["target_user_id"] = user_id
    await update.effective_message.reply_text("✅ آیدی کاربر ذخیره شد. لطفا پیام خود را وارد کنید:")
    return BROADCAST_MESSAGE

async def admin_receive_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.effective_message.reply_text("❌ دسترسی denied.")
        return ConversationHandler.END

    if not update.message or not update.message.text:
        await update.effective_message.reply_text("❌ پیامی دریافت نشد.")
        return ConversationHandler.END

    message = update.message.text
    target_user_id = context.user_data.get("target_user_id")

    if target_user_id:
        try:
            await context.bot.send_message(chat_id=int(target_user_id), text=message)
            await update.effective_message.reply_text(f"✅ پیام با موفقیت به کاربر {target_user_id} ارسال شد.")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ خطا در ارسال پیام: {str(e)}")
    else:

        all_users = load_all_users()
        success_count = 0
        fail_count = 0
        
        for user_id_str in all_users.keys():
            try:
                await context.bot.send_message(chat_id=int(user_id_str), text=message)
                success_count += 1
            except Exception as e:
                logger.error(f"Error sending message to user {user_id_str}: {str(e)}")
                fail_count += 1
        
        await update.effective_message.reply_text(
            f"📨 نتیجه ارسال همگانی:\n"
            f"✅ موفق: {success_count}\n"
            f"❌ ناموفق: {fail_count}"
        )
    
    if "target_user_id" in context.user_data:
        del context.user_data["target_user_id"]
    
    return ConversationHandler.END

async def admin_bot_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    global BOT_ACTIVE
    status = "🟢 روشن" if BOT_ACTIVE else "🔴 خاموش"
    
    keyboard = [
        [InlineKeyboardButton("🔌 خاموش کردن ربات", callback_data="admin_turn_off")],
        [InlineKeyboardButton("🟢 روشن کردن ربات", callback_data="admin_turn_on")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    markup = InlineKeyboardMarkup(keyboard)

    await query.message.edit_text(
        f"🔌 وضعیت ربات: {status}\n\n"
        f"از دکمه‌های زیر برای تغییر وضعیت استفاده کنید:",
        reply_markup=markup
    )

async def admin_turn_off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    global BOT_ACTIVE
    BOT_ACTIVE = False
    
    await query.message.edit_text("✅ ربات خاموش شد.")

async def admin_turn_on(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.message.edit_text("❌ دسترسی denied.")
        return

    global BOT_ACTIVE
    BOT_ACTIVE = True
    
    await query.message.edit_text("✅ ربات روشن شد.")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(msg="Exception while handling an update:", exc_info=context.error)


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):

    await update.message.reply_text("❌ عملیات لغو شد.")
    return ConversationHandler.END


app = ApplicationBuilder().token(TOKEN).build()


interval_conv_handler = ConversationHandler(
    entry_points=[MessageHandler(filters.Regex(r"^تنظیم بازه$"), set_interval_start)],
    states={
        WAITING_INTERVAL: [MessageHandler(filters.TEXT & (~filters.COMMAND), set_interval_receive)]
    },
    fallbacks=[CommandHandler("cancel", cancel)]
)

support_conv_handler = ConversationHandler(
    entry_points=[
        CallbackQueryHandler(create_ticket_handler, pattern="^create_ticket$"),
        CallbackQueryHandler(reply_ticket_handler, pattern="^reply_ticket_")
    ],
    states={
        SUPPORT_TICKET: [MessageHandler(filters.TEXT & (~filters.COMMAND), receive_ticket_message)]
    },
    fallbacks=[CommandHandler("cancel", cancel)]
)


admin_reply_conv_handler = ConversationHandler(
    entry_points=[CallbackQueryHandler(admin_reply_handler, pattern="^admin_reply_")],
    states={
        ADMIN_REPLY: [MessageHandler(filters.TEXT & (~filters.COMMAND), admin_receive_reply)]
    },
    fallbacks=[CommandHandler("cancel", cancel)]
)

message_conv_handler = ConversationHandler(
    entry_points=[
        CallbackQueryHandler(admin_broadcast_start, pattern="^admin_broadcast$"),
        CallbackQueryHandler(admin_send_to_user_start, pattern="^admin_send_to_user$")
    ],
    states={
        SEND_TO_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_receive_user_id)],
        BROADCAST_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_receive_broadcast_message)]
    },
    fallbacks=[CommandHandler("cancel", cancel)]
)

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("price", send_prices))
app.add_handler(MessageHandler(filters.Regex(r'(کریپتو|price|crypto)'), send_prices))

app.add_handler(admin_reply_conv_handler)
app.add_handler(interval_conv_handler)
app.add_handler(support_conv_handler)
app.add_handler(message_conv_handler)

app.add_handler(CallbackQueryHandler(admin_view_tickets, pattern="^admin_view_tickets$"))
app.add_handler(CallbackQueryHandler(delete_ticket_handler, pattern="^delete_ticket_"))
app.add_handler(CallbackQueryHandler(view_tickets, pattern="^view_tickets$"))
app.add_handler(CallbackQueryHandler(back_to_start, pattern="^back_to_start$"))
app.add_handler(CallbackQueryHandler(view_ticket_detail, pattern="^view_ticket_"))
app.add_handler(CallbackQueryHandler(close_ticket_handler, pattern="^close_ticket_"))
app.add_handler(CallbackQueryHandler(reopen_ticket_handler, pattern="^reopen_ticket_"))
app.add_handler(CallbackQueryHandler(reply_ticket_handler, pattern="^reply_ticket_"))
app.add_handler(CallbackQueryHandler(admin_view_ticket, pattern="^admin_view_ticket_"))
app.add_handler(CallbackQueryHandler(admin_reply_handler, pattern="^admin_reply_"))
app.add_handler(CallbackQueryHandler(admin_tickets_back, pattern="^admin_tickets_back$"))
app.add_handler(CallbackQueryHandler(admin_close_ticket_handler, pattern="^admin_close_ticket_"))
app.add_handler(CallbackQueryHandler(admin_reopen_ticket_handler, pattern="^admin_reopen_ticket_"))
app.add_handler(CallbackQueryHandler(admin_delete_ticket, pattern="^admin_delete_ticket_"))

app.add_handler(CommandHandler("admin_panel", admin_panel))
app.add_handler(CallbackQueryHandler(admin_back, pattern="^admin_back$"))
app.add_handler(CallbackQueryHandler(admin_manage_groups, pattern="^admin_manage_groups$"))
app.add_handler(CallbackQueryHandler(admin_group_detail, pattern="^admin_group_detail_"))
app.add_handler(CallbackQueryHandler(admin_remove_group, pattern="^admin_remove_group_"))
app.add_handler(CallbackQueryHandler(admin_stats, pattern="^admin_stats$"))
app.add_handler(CallbackQueryHandler(admin_list_banned, pattern="^admin_list_banned$"))
app.add_handler(CallbackQueryHandler(admin_manage_bans, pattern="^admin_manage_bans$"))
app.add_handler(CallbackQueryHandler(admin_list_users, pattern="^admin_list_users$"))
app.add_handler(CallbackQueryHandler(admin_ban_callback, pattern="^admin_ban_"))
app.add_handler(CallbackQueryHandler(admin_unban_callback, pattern="^admin_unban_"))
app.add_handler(CallbackQueryHandler(admin_bot_status, pattern="^admin_bot_status$"))
app.add_handler(CallbackQueryHandler(admin_turn_off, pattern="^admin_turn_off$"))
app.add_handler(CallbackQueryHandler(admin_turn_on, pattern="^admin_turn_on$"))
app.add_handler(CallbackQueryHandler(admin_send_message, pattern="^admin_send_message$"))
app.add_handler(CallbackQueryHandler(admin_broadcast_start, pattern="^admin_broadcast$"))
app.add_handler(CallbackQueryHandler(admin_send_to_user_start, pattern="^admin_send_to_user$"))

app.add_handler(CallbackQueryHandler(tutorial, pattern="^tutorial$"))
app.add_handler(CallbackQueryHandler(check_sub_handler, pattern="^check_sub$"))
app.add_handler(CallbackQueryHandler(my_groups, pattern="^my_groups$"))
app.add_handler(CallbackQueryHandler(manage_group, pattern="^group_"))
app.add_handler(CallbackQueryHandler(remove_from_group, pattern="^remove_"))
app.add_handler(CallbackQueryHandler(support, pattern="^support$"))
app.add_handler(CallbackQueryHandler(about, pattern="^about$"))

app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, on_group_join))

app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), crypto_listener))

app.add_error_handler(error_handler)


print("bot is run...")
app.run_polling()
