from pyrubi import Bot
from threading import Thread
from datetime import datetime
from rabino import rubino
import os
os.system("clear")


bot = Bot("Reza")
app = rubino("Auth")
et = {}
Time = 180
guidCh = "c0BhWBw018855170cf748f281bc40e2f"


def stoort():
	return f"""سلام کاربر {msg.chat_title()} عزیز به ربات دانلودر روبینو خوش آمدید لطفا متن های زیر را مطالعه فرمایید 📣❤️


این ربات جهت دانلود پست های روبینو ساخته شده است و جهت اشنایی با ان متن زیر را با دقت مطالعه فرمایید 🥇 :

❗️ ** قوانین و محدودیت های ربات **:

1 برای دانلود پست روبینو لینک انرا بدون هیچ پیام اضافی ارسال کنید تا ربات شروع به دانلود کند 🔥
مثال :
https://rubika.ir/post/ZQWkwXIYNW

2 ربات فقط هر 3 دقیقه یک بار جواب پیام هارو شما رو میده یعنی از ارسال اولین پیام شما باید 3 دقیقه گذشته باشه 🚫

3 این پیام راهنما فقط یک بار برای شما ارسال میشود و ازین به بعد با گفتن متن شروع چیزی برای شما ارسال نمیشود دوستان 🔷

4 برای پیام به سازنده ربات قبل پیامتون + بزارید و متن رو بنویسید (استفاده از کلمات نا مناسب موجب مسدودیت شما از ربات میشود ) 😐😂

💎 برای دریافت آخرین اخبار در کانال ما عضو شوید :

@crezabkg1"""

def khishamad():
		try:
			HXghhhhGycchh = msg.message_id()
			hXfyvvhy = msg.chat_id()
			print(hXfyvvhy,HXghhhhGycchh)
			et.update({hXfyvvhy: 9999999})
			bot.send_text(hXfyvvhy,stoort(),message_id=HXghhhhGycchh)
			print(et)
		except:pass
			
def Sendv():
		try:
			Hhhugyy = msg.chat_id()
			Dhdbdjddudd = msg.message_id()
			texttttt = msg.text()
			jdudhwiwjwj = msg.chat_title()
			if et[Hhhugyy] + Time <= int(datetime.timestamp(datetime.now())):
				et.update({Hhhugyy: int(datetime.timestamp(datetime.now()))})
				bot.send_text(Hhhugyy,"**در حال دانلود لطفا صبور باشید . . .** \n\nدقت کنید برای درخواست بعدی باید 3 دقیقه از این درخواست گذشته باشد در غیر این صورت ربات پاسخگو شما نیست ❗️",message_id=Dhdbdjddudd)
				try:
					url = app.getPostByShareLink(texttttt.replace("https://rubika.ir/post/",""))["post"]
				except:
					bot.send_text(Hhhugyy,"**متاسفانه امکان دریافت پست وجود ندارد از درست بودن لینک یا عمومی بودن پیج اطمینان حاصل فرمایید 🚫**",message_id=Dhdbdjddudd)
				if url['file_type'] == "Video":
					sendV = bot.send_video(guidCh,url["full_file_url"],caption=f"""**با موفقیت دانلود شد ❗️**

لینک >>> {texttttt}

درخواست از >>> {jdudhwiwjwj}

**تنها ربات روبینو دانلودر 📣 :**

@city_downlod_bot""")['message_update']['message_id']
					print(sendV)
				else:
					sendV = bot.send_image(guidCh,url["full_file_url"],caption=f"""**با موفقیت دانلود شد ❗️**

لینک >>> {texttttt}

درخواست از >>> {jdudhwiwjwj}

**تنها ربات روبینو دانلودر 📣 :**

@city_downlod_bot""")['message_update']['message_id']
				bot.forward_message(guidCh,[sendV],Hhhugyy)
		except:
			try:
				bot.send_text(hXfyvvhy,"خطایی رخ داد دوباره تلاش کنید .")
			except:
				pass
			pass	

def textPoshtibani():
	try:
		cID = msg.chat_id()
		if et[cID] + Time <= int(datetime.timestamp(datetime.now())):
			et.update({cID: int(datetime.timestamp(datetime.now()))})
			mID = msg.message_id()
			tTT = msg.text()
			nnnnr = msg.chat_title()
			if "کیر" in tTT or "کص" in tTT or "کیل" in tTT or "آلت" in tTT or "کص" in tTT or "کث" in tTT or "کاپص" in tTT or "کوبص" in tTT or "مادر" in tTT or "مامان" in tTT or "کیبر" in tTT or "kir" in tTT or "kos" in tTT or "کون" in tTT or "باسن" in tTT or "جق" in tTT or "جاق" in tTT or "واژن" in tTT or "ارضا" in tTT or "ابم" in tTT or "اسپرم" in tTT or "حامله" in tTT or "مامی" in tTT or "کان" in tTT or "کیان" in tTT or "چیزم" in tTT:
				bot.send_text(cID,"بیا اینو بخور کون صلواتی هرچیم گوفتی برا خودت 😍😂",mID)
				bot.block_user(cID)
			else:
				bot.send_text("u0CdLxb035b81bbafadeb9c7c44b0532",tTT.replace("+","") )
				bot.send_text(cID,"**پیام با موفقیت ثبت شد** ✔️\n\nبرای ثبت درخواست بعدی 3 دقیقه صبر کنید در غیر این صورت ربات پاسخگو شما نیست ❗️",message_id=mID)
	except:pass
	
def meghdarBot():
	try:
		bot.send_text("گوید ادمین ربات","تعداد اعضای ربات : "+str(len(et.keys())),message_id=msg.message_id())
	except:pass
	
def getRubika():
	while True:
		try:
			bot.get_chats_update2()
		except:pass
		
Thread(target=getRubika, args=[]).start()

while True:
	for msg in bot.on_message():
		try:
			print(msg.text())
			if msg.chat_type() == "User":
				if not msg.chat_id() in et.keys():
					Thread(target=khishamad, args=[]).start()
				elif msg.text().startswith("https://rubika.ir/post/"):
					Thread(target=Sendv, args=[]).start()
				elif msg.text().startswith("+"):
					Thread(target=textPoshtibani, args=[]).start()
				elif msg.text() == "تعداد" and msg.chat_id() == "u0CdLxb035b81bbafadeb9c7c44b0532":
					Thread(target=meghdarBot, args=[]).start()
		except:pass