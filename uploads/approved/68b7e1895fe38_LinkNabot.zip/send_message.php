<?php

if (isset($_GET['ref'])) {
    $ownerId = $_GET['ref'];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $message = $_POST['message'];

        $badWords = ['گاییدم', 'ننت', 'مادرتو', 'کیر', 'کص', 'کون' ,'fuck'];

        foreach ($badWords as $badWord) {
    if (stripos($message, $badWord) !== false) {
        echo "پیام شما شامل کلمات نامناسب است.";
        exit;
    }
}

        sendMessageToOwner($ownerId, $message);
        echo "پیام شما ارسال شد!";
    }
} else {
    echo "شناسه کاربر نامعتبر است.";
}

function sendMessageToOwner($ownerId, $message) {
    $token = "توکن"; 
    $apiUrl = "https://api.telegram.org/bot$token/";
    $url = $apiUrl . "sendMessage?chat_id=$ownerId&text=پیام جدید: " . urlencode($message);
    file_get_contents($url);
}

?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>@LinkNabot</title>
    <style>
        body {
            background-color: #800080; 
            color: white; 
            font-family: Arial, sans-serif; 
            text-align: center; 
            padding: 50px; 
        }
        h1 {
            margin-bottom: 20px; 
        }
        textarea {
            width: 80%; 
            height: 100px; 
            border-radius: 5px; 
            border: 1px solid #ccc; 
            padding: 10px; 
            font-size: 16px; 
        }
        button {
            background-color: #4CAF50; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            padding: 10px 20px; 
            font-size: 16px; 
            cursor: pointer; 
            margin-top: 10px; 
        }
        button:hover {
            background-color: #45a049; 
        }
    </style>
</head>
<body>
    <h1>ارسال پیام ناشناس</h1>
    <form method="POST">
        <textarea name="message" required placeholder="پیام خود را اینجا وارد کنید..."></textarea><br>
        <button type="submit">ارسال پیام</button>
    </form>
</body>
</html>