<?php
// نوشته شده جهت طنز و ازمایش @Maniawma
$token = "توکن";
$apiUrl = "https://api.telegram.org/bot$token/";

$badWords = ['کیر', 'کص', 'کون' ,'ننتو'];
$admin_id = "ایدی عددی";

function sendMessage($chatId, $text, $replyMarkup = null) {
    global $apiUrl;
    $data = [
        'chat_id' => $chatId,
        'text' => $text,
    ];
    if ($replyMarkup) {
        $data['reply_markup'] = json_encode($replyMarkup);
    }
    $response = file_get_contents($apiUrl . 'sendMessage?' . http_build_query($data));
    return json_decode($response, true);
}

function addUser ($chatId) {
    $file = 'num.txt';
    $users = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!in_array($chatId, $users)) {
        file_put_contents($file, $chatId . PHP_EOL, FILE_APPEND);
    }
}

function createLink($chatId) {
    return "https://دامین/send_message.php?ref=$chatId"; 
}

function containsBadWords($text, $badWords) {
    foreach ($badWords as $word) {
        if (stripos($text, $word) !== false) {
            return true;
        }
    }
    return false;
}

$update = json_decode(file_get_contents("php://input"), true);
$chatId = $update['message']['chat']['id'];
$messageText = $update['message']['text'];
$first_name = $update['message']['from']['first_name'];

addUser ($chatId);

if ($messageText === '/start') {
    sendMessage($chatId, "سلام $first_name عزیز😄

🚩به ربات لینک ناشناس پرفکت خوش اومدی!

از دکمه پایین برای گرفتن لینک شخصی خودت استفاده کن✅
🆔 @LinkNabot", [
        'keyboard' => [
            [['text' => "ساخت لینک شخصی"], ['text' => "کانال ما"]],
        ],
        'resize_keyboard' => true,
        'one_time_keyboard' => true
    ]);
} elseif ($messageText === 'ساخت لینک شخصی') {
    $link = createLink($chatId);
    sendMessage($chatId, "لینک ناشناس شما👇

( $link )

یادتون باشه هر کاربر حق داره فقط یک لینک داشته باشه❗️

🆔 @LinkNabot");
} elseif ($messageText === 'کانال ما') {
    sendMessage($chatId, "کانال ما: @ایدی چنل");
} elseif ($messageText === '/panel' && $chatId == $admin_id) {
    $user_count = count(file('num.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
    sendMessage($chatId, "تعداد کاربران: $user_count\nبرای ارسال پیام به همه کاربران، از دستور /send استفاده کنید.");
} elseif (strpos($messageText, '/send ') === 0 && $chatId == $admin_id) {
    $message_to_send = substr($messageText, 6);
    sendMessageToAll($message_to_send);
    sendMessage($chatId, "پیام به همه کاربران ارسال شد.");
} else {

    if (containsBadWords($messageText, $badWords)) {
        sendMessage($chatId, "پیام شما شامل کلمات نامناسب است.");
    } else {
        sendMessage($chatId, "لطفاً از دکمه‌های موجود استفاده کنید.");
    }
}

function sendMessageToAll($message) {
    global $token, $admin_id;
    $users = file('num.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($users as $user) {
        if ($user != $admin_id) {
            $response = sendMessage($user, $message);
            if (isset($response['ok']) && !$response['ok']) {
                error_log("Error sending message to user $user: " . $response['description']);
            }
        }
    }
}
// نوشته شده جهت طنز و ازمایش @Maniawma
?>