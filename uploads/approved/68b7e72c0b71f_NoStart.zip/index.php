<?php
/*
-----------------------------------
In The Name Of God

نوشته شده توسط (@Maniawma)
-----------------------------------
*/
error_reporting(0);
define('API_KEY','توکن ربات'); //توکن
$admin = "12345678"; //ایدی عددی ادمین
$channel = "بدون@"; //کانال قفل ربات
$token = "توکن ربات";
$supp = "Glviz"; //ایدی پشتیبان
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendMessage($chat_id,$text,$keyboard){
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$text,
	'reply_markup'=>$keyboard]);
}
function edit($chat_id,$meesage_id,$text,$reply_markup){
	bot('editMessageText',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
	'text'=>$text,
	'reply_markup'=>$reply_markup]);
}
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function Forward($koja,$key,$pm)
{
    bot('ForwardMessage',[
        'chat_id'=>$koja,
        'from_chat_id'=>$key,
        'message_id'=>$pm
    ]);
}
$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$text = $update->message->text;
$chat_id = $update->message->chat->id;
$chat_id = $update->message->from->id;
$message_id = $update->message->message_id;
$first_name = $update->message->from->first_name;
$first = $update->callback_query->from->first_name;
$last_name = $update->callback_query->from->last_name;
$username = $update->callback_query->from->username;
$username2 = $update->message->from->username;
$time = file_get_contents("http://mehdiyousefii.lordmizban.ir/api/date.php");
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@$channel&user_id=".$chat_id));
$tch = $forchannel->result->status;
$chatid = $update->callback_query->message->chat->id;
$messageid = $update->callback_query->message->message_id;
$forward_username = $update->message->forward_from_chat->username;
$reply = $message->reply_to_message->forward_from->id;
$reply_username = $message->reply_to_message->forward_from->username;
mkdir("data/$chat_id");
$data = file_get_contents("data/$chat_id/mehdii.txt");
$load = sys_getloadavg();
if($text == "/start"){	
	if($tch == 'member' or $tch == 'creator' or $tch == 'administrator'){
if (!file_exists("data/$chat_id/mehdii.txt")) {
        mkdir("data/$chat_id");
       file_put_contents("data/$chat_id/mehdii.txt","none");
        $myfile2 = fopen("member.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$chat_id\n");
        fclose($myfile2);
    }
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"سلام کاربر $first_name 
به ربات No Start  در ساعت $time خوش امدید 💚

جهت رفتن به منوی اصلی ربات از دکمه ( شیشه ای )
زیر استفاده کنید 👇🏼",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"▫️رفتن به مرحله بعد▫️"],
],
],
'resize_keyboard'=>true
])
]);
}else {
    bot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "دوست عزیز  بدلیل رایگان بودن ربات 
و همچنین حمایت شما از ما ابتدا در کانال ما


🆔 @$channel

عضو شده و سپس دوباره ربات را /start کنید ✅"
    ]);
    return false;
}
}
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }  
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode' => "html",
'reply_markup'=>json_encode([
    'Remove_Keyboard'=>[
        ],
        'remove_keyboard'=>true
    ])
]);
  }
if($text == "▫️رفتن به مرحله بعد▫️"){
	$from_file = file_get_contents("foshs.txt");
	$arraytext = explode("\n",$from_file);
	$numtext = count($arraytext);
	$randtext = rand(0,$numtext);
	$echotext = $arraytext[$randtext];
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"| $echotext |",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"✉️راهنما✉️"],['text'=>"👮🏻‍♂️پشتیبانی👮🏻‍♂️"]
],
[
['text'=>"/start"],
],
],
'resize_keyboard'=>true
])
]);
}   
if($text == "👮🏻‍♂️پشتیبانی👮🏻‍♂️"){
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"اگر انتقاد یا پیشنهادی دارید با ایدی زیر در ارتباط باشید 👇🏼
@$supp ",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"/start"],
],
],
'resize_keyboard'=>true
])
]);
} 
if($text == "✉️راهنما✉️"){
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" راهنمای ربات:

این ربات برای سرگرمی و شوخی و فان است 

سازنده ربات:
@$supp ",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"/start"],
],
],
'resize_keyboard'=>true
])
]);
}  
elseif($text == '/creator'){
sendmessage($chat_id,"Created By @Maniawma");
}
elseif($text == "/panel" and $chat_id == $admin){
bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام قربان 🙃🙌🏻

به پنل ربات خودتون خوش امدید ❤️

چکاری از دستم برمیاد؟؟؟؟",
 
 'parse_mode'=>'MarkDown', 
 'reply_markup'=>json_encode([
 'resize_keyboard'=>true,
 'keyboard'=>[
 [['text'=>"🏷 پیام همگانی"],['text'=>"📪فوروارد همگانی"]],
 [['text'=>"👥امار ربات"],['text'=>"🗃وضعیت ربات"]],
 ]
 ])
 ]);
 }
elseif($text == "🔙بازگشت🔙"){
bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"به پنل برگشتید",     
 'parse_mode'=>'MarkDown', 
 'reply_markup'=>json_encode([
 'resize_keyboard'=>true,
 'keyboard'=>[
 [['text'=>"🏷 پیام همگانی"],['text'=>"📪فوروارد همگانی"]],
 [['text'=>"👥امار ربات"],['text'=>"🗃وضعیت ربات"]],
 ]
 ])
 ]);
 }
elseif($text == "👥امار ربات" && $chat_id == $admin){
    $user = file_get_contents("member.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🔖امار ربات شما:
$member_count",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙بازگشت🔙"],
],
],
'resize_keyboard'=>true
])
]);
}
elseif($text == "🏷 پیام همگانی" && $chat_id == $admin){
    file_put_contents("data/$chat_id/mehdii.txt","send");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" 📝 پیام مورد نظر رو در قالب متن بفرستید:",
    'parse_mode'=>'html',    'reply_markup'=>json_encode([
      'keyboard'=>[
   [['text'=>'🔙بازگشت🔙']],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($data == "send" && $chat_id == $admin){
    file_put_contents("data/$chat_id/mehdii.txt","no");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>" 📬پیام همگانی ارسال شد",
  ]);
 $all_member = fopen( "member.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
			bot('SendMessage',[
			'chat_id'=>$user,
			'text'=>$text]);
	}
}
elseif($text == "📪فوروارد همگانی" && $chat_id == $admin){
    file_put_contents("data/$chat_id/mehdii.txt","fwd");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"پیام خودتون را فوروارد کنید:",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
   [['text'=>'🔙بازگشت🔙']],
      ],'resize_keyboard'=>true])
  ]);
}
elseif($data == "fwd" && $chat_id == $admin){
    file_put_contents("data/$chat_id/mehdii.txt","no");
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"درحال ارسال",
  ]);
$forp = fopen( "member.txt", 'r'); 
while( !feof( $forp)) { 
$fakar = fgets( $forp); 
Forward($fakar, $chat_id,$message_id); 
  } 
   bot('sendMessage',[ 
   'chat_id'=>$chat_id, 
   'text'=>"با موفقیت ارسال شد.", 
   ]);
}
elseif($text == "🗃وضعیت ربات"){
    bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍PING ; $load[0] ",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'keyboard'=>[
[
['text'=>"🔙بازگشت🔙"],
],
],
'resize_keyboard'=>true
])
]);
}
?>