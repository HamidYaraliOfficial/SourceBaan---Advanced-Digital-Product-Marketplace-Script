import os
import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

BOT_TOKEN = "8311033246:AAH-Riee6abMqblYZbDbmXPgxGZRW3Ly4eY"
BASE_DOWNLOAD_PATH = os.path.join(os.getcwd(), "downloads")
os.makedirs(BASE_DOWNLOAD_PATH, exist_ok=True)

FASTCREATE_API = "https://api.fast-creat.ir/instagram"
API_KEY = "6962248902:Xg6UYGbr3KaxcjZ@Api_ManagerRoBot"

HISTORY_FILE = "history.json"
def save_history(chat_id, url):
    import json
    history = {}
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            history = json.load(f)
    user_history = history.get(str(chat_id), [])
    user_history.append(url)
    history[str(chat_id)] = user_history
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f)


def get_history(chat_id):
    import json
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            history = json.load(f)
        return history.get(str(chat_id), [])
    return []
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("دانلود پست", callback_data="post")],
        [InlineKeyboardButton("دانلود ریلز", callback_data="reel")],
        [InlineKeyboardButton("دانلود IGTV", callback_data="igtv")],
        [InlineKeyboardButton("تاریخچه دانلود", callback_data="history")]
    ]
    await update.message.reply_text(
         "به دانلودر ورینوکس خوش امدید ❤️‍🔥", 
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    chat_id = query.message.chat.id

    if data in ["post", "reel", "igtv"]:
        await context.bot.send_message(chat_id, "لطفا لینک مورد نظر را ارسال کنید:")
        context.user_data["download_type"] = data

    elif data == "history":
        links = get_history(chat_id)
        if links:
            await context.bot.send_message(chat_id, "📜 تاریخچه دانلود شما:\n" + "\n".join(links))
        else:
            await context.bot.send_message(chat_id, "❌ هنوز هیچ لینکی دانلود نکرده‌اید.")
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip() if update.message.text else None

    download_type = context.user_data.get("download_type")

    if not download_type:
        await update.message.reply_text("لطفا ابتدا یکی از گزینه‌های دانلود را انتخاب کنید.")
        return

    if text is None or not text.startswith("http") or "instagram.com" not in text:
        await update.message.reply_text("لطفا لینک معتبر اینستاگرام ارسال کنید.")
        return

    await update.message.reply_text("لطفا کمی صبر کنید، در حال دریافت محتوا ...")
    await download_instagram_post(text, chat_id, context)
    save_history(chat_id, text)
    context.user_data.pop("download_type", None)
    
async def download_instagram_post(url, chat_id, context):
    params = {"apikey": API_KEY, "type": "post", "url": url}
    async with aiohttp.ClientSession() as session:
        async with session.get(FASTCREATE_API, params=params) as resp:
            data = await resp.json()

    if data.get("ok") and data["result"].get("result"):
        first_item = data["result"]["result"][0]
        caption = first_item.get("caption", "")
        caption += "\n\nDevelopers:@PV_TRINOX"

        if first_item.get("is_video") and first_item.get("video_url"):
            await context.bot.send_video(chat_id, video=first_item["video_url"], caption=caption)
        else:
            await context.bot.send_message(chat_id, "❌ ویدیویی پیدا نشد یا لینک معتبر نیست.")
    else:
        await context.bot.send_message(chat_id, "⛔️ خطا در دریافت اطلاعات.")


# ---------- اجرای بات ----------
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Bot is running 🔥")
    app.run_polling()


if __name__ == "__main__":
    main()