import os
import logging
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext, CallbackQueryHandler
from PIL import Image
from fpdf import FPDF
import uuid
from datetime import datetime, timedelta
from collections import defaultdict

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "BOT_TOKEN" # توکن ربات 
ADMIN_IDS = [123456789] # آیدی ادمین ها 
CONFIG_FILE = "bot_config.json"

CONVERSION_OPTIONS = {
    'image': {
        'jpg': ['png', 'webp', 'bmp'],
        'jpeg': ['png', 'webp', 'bmp'],
        'png': ['jpg', 'webp', 'bmp'],
        'webp': ['jpg', 'png', 'bmp'],
        'bmp': ['jpg', 'png', 'webp'],
    },
    'document': {
        'txt': ['pdf', 'md'],
        'md': ['txt', 'pdf'],
    }
}

class FileConverterBot:
    def __init__(self):
        self.application = Application.builder().token(BOT_TOKEN).build()
        self.user_sessions = {}
        self.banned_users = set()
        self.user_message_counts = defaultdict(list)
        self.temp_banned_users = {}
        self.bot_config = self.load_config()
        self.setup_handlers()

    def load_config(self):
        default_config = {
            "forced_joins": [],
            "start_message": "🤖 به ربات تبدیل فایل خوش آمدید!\n📁 فایل خود را ارسال کنید (عکس، سند)\n🔄 ربات به صورت خودکار فرمت‌های قابل تبدیل را نمایش می‌دهد\n\nدستورات:\n/start - شروع کار با ربات\n/help - راهنمایی\nDeveloper: https://info-me.netlify.app",
            "help_message": "📖 راهنمای ربات تبدیل فایل:\n• عکس‌ها (JPG, PNG, WebP, BMP) را می‌توانید به فرمت‌های دیگر تبدیل کنید\n• متن‌ها (TXT, MD) را می‌توانید به PDF تبدیل کنید\n• فایل خود را مستقیماً ارسال کنید و گزینه‌های تبدیل را انتخاب کنید\n• /support برای ارسال پیام به پشتیبانی\n⚠️ محدودیت حجم: 20MB",
            "bot_enabled": True,
            "bot_off_message": "⚠️ ربات غیرفعال است."
        }
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r') as f:
                    return json.load(f)
            return default_config
        except:
            return default_config

    def save_config(self):
        with open(CONFIG_FILE, 'w') as f:
            json.dump(self.bot_config, f, indent=4)

    def setup_handlers(self):
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(CommandHandler("help", self.help))
        self.application.add_handler(CommandHandler("admin", self.admin_panel))
        self.application.add_handler(CommandHandler("support", self.support_message))
        self.application.add_handler(MessageHandler(filters.Document.ALL, self.handle_document))
        self.application.add_handler(MessageHandler(filters.PHOTO, self.handle_photo))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_user_message))
        self.application.add_handler(CallbackQueryHandler(self.handle_callback))

    async def check_message_limit(self, user_id: int) -> bool:
        current_time = datetime.now()
        self.user_message_counts[user_id] = [t for t in self.user_message_counts[user_id] if current_time - t < timedelta(seconds=30)]
        self.user_message_counts[user_id].append(current_time)
        
        if len(self.user_message_counts[user_id]) > 3:
            self.temp_banned_users[user_id] = current_time + timedelta(minutes=5)
            return False
        return True

    async def start(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not self.bot_config["bot_enabled"]:
            await update.message.reply_text(self.bot_config["bot_off_message"])
            return
        if not await self.check_forced_joins(update, context):
            return
        await update.message.reply_text(self.bot_config["start_message"])

    async def help(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not self.bot_config["bot_enabled"]:
            await update.message.reply_text(self.bot_config["bot_off_message"])
            return
        await update.message.reply_text(self.bot_config["help_message"])

    async def check_forced_joins(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        for channel in self.bot_config["forced_joins"]:
            try:
                member = await context.bot.get_chat_member(channel, user_id)
                if member.status not in ['member', 'administrator', 'creator']:
                    keyboard = [[InlineKeyboardButton("عضویت", url=f"https://t.me/{channel[1:]}")]]
                    await update.message.reply_text("لطفاً ابتدا در کانال‌های زیر عضو شوید:", reply_markup=InlineKeyboardMarkup(keyboard))
                    return False
            except:
                continue
        return True

    async def admin_panel(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if user_id not in ADMIN_IDS:
            await update.message.reply_text("❌ شما دسترسی ادمین ندارید.")
            return
        keyboard = [
            [InlineKeyboardButton("اضافه کردن جوین اجباری", callback_data="add_forced_join")],
            [InlineKeyboardButton("حذف جوین اجباری", callback_data="remove_forced_join")],
            [InlineKeyboardButton("ارسال پیام تکی", callback_data="send_single_message")],
            [InlineKeyboardButton("ارسال پیام همگانی", callback_data="send_broadcast")],
            [InlineKeyboardButton("مسدود کردن کاربر", callback_data="ban_user")],
            [InlineKeyboardButton("لغو مسدودیت کاربر", callback_data="unban_user")],
            [InlineKeyboardButton("تغییر متن start", callback_data="change_start_message")],
            [InlineKeyboardButton("تغییر متن help", callback_data="change_help_message")],
            [InlineKeyboardButton("تغییر متن خاموشی ربات", callback_data="change_off_message")],
            [InlineKeyboardButton("خاموش/روشن کردن ربات", callback_data="toggle_bot")]
        ]
        await update.message.reply_text("پنل مدیریت ادمین:", reply_markup=InlineKeyboardMarkup(keyboard))

    async def handle_callback(self, update: Update, context: CallbackContext):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id
        if user_id not in ADMIN_IDS and not query.data.startswith('conv:'):
            await query.edit_message_text("❌ شما دسترسی ادمین ندارید.")
            return

        if query.data == "add_forced_join":
            await query.edit_message_text("لطفاً آیدی کانال را وارد کنید (مثال: @ChannelID)")
            context.user_data['admin_action'] = "add_forced_join"
        elif query.data == "remove_forced_join":
            keyboard = [[InlineKeyboardButton(channel, callback_data=f"remove_channel:{channel}")] for channel in self.bot_config["forced_joins"]]
            await query.edit_message_text("کانال مورد نظر برای حذف:", reply_markup=InlineKeyboardMarkup(keyboard))
        elif query.data.startswith("remove_channel:"):
            channel = query.data.split(":")[1]
            if channel in self.bot_config["forced_joins"]:
                self.bot_config["forced_joins"].remove(channel)
                self.save_config()
                await query.edit_message_text(f"کانال {channel} از جوین اجباری حذف شد.")
            else:
                await query.edit_message_text("کانال یافت نشد.")
        elif query.data == "send_single_message":
            await query.edit_message_text("آیدی عددی کاربر و پیام را وارد کنید (فرمت: user_id پیام)")
            context.user_data['admin_action'] = "send_single_message"
        elif query.data == "send_broadcast":
            await query.edit_message_text("پیام همگانی را وارد کنید:")
            context.user_data['admin_action'] = "send_broadcast"
        elif query.data == "ban_user":
            await query.edit_message_text("آیدی عددی کاربر را وارد کنید:")
            context.user_data['admin_action'] = "ban_user"
        elif query.data == "unban_user":
            await query.edit_message_text("آیدی عددی کاربر را وارد کنید:")
            context.user_data['admin_action'] = "unban_user"
        elif query.data == "change_start_message":
            await query.edit_message_text("متن جدید start را وارد کنید:")
            context.user_data['admin_action'] = "change_start_message"
        elif query.data == "change_help_message":
            await query.edit_message_text("متن جدید help را وارد کنید:")
            context.user_data['admin_action'] = "change_help_message"
        elif query.data == "change_off_message":
            await query.edit_message_text("متن جدید خاموشی ربات را وارد کنید:")
            context.user_data['admin_action'] = "change_off_message"
        elif query.data == "toggle_bot":
            self.bot_config["bot_enabled"] = not self.bot_config["bot_enabled"]
            self.save_config()
            status = "روشن" if self.bot_config["bot_enabled"] else "خاموش"
            await query.edit_message_text(f"ربات {status} شد.")
        elif query.data.startswith('conv:'):
            await self.handle_conversion_choice(update, context)

    async def handle_user_message(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not await self.check_message_limit(user_id):
            await update.message.reply_text("❌ شما بیش از حد پیام ارسال کرده‌اید. لطفاً ۵ دقیقه صبر کنید.")
            return
        if 'admin_action' in context.user_data and user_id in ADMIN_IDS:
            action = context.user_data['admin_action']
            if action == "add_forced_join":
                channel_id = update.message.text.strip()
                if channel_id.startswith('@'):
                    self.bot_config["forced_joins"].append(channel_id)
                    self.save_config()
                    await update.message.reply_text(f"کانال {channel_id} به جوین اجباری اضافه شد.")
                else:
                    await update.message.reply_text("لطفاً آیدی معتبر کانال (با @) وارد کنید.")
            elif action == "send_single_message":
                try:
                    target_id, message = update.message.text.split(" ", 1)
                    await context.bot.send_message(target_id, message)
                    await update.message.reply_text("پیام ارسال شد.")
                except:
                    await update.message.reply_text("فرمت اشتباه. مثال: 123456789 پیام")
            elif action == "send_broadcast":
                message = update.message.text
                for session in self.user_sessions.values():
                    try:
                        await context.bot.send_message(session['user_id'], message)
                    except:
                        continue
                await update.message.reply_text("پیام همگانی ارسال شد.")
            elif action == "ban_user":
                try:
                    target_id = int(update.message.text)
                    self.banned_users.add(target_id)
                    await update.message.reply_text(f"کاربر {target_id} مسدود شد.")
                except:
                    await update.message.reply_text("آیدی عددی معتبر وارد کنید.")
            elif action == "unban_user":
                try:
                    target_id = int(update.message.text)
                    self.banned_users.discard(target_id)
                    await update.message.reply_text(f"مسدودیت کاربر {target_id} لغو شد.")
                except:
                    await update.message.reply_text("آیدی عددی معتبر وارد کنید.")
            elif action == "change_start_message":
                self.bot_config["start_message"] = update.message.text
                self.save_config()
                await update.message.reply_text("متن start تغییر کرد.")
            elif action == "change_help_message":
                self.bot_config["help_message"] = update.message.text
                self.save_config()
                await update.message.reply_text("متن help تغییر کرد.")
            elif action == "change_off_message":
                self.bot_config["bot_off_message"] = update.message.text
                self.save_config()
                await update.message.reply_text("متن خاموشی ربات تغییر کرد.")
            context.user_data.pop('admin_action', None)
        else:
            await self.support_message(update, context)

    async def support_message(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not await self.check_message_limit(user_id):
            await update.message.reply_text("❌ شما بیش از حد پیام ارسال کرده‌اید. لطفاً ۵ دقیقه صبر کنید.")
            return
        message = update.message.text
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(admin_id, f"پیام پشتیبانی از {user_id}:\n{message}")
            except:
                continue
        await update.message.reply_text("پیام شما به پشتیبانی ارسال شد.")

    def get_file_info(self, file_name):
        if not file_name or '.' not in file_name:
            return None, None
        ext = file_name.split('.')[-1].lower()
        file_type = None
        for category, formats in CONVERSION_OPTIONS.items():
            if ext in formats:
                file_type = category
                break
        return ext, file_type

    async def handle_document(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if not self.bot_config["bot_enabled"]:
            await update.message.reply_text(self.bot_config["bot_off_message"])
            return
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not await self.check_message_limit(user_id):
            await update.message.reply_text("❌ شما بیش از حد پیام ارسال کرده‌اید. لطفاً ۵ دقیقه صبر کنید.")
            return
        try:
            document = update.message.document
            file_name = document.file_name
            if not file_name:
                await update.message.reply_text("⚠️ نام فایل مشخص نیست")
                return
            ext, file_type = self.get_file_info(file_name)
            if file_type:
                await self.show_conversion_options(update, context, file_name, ext, file_type, document.file_id)
            else:
                await update.message.reply_text("⚠️ فرمت فایل پشتیبانی نمی‌شود")
        except Exception as e:
            logger.error(f"Error handling document: {e}")
            await update.message.reply_text("❌ خطا در پردازش فایل")

    async def handle_photo(self, update: Update, context: CallbackContext):
        user_id = update.message.from_user.id
        if not self.bot_config["bot_enabled"]:
            await update.message.reply_text(self.bot_config["bot_off_message"])
            return
        if user_id in self.banned_users or user_id in self.temp_banned_users:
            if user_id in self.temp_banned_users and datetime.now() < self.temp_banned_users[user_id]:
                await update.message.reply_text(f"❌ شما برای {int((self.temp_banned_users[user_id] - datetime.now()).total_seconds() // 60)} دقیقه مسدود شده‌اید.")
                return
            elif user_id in self.temp_banned_users:
                del self.temp_banned_users[user_id]
            else:
                await update.message.reply_text("❌ شما از ربات مسدود شده‌اید.")
                return
        if not await self.check_message_limit(user_id):
            await update.message.reply_text("❌ شما بیش از حد پیام ارسال کرده‌اید. لطفاً ۵ دقیقه صبر کنید.")
            return
        try:
            photo = update.message.photo[-1]
            file_name = f"photo.jpg"
            file_id = photo.file_id
            user_id = update.message.from_user.id
            session_id = str(uuid.uuid4())
            self.user_sessions[session_id] = {
                'file_id': file_id,
                'file_name': file_name,
                'current_ext': 'jpg',
                'file_type': 'image',
                'user_id': user_id
            }
            await self.show_conversion_options(update, context, file_name, 'jpg', 'image', file_id, session_id)
        except Exception as e:
            logger.error(f"Error handling photo: {e}")
            await update.message.reply_text("❌ خطا در پردازش عکس")

    async def show_conversion_options(self, update: Update, context: CallbackContext, 
                                    file_name: str, current_ext: str, file_type: str, 
                                    file_id: str, session_id: str = None):
        try:
            if not session_id:
                session_id = str(uuid.uuid4())
                user_id = update.message.from_user.id
                self.user_sessions[session_id] = {
                    'file_id': file_id,
       