# config.py
# تنظیمات اصلی ربات حکم

# توکن ربات از BotFather
BOT_TOKEN = "7698184202:AAH9mjGC1QErqJSAG40jWqR63T9PKQfj6jY"

# لیست آیدی عددی ادمین‌ها
# می‌تونی با /idbot یا ربات‌های UserInfo آیدیت رو پیدا کنی
ADMINS = [
    7135477742,  # غفور
    # می‌تونی آیدی‌های دیگه هم اضافه کنی
]

# حداکثر تعداد میز فعال همزمان
MAX_TABLES = 50

# مسیر ذخیره وضعیت (Persistence)
STATE_FILE = "hokm_state.pkl"

# حداکثر طول هر پیام متنی برای تکه‌تکه کردن (حداکثر تلگرام 4096)
MSG_CHUNK = 3500
