# hokm_bot.py
# ===========
# Requires: python-telegram-bot==20.7
# Run:      python hokm_bot.py
#
# Features
# - Group-friendly Hokm (حکم) with inline table creation
# - 2x2 teams, hakim selection, trump (حکم) choice, trick tracking, hand scoring
# - Persistence via PicklePersistence
# - Admin panel (/admin): see tables, close tables, broadcast, stats
# - Uses config.py for BOT_TOKEN, ADMINS, STATE_FILE, MAX_TABLES

from __future__ import annotations
import logging
import random
import string
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQueryResultArticle,
    InputTextMessageContent,
    Update,
)
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    InlineQueryHandler,
    MessageHandler,
    PicklePersistence,
    filters,
)

from config import BOT_TOKEN, ADMINS, MAX_TABLES, STATE_FILE, MSG_CHUNK

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("hokm-bot")

# ---------- Game Model ----------
SUITS = ["♠", "♥", "♦", "♣"]
RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
RANK_VAL = {r: i for i, r in enumerate(RANKS)}

Card = Tuple[str, str]  # (rank, suit)

def make_deck() -> List[Card]:
    return [(r, s) for s in SUITS for r in RANKS]


def card_str(card: Card) -> str:
    r, s = card
    return f"{r}{s}"


def sort_hand(hand: List[Card], trump: Optional[str]) -> List[Card]:
    def key(c):
        r, s = c
        return (0 if trump and s == trump else 1, SUITS.index(s), RANK_VAL[r])

    return sorted(hand, key=key)


def hand_to_text(hand: List[Card]) -> str:
    by_suit = {s: [] for s in SUITS}
    for c in hand:
        by_suit[c[1]].append(c)
    parts = []
    for s in SUITS:
        if by_suit[s]:
            parts.append(s + ": " + " ".join(card_str(c) for c in sort_hand(by_suit[s], None)))
    return "\n".join(parts) if parts else "—"


@dataclass
class Player:
    user_id: int
    name: str


@dataclass
class TrickState:
    leader_index: int = 0
    lead_suit: Optional[str] = None
    plays: Dict[int, Card] = field(default_factory=dict)  # seat -> card


@dataclass
class Table:
    table_id: str
    chat_id: int
    message_id: int
    title: str
    players: List[Optional[Player]] = field(default_factory=lambda: [None, None, None, None])
    teams: Dict[int, int] = field(default_factory=dict)  # seat -> team (0 or 1)
    hakem_seat: Optional[int] = None
    trump: Optional[str] = None
    deck: List[Card] = field(default_factory=list)
    hands: Dict[int, List[Card]] = field(default_factory=dict)  # seat -> cards
    turn_seat: Optional[int] = None
    trick: TrickState = field(default_factory=TrickState)
    score_hands: List[int] = field(default_factory=lambda: [0, 0])
    score_sets: List[int] = field(default_factory=lambda: [0, 0])
    started: bool = False
    finished: bool = False
    created_at: float = field(default_factory=time.time)

    def seats_filled(self) -> int:
        return sum(1 for p in self.players if p)

    def is_full(self) -> bool:
        return self.seats_filled() == 4

    def seat_of(self, user_id: int) -> Optional[int]:
        for i, p in enumerate(self.players):
            if p and p.user_id == user_id:
                return i
        return None

    def teammate_seat(self, seat: int) -> int:
        return (seat + 2) % 4

    def next_seat(self, seat: int) -> int:
        return (seat + 1) % 4

    def ensure_team_mapping(self):
        self.teams = {0: 0, 2: 0, 1: 1, 3: 1}

    def start_hand(self):
        self.score_hands = [0, 0]
        self.trick = TrickState(leader_index=self.hakem_seat or 0)
        self.trump = None
        self.deck = make_deck()
        random.shuffle(self.deck)
        self.hands = {seat: [] for seat in range(4)}
        for _ in range(5):
            self.hands[self.hakem_seat].append(self.deck.pop())
        self.turn_seat = self.hakem_seat

    def set_trump(self, suit: str):
        self.trump = suit
        while any(len(h) < 13 for h in self.hands.values()):
            for seat in range(4):
                if len(self.hands[seat]) < 13 and self.deck:
                    self.hands[seat].append(self.deck.pop())
        for seat in range(4):
            self.hands[seat] = sort_hand(self.hands[seat], self.trump)
        self.trick = TrickState(leader_index=self.hakem_seat)
        self.turn_seat = self.hakem_seat

    def legal_moves(self, seat: int) -> List[Card]:
        hand = self.hands[seat]
        if self.trick.lead_suit is None:
            return hand[:]
        follow = [c for c in hand if c[1] == self.trick.lead_suit]
        return follow if follow else hand[:]

    def play_card(self, seat: int, card: Card) -> Optional[str]:
        if seat != self.turn_seat:
            return "نوبت شما نیست."
        if card not in self.hands[seat]:
            return "این کارت در دست شما نیست."
        legal = self.legal_moves(seat)
        if card not in legal:
            return "باید از خال شروع‌شده پیروی کنید."
        self.hands[seat].remove(card)
        self.trick.plays[seat] = card
        if self.trick.lead_suit is None:
            self.trick.lead_suit = card[1]
        self.turn_seat = self.next_seat(seat)
        if len(self.trick.plays) == 4:
            winner = self.determine_trick_winner()
            team = self.teams[winner]
            self.score_hands[team] += 1
            self.trick = TrickState(leader_index=winner)
            self.turn_seat = winner
            if sum(self.score_hands) == 13:
                if self.score_hands[0] > self.score_hands[1]:
                    self.score_sets[0] += 1
                    hand_winner_team = 0
                else:
                    self.score_sets[1] += 1
                    hand_winner_team = 1
                # Next hakim = winner of last trick (simple rule)
                self.hakem_seat = self.trick.leader_index
                self.start_hand()
                return (
                    f"دست تمام شد! تیم {hand_winner_team+1} این دست را برد. "
                    f"امتیاز ست‌ها: {self.score_sets[0]}–{self.score_sets[1]}"
                )
        return None

    def determine_trick_winner(self) -> int:
        lead = self.trick.lead_suit
        plays = self.trick.plays
        assert lead is not None and self.trump is not None
        best_seat = None
        best_card = None
        for seat_order in range(4):
            seat = (self.trick.leader_index + seat_order) % 4
            card = plays[seat]
            if best_card is None:
                best_card, best_seat = card, seat
                continue
            if card[1] == self.trump and best_card[1] != self.trump:
                best_card, best_seat = card, seat
            elif card[1] == self.trump and best_card[1] == self.trump:
                if RANK_VAL[card[0]] > RANK_VAL[best_card[0]]:
                    best_card, best_seat = card, seat
            elif best_card[1] != self.trump:
                if card[1] == lead and best_card[1] == lead:
                    if RANK_VAL[card[0]] > RANK_VAL[best_card[0]]:
                        best_card, best_seat = card, seat
        return best_seat


# ---------- Persistence & Registry ----------
class Registry:
    def __init__(self):
        self.tables: Dict[str, Table] = {}


REGISTRY_KEY = "registry"


def get_registry(context: ContextTypes.DEFAULT_TYPE) -> Registry:
    reg = context.application.bot_data.get(REGISTRY_KEY)
    if not reg:
        reg = Registry()
        context.application.bot_data[REGISTRY_KEY] = reg
    return reg


def gen_id(k=6) -> str:
    import secrets

    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(k))


# ---------- UI Helpers ----------

def table_inline_keyboard(t: Table) -> InlineKeyboardMarkup:
    join_buttons = []
    for i in range(4):
        p = t.players[i]
        label = f"صندلی {i+1} {'✅' if p else '➕'}"
        join_buttons.append(InlineKeyboardButton(label, callback_data=f"join|{t.table_id}|{i}"))
    rows = [join_buttons[0:2], join_buttons[2:4]]
    rows.append([InlineKeyboardButton("شروع بازی ▶️", callback_data=f"start|{t.table_id}")])
    if t.started and t.trump is None and t.hakem_seat is not None:
        rows.append(
            [
                InlineKeyboardButton("♠ حکم", callback_data=f"trump|{t.table_id}|♠"),
                InlineKeyboardButton("♥ حکم", callback_data=f"trump|{t.table_id}|♥"),
                InlineKeyboardButton("♦ حکم", callback_data=f"trump|{t.table_id}|♦"),
                InlineKeyboardButton("♣ حکم", callback_data=f"trump|{t.table_id}|♣"),
            ]
        )
    return InlineKeyboardMarkup(rows)


def table_header(t: Table) -> str:
    names = []
    for i, p in enumerate(t.players):
        names.append(f"{i+1}:{p.name if p else '—'}")
    status = []
    if not t.started:
        status.append("وضعیت: در انتظار شروع")
    elif t.trump is None:
        status.append(f"حاکم: صندلی {(t.hakem_seat or 0)+1} → انتخاب حکم")
    else:
        status.append(f"حکم: {t.trump} | نوبت: صندلی {(t.turn_seat or 0)+1}")
        status.append(f"تریک‌ها: تیم۱ {t.score_hands[0]} - تیم۲ {t.score_hands[1]}")
        status.append(f"ست‌ها: تیم۱ {t.score_sets[0]} - تیم۲ {t.score_sets[1]}")
    return (
        f"🎴 میز حکم «{t.title}»\nبازیکنان: "
        + " | ".join(names)
        + "\n"
        + "\n".join(status)
    )


async def refresh_table_message(context: ContextTypes.DEFAULT_TYPE, t: Table):
    try:
        await context.bot.edit_message_text(
            chat_id=t.chat_id,
            message_id=t.message_id,
            text=table_header(t),
            reply_markup=table_inline_keyboard(t),
        )
    except Exception as e:
        log.warning(f"edit_message failed: {e}")


# ---------- Commands ----------
async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "سلام! من ربات بازی حکم‌ام.\n"
        "در گروه: /table اسم_میز\n"
        "یا اینلاین: @YourBotName ایجاد میز"
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "دستورات:\n"
        "/table [عنوان] — ساخت میز جدید در همین چت\n"
        "اینلاین: @YourBotName ایجاد میز — ساخت میز و دعوت دوستان\n"
        "قوانین: ۴ نفره، تیم‌ها ۲×۲، انتخاب حکم با حاکم، رعایت خال اجباری، امتیاز تریک‌ها و ست‌ها."
    )


async def id_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await update.message.reply_text(f"User ID: {uid}")


async def table_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_chat:
        return
    reg = get_registry(context)
    if len(reg.tables) >= MAX_TABLES:
        await update.message.reply_text("🚫 به سقف میزهای فعال رسیدیم. لطفاً یکی را ببندید و دوباره تلاش کنید.")
        return

    title = " ".join(context.args) if context.args else f"میز {gen_id(4)}"
    table_id = gen_id()
    t = Table(table_id=table_id, chat_id=update.effective_chat.id, message_id=0, title=title)
    reg.tables[table_id] = t
    msg = await update.message.reply_text(table_header(t), reply_markup=table_inline_keyboard(t))
    t.message_id = msg.message_id
    # If group, optionally delete the command message for cleanliness
    try:
        if update.effective_chat.type != "private":
            await update.message.delete()
    except Exception:
        pass


# ---------- Inline Mode ----------
async def inline_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = (update.inline_query.query or "").strip()
    title = query if query else "میز جدید حکم"
    table_id = gen_id()
    content = InputTextMessageContent(f"ایجاد میز حکم: «{title}»\nبرای پیوستن دکمه‌ها را بزنید.")
    keyboard = InlineKeyboardMarkup(
        [[InlineKeyboardButton("ساخت میز و پیوستن", callback_data=f"inline_create|{table_id}|{title}")]]
    )
    results = [
        InlineQueryResultArticle(
            id=table_id,
            title=f"ایجاد میز: {title}",
            description="یک میز جدید بساز و دوستانت را دعوت کن",
            input_message_content=content,
            reply_markup=keyboard,
        )
    ]
    await update.inline_query.answer(results, cache_time=0, is_personal=True)


# ---------- Admin Helpers ----------

def admin_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        uid = update.effective_user.id
        if uid not in ADMINS:
            await update.message.reply_text("🚫 شما ادمین نیستید.")
            return
        return await func(update, context, *args, **kwargs)

    return wrapper


def chunk_text(s: str) -> List[str]:
    if len(s) <= MSG_CHUNK:
        return [s]
    out = []
    i = 0
    while i < len(s):
        out.append(s[i : i + MSG_CHUNK])
        i += MSG_CHUNK
    return out


@admin_only
async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reg = get_registry(context)
    tables = reg.tables
    lines = ["📊 پنل ادمین:", f"تعداد میزهای فعال: {len(tables)}"]
    if not tables:
        lines.append("— هیچ میزی فعال نیست.")
    else:
        lines.append("لیست میزها:")
        for tid, t in tables.items():
            lines.append(
                f" • {tid} | '{t.title}' | chat:{t.chat_id} | msg:{t.message_id} | بازیکنان:{t.seats_filled()}/4"
            )
        lines.append("\nبرای بستن میز: /close <TABLE_ID>")
        lines.append("برای برادکست: /broadcast متن پیام")
    txt = "\n".join(lines)
    for ch in chunk_text(txt):
        await update.message.reply_text(ch)


@admin_only
async def close_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await update.message.reply_text("استفاده: /close <TABLE_ID>")
        return
    tid = args[0]
    reg = get_registry(context)
    t = reg.tables.get(tid)
    if not t:
        await update.message.reply_text("این Table ID یافت نشد.")
        return
    # Try to delete the table message from chat
    try:
        await context.bot.delete_message(chat_id=t.chat_id, message_id=t.message_id)
    except Exception as e:
        log.warning(f"delete table message failed: {e}")
    # Remove from registry
    del reg.tables[tid]
    await update.message.reply_text(f"✅ میز {tid} بسته شد.")


@admin_only
async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Broadcast to all table chats (unique chat IDs)
    msg = " ".join(context.args).strip()
    if not msg:
        await update.message.reply_text("استفاده: /broadcast متن پیام")
        return
    reg = get_registry(context)
    chats = {t.chat_id for t in reg.tables.values()}
    sent, fail = 0, 0
    for cid in chats:
        try:
            await context.bot.send_message(chat_id=cid, text=msg)
            sent += 1
        except Exception:
            fail += 1
    await update.message.reply_text(f"برادکست انجام شد ✅ ارسال‌شده: {sent} | ناموفق: {fail}")


# ---------- Callbacks ----------
async def callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.callback_query:
        return
    q = update.callback_query
    data = q.data or ""
    parts = data.split("|")
    action = parts[0]

    reg = get_registry(context)

    if action == "inline_create":
        table_id, title = parts[1], parts[2]
        chat_id = q.message.chat_id
        if table_id in reg.tables:
            t = reg.tables[table_id]
        else:
            t = Table(table_id=table_id, chat_id=chat_id, message_id=q.message.message_id, title=title)
            reg.tables[table_id] = t
        await q.answer("میز ساخته شد. یک صندلی انتخاب کن.")
        await refresh_table_message(context, t)
        return

    try:
        table_id = parts[1]
    except Exception:
        await q.answer("درخواست نامعتبر.")
        return
    t = reg.tables.get(table_id)
    if not t:
        await q.answer("این میز وجود ندارد یا پاک شده است.", show_alert=True)
        return

    if action == "join":
        seat = int(parts[2])
        user = q.from_user
        prev = t.seat_of(user.id)
        if prev is not None and prev != seat:
            t.players[prev] = None
        if t.players[seat] and t.players[seat].user_id != user.id:
            await q.answer("این صندلی پر است.")
            return
        t.players[seat] = Player(user_id=user.id, name=user.first_name or f"user{user.id}")
        t.ensure_team_mapping()
        await q.answer(f"روی صندلی {seat+1} نشستی.")
        await refresh_table_message(context, t)
        return

    if action == "start":
        if t.started:
            await q.answer("بازی شروع شده.")
            return
        if not t.is_full():
            await q.answer("چهار نفر کامل نیست.", show_alert=True)
            return
        import secrets

        t.hakem_seat = secrets.randbelow(4)
        t.started = True
        t.finished = False
        t.score_hands = [0, 0]
        t.trick = TrickState(leader_index=t.hakem_seat)
        t.start_hand()
        await q.answer("بازی شروع شد! حاکم ۵ کارت گرفت، حکم را انتخاب کند.")
        await refresh_table_message(context, t)
        await send_hand_dm(context, t, t.hakem_seat)
        return

    if action == "trump":
        suit = parts[2]
        if q.from_user.id != (t.players[t.hakem_seat].user_id if t.hakem_seat is not None else -1):
            await q.answer("فقط حاکم می‌تواند حکم را انتخاب کند.", show_alert=True)
            return
        if t.trump:
            await q.answer("حکم قبلاً انتخاب شده.")
            return
        t.set_trump(suit)
        await q.answer(f"حکم شد: {suit}")
        await refresh_table_message(context, t)
        for seat in range(4):
            await send_hand_dm(context, t, seat)
        return

    if action == "play":
        seat = int(parts[2])
        r, s = parts[3].split("_", 1)
        card = (r, s)
        if not t.players[seat] or q.from_user.id != t.players[seat].user_id:
            await q.answer("این دکمه برای شما نیست.", show_alert=True)
            return
        err = t.play_card(seat, card)
        if err:
            await q.answer(err, show_alert=True)
        else:
            await q.answer("بازی شد.")
        await refresh_table_message(context, t)
        for seat2 in range(4):
            await send_hand_dm(context, t, seat2)
        return


# ---------- DM helpers ----------
async def send_hand_dm(context: ContextTypes.DEFAULT_TYPE, t: Table, seat: int):
    player = t.players[seat]
    if not player:
        return
    hand = t.hands.get(seat, [])
    header = f"میز «{t.title}» | صندلی {seat+1}\n"
    if t.trump is None:
        if seat == t.hakem_seat:
            txt = header + "۵ کارت اولیه شما:\n" + hand_to_text(hand)
        else:
            txt = header + "در انتظار انتخاب حکم توسط حاکم…"
        try:
            await context.bot.send_message(chat_id=player.user_id, text=txt)
        except Exception as e:
            log.warning(f"DM fail: {e}")
        return

    legal = []
    if t.turn_seat == seat:
        legal = t.legal_moves(seat)
    keyboard_rows = []
    if legal:
        row = []
        for c in legal:
            label = card_str(c)
            row.append(InlineKeyboardButton(label, callback_data=f"play|{t.table_id}|{seat}|{c[0]}_{c[1]}"))
            if len(row) == 6:
                keyboard_rows.append(row)
                row = []
        if row:
            keyboard_rows.append(row)
    else:
        keyboard_rows = [[InlineKeyboardButton("نوبت شما نیست", callback_data="noop")]]
    kb = InlineKeyboardMarkup(keyboard_rows)

    txt = (
        header
        + (f"حکم: {t.trump} | " if t.trump else "")
        + ("نوبت شماست، یک کارت بازی کنید.\n" if t.turn_seat == seat else "صبر کنید تا نوبت شما شود.\n")
        + "دست شما:\n"
        + hand_to_text(hand)
    )
    try:
        await context.bot.send_message(chat_id=player.user_id, text=txt, reply_markup=kb)
    except Exception as e:
        log.warning(f"DM fail: {e}")


# ---------- App ----------

def build_app() -> Application:
    persistence = PicklePersistence(filepath=STATE_FILE)
    app = ApplicationBuilder().token(BOT_TOKEN).persistence(persistence).build()

    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("id", id_cmd))
    app.add_handler(CommandHandler("table", table_cmd))

    # Admin
    app.add_handler(CommandHandler("admin", admin_cmd))
    app.add_handler(CommandHandler("close", close_cmd))
    app.add_handler(CommandHandler("broadcast", broadcast_cmd))

    # Inline + Callbacks
    app.add_handler(InlineQueryHandler(inline_query))
    app.add_handler(CallbackQueryHandler(callback_query))

    # Unknown commands fallback
    app.add_handler(MessageHandler(filters.COMMAND, help_cmd))

    async def post_init(app: Application):
        if REGISTRY_KEY not in app.bot_data:
            app.bot_data[REGISTRY_KEY] = Registry()
        log.info("Bot is up. Ready.")

    app.post_init = post_init
    return app


if __name__ == "__main__":
    application = build_app()
    log.info("Hokm bot is running…")
    application.run_polling(
        allowed_updates=["message", "callback_query", "inline_query", "chosen_inline_result"]
    )