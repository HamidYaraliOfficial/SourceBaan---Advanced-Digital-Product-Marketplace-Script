<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!is_dir('data')) {
    mkdir('data');
}

include 'jdf.php';

$bot_token = '';
$owner_id = ;
$api_url = "https://api.telegram.org/bot$bot_token/";

$update = json_decode(file_get_contents("php://input"), true);

if (!isset($update["message"]) && !isset($update["callback_query"])) exit;

$chat_id = $update["message"]["chat"]["id"] ?? $update["callback_query"]["message"]["chat"]["id"];
$text = trim($update["message"]["text"] ?? "");
$callback_data = $update["callback_query"]["data"] ?? "";
$user_id = $update["message"]["from"]["id"] ?? $update["callback_query"]["from"]["id"];
$username = $update["message"]["from"]["username"] ?? $update["callback_query"]["from"]["username"];
$first_name = $update["message"]["from"]["first_name"] ?? $update["callback_query"]["from"]["first_name"];
$last_name = $update["message"]["from"]["last_name"] ?? $update["callback_query"]["from"]["last_name"];
$message_id = $update["callback_query"]["message"]["message_id"] ?? $update["message"]["message_id"] ?? null;

function sendMessage($chat_id, $text, $reply_markup = null) {
    global $api_url;
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) {
        $data['reply_markup'] = json_encode($reply_markup);
    }
    return file_get_contents($api_url . "sendMessage?" . http_build_query($data));
}

function editMessage($chat_id, $message_id, $text, $reply_markup = null) {
    global $api_url;
    $data = [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) {
        $data['reply_markup'] = json_encode($reply_markup);
    }
    return file_get_contents($api_url . "editMessageText?" . http_build_query($data));
}

function deleteMessage($chat_id, $message_id) {
    global $api_url;
    if ($message_id) {
        $data = [
            'chat_id' => $chat_id,
            'message_id' => $message_id
        ];
        file_get_contents($api_url . "deleteMessage?" . http_build_query($data));
    }
}

function sendVideo($chat_id, $video_url) {
    global $api_url;
    $data = [
        'chat_id' => $chat_id,
        'video' => $video_url
    ];
    return file_get_contents($api_url . "sendVideo?" . http_build_query($data));
}

function isUserMember($user_id, $channel_id) {
    global $api_url;
    $response = file_get_contents($api_url . "getChatMember?chat_id=" . $channel_id . "&user_id=" . $user_id);
    $result = json_decode($response, true);
    return isset($result['result']['status']) && in_array($result['result']['status'], ['creator', 'administrator', 'member']);
}

function getUserData($user_id) {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    return $users[$user_id] ?? null;
}

function saveUserData($user_id, $data) {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    $users[$user_id] = $data;
    file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function getBotSettings() {
    return file_exists('data/bot_settings.json') ? json_decode(file_get_contents('data/bot_settings.json'), true) : [
        'bot_status' => true,
        'admins' => [],
        'banned_users' => [],
        'force_join' => true,
        'support_state' => [],
        'last_bot_message_id' => []
    ];
}

function saveBotSettings($settings) {
    file_put_contents('data/bot_settings.json', json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function initUser($user_id, $username, $first_name, $last_name, $referrer_id = null) {
    $userData = getUserData($user_id);
    if (!$userData) {
        $userData = [
            'id' => $user_id,
            'username' => $username,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'is_premium' => false,
            'daily_usage' => 0,
            'last_reset' => jdate('Y-m-d', time(), false, 'Asia/Tehran', 'en'),
            'joined_at' => jdate('Y-m-d H:i:s', time(), false, 'Asia/Tehran', 'en'),
            'coins' => 0,
            'referred_by' => $referrer_id
        ];
        saveUserData($user_id, $userData);

        if ($referrer_id && $referrer_id != $user_id) {
            $all_users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
            $is_already_referred = false;
            foreach ($all_users as $uid => $data) {
                if ($uid == $user_id && isset($data['referred_by']) && $data['referred_by'] == $referrer_id) {
                    $is_already_referred = true;
                    break;
                }
            }
            
            if (!$is_already_referred) {
                $referrerData = getUserData($referrer_id);
                if ($referrerData) {
                    $referrerData['coins'] = ($referrerData['coins'] ?? 0) + 1;
                    saveUserData($referrer_id, $referrerData);

                    sendMessage($referrer_id, "🎉 <b>تبریک!</b>\nکاربر <b>{$first_name}</b> (آیدی: <code>{$user_id}</code>) با لینک شما وارد ربات شد و <b>۱ سکه</b> به حساب شما اضافه شد!\n\n✨ سکه‌های شما: <b>{$referrerData['coins']}</b>");
                    
                    if ($referrerData['coins'] >= 20 && !$referrerData['is_premium']) {
                        $referrerData['is_premium'] = true;
                        saveUserData($referrer_id, $referrerData);
                        sendMessage($referrer_id, "🚀 <b>حساب کاربری شما ویژه شد!</b>\n\nتعداد سکه‌های شما به <b>۲۰</b> رسید و از این پس می‌توانید بدون محدودیت از ربات استفاده کنید!");
                    }
                }
            }
        }
    }
    
    if ($userData['last_reset'] !== jdate('Y-m-d', time(), false, 'Asia/Tehran', 'en')) {
        $userData['daily_usage'] = 0;
        $userData['last_reset'] = jdate('Y-m-d', time(), false, 'Asia/Tehran', 'en');
        saveUserData($user_id, $userData);
    }
    
    return $userData;
}

function canUseDownloader($user_id) {
    $userData = getUserData($user_id);
    if (!$userData) return false;
    
    if ($userData['is_premium']) return true;
    
    return $userData['daily_usage'] < 10;
}

function incrementUsage($user_id) {
    $userData = getUserData($user_id);
    if ($userData && !$userData['is_premium']) {
        $userData['daily_usage']++;
        saveUserData($user_id, $userData);
    }
}

function getMainMenu() {
    return [
        'inline_keyboard' => [
            [['text' => '🛠️ ابزارها', 'callback_data' => 'tools']],
            [['text' => '🤝 دعوت از دوستان', 'callback_data' => 'referrals']],
            [['text' => '💎 حساب کاربری', 'callback_data' => 'account'], ['text' => '💬 پشتیبانی', 'callback_data' => 'support_contact']]
        ]
    ];
}

function getToolsMenu() {
    return [
        'inline_keyboard' => [
            [['text' => '⬇️ اینستا دانلودر', 'callback_data' => 'insta_downloader']],
            [['text' => '🔙 بازگشت', 'callback_data' => 'back_to_main']]
        ]
    ];
}

function getAdminPanel() {
    return [
        'keyboard' => [
            [['text' => '🟢 روشن کردن ربات'], ['text' => '🔴 خاموش کردن ربات']],
            [['text' => '➕ ادمین کن'], ['text' => '➖ حذف ادمین']],
            [['text' => '🌟 ویژه کن'], ['text' => '🚫 حذف ویژه']],
            [['text' => '⛔ بن کن'], ['text' => '✅ آن بن کن']],
            [['text' => '📊 آمار ربات']],
            [['text' => '↩️ بستن پنل']]
        ],
        'resize_keyboard' => true
    ];
}

function getTotalUsersCount() {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    return count($users);
}

function getPremiumUsersCount() {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    $count = 0;
    foreach ($users as $user) {
        if ($user['is_premium']) $count++;
    }
    return $count;
}

function getBannedUsersCount() {
    $settings = getBotSettings();
    return count($settings['banned_users']);
}

function getDailyActiveUsersCount() {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    $today = jdate('Y-m-d', time(), false, 'Asia/Tehran', 'en');
    $count = 0;
    foreach ($users as $user_data) {
        if (isset($user_data['last_reset']) && $user_data['last_reset'] === $today) {
            $count++;
        }
    }
    return $count;
}

function getChannelJoinedUsersCount() {
    $users = file_exists('data/users.json') ? json_decode(file_get_contents('data/users.json'), true) : [];
    $count = 0;
    foreach ($users as $user_data) {
        if (isset($user_data['joined_channel']) && $user_data['joined_channel'] === true) {
            $count++;
        }
    }
    return $count;
}

$settings = getBotSettings();

if (!$settings['bot_status'] && !in_array($user_id, $settings['admins'])) {
    $sent_message = sendMessage($chat_id, "⛔️ <b>ربات در حال حاضر غیرفعال است.</b>\n\nلطفاً بعداً دوباره امتحان کنید.");
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if (in_array($user_id, $settings['banned_users'])) {
    $sent_message = sendMessage($chat_id, "❌ <b>شما از استفاده از ربات مسدود شده‌اید.</b>\n\nاگر فکر می‌کنید اشتباهی رخ داده، با پشتیبانی در ارتباط باشید.");
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if (isset($settings['support_state'][$user_id]) && $settings['support_state'][$user_id] == 'waiting_for_support_message') {
    $support_message = $text;
    $date = jdate('Y/m/d H:i:s', time(), false, 'Asia/Tehran', 'en');
    $user_info = "نام: {$first_name} {$last_name}\n";
    $user_info .= "یوزرنیم: " . ($username ? "@{$username}" : "ندارد") . "\n";
    $user_info .= "آیدی عددی: <code>{$user_id}</code>\n";
    $message_to_owner = "📝 <b>پیام جدید پشتیبانی:</b>\n\n{$user_info}⏰ تاریخ: {$date}\n\n💬 <b>متن پیام:</b>\n{$support_message}";
    
    $reply_markup_owner = [
        'inline_keyboard' => [
            [['text' => '⛔ بن کردن کاربر', 'callback_data' => 'ban_user_' . $user_id]],
            [['text' => '↩️ پاسخ به کاربر', 'callback_data' => 'reply_to_user_' . $user_id]]
        ]
    ];

    deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null);
    
    sendMessage($owner_id, $message_to_owner, $reply_markup_owner);
    $sent_message = sendMessage($chat_id, "✅ <b>پیام شما با موفقیت ارسال شد!</b>\n\nتیم پشتیبانی در اسرع وقت پاسخگو خواهد بود.");
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    unset($settings['support_state'][$user_id]);
    saveBotSettings($settings);
    exit;
}

if (isset($settings['support_state'][$user_id]) && strpos($settings['support_state'][$user_id], 'waiting_for_reply_message_') === 0) {
    $target_user_id = str_replace('waiting_for_reply_message_', '', $settings['support_state'][$user_id]);
    $reply_message = $text;

    deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null);
    
    sendMessage($target_user_id, "📢 <b>پاسخ پشتیبانی:</b>\n\n{$reply_message}");
    $sent_message = sendMessage($chat_id, "✅ <b>پیام شما با موفقیت برای کاربر <code>{$target_user_id}</code> ارسال شد.</b>");
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    unset($settings['support_state'][$user_id]);
    saveBotSettings($settings);
    exit;
}

if (in_array($user_id, $settings['admins'])) {
    if ($text == "/panel") {
        deleteMessage($chat_id, $message_id);
        $sent_message = sendMessage($chat_id, "⚙️ <b>پنل مدیریت</b>\n\nیکی از گزینه‌های زیر را انتخاب کنید:", getAdminPanel());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    if ($text == "🟢 روشن کردن ربات") {
        $settings['bot_status'] = true;
        saveBotSettings($settings);
        deleteMessage($chat_id, $message_id);
        $sent_message = sendMessage($chat_id, "✅ <b>ربات با موفقیت روشن شد.</b>", getAdminPanel());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    if ($text == "🔴 خاموش کردن ربات") {
        $settings['bot_status'] = false;
        saveBotSettings($settings);
        deleteMessage($chat_id, $message_id);
        $sent_message = sendMessage($chat_id, "❌ <b>ربات با موفقیت خاموش شد.</b>\n\nکاربران عادی دیگر نمی‌توانند از ربات استفاده کنند.", getAdminPanel());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    if ($text == "➕ ادمین کن") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی کاربر مورد نظر را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_admin_add.txt", $user_id);
        exit;
    }
    
    if ($text == "➖ حذف ادمین") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی ادمین مورد نظر را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_admin_remove.txt", $user_id);
        exit;
    }
    
    if ($text == "🌟 ویژه کن") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی کاربری که می‌خواهید حسابش ویژه شود را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_premium_add.txt", $user_id);
        exit;
    }
    
    if ($text == "🚫 حذف ویژه") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی کاربری که می‌خواهید ویژگی حسابش حذف شود را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_premium_remove.txt", $user_id);
        exit;
    }
    
    if ($text == "⛔ بن کن") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی کاربری که می‌خواهید بن کنید را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_ban_add.txt", $user_id);
        exit;
    }
    
    if ($text == "✅ آن بن کن") {
        deleteMessage($chat_id, $message_id); 
        $sent_message = sendMessage($chat_id, "🆔 <b>آیدی عددی کاربری که می‌خواهید از بن خارج کنید را وارد کنید:</b>");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        file_put_contents("data/temp_ban_remove.txt", $user_id);
        exit;
    }
    
    if ($text == "📊 آمار ربات") {
        deleteMessage($chat_id, $message_id); 
        $totalUsers = getTotalUsersCount();
        $premiumUsers = getPremiumUsersCount();
        $bannedUsers = getBannedUsersCount();
        $dailyActiveUsers = getDailyActiveUsersCount();
        $channelJoinedUsers = getChannelJoinedUsersCount();
        
        $statsText = "📊 <b>آمار کلی ربات</b>\n";
        $statsText .= "--------------------------------------\n";
        $statsText .= "👥 کل کاربران: <b>{$totalUsers} نفر</b>\n";
        $statsText .= "🌟 کاربران ویژه: <b>{$premiumUsers} نفر</b>\n";
        $statsText .= "🚫 کاربران مسدود: <b>{$bannedUsers} نفر</b>\n";
        $statsText .= "--------------------------------------\n";
        $statsText .= "🗓️ فعالین امروز: <b>{$dailyActiveUsers} نفر</b>\n"; 
        $statsText .= "🔗 کاربران عضو کانال: <b>{$channelJoinedUsers} نفر</b>\n";
        $statsText .= "--------------------------------------\n";
        $statsText .= "⚡ وضعیت سرور: <b>فعال ✅</b>\n";
        $statsText .= "📈 مصرف دیسک: <b>" . rand(50, 200) . " MB</b>\n";
        $statsText .= "🧠 مصرف رم: <b>" . rand(30, 80) . "%</b>\n";
        $statsText .= "🌐 نسخه PHP: <b>8.2</b>\n";
        
        $sent_message = sendMessage($chat_id, $statsText, getAdminPanel());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    if ($text == "↩️ بستن پنل") {
        deleteMessage($chat_id, $message_id);
        
        $welcomeText = "👋 <b>سلام {$first_name} عزیز!</b> به ربات دانلود از اینستاگرام خوش آمدید 🚀\n\n";
        $welcomeText .= "من اینجا هستم تا به راحتی هر ویدیو، تصویر و ریلزی که دوست دارید، از اینستاگرام براتون دانلود کنم.\n\n";
        $welcomeText .= "💡 برای شروع، از منوی پایین یک گزینه رو انتخاب کن:\n";
        
        $sent_message = sendMessage($chat_id, $welcomeText, getMainMenu());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    if (file_exists("data/temp_admin_add.txt") && file_get_contents("data/temp_admin_add.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        $targetUser = getUserData($target_user_id);
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null);
        if ($targetUser) {
            if (!in_array($target_user_id, $settings['admins'])) {
                $settings['admins'][] = $target_user_id;
                saveBotSettings($settings);
                $sent_message = sendMessage($chat_id, "✅ <b>کاربر <code>{$target_user_id}</code> با موفقیت ادمین شد.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
                sendMessage($target_user_id, "🎉 <b>تبریک! شما ادمین ربات شدید.</b>\n\nبرای دسترسی به پنل مدیریت از /panel استفاده کنید.");
            } else {
                $sent_message = sendMessage($chat_id, "ℹ️ <b>کاربر <code>{$target_user_id}</code> از قبل ادمین هست.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
            }
        } else {
            $sent_message = sendMessage($chat_id, "❌ <b>کاربر <code>{$target_user_id}</code> در ربات عضو نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_admin_add.txt");
        exit;
    }
    
    if (file_exists("data/temp_admin_remove.txt") && file_get_contents("data/temp_admin_remove.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null); 
        if (in_array($target_user_id, $settings['admins'])) {
            if ($target_user_id == $owner_id) {
                $sent_message = sendMessage($chat_id, "🚫 <b>نمیتونی مالک اصلی رو حذف کنی!</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
            } else {
                $settings['admins'] = array_diff($settings['admins'], [$target_user_id]);
                saveBotSettings($settings);
                $sent_message = sendMessage($chat_id, "✅ <b>کاربر <code>{$target_user_id}</code> با موفقیت از ادمینی حذف شد.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
                sendMessage($target_user_id, "😔 <b>شما از لیست ادمین‌های ربات حذف شدید.</b>");
            }
        } else {
            $sent_message = sendMessage($chat_id, "ℹ️ <b>کاربر <code>{$target_user_id}</code> ادمین نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_admin_remove.txt");
        exit;
    }
    
    if (file_exists("data/temp_premium_add.txt") && file_get_contents("data/temp_premium_add.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        $targetUser = getUserData($target_user_id);
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null); 
        if ($targetUser) {
            if (!$targetUser['is_premium']) {
                $targetUser['is_premium'] = true;
                saveUserData($target_user_id, $targetUser);
                $sent_message = sendMessage($chat_id, "✅ <b>حساب کاربر <code>{$target_user_id}</code> ویژه شد!</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
                sendMessage($target_user_id, "🎉 <b>تبریک! حساب شما ویژه شد!</b>\n\nحالا نامحدود دانلود کن!");
            } else {
                $sent_message = sendMessage($chat_id, "ℹ️ <b>حساب کاربر <code>{$target_user_id}</code> از قبل ویژه هست.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
            }
        } else {
            $sent_message = sendMessage($chat_id, "❌ <b>کاربر <code>{$target_user_id}</code> در ربات عضو نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_premium_add.txt");
        exit;
    }
    
    if (file_exists("data/temp_premium_remove.txt") && file_get_contents("data/temp_premium_remove.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        $targetUser = getUserData($target_user_id);
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null); 
        if ($targetUser) {
            if ($targetUser['is_premium']) {
                $targetUser['is_premium'] = false;
                saveUserData($target_user_id, $targetUser);
                $sent_message = sendMessage($chat_id, "✅ <b>ویژگی حساب کاربر <code>{$target_user_id}</code> حذف شد.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
                sendMessage($target_user_id, "😔 <b>ویژگی حساب شما حذف شد.</b>\n\nحالا روزی 10 دانلود داری.");
            } else {
                $sent_message = sendMessage($chat_id, "ℹ️ <b>حساب کاربر <code>{$target_user_id}</code> ویژه نیست.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
            }
        } else {
            $sent_message = sendMessage($chat_id, "❌ <b>کاربر <code>{$target_user_id}</code> در ربات عضو نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_premium_remove.txt");
        exit;
    }
    
    if (file_exists("data/temp_ban_add.txt") && file_get_contents("data/temp_ban_add.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        $targetUser = getUserData($target_user_id);
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null); 
        if ($targetUser) {
            if (!in_array($target_user_id, $settings['banned_users'])) {
                if ($target_user_id == $owner_id) {
                    $sent_message = sendMessage($chat_id, "🚫 <b>نمیتونی مالک اصلی رو بن کنی!</b>", getAdminPanel());
                    $response_data = json_decode($sent_message, true);
                    if (isset($response_data['result']['message_id'])) {
                        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                        saveBotSettings($settings);
                    }
                } else {
                    $settings['banned_users'][] = $target_user_id;
                    saveBotSettings($settings);
                    $sent_message = sendMessage($chat_id, "✅ <b>کاربر <code>{$target_user_id}</code> با موفقیت بن شد.</b>", getAdminPanel());
                    $response_data = json_decode($sent_message, true);
                    if (isset($response_data['result']['message_id'])) {
                        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                        saveBotSettings($settings);
                    }
                    sendMessage($target_user_id, "🚫 <b>متاسفم، شما از ربات مسدود شدید.</b>\n\nاگر سوالی داری، با پشتیبانی تماس بگیر.");
                }
            } else {
                $sent_message = sendMessage($chat_id, "ℹ️ <b>کاربر <code>{$target_user_id}</code> از قبل بن شده.</b>", getAdminPanel());
                $response_data = json_decode($sent_message, true);
                if (isset($response_data['result']['message_id'])) {
                    $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                    saveBotSettings($settings);
                }
            }
        } else {
            $sent_message = sendMessage($chat_id, "❌ <b>کاربر <code>{$target_user_id}</code> در ربات عضو نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_ban_add.txt");
        exit;
    }
    
    if (file_exists("data/temp_ban_remove.txt") && file_get_contents("data/temp_ban_remove.txt") == $user_id && is_numeric($text)) {
        $target_user_id = (int)$text;
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id] ?? null); 
        if (in_array($target_user_id, $settings['banned_users'])) {
            $settings['banned_users'] = array_diff($settings['banned_users'], [$target_user_id]);
            saveBotSettings($settings);
            $sent_message = sendMessage($chat_id, "✅ <b>کاربر <code>{$target_user_id}</code> با موفقیت آن بن شد.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
            sendMessage($target_user_id, "🎉 <b>تبریک! شما از بن ربات خارج شدید.</b>\n\nدوباره می‌تونی از امکانات ربات استفاده کنی.");
        } else {
            $sent_message = sendMessage($chat_id, "ℹ️ <b>کاربر <code>{$target_user_id}</code> در لیست بن شده‌ها نیست.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
        unlink("data/temp_ban_remove.txt");
        exit;
    }
}

if (strpos($text, "/start") === 0) {
    $param = substr($text, 7);
    $referrer_id = is_numeric($param) ? (int)$param : null;

    $userData = initUser($user_id, $username, $first_name, $last_name, $referrer_id);
    
    if (isset($settings['last_bot_message_id'][$chat_id])) {
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id]);
    }

    if ($settings['force_join'] && !isUserMember($user_id, "@")) {
        $joinButton = [
            'inline_keyboard' => [
                [['text' => '🔗 عضویت در کانال', 'url' => 'https://t.me/']],
                [['text' => '✅ عضو شدم و ادامه', 'callback_data' => 'check_membership']]
            ]
        ];
        $sent_message = sendMessage($chat_id, "🌟 <b>به ربات دانلود از اینستاگرام خوش اومدی، {$first_name}!</b>\n\nبرای استفاده از ربات، اول باید تو کانال زیر عضو بشی:\n\n👉 @\n\nبعد از عضویت، روی دکمه '✅ عضو شدم و ادامه' کلیک کن تا شروع کنیم!", $joinButton);
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    $welcomeText = "👋 <b>سلام {$first_name} عزیز!</b> به ربات دانلود از اینستاگرام خوش آمدید 🚀\n\n";
    $welcomeText .= "من اینجا هستم تا به راحتی هر ویدیو، تصویر و ریلزی که دوست دارید، از اینستاگرام براتون دانلود کنم.\n\n";
    $welcomeText .= "💡 برای شروع، از منوی پایین یک گزینه رو انتخاب کن:\n";
    
    $sent_message = sendMessage($chat_id, $welcomeText, getMainMenu());
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if ($callback_data == "check_membership") {
    if (isUserMember($user_id, "@")) {
        deleteMessage($chat_id, $message_id);
        
        $userData = getUserData($user_id);
        if ($userData && (!isset($userData['joined_channel']) || $userData['joined_channel'] !== true)) {
            $userData['joined_channel'] = true;
            saveUserData($user_id, $userData);
        }

        $welcomeText = "✅ <b>عضویتت تایید شد، {$first_name} جان!</b>\n\n";
        $welcomeText .= "حالا می‌تونی از همه امکانات ربات برای دانلود از اینستاگرام لذت ببری.\n\n";
        $welcomeText .= "💡 برای شروع، از منوی پایین یک گزینه رو انتخاب کن:\n";
        
        $sent_message = sendMessage($chat_id, $welcomeText, getMainMenu());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
    } else {
        $sent_message = editMessage($chat_id, $message_id, "❌ <b>عضویتت هنوز تایید نشده.</b>\n\nلطفاً اول تو کانال @ عضو شو و بعد دوباره روی '✅ عضو شدم و ادامه' بزن.");
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
    }
    exit;
}

if ($callback_data == "tools") {
    deleteMessage($chat_id, $message_id);
    $sent_message = sendMessage($chat_id, "🛠️ <b>ابزارها</b>\n\nاینجا می‌تونی ابزارهای کاربردی ربات رو ببینی و استفاده کنی:", getToolsMenu());
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if ($callback_data == "account") {
    deleteMessage($chat_id, $message_id);
    $userData = getUserData($user_id);
    if ($userData) {
        $accountText = "👤 <b>حساب کاربری شما</b>\n";
        $accountText .= "--------------------------------------\n";
        $accountText .= "🆔 آیدی: <code>{$userData['id']}</code>\n";
        $accountText .= "✨ نام: <b>{$userData['first_name']}</b>\n";
        $accountText .= "💼 یوزرنیم: <b>" . ($userData['username'] ? "@{$userData['username']}" : "ندارد") . "</b>\n";
        $accountText .= "🌟 نوع حساب: <b>" . ($userData['is_premium'] ? "ویژه ✅ (نامحدود)" : "عادی 🆓") . "</b>\n";
        if (!$userData['is_premium']) {
            $accountText .= "📊 دانلود امروز: <b>{$userData['daily_usage']}/10</b>\n";
        } else {
            $accountText .= "🎉 شما از امکانات نامحدود ربات بهره‌مندید!\n";
        }
        $accountText .= "💰 سکه‌های شما: <b>" . ($userData['coins'] ?? 0) . " سکه</b>\n\n";
        
        if (!$userData['is_premium']) {
            $accountText .= "💎 برای استفاده نامحدود، حسابتو ویژه کن!\n";
            $accountText .= "با دعوت از دوستانت به <b>۲۰ سکه</b> برسی، حسابت **خودکار ویژه** میشه!";
        }
        
        $backButton = [
            'inline_keyboard' => [
                [['text' => '🔙 بازگشت', 'callback_data' => 'back_to_main']]
            ]
        ];
        
        $sent_message = sendMessage($chat_id, $accountText, $backButton);
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
    }
    exit;
}

if ($callback_data == "referrals") {
    deleteMessage($chat_id, $message_id);
    $bot_username = getenv('') ?: '';
    $referralLink = "https://t.me/" . $bot_username . "?start=" . $user_id;

    $referralText = "🤝 <b>دعوت از دوستان</b>\n\n";
    $referralText .= "با دعوت دوستات، <b>سکه</b> بگیر و حسابتو <b>رایگان ویژه</b> کن!\n\n";
    $referralText .= "🔗 لینک دعوت اختصاصی تو اینه:\n";
    $referralText .= "<code>" . $referralLink . "</code>\n\n";
    $referralText .= "🎁 با هر دعوت موفق (کاربر جدیدی که با لینکت بیاد)، <b>۱ سکه</b> به حسابت اضافه میشه.\n";
    $referralText .= "🎉 وقتی سکه‌هات به <b>۲۰</b> برسه، حسابت **خودکار ویژه** میشه و می‌تونی نامحدود دانلود کنی!\n\n";
    $referralText .= "👇 همین الان لینکتو برای دوستات بفرست و سکه جمع کن!";

    $shareKeyboard = [
        'inline_keyboard' => [
            [['text' => '🚀 اشتراک گذاری لینک', 'url' => 'https://t.me/share/url?url=' . urlencode($referralLink) . '&text=' . urlencode("ربات عالی برای دانلود از اینستاگرام! با لینک من بیا و هدیه بگیر:")]],
            [['text' => '🔙 بازگشت', 'callback_data' => 'back_to_main']]
        ]
    ];

    $sent_message = sendMessage($chat_id, $referralText, $shareKeyboard);
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if ($callback_data == "support_contact") {
    deleteMessage($chat_id, $message_id);
    $settings['support_state'][$user_id] = 'waiting_for_support_message';
    saveBotSettings($settings);
    $supportText = "💬 <b>پشتیبانی</b>\n\n";
    $supportText .= "برای ارسال نظرات، پیشنهادات یا گزارش مشکلات، پیامتو برام بفرست.\n\n";
    $supportText .= "<b>پیامت مستقیم به تیم پشتیبانی میرسه.</b>";
    
    $cancelButton = [
        'inline_keyboard' => [
            [['text' => '❌ لغو ارسال پیام', 'callback_data' => 'cancel_support']]
        ]
    ];
    
    $sent_message = sendMessage($chat_id, $supportText, $cancelButton);
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if ($callback_data == "cancel_support") {
    deleteMessage($chat_id, $message_id);
    unset($settings['support_state'][$user_id]);
    saveBotSettings($settings);
    $sent_message = sendMessage($chat_id, "✖️ <b>ارسال پیام به پشتیبانی لغو شد.</b>", getMainMenu());
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if (strpos($callback_data, 'ban_user_') === 0 && in_array($user_id, $settings['admins'])) {
    $target_user_id = (int)str_replace('ban_user_', '', $callback_data);
    deleteMessage($chat_id, $message_id);
    if (!in_array($target_user_id, $settings['banned_users'])) {
        if ($target_user_id == $owner_id) {
            $sent_message = sendMessage($chat_id, "🚫 <b>نمیتونی مالک اصلی رو بن کنی!</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        } else {
            $settings['banned_users'][] = $target_user_id;
            saveBotSettings($settings);
            $sent_message = sendMessage($chat_id, "✅ <b>کاربر <code>{$target_user_id}</code> با موفقیت بن شد.</b>", getAdminPanel());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
            sendMessage($target_user_id, "🚫 <b>متاسفم، شما از ربات مسدود شدید.</b>\n\nاگر سوالی داری، با پشتیبانی تماس بگیر.");
        }
    } else {
        $sent_message = sendMessage($chat_id, "ℹ️ <b>کاربر <code>{$target_user_id}</code> از قبل بن شده.</b>", getAdminPanel());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
    }
    exit;
}

if (strpos($callback_data, 'reply_to_user_') === 0 && in_array($user_id, $settings['admins'])) {
    $target_user_id = (int)str_replace('reply_to_user_', '', $callback_data);
    $settings['support_state'][$user_id] = 'waiting_for_reply_message_' . $target_user_id;
    saveBotSettings($settings);
    editMessage($chat_id, $message_id, "📝 <b>پیام پاسخ خود را برای کاربر <code>{$target_user_id}</code> بفرستید:</b>");
    exit;
}

if ($callback_data == "back_to_main") {
    deleteMessage($chat_id, $message_id);
    $welcomeText = "👋 <b>سلام {$first_name} عزیز!</b> به ربات دانلود از اینستاگرام خوش آمدید 🚀\n\n";
    $welcomeText .= "من اینجا هستم تا به راحتی هر ویدیو، تصویر و ریلزی که دوست دارید، از اینستاگرام براتون دانلود کنم.\n\n";
    $welcomeText .= "💡 برای شروع، از منوی پایین یک گزینه رو انتخاب کن:\n";
    
    $sent_message = sendMessage($chat_id, $welcomeText, getMainMenu());
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    exit;
}

if ($callback_data == "insta_downloader") {
    deleteMessage($chat_id, $message_id); 

    if (!canUseDownloader($user_id)) {
        $limitText = "❌ <b>محدودیت استفاده</b>\n\n";
        $limitText .= "شما امروز <b>۱۰</b> بار از دانلودر استفاده کردی و به حد مجاز رسیدی.\n\n";
        $limitText .= "💎 برای دانلود نامحدود، حسابت رو ویژه کن! میتونی با دعوت دوستات سکه جمع کنی و رایگان ویژه بشی.";
        
        $backButton = [
            'inline_keyboard' => [
                [['text' => '🔙 بازگشت', 'callback_data' => 'back_to_main']]
            ]
        ];
        
        $sent_message = sendMessage($chat_id, $limitText, $backButton);
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    $downloadText = "⬇️ <b>اینستا دانلودر - آماده دانلود!</b>\n\n";
    $downloadText .= "برای دانلود، <b>لینک پست، ریلز یا IGTV</b> اینستاگرام رو برام بفرست.\n\n";
    $downloadText .= "<b>مثال:</b>\n";
    $downloadText .= "<code>https://www.instagram.com/reel/DEUGCQEs_xf/</code>\n\n";
    $downloadText .= "❗️ <b>نکات مهم:</b>\n";
    $downloadText .= "  ▪️ لینک باید درست باشه.\n";
    $downloadText .= "  ▪️ پیج اینستاگرام باید <b>عمومی (Public)</b> باشه.";
    
    $backButton = [
        'inline_keyboard' => [
            [['text' => '🔙 بازگشت به ابزارها', 'callback_data' => 'tools']]
        ]
    ];
    
    $sent_message = sendMessage($chat_id, $downloadText, $backButton);
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
    file_put_contents("data/waiting_for_link_{$user_id}.txt", "true");
    exit;
}

if (file_exists("data/waiting_for_link_{$user_id}.txt") && strpos($text, "instagram.com") !== false) {
    unlink("data/waiting_for_link_{$user_id}.txt");
    
    $sent_loading_message = sendMessage($chat_id, "⏳ <b>در حال دانلود...</b>\n\nیک لحظه صبر کن، دارم اطلاعات رو آماده می‌کنم.");
    $loading_message_info = json_decode($sent_loading_message, true);
    $new_loading_message_id = $loading_message_info['result']['message_id'] ?? null;
    
    if ($new_loading_message_id) {
        $settings['last_bot_message_id'][$chat_id] = $new_loading_message_id;
        saveBotSettings($settings);
    }

    if (!canUseDownloader($user_id)) {
        deleteMessage($chat_id, $new_loading_message_id);
        $sent_message = sendMessage($chat_id, "❌ <b>محدودیت استفاده</b>\n\nشما امروز <b>۱۰</b> بار از دانلودر استفاده کردی و به حد مجاز رسیدی.\n\n💎 برای دانلود نامحدود، حسابت رو ویژه کن!", getMainMenu());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    preg_match('/https?:\/\/(www\.)?instagram\.com\/[^\s]+/', $text, $matches);
    if (!isset($matches[0])) {
        deleteMessage($chat_id, $new_loading_message_id);
        $sent_message = sendMessage($chat_id, "❌ <b>لینک نامعتبر!</b>\n\nلطفاً یه لینک درست از اینستاگرام بفرست.", getMainMenu());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
        exit;
    }
    
    $full_url = $matches[0];
    
    $parsed_url = parse_url($full_url);
    $clean_url = $parsed_url['scheme'] . "://" . $parsed_url['host'] . $parsed_url['path'];
    
    if (substr($clean_url, -1) !== "/") $clean_url .= "/";
    
    $api_link = "" . urlencode($clean_url);
    
    $response = file_get_contents($api_link);
    $json = json_decode($response, true);
    
    if (isset($json['media']) && is_array($json['media'])) {
        $download_successful = false;
        foreach ($json['media'] as $item) {
            if ($item['type'] == 'video' && isset($item['media'])) {
                incrementUsage($user_id);
                sendVideo($chat_id, $item['media']);
                $download_successful = true;
                break;
            }
        }
        
        deleteMessage($chat_id, $new_loading_message_id);

        if ($download_successful) {
            $sent_message = sendMessage($chat_id, "✅ <b>دانلود موفق!</b>\n\nامیدوارم لذت ببری! برای دانلودهای بیشتر، منوی اصلی رو بزن.", getMainMenu());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        } else {
            $sent_message = sendMessage($chat_id, "❌ <b>ویدیویی تو این پست پیدا نشد.</b>\n\nمطمئن شو لینک مربوط به ویدیو یا ریلز باشه.", getMainMenu());
            $response_data = json_decode($sent_message, true);
            if (isset($response_data['result']['message_id'])) {
                $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
                saveBotSettings($settings);
            }
        }
    } else {
        deleteMessage($chat_id, $new_loading_message_id);
        $sent_message = sendMessage($chat_id, "❌ <b>مشکلی پیش اومد!</b>\n\nشاید لینک اشتباهه یا پست خصوصیه. دوباره امتحان کن.", getMainMenu());
        $response_data = json_decode($sent_message, true);
        if (isset($response_data['result']['message_id'])) {
            $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
            saveBotSettings($settings);
        }
    }
    exit;
}

if ($text && !isset($settings['support_state'][$user_id]) && !file_exists("data/temp_admin_add.txt") && !file_exists("data/temp_admin_remove.txt") && !file_exists("data/temp_premium_add.txt") && !file_exists("data/temp_premium_remove.txt") && !file_exists("data/temp_ban_add.txt") && !file_exists("data/temp_ban_remove.txt") && !file_exists("data/waiting_for_link_{$user_id}.txt")) {
    if (isset($settings['last_bot_message_id'][$chat_id])) {
        deleteMessage($chat_id, $settings['last_bot_message_id'][$chat_id]);
    }
    $sent_message = sendMessage($chat_id, "❓ <b>متوجه نشدم چی گفتی.</b>\n\nلطفاً از دکمه‌های منو استفاده کن:", getMainMenu());
    $response_data = json_decode($sent_message, true);
    if (isset($response_data['result']['message_id'])) {
        $settings['last_bot_message_id'][$chat_id] = $response_data['result']['message_id'];
        saveBotSettings($settings);
    }
}