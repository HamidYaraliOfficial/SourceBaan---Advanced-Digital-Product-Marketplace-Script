import telebot
import random
import time
import threading
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# Bot token and IDs
TOKEN = '8136500994:' توکن ربات
ADMIN_ID = 6732036 ایدی عددی ادمین
CHANNEL_ID = -100275712 ایدی عددی چنل

bot = telebot.TeleBot(TOKEN)

# Store participants and giveaway info
participants = {}
giveaway_active = False
giveaway_group_chat_id = None
giveaway_channel_message_id = None
giveaway_group_message_id = None

def create_inline_keyboard():
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🎉 شرکت در چالش", callback_data="join_giveaway"))
    return keyboard

def select_winner(group_chat_id, channel_message_id, group_message_id):
    global giveaway_active, participants
    time.sleep(300)  # Wait for 5 minutes
    if len(participants.get(group_chat_id, [])) >= 10:
        winner = random.choice(participants[group_chat_id])
        winner_text = (
            f"🎊 برنده خوش‌شانس چالش: [{winner['first_name']}](tg://user?id={winner['id']}) 🎉\n"
            f"تبریک به برنده عزیز! 🥳 لطفاً به ادمین پیام بدید: @innocentgirlN"
        )
        bot.edit_message_text(
            winner_text,
            chat_id=group_chat_id,
            message_id=group_message_id,
            parse_mode="Markdown"
        )
        bot.edit_message_text(
            winner_text,
            chat_id=CHANNEL_ID,
            message_id=channel_message_id,
            parse_mode="Markdown"
        )
    else:
        cancel_text = (
            f"😔 چالش به دلیل نرسیدن به حداقل 10 شرکت‌کننده لغو شد.\n"
            f"تعداد شرکت‌کنندگان: {len(participants.get(group_chat_id, []))} نفر"
        )
        bot.edit_message_text(
            cancel_text,
            chat_id=group_chat_id,
            message_id=group_message_id
        )
        bot.edit_message_text(
            cancel_text,
            chat_id=CHANNEL_ID,
            message_id=channel_message_id
        )
    participants.pop(group_chat_id, None)
    giveaway_active = False
    global giveaway_group_chat_id, giveaway_channel_message_id, giveaway_group_message_id
    giveaway_group_chat_id = None
    giveaway_channel_message_id = None
    giveaway_group_message_id = None

@bot.message_handler(commands=['start_giveaway'])
def start_giveaway(message):
    global giveaway_active, giveaway_group_chat_id, giveaway_channel_message_id, giveaway_group_message_id
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, "🚫 فقط ادمین می‌تونه چالش رو شروع کنه! 😊")
        return
    if giveaway_active:
        bot.reply_to(message, "⏳ یه چالش دیگه در جریانه! لطفاً صبر کن تا تموم بشه. 😊")
        return
    if message.chat.type == 'channel':
        bot.reply_to(message, "🚫 چالش‌ها فقط توی گروه شروع می‌شن! لطفاً توی گروه استفاده کن. 😊")
        return

    giveaway_active = True
    giveaway_group_chat_id = message.chat.id
    giveaway_text = (
        "🎈 چالش جدید شروع شد! 🎈\n"
        "برای شرکت در قرعه‌کشی، روی دکمه زیر کلیک کن! 🥰\n"
        "حداقل 10 نفر باید شرکت کنن تا برنده مشخص بشه! 🎁\n"
        "زمان باقی‌مانده: 5 دقیقه ⏰"
    )
    # Send to group
    group_message = bot.send_message(
        message.chat.id,
        giveaway_text,
        reply_markup=create_inline_keyboard()
    )
    giveaway_group_message_id = group_message.message_id
    # Send to channel
    channel_message = bot.send_message(
        CHANNEL_ID,
        giveaway_text,
        reply_markup=create_inline_keyboard()
    )
    giveaway_channel_message_id = channel_message.message_id
    threading.Thread(target=select_winner, args=(message.chat.id, channel_message.message_id, group_message.message_id)).start()

@bot.callback_query_handler(func=lambda call: call.data == "join_giveaway")
def handle_join_giveaway(call):
    global participants
    user = call.from_user
    chat_id = call.message.chat.id

    if not giveaway_active or (chat_id != giveaway_group_chat_id and chat_id != CHANNEL_ID):
        bot.answer_callback_query(call.id, "😔 این چالش تموم شده یا وجود نداره!")
        return

    if giveaway_group_chat_id not in participants:
        participants[giveaway_group_chat_id] = []

    if user.id not in [p['id'] for p in participants[giveaway_group_chat_id]]:
        participants[giveaway_group_chat_id].append({'id': user.id, 'first_name': user.first_name})
        bot.answer_callback_query(call.id, f"🎉 {user.first_name}، شما با موفقیت در چالش شرکت کردید! 😊")
        update_text = (
            f"🎈 چالش جدید در جریان است! 🎈\n"
            f"تعداد شرکت‌کنندگان تا الان: {len(participants[giveaway_group_chat_id])} نفر 🥰\n"
            f"برای شرکت، روی دکمه زیر کلیک کن! 🎁\n"
            f"زمان باقی‌مانده: 5 دقیقه ⏰"
        )
        # Update group message
        bot.edit_message_text(
            update_text,
            chat_id=giveaway_group_chat_id,
            message_id=giveaway_group_message_id,
            reply_markup=create_inline_keyboard()
        )
        # Update channel message
        bot.edit_message_text(
            update_text,
            chat_id=CHANNEL_ID,
            message_id=giveaway_channel_message_id,
            reply_markup=create_inline_keyboard()
        )
    else:
        bot.answer_callback_query(call.id, "😅 شما قبلاً در این چالش شرکت کردید!")

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(
        message,
        "🌟 به ربات چالش خوش اومدی! 🌟\n"
        "این ربات قرعه‌کشی‌های هیجان‌انگیز برگزار می‌کنه! 🎉\n"
        "دستورات:\n"
        "/start_giveaway - شروع چالش (فقط ادمین، فقط در گروه)\n"
        "فقط کافیه روی دکمه شیشه‌ای کلیک کنی تا توی قرعه‌کشی شرکت کنی! 🥳\n"
        "حداقل 10 نفر باید شرکت کنن و بعد از 5 دقیقه برنده مشخص می‌شه! 🎁\n"
        "با ما در @innocentgirlN همراه باش! 😊"
    )

# Start the bot
bot.polling()