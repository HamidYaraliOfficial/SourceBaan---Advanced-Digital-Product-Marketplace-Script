import telebot
import requests
import time

TOKEN = "Token_here"
bot = telebot.TeleBot(TOKEN)
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "سلام! فایل، عکس یا ویدیوی خود را بفرستید تا لینک دان>
@bot.message_handler(content_types=['document', 'photo', 'video'])
def handle_file(message):
    file_id = None
    if message.document:
        file_id = message.document.file_id
    elif message.photo:
        file_id = message.photo[-1].file_id  # آخرین عکس (با کیفیت بالا)
    elif message.video:
        file_id = message.video.file_id
    if file_id:
        # Send the initial 'creating link' message
        msg = bot.reply_to(message, "❖ **Creating the link**...", parse_mode="M>
        # Get file information from Telegram
        file_info = bot.get_file(file_id)
        file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_info.file_p>
        # Shorten the Telegram file URL using TinyURL
        api_url = f"https://tinyurl.com/api-create.php?url={file_url}"
        response = requests.get(api_url)
        if response.status_code == 200 and response.text.startswith("https://ti>
            short_url = response.text
            # Edit the message with the bold link
            bot.edit_message_text(f"**❖ The link is ready\n❖ Link:**\n`{short_u>
        else:
            bot.edit_message_text("❌  Error in shortening the URL. Please try a>
    else:
        bot.reply_to(message, "⚠️ لطفاً یک فایل معتبر ارسال کنید!")
bot.polling(non_stop=True)