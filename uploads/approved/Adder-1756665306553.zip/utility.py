import telegram
from config import *

admini = 'admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon'
analyze = 'analyze_6OiPm3nDgKvykUbeGzsVrNExpX24ld'
apis = 'apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU'
egroup = 'export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq'
gtg = 'group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa'
mbots = 'madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4'
moveds = 'moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO'
users = 'users_hc137ZnsdyHY38Qpsk47Sj39Palw379'

menu_var = '🏛 منو اصلی'
panel_var = '👨‍💻 پنل ادمین'
back_var = 'بازگشت 🔙'

bot = telegram.Bot(token=token)
get_me = bot.get_me()
bot_id = get_me.id
bot_username = get_me.username

status_mbots = {
    'first_level': 'در حال ثبت ⏳',
    'code': 'دریافت کد تایید 📞',
    'password': 'دریافت پسورد 🛡',
    'submitted': 'فعال ✅',
    'restrict': 'محدود ⛔️',
    'expired': 'منقضی ❗️️'
}
status_gtg = {
    'start': 'در حال ثبت ❕️',
    'doing': 'در حال انجام ♻️',
    'end': 'تمام شده ✅',
}

def convert_time(time, level=4):
    time = int(time)
    day = int(time / 86400)
    hour = int((time % 86400) / 3600)
    minute = int((time % 3600) / 60)
    second = int(time % 60)
    level_check = 1
    if time >= 86400:
        if time == 86400:
            return "1 روز"
        output = f"{day} روز"
        if hour > 0 and level > level_check:
            output += f" و {hour} ساعت"
            level_check += 1
        if minute > 0 and level > level_check:
            output += f" و {minute} دقیقه"
            level_check += 1
        if second > 0 and level > level_check:
            output += f" و {second} ثانیه"
        return output
    if time >= 3600:
        if time == 3600:
            return "1 ساعت"
        output = f"{hour} ساعت"
        if minute > 0 and level > level_check:
            output += f" و {minute} دقیقه"
            level_check += 1
        if second > 0 and level > level_check:
            output += f" و {second} ثانیه"
        return output
    if time >= 60:
        if time == 60:
            return "1 دقیقه"
        output = f"{minute} دقیقه"
        if second > 0 and level > level_check:
            output += f" و {second} ثانیه"
        return output
    if second > 0:
        return f"{second} ثانیه"
    else:
        return False
