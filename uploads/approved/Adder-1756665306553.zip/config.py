admin_id = 111111
token = ""

host_db = 'localhost'
database = ''
user_db = ''
passwd_db = ''
