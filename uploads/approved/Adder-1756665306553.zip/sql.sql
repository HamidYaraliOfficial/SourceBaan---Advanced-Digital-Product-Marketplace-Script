CREATE TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon` (
  `id` int(11) NOT NULL,
  `leave_per` tinyint(1) NOT NULL DEFAULT 0,
  `delete_first_levels` tinyint(1) NOT NULL DEFAULT 0,
  `change_pass` tinyint(1) NOT NULL DEFAULT 0,
  `exit_session` tinyint(1) NOT NULL DEFAULT 0,
  `gtg_per` tinyint(1) NOT NULL DEFAULT 0,
  `type_analyze` tinyint(1) NOT NULL DEFAULT 0,
  `type_add` tinyint(1) NOT NULL DEFAULT 0,
  `api_per_number` int(11) NOT NULL DEFAULT 1,
  `limit_per_h` int(11) NOT NULL DEFAULT 24,
  `add_per_h` int(11) NOT NULL DEFAULT 20
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;


INSERT INTO `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon` (`id`, `leave_per`, `delete_first_levels`, `change_pass`, `exit_session`, `gtg_per`, `type_analyze`, `type_add`, `api_per_number`, `limit_per_h`, `add_per_h`) VALUES
(0, 0, 0, 0, 0, 0, 1, 0, 1, 24, 8);


CREATE TABLE `analyze_6OiPm3nDgKvykUbeGzsVrNExpX24ld` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `origin_id` varchar(30) NOT NULL,
  `destination_id` varchar(30) NOT NULL,
  `is_real` tinyint(1) NOT NULL DEFAULT 0,
  `is_fake` tinyint(1) NOT NULL DEFAULT 0,
  `is_phone` tinyint(1) NOT NULL DEFAULT 0,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `is_bad` tinyint(1) NOT NULL DEFAULT 0,
  `reserved_by` varchar(20) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;


CREATE TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU` (
  `id` int(11) NOT NULL,
  `api_id` varchar(20) NOT NULL,
  `api_hash` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;


CREATE TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq` (
  `id` int(11) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `chat_id` varchar(30) DEFAULT NULL,
  `link` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'start',
  `users` int(11) NOT NULL DEFAULT 0,
  `users_has_phone` int(11) NOT NULL DEFAULT 0,
  `users_online` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;


CREATE TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `origin` varchar(200) NOT NULL,
  `origin_id` varchar(20) NOT NULL DEFAULT '0',
  `destination` varchar(200) DEFAULT NULL,
  `destination_id` varchar(20) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT 0,
  `count_moved` int(11) NOT NULL DEFAULT 0,
  `last_bot_check` int(11) NOT NULL DEFAULT 0,
  `last_member_check` int(11) NOT NULL DEFAULT 0,
  `max_users` int(11) NOT NULL DEFAULT 0,
  `type_users` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'start',
  `status_analyze` varchar(10) NOT NULL DEFAULT 'run',
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;


CREATE TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4` (
  `id` int(11) NOT NULL,
  `creator_user_id` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'first_level',
  `end_restrict` int(11) NOT NULL DEFAULT 0,
  `last_order_at` int(11) NOT NULL DEFAULT 0,
  `last_leve_at` int(11) NOT NULL DEFAULT 0,
  `api_id` varchar(20) NOT NULL,
  `api_hash` varchar(200) NOT NULL,
  `phone_code_hash` varchar(100) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `is_change_pass` tinyint(1) NOT NULL DEFAULT 0,
  `change_pass_at` int(11) NOT NULL DEFAULT 0,
  `is_exit_session` tinyint(1) NOT NULL DEFAULT 0,
  `exit_session_at` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

CREATE TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `origin_id` varchar(30) NOT NULL,
  `destination_id` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'join',
  `created_at` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

CREATE TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'user',
  `step` varchar(50) NOT NULL DEFAULT 'start',
  `prev_step` varchar(50) NOT NULL DEFAULT 'start',
  `last_auto_update_at` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

ALTER TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `analyze_6OiPm3nDgKvykUbeGzsVrNExpX24ld`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `user_id` (`user_id`);

ALTER TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api_id` (`api_id`),
  ADD UNIQUE KEY `api_hash` (`api_hash`);

ALTER TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`);

ALTER TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`);

ALTER TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`),
  ADD UNIQUE KEY `phone` (`phone`);

ALTER TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

ALTER TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `analyze_6OiPm3nDgKvykUbeGzsVrNExpX24ld`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
