#!/bin/sh
python3 tl.direct_add.py $1 &