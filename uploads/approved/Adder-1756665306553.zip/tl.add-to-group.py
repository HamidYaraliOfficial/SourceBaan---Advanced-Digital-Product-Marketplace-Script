#!/usr/bin/env python3

import os
import time
import datetime
import json
import re
import mysql.connector
from telethon.sync import TelegramClient
from telethon import functions, errors
import utility as utl

directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))
try:
    with open(f"{directory}/pid/{filename}.txt", "r") as file:
        pid = int(file.read())
    os.kill(pid, 0)
except OSError:
    with open(f"{directory}/pid/{filename}.txt", "w") as file:
        file.write(str(os.getpid()))
else:
    os.system(f"kill -9 {pid}")
    time.sleep(2)
    try:
        os.kill(pid, 0)
    except OSError:
        with open(f"{directory}/pid/{filename}.txt", "w") as file:
            file.write(str(os.getpid()))
    else:
        print("Try again!")
        exit()
print(f"run: {filename}")


def insert(cs, sql):
    try:
        cs.execute(sql)
    except:
        pass

def add_to_group(cs,row_gtg,row_mbots,row_admin,result):
    try:
        count_join = i = count_limit = 0
        timestamp = int(time.time())
        client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}", api_id=row_mbots['api_id'], api_hash=row_mbots['api_hash'])
        client.connect()
        if not client.is_user_authorized():
            cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
        else:
            try:
                for r in client(functions.messages.StartBotRequest(bot="@spambot",peer="@spambot",start_param="start")).updates:
                    for r1 in client(functions.messages.GetMessagesRequest(id=[r.id + 1])).messages:
                        if "I’m afraid some Telegram users found your messages annoying and forwarded them to our team of moderators for inspection." in r1.message:
                            regex = re.findall('automatically released on [\d\w ,:]*UTC', r1.message)[0]
                            regex = regex.replace("automatically released on ","")
                            regex = regex.replace(" UTC","")
                            restrict = datetime.datetime.strptime(regex, "%d %b %Y, %H:%M").timestamp()
                            cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{restrict}' WHERE id={row_mbots['id']}")
                            print(f"{row_mbots['phone']}: Reported in first step")
                            return
                    break
            except:
                pass
            try:
                if "/joinchat/" in row_gtg['destination']:
                    client(functions.messages.ImportChatInviteRequest(row_gtg['destination'].split("/joinchat/")[1]))
                else:
                    client(functions.channels.JoinChannelRequest(channel=row_gtg['destination']))
                for row in result:
                    user = row['username']
                    if row_admin['type_analyze']:
                        try:
                            cs.execute(f"UPDATE {utl.gtg} SET last_member_check=last_member_check+1 WHERE id={row_gtg['id']}")
                            client(functions.channels.InviteToChannelRequest(channel=row_gtg['destination'],users=[user]))
                            print(f"{row_mbots['id']} ({i}): Joined")
                            count_join += 1
                            if (row_gtg['count_moved'] + count_join) >= row_gtg['count']:
                                cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']} AND count_moved>0 AND count_moved>=count")
                                if cs.fetchone() is not None:
                                    return
                            cs.execute(f"UPDATE {utl.gtg} SET count_moved=count_moved+1 WHERE id={row_gtg['id']}")
                            cs.execute(f"DELETE FROM {utl.analyze} WHERE username='{user}'")
                            insert(cs, f"INSERT INTO {utl.moveds} (bot_id,username,origin_id,destination_id,created_at) VALUES ('{row_mbots['id']}','{user}','{row_gtg['origin_id']}','{row_gtg['destination_id']}','{timestamp}')")
                        except errors.FloodWaitError as e:
                            print(f"{row_mbots['id']} ({i}): Restricted when Invite")
                            end_restrict = int(time.time()) + int(e.seconds)
                            cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                            return
                        except Exception as e:
                            print(f"{row_mbots['id']} ({i}): Error when Invite ({str(e)})")
                            if str(e) == 'Too many requests (caused by InviteToChannelRequest)':
                                cs.execute(f"UPDATE {utl.gtg} SET last_member_check=last_member_check-1 WHERE id={row_gtg['id']}")
                                count_limit += 1
                                if count_limit > 3:
                                    end_restrict = int(time.time()) + 86400
                                    cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                                    return
                            else:
                                cs.execute(f"UPDATE {utl.analyze} SET is_bad=1 WHERE id='{row['id']}'")
                    else:
                        try:
                            cs.execute(f"UPDATE {utl.gtg} SET last_member_check=last_member_check+1 WHERE id={row_gtg['id']}")
                            client(functions.channels.GetParticipantRequest(channel=row_gtg['destination'],participant=user))
                            insert(cs, f"INSERT INTO {utl.moveds} (bot_id,username,origin_id,destination_id,status,created_at) VALUES ('{row_mbots['id']}','{user}','{row_gtg['origin_id']}','{row_gtg['destination_id']}','already','{timestamp}')")
                            print(f"{row_mbots['id']} ({i}): Already")
                        except errors.UserNotParticipantError as e:
                            try:
                                client(functions.channels.InviteToChannelRequest(channel=row_gtg['destination'],users=[user]))
                                print(f"{row_mbots['id']} ({i}): Joined")
                                count_join += 1
                                if (row_gtg['count_moved'] + count_join) >= row_gtg['count']:
                                    cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']} AND count_moved>0 AND count_moved>=count")
                                    if cs.fetchone() is not None:
                                        return
                                cs.execute(f"UPDATE {utl.gtg} SET count_moved=count_moved+1 WHERE id={row_gtg['id']}")
                                cs.execute(f"DELETE FROM {utl.analyze} WHERE username='{user}'")
                                insert(cs, f"INSERT INTO {utl.moveds} (bot_id,username,origin_id,destination_id,created_at) VALUES ('{row_mbots['id']}','{user}','{row_gtg['origin_id']}','{row_gtg['destination_id']}','{timestamp}')")
                            except errors.FloodWaitError as e:
                                print(f"{row_mbots['id']} ({i}): Restricted when Invite")
                                end_restrict = int(time.time()) + int(e.seconds)
                                cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                                return
                            except Exception as e:
                                print(f"{row_mbots['id']} ({i}): Error when Invite ({str(e)})")
                                if str(e) == 'Too many requests (caused by InviteToChannelRequest)':
                                    cs.execute(f"UPDATE {utl.gtg} SET last_member_check=last_member_check-1 WHERE id={row_gtg['id']}")
                                    count_limit += 1
                                    if count_limit > 3:
                                        end_restrict = int(time.time()) + 86400
                                        cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                                        return
                                else:
                                    cs.execute(f"UPDATE {utl.analyze} SET is_bad=1 WHERE id='{row['id']}'")
                        except errors.FloodWaitError as e:
                            print(f"{row_mbots['id']} ({i}): Restricted when checking")
                            end_restrict = int(time.time()) + int(e.seconds)
                            cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                            break
                        except Exception as e:
                            print(f"{row_mbots['id']} ({i}): Error when checking ({str(e)})")
                            if str(e) == 'Too many requests (caused by InviteToChannelRequest)':
                                cs.execute(f"UPDATE {utl.gtg} SET last_member_check=last_member_check-1 WHERE id={row_gtg['id']}")
                                count_limit += 1
                                if count_limit > 3:
                                    end_restrict = int(time.time()) + 86400
                                    cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                                    return
                            else:
                                cs.execute(f"UPDATE {utl.analyze} SET is_bad=1 WHERE id='{row['id']}'")
                    i += 1
                    try:
                        for r in client(functions.messages.StartBotRequest(bot="@spambot",peer="@spambot",start_param="start")).updates:
                            for r1 in client(functions.messages.GetMessagesRequest(id=[r.id + 1])).messages:
                                if "I’m afraid some Telegram users found your messages annoying and forwarded them to our team of moderators for inspection." in r1.message:
                                    regex = re.findall('automatically released on [\d\w ,:]*UTC', r1.message)[0]
                                    regex = regex.replace("automatically released on ","")
                                    regex = regex.replace(" UTC","")
                                    restrict = datetime.datetime.strptime(regex, "%d %b %Y, %H:%M").timestamp()
                                    cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{restrict}' WHERE id={row_mbots['id']}")
                                    print(f"{row_mbots['phone']}: Reported in last step")
                                    return
                            break
                    except:
                        pass
            except errors.FloodWaitError as e:
                print(f"{row_mbots['id']} ({i}): Restricted when join group")
                end_restrict = int(time.time()) + int(e.seconds)
                cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                return
            except Exception as e:
                print(f"{row_mbots['id']} ({i}): Error  join group ({str(e)})")
                return
    except Exception as e:
        print(f"{row_mbots['id']} ({i}): Error when Start ({str(e)})")
    finally:
        try:
            client.disconnect()
        except:
            pass
    print(f"{row_mbots['id']} RESULT: {count_join}")


while True:
    try:
        mydb = mysql.connector.connect(host = utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4")
        cs = mydb.cursor(dictionary=True,buffered=True)
        cs.execute(f"SELECT * FROM {utl.admini}")
        row_admin = cs.fetchone()
        join_number = row_admin['add_per_h']
        limit_per_h = row_admin['limit_per_h'] * 3600
        timestamp = int(time.time())
        
        cs.execute(f"SELECT * FROM {utl.gtg} WHERE status='doing'")
        row_gtg = cs.fetchone()
        if row_gtg is not None:
            if row_gtg['count_moved'] > 0 and row_gtg['count_moved'] >= row_gtg['count']:
                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
            else:
                if row_admin['type_add']:
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC")
                    # cs.execute(f"SELECT {utl.mbots}.id as id,phone,api_id,api_hash,COUNT(*) as count_add FROM {utl.moveds} INNER JOIN {utl.mbots} ON {utl.moveds} .bot_id={utl.mbots}.id WHERE {utl.moveds}.status='join' AND {utl.mbots}.status='submitted' AND ({utl.mbots}.last_order_at+{limit_per_h})<{timestamp} GROUP BY {utl.moveds}.bot_id ORDER BY count_add ASC")
                    result_mbots = cs.fetchall()
                    if result_mbots:
                        i = 0
                        for row_mbots in result_mbots:
                            cs.execute(f"SELECT * FROM {utl.analyze} WHERE is_bad=0 AND reserved_by='0' ORDER BY id ASC LIMIT {join_number}")
                            result = cs.fetchall()
                            if result:
                                try:
                                    print(f"Start: {row_mbots['phone']}")
                                    cs.execute(f"UPDATE {utl.analyze} SET is_bad=0,reserved_by='{row_mbots['phone']}' WHERE is_bad=0 AND reserved_by='0' ORDER BY id ASC LIMIT {join_number}")
                                    cs.execute(f"UPDATE {utl.mbots} SET last_order_at='{timestamp}' WHERE id={row_mbots['id']}")
                                    os.system(f"./job_add.sh {row_mbots['phone']}")
                                except:
                                    pass
                            else:
                                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                                break
                            i += 1
                            timestamp = int(time.time())
                            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']} AND status='doing'")
                            row_gtg = cs.fetchone()
                            if row_gtg is None:
                                break
                            elif row_gtg['count_moved'] > 0 and row_gtg['count_moved'] >= row_gtg['count']:
                                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                                break
                            else:
                                cs.execute(f"UPDATE {utl.gtg} SET last_bot_check='{row_mbots['id']}',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                            time.sleep(3)
                    else:
                        cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                else:
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC")
                    result_mbots = cs.fetchall()
                    if result_mbots:
                        for row_mbots in result_mbots:
                            cs.execute(f"SELECT * FROM {utl.analyze} WHERE is_bad=0 LIMIT {join_number}")
                            result = cs.fetchall()
                            if result:
                                cs.execute(f"UPDATE {utl.mbots} SET last_order_at='{timestamp}' WHERE id={row_mbots['id']}")
                                add_to_group(cs,row_gtg,row_mbots,row_admin,result)
                            else:
                                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                                break
                            timestamp = int(time.time())
                            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']} AND status='doing'")
                            row_gtg = cs.fetchone()
                            if row_gtg is None:
                                break
                            elif row_gtg['count_moved'] > 0 and row_gtg['count_moved'] >= row_gtg['count']:
                                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                                break
                            else:
                                cs.execute(f"UPDATE {utl.gtg} SET last_bot_check='{row_mbots['id']}',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                    else:
                        cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
    except Exception as e:
        print(f"Error in main: " + str(e))
    time.sleep(10)

