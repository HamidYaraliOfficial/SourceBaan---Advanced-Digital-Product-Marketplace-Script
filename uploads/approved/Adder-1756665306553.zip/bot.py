#!/usr/bin/env python3
# pylint: disable=C0116,W0613

import string
import random
import os
import json
import time
import datetime
import jdatetime
import mysql.connector
from telegram import Update, ChatPermissions,  ForceReply, chat
from telegram.ext import Updater, CommandHandler, MessageHandler,CallbackQueryHandler, Filters, CallbackContext
from telegram.error import RetryAfter, TimedOut
import utility as utl


directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))
try:
    with open(f"{directory}/pid/{filename}.txt", "r") as file:
        pid = int(file.read())
    os.kill(pid, 0)
except OSError:
    with open(f"{directory}/pid/{filename}.txt", "w") as file:
        file.write(str(os.getpid()))
else:
    os.system(f"kill -9 {pid}")
    time.sleep(2)
    try:
        os.kill(pid, 0)
    except OSError:
        with open(f"{directory}/pid/{filename}.txt", "w") as file:
            file.write(str(os.getpid()))
    else:
        print("Try again!")
        exit()
print(f"run: {filename}")

step_page = 15


def write_on_file(name,content):
    with open(name, 'w') as file:
        file.write(content)


def uniq_id_generate(cs,num,table):
    randon_num = str(''.join(random.choices(string.ascii_uppercase + string.digits, k = num)))
    cs.execute(f"SELECT * FROM {table} WHERE uniq_id='{randon_num}'")
    if cs.fetchone() == None:
        return randon_num
    else:
        uniq_id_generate(num,table)


def select_api(cs,num):
    outout = ""
    cs.execute(f"SELECT api_id,count(*) FROM {utl.mbots} GROUP BY api_id HAVING count(*)>={num}")
    result = cs.fetchall()
    if not result:
        cs.execute(f"SELECT * FROM {utl.apis}")
        return cs.fetchone()
    
    for row in result:
        outout += f"'{row['api_id']}',"
    
    cs.execute(f"SELECT * FROM {utl.apis} WHERE api_id NOT IN ({outout[0:-1]})")
    return cs.fetchone()


def user_panel(update,text=None):
    if not text:
        text = "ناحیه کاربری:"
    update.message.reply_html(text=text,
        reply_markup={'resize_keyboard': True,'keyboard': [
            [{'text': '📚 راهنما 📚'},{'text': '📊 آمار 📊'}],
            [{'text': '📋 سفارشات'},{'text': '➕ ایجاد سفارش'}],
            [{'text': '📋 اکانت ها'},{'text': '➕ افزودن اکانت'}],
            [{'text': '📋 لیست api ها'},{'text': '➕ افزودن api'}],
            [{'text': '🔮 آنالیز گروه 🔮'},{'text': '⚙️ تنظیمات ⚙️'}],
        ]}
    )


class Pagination:
    
    def __init__(self,update,type_btn,output,step_page,num_all_pages):
        self.update = update
        self.type_btn = type_btn
        self.text = output
        self.step_page = step_page
        self.num_all_pages = num_all_pages

    def setStepPage(self,step_page):
        self.step_page = step_page
    
    def setText(self,text):
        self.text = text
    
    def setNumAllPages(self,num_all_pages):
        self.num_all_pages = num_all_pages
    
    def processMessage(self):
        chat_id = self.update.message.chat.id
        if self.num_all_pages > self.step_page:
            self.update.message.reply_html(disable_web_page_preview=True,text=self.text,
                reply_markup={'inline_keyboard': [[{'text': f"صفحه 2", 'callback_data': f"pg;{self.type_btn};2"}]]}
            )
        else:
            self.update.message.reply_html(disable_web_page_preview=True,text=self.text)
        return
    
    def processCallback(self):
        query = self.update.callback_query
        ex_data = query.data.split(";")
        num_current_page = int(ex_data[2])
        num_prev_page = num_current_page - 1
        num_next_page = num_current_page + 1
        if num_current_page == 1:
            query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text=self.text,
                reply_markup={'inline_keyboard': [[{'text': f"<< صفحه {num_next_page}", 'callback_data': f"pg;{self.type_btn};{num_next_page}"}]]}
            )
        elif self.num_all_pages > (num_current_page * self.step_page):
            query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text=self.text,
                reply_markup={'inline_keyboard': [
                    [{'text': f"صفحه {num_prev_page} >>", 'callback_data': f"pg;{self.type_btn};{num_prev_page}"},
                    {'text': f"<< صفحه {num_next_page}", 'callback_data': f"pg;{self.type_btn};{num_next_page}"}]
                ]}
            )
        else:
            query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text=self.text,
                reply_markup={'inline_keyboard': [[{'text': f"صفحه {num_prev_page} >>", 'callback_data': f"pg;{self.type_btn};{num_prev_page}"}]]}
            )
        return


def callbackquery_process(update: Update, context: CallbackContext) -> None:
    # write_on_file("callbackquery_process.txt",str(update))
    try:
        bot = context.bot
        query = update.callback_query
        from_id = query.from_user.id
        chat_id = query.message.chat.id
        chat_type = query.message.chat.type
        data = query.data
        ex_data = data.split(';')
    except:
        pass
    timestamp = int(time.time())
    try:
        if data == "test":
            return
        elif data == "nazan":
            return query.answer("نزن خراب میشه 😕")
        mydb = mysql.connector.connect(host=utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4")
        cs = mydb.cursor(dictionary=True,buffered=True)
        cs.execute(f"SELECT * FROM {utl.admini}")
        row_admin = cs.fetchone()
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{from_id}'")
        row_user = cs.fetchone()
        is_admin = True if from_id == utl.admin_id or row_user['status'] == 'admin' else False
        
        if row_admin['gtg_per'] or is_admin:
            if ex_data[0] == 'update':
                gtg_id = int(ex_data[1])
                cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
                row_gtg = cs.fetchone()
                if row_gtg is None:
                    return query.answer("❌ یافت نشد",show_alert=True)
                created_at = jdatetime.datetime.fromtimestamp(row_gtg['created_at']).strftime('%Y/%m/%d %H:%M:%S')
                updated_at = jdatetime.datetime.fromtimestamp(row_gtg['updated_at']).strftime('%Y/%m/%d %H:%M:%S')
                now = jdatetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
                
                inline_keyboard = []
                if not is_admin or row_gtg['status'] == 'end':
                    inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'url': f"https://t.me/{utl.bot_username}"}])
                else:
                    inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'callback_data': f"change_status;{row_gtg['id']};none"}])
                if row_gtg['status'] != "end" or is_admin:
                    inline_keyboard.append([{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}])
                    inline_keyboard.append([{'text': '🔄 بروزرسانی خودکار 🔄', 'callback_data': f"auto_update;{row_gtg['id']}"}])
                
                query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text="🔹️ گروه مبدا:\n"+
                    f"<code>{row_gtg['origin_id']}</code>\n"+
                    f"{row_gtg['origin']}\n"+
                    "🔹 گروه مقصد:\n"+
                    f"<code>{row_gtg['destination_id']}</code>\n"+
                    f"{row_gtg['destination']}\n\n"+
                    f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n"+
                    f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n"+
                    f"\n"+
                    f"📅️ Created: {created_at}\n"+
                    f"📅️ Updated: {updated_at}\n"+
                    f"📅️ ️Now: {now}",
                    reply_markup={'inline_keyboard': inline_keyboard}
                )
                return
            if ex_data[0] == 'auto_update':
                gtg_id = int(ex_data[1])
                cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
                row_gtg = cs.fetchone()
                if row_gtg is None:
                    return query.answer("❌ یافت نشد",show_alert=True)
                if (timestamp - row_user['last_auto_update_at']) < 60:
                    wait = 60 - (timestamp - row_user['last_auto_update_at'])
                    return query.answer(f"❌ آدم باش {wait} ثانیه دیگه صبر کن")
                i = 0
                cs.execute(f"UPDATE {utl.users} SET last_auto_update_at='{timestamp}' WHERE user_id='{from_id}'")
                while i < 60 and row_gtg['status'] == 'doing':
                    try:
                        cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
                        row_gtg = cs.fetchone()
                        created_at = jdatetime.datetime.fromtimestamp(row_gtg['created_at']).strftime('%Y/%m/%d %H:%M:%S')
                        updated_at = jdatetime.datetime.fromtimestamp(row_gtg['updated_at']).strftime('%Y/%m/%d %H:%M:%S')
                        now = jdatetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
                        
                        query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text="🔹️ گروه مبدا:\n"+
                            f"<code>{row_gtg['origin_id']}</code>\n"+
                            f"{row_gtg['origin']}\n"+
                            "🔹 گروه مقصد:\n"+
                            f"<code>{row_gtg['destination_id']}</code>\n"+
                            f"{row_gtg['destination']}\n\n"+
                            f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n"+
                            f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n"+
                            f"\n"+
                            f"📅️ Created: {created_at}\n"+
                            f"📅️ Updated: {updated_at}\n"+
                            f"📅️ ️Now: {now}\n"+
                            "➖➖➖➖➖\n"+
                            f"در حال آپدیت خودکار یک دقیقه: {(60-i)}",
                            reply_markup={'inline_keyboard': [
                                [{'text': utl.status_gtg[row_gtg['status']], 'callback_data': f"change_status;{row_gtg['id']};none"}],
                            ]}
                        )
                        if row_gtg['status'] != 'doing':
                            break
                    except:
                        pass
                    i += 4
                    time.sleep(4)
                
                inline_keyboard = []
                if not is_admin or row_gtg['status'] == 'end':
                    inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'url': f"https://t.me/{utl.bot_username}"}])
                else:
                    inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'callback_data': f"change_status;{row_gtg['id']};none"}])
                if row_gtg['status'] != "end" or is_admin:
                    inline_keyboard.append([{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}])
                    inline_keyboard.append([{'text': '🔄 بروزرسانی خودکار 🔄', 'callback_data': f"auto_update;{row_gtg['id']}"}])
                
                query.edit_message_text(parse_mode='HTML',disable_web_page_preview=True,text="🔹️ گروه مبدا:\n"+
                    f"<code>{row_gtg['origin_id']}</code>\n"+
                    f"{row_gtg['origin']}\n"+
                    "🔹 گروه مقصد:\n"+
                    f"<code>{row_gtg['destination_id']}</code>\n"+
                    f"{row_gtg['destination']}\n\n"+
                    f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n"+
                    f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n"+
                    f"\n"+
                    f"📅️ Created: {created_at}\n"+
                    f"📅️ Updated: {updated_at}\n"+
                    f"📅️ ️Now: {now}",
                    reply_markup={'inline_keyboard': inline_keyboard}
                )
                return
        if from_id != utl.admin_id and row_user['status'] != 'admin':
            return
        
        if ex_data[0] == 'pg':
            if ex_data[1] == 'accounts':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    if row['status'] == 'restrict':
                        output += f"{i}. شماره: <code>{row['phone']}</code>\n"
                        output += f"⛔ محدودیت: ({utl.convert_time((row['end_restrict'] - timestamp),2)})\n"
                    else:
                        output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت ها:\n\n"+output+"ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots}")
                ob = Pagination(update,"accounts",output,step_page,cs.rowcount)
                ob.processCallback()
                return
            if ex_data[1] == 'restrict':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='restrict' ORDER BY end_restrict ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code>\n"
                    output += f"⛔ محدودیت: ({utl.convert_time((row['end_restrict'] - timestamp),2)})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های محدود شده:\n\n"+output+"ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='restrict'")
                ob = Pagination(update,"restrict",output,step_page,cs.rowcount)
                ob.processCallback()
                return
            if ex_data[1] == 'first_level':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='first_level' ORDER BY last_order_at DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های ثبت نشده:\n\n"+output+"ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='first_level'")
                ob = Pagination(update,"first_level",output,step_page,cs.rowcount)
                ob.processCallback()
                return
            if ex_data[1] == 'submitted':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' ORDER BY last_order_at ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های فعال:\n\n"+output+"ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted'")
                ob = Pagination(update,"submitted",output,step_page,cs.rowcount)
                ob.processCallback()
                return
            if ex_data[1] == 'adability':
                limit_per_h = row_admin['limit_per_h'] * 3600
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های با قلبیت اد:\n\n"+output+"ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp}")
                ob = Pagination(update,"adability",output,step_page,cs.rowcount)
                ob.processCallback()
                return
            if ex_data[1] == 'orders':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.gtg} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    query.answer("❌ لیست خالی است",show_alert=True)
                    return
                output = ""
                for row in result:
                    created_at = jdatetime.datetime.fromtimestamp(row['created_at'])
                    output += f"{i}. /gtg_{row['id']}\n"
                    output += f"🔹️ گروه مبدا: {row['origin']}\n"
                    output += f"🔹️ گروه مقصد: {row['destination']}\n"
                    output += f"🔹️ تعداد ارسال شده/درخواستی: [{row['count']}/{row['count_moved']}]\n"
                    output += f"🔹️ وضعیت: {utl.status_gtg[row['status']]}\n"
                    output += f"📅️ {created_at.strftime('%Y/%m/%d %H:%M')}\n\n"
                    i += 1
                output = "پنل ادمین » سفارشات:\n\n"+output
                cs.execute(f"SELECT id FROM {utl.gtg}")
                ob = Pagination(update,"orders",output,step_page,cs.rowcount)
                ob.processCallback()
                cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
                return
            if ex_data[1] == 'apis':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return query.answer("❌ لیست خالی است",show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. حذف: /dela_{row['id']}\n🔴️ Api ID: <code>{row['api_id']}</code>\n🔴️ Api Hash: <code>{row['api_hash']}</code>\n\n"
                    i += 1
                cs.output = "پنل ادمین » لیست api ها:\n\n"+output
                cs.execute(f"SELECT id FROM {utl.apis}")
                ob = Pagination(update,"apis",output,step_page,cs.rowcount)
                ob.processCallback()
                cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
                return
            return
        if ex_data[0] == 'settings':
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE status NOT IN ('end')")
            if cs.fetchone():
                return query.answer(
                    "❌ امکان تغییر در تنظیمات وجود ندارد.\n\n"+
                    "شما سفارش فعال دارید",
                    show_alert=True
                )
            elif ex_data[1] == 'change_pass':
                row_admin['change_pass'] = 1 - row_admin['change_pass']
                cs.execute(f"UPDATE {utl.admini} SET change_pass={row_admin['change_pass']}")
            elif ex_data[1] == 'exit_session':
                row_admin['exit_session'] = 1 - row_admin['exit_session']
                cs.execute(f"UPDATE {utl.admini} SET exit_session={row_admin['exit_session']}")
            elif ex_data[1] == 'leave_per':
                row_admin['leave_per'] = 1 - row_admin['leave_per']
                cs.execute(f"UPDATE {utl.admini} SET leave_per={row_admin['leave_per']}")
            elif ex_data[1] == 'delete_first_levels':
                row_admin['delete_first_levels'] = 1 - row_admin['delete_first_levels']
                cs.execute(f"UPDATE {utl.admini} SET delete_first_levels={row_admin['delete_first_levels']}")
            elif ex_data[1] == 'gtg_per':
                row_admin['gtg_per'] = 1 - row_admin['gtg_per']
                cs.execute(f"UPDATE {utl.admini} SET gtg_per={row_admin['gtg_per']}")
            elif ex_data[1] == 'type_analyze':
                row_admin['type_analyze'] = 1 - row_admin['type_analyze']
                cs.execute(f"UPDATE {utl.admini} SET type_analyze={row_admin['type_analyze']}")
            elif ex_data[1] == 'type_add':
                row_admin['type_add'] = 1 - row_admin['type_add']
                cs.execute(f"UPDATE {utl.admini} SET type_add={row_admin['type_add']}")
            elif ex_data[2] == 'guide':
                pass
            else:
                number = int(ex_data[2])
                if ex_data[1] == 'api_per_number':
                    row_admin['api_per_number'] += number
                    if row_admin['api_per_number'] < 1:
                        return query.answer("❌ حداقل باید 1 باشد")
                    else:
                        cs.execute(f"UPDATE {utl.admini} SET api_per_number={row_admin['api_per_number']}")
                elif ex_data[1] == 'add_per_h':
                    row_admin['add_per_h'] += number
                    if row_admin['add_per_h'] < 5:
                        return query.answer("❌ حداقل باید 5 باشد")
                    elif row_admin['add_per_h'] > 28:
                        return query.answer("❌ حداقل باید 28 باشد")
                    else:
                        cs.execute(f"UPDATE {utl.admini} SET add_per_h={row_admin['add_per_h']}")
                elif ex_data[1] == 'limit_per_h':
                    row_admin['limit_per_h'] += number
                    if row_admin['limit_per_h'] < 0:
                        return query.answer("❌ حداقل باید 0 باشد")
                    else:
                        cs.execute(f"UPDATE {utl.admini} SET limit_per_h={row_admin['limit_per_h']}")
            change_pass = "✅ تغییر/تنظیم پسورد دومرحله ای ✅" if row_admin['change_pass'] else "❌ تغییر/تنظیم پسورد دومرحله ها ❌"
            exit_session = "✅ خروج از بقیه سشن ها ✅" if row_admin['exit_session'] else "❌ خروج از بقیه سشن ها ❌"
            leave_per = "✅ اکانت ها گروه ها را ترک کنند ✅" if row_admin['leave_per'] else "❌ اکانت ها گروه ها را ترک کنند ❌"
            delete_first_levels = "✅ حذف خودکار اکانت های ثبت نشده ✅" if row_admin['delete_first_levels'] else "❌ حذف خودکار اکانت های ثبت نشده ❌"
            gtg_per = "✅ دسترسی همه به شناسه سفارش ✅" if row_admin['gtg_per'] else "❌ دسترسی همه به شناسه سفارش ❌"
            type_analyze = "نوع آنالیز سفارش: لحظه ای" if row_admin['type_analyze'] else "نوع آنالیز سفارش: دیتابیس"
            type_add = "نوع اد: حرفه ای" if row_admin['type_add'] else "نوع اد: عادی"
            
            return query.edit_message_text(text=f"پنل تنظیمات:",
                reply_markup={'inline_keyboard': [
                    [{'text': f"در هر ای پی ای {row_admin['api_per_number']} شماره ثبت شود",'callback_data': f"settings;api_per_number;guide"}],
                    [
                        {'text': '+10','callback_data': f"settings;api_per_number;+10"},
                        {'text': '+5','callback_data': f"settings;api_per_number;+5"},
                        {'text': '+1','callback_data': f"settings;api_per_number;+1"},
                        {'text': '-1','callback_data': f"settings;api_per_number;-1"},
                        {'text': '-5','callback_data': f"settings;api_per_number;-5"},
                        {'text': '-10','callback_data': f"settings;api_per_number;-10"},
                    ],
                    [{'text': f"هر اکانت در هر استفاده {row_admin['add_per_h']} اد کند",'callback_data': f"settings;add_per_h;guide"}],
                    [
                        {'text': '+10','callback_data': f"settings;add_per_h;+10"},
                        {'text': '+5','callback_data': f"settings;add_per_h;+5"},
                        {'text': '+1','callback_data': f"settings;add_per_h;+1"},
                        {'text': '-1','callback_data': f"settings;add_per_h;-1"},
                        {'text': '-5','callback_data': f"settings;add_per_h;-5"},
                        {'text': '-10','callback_data': f"settings;add_per_h;-10"},
                    ],
                    [{'text': f"هر اکانت هر {row_admin['limit_per_h']} ساعت استفاده شود",'callback_data': f"settings;limit_per_h;guide"}],
                    [
                        {'text': '+10','callback_data': f"settings;limit_per_h;+10"},
                        {'text': '+5','callback_data': f"settings;limit_per_h;+5"},
                        {'text': '+1','callback_data': f"settings;limit_per_h;+1"},
                        {'text': '-1','callback_data': f"settings;limit_per_h;-1"},
                        {'text': '-5','callback_data': f"settings;limit_per_h;-5"},
                        {'text': '-10','callback_data': f"settings;limit_per_h;-10"},
                    ],
                    [{'text': change_pass,'callback_data': f"settings;change_pass;guide"}],
                    [{'text': exit_session,'callback_data': f"settings;exit_session;guide"}],
                    [{'text': leave_per,'callback_data': f"settings;leave_per;guide"}],
                    [{'text': delete_first_levels,'callback_data': f"settings;delete_first_levels;guide"}],
                    [{'text': gtg_per,'callback_data': f"settings;gtg_per;guide"}],
                    [{'text': type_analyze,'callback_data': f"settings;type_analyze;guide"}],
                    [{'text': type_add,'callback_data': f"settings;type_add;guide"}]
                ]}
            )
            return
        if ex_data[0] == 'change_status':
            gtg_id = int(ex_data[1])
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
            row_gtg = cs.fetchone()
            if row_gtg is None:
                return query.answer("❌ یافت نشد",show_alert=True)
            inline_keyboard = []
            if row_gtg['status'] == 'doing':
                if ex_data[2] == 'none':
                    inline_keyboard.append([{'text': 'آیا از اتمام سفارش مطمئن هستید؟', 'url': f"https://t.me/{utl.bot_username}"}])
                    inline_keyboard.append([{'text': '❌ کنسل ❌', 'callback_data': f"update;{row_gtg['id']}"},{'text': '✅ بله ✅', 'callback_data': f"change_status;{row_gtg['id']};end"}])
                    return query.edit_message_reply_markup(reply_markup={'inline_keyboard': inline_keyboard})
                elif ex_data[2] == 'end':
                    row_gtg['status'] = 'end'
                    cs.execute(f"UPDATE {utl.gtg} SET status='{row_gtg['status']}' WHERE id={row_gtg['id']}")
            
            inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'url': f"https://t.me/{utl.bot_username}"}])
            inline_keyboard.append([{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}])
            inline_keyboard.append([{'text': '🔄 بروزرسانی خودکار 🔄', 'callback_data': f"auto_update;{row_gtg['id']}"}])
            query.edit_message_reply_markup(reply_markup={'inline_keyboard': inline_keyboard})
            return
        if ex_data[0] == "d":
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{ex_data[1]}'")
            row_user_select = cs.fetchone()
            if row_user_select is None:
                return query.answer("❌ کاربر یافت نشد",show_alert=True)
            value = ex_data[2]
            if value == 'balance':
                change_balance = row_user_select['balance'] + int(ex_data[3])
                if change_balance <= 0:
                    if not row_user_select['balance']:
                        return query.answer("❌ امکان پذیر نیست",show_alert=True)
                    else:
                        row_user_select['balance'] = 0
                else:
                    row_user_select['balance'] = change_balance
                cs.execute(f"UPDATE {utl.users} SET balance='{row_user_select['balance']}' WHERE user_id='{row_user_select['user_id']}'")
            if value == 'is_submit_panel':
                row_user_select['is_submit_panel'] = 1 - row_user_select['is_submit_panel']
                cs.execute(f"UPDATE {utl.users} SET is_submit_panel='{row_user_select['is_submit_panel']}' WHERE user_id='{row_user_select['user_id']}'")
            else:
                if value == "admin" or ((value == "user" or value == "block") and row_user_select['status'] == 'admin'):
                    if utl.admin_id == from_id:
                        cs.execute(f"UPDATE {utl.users} SET status='{value}' WHERE user_id='{row_user_select['user_id']}'")
                    else:
                        return query.answer("⛔️ این عملکرد مخصوص ادمین اصلی است",show_alert=True)
                elif value == "block" or value == "user":
                    cs.execute(f"UPDATE {utl.users} SET status='{value}' WHERE user_id='{row_user_select['user_id']}'")
                elif value == "sendmsg":
                    cs.execute(f"UPDATE {utl.users} SET step='sendmsg;{row_user_select['user_id']}' WHERE user_id='{from_id}'")
                    return bot.send_message(chat_id=chat_id,text="پیام را ارسال کنید:\nکنسل: /cancel")
                else:
                    return
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{ex_data[1]}'")
            row_user_select = cs.fetchone()
            if row_user_select['status'] == "block":
                block = 'بلاک ✅'
                block_status = "user"
            else:
                block = 'بلاک ❌'
                block_status = "block"
            if row_user_select['status'] == "admin":
                admin = 'ادمین ✅'
                admin_status = "user"
            else:
                admin = 'ادمین ❌'
                admin_status = "admin"
            return query.edit_message_text(parse_mode='HTML',text=f"کاربر <a href='tg://user?id={row_user_select['user_id']}'>{row_user_select['user_id']}</a> (/d_{row_user_select['user_id']})",
                reply_markup={'inline_keyboard': [
                    [{'text': "ارسال پیام",'callback_data': f"d;{row_user_select['user_id']};sendmsg"}],
                    [
                        {'text': block,'callback_data': f"d;{row_user_select['user_id']};{block_status}"},
                        {'text': admin,'callback_data': f"d;{row_user_select['user_id']};{admin_status}"}
                    ]
                ]}
            )
        if ex_data[0] == "analyze":
            cs.execute(f"SELECT * FROM {utl.egroup} WHERE id='{ex_data[1]}'")
            row_egroup = cs.fetchone()
            if row_egroup is not None:
                cs.execute(f"UPDATE {utl.egroup} SET status='end' WHERE id='{row_egroup['id']}'")
                query.edit_message_reply_markup(
                    reply_markup={'inline_keyboard': [[{'text': "در حال اتمام...",'callback_data': "nazan"}]]}
                )
            else:
                query.answer("❌ آنالیز یافت نشد",show_alert=True)
            return
        if ex_data[0] == "status_analyze":
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id='{ex_data[1]}'")
            row_gtg = cs.fetchone()
            if row_gtg is not None:
                cs.execute(f"UPDATE {utl.gtg} SET status_analyze='end' WHERE id='{row_gtg['id']}'")
                query.edit_message_reply_markup(
                    reply_markup={'inline_keyboard': [[{'text': "در حال اتمام...",'callback_data': "nazan"}]]}
                )
            else:
                query.answer("❌ آنالیز یافت نشد",show_alert=True)
            return
    except RetryAfter as e:
        query.answer("−⚠️┈┅━ "+str(int(e.retry_after))+" ثانیه بعد تلاش کنید!",show_alert=True)
    except:
        pass


def private_process(update: Update, context: CallbackContext) -> None:
    # write_on_file("private_process.txt",str(update))
    bot = context.bot
    message = update.message
    from_id = message.from_user.id
    first_name = message.from_user.first_name
    username = message.from_user.username
    chat_id = message.chat.id
    message_id = message.message_id
    text = message.text
    if update.message.text:
        txtcap = update.message.text
    elif update.message.caption:
        txtcap = update.message.caption
    ex_text = text.split('_')
    
    timestamp = int(time.time())
    mydb = mysql.connector.connect(host=utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4")
    cs = mydb.cursor(dictionary=True,buffered=True)
    cs.execute(f"SELECT * FROM {utl.admini}")
    row_admin = cs.fetchone()
    
    cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{from_id}'")
    row_user = cs.fetchone()
    if row_user is None:
        cs.execute(f"INSERT INTO {utl.users} (user_id,created_at,uniq_id) VALUES ('{from_id}','{timestamp}','{uniq_id_generate(cs,10,utl.users)}')")
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{from_id}'")
        row_user = cs.fetchone()
    ex_step = row_user['step'].split(';')
    is_admin = True if from_id == utl.admin_id or row_user['status'] == 'admin' else False
    
    if row_admin['gtg_per'] or is_admin:
        if ex_text[0] == '/gtg':
            gtg_id = int(ex_text[1])
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
            row_gtg = cs.fetchone()
            if row_gtg is None:
                return message.reply_html(text="❌ یافت نشد")
            created_at = jdatetime.datetime.fromtimestamp(row_gtg['created_at']).strftime('%Y/%m/%d %H:%M:%S')
            updated_at = jdatetime.datetime.fromtimestamp(row_gtg['updated_at']).strftime('%Y/%m/%d %H:%M:%S')
            now = jdatetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            inline_keyboard = []
            if not is_admin or row_gtg['status'] == 'end':
                if not is_admin and row_gtg['status'] == 'start':
                    return
                inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'url': f"https://t.me/{utl.bot_username}"}])
            else:
                inline_keyboard.append([{'text': utl.status_gtg[row_gtg['status']], 'callback_data': f"change_status;{row_gtg['id']};none"}])
            if row_gtg['status'] != "end" or is_admin:
                inline_keyboard.append([{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}])
                inline_keyboard.append([{'text': '🔄 بروزرسانی خودکار 🔄', 'callback_data': f"auto_update;{row_gtg['id']}"}])
            
            message.reply_html(disable_web_page_preview=True,
                text="🔹️ گروه مبدا:\n"+
                    f"<code>{row_gtg['origin_id']}</code>\n"+
                    f"{row_gtg['origin']}\n"+
                    "🔹 گروه مقصد:\n"+
                    f"<code>{row_gtg['destination_id']}</code>\n"+
                    f"{row_gtg['destination']}\n\n"+
                    f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n"+
                    f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n"+
                    f"\n"+
                    f"📅️ Created: {created_at}\n"+
                    f"📅️ Updated: {updated_at}\n"+
                    f"📅 ️Now: {now}",
                reply_markup={'inline_keyboard': inline_keyboard}
            )
            return
    if not is_admin:
        return
    if text == '/start' or text == 'start' or text == '/panel' or text == 'panel' or text == 'پنل' or text == utl.menu_var or text == '/cancel':
        user_panel(update)
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        cs.execute(f"DELETE FROM {utl.gtg} WHERE user_id='{from_id}' AND status='start'")
        return
    if text == '📚 راهنما 📚':
        return message.reply_html(
            text="📚 راهنمای ربات\n\n"+
            "1️⃣ بخش تنظیمات:\n"+
            "1. در هر ای پی ای x شماره ثبت شود\n"+
            "❕ هر چقدر این عدد کم باشد بهتر است (برای کاهش میزان بن شدن اکانت ها)\n\n"+
            "2. هر اکانت در هر استفاده x اد کند\n"+
            "❕ تعیین میکنید که هر اکانت موقع استفاده شدن چقدر اد کند\n\n"+
            "3. هر اکانت هر x ساعت استفاده شود\n"+
            "❕ تعیین میکنید هر اکانت هر چند ساعت استفاده شود (در بخش آمار اکانت های قابلیت اد)\n\n"+
            "4. تغییر پسورد و خروج از بقیه سشن ها\n"+
            "❕ با فعال کردن این مورد پسود دو مرحله ای اکانت ها فعال یا عوض خواهد شد\n\n"+
            "5. اکانت ها گروه ها را ترک کنند\n"+
            "❕ با فعال کردن این مورد اکانت ها هر چند روز یکبار خودکار از گروه ها لفت می دهند\n\n"+
            "6. حذف خودکار اکانت های ثبت نشده\n"+
            "❕ با فعال کردن این گزینه اکانت های ثبت نشده خودکار از ربات حذف خواهند شد\n\n"+
            "7. دسترسی همه به شناسه سفارش\n"+
            "❕ با فعال کردن این گزینه همه به جزئیات سفارش دسترسی خواهند داشت (مثال /gtg_x)\n\n"+
            "8. نوع آنالیز\n"+
            "❕ نوع آنالیز دیتابیس از اطلاعات ثبت شده در دیتابیس استفاده می کند و آنالیز لحظه ای در لحظه همه اکانت های تکراری دو گروه سفارش را شناسایی می کند\n"+
            "❕ سرعت آنالیز دیتابیس بیشتر است\n\n"+
            "9. نوع اد\n"+
            "❕ نوع عادی یک به یک اکانت ها را بررسی میکند و نوع حرفه ای با هم بررسی میکند\n"+
            "❕ سرعت اد حرفه ای 10 تا 15 برابر بیشتر از عادی است\n"+
            "❗️ اگر ربات را روی هاست ران کردید توصیه نمیشه از نوع حرفه ای استفاده کنید\n\n"+
            "2️⃣ آنالیز:\n"+
            "❕ در این بخش میتوانید گروه خود را آنالیز کنید\n\n"+
            "3️⃣ ایجاد سفارش:\n"+
            "❕ در این بخش ابتدا سفارش خود را ثبت کنید و صبر کنید تا آنالیز تمام شود. بعد از اتمام آنالیز هر کدام از اعضا که میخواهید را از منو انتخاب کنید تا سفارش شما ثبت شود\n\n"+
            "4️⃣ افزودن اکانت:\n"+
            "❕ شماره خود را همراه با پیش شماره ارسال کنید و بقیه مراحل را ادامه دهید تا اکانت ثبت شود\n\n"+
            "5️⃣ افزودن api:\n"+
            "❕ ای پی ای را سایت تلگرام my.telegram.org دریافت کنید و ثبت کنید\n\n"+
            "➖➖➖➖➖➖\n"+
            "⚠️ نکات مهم:\n"+
            "‼️ به هیچ وجه چند نفر همزمان با ربات کار نکنند\n"+
            "‼️ اگر از هاست استفاده میکنید توصیه میشه از نوع اد حرفه ای استفاده نکنید\n"+
            "‼️ هنگام سفارش فعال یا آنالیز یا ... در بخش تنظیمات تغییراتی ایجاد نکنید\n"+
            "\n"+
            "\n"
        )
    if text == '➕ افزودن اکانت':
        row_apis = select_api(cs,row_admin['api_per_number'])
        if row_apis is None:
            return message.reply_html(text="❌ هیچ Api ای یافت نشد") 
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id='{from_id}' AND status='first_level'")
        row_mbots = cs.fetchone()
        if row_mbots is not None:
            return message.reply_html(text="❌ برخی از شماره های ثبت شده شما در وضعیت اولیه قرار دارند لطفا آن ها را تعیین تکلیف کنید")
        cs.execute(f"UPDATE {utl.users} SET step='add_acc;phone' WHERE user_id='{from_id}'")
        message.reply_html(
            text="پنل ادمین » افزودن اکانت » ارسال شماره:",
            reply_markup={'resize_keyboard': True,'keyboard': [[{'text': utl.menu_var}]]}
        )
        return
    if ex_step[0] == 'add_acc':
        if ex_step[1] == 'phone':
            phone = text.replace("+","").replace(" ","")
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE phone='{phone}'")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                row_apis = select_api(cs,row_admin['api_per_number'])
                if row_apis is not None:
                    uniq_id = uniq_id_generate(cs,10,utl.mbots)
                    cs.execute(f"INSERT INTO {utl.mbots} (creator_user_id,phone,last_order_at,api_id,api_hash,created_at,uniq_id) VALUES ('{from_id}','{phone}','0','{row_apis['api_id']}','{row_apis['api_hash']}','{timestamp}','{uniq_id}')")
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{uniq_id}'")
                    row_mbots = cs.fetchone()
                else:
                    return message.reply_html(text="❌ هیچ Api ای یافت نشد")
            info_msg = message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.account.py {from_id} first_level {row_mbots['id']}")
            bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
            return
        if ex_step[1] == 'code':
            mbots_id = int(ex_step[2])
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
            row_mbots = cs.fetchone()
            try:
                ex_nl_text = text.split("\n")
                if len(ex_nl_text[0]) > 200 or len(ex_nl_text[1]) > 200:
                    return message.reply_html(text="❌ ورودی نادرست")
                cs.execute(f"UPDATE {utl.mbots} SET code='{ex_nl_text[0]}',password='{ex_nl_text[1]}' WHERE id={row_mbots['id']}")
            except:
                cs.execute(f"UPDATE {utl.mbots} SET code='{text}' WHERE id={row_mbots['id']}")
            info_msg = message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.account.py {from_id} code {row_mbots['id']}")
            bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
            user_panel(update)
            return
    if text == '➕ ایجاد سفارش':
        cs.execute(f"SELECT * FROM {utl.gtg} WHERE status NOT IN ('end')")
        row_gtg = cs.fetchone()
        if row_gtg is not None:
            return message.reply_html(text="❌ سفارش فعال وجود دارد")
        limit_per_h = row_admin['limit_per_h'] * 3600
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC")
        if cs.fetchone() == None:
            return message.reply_html(text="❌ اکانتی برای انجام سفارش یافت نشد")
        cs.execute(f"UPDATE {utl.users} SET step='create_order;info' WHERE user_id='{from_id}'")
        return message.reply_html(disable_web_page_preview=True,
            text="پنل ادمین » ایجاد سفارش » ارسال اطلاعات:\n\n"+
            "اطلاعات را به این شکل و در سه خط ارسال کنید:\n"+
            "لینک گروه مبدا\n"+
            "لینک گروه مقصد\n"+
            "تعداد اعضا برای انتقال\n\n"+
            "مثال:\n" +
            "https://t.me/source\n" +
            "https://t.me/target\n" +
            "500\n" +
            "\n" +
            "❗️ اعضای گروه مبدا به گروه مقصد منتقل می شوند",
            reply_markup={'resize_keyboard': True,'keyboard': [[{'text': utl.menu_var}]]}
        )
    if ex_step[0] == 'create_order':
        if ex_step[1] == 'info':
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE status NOT IN ('end')")
            row_gtg = cs.fetchone()
            if row_gtg is not None:
                return message.reply_html(text="❌ سفارش فعال وجود دارد")
            try:
                ex_nl_text = text.split("\n")
                source = ex_nl_text[0].replace("/+","/joinchat/")
                target = ex_nl_text[1].replace("/+","/joinchat/")
                count = int(ex_nl_text[2])
                ex_nl_text = text.split("\n")
                if len(source) > 200 or len(target) > 200 or len(ex_nl_text) != 3:
                    return message.reply_html(text="❌ مقادیر نامعتبر")
                if source[0:13] != "https://t.me/":
                    return message.reply_html(text="❌ گروه مبدا غیر معتبر")
                if target[0:13] != "https://t.me/":
                    return message.reply_html(text="❌ گروه مقصد غیر معتبر")
            except:
                return message.reply_html(text="❌ طبق نمونه ارسال کنید")
            
            uniq_id = uniq_id_generate(cs,10,utl.gtg)
            cs.execute(f"INSERT INTO {utl.gtg} (user_id,origin,destination,count,created_at,updated_at,uniq_id) VALUES ('{from_id}','{source}','{target}','{count}','{timestamp}','{timestamp}','{uniq_id}')")
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE uniq_id='{uniq_id}'")
            row_gtg = cs.fetchone()
            cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
            
            info_msg = message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.analyze.py {from_id} check {row_gtg['id']}")
            bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
            return
        if ex_step[1] == 'type_users':
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE user_id='{from_id}' AND status='start'")
            row_gtg = cs.fetchone()
            if row_gtg is not None:
                info_msg = message.reply_html(text="در حال پیکربندی...")
                if text == 'همه کاربران':
                    type_users = 'users_all'
                    cs.execute(f"SELECT * FROM {utl.analyze} WHERE is_bad=0")
                    max_users = cs.rowcount
                elif text == 'کاربران واقعی':
                    type_users = 'users_real'
                    cs.execute(f"DELETE FROM {utl.analyze} WHERE is_bad=0 AND is_real=0")
                elif text == 'کاربران فیک':
                    type_users = 'users_fake'
                    cs.execute(f"DELETE FROM {utl.analyze} WHERE is_bad=0 AND is_fake=0")
                elif text == 'کاربران آنلاین':
                    type_users = 'users_online'
                    cs.execute(f"DELETE FROM {utl.analyze} WHERE is_bad=0 AND is_online=0")
                elif text == 'کاربران دارای شماره':
                    type_users = 'users_has_phone'
                    cs.execute(f"DELETE FROM {utl.analyze} WHERE is_bad=0 AND is_phone=0")
                else:
                    return message.reply_html(text="❌ صرفا از منو انتخاب کنید")
                cs.execute(f"SELECT * FROM {utl.analyze} WHERE is_bad=0")
                max_users = cs.rowcount
                cs.execute(f"UPDATE {utl.gtg} SET status='doing',max_users='{max_users}',type_users='{type_users}',created_at='{timestamp}',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
                user_panel(update,
                    text=f"✅ سفارش با موفقیت ثبت شد و در حال انجام است\n\n"+
                    f"♻️ /gtg_{row_gtg['id']}"
                )
                bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
            else:
                message.reply_html(text="❌ سفارش یافت نشد")
            return
    if text == '🔮 آنالیز گروه 🔮':
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted'")
        row_mbots = cs.fetchone()
        if row_mbots is not None:
            cs.execute(f"UPDATE {utl.users} SET step='analyze;' WHERE user_id='{from_id}'")
            message.reply_html(
                text="پنل ادمین » آنالیز گروه » ارسال لینک:\n\n"+
                "❗️ لینک عضویت دائمی گروه را وارد کنید نه لینک موقت تولید شده توسط ربات ها",
                reply_markup={'resize_keyboard': True,'keyboard': [[{'text': utl.menu_var}]]}
            )
        else:
            message.reply_html(text="❌ اکانتی برای انجام سفارش یافت نشد")
        return
    if ex_step[0] == 'analyze':
        uniq_id = uniq_id_generate(cs,10,utl.egroup)
        text = text.replace("/+","/joinchat/")
        cs.execute(f"INSERT INTO {utl.egroup} (user_id,link,created_at,updated_at,uniq_id) VALUES ({from_id},'{text}','{timestamp}','{timestamp}','{uniq_id}')")
        cs.execute(f"SELECT * FROM {utl.egroup} WHERE uniq_id='{uniq_id}'")
        row_egroup = cs.fetchone()
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        
        info_msg = message.reply_html(text="در حال بررسی ...")
        os.system(f"python3 tl.analyze.py {from_id} analyze {row_egroup['id']}")
        bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
        user_panel(update)
        return
    if text == '➕ افزودن api':
        cs.execute(f"UPDATE {utl.users} SET step='add_api;' WHERE user_id='{from_id}'")
        return message.reply_html(
            text="پنل ادمین » افزودن api » ارسال اطلاعات:\n\n"+
            "اطلاعات را به این شکل و در دو خط ارسال کنید:\n"+
            "api id\n"+
            "api hash",
            reply_markup={'resize_keyboard': True,'keyboard': [[{'text': utl.menu_var}]]}
        )
    if ex_step[0] == 'add_api':
        try:
            ex_nl_text = text.split("\n")
            if len(ex_nl_text[0]) > 200 or len(ex_nl_text[1]) > 200 or len(ex_nl_text) != 2:
                return message.reply_html(text="❌ ورودی نادرست")
            api_id = ex_nl_text[0]
            api_hash = ex_nl_text[1]
        except:
            return message.reply_html(text="❌ طبق نمونه ارسال کنید")
        cs.execute(f"SELECT * FROM {utl.apis} WHERE api_id='{api_id}' OR api_hash='{api_hash}'")
        if cs.fetchone() is not None:
            return message.reply_html(text="❌ این api قبلا ثبت شده")
        cs.execute(f"INSERT INTO {utl.apis} (api_id,api_hash) VALUES ('{api_id}','{api_hash}')")
        cs.execute(f"UPDATE {utl.users} SET step='add_api;' WHERE user_id='{from_id}'")
        message.reply_html(
            text="✅ با موفقیت افزوده شد\n\n"+
            "ای پی ای دیگری ارسال کنید:",
            reply_markup={'resize_keyboard': True,'keyboard': [[{'text': utl.menu_var}]]}
        )
        return 
    if text == "⚙️ تنظیمات ⚙️":
        change_pass = "✅ تغییر/تنظیم پسورد دومرحله ای ✅" if row_admin['change_pass'] else "❌ تغییر/تنظیم پسورد دومرحله ها ❌"
        exit_session = "✅ خروج از بقیه سشن ها ✅" if row_admin['exit_session'] else "❌ خروج از بقیه سشن ها ❌"
        leave_per = "✅ اکانت ها گروه ها را ترک کنند ✅" if row_admin['leave_per'] else "❌ اکانت ها گروه ها را ترک کنند ❌"
        delete_first_levels = "✅ حذف خودکار اکانت های ثبت نشده ✅" if row_admin['delete_first_levels'] else "❌ حذف خودکار اکانت های ثبت نشده ❌"
        gtg_per = "✅ دسترسی همه به شناسه سفارش ✅" if row_admin['gtg_per'] else "❌ دسترسی همه به شناسه سفارش ❌"
        type_analyze = "نوع آنالیز سفارش: لحظه ای" if row_admin['type_analyze'] else "نوع آنالیز سفارش: دیتابیس"
        type_add = "نوع اد: حرفه ای" if row_admin['type_add'] else "نوع اد: عادی"
        
        message.reply_html(text=f"پنل تنظیمات:",
            reply_markup={'inline_keyboard': [
                [{'text': f"در هر ای پی ای {row_admin['api_per_number']} شماره ثبت شود",'callback_data': f"settings;api_per_number;guide"}],
                [
                    {'text': '+10','callback_data': f"settings;api_per_number;+10"},
                    {'text': '+5','callback_data': f"settings;api_per_number;+5"},
                    {'text': '+1','callback_data': f"settings;api_per_number;+1"},
                    {'text': '-1','callback_data': f"settings;api_per_number;-1"},
                    {'text': '-5','callback_data': f"settings;api_per_number;-5"},
                    {'text': '-10','callback_data': f"settings;api_per_number;-10"},
                ],
                [{'text': f"هر اکانت در هر استفاده {row_admin['add_per_h']} اد کند",'callback_data': f"settings;add_per_h;guide"}],
                [
                    {'text': '+10','callback_data': f"settings;add_per_h;+10"},
                    {'text': '+5','callback_data': f"settings;add_per_h;+5"},
                    {'text': '+1','callback_data': f"settings;add_per_h;+1"},
                    {'text': '-1','callback_data': f"settings;add_per_h;-1"},
                    {'text': '-5','callback_data': f"settings;add_per_h;-5"},
                    {'text': '-10','callback_data': f"settings;add_per_h;-10"},
                ],
                [{'text': f"هر اکانت هر {row_admin['limit_per_h']} ساعت استفاده شود",'callback_data': f"settings;limit_per_h;guide"}],
                [
                    {'text': '+10','callback_data': f"settings;limit_per_h;+10"},
                    {'text': '+5','callback_data': f"settings;limit_per_h;+5"},
                    {'text': '+1','callback_data': f"settings;limit_per_h;+1"},
                    {'text': '-1','callback_data': f"settings;limit_per_h;-1"},
                    {'text': '-5','callback_data': f"settings;limit_per_h;-5"},
                    {'text': '-10','callback_data': f"settings;limit_per_h;-10"},
                ],
                [{'text': change_pass,'callback_data': f"settings;change_pass;guide"}],
                [{'text': exit_session,'callback_data': f"settings;exit_session;guide"}],
                [{'text': leave_per,'callback_data': f"settings;leave_per;guide"}],
                [{'text': delete_first_levels,'callback_data': f"settings;delete_first_levels;guide"}],
                [{'text': gtg_per,'callback_data': f"settings;gtg_per;guide"}],
                [{'text': type_analyze,'callback_data': f"settings;type_analyze;guide"}],
                [{'text': type_add,'callback_data': f"settings;type_add;guide"}],
            ]}
        )
        return
    
    if text == '📊 آمار 📊':
        now = jdatetime.datetime.now()
        time_today = jdatetime.datetime(day = now.day,month = now.month,year = now.year).timestamp()
        time_yesterday = time_today - 86400
        
        cs.execute(f"SELECT id FROM {utl.gtg}")
        orders_count_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.gtg} WHERE created_at>={time_today}")
        orders_count_today = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.gtg} WHERE created_at<{time_today} AND created_at>={time_yesterday}")
        orders_count_yesterday = cs.rowcount
        
        cs.execute(f"SELECT id FROM {utl.moveds} WHERE status='join'")
        orders_count_moved_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.moveds} WHERE created_at>={time_today} AND status='join'")
        orders_count_moved_today = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.moveds} WHERE created_at<{time_today} AND created_at>={time_yesterday} AND status='join'")
        orders_count_moved_yesterday = cs.rowcount
        
        cs.execute(f"SELECT id FROM {utl.mbots}")
        accs_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted'")
        accs_active = cs.rowcount
        limit_per_h = row_admin['limit_per_h'] * 3600
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp}")
        accs_ability_ad = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='restrict'")
        accs_restrict = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='first_level'")
        accs_first_level = cs.rowcount
        
        cs.execute(f"SELECT id FROM {utl.apis}")
        apis_count_all = cs.rowcount
        return message.reply_html(text="پنل ادمین » آمار:\n\n"+
            "🛍 سفارشات:\n"+
            f"🟢 امروز: {orders_count_today} ({orders_count_moved_today:,})\n"+
            f"⚪️ دیروز: {orders_count_yesterday} ({orders_count_moved_yesterday:,})\n"+
            f"🔴 کل: {orders_count_all} ({orders_count_moved_all:,})\n\n"+
            "🤖 اکانت ها:\n"+
            f"💢️️ کل: {accs_all}\n"+
            f"✅️ فعال: {accs_active}\n"+
            f"♻️️ قابلیت اد: {accs_ability_ad}\n"+
            f"⚠️ محدود شده: {accs_restrict}\n\n"+
            f"⛔️ ثبت نشد: {accs_first_level}\n\n"+
            f"🔘 تعداد api ها: {apis_count_all}"
        )
    if text == '📋 سفارشات':
        cs.execute(f"SELECT * FROM {utl.gtg} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return message.reply_html(text="❌ لیست خالی است")
        output = ""
        i = 1
        for row in result:
            created_at = jdatetime.datetime.fromtimestamp(row['created_at'])
            output += f"{i}. /gtg_{row['id']}\n"
            output += f"🔹️ گروه مبدا: {row['origin']}\n"
            output += f"🔹️ گروه مقصد: {row['destination']}\n"
            output += f"🔹️ تعداد ارسال شده/درخواستی: [{row['count']}/{row['count_moved']}]\n"
            output += f"🔹️ وضعیت: {utl.status_gtg[row['status']]}\n"
            output += f"📅️ {created_at.strftime('%Y/%m/%d %H:%M')}\n\n"
            i += 1
        output = "پنل ادمین » سفارشات:\n\n"+output
        cs.execute(f"SELECT id FROM {utl.gtg}")
        ob = Pagination(update,"orders",output,step_page,cs.rowcount)
        ob.processMessage()
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        return
    if text == '📋 اکانت ها':
        cs.execute(f"SELECT * FROM {utl.mbots} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return message.reply_html(text="❌ لیست خالی است")
        return message.reply_html(
            text="پنل ادمین » اکانت ها:",
            reply_markup={'inline_keyboard': [
                [
                    {'text': "💢 همه 💢", 'callback_data': f"pg;accounts;1"},
                ],
                [
                    {'text': "⛔️ ثبت نشده", 'callback_data': f"pg;first_level;1"},
                    {'text': "❌ محدود شده", 'callback_data': f"pg;restrict;1"}
                ],
                [
                    {'text': "♻️ قابلیت اد", 'callback_data': f"pg;adability;1"},
                    {'text': "✅ فعال", 'callback_data': f"pg;submitted;1"}
                ]
            ]}
        )
    if text == '📋 لیست api ها':
        cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return message.reply_html(text="❌ لیست خالی است")
        output = ""
        i = 1
        for row in result:
            output += f"{i}. حذف: /dela_{row['id']}\n🔴️ Api ID: <code>{row['api_id']}</code>\n🔴️ Api Hash: <code>{row['api_hash']}</code>\n\n"
            i += 1
        output = "پنل ادمین » لیست api ها:\n\n"+output
        cs.execute(f"SELECT id FROM {utl.apis}")
        ob = Pagination(update,"apis",output,step_page,cs.rowcount)
        ob.processMessage()
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        return
    if ex_text[0] == '/status':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return message.reply_html(text="❌ یافت نشد")
        info_msg = message.reply_html(text="در حال بررسی ...")
        os.system(f"python3 tl.account.py {from_id} check {row_mbots['id']}")
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
        return message.reply_html(text=f"حذف اکانت: /delete_{row_mbots['id']}")
    if ex_text[0] == '/delete':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return message.reply_html(text="❌ یافت نشد")
        return message.reply_html(
            reply_to_message_id=message_id,
            text=f"❌ حذف اکانت: {row_mbots['phone']}\n\n"+
            f"without api: /deleteconfirm_{ex_text[1]}\n"
            f"with api: /deleteconfirmapi_{ex_text[1]}\n"
        )
    if ex_text[0] == '/deleteconfirm':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return message.reply_html(text="❌ یافت نشد")
        try:
            cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row_mbots['id']}")
            os.remove(f"{directory}/sessions/{row_mbots['phone']}.session")
        except:
            pass
        return message.reply_html(text=f"✅ با موفقیت حذف شد")
    if ex_text[0] == '/deleteconfirmapi':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return message.reply_html(text="❌ یافت نشد")
        try:
            cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row_mbots['id']}")
            cs.execute(f"DELETE FROM {utl.apis} WHERE api_id='{row_mbots['api_id']}'")
            os.remove(f"{directory}/sessions/{row_mbots['phone']}.session")
        except:
            pass
        return message.reply_html(text=f"✅ با موفقیت حذف شد")
    if ex_text[0] == '/ex':
        egroup_id = int(ex_text[2])
        cs.execute(f"SELECT * FROM {utl.egroup} WHERE id={egroup_id}")
        row_egroup = cs.fetchone()
        if row_egroup is None:
            return message.reply_html(text="❌ یافت نشد")
        info_msg = message.reply_html(text="در حال ارسال ...")
        if ex_text[1] == 'a':
            bot.send_document(chat_id=chat_id,document=open(f"{directory}/export/{row_egroup['chat_id']}/users_all_id.json","rb"),caption='کاربران شناسایی شده')
        elif ex_text[1] == 'u':
            bot.send_document(chat_id=chat_id,document=open(f"{directory}/export/{row_egroup['chat_id']}/users_real.json","rb"),caption='کاربران شناسایی شده (واقعی)')
        elif ex_text[1] == 'f':
            bot.send_document(chat_id=chat_id,document=open(f"{directory}/export/{row_egroup['chat_id']}/users_fake.json","rb"),caption='کاربران شناسایی شده (فیک)')
        elif ex_text[1] == 'n':
            bot.send_document(chat_id=chat_id,document=open(f"{directory}/export/{row_egroup['chat_id']}/users_has_phone.json","rb"),caption='کاربران شناسایی شده (دارای شماره)')
        elif ex_text[1] == 'o':
            bot.send_document(chat_id=chat_id,document=open(f"{directory}/export/{row_egroup['chat_id']}/users_online.json","rb"),caption='کاربران شناسایی شده (آنلاین)')
        bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
        return bot.delete_message(chat_id=from_id,message_id=message_id)
    if ex_text[0] == '/dela':
        apis_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.apis} WHERE id={apis_id}")
        row_apis = cs.fetchone()
        if row_apis is None:
            return message.reply_html(text="❌ یافت نشد")
        return message.reply_html(
            reply_to_message_id=message_id,
            text=f"❌ حذف ای پی ای: {row_apis['api_id']}\n\n"+
            f"/delaconfirm_{ex_text[1]}"
        )
    if ex_text[0] == '/delaconfirm':
        apis_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.apis} WHERE id={apis_id}")
        row_apis = cs.fetchone()
        if row_apis is None:
            return message.reply_html(text="❌ یافت نشد")
        cs.execute(f"DELETE FROM {utl.apis} WHERE id={row_apis['id']}")
        return message.reply_html(text=f"✅ با موفقیت حذف شد")
    if ex_text[0] == "/d":
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{ex_text[1]}'")
        row_user_select = cs.fetchone()
        if row_user_select is None:
            return message.reply_html(text=f"❌ کاربر یافت نشد")
        if row_user_select['status'] == "block":
            block = 'بلاک ✅'
            block_status = "user"
        else:
            block = 'بلاک ❌'
            block_status = "block"
        if row_user_select['status'] == "admin":
            admin = 'ادمین ✅'
            admin_status = "user"
        else:
            admin = 'ادمین ❌'
            admin_status = "admin"
        return message.reply_html(text=f"کاربر <a href='tg://user?id={row_user_select['user_id']}'>{row_user_select['user_id']}</a> (/d_{row_user_select['user_id']})",
            reply_markup={'inline_keyboard': [
                [{'text': "ارسال پیام",'callback_data': f"d;{row_user_select['user_id']};sendmsg"}],
                [
                    {'text': block,'callback_data': f"d;{row_user_select['user_id']};{block_status}"},
                    {'text': admin,'callback_data': f"d;{row_user_select['user_id']};{admin_status}"}
                ]
            ]}
        )
    if ex_step[0] == 'sendmsg':
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{ex_step[1]}'")
        row_user_select = cs.fetchone()
        if row_user_select is None:
            return message.reply_html(text=f"❌ کاربر یافت نشد")
        try:
            if update.message.text:
                bot.send_message(chat_id=chat_id,disable_web_page_preview=True,parse_mode='HTML',
                text=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
            )
            elif update.message.photo:
                bot.send_photo(chat_id=chat_id,parse_mode='HTML',
                    photo=update.message.photo[len(update.message.photo) - 1].file_id,
                    caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                )
            elif update.message.video:
                bot.send_video(chat_id=chat_id,parse_mode='HTML',
                    video=update.message.video.file_id,
                    caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                )
            elif update.message.audio:
                bot.send_audio(chat_id=chat_id,parse_mode='HTML',
                    audio=update.message.audio.file_id,
                    caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                )
            elif update.message.voice:
                bot.send_voice(chat_id=chat_id,parse_mode='HTML',
                    voice=update.message.voice.file_id,
                    caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                )
            elif update.message.document:
                bot.send_document(chat_id=chat_id,parse_mode='HTML',
                    document=update.message.document.file_id,
                    caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                )
            else:
                return message.reply_html(text="⛔️ پیام پشتیبانی نمی شود")
        except:
            return message.reply_html(text="❌ مشکلی در ارسال پیام رخ داد")
        cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
        return message.reply_html(text="✅ پیام با موفقیت ارسال شد")
        

def main() -> None:
    updater = Updater(utl.token)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(MessageHandler(Filters.chat_type.private & Filters.update.message & Filters.update, private_process, run_async=True))
    dispatcher.add_handler(CallbackQueryHandler(callbackquery_process,run_async=True))
    
    # updater.start_polling(drop_pending_updates=True)
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
