#!/usr/bin/env python3

import os
import time
import datetime
import string
import random
import mysql.connector
from telethon.sync import TelegramClient
from telethon import functions, types, errors
import utility as utl

directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))
try:
    with open(f"{directory}/pid/{filename}.txt", "r") as file:
        pid = int(file.read())
    os.kill(pid, 0)
except OSError:
    with open(f"{directory}/pid/{filename}.txt", "w") as file:
        file.write(str(os.getpid()))
else:
    os.system(f"kill -9 {pid}")
    time.sleep(2)
    try:
        os.kill(pid, 0)
    except OSError:
        with open(f"{directory}/pid/{filename}.txt", "w") as file:
            file.write(str(os.getpid()))
    else:
        print("Try again!")
        exit()
print(f"run: {filename}")


def uniq_id_generate(cs,num):
    return str(''.join(random.choices(string.ascii_uppercase + string.digits, k = num)))


def leave(cs,row_mbots):
    try:
        client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}", api_id=row_mbots['api_id'], api_hash=row_mbots['api_hash'])
        client.connect()
        if not client.is_user_authorized():
            cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
        else:
            for dialog in client.iter_dialogs():
                chat_id = dialog.entity.id
                if isinstance(dialog.entity, types.Channel):
                    client(functions.channels.LeaveChannelRequest(channel=dialog.entity))
                elif isinstance(dialog.entity, types.User):
                    if chat_id == 178220800:
                        continue
                    client.delete_dialog(entity=dialog.entity)
    except Exception as e:
        print(f"{row_mbots['phone']}: {e}")
    finally:
        try:
            client.disconnect()
        except:
            pass

while True:
    try:
        mydb = mysql.connector.connect(host = utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4")
        cs = mydb.cursor(dictionary=True,buffered=True)
        cs.execute(f"SELECT * FROM {utl.admini}")
        row_admin = cs.fetchone()
        timestamp = int(time.time())
        
        cs.execute(f"UPDATE {utl.mbots} SET status='submitted' WHERE status='restrict' AND end_restrict<{timestamp}")
        if row_admin['delete_first_levels']:
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='first_level' AND ({timestamp}-created_at)>86400")
            result = cs.fetchall()
            for row in result:
                try:
                    cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row['id']}")
                    os.remove(f"{directory}/sessions/{row['phone']}.session")
                except:
                    pass
        if row_admin['exit_session']:
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE is_exit_session=0 AND (status='submitted' OR status='restrict') AND ({timestamp}-exit_session_at)>43200")
            for row in cs.fetchall():
                try:
                    cs.execute(f"UPDATE {utl.mbots} SET exit_session_at='{timestamp}' WHERE phone='{row['phone']}'")
                    client = TelegramClient(session=f"{directory}/sessions/{row['phone']}", api_id=row['api_id'], api_hash=row['api_hash'])
                    client.connect()
                    if not client.is_user_authorized():
                        cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE phone='{row['phone']}'")
                        print(f"{row['phone']}: first_level")
                    else:
                        is_ok = True
                        for session in client(functions.account.GetAuthorizationsRequest()).authorizations:
                            if not session.current:
                                if (timestamp - session.date_created.timestamp()) > 90000:
                                    try:
                                        client(functions.account.ResetAuthorizationRequest(hash=session.hash))
                                        print(f"{row['phone']}: Exit Session")
                                    except:
                                        is_ok = False
                                else:
                                    is_ok = False
                        if is_ok:
                            cs.execute(f"UPDATE {utl.mbots} SET is_exit_session=1 WHERE phone='{row['phone']}'")
                except Exception as e:
                    print("Error: " + str(e))
                finally:
                    try:
                        client.disconnect()
                    except:
                        pass
        if row_admin['change_pass']:
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE is_change_pass=0 AND (status='submitted' OR status='restrict') AND ({timestamp}-change_pass_at)>43200")
            for row in cs.fetchall():
                try:
                    cs.execute(f"UPDATE {utl.mbots} SET change_pass_at='{timestamp}' WHERE phone='{row['phone']}'")
                    client = TelegramClient(session=f"{directory}/sessions/{row['phone']}", api_id=row['api_id'], api_hash=row['api_hash'])
                    client.connect()
                    if not client.is_user_authorized():
                        cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE phone='{row['phone']}'")
                        print(f"{row['phone']}: first_level")
                    else:
                        try:
                            new_password = uniq_id_generate(cs,10)
                            if row['password'] is None or row['password'] == '':
                                client.edit_2fa(new_password=new_password)
                            else:
                                client.edit_2fa(current_password=row['password'],new_password=new_password)
                            cs.execute(f"UPDATE {utl.mbots} SET password='{new_password}',is_change_pass=1 WHERE phone='{row['phone']}'")
                            print(f"{row['phone']}: Password Changed")
                        except Exception as e:
                            if "you entered is invalid" in str(e):
                                print(f"{row['phone']}: Password Invalid")
                                cs.execute(f"UPDATE {utl.mbots} SET is_change_pass=1 WHERE phone='{row['phone']}'")
                            else:
                                print("Error Password" + str(e))
                except Exception as e:
                    print("Error: " + str(e))
                finally:
                    try:
                        client.disconnect()
                    except:
                        pass
        if row_admin['leave_per']:
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE (status='submitted' OR status='restrict') AND ({timestamp}-last_leve_at)>604800")
            for row_mbots in cs.fetchall():
                try:
                    cs.execute(f"UPDATE {utl.mbots} SET last_leve_at='{timestamp}' WHERE id='{row_mbots['id']}'")
                    leave(cs,row_mbots)
                except:
                    pass
        end_restrict = int(time.time()) + 86400
        cs.execute(f"SELECT {utl.mbots}.id as id,COUNT(*) as count_add FROM {utl.moveds} INNER JOIN {utl.mbots} ON {utl.moveds} .bot_id={utl.mbots}.id WHERE {utl.moveds}.status='join' AND {utl.mbots}.status='submitted' AND ({timestamp}-{utl.moveds}.created_at)<86400 GROUP BY {utl.moveds}.bot_id HAVING count_add>=35")
        result = cs.fetchall()
        for row in result:
            cs.execute(f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row['id']}")
    except:
        pass
    time.sleep(60)
