import requests
import json
import os
from time import sleep

class RubikaBot:
    def __init__(self):
        self.base_url = 'https://messengerg2c280.iranlms.ir/'
        self.session = requests.Session()
        self.phone_number = None
        self.authenticated = False

    def login(self, phone_number):
        self.phone_number = phone_number
        print(f"در حال ارسال کد تأیید به شماره تلفن {phone_number}...")
        
        # ارسال درخواست برای دریافت کد تأیید
        try:
            url = f'{self.base_url}auth/send_code'
            response = self.session.post(url, json={'phone_number': self.phone_number})
            response_data = response.json()
            
            if response_data.get('status') == 'OK':
                print("کد تأیید به شماره تلفن ارسال شده است.")
                return True
            else:
                print("خطا در ارسال کد تأیید:", response_data.get('status'))
                return False
        except requests.exceptions.RequestException as e:
            print("خطا در اتصال به API:", e)
            return False

    def verify_code(self, verification_code):
        print("در حال تأیید کد...")
        try:
            url = f'{self.base_url}auth/verify_code'
            response = self.session.post(url, json={'phone_number': self.phone_number, 'code': verification_code})
            response_data = response.json()
            
            if response_data.get('status') == 'OK':
                print("تأیید با موفقیت انجام شد!")
                self.authenticated = True
                return True
            else:
                print("خطا در تأیید کد:", response_data.get('status'))
                return False
        except requests.exceptions.RequestException as e:
            print("خطا در اتصال به API:", e)
            return False

    def download_files(self, links, save):
        print('   \033[1;33mStarting to download Files . . .\n\033[1;32m')
        for link in links:
            try:
                get_info = bot.get_link_info(link)
                guid = get_info['object_guid']
                message_id = get_info['message_id']
                don = bot.download_file(guid, message_id, save=save)
                print(don, '\n')
                if not save:
                    os.remove(don['file_inline']['file_name'])
                sleep(8)
            except Exception as e:
                print("خطا در دانلود فایل:", e)

# استفاده از کلاس
if __name__ == "__main__":
    bot = RubikaBot()
    
    # ورود به حساب کاربری
    phone_number = input("لطفا شماره تلفن خود را وارد کنید (با کد کشور): ")
    
    if bot.login(phone_number):
        verification_code = input("لطفا کد تأیید را وارد کنید: ")
        if bot.verify_code(verification_code):
            # اگر تأیید شد، دانلود پست‌ها را آغاز کنید
            links = [
                'link1',  # لینک‌های پست‌ها را وارد کنید
                'link2',
                'link3'
            ]
            save = input('آیا می‌خواهید فایل‌های دانلود شده ذخیره شوند؟ [y / n]: ').lower() == 'y'
            bot.download_files(links, save)