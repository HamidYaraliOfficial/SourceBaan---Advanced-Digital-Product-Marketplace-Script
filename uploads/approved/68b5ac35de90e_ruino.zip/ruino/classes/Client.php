<?php
// Client.php

class Connection {
    private $client;
    public $session;

    public function __construct(Client $client) {
        $this->client = $client;
        $this->session = curl_init();
        curl_setopt($this->session, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->session, CURLOPT_SSL_VERIFYPEER, false);
        
        if ($this->client->proxy) {
            curl_setopt($this->session, CURLOPT_PROXY, $this->client->proxy);
        }
    }

    public function send(
        string $apiVersion,
        array $input,
        string $method,
        string $url,
        array $client
    ): array {
        $payload = [
            'api_version' => $apiVersion,
            'auth' => $this->client->auth,
            'client' => $client,
            'data' => $input,
            'method' => $method,
        ];

        curl_setopt($this->session, CURLOPT_URL, $url);
        curl_setopt($this->session, CURLOPT_POST, true);
        curl_setopt($this->session, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($this->session, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);

        $response = curl_exec($this->session);
        $httpCode = curl_getinfo($this->session, CURLINFO_HTTP_CODE);

        if ($response === false) {
            $error = curl_error($this->session);
            $this->client->logger->error("cURL error: $error");
            throw new Exception("cURL error: $error");
        }

        if ($httpCode !== 200) {
            $this->client->logger->error("HTTP error: $httpCode");
            throw new Exception("HTTP error: $httpCode");
        }

        return json_decode($response, true) ?? [];
    }

    public function close(): void {
        if ($this->session) {
            curl_close($this->session);
            $this->session = null;
        }
    }
}

class Logger {
    public function info(string $message): void {
        echo "[INFO] " . date('Y-m-d H:i:s') . " - $message\n";
    }

    public function error(string $message): void {
        echo "[ERROR] " . date('Y-m-d H:i:s') . " - $message\n";
    }
}
class Client {
    public $auth;
    public $proxy;
    public $connection; // اطمینان از وجود پراپرتی
    public $logger;

    public function __construct(string $auth, ?string $proxy = null) {
        $this->auth = $auth;
        $this->proxy = $proxy;
        $this->logger = new Logger();
        $this->connection = null; // مقداردهی اولیه
    }

    public function connect(): void {
        // اگر connection وجود ندارد یا بسته شده است
        if ($this->connection === null) {
            $this->connection = new Connection($this);
        }
    }
}