<?php

class RubikaConfig {
    const VERSION = "6.6.6";
    const LICENSE = "None";
    
    public static function getCopyright() {
        
    }
    
    public static function welcome($text) {
        echo $text . PHP_EOL;
    }
}

class Rubino {
    private $auth;
    private $profileID;
    private $clientConfig = [
        "app_name" => "Main",
        "app_version" => "1.2.1",
        "platform" => "PWA",
        "package" => "m.rubika.ir",
        "lang_code" => "fa"
    ];
    
    public function __construct($auth) {
        $this->auth = $auth;
        
        // Initialize profile ID
        $this->initProfile();
        
        RubikaConfig::welcome(
            "rubika library version " . RubikaConfig::VERSION . "\n" . 
            RubikaConfig::getCopyright() . "\n" .
            "→ docs : https://rubikalib.github.io\n\n" .
            "switching rubino..."
        );
    }
    
    private function initProfile() {
        $response = $this->getMyProfileInfo();
        if (isset($response['profile'])) {
             $this->profileID = $response['profile']['id'];
        }
    }
    
    public function addPost($file, $caption = null, $isMultiFile = null, $postType = "Picture") {
        $uresponse = $this->fileUpload($file, $postType);
        return $this->makeRubinoData("addPost", [
            "caption" => $caption,
            "file_id" => $uresponse[0]['file_id'],
            "hash_file_receive" => $uresponse[1],
            "height" => "800",
            "width" => "800",
            "is_multi_file" => $isMultiFile,
            "post_type" => $postType,
            "rnd" => rand(100000, 999999999),
            "thumbnail_file_id" => $uresponse[0]['file_id'],
            "thumbnail_hash_file_receive" => $uresponse[1],
            "profile_id" => $this->profileID
        ]);
    }
    
    public function addStory($file, $duration, $width, $height, $storyType = "Picture") {
        $uresponse = $this->fileUpload($file, $storyType);
        return $this->makeRubinoData("addStory", [
            "duration" => $duration,
            "file_id" => $uresponse[0]['file_id'],
            "hash_file_receive" => $uresponse[1],
            "height" => $height,
            "profile_id" => $this->profileID,
            "rnd" => rand(100000, 999999999),
            "story_type" => $storyType,
            "thumbnail_file_id" => $uresponse[0]['file_id'],
            "thumbnail_hash_file_receive" => $uresponse[1],
            "width" => $width
        ]);
    }
    
    public function bookmark($postID, $postProfileID) {
        return $this->makeRubinoData("postBookmarkAction", [
            "action_type" => "Bookmark",
            "post_id" => $postID,
            "post_profile_id" => $postProfileID,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function createPage($name, $username, $bio = null) {
        return $this->makeRubinoData("createPage", [
            "bio" => $bio,
            "name" => $name,
            "username" => $username
        ]);
    }
    
    public function comment($text, $postID, $postProfileID) {
        return $this->makeRubinoData("addComment", [
            "content" => $text,
            "post_id" => $postID,
            "post_profile_id" => $postProfileID,
            "rnd" => (string)rand(100000, 999999999),
            "profile_id" => $this->profileID
        ]);
    }
    
    public function fileUpload($file, $type = "Picture") {
        $request = $this->requestUploadFile($file, null, $type);
        
        if (!isset($request['data']['file_id']) || !isset($request['data']['upload_url'])) {
            throw new Exception("Failed to get upload permission");
        }
        
        $fileId = $request['data']['file_id'];
        $uploadUrl = $request['data']['upload_url'];
        
        $uploadResponse = $this->uploadToServer($file, $uploadUrl);
        
        if (!$uploadResponse) {
            throw new Exception("File upload failed");
        }
       
        return [
            ['file_id' => $fileId],
            $request['data']['hash_file_receive']
        ];
    }
    
    private function uploadToServer($filePath, $uploadUrl) {
        $ch = curl_init($uploadUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'file' => new CURLFile($filePath)
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode === 200;
    }
    
    public function follow($followee_id) {
        return $this->makeRubinoData("requestFollow", [
            "f_type" => "Follow",
            "followee_id" => $followee_id,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getComments($postID, $postProfileID, $limit = 50, $sort = "FromMax") {
        return $this->makeRubinoData("getComments", [
            "equal" => false,
            "limit" => $limit,
            "sort" => $sort,
            "post_id" => $postID,
            "profile_id" => $this->profileID,
            "post_profile_id" => $postProfileID
        ]);
    }
    
    public function getMyProfileInfo() {
        return $this->makeRubinoData("getMyProfileInfo", [
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getPostByShareLink($shareString) {
        return $this->makeRubinoData("getPostByShareLink", [
            "share_string" => str_replace('https://rubika.ir/post/', '', $shareString),
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getProfileList($equal = false, $limit = 10, $sort = "FromMax") {
        return $this->makeRubinoData("getProfileList", [
            "equal" => $equal,
            "limit" => $limit,
            "sort" => $sort
        ]);
    }
    
    public function getProfilePosts($targetProfileID, $limit = 51, $sort = "FromMax") {
        return $this->makeRubinoData("getProfilePosts", [
            "equal" => false,
            "limit" => $limit,
            "sort" => $sort,
            "target_profile_id" => $targetProfileID,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getRecentPosts($equal = false, $limit = 30, $sort = "FromMax") {
        return $this->makeRubinoData("getRecentFollowingPosts", [
            "equal" => $equal,
            "limit" => $limit,
            "sort" => $sort,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getShareLink($postID, $postProfileID) {
        return $this->makeRubinoData("getShareLink", [
            "post_id" => $postID,
            "post_profile_id" => $postProfileID,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function getStories($targetProfileID, $limit = 100) {
        return $this->makeRubinoData("getProfileStories", [
            "limit" => $limit,
            "profile_id" => $targetProfileID
        ]);
    }
    
    public function getStoryIds($targetProfileID) {
        return $this->makeRubinoData("getStoryIds", [
            "profile_id" => $this->profileID,
            "target_profile_id" => $targetProfileID
        ]);
    }
    
    public function isExist($username) {
        return $this->makeRubinoData("isExistUsername", [
            "username" => str_replace('@', '', $username)
        ]);
    }
    
    public function like($post_id, $post_profile_id) {
        return $this->makeRubinoData("likePostAction", [
            "action_type" => "Like",
            "post_id" => $post_id,
            "post_profile_id" => $post_profile_id,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function reloadProfile() {
        return $this->makeRubinoData("updateProfile", [
            "profile_id" => $this->profileID,
            "profile_status" => "Public"
        ]);
    }
    
    public function requestUploadFile($file, $size = null, $type = "Picture") {
        $filename = basename($file);
        $filesize = $size ?? filesize($file);
        
        return $this->makeRubinoData("requestUploadFile", [
            "file_name" => $filename,
            "file_size" => $filesize,
            "file_type" => $type,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function unbookmark($postID, $postProfileID) {
        return $this->makeRubinoData("postBookmarkAction", [
            "action_type" => "Unbookmark",
            "post_id" => $postID,
            "post_profile_id" => $postProfileID,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function unfollow($followee_id) {
        return $this->makeRubinoData("requestFollow", [
            "f_type" => "Unfollow",
            "followee_id" => $followee_id,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function unlike($post_id, $post_profile_id) {
        return $this->makeRubinoData("likePostAction", [
            "action_type" => "Unlike",
            "post_id" => $post_id,
            "post_profile_id" => $post_profile_id,
            "profile_id" => $this->profileID
        ]);
    }
    
    public function updateProfile($name = null, $bio = null, $email = null) {
        $data = [];
        if ($name !== null) $data['name'] = $name;
        if ($bio !== null) $data['bio'] = $bio;
        if ($email !== null) $data['email'] = $email;
        
        return $this->makeRubinoData("updateProfile", $data);
    }
    
    public function viewPost($post_id, $post_profile_id) {
        return $this->makeRubinoData("addPostViewCount", [
            "post_id" => $post_id,
            "post_profile_id" => $post_profile_id
        ]);
    }
    
    public function viewStories($storyIds, $storyProfileID) {
        return $this->makeRubinoData("addViewStory", [
            "profile_id" => $this->profileID,
            "story_ids" => $storyIds,
            "story_profile_id" => $storyProfileID
        ]);
    }
    
    private function makeRubinoData($method, $data) {
        $payload = [
            "api_version" => "0",
            "auth" => $this->auth,
            "client" => $this->clientConfig,
            "data" => $data,
            "method" => $method
        ];
        
        return $this->postRequest($payload, "https://rubino12.iranlms.ir/");
    }
    
    private function postRequest($payload, $url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0',
            'Origin: https://web.rubika.ir',
            'Referer: https://web.rubika.ir/'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception("API request failed with HTTP code: $httpCode");
        }
        
        return json_decode($response, true)['data'];
    }
}