<?php
require_once('classes/RubikaBot.php');
require_once('classes/Rubino.php');

class Users {
    private string $file;
    private array $users = [];
    public array $adminGuids = [
        'u0He4Ib05c453223b2d056dfa6f192da' // گوید ادمین
    ];

    public function __construct(string $file) {
        $this->file = $file;
        $this->loadUsers();
    }

    private function loadUsers(): void {
        if (file_exists($this->file)) {
            $data = file_get_contents($this->file);
            $this->users = json_decode($data, true) ?: [];
        }
    }

    public function saveUsers(): void {
        file_put_contents($this->file, json_encode($this->users, JSON_PRETTY_PRINT));
    }

    public function getUser(string $guid): ?array {
        return $this->users[$guid] ?? null;
    }

    public function addUser(string $guid, string $chat_id, string $first_name, ?string $username): void {
        $this->users[$guid] = [
            'chat_id' => $chat_id,
            'first_name' => $first_name,
            'username' => $username,
            'work' => null,
            'is_admin' => in_array($guid, $this->adminGuids),
            'blocked' => false,
            'downloads' => [],
            'created_at' => date('Y-m-d H:i:s')
        ];
        $this->saveUsers();
    }

    public function setWork(string $guid, ?string $work = '') {
        $this->users[$guid]['work'] = $work;
        $this->saveUsers();
    }

    public function addDownload(string $guid, array $postData): void {
        if (isset($this->users[$guid])) {
            $this->users[$guid]['downloads'][] = [
                'post_id' => $postData['id'],
                'url' => $postData['full_file_url'],
                'type' => $postData['type'],
                'caption' => $postData['caption'],
                'downloaded_at' => date('Y-m-d H:i:s')
            ];
            $this->saveUsers();
        }
    }

    public function getDownloads(string $guid): array {
        return $this->users[$guid]['downloads'] ?? [];
    }

    public function getDownloadsPage(string $guid, int $page): array {
        $downloads = $this->getDownloads($guid);
        $chunks = array_chunk($downloads, 10);
        return $chunks[$page] ?? [];
    }

    public function getTotalPages(string $guid): int {
        $downloads = $this->getDownloads($guid);
        return ceil(count($downloads) / 10);
    }

    public function isAdmin(string $guid): bool {
        return $this->users[$guid]['is_admin'] ?? false;
    }

    public function blockUser(string $guid): void {
        if (isset($this->users[$guid])) {
            $this->users[$guid]['blocked'] = true;
            $this->saveUsers();
        }
    }

    public function unblockUser(string $guid): void {
        if (isset($this->users[$guid])) {
            $this->users[$guid]['blocked'] = false;
            $this->saveUsers();
        }
    }

    public function isBlocked(string $guid): bool {
        return $this->users[$guid]['blocked'] ?? false;
    }

    public function getAllUsers(): array {
        return $this->users;
    }

    public function getTotalUsers(): int {
        return count($this->users);
    }

    public function getTotalDownloads(): int {
        $total = 0;
        foreach ($this->users as $user) {
            $total += count($user['downloads']);
        }
        return $total;
    }

    public function getUsersPage(int $page): array {
        $users = array_slice($this->users, $page * 10, 10, true);
        return $users;
    }

    public function getTotalUserPages(): int {
        return ceil(count($this->users) / 10);
    }
}

$rubino = new Rubino('Auth rubino'); // اوت روبینو

class Download {
    public function downloadPost(string $url) {
        global $rubino;
        $data = $rubino->getPostByShareLink($url);
        return $data['post'];
    }
    public function downloadStory(string $id) {
        global $rubino;
    
        $result = $rubino->isExist($id);
        $getst = $rubino->getStoryIds($result['profile']['id']);
        if (!is_array($getst) || !isset($getst['story_ids']) || !isset($getst['story_ids'][0])) {
            return [
                'error' => 'notUser'
            ];
        }
        $prof = $getst['story_ids'];
        $stories = $rubino->viewStories($getst['story_ids'], $result['profile']['id']);
        file_put_contents('resb.txt', json_encode($stories));
        /*foreach ($st as $key => $value) {
            // code...
        }
        return $stories;*/
    }
}

$bot = new RubikaBot('Token'); // توکن دریافتی از بات فادر
$users = new Users('users.txt');
$downloader = new Download();

$updateType = $bot->getUpdateType();
$text = $bot->getText();
$chatId = $bot->getChatId();
$senderGuid = $bot->getSenderId();
$firstName = $bot->getFirstName();
$username = $bot->getUserName();
$buttonId = $bot->getButtonId();
if ($users->isBlocked($senderGuid)) return;
if ($updateType === 'NewMessage' && !$users->getUser($senderGuid)) {
    $users->addUser($senderGuid, $chatId, $firstName, $username);
}

if (!$users->isAdmin($senderGuid)) {
    $main_keypad = RubikaBot::makeKeypad([
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('down_story', '🎭 دانلود استوری')
        ]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('start_download', '📥 دانلود پست'),
            RubikaBot::makeSimpleButton('my_history', '📚 تاریخچه دانلودها')
        ]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('support', '📮 تیکت')
        ])
    ]);
} else {
    $main_keypad = RubikaBot::makeKeypad([
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('down_story', '🎭 دانلود استوری')
        ]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('start_download', '📥 دانلود پست'),
            RubikaBot::makeSimpleButton('my_history', '📚 تاریخچه دانلودها')
        ]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('acvk', '/admin')
        ])
    ]);
}

if ($text == '🔙') {
    $users->setWork($senderGuid);
    $bot->reply([
        'chat_id' => $chatId,
        'text' => "✨ به روینو خوش آمدید!\n\nبرای ادامه از دکمه های زیر استفاده کنید.",
        'chat_keypad' => $main_keypad,
        'chat_keypad_type' => 'New'
    ]);
    return;
}

$work = $users->getUser($senderGuid)['work'];

$button_admin = [
    '📊 آمار ربات' => 'admin_stats',
    '📣 ارسال همگانی' => 'admin_broadcast',
    '👥 لیست کاربران' => 'admin_users'
];

$button_user = [
    '🎭 دانلود استوری' => 'down_story',
    '📥 دانلود پست' => 'start_download',
    '📚 تاریخچه دانلودها' => 'my_history',
    '📮 تیکت' => 'support'
];

$buttons = $users->isAdmin($senderGuid) ? $button_admin + $button_user : $button_user;
$buttonId = $buttons[$text] ?? $buttonId;

if (strpos($buttonId, 'download_') === 0) {
    $postId = str_replace('download_', '', $buttonId);
    $downloads = $users->getDownloads($senderGuid);

    foreach ($downloads as $download) {
        if ($download['post_id'] == $postId) {
            downloadPostButton($chatId, $download);
            break;
        }
    }
}
if ($work == 'getId') {
    downloadStory($chatId, $text);
    return;
}
if ($work === 'getLink') {
    downloadPost($chatId, $text);
    return;
} elseif ($work == 'admin_broadcast') {
    $users->setWork($senderGuid);
    $allUsers = $users->getAllUsers();
    $num = 0;
    $msgid = $bot->reply([
        'chat_id' => $chatId,
        'text' => '⏳ درحال ارسال به '.$num.' نفر...'
    ])['data']['message_id'];
    
    foreach ($allUsers as $guid => $user) {
        if ($users->isAdmin($guid) || $users->isBlocked($guid)) continue;
        try {
            $bot->reply([
                'chat_id' => $user['chat_id'],
                'text' => $text
            ]);
        } catch (Exception $e) {
            continue;
        }
        $num++;
        $bot->editMessageText([
            'chat_id' => $chatId,
            'message_id' => $msgid,
            'text' => "⏳ در حال ارسال به $num نفر..."
        ]);
        usleep(200000);
    }
    
    $bot->editMessageText([
        'chat_id' => $chatId,
        'message_id' => $msgid,
        'text' => "✅ پیام برای $num کاربر ارسال شد."
    ]);
    $bot->editChatKeypad([
        'chat_id' => $chatId,
        'chat_keypad' => $main_keypad,
        'chat_keypad_type' => 'New'
    ]);
    return;
} elseif ($work == 'support_w') {
    $users->setWork($senderGuid);
    $dat = $users->adminGuids;
    $message = "💭 پیام جدید از $firstName ،\n💬 پیام :\n" . $text;
    $buttons = RubikaBot::makeKeypad([
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('admin_reply_' . $senderGuid, '🔖 پاسخ'),
            RubikaBot::makeSimpleButton('admin_reply_block_' . $senderGuid, '🚫 بلاک')
        ]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton('admin_close_list', '❌ بستن')
        ])
    ]);
    foreach ($dat as $guid) {
        $bot->sendMessage([
            'chat_id' => $users->getUser($guid)['chat_id'],
            'text' => $message,
            'inline_keypad' => $buttons
        ]);
    }
    $bot->reply([
        'text' => "✅ پیام شما با موفقیت ارسال شد.\n♻️ مننظر پاسخ ادمین باشید ...",
        'chat_keypad' => $main_keypad,
        'chat_keypad_type' => 'New'
    ]);
    return;
}

if ($updateType === 'NewMessage') {
    if ($users->isAdmin($senderGuid)) {
        if ($text === '/admin') {
            $keypad = RubikaBot::makeKeypad([
                RubikaBot::makeKeypadRow([
                    RubikaBot::makeSimpleButton('admin_stats', '📊 آمار ربات')
                ]),
                RubikaBot::makeKeypadRow([
                    RubikaBot::makeSimpleButton('admin_broadcast', '📣 ارسال همگانی'),
                    RubikaBot::makeSimpleButton('admin_users', '👥 لیست کاربران')
                ]),
                RubikaBot::makeKeypadRow([
                    RubikaBot::makeSimpleButton('back', '🔙')
                ])
            ]);
            $bot->reply([
                'chat_id' => $chatId,
                'text' => "👮‍♂️ پنل مدیریت روینو",
                'chat_keypad' => $keypad,
                'chat_keypad_type' => 'New'
            ]);
            return;
        }
    }

    switch ($text) {
        case '/start':
            $bot->reply([
                'chat_id' => $chatId,
                'text' => "✨ به روینو خوش آمدید!\n\nبرای ادامه از دکمه های زیر استفاده کنید.",
                'chat_keypad' => $main_keypad,
                'chat_keypad_type' => 'New'
            ]);
            break;

        case '/history':
            showHistory($senderGuid, $chatId, 0);
            break;
    }
}

if ($buttonId !== null) {
    if ($buttonId == 'admin_close_list') {
        $bot->deleteMessage([
            'chat_id' => $chatId,
            'message_id' => $bot->getMessageId()
        ]);
        return;
    }
    if (strpos($buttonId, 'admin_') === 0) {
        handleAdminCommands($buttonId, $chatId, $senderGuid);
        return;
    }

    if (strpos($buttonId, 'history_') === 0) {
        $parts = explode('_', $buttonId);
        $page = (int)($parts[1] ?? 0);
        $direction = $parts[2] ?? '';
        if ($direction === 'prev' && $page > 0) $page--;
        if ($direction === 'next') $page++;
        showHistory($senderGuid, $chatId, $page, true);
        return;
    }

    switch ($buttonId) {
        case 'down_story':
            $bot->reply([
                'text' => '‼️ این قابلیت هنوز فعال نیست!'
            ]);
            /*$users->setWork($senderGuid, 'getId');
            $bot->reply([
                'chat_id' => $chatId,
                'text' => "📥 آیدی کاربر مورد نظر را ارسال کنید:",
                'chat_keypad' => RubikaBot::makeKeypad([
                    RubikaBot::makeKeypadRow([
                        RubikaBot::makeSimpleButton('back', '🔙')
                    ])
                ]),
                'chat_keypad_type' => 'New'
            ]);*/
            break;
        case 'start_download':
            $users->setWork($senderGuid, 'getLink');
            $bot->reply([
                'chat_id' => $chatId,
                'text' => "📥 لینک پست روبینو را ارسال کنید:",
                'chat_keypad' => RubikaBot::makeKeypad([
                    RubikaBot::makeKeypadRow([
                        RubikaBot::makeSimpleButton('back', '🔙')
                    ])
                ]),
                'chat_keypad_type' => 'New'
            ]);
            break;
        case 'my_history':
            showHistory($senderGuid, $chatId, 0);
            break;
        case 'support':
            $users->setWork($senderGuid, 'support_w');
            $bot->reply([
                'text' => "📨 ارسال پیام به پشتیبانی روینو
سلام!\nبرای ارتباط با پشتیبانی، لطفاً مشکل خود را به صورت کامل و دقیق فقط با متن وارد کنید.
\n\n🔹 حتماً موارد زیر را در نظر بگیرید:\n• در صورت دیده شدن مشکل گزارش کنید!\n• در صورت پیشنهاد قابلیت گزارش کنید!
\n• هرگونه استفاده از کلمات رکیک مسدودیت شما را در ربات به همراه دارد\n\n🙏 ممنون از همکاری‌تون",
                'chat_keypad' => RubikaBot::makeKeypad([
                    RubikaBot::makeKeypadRow([
                        RubikaBot::makeSimpleButton('back', '🔙')
                    ])
                ]),
                'chat_keypad_type' => 'New'
            ]);
    }
}
function isValidUsername(string $text) {
    $text = trim($text);
    if (strpos($text, '@') === 0) {
        $text = substr($text, 1);
    }
    if (preg_match('/^[a-zA-Z0-9_]{5,32}$/', $text)) {
        return true;
    }
    return false;
}
function downloadStory(string $chatId, string $text) {
    global $downloader, $users, $bot, $senderGuid, $main_keypad;
    if (!isValidUsername($text)) {
        $bot->reply([
            'text' => "❗️آیدی وارد شده معتبر نیست.\nلطفاً از درستی آن مطمئن شوید و دوباره امتحان کنید.\nدر صورت نیاز، پشتیبانی در خدمت شماست. 🙏"
        ]);
        return;
    }
    $users->setWork($senderGuid);
    $bot->reply([
        'text' => "⏳ در حال بررسی آیدی و دانلود استوری... لطفا منتظر بمانید"
    ]);
    $storyData = $downloader->downloadStory($text);
    if (isset($storyData['error']) && $storyData['error'] === 'notUser') {
        $bot->reply([
            'text' => "❌ کاربری با این آیدی پیدا نشد.\nلطفاً آیدی را بررسی کرده و مجدد تلاش کنید."
        ]);
        return;
    }
    if (empty($storyData->profiles)) {
        $bot->reply([
            'text' => "ℹ️ این کاربر هیچ استوری فعالی ندارد یا دسترسی محدود است."
        ]);
        return;
    }
    $story = $storyData['profiles'][0];
    if (!isset($story['full_thumbnail_url'])) {
        $bot->reply([
            'text' => "❌ استوری قابل دانلود نیست یا لینک فایل وجود ندارد."
        ]);
        return;
    }

    $name = rand(10000, 99999) . '.mp4';
    $ch = curl_init($story['full_file_url']);
    $fp = fopen($name, 'wb');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 50);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);

    $file = $bot->sendFile($chatId, $name, $story['caption'] ?? '');
    unlink($name);
    $story->post_id = $file['file_id'];
    $story->type = $file['type'];
    $bot->reply([
        'chat_id' => $chatId,
        'text' => "✅ استوری با موفقیت دانلود شد!\n\n📝 کپشن: " . mb_substr($story->caption ?? 'بدون توضیح', 0, 100) . "...",
        'chat_keypad' => $main_keypad,
        'chat_keypad_type' => 'New'
    ]);
}
function downloadPost(string $chatId, string $text) {
    global $downloader, $users, $bot, $senderGuid, $main_keypad;
    if (!preg_match('#https:\/\/rubika\.ir\/post\/[a-zA-Z0-9]+#', $text)) {
        $bot->reply([
            'text' => "❗️ لینک پست ارسال شده صحیح نیست.\nلطفاً از صحت لینک اطمینان حاصل کرده و مجدداً تلاش نمایید.\nدر صورت نیاز، آماده پاسخگویی به سوالات شما هستیم. 🙏"
        ]);
        return;
    }
    $users->setWork($senderGuid);
    $bot->reply([
        'text' => "⏳ در حال دانلود پست... لطفا منتظر بمانید"
    ]);
    $postData = $downloader->downloadPost($text);
    $postData['full_file_url'] = $postData['full_file_url'] ?? $postData['full_thumbnail_url'] ?? null;
    if (isset($postData['full_file_url'])) {
        $name = rand(11111, 999999).'.mp4';
        $ch = curl_init($postData['full_file_url']);
        $fp = fopen($name, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);
        $file = $bot->sendFile($chatId, $name, $postData['caption'] ?? '');
        unlink($name);
        $postData['type'] = $file['type'];
        $users->addDownload($senderGuid, $postData);
        $bot->reply([
            'chat_id' => $chatId,
            'text' => "✅ پست با موفقیت دانلود شد!\n\n📝 کپشن: " . mb_substr($postData['caption'] ?? 'بدون توضیح', 0, 100) . "...",
            'chat_keypad' => $main_keypad,
            'chat_keypad_type' => 'New'
        ]);
    } else {
        $bot->reply([
            'text' => "❌ خطا در دانلود پست! لطفا یک لینک معتبر ارسال کنید."
        ]);
    }
    return;
}

function downloadPostButton(string $chatId, array $text) {
    global $downloader, $users, $bot, $senderGuid;
    $bot->reply([
        'chat_id' => $chatId,
        'text' => "⏳ در حال دانلود پست... لطفا منتظر بمانید"
    ]);
    if (isset($text['url'])) {
        $name = rand(11111, 999999).'.mp4';
        $ch = curl_init($text['url']);
        $fp = fopen($name, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);
        $bot->sendFile($chatId, $name, $text['caption'] ?? '');
        $bot->reply([
            'chat_id' => $chatId,
            'text' => "✅ پست با موفقیت دانلود شد!\n\n📝 کپشن: " . mb_substr($text['caption'] ?? 'بدون توضیح', 0, 100) . "..."
        ]);
    } else {
        $bot->reply([
            'chat_id' => $chatId,
            'text' => "❌ خطا در دانلود پست!"
        ]);
    }
    $users->setWork($senderGuid);
    return;
}

function showHistory(string $guid, string $chatId, int $page, ?bool $edit = false) {
    global $bot, $users;
    $downloads = $users->getDownloadsPage($guid, $page);
    $totalPages = $users->getTotalPages($guid);

    if (empty($downloads)) {
        $bot->reply([
            'chat_id' => $chatId,
            'text' => "📭 تاریخچه دانلودهای شما خالی است."
        ]);
        return;
    }

    $message = "📚 تاریخچه دانلودها (صفحه " . ($page + 1) . "/$totalPages):\n\n";
    foreach ($downloads as $index => $download) {
        $message .= sprintf(
            "%d. %s\n📅 %s\n\n",
            ($page * 10) + $index + 1,
            mb_substr($download['caption'] ?? 'بدون توضیح', 0, 30) . '...',
            $download['downloaded_at']
        );
    }

    $rows = [];
    $buttons = [];
    $downloadButtons = [];
    foreach ($downloads as $index => $download) {
        $downloadButtons[] = RubikaBot::makeKeypadRow([RubikaBot::makeSimpleButton("download_{$download['post_id']}", '🔁 ' . ($index + 1))]);
    }

    $rows = $downloadButtons;
    if ($page > 0) $buttons[] = RubikaBot::makeSimpleButton("history_{$page}_prev", '<<');
    if ($page < $totalPages - 1) $buttons[] = RubikaBot::makeSimpleButton("history_{$page}_next", '>>');
    if (!empty($buttons)) $rows[] = RubikaBot::makeKeypadRow($buttons);
    
    $keypad = RubikaBot::makeKeypad($rows);
    if ($edit) {
        $bot->editMessageText([
            'chat_id' => $chatId,
            'text' => $message,
            'message_id' => $bot->getMessageId()
        ]);
        $bot->editMessageKeypad([
            'chat_id' => $chatId,
            'message_id' => $bot->getMessageId(),
            'inline_keypad' => $keypad
        ]);
        return;
    }
    $bot->reply([
        'chat_id' => $chatId,
        'text' => $message,
        'inline_keypad' => $keypad
    ]);
}

function showUsersList(string $chatId, int $page, ?bool $edit = false) {
    global $bot, $users;
    $userList = $users->getUsersPage($page);
    $totalPages = $users->getTotalUserPages();

    $message = "👥 لیست کاربران (صفحه " . ($page + 1) . "/$totalPages):\n\n";
    
    $keypadRows = [];
    foreach ($userList as $guid => $user) {
        if ($users->isAdmin($guid)) continue;
        $status = $users->isBlocked($guid) ? "🚫 بلاک" : "✅ فعال";
        $displayName = $user['first_name'] . " ($status)";
        
        $keypadRows[] = RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton("admin_user_{$guid}_{$page}", $displayName)
        ]);
    }
    if (empty($keypadRows)) {
        $bot->reply([
            'chat_id' => $chatId,
            'text' => "📭 لیست کاربران خالی است."
        ]);
        return;
    }
    $paginationButtons = [];
    if ($page > 0) {
        $paginationButtons[] = RubikaBot::makeSimpleButton("admin_users_prev_{$page}", '<<');
    }
    if ($page < $totalPages - 1) {
        $paginationButtons[] = RubikaBot::makeSimpleButton("admin_users_next_{$page}", '>>');
    }
    
    if (!empty($paginationButtons)) {
        $keypadRows[] = RubikaBot::makeKeypadRow($paginationButtons);
    }

    $keypadRows[] = RubikaBot::makeKeypadRow([
        RubikaBot::makeSimpleButton('admin_close_list', 'بستن ❌')
    ]);

    $keypad = RubikaBot::makeKeypad($keypadRows);
    if ($edit) {
        $bot->editMessageText([
            'chat_id' => $chatId,
            'text' => $message,
            'message_id' => $bot->getMessageId()
        ]);
        $bot->editMessageKeypad([
            'chat_id' => $chatId,
            'message_id' => $bot->getMessageId(),
            'inline_keypad' => $keypad
        ]);
        return;
    }
    $bot->reply([
        'chat_id' => $chatId,
        'text' => $message,
        'inline_keypad' => $keypad
    ]);
}

function showUserDetail(string $chatId, string $userGuid, int $page, ?bool $edit = false) {
    global $bot, $users;
    $user = $users->getUser($userGuid);
    
    if (!$user) {
        $bot->reply(['chat_id' => $chatId, 'text' => "❌ کاربر یافت نشد!"]);
        return;
    }
    
    $status = $users->isBlocked($userGuid) ? "🚫 بلاک شده" : "✅ فعال";
    $message = "👤 اطلاعات کاربر:\n\n";
    $message .= "🆔 شناسه: $userGuid\n";
    $message .= "👤 نام: {$user['first_name']}\n";
    $message .= "📅 تاریخ ثبت‌نام: {$user['created_at']}\n";
    $message .= "🔒 وضعیت: $status\n";
    $message .= "📥 تعداد دانلودها: " . count($user['downloads'] ?? []) . "\n";

    $blockButton = $users->isBlocked($userGuid) 
        ? RubikaBot::makeSimpleButton("admin_unblock_{$userGuid}_{$page}", '🔓 آنبلاک')
        : RubikaBot::makeSimpleButton("admin_block_{$userGuid}_{$page}", '🚫 بلاک');

    $keypad = RubikaBot::makeKeypad([
        RubikaBot::makeKeypadRow([$blockButton]),
        RubikaBot::makeKeypadRow([
            RubikaBot::makeSimpleButton("admin_users_back_{$page}", '🔙 بازگشت')
        ])
    ]);
    if ($edit) {
        $bot->editMessageText([
            'chat_id' => $chatId,
            'text' => $message,
            'message_id' => $bot->getMessageId()
        ]);
        $bot->editMessageKeypad([
            'chat_id' => $chatId,
            'message_id' => $bot->getMessageId(),
            'inline_keypad' => $keypad
        ]);
        return;
    }
    $bot->reply([
        'chat_id' => $chatId,
        'text' => $message,
        'inline_keypad' => $keypad
    ]);
}

function handleAdminCommands(string $buttonId, string $chatId, string $senderGuid) {
    global $bot, $users;
    
    if (!$users->isAdmin($senderGuid)) return;
    if (strpos($buttonId, 'admin_users_back_') === 0) {
        $parts = explode('_', $buttonId);
        $page = (int)($parts[3] ?? 0);
        showUsersList($chatId, $page, true);
        return;
    }
    if (strpos($buttonId, 'admin_users_') === 0) {
        $parts = explode('_', $buttonId);
        $action = $parts[2] ?? '';
        $page = (int)($parts[3] ?? 0);
        
        if ($action === 'prev' && $page > 0) $page--;
        if ($action === 'next') $page++;
        
        showUsersList($chatId, $page, true);
        return;
    }
    if (strpos($buttonId, 'admin_user_') === 0) {
        $parts = explode('_', $buttonId);
        $userGuid = $parts[2];
        $page = (int)($parts[3] ?? 0);
        showUserDetail($chatId, $userGuid, $page, true);
        return;
    }
    if (strpos($buttonId, 'admin_block_') === 0 || strpos($buttonId, 'admin_unblock_') === 0) {
        $parts = explode('_', $buttonId);
        $action = $parts[1];
        $userGuid = $parts[2];
        if ($users->isAdmin($userGuid)) return;
        $page = (int)($parts[3] ?? 0);
        
        $user = $users->getUser($userGuid);
        $userName = $user ? $user['first_name'] : 'کاربر';
        if ($action === 'block') {
            if ($users->isBlocked($userGuid)) {
                showUserDetail($chatId, $userGuid, $page, true);
            } else {
                $users->blockUser($userGuid);
                showUserDetail($chatId, $userGuid, $page, true);
            }
        } else {
            if (!$users->isBlocked($userGuid)) {
                showUserDetail($chatId, $userGuid, $page, true);
            } else {
                $users->unblockUser($userGuid);
                showUserDetail($chatId, $userGuid, $page, true);
            }
        }
        showUserDetail($chatId, $userGuid, $page, true);
        return;
    }

    switch ($buttonId) {
        case 'admin_stats':
            $totalUsers = $users->getTotalUsers();
            $totalDownloads = $users->getTotalDownloads();
            $blockedCount = count(array_filter($users->getAllUsers(), fn($u) => $u['blocked'] ?? false));
            
            $message = "📊 آمار ربات:\n\n";
            $message .= "👥 تعداد کاربران: $totalUsers\n";
            $message .= "📥 تعداد دانلودها: $totalDownloads\n";
            $message .= "🚫 کاربران بلاک شده: $blockedCount";
            
            $bot->reply(['chat_id' => $chatId, 'text' => $message]);
            break;

        case 'admin_users':
            showUsersList($chatId, 0);
            break;
        case 'admin_broadcast':
            $users->setWork($senderGuid, 'admin_broadcast');
            $bot->reply([
                'chat_id' => $chatId,
                'text' => "✍️ لطفا پیام همگانی را وارد کنید:"
            ]);
            break;
    }
}