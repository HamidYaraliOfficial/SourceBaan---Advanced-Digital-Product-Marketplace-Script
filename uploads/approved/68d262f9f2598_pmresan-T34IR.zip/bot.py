from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton, KeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
import os, logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("bot")

BOT_TOKEN = "" #توکن جایگزین بشه
ADMIN_ID = 1111111 #ایدی عددی ادمین 

user_keyboard = ReplyKeyboardMarkup([
    ["🆘 پشتیبانی", "📋 اطلاعات من"],
    [KeyboardButton("📱 اشتراک شماره من", request_contact=True)]
], resize_keyboard=True)

admin_keyboard = ReplyKeyboardMarkup([
    ["📊 آمار ربات", "👥 کاربران ربات"],
    ["📢 پیام همگانی", "📨 ارسال پیام به کاربر"],
    ["🚫 بلاک کاربر", "✅ آنبلاک کاربر"],
    ["📞 شماره موبایل کاربران", "📋 اطلاعات من"]
], resize_keyboard=True)

awaiting_broadcast = {}
awaiting_support = {}
reply_targets = {}
awaiting_direct_id = {}
awaiting_direct_message = {}
awaiting_block_id = {}
awaiting_unblock_id = {}

def ensure_file(path):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write("")

def save_user(user_id, name):
    ensure_file("users.txt")
    with open("users.txt", "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    ids = [line.split(" - ")[0] for line in lines]
    if str(user_id) not in ids:
        lines.append(f"{user_id} - {name}")
        with open("users.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    with open("stats.txt", "w", encoding="utf-8") as f:
        f.write(str(len(lines)))

def is_blocked(user_id):
    if not os.path.exists("blocked.txt"):
        return False
    with open("blocked.txt", "r", encoding="utf-8") as f:
        return str(user_id) in [ln.strip() for ln in f if ln.strip()]

def block_user(user_id):
    ensure_file("blocked.txt")
    with open("blocked.txt", "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    if str(user_id) not in lines:
        lines.append(str(user_id))
        with open("blocked.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

def unblock_user(user_id):
    if not os.path.exists("blocked.txt"):
        return
    with open("blocked.txt", "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    lines = [ln for ln in lines if ln != str(user_id)]
    with open("blocked.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))

def save_phone(user_id, name, phone):
    ensure_file("phones.txt")
    updated = False
    with open("phones.txt", "r", encoding="utf-8") as f:
        rows = [ln.strip() for ln in f if ln.strip()]
    new_rows = []
    for row in rows:
        parts = [p.strip() for p in row.split(" - ")]
        if len(parts) >= 3 and parts[0] == str(user_id):
            new_rows.append(f"{user_id} - {name} - {phone}")
            updated = True
        else:
            new_rows.append(row)
    if not updated:
        new_rows.append(f"{user_id} - {name} - {phone}")
    with open("phones.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(new_rows) + "\n")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    save_user(user.id, user.full_name)
    if is_blocked(user.id) and user.id != ADMIN_ID:
        await update.message.reply_text("⛔ شما بلاک شده‌اید.")
        return
    if user.id == ADMIN_ID:
        await update.message.reply_text("🎛️ خوش آمدی ادمین!", reply_markup=admin_keyboard)
    else:
        await update.message.reply_text("سلام به ربات پیامرسان شخصی من خیلی خوش آمدید!:", reply_markup=user_keyboard)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    msg = update.message
    text = msg.text or ""
    contact = msg.contact

    if is_blocked(user.id) and user.id != ADMIN_ID:
        await msg.reply_text("⛔ شما بلاک شده‌اید.")
        return

    if contact:
        phone = contact.phone_number
        save_phone(user.id, user.full_name, phone)
        await msg.reply_text("✅ شماره شما ذخیره شد.")
        await context.bot.send_message(chat_id=ADMIN_ID,
            text=f"📱 شماره جدید:\nنام: {user.full_name}\nآیدی: {user.id}\nشماره: {phone}")
        return

    if reply_targets.get(user.id):
        target_id = reply_targets.pop(user.id)
        try:
            await context.bot.copy_message(chat_id=target_id, from_chat_id=msg.chat_id, message_id=msg.message_id)
            await msg.reply_text("✅ پیام شما برای کاربر ارسال شد.")
        except Exception as e:
            logger.error(f"ارسال پاسخ به کاربر {target_id} ناکام: {e}")
            await msg.reply_text("❌ ارسال پیام به کاربر ناموفق بود.")
        return

    if user.id == ADMIN_ID:
        if text == "📊 آمار ربات":
            if os.path.exists("stats.txt"):
                with open("stats.txt", "r", encoding="utf-8") as f:
                    count = f.read().strip() or "0"
                await msg.reply_text(f"📈 تعداد کاربران: {count}")
            else:
                await msg.reply_text("📈 هیچ کاربری ثبت نشده.")
        elif text == "👥 کاربران ربات":
            if os.path.exists("users.txt"):
                with open("users.txt", "r", encoding="utf-8") as f:
                    users = f.read().strip()
                await msg.reply_text(f"👥 لیست کاربران:\n{users or 'خالی'}")
            else:
                await msg.reply_text("👥 لیست خالی است.")
        elif text == "📢 پیام همگانی":
            awaiting_broadcast[user.id] = True
            await msg.reply_text("📝 پیام خود را بفرستید:")
        elif awaiting_broadcast.get(user.id):
            awaiting_broadcast.pop(user.id)
            if os.path.exists("users.txt"):
                with open("users.txt", "r", encoding="utf-8") as f:
                    lines = [ln.strip() for ln in f if ln.strip()]
                for line in lines:
                    try:
                        uid = int(line.split(" - ")[0])
                        if not is_blocked(uid):
                            await context.bot.copy_message(chat_id=uid, from_chat_id=msg.chat_id, message_id=msg.message_id)
                    except Exception as e:
                        logger.warning(f"ارسال همگانی به {line} ناکام: {e}")
            await msg.reply_text("✅ پیام همگانی ارسال شد.")
        elif text == "📨 ارسال پیام به کاربر":
            awaiting_direct_id[user.id] = True
            await msg.reply_text("🔢 آیدی عددی کاربر را وارد کنید:")
        elif awaiting_direct_id.get(user.id):
            awaiting_direct_id.pop(user.id)
            try:
                target_id = int(text.strip())
                awaiting_direct_message[user.id] = target_id
                await msg.reply_text("✉️ حالا پیام خود را برای کاربر ارسال کن:")
            except Exception:
                await msg.reply_text("❌ آیدی عددی نامعتبر بود.")
        elif awaiting_direct_message.get(user.id):
            target_id = awaiting_direct_message.pop(user.id)
            try:
                await context.bot.copy_message(chat_id=target_id, from_chat_id=msg.chat_id, message_id=msg.message_id)
                await msg.reply_text("✅ پیام برای کاربر ارسال شد.")
            except Exception as e:
                logger.error(f"ارسال پیام به کاربر {target_id} ناموفق بود: {e}")
                await msg.reply_text("❌ ارسال پیام به کاربر ناموفق بود.")
        elif text == "🚫 بلاک کاربر":
            awaiting_block_id[user.id] = True
            await msg.reply_text("🔒 آیدی عددی کاربر را وارد کنید:")
        elif awaiting_block_id.get(user.id):
            awaiting_block_id.pop(user.id)
            try:
                target_id = int(text.strip())
                block_user(target_id)
                await msg.reply_text(f"🚫 کاربر {target_id} بلاک شد.")
            except Exception:
                await msg.reply_text("❌ آیدی عددی نامعتبر بود.")
        elif text == "✅ آنبلاک کاربر":
            awaiting_unblock_id[user.id] = True
            await msg.reply_text("🔓 آیدی عددی کاربر را وارد کنید:")
        elif awaiting_unblock_id.get(user.id):
            awaiting_unblock_id.pop(user.id)
            try:
                target_id = int(text.strip())
                unblock_user(target_id)
                await msg.reply_text(f"✅ کاربر {target_id} آنبلاک شد.")
            except Exception:
                await msg.reply_text("❌ آیدی عددی نامعتبر بود.")
        elif text == "📞 شماره موبایل کاربران":
            if os.path.exists("phones.txt"):
                with open("phones.txt", "r", encoding="utf-8") as f:
                    phones = f.read().strip()
                await msg.reply_text(f"📞 شماره‌ها:\n{phones or 'خالی'}")
            else:
                await msg.reply_text("📞 هیچ شماره‌ای ثبت نشده.")
        elif text == "📋 اطلاعات من":
            info = f"🆔 آیدی عددی شما: {user.id}\n👤 نام شما: {user.full_name}"
            phone = None
            if os.path.exists("phones.txt"):
                with open("phones.txt", "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.strip().split(" - ")
                        if len(parts) >= 3 and parts[0] == str(user.id):
                            phone = parts[2]
                            break
            if phone:
                info += f"\n📱 شماره ثبت‌شده: {phone}"
            await msg.reply_text(info)
        else:
            await msg.reply_text("از دکمه‌های پنل مدیریت استفاده کن.")
    else:
        if text == "🆘 پشتیبانی":
            awaiting_support[user.id] = True
            await msg.reply_text("📝 پیام خود را برای پشتیبانی ارسال کنید:")
        elif text == "📋 اطلاعات من":
            info = f"🆔 آیدی عددی شما: {user.id}\n👤 نام شما: {user.full_name}"
            phone = None
            if os.path.exists("phones.txt"):
                with open("phones.txt", "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.strip().split(" - ")
                        if len(parts) >= 3 and parts[0] == str(user.id):
                            phone = parts[2]
                            break
            if phone:
                info += f"\n📱 شماره ثبت‌شده: {phone}"
            await msg.reply_text(info)
        elif awaiting_support.get(user.id):
            awaiting_support.pop(user.id)
            await msg.reply_text("✅ پیام شما ارسال شد. منتظر پاسخ باشید.")
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("📩 پاسخ", callback_data=f"reply_{user.id}")]
            ])
            try:
                await context.bot.copy_message(chat_id=ADMIN_ID, from_chat_id=msg.chat_id, message_id=msg.message_id)
                await context.bot.send_message(chat_id=ADMIN_ID,
                    text=f"👤 از: {user.full_name} ({user.id})",
                    reply_markup=keyboard)
            except Exception as e:
                logger.error(f"ارسال پیام پشتیبانی به ادمین ناموفق بود: {e}")
        else:
            await msg.reply_text("از دکمه‌ها استفاده کن 🙂")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data.startswith("reply_"):
        user_id = int(query.data.split("_")[1])
        reply_targets[ADMIN_ID] = user_id
        await query.message.reply_text("✉️ پیام خود را برای کاربر بفرستید:")

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.ALL, handle_message))
    print("ربات اجرا شد...")
    app.run_polling()