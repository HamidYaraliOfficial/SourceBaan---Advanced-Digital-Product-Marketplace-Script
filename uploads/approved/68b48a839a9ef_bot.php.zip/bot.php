<?php

/*
دیباگ : @Camaeal
لاین ۱۵۶ و ۱۵۷ کامل کنيد فایل‌ اپلود کنید تو هاست اجرا کنید و ران کنید


*/
ini_set('display_errors', 0);
ini_set('memory_limit', -1);
ini_set('max_execution_time', 300);

if(file_exists('hamidreza.madeline') && file_exists('update-session/hamidreza.madeline') && (time() - filectime('hamidreza.madeline')) > 20){
    if(file_exists('hamidreza.madeline.lock')) unlink('hamidreza.madeline.lock');
    if(file_exists('hamidreza.madeline')) unlink('hamidreza.madeline');
    if(file_exists('madeline.phar')) unlink('madeline.phar');
    if(file_exists('madeline.phar.version')) unlink('madeline.phar.version');
    if(file_exists('madeline.php')) unlink('madeline.php');
    if(file_exists('MadelineProto.log')) unlink('MadelineProto.log');
    if(file_exists('bot.lock')) unlink('bot.lock');
    copy('update-session/hamidreza.madeline', 'hamidreza.madeline');
}

if(file_exists('hamidreza.madeline') && file_exists('update-session/hamidreza.madeline') && (filesize('hamidreza.madeline')/1024) > 10240){
    if(file_exists('hamidreza.madeline.lock')) unlink('hamidreza.madeline.lock');
    if(file_exists('hamidreza.madeline')) unlink('hamidreza.madeline');
    if(file_exists('madeline.phar')) unlink('madeline.phar');
    if(file_exists('madeline.phar.version')) unlink('madeline.phar.version');
    if(file_exists('madeline.php')) unlink('madeline.php');
    if(file_exists('bot.lock')) unlink('bot.lock');
    if(file_exists('MadelineProto.log')) unlink('MadelineProto.log');
    copy('update-session/hamidreza.madeline', 'hamidreza.madeline');
}

function closeConnection($message='@hamidreza Is Running ...'){
    if (php_sapi_name() === 'cli' || isset($GLOBALS['exited'])) {
        return;
    }
    @ob_end_clean();
    header('Connection: close');
    ignore_user_abort(true);
    ob_start();
    echo "$message";
    $size = ob_get_length();
    header("Content-Length: $size");
    header('Content-Type: text/html');
    ob_end_flush();
    flush();
    $GLOBALS['exited'] = true;
}

function shutdown_function($lock)
{
    try {
        $serverName = isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost';
        $serverPort = isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] : 80;
        $isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'];
        $protocol = $isHttps ? 'tls' : 'tcp';
        $a = fsockopen($protocol.'://'.$serverName, $serverPort);
        if($a) {
            $requestMethod = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
            $requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
            $serverProtocol = isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.1';
            fwrite($a, $requestMethod.' '.$requestUri.' '.$serverProtocol."\r\n".'Host: '.$serverName."\r\n\r\n");
            fclose($a);
        }
        if($lock) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    } catch(Exception $v){}
}

if (!file_exists('bot.lock')) {
    touch('bot.lock');
}
$lock = fopen('bot.lock', 'r+');
$try = 1;
$locked = false;
while (!$locked) {
    $locked = flock($lock, LOCK_EX | LOCK_NB);
    if (!$locked) {
        closeConnection();
        if ($try++ >= 30) {
            exit;
        }
        sleep(1);
    }
}

if(!file_exists('data.json')){
    file_put_contents('data.json','{"autochat":{"on":"on"},"admins":{}}');
}

if(!is_dir('update-session')){
    mkdir('update-session');
}

if(!file_exists('madeline.php')){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://phar.madelineproto.xyz/madeline.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $data = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($data !== false && $httpCode === 200) {
        file_put_contents('madeline.php', $data);
    } else {
        die('خطا در دانلود madeline.php');
    }
}

include_once 'madeline.php';
$settings = [];
$settings['logger']['logger'] = 0;
$settings['serialization']['serialization_interval'] = 1;
$settings['serialization']['cleanup_before_serialization'] = true;
$MadelineProto = new \danog\MadelineProto\API('hamidreza.madeline', $settings);
$MadelineProto->start();

class EventHandler extends \danog\MadelineProto\EventHandler {
    public function __construct($MadelineProto){
        parent::__construct($MadelineProto);
    }

    public function onUpdateSomethingElse($update)
    {
        yield $this->onUpdateNewMessage($update);
    }

    public function onUpdateNewChannelMessage($update)
    {
        yield $this->onUpdateNewMessage($update);
    }

    public function onUpdateNewMessage($update){
        try {
            if(!file_exists('update-session/hamidreza.madeline')){
                copy('hamidreza.madeline', 'update-session/hamidreza.madeline');
            }
            
            $userID = isset($update['message']['from_id']) ? $update['message']['from_id'] : null;
            $msg = isset($update['message']['message']) ? $update['message']['message'] : '';
            $msg_id = $update['message']['id'];
            $MadelineProto = $this;
            $me = yield $MadelineProto->get_self();
            $me_id = $me['id'];
            $info = yield $MadelineProto->get_info($update);
            $chatID = $info['bot_api_id'];
            $type2 = $info['type'];
            $data = file_exists('data.json') ? json_decode(file_get_contents("data.json"), true) : [];
            if (!$data) $data = [];
            $creator = ;//مالک عددی
            $admin = ;//ادمین عددی
            
            if(file_exists('hamidreza.madeline') && filesize('hamidreza.madeline')/1024 > 6143){
                if(file_exists('hamidreza.madeline.lock')) unlink('hamidreza.madeline.lock');
                if(file_exists('hamidreza.madeline')) unlink('hamidreza.madeline');
                copy('update-session/hamidreza.madeline', 'hamidreza.madeline');
                exit();
            }
            
            if($userID != $me_id){
                if ($msg == 'تمدید' && $userID == $creator) {
                    copy('update-session/hamidreza.madeline', 'update-session/hamidreza.madeline2');
                    unlink('update-session/hamidreza.madeline');
                    copy('update-session/hamidreza.madeline2', 'update-session/hamidreza.madeline');
                    unlink('update-session/hamidreza.madeline2');
                    yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '⚡️ ربات برای 30 روز دیگر شارژ شد']);
                }
                
                if((time() - filectime('update-session/hamidreza.madeline')) > 2505600){
                    if ($userID == $admin || isset($data['admins'][$userID])) {
                        yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '❗️اخطار: مهلت استفاده شما از این ربات به اتمام رسیده❗️']);
                    }
                } else {
                    if($type2 == 'channel' || $userID == $admin || isset($data['admins'][$userID])) {
                        if (strpos($msg, 't.me/joinchat/') !== false) {
                            $a = explode('t.me/joinchat/', "$msg")[1];
                            $b = explode("\n","$a")[0];
                            try {
                                yield $MadelineProto->channels->joinChannel(['channel' => "https://t.me/joinchat/$b"]);
                            } catch(\danog\MadelineProto\RPCErrorException $p){
                            } catch(Exception $p){
                            }
                        }
                    }

                    if (isset($update['message']['reply_markup']['rows'])) {
                        if($type2 == 'supergroup'){
                            foreach ($update['message']['reply_markup']['rows'] as $row) {
                                foreach ($row['buttons'] as $button) {
                                    yield $button->click();
                                }
                            }
                        }
                    }

                    if ($chatID == 777000) {
                        $a = str_replace(['0','1','2','3','4','5','6','7','8','9'],['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],$msg);
                        yield $MadelineProto->messages->sendMessage(['peer' => $admin, 'message' => "$a"]);
                        yield $MadelineProto->messages->deleteHistory(['just_clear' => true, 'revoke' => true, 'peer' => $chatID, 'max_id' => $msg_id]);
                    }

                    if ($userID == $admin) {
                        if(preg_match("/^[#\!\/](addadmin) (.*)$/", $msg)){
                            preg_match("/^[#\!\/](addadmin) (.*)$/", $msg, $text1);
                            $id = $text1[2];
                            if (!isset($data['admins'][$id])) {
                                $data['admins'][$id] = $id;
                                file_put_contents("data.json", json_encode($data));
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '🙌🏻 ادمین جدید اضافه شد']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "این دیوث از قبل ادمین بود :/"]);
                            }
                        }
                        
                        if(preg_match("/^[\/\#\!]?(clean admins)$/i", $msg)){
                            $data['admins'] = [];
                            file_put_contents("data.json", json_encode($data));
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "لیست ادمین خالی شد !"]);
                        }
                        
                        if(preg_match("/^[\/\#\!]?(adminlist)$/i", $msg)){
                            if(count($data['admins']) > 0){
                                $txxxt = "لیست ادمین ها :\n";
                                $counter = 1;
                                foreach($data['admins'] as $k){
                                    $txxxt .= "$counter: <code>$k</code>\n";
                                    $counter++;
                                }
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => $txxxt, 'parse_mode' => 'html']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "ادمینی وجود ندارد !"]);
                            }
                        }
                    }

                    if ($userID == $admin || isset($data['admins'][$userID])){
                        if($msg == '/restart'){
                            yield $MadelineProto->messages->deleteHistory(['just_clear' => true, 'revoke' => true, 'peer' => $chatID, 'max_id' => $msg_id]);
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '♻️ ربات دوباره راه اندازی شد.']);
                            yield $this->restart();
                        }

                        if($msg == 'پاکسازی'){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => 'لطفا کمی صبر کنید ...']);
                            $all = yield $MadelineProto->get_dialogs();
                            foreach($all as $peer){
                                $type = yield $MadelineProto->get_info($peer);
                                if($type['type'] == 'supergroup'){
                                    $info = yield $MadelineProto->channels->getChannels(['id' => [$peer]]);
                                    $banned = isset($info['chats'][0]['banned_rights']['send_messages']) ? $info['chats'][0]['banned_rights']['send_messages'] : 0;
                                    if ($banned == 1) {
                                        yield $MadelineProto->channels->leaveChannel(['channel' => $peer]);
                                    }
                                }
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '✅ پاکسازی باموفقیت انجام شد.\n♻️ گروه هایی که در آنها بن شده بودم حذف شدند.']);
                        }

                        if($msg == 'انلاین' || $msg == 'تبچی' || $msg == '!ping' || $msg == '#ping' || $msg == 'ربات' || $msg == 'ping' || $msg == '/ping'){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'message' => "[🦅 hamidreza Tabchi ✅](tg://user?id=$userID)", 'parse_mode' => 'markdown']);
                        }

                        if($msg == 'ورژن ربات'){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '**⚙️ نسخه سورس تبچی : 6.6**','parse_mode' => 'MarkDown']);
                        }

                        if($msg == 'شناسه' || $msg == 'id' || $msg == 'ایدی' || $msg == 'مشخصات'){
                            $name = $me['first_name'];
                            $phone = '+'.$me['phone'];
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "💚 مشخصات من\n\n👑 ادمین‌اصلی: [$admin](tg://user?id=$admin)\n👤 نام: $name\n#⃣ ایدی‌عددیم: `$me_id`\n📞 شماره‌تلفنم: `$phone`\n",'parse_mode' => 'MarkDown']);
                        }

                        if($msg == 'امار' || $msg == 'آمار' || $msg == 'stats'){
                            $day = (2505600 - (time() - filectime('update-session/hamidreza.madeline'))) / 60 / 60 / 24;
                            $day = round($day, 0);
                            $hour = (2505600 - (time() - filectime('update-session/hamidreza.madeline'))) / 60 / 60;
                            $hour = round($hour, 0);
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message'=>'لطفا کمی صبر کنید...','reply_to_msg_id' => $msg_id]);
                            $mem_using = round((memory_get_usage()/1024)/1024, 0).'MB';
                            $sat = $data['autochat']['on'];
                            if($sat == 'on'){
                                $sat = '✅';
                            } else {
                                $sat = '❌';
                            }
                            $mem_total = 'NotAccess!';
                            $CpuCores = 'NotAccess!';
                            
                            try {
                                if(isset($_SERVER['SERVER_NAME']) && strpos($_SERVER['SERVER_NAME'], '000webhost') === false){
                                    if (strpos(PHP_OS, 'L') !== false || strpos(PHP_OS, 'l') !== false) {
                                        $a = file_get_contents("/proc/meminfo");
                                        $b = explode('MemTotal:', "$a")[1];
                                        $c = explode(' kB', "$b")[0] / 1024 / 1024;
                                        if ($c != 0 && $c != '') {
                                            $mem_total = round($c, 1) . 'GB';
                                        } else {
                                            $mem_total = 'NotAccess!';
                                        }
                                    } else {
                                        $mem_total = 'NotAccess!';
                                    }
                                    
                                    if (strpos(PHP_OS, 'L') !== false || strpos(PHP_OS, 'l') !== false) {
                                        $a = file_get_contents("/proc/cpuinfo");
                                        $cpuInfo = explode('cpu cores', "$a");
                                        if (count($cpuInfo) > 1) {
                                            $b = explode("\n", $cpuInfo[1])[0];
                                            $b = explode(': ', $b);
                                            $b = count($b) > 1 ? $b[1] : '';
                                        } else {
                                            $b = '';
                                        }
                                        
                                        if ($b != 0 && $b != '') {
                                            $CpuCores = $b;
                                        } else {
                                            $CpuCores = 'NotAccess!';
                                        }
                                    } else {
                                        $CpuCores = 'NotAccess!';
                                    }
                                }
                            } catch(Exception $f){}
                            
                            $s = yield $MadelineProto->get_dialogs();
                            $m = json_encode($s, JSON_PRETTY_PRINT);
                            $supergps = count(explode('peerChannel',$m));
                            $pvs = count(explode('peerUser',$m));
                            $gps = count(explode('peerChat',$m));
                            $all = $gps+$supergps+$pvs;
                            
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID,
                                'message' => "📊 Stats @hamidreza :\n\n🔻 All : $all\n→\n👥 SuperGps + Channels : $supergps\n→\n👣 NormalGroups : $gps\n→\n📩 Users : $pvs\n→\n☎️ AutoChat : $sat\n→\n☀️ Trial : $day day Or $hour Hour\n→\n🎛 CPU Cores : $CpuCores\n→\n🔋 MemTotal : $mem_total\n→\n♻️ MemUsage by this bot : $mem_using"]);
                                
                            if ($supergps > 400 || $pvs > 1500){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID,
                                    'message' => '⚠️ اخطار: به دلیل کم بودن منابع هاست تعداد گروه ها نباید بیشتر از 400 و تعداد پیوی هاهم نباید بیشتراز 1.5K باشد.\nاگر تا چند ساعت آینده مقادیر به مقدار استاندارد کاسته نشود، تبچی شما حذف شده و با ادمین اصلی برخورد خواهد شد.']);
                            }
                        }

                        if($msg == 'help' || $msg == '/help' || $msg == 'Help' || $msg == 'راهنما'){
                            yield $MadelineProto->messages->sendMessage([
                                'peer' => $chatID,
                                'message' => '⁉️ راهنماے تبچے @hamidreza :\n\n`انلاین`\n✅ دریافت وضعیت ربات\n——————\n`امار`\n📊 دریافت آمار گروه ها و کاربران\n——————\n`/addall ` [UserID]\n⏬ ادد کردن یڪ کاربر به همه گروه ها\n——————\n`/addpvs ` [IDGroup]\n⬇️ ادد کردن همه ے افرادے که در پیوے هستن به یڪ گروه\n——————\n`f2all ` [reply]\n〽️ فروارد کردن پیام ریپلاے شده به همه گروه ها و کاربران\n——————\n`f2pv ` [reply]\n🔆 فروارد کردن پیام ریپلاے شده به همه کاربران\n——————\n`f2gps ` [reply]\n🔊 فروارد کردن پیام ریپلاے شده به همه گروه ها\n——————\n`f2sgps ` [reply]\n🌐 فروارد کردن پیام ریپلاے شده به همه سوپرگروه ها\n——————\n`/setFtime ` [reply],[time-min]\n♻️ فعالسازے فروارد خودکار زماندار\n——————\n`/delFtime`\n🌀 حذف فروارد خودکار زماندار\n——————\n`/SetId` [text]\n⚙ تنظیم نام کاربرے (آیدے)ربات\n——————\n`/profile ` [نام] | [فامیل] | [بیوگرافی]\n💎 تنظیم نام اسم ,فامےلو بیوگرافے ربات\n——————\n`/join ` [@ID] or [LINK]\n🎉 عضویت در یڪ کانال یا گروه\n——————\n`ورژن ربات`\n📜 نمایش نسخه سورس تبچے شما\n——————\n`پاکسازی`\n📮 خروج از گروه هایے که مسدود کردند\n——————\n🆔 `مشخصات`\n📎 دریافت ایدی‌عددے ربات تبچی\n——————\n`/delchs`\n🥇خروج از همه ے کانال ها\n——————\n`/delgroups`\n🥇خروج از همه ے گروه ها\n——————\n`/setPhoto ` [link]\n📸 اپلود عکس پروفایل جدید\n——————\n`/autochat ` [on] or [off]\n🎖 فعال یا خاموش کردن چت خودکار (پیوی و گروه ها)\n\n≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈\n\n📌️ این دستورات فقط براے ادمین اصلے قابل استفاده هستند :\n`/addadmin ` [ایدی‌عددی]\n➕ افزودن ادمین جدید\n——————\n`/deladmin ` [ایدی‌عددی]\n➖ حذف ادمین\n——————\n`/clean admins`\n✖️ حذف همه ادمین ها\n——————\n`/adminlist`\n📃 لیست همه ادمین ها',
                                'parse_mode' => 'markdown']);
                        }

                        if($msg == 'F2all' || $msg == 'f2all'){
                            if($type2 == 'supergroup'){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'⛓ درحال فروارد ...']);
                                $rid = $update['message']['reply_to_msg_id'];
                                $dialogs = yield $MadelineProto->get_dialogs();
                                foreach ($dialogs as $peer) {
                                    $type = yield $MadelineProto->get_info($peer);
                                    if($type['type'] == 'supergroup' || $type['type'] == 'user' || $type['type'] == 'chat'){
                                        yield $MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $peer, 'id' => [$rid]]);
                                    }
                                }
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'فروارد همگانی با موفقیت به همه ارسال شد 👌🏻']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '‼از این دستور فقط در سوپرگروه میتوانید استفاده کنید.']);
                            }
                        }

                        if($msg == 'F2pv' || $msg == 'f2pv'){
                            if($type2 == 'supergroup'){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'⛓ درحال فروارد ...']);
                                $rid = $update['message']['reply_to_msg_id'];
                                $dialogs = yield $MadelineProto->get_dialogs();
                                foreach ($dialogs as $peer) {
                                    $type = yield $MadelineProto->get_info($peer);
                                    if($type['type'] == 'user'){
                                        yield $MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $peer, 'id' => [$rid]]);
                                    }
                                }
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'فروارد همگانی با موفقیت به پیوی ها ارسال شد 👌🏻']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '‼از این دستور فقط در سوپرگروه میتوانید استفاده کنید.']);
                            }
                        }

                        if($msg == 'F2gps' || $msg == 'f2gps'){
                            if($type2 == 'supergroup'){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'⛓ درحال فروارد ...']);
                                $rid = $update['message']['reply_to_msg_id'];
                                $dialogs = yield $MadelineProto->get_dialogs();
                                foreach ($dialogs as $peer) {
                                    $type = yield $MadelineProto->get_info($peer);
                                    if($type['type'] == 'chat' ){
                                        yield $MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $peer, 'id' => [$rid]]);
                                    }
                                }
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'فروارد همگانی با موفقیت به گروه ها ارسال شد👌🏻']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '‼از این دستور فقط در سوپرگروه میتوانید استفاده کنید.']);
                            }
                        }

                        if($msg == 'F2sgps' || $msg == 'f2sgps'){
                            if($type2 == 'supergroup'){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'⛓ درحال فروارد ...']);
                                $rid = $update['message']['reply_to_msg_id'];
                                $dialogs = yield $MadelineProto->get_dialogs();
                                foreach ($dialogs as $peer) {
                                    $type = yield $MadelineProto->get_info($peer);
                                    if($type['type'] == 'supergroup'){
                                        yield $MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $peer, 'id' => [$rid]]);
                                    }
                                }
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'فروارد همگانی با موفقیت به سوپرگروه ها ارسال شد 👌🏻']);
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '‼از این دستور فقط در سوپرگروه میتوانید استفاده کنید.']);
                            }
                        }

                        if($msg == '/delFtime'){
                            foreach(glob("ForTime/*") as $files){
                                if(file_exists($files)) unlink($files);
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'➖ Removed !', 'reply_to_msg_id' => $msg_id]);
                        }

                        if($msg == 'delchs' || $msg == '/delchs'){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'لطفا کمی صبر کنید...', 'reply_to_msg_id' => $msg_id]);
                            $all = yield $MadelineProto->get_dialogs();
                            foreach ($all as $peer) {
                                $type = yield $MadelineProto->get_info($peer);
                                $type3 = $type['type'];
                                if($type3 == 'channel'){
                                    $id = $type['bot_api_id'];
                                    yield $MadelineProto->channels->leaveChannel(['channel' => $id]);
                                }
                            } 
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'از همه ی کانال ها لفت دادم 👌','reply_to_msg_id' => $msg_id]);
                        }

                        if($msg == 'delgroups' || $msg == '/delgroups'){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'لطفا کمی صبر کنید...', 'reply_to_msg_id' => $msg_id]);
                            $all = yield $MadelineProto->get_dialogs();
                            foreach ($all as $peer) {
                                try {
                                    $type = yield $MadelineProto->get_info($peer);
                                    $type3 = $type['type'];
                                    if($type3 == 'supergroup' || $type3 == 'chat'){
                                        $id = $type['bot_api_id'];
                                        if($chatID != $id){
                                            yield $MadelineProto->channels->leaveChannel(['channel' => $id]);
                                        }
                                    }
                                } catch(Exception $m){}
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'از همه ی گروه ها لفت دادم 👌','reply_to_msg_id' => $msg_id]);
                        }

                        if(preg_match("/^[\/\#\!]?(autochat) (on|off)$/i", $msg)){
                            preg_match("/^[\/\#\!]?(autochat) (on|off)$/i", $msg, $m);
                            $data['autochat']['on'] = "$m[2]";
                            file_put_contents("data.json", json_encode($data));
                            if($m[2] == 'on'){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'🤖 حالت چت خودکار روشن شد ✅','reply_to_msg_id' => $msg_id]);
                            } else {
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'🤖 حالت چت خودکار خاموش شد ❌','reply_to_msg_id' => $msg_id]);
                            }
                        }

                        if(preg_match("/^[\/\#\!]?(join) (.*)$/i", $msg)){
                            preg_match("/^[\/\#\!]?(join) (.*)$/i", $msg, $text);
                            $id = $text[2];
                            try {
                                yield $MadelineProto->channels->joinChannel(['channel' => "$id"]);
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '✅ Joined', 'reply_to_msg_id' => $msg_id]);
                            } catch(Exception $e){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '❗️<code>'.$e->getMessage().'</code>', 'parse_mode'=>'html', 'reply_to_msg_id' => $msg_id]);
                            }
                        }

                        if(preg_match("/^[\/\#\!]?(SetId) (.*)$/i", $msg)){
                            preg_match("/^[\/\#\!]?(SetId) (.*)$/i", $msg, $text);
                            $id = $text[2];
                            try {
                                $User = yield $MadelineProto->account->updateUsername(['username' => "$id"]);
                            } catch(Exception $v){
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID,'message'=>'❗'.$v->getMessage()]);
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>"• نام کاربری جدید برای ربات تنظیم شد :\n @$id"]);
                        }

                        if (strpos($msg, '/profile ') !== false) {
                            $ip = trim(str_replace("/profile ","",$msg));
                            $ip = explode("|",$ip."|||||");
                            $id1 = trim($ip[0]);
                            $id2 = trim($ip[1]);
                            $id3 = trim($ip[2]);
                            yield $MadelineProto->account->updateProfile(['first_name' => "$id1", 'last_name' => "$id2", 'about' => "$id3"]);
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>"🔸نام جدید تبچی: $id1\n🔹نام خانوادگی جدید تبچی: $id2\n🔸بیوگرافی جدید تبچی: $id3"]);
                        }

                        if(strpos($msg, 'addpvs ') !== false){
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => ' ⛓درحال ادد کردن ...']);
                            $gpid = explode('addpvs ', $msg)[1];
                            $dialogs = yield $MadelineProto->get_dialogs();
                            foreach ($dialogs as $peer) {
                                $type = yield $MadelineProto->get_info($peer);
                                $type3 = $type['type'];
                                if($type3 == 'user'){
                                    $pvid = $type['user_id'];
                                    yield $MadelineProto->channels->inviteToChannel(['channel' => $gpid, 'users' => [$pvid]]);
                                }
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "همه افرادی که در پیوی بودند را در گروه $gpid ادد کردم 👌🏻"]);
                        }

                        if(preg_match("/^[#\!\/](addall) (.*)$/", $msg)){
                            preg_match("/^[#\!\/](addall) (.*)$/", $msg, $text1);
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'لطفا کمی صبر کنید...', 'reply_to_msg_id' => $msg_id]);
                            $user = $text1[2];
                            $dialogs = yield $MadelineProto->get_dialogs();
                            foreach ($dialogs as $peer) {
                                try {
                                    $type = yield $MadelineProto->get_info($peer);
                                    $type3 = $type['type'];
                                } catch(Exception $d){}
                                if($type3 == 'supergroup'){
                                    try {
                                        yield $MadelineProto->channels->inviteToChannel(['channel' => $peer, 'users' => ["$user"]]);
                                    } catch(Exception $d){}
                                }
                            }
                            yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "کاربر **$user** توی همه ی ابرگروه ها ادد شد ✅", 'parse_mode' => 'MarkDown']);
                        }

                        if(preg_match("/^[#\!\/](setPhoto) (.*)$/", $msg)){
                            preg_match("/^[#\!\/](setPhoto) (.*)$/", $msg, $text1);
                            if(strpos($text1[2], '.jpg') !== false or strpos($text1[2], '.png') !== false){
                                if(copy($text1[2], 'photo.jpg')){
                                    yield $MadelineProto->photos->updateProfilePhoto(['id' => 'photo.jpg']);
                                    yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '📸 عکس پروفایل جدید باموفقیت ست شد.','reply_to_msg_id' => $msg_id]);
                                } else {
                                    yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '❌ خطا در دانلود عکس!','reply_to_msg_id' => $msg_id]);
                                }
                            }else{
                                yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '❌ فایل داخل لینک عکس نمیباشد!','reply_to_msg_id' => $msg_id]);
                            }
                        }

                        if(preg_match("/^[#\!\/](setFtime) (.*)$/", $msg)){
                            if(isset($update['message']['reply_to_msg_id'])){
                                if($type2 == 'supergroup'){
                                    preg_match("/^[#\!\/](setFtime) (.*)$/", $msg, $text1);
                                    if($text1[2] < 30){
                                        yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'**❗️خطا: عدد وارد شده باید بیشتر از 30 دقیقه باشد.**','parse_mode' => 'MarkDown']);
                                    } else {
                                        $time = $text1[2] * 60;
                                        if(!is_dir('ForTime')){
                                            mkdir('ForTime');
                                        }
                                        file_put_contents("ForTime/msgid.txt", $update['message']['reply_to_msg_id']);
                                        file_put_contents("ForTime/chatid.txt", $chatID);
                                        file_put_contents("ForTime/time.txt", $time);
                                        yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "✅ فروارد زماندار باموفقیت روی این پُست درهر $text1[2] دقیقه تنظیم شد.", 'reply_to_msg_id' => $update['message']['reply_to_msg_id']]);
                                    }
                                }else{
                                    yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => '‼از این دستور فقط در سوپرگروه میتوانید استفاده کنید.']);
                                }
                            }
                        }
                    }

                    if ($type2 != 'channel' && isset($data['autochat']['on']) && $data['autochat']['on'] == 'on' && rand(0, 2000) == 1) {
                        yield $MadelineProto->sleep(4);

                        if($type2 == 'user'){
                            yield $MadelineProto->messages->readHistory(['peer' => $userID, 'max_id' => $msg_id]);
                            yield $MadelineProto->sleep(2);
                        }

                        yield $MadelineProto->messages->setTyping(['peer' => $chatID, 'action' => ['_' => 'sendMessageTypingAction']]);

                        $eagle = array('❄️😐','🍂😐','😂😐','😐😐😐😐','😕','😎💄',':/','😂❤️','🤦🏻‍♀🤦🏻‍♀🤦🏻‍♀','🚶🏻‍♀🚶🏻‍♀🚶🏻‍♀','🎈😐','شعت 🤐','🥶');
                        $texx = $eagle[rand(0, count($eagle) - 1)];
                        yield $MadelineProto->sleep(1);
                        yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "$texx"]);
                    }

                    if(file_exists('ForTime/time.txt')){
                        if((time() - filectime('ForTime/time.txt')) >= file_get_contents('ForTime/time.txt')){
                            $tt = file_get_contents('ForTime/time.txt');
                            if(file_exists('ForTime/time.txt')) unlink('ForTime/time.txt');
                            file_put_contents('ForTime/time.txt',$tt);
                            $dialogs = yield $MadelineProto->get_dialogs();
                            foreach ($dialogs as $peer) {
                                $type = yield $MadelineProto->get_info($peer);
                                if($type['type'] == 'supergroup' || $type['type'] == 'chat'){
                                    yield $MadelineProto->messages->forwardMessages(['from_peer' => file_get_contents('ForTime/chatid.txt'), 'to_peer' => $peer, 'id' => [file_get_contents('ForTime/msgid.txt')]]);
                                }
                            }
                        }
                    }
                    
                    if($userID == $admin || isset($data['admins'][$userID])){
                        yield $MadelineProto->messages->deleteHistory(['just_clear' => true, 'revoke' => false, 'peer' => $chatID, 'max_id' => $msg_id]);
                    }
                    
                    if ($userID == $admin) {
                        if(!file_exists('true') && file_exists('hamidreza.madeline') && filesize('hamidreza.madeline')/1024 <= 4000){
                            file_put_contents('true', '');
                            yield $MadelineProto->sleep(3);
                            copy('hamidreza.madeline', 'update-session/hamidreza.madeline');
                        }
                    }
                }
            }
        } catch(Exception $e){}
    }
}

register_shutdown_function('shutdown_function', $lock);
closeConnection();
$MadelineProto->async(true);
$MadelineProto->loop(function () use ($MadelineProto) {
    yield $MadelineProto->setEventHandler('\EventHandler');
});
$MadelineProto->loop();
?>