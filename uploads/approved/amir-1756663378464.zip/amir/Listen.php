<?php
//@MadeLineproto_F
if(file_exists('MadelineProto.log')){
unlink("MadelineProto.log");
}
if(!file_exists('madeline.php')){
copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
} /// @MadeLineproto_F
include 'madeline.php';
ini_set('memory_limit', '256M');
class EventHandler extends \danog\MadelineProto\EventHandler{
public function __construct($MadelineProto){
parent::__construct($MadelineProto);
}

public function onUpdateNewChannelMessage($update){
yield $this->onUpdateNewMessage($update);
}  // @MadeLineproto_F
public function onUpdateNewMessage($update){
$userID = @$update['message']['from_id'];
$message = isset($update['message']) ? $update['message']:'';
$msg = isset($update['message']['message']) ? $update['message']['message']:'';
$msg_id = $update['message']['id'];
$me = yield $this->get_self();
 $adm = $me['id'];
$chID = yield $this->get_info($update);
$chatID = $chID['bot_api_id'];
$type = $chID['type'];
@$data = json_decode(file_get_contents("data.json"), true);
$chat_id= str_replace("-","",$chatID);
// ایدی عددی ادمین رو بذارید 
$admin = "1377243724";
if(!file_exists('Admin.txt')){
//	file_put_contents("Admin.txt","\n");
$fh = fopen("Admin.txt", 'wp') or die("Could not create the file.");
    fwrite($fh, "\n") or die("Could not write to the file.");
    fclose($fh);
}if(!file_exists('linkgroup.txt')){
//	file_put_contents("Admin.txt","\n");
$fh = fopen("linkgroup.txt", 'wp') or die("Could not create the file.");
    fwrite($fh, "\n") or die("Could not write to the file.");
    fclose($fh);
}
$listAdmin=file_get_contents("Admin.txt");
$ldmin = explode("\n",$listAdmin);

$op = @$update['pts'];
try{
if(!isset($data['lock']["$chatID"])) $data['lock']["$chatID"] = 0;
if($op > $data['lock']["$chatID"]){
	if($msg=="Help"){
		$txt="
		♻راهنمای کلی ربات

✓دستورات کاربران
Help Member
✓دستورات ادمین ها
Help Admin
✓دستورات سازنده
Help Creator

★★ربات به حروف بزرگ و کوچک حساس هست !!
★★دستورات را به درستی وارد کنید !!
		";
		
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);
		}if($msg=="Help Member"){
			$txt="
			♻راهنمای کاربران

✓دریافت مشخصات کاربر با ریپلی
User Info
✓منشن کاربر با ایدی یا یوزرنیم
Check (ID | User)
✓دریافت ایدی عددی
Chat ID
✓دریافت لینک پیام در گروه
Msg Link
✓روز شمار عید
Eid
✓زیبا نویس اسم
Font (Name)
✓ساخت لوگو
Logo (Name (Num 1-5)
✓چک کردن وضعیت هوا
Weather (City)
✓سرچ موزیک ملوبیت
Music (Name)
✓تبدیل فینگلیش به فارسی
Finglish (Text)
✓چک کردن صحت کدملی
Meli (Num)
✓شعر غزلیات سعدی
Ghazal
✓بیو خاص بصورت رندوم
Bio
✓دریافت تاریخ و ساعت
Time
			";
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);
			}
			if($msg=="ID Bot"){
				
				yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"Your ID is $userID\nID Bot is $adm"]);
				}
			if($msg=="Help Admin"){
			if(in_array($userID,$ldmin)  or $userID == $admin){
				
			$txt="
			♻راهنمای ادمین ها 

✓حالت تایپینگ روشن
Typing On
✓حالت تایپینگ خاموش
Typing Off
✓خراب کردن گروه
Start Fuck
✓پایان خرابکاری گروه
Finish Fuck
✓سکوت کاربر با ریپلی
Mute
✓در آوردن سکوت کاربر با ریپلی
UnMute
✓بلاک کردن کاربر از ربات
Block
✓انبلاک کردن کاربر از ربات
UnBlock
✓حذف کاربر از گروه 
Kick (ID)
✓حذف کاربر از گروه با ریپلی
Kick
✓ارسال پیام به پیوی با ریپلی
Send Pv
✓تگ کردن همه ی کاربران گروه
Tag All
✓ساخت گروه دو نفره (در پیوی)
Create Group
✓ساخت سوپرگروه
Create SuperGp
✓ثبت کاربر هدف برای شنود
Add User (ID)
✓حذف کاربر هدف شنود شده
Del User (ID)
✓ثبت کانال فوروارد شنود
Set For (ID)
✓حذف همه کاربران هدف شنود
Clean User
✓عضویت در گروه با لینک
Join (Link)
			";	
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);

				}else{
					
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"شما دسترسی به این بخش را ندارید🚫"]);
				}
			
			}if($msg=="Help Creator"){
				if($userID != $admin){
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"شما دسترسی به این بخش را ندارید🚫"]);
					}else{
					$txt="
	♻راهنمای سازنده

✓وضعیت پنل ربات
Status Panel
✓حالت پاسخ خودکار روشن
Auto Answer On
✓حالت پاسخ خودکار خاموش
Auto Answer Off
✓تعیین پاسخ و جواب
Set Answer (Ans1|Ans2)
✓حذف پاسخ خودکار
Del Answer
✓لیست پاسخ ها
Answer List
✓حالت تبچی روشن
Tabchi On
✓حالت تبچی خاموش
Tabchi Off
✓دریافت لینک های سیو شده تبچی
Link List
✓آمار گروه و پیوی ها
Stats Group
✓افزودن ادمین با ریپلی
Add Admin
✓حذف ادمین
Remove Admin (ID)
✓لیست ادمین
Admin UserList
✓مقدار رم استفاده شده
Memory Usage
✓بازسازی ربات
Reload
					";
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);

					}
				}if($msg=="Msg Link" and isset($update['message']['reply_to_msg_id'])){
			if($type=="supergroup"){
			$msg_id = $update['message']['reply_to_msg_id'];
			$ch =$update['message']['to_id']['channel_id'] ?? null;
			$txt ="http://t.me/c/$ch/$msg_id";
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$txt"]);
	}
			}
	if($type=="user"){
		if($msg=="سلام"){
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"سلام چه خبر"]);
			
			}
		}
		if($msg=="Info Me"){
			$me = yield $this->getFullInfo($userID);
			$name = $me['User']['first_name'];
			$phone = $me['User']['phone'];
			$id= $me['User']['id'];
			$te="
			
			";
		//	$to =json_encode($me);
		//	file_put_contents("me.txt",$to);
			
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"ok \n $te"]);
		
			}
			if(preg_match('/^(Logo (.*) (.*))$/i',$msg)){
				preg_match('/^(Logo (.*) (.*))$/i',$msg,$text1);
		$tex = $text1[2];
		$style = $text1[3];
		//		$tex = $text1[2];
		$textt=str_replace(" ","%20",$tex);
				$url="https://codebazan.ir/Tools/text_to_img/?text=$tex&style=$style";
		//		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$url]);
				yield $this->messages->sendMedia([
    'peer' => $chatID,
    'media' => [
        '_' => 'inputMediaUploadedDocument',
        'file' => $url,
        'attributes' => [
            ['_' => 'documentAttributeImageSize'],
            ['_' => 'documentAttributeFilename', 'file_name' => 'image.jpg']
        ]
    ],
    'message' => "$tex",
    'parse_mode' => 'Markdown'
]);
		
				}if(preg_match("/^(Music (.*))$/i", $msg)){
preg_match("/^(Music (.*))$/i", $msg, $tex);
$tex = $tex[2];
$message = yield $this->messages->getInlineBotResults(['bot' => "@melobot", 'peer' => $chatID, 'query' => $tex, 'offset' => '0']);
$query_id = $message['query_id'];
$query_res_id = $message['results'][rand(0, count($message['results']))]['id'];
yield $this->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'query_id' => $query_id, 'id' => "$query_res_id"]);
     }
	if(preg_match('/^(Finglish (.*))$/i',$msg)){
		preg_match('/^(Finglish (.*))$/i',$msg,$text1);
		$tex = $text1[2];
		$textt=str_replace(" ","%20",$tex);
			$url="https://api.codebazan.ir/fintofa/?text=$textt";
			$put=json_decode(file_get_contents($url),true);
			$res=$put['result'];
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$res]);
		
			}
	if(preg_match('/^(Weather (.*))$/i',$msg)){
		
		preg_match('/^(Weather (.*))$/i',$msg,$text1);
$tex = $text1[2];
$texttt=str_replace(" ","%20",$tex);
$url = json_decode(file_get_contents("http://api.openweathermap.org/data/2.5/weather?q=".$texttt."&appid=eedbc05ba060c787ab0614cad1f2e12b&units=metric"), true);
$city = $url["name"];
$deg = $url["main"]["temp"];
$type1 = $url["weather"][0]["main"];
if($type1 == "Clear"){
		$tpp = 'آفتابی☀';
		file_put_contents('type.txt',$tpp);
	}
	elseif($type1 == "Clouds"){
		$tpp = 'ابری ☁☁';
		file_put_contents('type.txt',$tpp);
	}
	elseif($type1 == "Rain"){
		 $tpp = 'بارانی ☔';
file_put_contents('type.txt',$tpp);
	}
	elseif($type1 == "Thunderstorm"){
		$tpp = 'طوفانی ☔☔☔☔';
file_put_contents('type.txt',$tpp);
	}
	elseif($type1 == "Mist"){
		$tpp = 'مه 💨';
file_put_contents('type.txt',$tpp);
	}
  if($city != ''){
$eagle_tm = file_get_contents('type.txt');
  $txt = "دمای شهر $city هم اکنون $deg درجه سانتی گراد می باشد

شرایط فعلی آب و هوا: $eagle_tm";
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => $txt]);
unlink('type.txt');
}else{
 $txt = "⚠️شهر مورد نظر شما يافت نشد";
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => $txt]);
 }
		}
	if(preg_match('/^(Meli (.*))$/i',$msg)){
		preg_match('/^(Meli (.*))$/i',$msg,$text1);
$tex = $text1[2];

		$textt=str_replace(" ","%20",$tex);
$url="https://api.codebazan.ir/codemelli/?code=$textt";
$c=json_decode(file_get_contents($url),true);
//yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$url"]);
$result=$c['Result'];
if($result=="The code is valid"){
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"این کدملی معتبره☺👌"]);
		
	}else{
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"این کدملی نامعتبره😕👎"]);
		
	}
		//send("تستی $tex",$chatID);
		//yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"test"]);
		}
	if($msg=="تاریخ بده" or $msg=="Time"){
		$time= file_get_contents("http://api.codebazan.ir/time-date/?td=all");
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$time]);
		
		}
			if(preg_match('/^(Font (.*))$/i',$msg)){
preg_match('/^(Font (.*))$/i',$msg,$text1);
$tex= $text1[2];
$url="https://api.codebazan.ir/font/?text=$tex";
$f = json_decode(file_get_contents($url),true);
$ok=$f['ok'];
$result=$f['result'];
if($ok == true){
	$esm = "💠فونت های زیبا برای شما :\n\n";
	for($x=1; $x <= 40; $x++){
		
		$esm .= "$x. `".$result[$x]."`\n";
		}
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$esm",'parse_mode'=>'MarkDown']);
	
		}else{
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"🚫خطایی رخ داد ، اسم را به دقت وارد کنید!!",]);
		}
					}if($msg=="Bio"){
						$url="https://api.codebazan.ir/bio/";
						$txt=file_get_contents($url);
						yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$txt"]);

						}if($msg=="Ghazal"){
							$rand=rand(0,363);
							$url="https://api.codebazan.ir/ghazalsaadi/?type=html&id=$rand";
							$txt=file_get_contents($url);
						yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$txt"]);
							}if($msg=="Memory Usage" and $userID==$admin){
					//			$name=$_SERVER['SERVER_NAME'];
							//	$protocol = $_SERVER['SERVER_PROTOCOL'];
							//	$ip = gethostbyname('www.dashifarhad.ir');
							$mem_using = round(memory_get_usage() / 1024 / 1024,1);	
							$txt = "
							♻MeMory Usage : $mem_using Mb
							";
							yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);	
								}
						if($msg=="Eid"){
						$url="https://api.codebazan.ir/new-year/";
						$f = json_decode(file_get_contents($url),true);
						$day=$f['day'];
						$hour=$f['hour'];
						$min=$f['min'];
						$sec=$f['sec'];
						$txt="
						🎊تا عید امسال
						$day روز و $hour ساعت و $min دقیقه و $sec ثانیه مانده است😊
						
						";
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>$txt]);	
						}if(preg_match('/^(Check (.*))$/i',$msg)){
preg_match('/^(Check (.*))$/i',$msg,$text1);
$id = $text1[2];
	$ec =yield $this->getInfo($id);	
	$ix = $ec['User']['id'];
	$nam = $ec['User']['first_name'];
	
		$c = json_encode($ec);
		
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"[$nam](tg://user?id=$ix) \n$ix",'parse_mode'=>'MarkDown']);
	
		}if($msg=="User Info" and isset($update['message']['repl	y_to_msg_id'])){
	$s = $update['message']['reply_to_msg_id'];
	$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);
$re =json_encode($user_id);
$id = $user_id['messages'][0]['from_id'];
$name = $user_id['users'][0]['first_name'];
$username = $user_id['users'][0]['username'] ?? null;
$photo = $user_id['users'][0]['photo']['photo_id'] ?? null;
if($username == null){
	$username = "ندارد";
	}
	if($photo == null){
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"ایدی عددی : $id\nیوزرنیم : $username \nاسم : $name"]);
		}else{
			$tex="ایدی عددی : $id\nیوزرنیم : $username \nاسم : $name";
		
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$tex"]);
		}
	}
if(in_array($userID,$ldmin) or$userID == $admin){
$data['lock']["$chatID"] = $op;
file_put_contents("data.json", json_encode($data, 128|256));
if($msg=="Create Group"){
	yield $this->messages->createChat(['users'=>[$chatID],'title'=>"تست"]);
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"گروه با موفقیت ساخته شد✅"]);
	
	}
		
			
		
				if($msg=="Add Admin" and isset($update['message']['reply_to_msg_id']) and $userID==$admin){
					
				
						$f=file_get_contents("Admin.txt");
						$x= explode("\n",$f);
		$s = $update['message']['reply_to_msg_id'];
		if($type=="user"){
			$user_id = yield $this->messages->getMessages([
  'peer' => $update,
  'id'      => [$s]
]);
			}elseif($type=="supergroup"){
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);
}
//$re =json_encode($user_id);
$name = $user_id['users'][0]['first_name'];
$id = $user_id['messages'][0]['from_id'];
if(in_array($id,$x)){
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"🚫این کاربر از قبل در لیست ادمین وجود داشت!!"]);
	
	}else{
file_put_contents("Admin.txt","$f$id\n");
		
//		$ch = json_encode($update);
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر $name با موفقیت به لیست ادمین های ربات اضافه شد✅",'parse_mode'=>'MarkDown']);
	
			}}
			if($msg=="Reload" and $userID==$admin){
			yield $this->messages->sendMessage (['peer' => $chatID, 'text' => "♻️در حال ریستارت ربات..
"]);	
    yield $this->restart ();
    

				}
			if($msg=="Admin UserList" and $userID==$admin){
				$f=file_get_contents("Admin.txt");
				if($f=="" or $f ==" " or $f=="\n"){
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"لیست ادمین خالی میباشد🚫"]);

					}else{
				
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"لیست ادمین ها🛃\n$f"]);
}
			}if(preg_match('/^(Remove Admin (.*))$/i',$msg) and $userID==$admin){
preg_match('/^(Remove Admin (.*))$/i',$msg,$text1);
$id = $text1[2];
$listfdmin=file_get_contents("Admin.txt");
$fdmin = explode("\n",$listfdmin);
if(in_array($id,$fdmin) !== false){
	$listfdmin=file_get_contents("Admin.txt");
	$d = str_replace("$id\n","",$listfdmin);
	file_put_contents("Admin.txt",$d);
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر $id از لیست ادمین ها حذف شد✅"]);
	}else{
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"این کاربر در لیست ادمین ها وجود ندارد🚫"]);
	
	}
}if($msg=="Block" and isset($update['message']['reply_to_msg_id'])){
	$s = $update['message']['reply_to_msg_id'];
		if($type=="user"){
			$user_id = yield $this->messages->getMessages([
  'peer' => $update,
  'id'      => [$s]
]);
			}elseif($type=="supergroup"){
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);
}
//$re =json_encode($user_id);
$name = $user_id['users'][0]['first_name'];
$id = $user_id['messages'][0]['from_id'];
//preg_match("/^(Block)$/i", $msg, $m);
yield $this->contacts->block(['id' => $id]);
yield $this->messages->sendMessage(['peer' => $chatID,'message' => "کاربر مورد نظر از ربات بلاک شد✅"]);
     }if($msg=="UnBlock" and isset($update['message']['reply_to_msg_id'])){
	$s = $update['message']['reply_to_msg_id'];
		if($type=="user"){
			$user_id = yield $this->messages->getMessages([
  'peer' => $update,
  'id'      => [$s]
]);
			}elseif($type=="supergroup"){
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);
}
//$re =json_encode($user_id);
$name = $user_id['users'][0]['first_name'];
$id = $user_id['messages'][0]['from_id'];
//preg_match("/^(Block)$/i", $msg, $m);
yield $this->contacts->unblock(['id' => $id]);
yield $this->messages->sendMessage(['peer' => $chatID,'message' => "کاربر مورد نظر از ربات انبلاک شد✅"]);
     }
		if(preg_match('/^(Kick (.*))$/i',$msg)){
preg_match('/^(Kick (.*))$/i',$msg,$text1);
$id = $text1[2];
$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $id, ]);
yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از گروه حذف شد✅"]);
}if($msg=="Kick" and isset($update['message']['reply_to_msg_id'])){
	$type = $chID['type'];
//yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از گروه حذف شد✅"]);

if($type=="supergroup"){
	//$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $replyID, ]);
//$me = $this->contacts->block(['id'=>$chatID]);
	//echo var_dump(json_decode($me, true));
	$s = $update['message']['reply_to_msg_id'];
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);

$id = $user_id['messages'][0]['from_id'];
$chatBannedRights = ['_' => 'chatBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => false, 'send_inline' => true, 'embed_links' => true, 'send_polls' => true, 'change_info' => true, 'invite_users' => true, 'pin_messages' => true, 'until_date' => 366];
$Updates = $this->channels->editBanned(['channel' => $chatID, 'user_id' => $id, 'banned_rights' =>$chatBannedRights, ]);
//$re =json_encode($user_id);
/*

$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $id, ]);
*/
yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از گروه حذف شد✅"]);

//$name = $user_id['users'][0]['first_name'];
}
}if($msg=="Mute" and isset($update['message']['reply_to_msg_id'])){
	$type = $chID['type'];
//yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از گروه حذف شد✅"]);

if($type=="supergroup"){
	//$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $replyID, ]);
//$me = $this->contacts->block(['id'=>$chatID]);
	//echo var_dump(json_decode($me, true));
	$s = $update['message']['reply_to_msg_id'];
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);

$id = $user_id['messages'][0]['from_id'];
$chatBannedRights = ['_' => 'chatBannedRights', 'view_messages' => false, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => false, 'send_inline' => true, 'embed_links' => false, 'send_polls' => true, 'change_info' => true, 'invite_users' => false, 'pin_messages' => false, 'until_date' => 366];
$Updates = $this->channels->editBanned(['channel' => $chatID, 'user_id' => $id, 'banned_rights' =>$chatBannedRights, ]);
//$re =json_encode($user_id);
/*

$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $id, ]);
*/
yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر به حالت سکوت رفت✅"]);

//$name = $user_id['users'][0]['first_name'];
}
}if($msg=="UnMute" and isset($update['message']['reply_to_msg_id'])){
	$type = $chID['type'];
//yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از گروه حذف شد✅"]);

if($type=="supergroup"){
	//$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $replyID, ]);
//$me = $this->contacts->block(['id'=>$chatID]);
	//echo var_dump(json_decode($me, true));
	$s = $update['message']['reply_to_msg_id'];
	//$reply_id = $update['message']['reply_to_msg_id'] ?? null;

$user_id = yield $this->channels->getMessages([
  'channel' => $update,
  'id'      => [$s]
]);

$id = $user_id['messages'][0]['from_id'];
$chatBannedRights = ['_' => 'chatBannedRights', 'view_messages' => false, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'send_polls' => false, 'change_info' => true, 'invite_users' => false, 'pin_messages' => false, 'until_date' => 366];
$Updates = $this->channels->editBanned(['channel' => $chatID, 'user_id' => $id, 'banned_rights' =>$chatBannedRights, ]);
//$re =json_encode($user_id);
/*

$this->messages->deleteChatUser(['chat_id' => $chatID, 'user_id' => $id, ]);
*/
yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"کاربر از حالت سکوت خارج شد✅"]);

//$name = $user_id['users'][0]['first_name'];
}
}

if($msg=="Create SuperGp"){
yield 	$this->channels->createChannel(['megagroup'=>true,'title'=>"Test",'about'=>"Test"]);
//$cx = json_encode($fl);
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"سوپرگروه با موفقیت ساخته شد✅\n$cx"]);

	}if($msg=="linked"){
		$fl = $this->messages->exportChatInvite(['peer' => $chatID, ]);
		$cx = json_encode($fl);
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"سوپرگروه با موفقیت ساخته شد✅\n$cx"]);


		}
	if($msg=="Delete History"){
		for($i = $msg_id ; $i>=0;$i--){
$this->channels->deleteMessages(['channel' => $chatID, 'id' => [$i]]);
}
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"گروه با موفقیت پاکسازی شد✅"]);

		}
		if($msg=="Leave Group"){
	//	$this->channels->leaveChannel(['channel'=>['inputChannel'=>['channel_id'=>$chatID,'access_hash'=>$access_hash]]]);
			 $this->channels->leaveChannel(['channel' => $chatID, ]);

			}
if($msg=="Start Fuck"){
	file_put_contents("count.txt",1);
	$count=file_get_contents("count.txt");
	$tex= array(
"دیوث",
"الاغ",
"کصکش",
"کص ننه پشمی ",
" ننه شلناموس",
" کونده خاره پلشت",
" ننتوسگ اسراعیلی بگاد",
"شل ناموس ",
"کیرم تو چشوچاله اقوامت ",
" لاندوریه دوذاری",
" لاش پشمه لاش الاغی",
" ننه حرمله اتو گییدم",
"همه خاندانت زیرمه ",
"همت کنید کیرمو بخورید ",
"نکنمت بدون میگامت ",
"لای پستون ابجیت ریدم ",
);

$c = count($tex);

//$d = json_encode($tex);
//yield $this->messages->sendMessage(['peer'=>$chatID,"message"=>"تعداد : $c\n$d"]);

	while($count==1){
		$count=file_get_contents("count.txt");
		$rand = rand(0,$c-1);
	if($count==0){
		file_put_contents("count.txt",0);
		
		yield $this->messages->sendMessage(['peer'=>$chatID,"message"=>"فحش تمام شد"]);
		break;
		}
	yield $this->messages->sendMessage(['peer'=>$chatID,"message"=>$tex[$rand]]);

	}
		}if($msg=="Tabchi On" and $userID == $admin){
		$data['Tabchi'] =  "on";
		file_put_contents("data.json", json_encode($data, 128|256));
	//	file_put_contents("data.json",json_encode($data));
	//	$Bool = $MadelineProto->messages->setTyping(['peer' => $chatID,  'action' => SendMessageAction, ]);
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت تبچی روشن شد✅"]);
	
		
	
	
	}if($msg=="Tabchi Off" and $userID == $admin){
		$data['Tabchi'] =  "off";
		file_put_contents("data.json", json_encode($data, 128|256));

//		file_put_contents("data.json",json_encode($data));
	//	$Bool = $MadelineProto->messages->setTyping(['peer' => $chatID,  'action' => SendMessageAction, ]);
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت تبچی خاموش شد✅"]);
	
		
	
	
	}
			if($msg=="Typing On"){
		$data['Typing'] =  "on";
		file_put_contents("data.json", json_encode($data, 128|256));
	//	file_put_contents("data.json",json_encode($data));
	//	$Bool = $MadelineProto->messages->setTyping(['peer' => $chatID,  'action' => SendMessageAction, ]);
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت تایپینگ روشن شد✅"]);
	
		
	
	
	}if($msg=="Typing Off"){
		$data['Typing'] =  "off";
		file_put_contents("data.json", json_encode($data, 128|256));

//		file_put_contents("data.json",json_encode($data));
	//	$Bool = $MadelineProto->messages->setTyping(['peer' => $chatID,  'action' => SendMessageAction, ]);
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت تایپینگ خاموش شد✅"]);
	
		
	
	
	}if($msg=="Auto Answer On" and $userID == $admin){
		$data['Answer'] =  "on";
		file_put_contents("data.json", json_encode($data, 128|256));
			yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت پاسخ خودکار روشن شد✅"]);
	}if($msg=="Auto Answer Off" and $userID == $admin){
		$data['Answer'] =  "off";
		file_put_contents("data.json", json_encode($data, 128|256));
	yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"حالت پاسخ خودکار خاموش شد✅"]);
	}if(preg_match("/^(Set Answer (.*))$/i", $msg) and $userID == $admin){
$ip = trim(str_replace("Set Answer ","",$msg));
$ip = explode("|",$ip."|||||");
$txxt = trim($ip[0]);
$answeer = trim($ip[1]);
if(!isset($data['joAnswer'][$txxt])){
$data['joAnswer'][$txxt] = $answeer;
file_put_contents("data.json", json_encode($data, 128|256));
//file_put_contents("data.json", json_encode($data));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "✅پاسخ خودکار برای $txxt اضافه شد"]);
}else{
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "🚫برای $txxt از قبل پاسخ وجود داشت"]);
 }
}if(preg_match('/^(Del Answer (.*))$/i',$msg) and $userID == $admin){
preg_match('/^(Del Answer (.*))$/i',$msg,$text1);
$ans = $text1[2];
if(isset($data['joAnswer'][$ans])){
unset($data['joAnswer'][$ans]);
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "✅پاسخ خودکار برای $ans پاک شد"]);
}else{
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "🚫پاسخ خودکاری برای $ans ثبت نشده است"]);
}
}if($msg=="Answer List" and $userID == $admin){
	$ans= $data['joAnswer'];
	$list = "♻لیست پاسخ های خودکار\n\n";
	if(isset($data['joAnswer'])){
	if($data['joAnswer']==null){
		yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "🚫هنوز پاسخی ثبت نشده است"]);
	}else{
		foreach ($ans as $key => $as){
			//$dt = $ans[$key];
			$list .= "$key => $as\n";
			}
			yield $this->messages->sendMessage(['peer' => $chatID, 'message' => $list]);
		}
	}else{
		yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "🚫هنوز پاسخی ثبت نشده است"]);
	
		}
}
		if($msg=="Send Pv" and isset($update['message']['reply_to_msg_id'])){
		$x = $update['message']['reply_to_msg_id'];
		
		
		yield $this->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $userID, 'id' => [$x]]);
		}if($msg =="Tag All"){
			if($type=="supergroup"){
			$Chat = yield $this->getPwrChat($chatID);
	//		$e = json_encode($Chat);
	//		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"Hi\n$e"]);
			$arr=$Chat['participants'];
			$list ="";
			$c = 0;
			$k=1;
			foreach($arr as $key) {
				if($c == 100){
					break;
					}
   // var_dump($key);
$user=$arr[$c]['user']['id'];
if(isset($arr[$c]['user']['first_name'])){
	$name =$arr[$c]['user']['first_name'];
	}else{
	$name =$arr[$c]['user']['id'];
	}
$list .= "*$k.*[$name](tg://user?id=$user)\n";
$k++;
$c++;
}
$tex ="بیاید بالا \n\n$list";
//yield $this->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $userID, 'id' => [$x]]);
yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$tex",'parse_mode'=>'MarkDown']);

			}
			}if($msg == "Link List" and $userID == $admin){
				$x = file_get_contents("linkgroup.txt");
				$exp = explode("\n",$x);
				$count = count($exp)-1;
				yield $this->messages->sendMedia([
    'peer' => $chatID,
    'media' => [
        '_' => 'inputMediaUploadedDocument',
        'file' => "linkgroup.txt",
        'attributes' => [
            ['_' => 'documentAttributeImageSize'],
            ['_' => 'documentAttributeFilename', 'file_name' => 'linkgroup.txt']
        ]
    ],
    'message' => "Count : $count",
    'parse_mode' => 'Markdown'
]);
		
				}if($msg=="Status Panel" and $userID == $admin){
					
					if(isset($data['Answer'])){
					if($data['Answer'] == "on"){
						$ans = "`روشن✅`";
						}else{
						$ans = "`خاموش⛔`";
						}
						}else{
						$ans = "`خاموش⛔`";
						}
					
					if(isset($data['Typing'])){
					if($data['Typing'] == "on"){
						$typ = "`روشن✅`";
						}else{
						$typ = "`خاموش⛔`";
						}
						}else{
						$typ = "`خاموش⛔`";
						}if(isset($data['Tabchi'])){
					if($data['Tabchi'] == "on"){
						$tab = "`روشن✅`";
						}else{
						$tab = "`خاموش⛔`";
						}
						}else{
						$tab = "`خاموش⛔`";
						}
					
					$txt = "
					♻وضعیت پنل ربات
					
					
					★حالت پاسخ خودکار : $ans
					★حالت تبچی : $tab
					★حالت تایپینگ : $typ
					";
					yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$txt",'parse_mode'=>'MarkDown']);
					}
				if($msg == 'Stats Group' and $userID == $admin){
	//	  yield $this->messages->sendMessage(['peer' => $update, 'message' => 'ʟᴏᴀᴅɪɴɢ . . .', 'reply_to_msg_id' => $msg_id]);      
		// $mem_using = round((memory_get_usage()/1024)/1024, 0).' ᴍʙ';
		  $peerUser = 0; $supergroup = 0; $channel = 0; $peerChat = 0; $leavegroup = 0;
          $dialogs = yield $this->get_dialogs();
		    foreach ($dialogs as $peer) { 
			 if($peer['_'] == 'peerUser') $peerUser ++;
			 elseif($peer['_'] == 'peerChannel') {
			   $Chat = yield $this->getInfo($peer);
			   if($Chat['type'] == 'supergroup') {
			    if(isset($Chat['Chat']['banned_rights']) and $Chat['Chat']['banned_rights']['send_messages'] == true){
					try {
			          yield $this->channels->leaveChannel(['channel' => $chatID]);
					  $leavegroup ++;
					} catch (\Throwable $e) { }
				}					
			    $supergroup ++;
			   }
			   elseif($Chat['type'] == 'channel') $channel ++;		       
			 }
			 elseif($peer['_'] == 'peerChat') $peerChat ++;
			}
		   $contacts = count(yield $this->contacts->getContactIDs());
		$txt="
		♻آمار گروه های ربات 
		
		★پیوی ها : $peerUser
		★کانال ها : $channel
		★گروه ها : $peerChat
		★سوپرگروه ها : $supergroup
		★مخاطبین ربات : $contacts
		
		
		";
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"$txt"]);
        }
		if($msg=="Finish Fuck"){
		file_put_contents("count.txt",0);
		}
if($msg=="چت ایدی" or $msg=="Chat ID"){
		yield $this->messages->sendMessage(['peer'=>$chatID,'message'=>"چت ایدی شما : $chatID"]);
	}
if(preg_match('/^(Help All)$/i',$msg)){
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => '
♻لیست راهنما

✓وضعیت پنل ربات
Status Panel
✓حالت پاسخ خودکار روشن
Auto Answer On
✓حالت پاسخ خودکار خاموش
Auto Answer Off
✓تعیین پاسخ و جواب
Set Answer (Ans1|Ans2)
✓حذف پاسخ خودکار
Del Answer
✓لیست پاسخ ها
Answer List
✓حالت تبچی روشن
Tabchi On
✓حالت تبچی خاموش
Tabchi Off
✓دریافت لینک های سیو شده تبچی
Link List
✓آمار گروه و پیوی ها
Stats Group
✓حالت تایپینگ روشن
Typing On
✓حالت تایپینگ خاموش
Typing Off
✓سکوت کاربر با ریپلی
Mute
✓در آوردن سکوت کاربر با ریپلی
UnMute
✓بلاک کردن کاربر از ربات
Block
✓انبلاک کردن کاربر از ربات
UnBlock
✓ارسال پیام به پیوی با ریپلی
Send Pv
✓تگ کردن همه ی کاربران گروه
Tag All
✓دریافت لینک پیام در گروه
Msg Link
✓خراب کردن گروه 
Start Fuck
✓پایان خرابکاری گروه
Finish Fuck
✓ساخت گروه دو نفره
Create Group
✓لفت دادن از گروه
Leave Group
✓ساخت سوپرگروه
Create SuperGp
✓حذف کاربر از گروه
Kick (id)
✓حذف کاربر از گروه با ریپلی
Kick
✓دریافت مشخصات کاربر با ریپلی
User Info
✓منشن کاربر با ایدی و یوزرنیم
Check (ID | User)
✓روز شمار عید نوروز
Eid
✓زیبا نویس اسم
Font (Name)
✓ساخت لوگو
Logo (Name) (Num1-5)
✓ چک اخرین وضعیت هوا
Weather (city)
✓سرچ موزیک ملوبیت
Music (Name)
✓تبدیل فینگلیش به فارسی
Finglish (Text)
✓چک کردن صحت کدملی
Meli (Num)
✓شعر غزلیات سعدی
Ghazal
✓بیو خاص بصورت رندوم
Bio
✓دریافت تاریخ و ساعت امروز
Time
✓برای دریافت ایدی عددی
Chat ID
✓ برای ثبت کاربر هدف
Add User (Id)
✓ برای حذف کاربر هدف
Del User (Id)
✓ ثبت شناسه کانال فروارد
Set For (Id)
✓ حذف همه کاربران
Clean User
✓ عضویت در یک گروه
Join (Link)
✓ لیست کاربران
User List
✓افزودن ادمین با ریپلی
Add Admin
✓حذف ادمین
Remove Admin (id)
✓لیست ادمین
Admin UserList
✓مقدار رم استفاده شده
Memory Usage
✓ریلود ربات
Reload

 ★★Elyas Galikeshi★★
	']);
}
// @@MadeLineproto_F
if(preg_match('/^(Join (.*))$/i',$msg)){
preg_match('/^(Join (.*))$/i',$msg,$txt);
$id = $txt[2];
try{
yield $this->channels->joinChannel(['channel' => "$id"]);
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => 'عضویت انجام شد!','reply_to_msg_id' => $msg_id]);
}catch(Exception $e){
}
}
// @@MadeLineproto_F
if(preg_match('/^(Add User (.*))$/i',$msg)){
preg_match('/^(Add User (.*))$/i',$msg,$text1);
$id = $text1[2];
if(!isset($data['list'][$id])){
$data['list'][$id] = $id;
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => 'کاربر اضافه شد!']);
}else{
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "کاربر از قبل ثبت شده بود!"]);
}
}
if(preg_match('/^(Del User (.*))$/i',$msg)){
preg_match('/^(Del User (.*))$/i',$msg,$text1);
$id = $text1[2];
if(isset($data['list'][$id])){
unset($data['list'][$id]);
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => 'کاربر حذف شد!']);
}else{
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "کاربر از قبل وجود نداشت!"]);
}
}
if(preg_match('/^(Set For (.*))$/i',$msg)){
preg_match('/^(Set For (.*))$/i',$msg,$text1);
$id = $text1[2];
$data['channel'] = $id;
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => 'کانال تنظیم شد!']);
}
if(preg_match('/^(Clean User)$/i',$msg)){
$data['list'] = [];
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "لیست کاربران پاکسازی شد!"]);
}
if(preg_match('/^(User List)$/i',$msg)){
if(count($data['list']) > 0){
$txxxt = "➿ لیست کاربران هدف:
";
$counter = 1;
foreach($data['list'] as $k){
$txxxt .= "$counter: <code>$k</code>\n";
$counter++;
}
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => $txxxt, 'parse_mode' => 'html']);
}else{
yield $this->messages->sendMessage(['peer' => $chatID, 'message' => "کاربری وجود ندارد."]);
}
}
}if(isset($update['message']['entities']) and preg_match_all('/\S+(joinchat)\S+/i' , $msg, $match)){
			 foreach ($match[0] as $link) {
				if(!in_array($link , file('linkgroup.txt', FILE_IGNORE_NEW_LINES))) {
                  try { 
	if(isset($data['Tabchi'])){
		if($data['Tabchi']){
				  $ChatInvite = yield $this->messages->checkChatInvite(['hash' => $link]);					  
				   if($ChatInvite['_'] == 'chatInvite' and $ChatInvite['broadcast'] != '1' and $ChatInvite['participants_count'] >= 200) {
                    yield $this->channels->joinChannel(['channel' =>$link]);
}
}}
				  } catch (\Throwable $e) { }
                 file_put_contents('linkgroup.txt', "$link\n", FILE_APPEND);				  
			    }				
		    
		}
		
		}
	if(isset($data['Answer'])){
		if($data['Answer']=="on"){
		if(isset($data['joAnswer'][$msg])){
			$txt = $data['joAnswer'][$msg];
			yield $this->messages->sendMessage(['peer' => $chatID, 'message' =>$txt]);
			}
		}
	
	}
if(isset($msg)){
	if(isset($data['Typing'])){
		if($data['Typing'] == "on"){
	$send = ['_' => 'sendMessageTypingAction'];
	$this->messages->setTyping(['peer' => $chatID,  'action' => $send, ]);
	}}
	}
if($type == "supergroup" or $type == "user"){
if(isset($data['list']["$userID"])){
$data['lock']["$chatID"] = $op;
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $data['channel'], 'id' => [$msg_id]]);
}
}
if($type == "channel"){
if(isset($data['list']["$chatID"])){
$data['lock']["$chatID"] = $op;
file_put_contents("data.json", json_encode($data, 128|256));
yield $this->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $data['channel'], 'id' => [$msg_id]]);
}
}
}
}catch(RPCErrorException $e){
	$v = $e->getMessage();
$this->messages->sendMessage([
                'peer'=>$admin,
                'message'=>"ERROR: <code>$v</code> <b>".PHP_EOL.date("H:i Y/m/d")."</b>",
                'parse_mode'=>'html'
            ]);
        }

}
}
$settings['logger']['max_size'] = 20*1024*1024;
/* از سایت خود تلگرام 
api_id 
api_hash 
رو بگیرید بهتره برای دیرتر دلیت شدن اکانت
لازمه حتما برای خود اکانتتونو بگیرید

کانال میدلاین فارسی رو حمایت کنید
@MadeLineproto_F
*/
$settings['app_info']['api_id']=176407; // از سایت بگیرید بهتره
$settings['app_info']['api_hash']="1f70c4348cd5e202cf476ff07d63f0e2";// از سایت بگیرید بهتره
$MadelineProto = new \danog\MadelineProto\API('session.madeline',$settings);
$MadelineProto->async(true);
$MadelineProto->loop(function () use ($MadelineProto){
yield $MadelineProto->start();
yield $MadelineProto->setEventHandler('\EventHandler');
}
);
// @@MadeLineproto_F
$MadelineProto->loop();
?>