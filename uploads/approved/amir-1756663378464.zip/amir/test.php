<?php
echo 'one';