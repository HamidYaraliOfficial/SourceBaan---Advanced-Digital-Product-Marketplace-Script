<?php

ob_start();
error_reporting(0);
date_default_timezone_set("Asia/Tehran");
define('API_KEY','TOKEN_BOT'); // توکن ربات خود را اینجا قرار دهید
$time = date('H:i');
$date1 = date('d.m.Y');


function bot($method, $steps = []){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $steps);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}


$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$chat_id = $message->chat->id;
$cid = $message->chat->id;
$callcid = $update->callback_query->message->chat->id;
$cmid = $update->callback_query->message->message_id; 
$uid = $message->from->id;
$name = $message->chat->first_name;
$text = $message->text;  
$tx = $message->text;  
$uid = $message->from->id;
$fname = $update->message->from->first_name;
$fname2 = $update->message->from->last_name;
$username = $update->message->from->username;
$name = "<a href='tg://user?id=$uid'> $fname $fname2 </a>";
$channel_id = "xxxxxx"; //آیدی کانال بدون @
$bot = bot('getme', ['BotName'])->result->username; 
$text = $message->text;
$back = "◀️ بازگشت";
$step = file_get_contents("step/$cid/$cid.txt");
$blocks = file_get_contents("data/blocks.txt");
$holat = file_get_contents("data/bot.txt");
$kanal = file_get_contents("data/kanal.txt");
$channel = file_get_contents("data/channel.txt");
$amar = file_get_contents("data/amar.txt");
$admins = file_get_contents("data/admins.txt");
$administrator = "ADMIN_ID"; // آیدی عددی ادمین اصلی را اینجا قرار دهید
$admin = array($administrator, $admins);
$admin_id = "xxxxxxx"; //آیدی ادمین بدون @
mkdir("data");
mkdir("step");
mkdir("step/$cid");


$home = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "📡 کانال ربات های مفید"]],
        [['text' => "💬 تماس"], ['text' => "🤖 درباره ربات"]],
    ]
]);


$panel = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "📝 سیستم پیام"], ['text' => "📊 آمار"]],
        [['text' => "📢 مدیریت کانال ها"], ['text' => "🔐 سیستم بلاک"]],
        [['text' => "⚙ تنظیمات ربات"], ['text' => "⭐️ مدیریت ادمین ها"]],
        [['text' => "$back"]],
    ]
]);

$message_manager = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "💬فوروارد پیام"]],
        [['text' => "👨🏻‍💻 پنل مدیریت"]],
    ]
]);

$channel_manager = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "📢 افزودن کانال"], ['text' => "📢 حذف کانال"]],
        [['text' => "📋 لیست کانال ها"], ['text' => "📋 پاک کردن لیست کانال ها"]],
        [['text' => "👨🏻‍💻 پنل مدیریت"]],
    ]
]);

$blok_manager = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "✅ آزادسازی از بلاک"], ['text' => "❌ بلاک کردن"]],
        [['text' => "📋 لیست بلاک شده ها"], ['text' => "📋 پاک کردن لیست بلاک شده ها"]],
        [['text' => "👨🏻‍💻 پنل مدیریت"]],
    ]
]);

$manage_bot = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "✅ روشن کردن ربات"], ['text' => "❌ خاموش کردن ربات"]],
        [['text' => "👨🏻‍💻 پنل مدیریت"]],
    ]
]);

$admins_manager = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "➕ افزودن ادمین"], ['text' => "🛑 حذف ادمین"]],
        [['text' => "📋 لیست ادمین ها"], ['text' => "📋 پاک کردن لیست ادمین ها"]],
        [['text' => "👨🏻‍💻 پنل مدیریت"]],
    ]
]);

$ortga = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text' => "$back"]],
    ]
]);

if(isset($message)){
    $get = file_get_contents("data/amar.txt");
    if(mb_stripos($get, $uid) == false){
        file_put_contents("data/amar.txt", "$get\n$uid");
    }
}

if(in_array($cid, $admin)){}
elseif(mb_stripos($blocks, $uid) !== false){
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => "<b>⚠️ با عرض پوزش <a href='tg://user?id=$cid'>$name</a>

📛 شما از ربات بلاک شده اید!

👨🏻‍💻 برای آزادسازی با ادمین ربات تماس بگیرید!</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "👨🏻‍💻 ادمین", 'url' => "tg://user?id=$administrator"]],
            ]
        ])
    ]);
    return false;
}

if(in_array($cid, $admin)){}
elseif($holat == "off"){
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "<b>🛠 در حال انجام تعمیرات!

▪ ادمین ربات در حال انجام برخی تعمیرات است.
▪ به همین دلیل منو برای کاربران غیرفعال شده است.
▪ پس از اتمام کار همه عملکردها بازگردانده می شود.

🔰 اگر شما ادمین این ربات هستید، می توانید این حالت را غیرفعال کنید!
👉👨🏻‍💻 پنل مدیریت | ⚙ تنظیمات ربات.

📝 برای سایرین:
ℹ️ لطفاً بعداً مراجعه کنید و برای بررسی وضعیت ربات /start را بزنید!</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode(['remove_keyboard' => true])
    ]);
    return false;
}

if(isset($message) and ($channel == "true")){
    $ids = explode("\n", $kanal);
    $soni = substr_count($kanal, "@");

    foreach($ids as $id){
        $keyboards = [];
        $k = [];
        for ($for = 1; $for <= $soni; $for++) {
            $kanall = str_replace("@", "", $ids[$for]);
            $keyboards[] = ["text" => "$for- کانال", "url" => "https://t.me/$kanall"];
        }

        $keyboard2 = array_chunk($keyboards, 1);
        $keyboard = json_encode(['inline_keyboard' => $keyboard2]);
    }

    $get = bot('getChatMember', [
        'chat_id' => $id,
        'user_id' => $uid,
    ])->result->status;

    if(in_array($cid, $admin)){}
    elseif($get == "member" or $get == "administrator" or $get == "creator"){
    } else {
        bot('sendMessage', [
            'chat_id' => $cid,
            'text' => "<b>❌ با عرض پوزش <a href='tg://user?id=$cid'>$name</a> شما در کانال های ما عضو نیستید!
🔰 پس از عضویت مجدداً /start را بزنید!</b>",
            'parse_mode' => 'html',
            'reply_markup' => $keyboard,
        ]); 
        return false;
    }
}

if($text == "/start" or $text == $back){
    unlink("step/$cid/$cid.txt");
    unlink("step/$cid/@$bot.mp3");
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => "<b>🐊 سلام
من را به عنوان ادمین به کانال خود اضافه کنید تا درخواست‌های عضویت کاربران را به صورت خودکار تأیید کنم!

",
        'parse_mode' => 'html',
        'reply_markup' => $home,
    ]);
}

if($text == "/save"){
    file_put_contents("step/$cid/$cid.txt", "video");
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => "<b>📹 لینک ویدیو یا موزیک TikTok را ارسال کنید! ✅</b>",
        'parse_mode' => 'html',
        'reply_markup' => $ortga
    ]);
}

$api = 'https://www.tikwm.com/api/';
$vidurl = $text;
$tikUrl = $vidurl;
$postData = [
    'url' => $tikUrl,
    'hd' => 0 
];

function curl_request($url, $postData = []){
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_ACCEPTTIMEOUT_MS, 10000);
    curl_setopt($curl, CURLOPT_ENCODING, 'gzip');

    $response = curl_exec($curl);
    return $response;
}

if($text != "/start" and $text != $back and $step == "video"){
    $music = file_get_contents("$music");
    file_put_contents("step/$cid/@$bot.mp3", "$music");
    $music = file_get_contents("step/$cid/@$bot.mp3");
    
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => "<b>⏳ در حال دانلود...
🛠 لطفاً کمی صبر کنید!</b>",
        'parse_mode' => 'html',
    ]);
    
    bot('deleteMessage', [
        'chat_id' => $cid,
        'message_id' => $mid + 1,
    ]);
    
    bot('sendVideo', [
        'chat_id' => $cid,
        'video' => $video,
        'caption' => "<b>♥️ لایک‌ها: $likes
✍️ کامنت‌ها: $comments
👁‍🗨 بازدیدها: $views
🔰 اشتراک‌گذاری: $posts
🌐 دانلودها: $downloads</b>",
        'parse_mode' => 'html',
        'reply_markup' => $home
    ]);
    
    bot('sendAudio', [
        'chat_id' => $cid,
        'audio' => new CURLFile("step/$cid/@$bot.mp3"),
        'parse_mode' => 'html',
        'reply_markup' => $home
    ]);
    
    unlink("step/$cid/$cid.txt");
    unlink("step/$cid/@$bot.mp3");
}

if($text == "📊 آمار"){
    $get = substr_count($amar, "\n");
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => "<b>👥 کاربران ربات: $get نفر
⏰ زمان: $time | 📆 تاریخ: $date1</b>",
        'parse_mode' => 'html',
        'reply_markup' => $ortga,
    ]);
}

if($text == "💬 تماس"){
    bot('SendMessage', [
        'chat_id' => $cid,
        'text' => "<b>📋 برای سوالات، پیشنهادات یا سایر درخواست‌ها با ادمین تماس بگیرید)</b>",
        'parse_mode' => "html", 
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "👨🏻‍💻 ادمین", "url" => "tg://user?id=$administrator"]],
            ]
        ])
    ]);
}

if($text == "🤖 درباره ربات"){
    bot('SendMessage', [
        'chat_id' => $cid,
        'text' => "<b>ℹ️ @$bot !

✅ امکانات:

👉🏻 درخواست‌های عضویت در کانال شما را به صورت خودکار تأیید می‌کنم

💫 ربات‌های مفید را در اینجا دنبال کنید: @$channel_id</b>",
        'parse_mode' => 'html', 
        'reply_markup' => $home,
    ]);
}

if($text == "📡 کانال ربات های مفید"){
    bot('SendMessage', [
        'chat_id' => $cid,
        'text' => "<b>ℹ️ @$bot 


✨ ارتباط با ادمین: @$admin_id

💫 ربات‌های مفید را در اینجا دنبال کنید: @$channel_id</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "👨🏻‍💻 ادمین", "url" => "tg://user?id=$administrator"]],
            ]
        ])
    ]);
}

$joinchatid = $update->chat_join_request->chat->id;
$chatjoinname = $update->chat_join_request->chat->title;
$chatjoinuser = $update->chat_join_request->chat->username;
$chatjoinlink = $update->chat_join_request->chat->invite_link;
$qb = $update->chat_join_request->from->id;
$fname = $update->chat_join_request->from->first_name;
$ty = $update->chat_join_request->chat->type;

if($ty == "channel" ){
    bot("approveChatJoinRequest", [
        "chat_id" => $joinchatid,
        "user_id" => $qb,
    ]);
    
    bot('sendmessage', [
        'chat_id' => $qb,
        'text' => "👋 سلام <b>$fname</b>
درخواست شما برای پیوستن به کانال <b>$chatjoinname</b> تأیید شد 🤭 

<b>@$bot_id</b> - درخواست‌ها را به صورت خودکار تأیید می‌کند",
        'parse_mode' => 'html',
        "reply_markup" => json_encode([
            "inline_keyboard" => [
                [["text" => "➕ربات‌های مفید", "url" => "https://t.me/$channel_id"]],
            ]
        ]),
    ]);
}

if($text == "/panel"){
    if(in_array($cid, $admin)){
        unlink("step/$cid/$cid.txt");
        bot('sendMessage', [
            'chat_id' => $cid,
            'text' => "<b>👨🏻‍💻 به پنل مدیریت خوش آمدید!
📋 یکی از بخش‌های زیر را انتخاب کنید!</b>",
            'parse_mode' => 'html',
            'reply_markup' => $panel,
        ]);
    } else {
        bot('sendMessage', [
            'chat_id' => $cid,
            'text' => "<b>👨🏻‍💻 فقط ادمین ربات می‌تواند از این بخش استفاده کند!</b>",
            'parse_mode' => 'html',
            'reply_markup' => $home,
        ]);
    }
}

if(in_array($cid,$admin)){
    if($text == "📝 سیستم پیام"){
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📝 شما در بخش سیستم پیام هستید!
📋 یکی از گزینه‌های زیر را انتخاب کنید:</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$message_manager,
        ]);
    }
}

if($text == "💬فوروارد پیام"){
    file_put_contents("step/$cid/$cid.txt","forward");
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"<b>👥 لطفا پیامی که می‌خواهید برای همه کاربران فوروارد شود را ارسال کنید!</b>",
        'parse_mode'=>'html',
        'reply_markup'=>$ortga,
        'disable_web_page_preview'=>true,
    ]);
}

if($step == "forward" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
    unlink("step/$cid/$cid.txt");
    $explode = explode("\n",$amar);
    foreach($explode as $id){
        $forward = bot('forwardMessage',[
            'chat_id' =>$id, 
            'from_chat_id' =>$cid, 
            'message_id' =>$mid, 
        ]);
    }
}

if($forward){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"<b>👥 پیام فورواردی شما با موفقیت برای همه کاربران ارسال شد! ✅</b>",
        'parse_mode'=>'html',
        'reply_markup'=>$message_manager,
    ]);
}


if(in_array($cid,$admin)){
    if($text == "📢 مدیریت کانال ها"){
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📢 شما در بخش مدیریت کانال‌ها هستید!
📋 یکی از گزینه‌های زیر را انتخاب کنید:</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$channel_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "📢 افزودن کانال"){
        file_put_contents("step/$cid/$cid.txt","kanal");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📡 لطفا آیدی کانال را ارسال کنید!
🔰 مثال: @$channel_id</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$ortga,
        ]);
    }
}

if($step == "kanal" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
    if(mb_stripos($kanal,"$text")!==false){

    } else {
        file_put_contents("data/kanal.txt","$kanal\n$text");
        file_put_contents("data/channel.txt","true");
        unlink("step/$cid/$cid.txt");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📡 کانال با موفقیت به ربات اضافه شد!
🤖 لطفا ربات را به عنوان ادمین به کانال اضافه کنید!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$channel_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "📢 حذف کانال"){
        file_put_contents("step/$cid/$cid.txt","delete");
        $ids = explode("\n",$kanal);
        $soni = substr_count($kanal,"@");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📡 لطفا آیدی کانالی که می‌خواهید حذف شود را ارسال کنید!

🔰 مثال: @$channel_id

👇 کانال‌های متصل به ربات:
$kanal

📝 تعداد کل کانال‌ها: $soni عدد
</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$ortga,
        ]);
    }
}

if($step == "delete" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
    if(mb_stripos($kanal,"$text")!==false){
        $k = str_replace("\n".$text."","",$kanal);
        file_put_contents("data/kanal.txt",$k);
        unlink("step/$cid/$cid.txt");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>🔰 کانال $text با موفقیت حذف شد! ✅</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$channel_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 لیست کانال ها"){
        if($kanal == null){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ کانالی به ربات متصل نیست!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$channel_manager,
            ]);
        } else {
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست کانال‌ها:
$kanal</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$channel_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 پاک کردن لیست کانال ها"){
        if($kanal == null){
            unlink("data/kanal.txt");
            unlink("data/channel.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ کانالی به ربات متصل نیست!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$channel_manager,
            ]);
        } else {
            unlink("data/kanal.txt");
            unlink("data/channel.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست کانال‌ها با موفقیت پاک شد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$channel_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "🔐 سیستم بلاک"){
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>🔐 شما در بخش سیستم بلاک هستید!
📋 یکی از گزینه‌های زیر را انتخاب کنید:</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$blok_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "✅ آزادسازی از بلاک"){
        file_put_contents("step/$cid/$cid.txt","unblock");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>🚫 لطفا آیدی عددی کاربری که می‌خواهید از بلاک خارج شود را وارد کنید!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$ortga,
        ]);
    }
}

if(in_array($cid,$admin)){
    if($step == "unblock" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
        unlink("step/$cid/$cid.txt");
        if(mb_stripos($blocks, $text)==false){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>👨🏻‍💻 این کاربر در لیست بلاک شده‌ها نیست!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        } else {
            $bl = str_replace("$text", " ", $blocks);
            file_put_contents("data/blocks.txt", "$bl");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>🔰 کاربر با موفقیت از بلاک خارج شد! ✅</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
            bot('sendMessage',[
                'chat_id'=>$text,
                'text'=>"<b>🎉 شما از بلاک خارج شدید!

🔄 اکنون می‌توانید از ربات استفاده کنید!

🤖 لطفا دوباره /start را بزنید ✅</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$home,
            ]);
        }
    }
}

if(in_array($cid,$admin)){
    if($text == "❌ بلاک کردن"){
        file_put_contents("step/$cid/$cid.txt","block");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>🚫 لطفا آیدی عددی کاربری که می‌خواهید بلاک شود را وارد کنید!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$ortga,
        ]);
    }
}

if(in_array($cid,$admin)){
    if($step == "block" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
        if(mb_stripos($blocks, $text)==false){
            file_put_contents("data/blocks.txt", "$blocks\n$text");
            unlink("step/$cid/$cid.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>🔰 کاربر با موفقیت بلاک شد! ✅</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
            bot('sendMessage',[
                'chat_id'=>$text,
                'text'=>"<b>🚫 شما از این ربات بلاک شدید!

🔄 دیگر نمی‌توانید از ربات استفاده کنید!

👨‍💻 برای آزادسازی با ادمین ربات تماس بگیرید!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>json_encode([
                    'remove_keyboard'=>true,
                ])
            ]);
        } else {
            unlink("step/$cid/$cid.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>👨🏻‍💻 این کاربر قبلا بلاک شده است!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 لیست بلاک شده ها"){
        if($blocks == null){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ کاربری بلاک نشده است!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        } else {
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست کاربران بلاک شده:
$blocks</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 پاک کردن لیست بلاک شده ها"){
        if($blocks == null){
            unlink("data/blocks.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ کاربری بلاک نشده است!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        } else {
            unlink("data/blocks.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست بلاک شده‌ها با موفقیت پاک شد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$blok_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "⚙ تنظیمات ربات"){
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>⚙ شما در بخش تنظیمات ربات هستید!
📋 یکی از گزینه‌های زیر را انتخاب کنید:</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$manage_bot,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "✅ روشن کردن ربات"){
        unlink("data/bot.txt");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>⚠️ ربات با موفقیت روشن شد!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$manage_bot,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "❌ خاموش کردن ربات"){
        file_put_contents("data/bot.txt","off");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>⚠️ ربات با موفقیت خاموش شد!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$manage_bot,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "⭐️ مدیریت ادمین ها"){
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>⭐️ شما در بخش مدیریت ادمین‌ها هستید!
📋 یکی از گزینه‌های زیر را انتخاب کنید:</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$admins_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "➕ افزودن ادمین"){
        file_put_contents("step/$cid/$cid.txt","setadmins");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>👨🏻‍💻 لطفا آیدی عددی کاربری که می‌خواهید ادمین شود را وارد کنید</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$ortga,
        ]);
    }
}

if($step == "setadmins" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
    if(is_numeric($text)){
        if(mb_stripos($amar,$text)!==false){
            file_put_contents("data/admins.txt","$admins\n$text");
            unlink("step/$cid/$cid.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📝 کاربر با آیدی <a href='tg://user?id=$text'>$text</a> به عنوان ادمین تنظیم شد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
            bot('sendMessage',[
                'chat_id'=>$text,
                'text'=>"<b>👨‍💻 شما به عنوان ادمین ربات منصوب شدید!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$home,
            ]);
        } else {
            unlink("step/$cid/$cid.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>👨‍💻 این کاربر در لیست کاربران ربات وجود ندارد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        }
    } else {
        unlink("step/$cid/$cid.txt");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📋 لطفا فقط عدد وارد کنید!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$admins_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "🛑 حذف ادمین"){
        if($admins == null){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ ادمینی در ربات وجود ندارد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        } else {
            file_put_contents("step/$cid/$cid.txt","deladmins");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>👨‍💻 لطفا آیدی عددی ادمینی که می‌خواهید حذف شود را وارد کنید</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$ortga,
            ]);
        }
    }
}

if($step == "deladmins" and $text!= "/start" and $text!= $back and $text!= "👨🏻‍💻 پنل مدیریت"){
    if(is_numeric($text)){
        if(mb_stripos($admins,$text)!==false){
            unlink("step/$cid/$cid.txt");
            $ad = str_replace("\n".$text."","",$admins);
            file_put_contents("data/admins.txt",$ad);
            unlink("step/$cid/$cid.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 کاربر با آیدی <a href='tg://user?id=$text'>$text</a> از لیست ادمین‌ها حذف شد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
            bot('sendMessage',[
                'chat_id'=>$text,
                'text'=>"<b>👨‍💻 شما از لیست ادمین‌های ربات حذف شدید!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$home,
            ]);
        } else {
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 کاربر با آیدی <a href='tg://user?id=$text'>$text</a> ادمین نیست!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        }
    } else {
        unlink("step/$cid/$cid.txt");
        bot('sendMessage',[
            'chat_id'=>$cid,
            'text'=>"<b>📋 لطفا فقط عدد وارد کنید!</b>",
            'parse_mode'=>'html',
            'reply_markup'=>$admins_manager,
        ]);
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 لیست ادمین ها"){
        if($admins == null){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ ادمینی در ربات وجود ندارد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        } else {
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست ادمین‌ها:
$admins</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        }
    }
}


if(in_array($cid,$admin)){
    if($text == "📋 پاک کردن لیست ادمین ها"){
        if($admins == null){
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 هیچ ادمینی در ربات وجود ندارد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        } else {
            unlink("data/admins.txt");
            bot('sendMessage',[
                'chat_id'=>$cid,
                'text'=>"<b>📋 لیست ادمین‌ها با موفقیت پاک شد!</b>",
                'parse_mode'=>'html',
                'reply_markup'=>$admins_manager,
            ]);
        }
    }
}

?>