<?php

function off($off)
{
	$off = str_replace([0, 1], ['❌', '✅'], $off);
	return $off;
}
function random_code($r=8)
{
$alf="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
$key="";
for($i=0;$i<$r;$i++){
$key.=$alf[rand(0,strlen($alf)-1)];
}
return $key;
}
function ping($host, $port=80, $timeout=30) { 
		$tB = microtime(true); 
	$fP = fSockOpen($host, $port, $errno, $errstr, $timeout); 
	if (!$fP) { return "down";}
	$tA = microtime(true); 
	return round((($tA - $tB) * 1000), 0)." ms"; 
  }

function ememoji($time){

$ar = [
'1200'=>'🕛',
'1230'=>'🕧',
'0100'=>'🕐',
'0130'=>'🕜',
'0200'=>'🕑',
'0230'=>'🕝',
'0300'=>'🕒',
'0330'=>'🕞',
'0400'=>'🕓',
'0430'=>'🕟',
'0500'=>'🕔',
'0530'=>'🕠',
'0600'=>'🕕',
'0630'=>'🕡',
'0700'=>'🕖',
'0730'=>'🕢',
'0800'=>'🕗',
'0830'=>'🕣',
'0900'=>'🕘',
'0930'=>'🕤',
'1000'=>'🕙',
'1030'=>'🕥',
'1100'=>'🕚',
'1130'=>'🕦',
];
if($time >= '1200' and $time <= '1230'){
return $ar['1200'];
}elseif($time >= '1230' and $time <= '0100'){
return $ar['1230'];
} elseif($time >= '0100' and $time <= '0130'){
return $ar['0100'];
}elseif($time >= '0130' and $time <= '0200'){
return $ar['0130'];
} elseif($time >= '0200' and $time <= '0330'){
return $ar['0200'];
}elseif($time >= '0330' and $time <= '0400'){
return $ar['0330'];
} elseif($time >= '0400' and $time <= '0430'){
return $ar['0400'];
}elseif($time >= '0430' and $time <= '0500'){
return $ar['0430'];
} elseif($time >= '0500' and $time <= '0530'){
return $ar['0500'];
}elseif($time >= '0530' and $time <= '0600'){
return $ar['0530'];
} elseif($time >= '0600' and $time <= '0630'){
return $ar['0600'];
}elseif($time >= '0530' and $time <= '0600'){
return $ar['0530'];
} elseif($time >= '0600' and $time <= '0630'){
return $ar['0600'];
}elseif($time >= '0630' and $time <= '0700'){
return $ar['0630'];
} elseif($time >= '0700' and $time <= '0730'){
return $ar['0700'];
}elseif($time >= '0730' and $time <= '0800'){
return $ar['0730'];
} elseif($time >= '0800' and $time <= '0830'){
return $ar['0800'];
}elseif($time >= '0830' and $time <= '0600'){
return $ar['0830'];
} elseif($time >= '0900' and $time <= '0930'){
return $ar['0900'];
}elseif($time >= '0930' and $time <= '1000'){
return $ar['0930'];
} elseif($time >= '1000' and $time <= '1030'){
return $ar['1000'];
}elseif($time >= '1030' and $time <= '1100'){
return $ar['1030'];
} elseif($time >= '1100' and $time <= '1130'){
return $ar['1100'];
}elseif($time >= '1130' and $time <= '1200'){
return $ar['1130'];
}
}
function curl_get($url){
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_TIMEOUT,30);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
return $resp;
}









