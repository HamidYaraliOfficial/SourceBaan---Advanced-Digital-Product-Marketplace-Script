<?php
/******************************************************************************** 
 * Programer: pertiam *
 ********************************************************************************/
//---------------کیبورد------------------//
$key['info'] = "⛏ استخراج اعضا";
$key['status'] = "📊 آمار ربات";
$key['sendall'] = "📨 ارسال پیام";
$key['settings'] = "⚙️ تنظیمات";
$key['shop'] = "🛍 فروشـگاه";
$key['panelupd'] = "📤 بخش آپلود";
$key['powerbot'] = "🤖 وضعیت ربات";
/*$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";
$key[''] = "";*/
//////// بخش اپلود /////////
$key['upload_group'] = "📤 آپلود آلبومی";
$key['upload_taki'] = "📤 آپلود تکی";
$key['upload_coin'] = "📤 آپلود پولی";
$key[''] = "";
$key[''] = "";
$key[''] = "";


//////// پیام همگانی /////////
$key['forall'] = "💬 فوروارد همگانی";
$key['msgall'] = "💬 ارسال همگانی";
$key['fealyabi'] = "🏃🏻‍♂️فعال یابی";
//////// تنظیمات /////////
$key['joins'] = "قفل کانال 🔐";
$key['joinsade'] = "قفل اختیاری";
$key['joinbot'] = "🔐 قفل ربات";
$key['chMedia'] = "♨️ کانال رسانه ♨️";
$key['admins'] = "👤 ادمین ها";
$key['texts'] = "✏️ متن ها";
$key['ads'] = "🪧 تنظیم تبلیغات";
$key['auto_del'] = "⏰ تنظیم حذف خودکار";
//////// تنظیم کانال /////////
$key['addjoin'] = "🔐 افزودن قفل";
$key['auto_link'] = "خودکار";
$key['deljoin'] = "🔓 حذف قفل";
//////// تنظیم لینک اختیاری /////////
$key['addsade'] = "🔐 افزودن لینک";
$key['delsade'] = "🔓 حذف لینک";
//////// تنظیم کانال مدیا /////////
$key['addchMedia'] = "🔐 افزودن کانال";
$key['Mediacaption'] = "🪧 تنظیم بنر";
$key['delchMedia'] = "🔓 حذف کانال";
//////// تنظیم قفل ربات /////////
$key['addrobots'] = "🔐 افزودن ربات";
$key['delrobots'] = "🔓 حذف ربات";
//////// اپلود البومی //////////
$key['end_upload_group'] = "انتهای آپلود";
$key['no_caption'] = "بدون کپشن";
//////// ادمین ها //////////
$key['addadmin'] = "👳🏾 افزودن ادمین";
$key['deladmin'] = "👳🏼‍♂️ حذف ادمین";
//////// تبلیغات /////////
$key['typeads'] = "🔆 تغییر نوع ارسال";
$key['timeads'] = "🔁 تغییر زمان ارسال";
$key['delads'] = "❌🪧 حذف تبلیغات";
//////// برگشت /////////
$key['back'] = "↪️ برگشت";
//////// متون ربات //////////
$key['text'] = [
    'start'=>"متن /start",
    'join'=>"متن جوین اجباری",
    'not_found'=>"متن یافت نشد",
    'del'=>"متن پاکسازی خودکار",
];
////////
//-------------------------------------------------//
class media
{
    function keys($keys=null,$data=null)
    {
        global $key;
        switch ($keys) {
            case 'home':
                    $t = ['keyboard' => [
                        [['text' => $key['status']]],
                        
                        
                        [['text' => $key['panelupd']],['text' => $key['info']],['text' => $key['sendall']]],
                        
                        
                        [['text' => $key['settings']],['text' => $key['powerbot']]],
                        
                        
                     //   [['text' => $key['shop']]],
                    ]];
                break;
                case 'panelupds':
                    $t = ['keyboard' => [
                       // [['text' => $key['upload_taki']]],
                        [['text' => $key['upload_taki']],['text' => $key['upload_group']]],
                        [['text' => $key['back']]],
                    ]];
                break;
            case 'settings':
                    $t = ['keyboard' => [
                        [['text' => $key['ads']]],
                        [['text' => $key['admins']],['text' => $key['chMedia']]],
                        [['text' => $key['joins']],['text' => $key['joinsade']],['text' => $key['joinbot']]],
                        [['text' => $key['texts']],['text' => $key['auto_del']]],
                        
                        [['text' => $key['back']]],
                    ]];
                break;
            case 'send_panel':
                    $t = ['keyboard' => [
                        [['text' => $key['fealyabi']]],
                        [['text' => $key['msgall']],['text' => $key['forall']]],
                        [['text' => $key['back']]],
                    ]];
                break;
            case 'lock':
                if($data){
                $t = [
                    'keyboard' => [
                        [['text' => $key['addjoin']],['text' => $key['deljoin']]],
                        [['text' => $key['back']]],
                    ]
                ];
                }else{
                 $t = [
                    'keyboard' => [
                        [['text' => $key['addjoin']]],
                        [['text' => $key['back']]],
                    ]
                ];   
                }
                break;
                case 'joinbot':
                if($data){
                $t = [
                    'keyboard' => [
                        [['text' => $key['addrobots']],['text' => $key['delrobots']]],
                        [['text' => $key['back']]],
                    ]
                ];
                }else{
                 $t = [
                    'keyboard' => [
                        [['text' => $key['addrobots']]],
                        [['text' => $key['back']]],
                    ]
                ];   
                }
                break;
                case 'joinsade':
                if($data){
                $t = [
                    'keyboard' => [
                        [['text' => $key['addsade']],['text' => $key['delsade']]],
                        [['text' => $key['back']]],
                    ]
                ];
                }else{
                 $t = [
                    'keyboard' => [
                        [['text' => $key['addsade']]],
                        [['text' => $key['back']]],
                    ]
                ];   
                }
                break;
                case 'chMedia':
                if($data){
                $t = [
                    'keyboard' => [
                        [['text' => $key['Mediacaption']]],
                        [['text' => $key['addchMedia']],['text' => $key['delchMedia']]],
                        [['text' => $key['back']]],
                    ]
                ];
                }else{
                 $t = [
                    'keyboard' => [
                        [['text' => $key['addchMedia']]],
                        [['text' => $key['back']]],
                    ]
                ];   
                }
                break;
                case 'admins':
                if($data){
                $t = [
                    'keyboard' => [
                        [['text' => $key['addadmin']],['text' => $key['deladmin']]],
                        [['text' => $key['back']]],
                    ]
                ];
                }else{
                 $t = [
                    'keyboard' => [
                        [['text' => $key['addadmin']]],
                        [['text' => $key['back']]],
                    ]
                ];   
                }
                break;
                case 'access_admin':
                    $id =$data[0];
                    $ts1 =$data[1];
                    $ts2 =$data[2];
                    $ts3 =$data[3];
                    $t1 = 'آپلود';
                    $t2 = 'تنظیمات';
                    $t3 = 'ارسال پیام';
                    $t4 = '✅ افزودن به ادمین';
                    $t5 = '❌ لغو';
                    $t = ['inline_keyboard'=>[
                            [['text'=>"⚙️: $t1",'callback_data'=>'fyk'],['text'=>"$ts1",'callback_data'=>'acc_file']],
                            [['text'=>"⚙️: $t2",'callback_data'=>'fyk'],['text'=>$ts2,'callback_data'=>'acc_settings']],
                            [['text'=>"⚙️: $t3",'callback_data'=>'fyk'],['text'=>$ts3,'callback_data'=>'acc_sendall']],
                            [['text'=>$t5,'callback_data'=>'acc_nok'],['text'=>$t4,'callback_data'=>'acc_ok_'.$id]],
                        ]
                        ];
                    break;
            case 'auto_link':
                $t = [
                    'keyboard' => [
                        [['text' => $key['auto_link']]],
                        [['text' => $key['back']]],
                    ]
                ];
                break;
            case 'texts':
                $t = [
                    'keyboard' => [
                        [['text' => $key['text']['start']],['text' => $key['text']['join']]],
                        [['text' => $key['text']['not_found']],['text' => $key['text']['del']]],
                        [['text' => $key['back']]],
                    ]
                ];
                break;
            case 'ads_panel':
                $t = [
                    'keyboard' => [
                        [['text' => $key['timeads']],['text' => $key['typeads']]],
                        [['text' => $key['delads']]],
                        [['text' => $key['back']]],
                    ]
                ];
                break;
                case 'del_baner':
                $ts = 'حذف بنر';
                    $t = ['inline_keyboard'=>[
                        [['text'=>$ts,'callback_data'=>'delbaner']],
                    ]
                    ];
                break;
                case 'del':
                    $code = $data;
                    $ts = 'حذف فایل';
                    $t = ['inline_keyboard'=>[
                        [['text'=>$ts,'callback_data'=>'del_'.$code]],
                    ]
                    ];
                    break;
                case 'joins':
                    $ch = $data[0];
                    $code = $data[1];
                    foreach($ch as $row){
                    $t[] = [['text'=>'عضویت','url'=>$row]];
                    }
                    $t[] = [['text'=>'دریافت فایل','callback_data'=>'file_'.$code]];
                    $t = ['inline_keyboard'=>$t];
                    break;
            case 'end_upload_group':
                $t = [
                    'keyboard' => [
                        [['text' => $key['end_upload_group']]],
                        [['text' => $key['back']]],
                    ]
                ];
                break;
            case 'caption':
                $t = [
                    'keyboard' => [
                        [['text' => $key['no_caption']]],
                        [['text' => $key['back']]],
                    ]
                ];
                break;
            case 'back':
                $t = [
                    'keyboard' => [
                        [['text' => $key['back']]],
                    ]
                ];
                break;
            default:
                $t = ['remove_keyboard' => true];
                break;
        }
        if (isset($t['keyboard'])) {
            $t = array_merge(array_slice($t, 0), ['resize_keyboard' => true], array_slice($t, 0));
            return $t;
        } else {
            return $t;
        }
    }
    function tx($tx,$data=null){
        switch ($tx){
            case 'fyk':
                $t = "🤖 این دکمه نمایشی است";
                break;
            case 'start':
                global $date,$time,$del_time,$emoji;
                $tx = str_replace(['SLEEPTIME','DATE','TIME','CLOCKEMOJI'],[$del_time,$date,$time,$emoji],$data[1]);
                if($data[0]){
                    
                    $tt = "شما وارد منوی مدیریت ربات شدید";
                    $t = $tx."\n".$tt;
                }else{
                    $t = $tx;
                }
            break;
            case 'back':
                $t = "شما وارد منوی مدیریت ربات شدید";
            break;
            case 'not_found':
                global $date,$time,$del_time,$emoji;
                $tx = str_replace(['SLEEPTIME','DATE','TIME','CLOCKEMOJI'],[$del_time,$date,$time,$emoji],$data);
                $t = $tx;
                break;
                case 'del':
                    global $date,$time,$del_time,$emoji;
                    $tx = str_replace(['SLEEPTIME','DATE','TIME','CLOCKEMOJI'],[$del_time,$date,$time,$emoji],$data[2]);
                    if($data[0]){
                        if($data[1]){
                            $tt = "این فایل {$data[3]} بار دانلود شده.";
                            $t = $tx."\n".$tt;
                        }else{
                            $t = $tx;
                        }
                    }else{
                        if($data[1]){
                            $tt = "این فایل {$data[3]} بار دانلود شده.";
                            $t = $tt;
                        }
                    }
                    break;
                    case 'join':
                    global $date,$time,$del_time,$emoji;
                    $tx = str_replace(['SLEEPTIME','DATE','TIME','CLOCKEMOJI'],[$del_time,$date,$time,$emoji],$data);
                    $t = $tx;
                    break;
                    case 'not_join':
                        $t = "شما عضو کانال ها نشده اید";
                        break;
                        case 'setcoinfile':
     
                        $t = "✅مبلغ فایل مورد نظر را برحسب ریال ارسال نمایید
✅نمونه صحیح : 3000
❌نمونه غلط : ۳۰۰۰ ، ۳۰۰۰ ریال ، 3000 ریال";
                        break;
            case 'status':
                $users = $data[0];
                $onlineusers = $data[1];
                $por = ($onlineusers * 100) / $users;
                $pr = floor($por);
                $lastday = $data[2];
                $lastweek = $data[3];
                $lastmonth = $data[4];
                $code = $data[5];
                $ping = $data[6];
                $fileup = $data[7];
                $onlinsers = $data[8];
                $joins = $data[9];
                $admins = $data[10];
                $del_time = $data[11];
                $upuser = $data[12];
                $fileup = $data[13];
                $groupfile = $data[14];
                $day = $data[15];
                if($day == 'رایگان'){
                $t = "🤖 آمار ربات شما
👥 |- تعداد کل کاربران:  <b>$users</b>
🏃‍♂️ |- تعداد کاربران فعال: <b>$onlineusers</b> ($pr%)
🗣 |- کاربران آنلاین: <b>$onlinsers</b> نفر 
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
👤 |- تعداد کاربران فعالیت اخیر 👇
🕛 |- 24 ساعت گذشته: <b>$lastday</b> نفر 
📅 |- 7 روز گذشته: <b>$lastweek</b> نفر 
🗓 |- 31 روز گذشته: <b>$lastmonth</b> نفر
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔐 |- تعداد کانال ها: <b>$joins</b> عدد
👰🏽‍♂️ |- تعداد ادمین ها: <b>$admins</b> نفر
⏳ |- زمان حذف خودکار <b>$del_time</b> ثانیه 
📁 |- تعداد فایل های اپلود شده: <b>$fileup</b> عدد
📂 |- تعداد آلبوم های اپلود شده: <b>$groupfile</b> عدد
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=stats$code'>تصدیق آمار</a>
🏓 |- پینگ <b>$ping</b>

@AnubisUploder_bot";
}else{
$t = "🤖 آمار ربات شما
👥 |- تعداد کل کاربران:  <b>$users</b>
🏃‍♂️ |- تعداد کاربران فعال: <b>$onlineusers</b> ($pr%)
🗣 |- کاربران آنلاین: <b>$onlinsers</b> نفر 
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
👤 |- تعداد کاربران فعالیت اخیر 👇
🕛 |- 24 ساعت گذشته: <b>$lastday</b> نفر 
📅 |- 7 روز گذشته: <b>$lastweek</b> نفر 
🗓 |- 31 روز گذشته: <b>$lastmonth</b> نفر
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
🔐 |- تعداد کانال ها: <b>$joins</b> عدد
👰🏽‍♂️ |- تعداد ادمین ها: <b>$admins</b> نفر
⏳ |- زمان حذف خودکار <b>$del_time</b> ثانیه 
📁 |- تعداد فایل های اپلود شده: <b>$fileup</b> عدد
📂 |- تعداد آلبوم های اپلود شده: <b>$groupfile</b> عدد
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=stats$code'>تصدیق آمار</a>
🏓 |- پینگ <b>$ping</b>

@AnubisUploder_bot";
}
            break;
            case 'sendall1':
                $t = "🔹 یکی از گزینه های زیر را انتخاب نمایید :️";
            break;
            case 'sendall2':
                $t = "❗️یک پیام در حال ارسال میباشد.

🔰شما میتوانید با ویژه کردن ربات خود بدون محدودیت همگانی ارسال کنید.";
            break;
            case 'sendall3':
                $t = "📨 پیام را جهت ارسال به $data[0] نفر بفرستید";
            break;
            case 'sendall4':
                $t = "📨 پیام را جهت ارسال به کاربران بفرستید

👈🏻 درصورتی که میخواهید به تعداد محدودی کاربر ارسال شود عددی در بازه ( 1-$data[0] ) ارسال کنید";
            break;
            case 'sendall5':
                $t = "📨 پیام را جهت ارسال به کاربران بفرستید";
            break;
            case 'sendall6':
                $t = "یک پیام درصف ارسال است لطفا دقایقی دیگر امتحان کنید";
            break;
            case 'sendall7':
                $t = "📨 پیام را جهت ارسال به $data[0] نفر فروارد کنید
                
👈🏻 درصورتی که میخواهید به تعداد محدودی کاربر ارسال شود عددی در بازه ( 1-$data[0] ) ارسال کنید";
            break;
            case 'time_all':
                $t = "بعد از $time ثانیه تلاش کنید";
            break;
            case 'settings':
                $t = "شما وارد منوی تنظیمات ربات شدید";
            break;
            case 'upuser':
                $type = ($data) ? 'روشن': 'خاموش';
                $t = "آپلود فایل توسط کاربران $type شد";
            break;
            case 'not_lock_bot':
                $t = "❗️هنوز رباتی برای جوین اجباری تنظیم نکرده اید.";
            break;
            case 'not_lock_sade':
                $t = "❗️هنوز لینکی برای جوین اختیاری تنظیم نکرده اید.";
            break;
            case 'not_lock_chMedia':
                $t = "❗️هنوز کانالی برای رسانه تنظیم نکرده اید.";
            break;
            case 'not_lock':
                $t = "❗️هنوز کانالی برای جوین اجباری تنظیم نکرده اید.";
            break;
            case 'head_list_lock':
                $t = "کانال های قفل شده:\n";
            break;
            case 'row_list_lock':
                $id = $data[0];
                $username = $data[1];
                $link = $data[2];
                $t = "🆔 $id (@$username)
🔗 $link\n";
            break;
            case 'head_list_bot':
                $t = "ربات های قفل شده:\n";
            break;
            case 'row_list_bot':
                $id = $data[0];
                $username = $data[1];
                $link = $data[2];
                $t = "🆔 $id (@$username)
🔗 $link\n";
            break;
            case 'head_list_chMedia':
                $t = "کانال های قفل شده:\n";
            break;
            case 'row_list_chMedia':
                $id = $data[0];
                $username = $data[1];
                $link = $data[2];
                $t = "🆔 $id (@$username)
🔗 $link\n";
            break;
            case 'head_list_sade':
                $t = "لینک های قفل شده:\n";
            break;
            case 'row_list_sade':
                $link = $data[0];
                $t = "🔗 $link\n";
            break;
            case 'addlockbot5':
                $t = "❗️این ربات قبلا اضافه شده است.";
            break;
            case 'addlockbot4':
                $t = "🤖 یک پیام از ربات مورد نظر فوروارد کنید";
            break;
            case 'addlockbot3':
                $t = "✅ ربات با موفقیت از لیست حذف شد.";
            break;
            case 'addlockbot6':
                $t = "✅ لینک با موفقیت از لیست حذف شد.";
            break;
            case 'addlockbot2':
                $t = "❗️این ربات روی سرور ما ساخته نشده است.";
            break;
            case 'addlockbot1':
                $t = "توکن ارسال شده منقضی شده و صحیح نیست ❗️";
            break;
            case 'addlock1':
                $t = "یک پیام از کانال مورد نظر فوروارد یا لینک پیامش را ارسال کنید";
            break;
            case 'addchMedia':
                $t = "یک پیام از کانال مورد نظر فوروارد کنید";
            break;
            case 'addlock2':
                $t = "درصورتی که میخواهید لینک شخصی ست کنید، لینک را فرستاده
در صورتی که میخواهید بصورت خودکار باشد، کلمه خودکار را ارسال کنید";
            break;
            case 'addlock3':
                $t = "من در این کانال ادمین نیستم یا دسترسی به لینک ندارم!";
                break;
                case 'addlock03':
                $t = "! این کانال در لیست کانال رسانه ها نیست.";
                break;
            case 'addlock4':
                $t = "فقط یک پیام از کانال مورد نظر فوروارد یا لینک پیامش را ارسال کنید";
                break;
            case 'addlock5':
                $t = "اضافه شد";
                break;
            case 'addlock6':
                $t = "لطفا فقط لینک یا کلمه خودکار را ارسال کنید";
                break;
            case 'dellock':
                $t = "حذف شد";
                break;
            case 'auto_del':
                $time = $data;
                $t = "زمان حذف خودکار فعلی: $time
عددی بین 5 تا 180 به عنوان زمان حذف خودکار تنظیم کنید.
درصورتی که میخواهید فایل بطور خودکار حذف نشود، عدد 0 را ارسال کنید";
            break;
            case 'auto_delok':
                $t = "تنظیم شد.";
                break;
                case 'auto_del_int':
                    $t = "فقط عددی بین 5 تا 180 بفرستید";
                    break;
                    
                    case 'not_admins':
                $t = "هیچ کس ادمین ربات نیست!";
            break;
            case 'panelupdm':
                $t = "📌 یکی از گزینه های زیر را انتخاب کنید :";
            break;
            case 'head_list_admin':
                $t = "user_id              - ⚙️ - 📂 - 🔊\n";
            break;
            case 'row_list_admins':
                $id = $data[0];
                $set = $data[1];
                $file = $data[2];
                $all = $data[3];
                $t = "<code>$id</code>     - $set - $file - $all\n";
            break;
            case 'addadmin1':
                $t = "ایدی عددی (user_id) ادمین مورد نظر را بفرستید";
            break;
            case 'addadmin2':
                $id = $data;
                $t = "میخواهید کاربر $id با دسترسی چه چیز هایی ادمین شود؟";
            break;
            case 'addadmin3':
                $t = "کاربر عضو ربات نمیباشد";
            break;
            case 'addadmin4':
                $t = "فقط ایدی عددی (user_id) ادمین مورد نظر را بفرستید";
            break;
            case 'edit_text':
                $t = "متن چه بخشی را میخواهید عوض کنید؟";
            break;
            case 'edit_text2':
                $tx = $data;
                $t = "متن خود را بفرستید، میتوانید از متغیر ها هم استفاده کنید
                درصورتی که میخوهید متن پیشفرض باشد /default را ارسال کنید.
                متغیر های موجود:
                SLEEPTIME = زمان پاکسازی
                DATE = تاریخ فعلی به فرمت yyyy-mm-dd
                TIME = زمان فعلی به فرمت hh:mm:ss
                CLOCKEMOJI = ایموجی ساعت با زمان فعلی
                
                متن فعلی:
                $tx";
            break;
            case 'edit_text3':
            $t = "تنظیم شد";
            break;
            case 'Mediacaption':
                $t = "
🔰 میتوانید هر نوع رسانه ای با کپشن تنظیم کنید.
❗️دکمه شیشه ای زیر بنر تنظیم میگردد برای دریافت فایل ❗️

برای تنظیم بنر مورد نظر خود را ارسال کنید:";
            break;
            case 'Mediacaption2':

                $t = "پیام بالا بنر تنظیم شده است";
            break;
            case 'ads1':
                $t = "تبلیغاتی تنظیم نشده!
                برای تنظیم پیام مورد نظر خود را ارسال کنید.";
            break;
            case 'ads2':
                $type = str_replace(['forwardmessage','copyMessage'],['فورارد','کپی'],$data[0]);
                $bef = str_replace(['bef','af'],['قبل','بعد'],$data[1]);
                $t = "پیام بالا تبلیغات تنظیم شده است
                این پیام {$bef} از فایل {$type} میشود";
            break;
            case 'ads3':
                $type = str_replace(['forwardmessage','copyMessage'],['فورارد','کپی'],$data[0]);
                $bef = str_replace(['bef','af'],['قبل','بعد'],$data[1]);
                $t = "
                این پیام {$bef} از فایل {$type} میشود";
            break;
            case 'linkcoin':
                $idbot = $data[0];
                $code = $data[1];
                $t = "✅ با موفقیت آپلود شد. 
💰 هزینه فایل <b>{$data[2]}</b> ریال
🔰 شناسه فایل : <code>$code</code>
⬇️ لینک دریافت فایل :
🔗 <code>https://t.me/$idbot?start=$code</code>
🔗 <a href='https://t.me/$idbot?start=$code'>دریافت فایل</a>";
                break;
            case 'link':
                $idbot = $data[0];
                $code = $data[1];
                $t = "✅ با موفقیت آپلود شد. در صورتی که میخواهید چیز دیگری هم اپلود شود ارسال نمایید در غیر این صورت دکمه   ( برگشت )  را فشار دهید. 

🔰 شناسه فایل : <code>$code</code>
⬇️ لینک دریافت فایل :
🔗 <code>https://t.me/$idbot?start=$code</code>
🔗 <a href='https://t.me/$idbot?start=$code'>دریافت فایل</a>";
                break;
                case 'grouptaki':
                $t ="📌 رسانه خود را جهت اپلود ارسال نمایید";
            break;
            case 'groupcoin':
                $t ="📌 رسانه خود را جهت اپلود ارسال نمایید

❗️این بخش مخصوص فایل های پولی است. پس از اپلود فایل مقدار هزینه دریافت فایل تنظیم کنید.
❗️برای دریافت فایل لینک پرداخت به صورت خوکار ساخته و پس از تایید پرداخت فایل برای کاربر ارسال میگردد.
➖➖➖➖➖➖➖➖";
            break;
            case 'group1':
                $t ="📌 رسانه های خود را جهت اپلود گروهی ارسال نمایید";
            break;
            case 'group2':
                $n = $data;
                $t ="✅ ثبت شد. فایل های اپلود شده $n/10";
            break;
            case 'group3':
                $t ='⚠️ فقط عکس، فایل، ویدیو و آهنگ قابل اپلود است.';
            break;
            case 'group4':
                $t = "⚠️ امکان ارسال البوم با این فایل نمیباشد.\nعکس و ویدئو با فرمت mp4 باهم\nاهنگ و ویس باهم\nفایل ها باهم";
            break;
            case 'group5':
                $t = "درصورت نیاز کپشن البوم را ارسال کرده و یا برروی بدون کپشن کلیک کنید";
            break;
            case 'default_start':
                $t = "خوش آمدید.\nCLOCKEMOJI DATE TIME";
            break;
            case 'default_not_found':
                $t = "⚠️ فایل مورد نظر پاک شده یا وجود ندارد.";
            break;
            case 'default_join':
                $t = "لطفا در کانال های زیر عضویت و سپس دکمه 'دریافت فایل' را انتخاب کنید.";
            break;
            case 'default_del':
                $t = "این پیام بعد از SLEEPTIME ثانیه پاک میشود.\nلطفا در جایی ذخیره کنید";
            break;
            case 'default_not_sade':
                $t = "⚠️ لینک مورد نظر پاک شده یا وجود ندارد.";
            break;
            
            case 'crlinkshop':
                $t ="♻️در حال ساخت لینک پرداخت....";
            break;
            case 'oklinkshop':
                $t ="لینک پرداخت برای شما با موفقیت ساخته شد✅

⚠️لینک پرداخت پس از چند دقیقه منقضی می شود و تنها یکبار قابل استفاده است";
            break;
            case 'sendtoken':
                $t ="📌توکن ربات مورد نظر را ارسال نمایید

⚠️ میتوانید از توکن هر نوع رباتی استفاده کنید.";
            break;
            case 'sendlink':
                $t ="لینک مورد نظر رسانه خود را ارسال کنید ";
            break;
            case 'dellocksade':
                $t ="لینک رسانه خود را ارسال کنید ";
            break;
            case 'chMedia':
                $t ="برای افزودن قفل (کانال یا گروه) طبق مراحل زیر پیش بروید👇
1️⃣ ربات را در (کانال یا گروه) مورد نظر ادمین کنید.
2️⃣ دستور زیر را کپی و در (کانال یا گروه) ارسال کنید.
<code>lock:$data</code>

☑️ اگر پیام شما حذف شد به معنای اضافه شدن (کانال یا گروه) شما است.";
            break;
       /*     case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            case '':
                $t ="";
            break;
            
            */
            case 'powerbot':
                $t ="✅در این بخش میتوانید در صورت نیاز ربات خود را غیر فعال کنید 

⚠️توجه داشته باشید زمانی که ربات خاموش است تنها مدیران ربات میتوانند با ربات کار کنند";
            break;
            
            
            
            
            
            default :
            $t ="انتخاب کنید";
            break;
        }
        return $t;
    }
}
