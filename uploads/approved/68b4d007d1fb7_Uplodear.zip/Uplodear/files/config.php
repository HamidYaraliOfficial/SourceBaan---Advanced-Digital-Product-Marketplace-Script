<?php

error_reporting(0);

date_default_timezone_set("Asia/Tehran");

@$sec_code = '*SEC*';



define('prefix','*BOT*');

define('code','*CODE*');

define('mainbot','*MAIN*');



@$Token = '*Token*'; // توکن ربات

@$admins = 'Admin'; // ایدی عددی ادمین ربات

@$localhost     = 'localhost'; // درصورت نیاز تغییر دهید

@$db_name       = 'seenapim_botsss'; // نام دیتابیس

@$db_username   = 'seenapim_botsss'; // یوزر دیتابیس

@$db_password   = 'seenapim_botsss'; // رمز یوزر دیتابیسبیس

//------------------------------------//

?>