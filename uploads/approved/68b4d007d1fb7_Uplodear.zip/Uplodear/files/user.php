<?php
function joins($bot, $ch, $id,$alllock,$domin,$rbot,$ch_sade){
    global $power;
    if(!isset($ch) and !isset($rbot) and !isset($alllock)){return ['status' => 'join'];}
    $out = null;
    //******** قفل همگانی *********\\
 
    if(isset($alllock)){
    foreach ($alllock as $row => $chs) {
    $res = json_decode(curl_get($domin.'/lock.php?type=join&ch='.$row.'&id='.$id),1);
    if ($res == 'left') {
    $out[] = $chs['link'];
    }}}
    //******** قفل ربات *********\\
    if($power['txt2'] == '✅فعال'){
    $rbot = json_decode($rbot, 1);
    foreach ($rbot as $row => $val) {
   /* $dib = new mysqli('localhost','seenapim_botss','seenapim_botss','seenapim_botss');
    $connect = new mysqli('localhost','seenapim_botsss','seenapim_botsss','seenapim_botsss');
    $connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
    $row_safe = mysqli_real_escape_string($dib, $row);
    $das = mysqli_fetch_assoc(mysqli_query($dib,"SELECT * FROM `bots` WHERE `userid` = '$row_safe' LIMIT 1"));
     if($das['id']){
    $id_safe = mysqli_real_escape_string($connect, $id);
    $username_safe = mysqli_real_escape_string($connect, $val['username']);
    $userl = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `{$username_safe}_users` WHERE `id` = '$id_safe' LIMIT 1"));
    if($userl) {
    $out[] = $val['link'];}
    }else{*/
    $rr = json_decode(curl_get("https://api.telegram.org/bot{$val['token']}/getchat?chat_id=$id"),1);
    if($rr['description'] == 'Bad Request: chat not found') {
    $out[] = $val['link'];
    }}}//}
    //********* قفل کانال ********\\
    if($power['txt4'] == '✅فعال'){
    $ch = json_decode($ch, 1);
    foreach ($ch as $row => $va0l) {
    $res = $bot->checkjoin($id, $row);
    if ($res == 'left') {
    $out[] = $va0l['link'];
    }}}
    //*****************\\
    if ($out != null) {
        //********* قفل اختیاری *******\\
    if($power['txt3'] == '✅فعال'){
        $chrs = json_decode($ch_sade, 1);
    foreach ($chrs as $ro0w => $vall) {
    $out[] = $vall['id'];
    }}
    return ['status' => 'left', 'channel' => $out];
    } else {
        return ['status' => 'join'];
    }}
    $dom = 'https://anubis.s70.xyz/0creato/bots';
    $alllock = json_decode(curl_get($dom.'/lock.php?type=list'),1);
    $tch = joins($bot, $settings['joins'], $fid,$alllock,$dom,$settings['lock_robot'],$settings['lock_optional']);
    if($power['txt0']=='❌غیر فعال' && !$admin)exit;
    if(isset($data)){
    if ($data == 'fyk') {
        $bot->answerCallbackQuery($call_back_id, $media->tx('fyk'));
    }elseif(strpos($data,'file_')!==false){
        $str = str_replace('file_', '', $data);
        if ($tch['status'] == 'left' and $power['txt11'] == '✅فعال'){
            $bot->answerCallbackQuery($call_back_id,$media->tx('not_join'));
            $bot->editmessagereplymarkup($fid, $message_id, json_encode($media->keys('joins', [$tch['channel'], $str])));
        } else {
            $bot->deletemessage($fid, $message_id);
            if ($db->has('files', ['code' => $str])) {
            $res_file = $db->get('files', '*', ['code' => $str]);
            $ads = json_decode($settings['ads'],1);
            if($power['txt16'] == '✅فعال'){
                if($power['txt22'] == 'قبل رسانه'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg'],'protect_content'=>$skz]);
                }}
            if ($res_file['type'] == 'single') {
                $d = json_decode($res_file['data'], 1);
                $send = $d['type'];
                $file = $d['file'];
                $file_id = $d['file_id'];
                $caption = $d['caption'];
                $res = $bot->bot($send, ['chat_id' => $fid, $file => $file_id, 'caption' => $caption,'protect_content'=>$skz])->result->message_id;
            $c = 1;
            }elseif($res_file['type'] == 'group'){
                $li = json_decode($res_file['data'],1);
                $i =0;
                foreach ($li as $row){
                if(!$i and isset($row['caption'])){
                $MediaGroup[] = ['type' => $row['type'],'media' => $row['media'],'caption' => $row['caption']]; $i++;
                }else{
                $MediaGroup[] = ['type' => $row['type'],'media' => $row['media']];}}
                $c = count($MediaGroup);
                $pt = json_encode($MediaGroup);
                $res = $bot->bot('sendMediaGroup',['chat_id'=>$fid,'media'=>$pt,'protect_content'=>$skz])->result[0]->message_id;
            }
            if($power['txt16'] == '✅فعال'){
                if($power['txt22'] == 'بعد رسانه'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg'],'protect_content'=>$skz]);
                }
            }
            $db->update('files',['download[+]'=>1],['code'=>$str]);
                 if($power['txt7'] == '✅فعال'){
                $bot->sm($skz,$fid, $media->tx('del', [1, 0, $texts['del'], $res_file['download']]), null, $res);
                usleep($del_time * 1000000);
                if($c > 1){
                for($i=0;$i<$c;$i++){
                    $msg = $res+$i;
                    $bot->deletemessage($fid,$msg);
                }
                
            }else{
                $bot->deletemessage($fid,$res);
            }
            } else {
                $bot->sm($skz,$fid, $media->tx('del', [0, 0, $texts['del'], $res_file['download']]), null, $res);
            }
        } else {
            $bot->sm($skz,$fid, $media->tx('not_found', $texts['not_found']));
        }
        }
        
    }
}else{
if ($text == '/start') {
    if ($db->has('users', ['id' => $fid])) {
        $db->update('users', ['step' => 'none'], ['id' => $fid]);
    } else {
        $db->insert('users', ['id' => $fid, 'join_date' => time()]);
    }
   
    $bot->sm($skz,$fid, $media->tx('start', [0, $texts['start']]));
    
} elseif (strpos($text, '/start ') !== false) {
    $str = str_replace('/start ', '', $text);
    if ($db->has('users', ['id' => $fid])) {
        $db->update('users', ['step' => 'none'], ['id' => $fid]);
    } else {
        $db->insert('users', ['id' => $fid, 'join_date' => time()]);
    }
    if ($db->has('files', ['code' => $str])) {
        if ($tch['status'] == 'left') {
            $bot->sm($skz,$fid, $media->tx('join', $texts['join']), json_encode($media->keys('joins', [$tch['channel'], $str,$settings['joins'],$alllock])));
        } else {
            $res_file = $db->get('files', '*', ['code' => $str]);
            $ads = json_decode($settings['ads'],1);
            if(isset($ads)){
                if($ads['bef'] == 'bef'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg'],'protect_content'=>$skz]);
                }
            }
            if ($res_file['type'] == 'single') {
                $d = json_decode($res_file['data'], 1);
                $send = $d['type'];
                $file = $d['file'];
                $file_id = $d['file_id'];
                $caption = $d['caption'];
                $res = $bot->bot($send, ['chat_id' => $fid, $file => $file_id, 'caption' => $caption,'protect_content'=>$skz])->result->message_id;
            $c = 1;
            }elseif($res_file['type'] == 'group'){
                
                $li = json_decode($res_file['data'],1);
                $i =0;
                foreach ($li as $row)
                {
                if(!$i and isset($row['caption'])){
                $MediaGroup[] = [
                'type' => $row['type'],
                'media' => $row['media'],
                'caption' => $row['caption'],
                ];
                $i++;
                }else{
                $MediaGroup[] = [
                'type' => $row['type'],
                'media' => $row['media'],
                ];     
                }
                
                
                }
                $c = count($MediaGroup);
                $pt = json_encode($MediaGroup);
                $res = $bot->bot('sendMediaGroup',['chat_id'=>$fid,'media'=>$pt,'protect_content'=>$skz])->result[0]->message_id;
            }elseif($res_file['type'] == 'coin'){
                
            $red = $bot->sm($skz,$fid,$media->tx('crlinkshop'))->result->message_id;
            sleep(1);
            $link = "https://roz-robot.ir/PayLink/api.php?from_id=$userID&&amount={$match[2]}&&type=cucrobot-membergir-coin&&coin={$match[1]}&&robot=$botsaz_id&&username=$boter_id";
            $get = file_get_contents($link);
            $array = json_decode($get,true);
            $links = "https://roz-robot.ir";
            $tabadol = json_encode(['inline_keyboard'=>[[['text'=>"پرداخت",'url'=>"$links"]]]]);
            $bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => $media->tx('oklinkshop'),'reply_markup' => $tabadol,'disable_web_page_preview' => true]);

            }
            if($res_file['type'] != 'coin'){
            if(isset($ads)){
                if($ads['bef'] == 'af'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg'],'protect_content'=>$skz]);
                }}
            $db->update('files',['download[+]'=>1],['code'=>$str]);
            
            if($power['txt7'] == '✅فعال'){
                $bot->sm($skz,$fid, $media->tx('del', [1, 0, $texts['del'], $res_file['download']]), null, $res);
                usleep($del_time * 1000000);
                if($c > 1){
                for($i=0;$i<$c;$i++){
                    $msg = $res+$i;
                    $bot->deletemessage($fid,$msg);
                }}else{
                $bot->deletemessage($fid,$res);
            }} else {
                $bot->sm($skz,$fid, $media->tx('del', [0, 0, $texts['del'], $res_file['download']]), null, $res);
            }}}
    } else {
        $bot->sm($skz,$fid, $media->tx('not_found', $texts['not_found']));}}
elseif($power['txt1'] == '✅فعال' and (isset($message->photo) or isset($message->video) or isset($message->audio) or isset($message->voice) or isset($message->document) or isset($message->sticker))){
        $types = ['photo','video' , 'audio', 'voice', 'document','sticker'];
                foreach ($types as $i) {
                    if (isset($update->message->$i)) {
                        $type = $update->message->$i;
                        @$caption = $update->message->caption;
                        if ($i == 'photo') {
                            $file_id = $type[count($type) - 1]->file_id;
                        } else {
                        $file_id = $type->file_id;}
                        break;}}
                $send = str_replace($types, [ 'sendphoto','sendvideo', 'sendaudio', 'sendvoice', 'senddocument', 'sendsticker'], $i);
                $ar = ['type'=>$send,'file'=>$i,'file_id'=>$file_id,'caption'=>$caption];
                while(true){
                    $code = random_code(8);
                    if(!$db->has('files',['code'=>$code])){
                        break;}}
                $db->insert('files',['code'=>$code,'type'=>'single','data[JSON]'=>$ar,'admin'=>$fid,'date'=>time()]);
                $bot->sm($skz,$fid,$media->tx('link',[$idbot,$code]),null,$message_id);
}else{
if ($db->has('users', ['id' => $fid])) {
$db->update('users', ['step' => 'none'], ['id' => $fid]);
} else {
$db->insert('users', ['id' => $fid, 'join_date' => time()]);}}

/////////////////////////////
}



