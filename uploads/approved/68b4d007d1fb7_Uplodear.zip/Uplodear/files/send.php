<?php
define('maindir',dirname(__DIR__));
require "config.php";
//-----------------------------------//
require_once maindir."/files/Medoo.php";
require_once maindir."/files/hkbot.php";
//------------------------------------//
use Medoo\Medoo;

$db = new Medoo([
	'type' => 'mysql',
	'host' => $localhost,
	'database' => $db_name,
	'username' => $db_username,
	'password' => $db_password,
	'charset' => 'utf8mb4',
	'collation' => 'utf8mb4_general_ci',
	'prefix' => prefix
]);
$count_send_min = 300;
$for_min = 200;
//===================================================================
$sendtoall = $db->get('sendall', '*', ['id' => 1]);
if ($sendtoall["step"] == "sendall") {
	@$bot = new hkbot($Token);
	$users_count = $db->count('users');
	$users = $db->select("users", 'id', ['LIMIT' => [$sendtoall['user'], $count_send_min]]);
	$info = json_decode($sendtoall['data'], 1);
	$i = 0;
	foreach ($users as $user) {
		$re = $bot->bot('copyMessage', [
			'chat_id' => $user,
			'from_chat_id' => $info['from_chat'],
			'message_id' => $info['msgid']
		]);
		/*
		if ($info['send'] == 'sm') {
			$bot->sm($user, $info['text']);
		} else {
			$bot->bot($info['send'], ['chat_id' => $user, $info['type_file'] => $info['file_id'], 'caption' => $info['caption']]);
		}
		*/
		if($re->ok){
		    $i++;
		    $db->update('users',['online'=>1],['id'=>$user]);
		}else{
		    
		}
	}
	$plus = $sendtoall['user'] + $count_send_min;
	$db->update('sendall', ['user' => $plus], ['id' => 1]);
	
	if ($plus >= $users_count) {
		$db->update('sendall', ['step' => 'none', 'data[JSON]' => [], 'user' => 0,'last'=>time()+1800], ['id' => 1]);
		$bot->sm($sendtoall["admin"], "پیام برای همه کابران ارسال شد");
	}
}
//================================================
elseif ($sendtoall["step"] == "fwd") {
	@$bot = new hkbot($Token);
	$users_count = $db->count('users');
	$users = $db->select("users", 'id', ['LIMIT' => [$sendtoall['user'], $for_min]]);
	$info = json_decode($sendtoall['data'], 1);
	$i = 0;
	foreach ($users as $user) {
		$re = $bot->bot('forwardmessage', [
			'chat_id' => $user,
			'from_chat_id' => $info['from_chat'],
			'message_id' => $info['msgid']
		]);
		if($re->ok){
		    $i++;
		    $db->update('users',['online'=>1],['id'=>$user]);
		}else{
		    
		}
	}
	$plus = $sendtoall['user'] + $for_min;
	$db->update('sendall', ['user' => $plus], ['id' => 1]);
	if ($plus >= $users_count) {
		$db->update('sendall', ['step' => 'none', 'data[JSON]' => [], 'user' => 0,'last'=>time()+1800], ['id' => 1]);
		$bot->sm($sendtoall["admin"], "پیام برای همه کابران ارسال شد");
	}
}
//================================================
$sendtoall = $db->get('sendall', '*', ['id' => 2]);
if ($sendtoall["step"] == "sendall") {
	@$bot = new hkbot($Token);
	$users_count = $db->count('users');
	$users = $db->select("users", 'id', ['LIMIT' => [$sendtoall['user'], $count_send_min]]);
	$info = json_decode($sendtoall['data'], 1);
	foreach ($users as $user) {
		$bot->bot('copyMessage', [
			'chat_id' => $user,
			'from_chat_id' => $info['from_chat'],
			'message_id' => $info['msgid']
		]);
	}
	$plus = $sendtoall['user'] + $count_send_min;
	$db->update('sendall', ['user' => $plus], ['id' => 2]);
	if ($plus >= $users_count) {
		$db->update('sendall', ['step' => 'none', 'data[JSON]' => [], 'user' => 0], ['id' => 2]);
	}
}elseif ($sendtoall["step"] == "fwd") {
	@$bot = new hkbot($Token);
	$users_count = $db->count('users');
	$users = $db->select("users", 'id', ['LIMIT' => [$sendtoall['user'], $for_min]]);
	$info = json_decode($sendtoall['data'], 1);
	foreach ($users as $user) {
		$re = $bot->bot('forwardmessage', [
			'chat_id' => $user,
			'from_chat_id' => $info['from_chat'],
			'message_id' => $info['msgid']
		]);
		
	}
	$plus = $sendtoall['user'] + $for_min;
	$db->update('sendall', ['user' => $plus], ['id' => 2]);
	if ($plus >= $users_count) {
		$db->update('sendall', ['step' => 'none', 'data[JSON]' => [], 'user' => 0], ['id' => 2]);
	}
}else{
    
}












echo 'ok';
?>