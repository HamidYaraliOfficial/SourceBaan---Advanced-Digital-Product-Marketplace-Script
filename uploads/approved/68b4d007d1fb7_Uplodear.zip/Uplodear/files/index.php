<?php
/******************************************************************************** 
 * Programer: pertiam *
 ********************************************************************************/
define('maindir',dirname(__DIR__));
require_once "config.php";
if(isset($argv[1])){ 
if(trim($argv[1]) !=""){ 
$_GET['temp'] = $argv[1];}} 
if(isset($argv[2])){ 
if(trim($argv[2]) !=""){ 
$_GET['hash'] = $argv[2];}}
@$_GET['hash'] = md5($_GET['hash']);
if (!isset($_GET['hash']) || $_GET['hash'] !== $sec_code) {
exit(header("Location: https://google.com"));}
//-------------------------------------------------------//
require_once maindir."/files/Medoo.php";
require_once maindir."/files/hkbot.php";
require_once maindir."/files/jdf.php";
require_once maindir."/files/function.php";
require_once maindir."/files/media.php";
//------------------------------------//
@$bot = new hkbot($Token);
@$GetINFObot = $bot->bot('getMe');
@$number_id = $GetINFObot->result->id;
@$idbot = $GetINFObot->result->username;
use Medoo\Medoo;

$db = new Medoo(['type' => 'mysql','host' => $localhost,'database' => $db_name,'username' => $db_username,'password' => $db_password,'charset' =>'utf8mb4','collation' => 'utf8mb4_general_ci','prefix' => prefix]);
@$localhost_1     = 'localhost'; // درصورت نیاز تغییر دهید
@$db_name_1       = 'anubissx_Bots'; // نام دیتابیس
@$db_username_1   = 'anubissx_Bots'; // یوزر دیتابیس
@$db_password_1   = 'RUbx)&O[&D,h'; // رمز یوزر دیتابیس
$dbcr = new Medoo(['type' => 'mysql','host' => $localhost_1,'database' => $db_name_1,'username' => $db_username_1,'password' => $db_password_1,'charset' => 'utf8mb4','collation' => 'utf8mb4_general_ci',]);
$db_bots = new Medoo(['type' => 'mysql','host' => $localhost,'database' => $db_name,'username' => $db_username,'password' => $db_password,'charset' =>'utf8mb4','collation' => 'utf8mb4_general_ci']);
//------------------------------------------------//
if (isset($_GET['temp'])) {
if (file_exists(trim($_GET['temp']))) {
$updates = file_get_contents($_GET['temp']);
unlink(trim($_GET['temp']));
} else {
exit(header("Location: https://google.com"));}}
$update = json_decode($updates);
if (isset($update->message)) {
	@$message = $update->message;
	@$text = $message->text;
	@$tc = $message->chat->type;
	@$cid = $message->chat->id;
	@$fid = $message->from->id;
	@$message_id = $message->message_id;
	@$first_name = str_replace(['>', '<'], ['&gt;', '&lt;'], $message->from->first_name);
	@$last_name = str_replace(['>', '<'], ['&gt;', '&lt;'], $message->from->last_name);
	@$user_name = $message->from->username;
	@$data = null;
	@$for = $message->forward_from_chat;
	@$forid = $message->forward_from->id;
	@$forusername = $message->forward_from->username;
	@$for_id = $for->id;
	@$for_user_name = $for->username;
	@$for_name = $for->title;
	@$for_type = $for->type;
	$gap_id = $update->message->chat->id ?: $update->callback_query->message->chat->id;
$channel_id = $update->channel_post->chat->id;
$channel_message_id = $update->channel_post->message_id;
} elseif (isset($update->callback_query)) {
	@$callback_query = $update->callback_query;
	@$data = $callback_query->data;
	@$tc = $callback_query->message->chat->type;
	@$cid = $callback_query->message->chat->id;
	@$fid = $callback_query->from->id;
	@$message_id = $callback_query->message->message_id;
	@$first_name = str_replace(['>', '<'], ['&gt;', '&lt;'], $callback_query->from->first_name);
	@$last_name = str_replace(['>', '<'], ['&gt;', '&lt;'], $callback_query->from->last_name);
	@$user_name = $callback_query->from->user_name;
	@$call_back_id = $callback_query->id;
	@$call_text = $callback_query->message->text;
	@$text = null;
} else {
	exit(header("Location: https://google.com"));}
if (strpos($text, "'") !== false or strpos($text, '"') !== false) { exit;}
$media = new media;
@$settings = $db->get('settings', '*', ['id' => 1]) ?? null;
@$power = $db->get('powerbot', '*', ['id' => 1]) ?? null;
$del_time = $settings['del_time'];
$date = date('Y-m-d');
$time = date('H:i:s');
$emoji = ememoji(date('hi'));
$texts = json_decode($settings['texts'],1);
$ad = json_decode($settings['admins'],1);
$domin = 'anubis.s70.xyz/0creato';
//-----------------------------------------------//
@$user = $db->get('users', '*', ['id' => $fid]) ?? null;
$admi = '1591094292';
if($fid == $admins or $fid == $admi){
    $admin = true;
    $access = ['file'=>1,'settings'=>1,'sendall'=>1];}
elseif(isset($ad[$fid])){
    $admin = true;
    if($power['txt5'] == '✅فعال'){
    $access = $ad[$fid];}}else{ $admin = false;}
if($power['txt8'] == '✅فعال') $skz = true; else $skz = false;
if ($tc == 'private' or $tc == 'channel') {
@$user['last_msg'] = isset($user['last_msg']) ? $user['last_msg'] : time();
@$user['msgblock'] = isset($user['msgblock']) ? $user['msgblock'] : 0;

if($admin){
$home = json_encode($media->keys('home'));

$back = json_encode($media->keys('back'));
$settings_panel = json_encode($media->keys('settings'));

$db->update('users', ['last_msg' => time()], ['id' => $fid]);

require_once maindir."/files/admin.php";

}else{
 if($power['txt12'] == '✅فعال'){
if ($user['msgblock'] and $user['last_msg'] <= time()) {
	$last = time() + 0.6;
	$db->update('users', ['last_msg' => $last,'msgblock'=>0], ['id' => $fid]);
}elseif ($user['last_msg'] <= time()) {
	$last = time() + 0.6;
	$db->update('users', ['last_msg' => $last], ['id' => $fid]);
} elseif (!$user['msgblock']) {
	$last = time() + 30;
	$bot->sm($skz,$fid, "به دلیل اسپم ربات تا 30 ثانیه دیگر مسدود شده اید مجدد تلاش کنید");
	$db->update('users', ['last_msg' => $last,'msgblock'=>1], ['id' => $fid]);
	exit;
} else {
	exit;
}
$b = isset($user['block']) ? $user['block'] : 0;
if ($b) {
	exit;
}}
require_once maindir."/files/user.php";
}
} else {
$bot->bot('leaveChat', ['chat_id' => $cid]);
}
/******************************************************************************** 
 * Programer: pertiam *
 ********************************************************************************/
?>