<?php
/******************************************************************************** 
 * Programer: pertiam *
 ********************************************************************************/
function loading(int $precent = 50)
{
    $precent = ($precent > 100) ? 100 : $precent;
    $per = floor($precent / 10);
    $left = 10 - $per;
    $result = str_repeat('◾️', $per) . str_repeat('▫️', $left);
    return $result;
}

if (isset($data)) {
    if ($data == 'fyk') {
        $bot->answerCallbackQuery($call_back_id, $media->tx('fyk'));
    } elseif (strpos($data, 'acc_') !== false) {
        $str = str_replace('acc_', '', $data);
        $ex = explode('_', $str);
        $type = $ex[0];
        if ($type == 'ok') {
            $id = $ex[1];
            $ad = json_decode($settings['admins'], 1);
            $de = json_decode($user['data'], 1);
            $ad[$id] = ['file' => $de['file'], 'settings' => $de['settings'], 'sendall' => $de['sendall']];
            $db->update('settings', ['admins[JSON]' => $ad], ['id' => 1]);
            $bot->deletemessage($fid, $message_id);
            $db->update('users', ['step' => 'settings'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addadminok'), $settings_panel);
        } elseif ($type == 'nok') {
            $bot->deletemessage($fid, $message_id);
            $db->update('users', ['step' => 'settings'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('settings'), $settings_panel);
        } else {
            $de = json_decode($user['data'], 1);
            if ($de[$type]) {
                $de[$type] = 0;
            } else {
                $de[$type] = 1;
            }
            $db->update('users', ['data[JSON]' => $de], ['id' => $fid]);
            $bot->editmessagereplymarkup($fid, $message_id, json_encode($media->keys('access_admin', [$de['id'], off($de['file']), off($de['settings']), off($de['sendall'])])));
        }
    }elseif (strpos($data, 'del_') !== false) {
        $str = str_replace('del_', '', $data);
        $db->delete('files',['code'=>$str]);
        $bot->deletemessage($fid, $message_id);
        $bot->sm($skz,$fid,"حذف شد");
    }
///////////////////////////////////////////////////////////////////
elseif($data == 'delbaner'){
            $db->update('settings',['Mediacaption'=>null],['id'=>1]);
            $bot->deletemessage($fid, $message_id);
        $bot->sm($skz,$fid,"حذف شد");
        }
//============================================================================\\
elseif(preg_match('/^power:(.*)/', $data, $match)){
$dok = $match[1];
$bot->answerCallbackQuery($call_back_id,$math);
@$math = $db->get('powerbot', '*', ['id' => 1]) ?? null;
if($math["$dok"] == 'شیشه ای')$slts= 'متنی';
if($math["$dok"] == 'متنی')$slts= 'شیشه ای';
if($math["$dok"] == 'بعد رسانه')$slts= 'قبل رسانه';
if($math["$dok"] == 'قبل رسانه')$slts= 'بعد رسانه';
if($math["$dok"] == 'فروارد')$slts= 'کپی';
if($math["$dok"] == 'کپی')$slts= 'فروارد';
if($math["$dok"] == 'روشن')$slts= 'خاموش';
if($math["$dok"] == 'خاموش')$slts= 'روشن';
if($math["$dok"] == '✅فعال')$slts= '❌غیر فعال';
if($math["$dok"] == '❌غیر فعال')$slts= '✅فعال';
$math["$dok"]= "$slts";
$db->update('powerbot', ["$dok" => $slts], ['id' => 1]);
@$power = $db->get('powerbot', '*', ['id' => 1]) ?? null;
$keyb[] = [['text'=>"👇🏻وضعیت ربات👇🏻",'callback_data'=>"null"],['text'=>"👇🏻بخش ربات👇🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt0']}",'callback_data'=>"power:txt0"],['text'=>"🤖 ربات 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt1']}",'callback_data'=>"power:txt1"],['text'=>"🤖 آپلود توسط کاربران 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt2']}",'callback_data'=>"power:txt2"],['text'=>"🤖 قفل ربات 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt3']}",'callback_data'=>"power:txt3"],['text'=>"🤖 قفل اختیاری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt4']}",'callback_data'=>"power:txt4"],['text'=>"🤖 قفل کانال 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt5']}",'callback_data'=>"power:txt5"],['text'=>"🤖 دسترسی ادمین ها 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt6']}",'callback_data'=>"power:txt6"],['text'=>"🤖 پین همگانی 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt7']}",'callback_data'=>"power:txt7"],['text'=>"🤖 حذف خودکار 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt8']}",'callback_data'=>"power:txt8"],['text'=>"🤖 محافظت از محتوا 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt9']}",'callback_data'=>"power:txt9"],['text'=>"🤖 محافظت از همگانی 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt10']}",'callback_data'=>"power:txt10"],['text'=>"🤖 سین زماندار 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt11']}",'callback_data'=>"power:txt11"],['text'=>"🤖 جوین اجباری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt12']}",'callback_data'=>"power:txt12"],['text'=>"🤖 آنتی اسپم 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt13']}",'callback_data'=>"power:txt13"],['text'=>"🤖 لایک و دیسلایک 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt14']}",'callback_data'=>"power:txt14"],['text'=>"🤖 کپشن پیشفرض 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt15']}",'callback_data'=>"power:txt15"],['text'=>"🤖 نمایش دانلود 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt16']}",'callback_data'=>"power:txt16"],['text'=>"🤖 تبلیغات 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt17']}",'callback_data'=>"power:txt17"],['text'=>"🤖 گزارش کار ادمین 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt21']}",'callback_data'=>"power:txt21"],['text'=>"🔰 جوین اجباری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt22']}",'callback_data'=>"power:txt22"],['text'=>"🔰 مکان تبلیغ 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt23']}",'callback_data'=>"power:txt23"],['text'=>"🔰 نوع تبلیغ 👈🏻",'callback_data'=>"null"]];
/*$keyb[] = [['text'=>"{$power['txt24']}",'callback_data'=>"power:txt24"],['text'=>"",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt25']}",'callback_data'=>"power:txt25"],['text'=>"",'callback_data'=>"null"]];*/

//$keyb[] = [['text'=>"",'callback_data'=>"null"],['text'=>"",'callback_data'=>"null"]];
$butt = json_encode(['inline_keyboard'=>$keyb,'resize_keyboard'=>true]);
$bot->bot('editMessageReplyMarkup',['chat_id'=>$fid,'message_id'=>$message_id,'reply_markup'=>$butt]);}


///////////////////////////////////////////////////////////////////
} else {
    if ($text == '/start') {
        if ($db->has('users', ['id' => $fid])) {
            $db->update('users', ['step' => 'none'], ['id' => $fid]);
        } else {
            $db->insert('users', ['id' => $fid, 'join_date' => time()]);
        }
        $db->update('users', ['step' => 'none'], ['id' => $fid]);
        $bot->sm($skz,$fid, $media->tx('start', [1, $texts['start']]), $home);
    } elseif(strpos($text,'/start ') !== false){
        $str = str_replace('/start ','',$text);
        if($db->has('files',['code'=>$str])){
            $res_file = $db->get('files','*',['code'=>$str]);
            $ads = json_decode($settings['ads'],1);
            if(isset($ads)){
                if($ads['bef'] == 'bef'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg']]);
                }
            }
            if($res_file['type'] == 'single'){
                $d = json_decode($res_file['data'],1);
                $send = $d['type'];$file = $d['file'];$file_id = $d['file_id'];$caption = $d['caption'];
                $res = $bot->bot($send, ['chat_id' => $fid, $file => $file_id, 'caption' => $caption])->result->message_id;
                $c = 1;
            }elseif($res_file['type'] == 'group'){
                
                $li = json_decode($res_file['data'],1);
                $i =0;
                foreach ($li as $row)
                {
                if(!$i and isset($row['caption'])){
                $MediaGroup[] = [
                'type' => $row['type'],
                'media' => $row['media'],
                'caption' => $row['caption'],
                ];
                $i++;
                }else{
                $MediaGroup[] = [
                'type' => $row['type'],
                'media' => $row['media'],
                ];     
                }
                
                
                }
                $c = count($MediaGroup);
                $pt = json_encode($MediaGroup);
                $res = $bot->bot('sendMediaGroup',['chat_id'=>$fid,'media'=>$pt])->result[0]->message_id;
            }
            elseif($res_file['type'] == 'coin'){
                
            $red = $bot->sm($skz,$fid,$media->tx('crlinkshop'))->result->message_id;
            sleep(1);

            $get = file_get_contents($link);
            $array = json_decode($get,true);
            $links = "https://roz-robot.ir";
            $tabadol = json_encode(['inline_keyboard'=>[[['text'=>"پرداخت",'url'=>"$links"]]]]);
            $bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => $media->tx('oklinkshop'),'reply_markup' => $tabadol,'disable_web_page_preview' => true]);

            
            }
            if($res_file['type'] != 'coin'){
            if(isset($ads)){
                if($ads['bef'] == 'af'){
                    $bot->bot($ads['type'],['chat_id'=>$fid,'from_chat_id'=>$ads['id'],'message_id'=>$ads['msg']]);
                }
            }
            
            if($del_time){
            $bot->sm($skz,$fid,$media->tx('del',[1,1,$texts['del'],$res_file['download']]),json_encode($media->keys('del',$str)),$res);
            usleep($del_time*1000000);
            if($c > 1){
                for($i=0;$i<$c;$i++){
                    $msg = $res+$i;
                    $bot->deletemessage($fid,$msg);
                }
                
            }else{
                $bot->deletemessage($fid,$res);
            }
            
            }else{
            $bot->sm($skz,$fid,$media->tx('del',[0,1,$texts['del'],$res_file['download']]),json_encode($media->keys('del',$str)),$res);
            }
            
       }}else{
            $bot->sm($skz,$fid,$media->tx('not_found',$texts['not_found']));
        }
}elseif ($text == $key['back'] ) {
$db->update('users', ['step' => 'none'], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('start', [1, $texts['start']]), $home);
} 

elseif ($text == $key['info']) {
$msgid= $bot->sm($skz,$fid,'❗️این بخش از ربات فعال نیست.' )->result->message_id;
} 
    elseif ($text == $key['status']) {
        $users = $db->count('users');
        $onlineusers = $db->count('users',['online'=>1]);
        $today1 = date('Y/m/d h:i:s');
        $today = strtotime("now");
        $minutes = strtotime($today1 . "-10 seconds");
        $yes = strtotime($today1 . "-1 day");
        $week = strtotime($today1 . "-7 day");
        $month = strtotime($today1 . "-30 day");
        $minutess = $db->count('users', 'id', ['join_date[<>]' => [$minutes, $today]]);
        $lastday = $db->count('users', 'id', ['join_date[<>]' => [$yes, $today]]);
        $lastweek = $db->count('users', 'id', ['join_date[<>]' => [$week, $today]]);
        $lastmonth = $db->count('users', 'id', ['join_date[<>]' => [$month, $today]]);
        $code = code;
        
        
        $rr = $dbcr->get('bots','*',['userid'=>$number_id]) ?? null;
if ($typebot == 'vip'){
$a = date('Y/m/d');
$sec = strtotime($rr['date'])-strtotime($a);
$days = $sec/86400;
$datebot = explode('.',$days)[0];
}else{
$datebot = 'رایگان';
}
        $ping = ping('api.telegram.org');
        $joins = (isset($settings['joins'])) ? count(json_decode($settings['joins'],1)):0;
        $admincount = (isset($settings['admins'])) ? count(json_decode($settings['admins'],1)):0;
        @$math = $db->get('powerbot', '*', ['id' => 1]) ?? null;
        $userup = str_replace([0, 1], ['خاموش', 'روشن'], $settings['upuser']);
        $fileup = $db->count('files', ['type' => 'single']);
        $groupup = $db->count('files', ['type' => 'group']);
        $bot->sm($skz,$fid, $media->tx('status', [$users, $onlineusers, $lastday, $lastweek, $lastmonth, $code, $ping,$fileup,$minutess, $joins, $admincount, $del_time, $userup, $fileup, $groupup,$datebot]), null, $message_id);
    }
    
    
    elseif ($text == $key['sendall'] or ($text == $key['back'] and in_array($user['data'], ['sendall']))){
            if($access['sendall']){
        $db->update('users', ['step' => "sendall",'data' => null], ['id' => $fid]);
       $sendstep = $db->count('sendall');
            $bot->sm($skz,$fid, $media->tx('sendall1'), json_encode($media->keys('send_panel')));
        
                
    }else{
        $db->update('users', ['data' => null], ['id' => $fid]);
        $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
    }
    }  
elseif ($text == $key['fealyabi']  and $user['step'] == 'sendall'){
$sendstep = $db->count('sendall');
$db->update('users', ['step' => "fealyabi"], ['id' => $fid]);
$users_count = $db->count('users');
$bot->sm($skz,$fid, $media->tx('sendall5'), $back);
}
elseif ($user["step"] == "fealyabi" and $text != '↪️ برگشت') {
$db->update('users', ['step' => "sendall",'data' => "sendall"], ['id' => $fid]);
$db->update('users',['online'=>0]);
$db->insert('sendall', ['step' => 'fealyabi', 'data[JSON]' => ['msgid' => $message_id, 'from_chat' => $fid], 'user' => $fid, 'admin' => $fid,'id' => $message_id]);
$red= $bot->sm($skz,$fid, '📯 درحال شروع عملیات ...')->result->message_id;
sleep(2);
$code = random_code(8);
$users_count = $db->count('users');
$db_bots->insert('Public_all', ['admin' => $fid,'users' => '0','user' => $users_count,'name' => 'fealyabi', 'step' => 'Beginning', 'username' => $idbot,'id' => $code]);

$users = $db->select("users", 'id', ['LIMIT' => [0, null]]);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال آماده سازی
🚀 |- سرعت ارسال در دقیقه : 600 نفر
📊 |- ▫️▫️▫️▫️▫️▫️▫️▫️▫️▫️ 0% 0/$users_count
🏃‍♂️ |- ▫️▫️▫️▫️▫️▫️▫️▫️▫️▫️ 0% 0/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$i = 0; $u = 0; $o = 0;
foreach ($users as $user) {
$re = $bot->bot('copyMessage', ['chat_id' => $user,'from_chat_id' => $fid,'message_id' =>$message_id]); $u++; $o++;
if($re->ok){$i++;$db->update('users',['online'=>1],['id'=>$user]);}
if(in_array($u, ['50'])){

$db_bots->update('Public_all', ['users' => "$o"], ['id' => $code]);

$ters = $o*100/$users_count;
$op = explode('.',$ters)[0];
$loads= loading($op);
$tes = $i*100/$users_count;
$ops = explode('.',$tes)[0];
$load = loading($ops);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال ارسال
🚀 |- سرعت ارسال در دقیقه : 600 نفر
📊 |- $loads $op% $o/$users_count
🏃‍♂️ |- $load $ops% $i/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$u = 0;}$y++;}
$db->delete('sendall',['id'=>$message_id]);

$db_bots->update('Public_all', ['users' => "$users_count",'step' => "end"], ['id' => $code]);

$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : اتمام ارسال
🚀 |- سرعت ارسال در دقیقه : 600 نفر
📊 |- ◾️◾️◾️◾️◾️◾️◾️◾️◾️◾️ 100% $users_count/$users_count
🏃‍♂️ |- $load $ops% $i/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);}
/////////////////////////////////////////////////////////
elseif ($text == $key['msgall']  and $user['step'] == 'sendall') {
$sendstep = $db->count('sendall');
$db->update('users', ['step' => "msgall:0",'data' => "sendall"], ['id' => $fid]);
$users_count = $db->count('users');
$bot->sm($skz,$fid, $media->tx('sendall4',[$users_count]), $back);
}
elseif(preg_match('/^msgall:(.*)/', $user['step'], $mc) and $text != '↪️ برگشت'){
$db->update('users', ['step' => "msgall",'data' => "sendall"], ['id' => $fid]);
$userscount = $db->count('users');
if(preg_match('/^([0-9])/',$text) and $text >= 1 && $text <= $userscount){
$db->update('users', ['step' => "msgall:$text",'data' => "sendall"], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('sendall3',[$text]), $back);
}else{
if($mc[1] >= 1){
$users_count = $mc[1];
$users = $db->select("users", 'id', ['LIMIT' => [$users_count, $users_count]]);
}else{
$users_count = $db->count('users');
$users = $db->select("users", 'id', ['LIMIT' => [0, null]]);}
$db->update('users', ['step' => "sendall",'data' => "sendall"], ['id' => $fid]);
$red= $bot->sm($skz,$fid, '📯 درحال شروع عملیات ...')->result->message_id;
sleep(2);
$code = random_code(8);
$users_count = $db->count('users');
$db_bots->insert('Public_all', ['admin' => $fid,'users' => '0','user' => $users_count,'name' => 'msgall', 'step' => 'Beginning', 'username' => $idbot,'id' => $code]);

$db->insert('sendall', ['step' => 'fealyabi', 'data[JSON]' => ['msgid' => $message_id, 'from_chat' => $fid], 'user' => $fid, 'admin' => $fid,'id' => $message_id]);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال آماده سازی
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- ▫️▫️▫️▫️▫️▫️▫️▫️▫️▫️ 0% 0/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$u = 0; $o = 0;
foreach ($users as $user) {
$re = $bot->bot('copyMessage', ['chat_id' => $user,'from_chat_id' => $fid,'message_id' =>$message_id]); $u++; $o++;
if(in_array($u, ['50'])){
    $db_bots->update('Public_all', ['users' => "$o"], ['id' => $code]);

$ters = $o*100/$users_count;
$op = explode('.',$ters)[0];
$loads= loading($op);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال ارسال
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- $loads $op% $o/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$u = 0;}$y++;}
$db->delete('sendall',['id'=>$message_id]);
$db_bots->update('Public_all', ['users' => "$users_count",'step' => "end"], ['id' => $code]);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : اتمام ارسال
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- ◾️◾️◾️◾️◾️◾️◾️◾️◾️◾️ 100% $users_count/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);}}
//////////////////////////////////////////////////////////
 elseif ($text == $key['forall']  and $user['step'] == 'sendall') {
$sendstep = $db->count('sendall');
$db->update('users', ['step' => "forall:0"], ['id' => $fid]);
$users_count = $db->count('users');
$bot->sm($skz,$fid, $media->tx('sendall7',[$users_count]), $back);}
//**************\\
elseif(preg_match('/^forall:(.*)/', $user['step'], $mc) and $text != '↪️ برگشت'){
$db->update('users', ['step' => "forall"], ['id' => $fid]);
$userscount = $db->count('users');
if(preg_match('/^([0-9])/',$text) and $text >= 1 && $text <= $userscount){
$db->update('users', ['step' => "forall:$text",'data' => "sendall"], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('sendall3',[$text]), $back);
}else{
if($mc[1] >= 1){
$users_count = $mc[1];
$users = $db->select("users", 'id', ['LIMIT' => [$users_count, $users_count]]);
}else{
$users_count = $db->count('users');
$users = $db->select("users", 'id', ['LIMIT' => [0, null]]);}
$db->update('users', ['step' => "sendall",'data' => "sendall"], ['id' => $fid]);
$red= $bot->sm($skz,$fid, '📯 درحال شروع عملیات ...')->result->message_id;
sleep(2);
$code = random_code(8);
$users_count = $db->count('users');
$db_bots->insert('Public_all', ['admin' => $fid,'users' => '0','user' => $users_count,'name' => 'forall', 'step' => 'Beginning', 'username' => $idbot,'id' => $code]);

$db->insert('sendall', ['step' => 'fealyabi', 'data[JSON]' => ['msgid' => $message_id, 'from_chat' => $fid], 'user' => $fid, 'admin' => $fid,'id' => $message_id]);
$users = $db->select("users", 'id', ['LIMIT' => [0, null]]);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال آماده سازی
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- ▫️▫️▫️▫️▫️▫️▫️▫️▫️▫️ 0% 0/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$u = 0; $o = 0;
foreach ($users as $user) {
$bot->bot('forwardmessage', ['chat_id' => $user,'from_chat_id' => $fid,'message_id' =>$message_id]); $u++; $o++;
if(in_array($u, ['50'])){
    $db_bots->update('Public_all', ['users' => "$o"], ['id' => $code]);

$ters = $o*100/$users_count;
$op = explode('.',$ters)[0];
$loads= loading($op);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : در حال ارسال
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- $loads $op% $o/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
$u = 0;}$y++;}
$db->delete('sendall',['id'=>$message_id]);
$db_bots->update('Public_all', ['users' => "$users_count",'step' => "end"], ['id' => $code]);
$bot->bot('editmessagetext', ['chat_id' => $fid,'message_id' => $red,'text' => "
🔗 |- <a href='https://t.me/AnubisUploder_bot?start=hamegani_$code'>تصدیق همگانی</a>
♻️ |- وضعیت : اتمام ارسال
🚀 |- سرعت ارسال در دقیقه : 1000 نفر
📊 |- ◾️◾️◾️◾️◾️◾️◾️◾️◾️◾️ 100% $users_count/$users_count",'reply_markup' => null,'parse_mode'=>'HTML','disable_web_page_preview' => true]);
}}
///////////////////////////////////////////////////////////////////////////
    elseif (($text == $key['settings'] and $user['step'] == 'none') or ($text == $key['back'] and in_array($user['step'], ['ads', 'texts', 'joins', 'auto_del', 'admins','joinbots','joinsade','chMedia','addMediacaption']))) {
             if($access['settings']){
        $db->update('users', ['step' => 'settings'], ['id' => $fid]);
        $bot->sm($skz,$fid, $media->tx('settings'), $settings_panel);
                
    }else{
        $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
    }
    } elseif ($user['step'] == 'settings' or ($text == $key['back'] and in_array($user['step'], ['addlock1', 'dellock1', 'deladmin', 'addadmin','texts2','joinbot','delrobots','joinbotss','joinsades','chMedias','addchMedia','delchMedia','addMediacaption']))) {
        if ($text == $key['joins'] or ($text == $key['back'] and in_array($user['step'], ['addlock1', 'dellock1']))) {
            $db->update('users', ['step' => 'joins'], ['id' => $fid]);
                if (isset($settings['joins']) and $settings['joins'] != '[]') {
                $list = $media->tx('head_list_lock');
                $d = json_decode($settings['joins'], 1);
                foreach ($d as $row) {
                    $list .= $media->tx('row_list_lock', [$row['id'], $row['username'], $row['link']]);
                }
                $bot->sm($skz,$fid, $list, json_encode($media->keys('lock', 1)));
            } else {
                $bot->sm($skz,$fid, $media->tx('not_lock'), json_encode($media->keys('lock')));
            }
        }
        elseif ($text == $key['joinbot'] or ($text == $key['back'] and in_array($user['step'], ['joinbot', 'delrobots','joinbotss']))) {
            $db->update('users', ['step' => 'joinbots'], ['id' => $fid]);
                if (isset($settings['lock_robot']) and $settings['lock_robot'] != '[]') {
                $list = $media->tx('head_list_bot');
                $d = json_decode($settings['lock_robot'], 1);
                foreach ($d as $row) {
                    $list .= $media->tx('row_list_bot', [$row['id'], $row['username'], $row['link']]);
                }
                $bot->sm($skz,$fid, $list, json_encode($media->keys('joinbot', 1)));
            } else {
                $bot->sm($skz,$fid, $media->tx('not_lock_bot'), json_encode($media->keys('joinbot')));
            }
        }
        elseif ($text == $key['joinsade'] or ($text == $key['back'] and in_array($user['step'], ['joinsade', 'delsade','joinsades']))) {
            $db->update('users', ['step' => 'joinsade'], ['id' => $fid]);
                if (isset($settings['lock_optional']) and $settings['lock_optional'] != '[]') {
                $list = $media->tx('head_list_sade');
                $d = json_decode($settings['lock_optional'], 1);
                foreach ($d as $row) {
                    $list .= $media->tx('row_list_sade', [$row['link']]);
                }
                $bot->sm($skz,$fid, $list, json_encode($media->keys('joinsade', 1)));
            } else {
                $bot->sm($skz,$fid, $media->tx('not_lock_sade'), json_encode($media->keys('joinsade')));
            }
        }
        elseif ($text == $key['chMedia'] or ($text == $key['back'] and in_array($user['step'], ['chMedias', 'delchMedia','addchMedia','addMediacaption']))) {
            $db->update('users', ['step' => 'chMedia'], ['id' => $fid]);
                if (isset($settings['lock_Media']) and $settings['lock_Media'] != '[]') {
                $list = $media->tx('head_list_chMedia');
                $d = json_decode($settings['lock_Media'], 1);
                foreach ($d as $row) {
                    $list .= $media->tx('row_list_chMedia', [$row['id'], $row['username'], $row['link']]);
                }
                $bot->sm($skz,$fid, $list, json_encode($media->keys('chMedia', 1)));
            } else {
                $bot->sm($skz,$fid, $media->tx('not_lock_chMedia'), json_encode($media->keys('chMedia')));
            }
        }
       elseif ($text == $key['auto_del']) {
            $db->update('users', ['step' => 'auto_del'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('auto_del', $del_time), $back);
        } elseif ($text == $key['admins'] or ($text == $key['back'] and in_array($user['step'], ['deladmin', 'addadmin']))) {
            if($fid == $admins){
            $db->update('users', ['step' => 'admins'], ['id' => $fid]);
            if (isset($settings['admins']) and $settings['admins'] != '[]') {
                $list = $media->tx('head_list_admin');
                $d = json_decode($settings['admins'], 1);
                foreach ($d as $row => $val) {
                    $list .= $media->tx('row_list_admins', [$row, off($val['settings']), off($val['file']), off($val['sendall'])]);
                }
                $bot->sm($skz,$fid, $list, json_encode($media->keys('admins', 1)));
            } else {
                $bot->sm($skz,$fid, $media->tx('not_admins'), json_encode($media->keys('admins')));
            }
            }else{
        $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
    }
        } elseif ($text == $key['texts'] or ($text == $key['back'] and $user['step'] == 'texts2')) {
            $db->update('users', ['step' => 'texts'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('edit_text'), json_encode($media->keys('texts')));
        } elseif ($text == $key['usersupload']) {
            if ($settings['upuser']) {
                $db->update('settings', ['upuser' => 0], ['id' => 1]);
                $bot->sm($skz,$fid, $media->tx('upuser', 0));
            } else {
                $db->update('settings', ['upuser' => 1], ['id' => 1]);
                $bot->sm($skz,$fid, $media->tx('upuser', 1));
            }
        } elseif ($text == $key['ads']) {
            $db->update('users', ['step' => 'ads'], ['id' => $fid]);
            if (isset($settings['ads']) and $settings['ads'] != '[]') {
                //ads
                $arr = json_decode($settings['ads'],1);
                $bot->bot($arr['type'],['chat_id'=>$fid,'from_chat_id'=>$arr['id'],'message_id'=>$arr['msg']]);
                $bot->sm($skz,$fid,$media->tx('ads2',[$arr['type'],$arr['bef']]),json_encode($media->keys('ads_panel')));
            } else {
                $db->update('users', ['step' => 'addads'], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('ads1'), $back);
            }
        }
        
    }
    
    elseif ($user['step'] == 'joins' or ($text == $key['back'] and in_array($user['step'], ['addlock2']))) {
        if ($text == $key['back']) {
            $db->update('users', ['step' => 'addlock1'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addlock1'), $back);
        } elseif ($text == $key['addjoin']) {
            $db->update('users', ['step' => 'addlock1'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addlock1'), $back);
        } elseif ($text == $key['deljoin']) {
            $db->update('users', ['step' => 'dellock1'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addlock1'), $back);
        }
    } elseif ($user['step'] == 'addlock1') {
        $d = json_decode($settings['joins'], 1);
        if (isset($for) and $for_type == 'channel') {
            $res = $bot->checkjoin($number_id, $for_id);
            if ($res == 'administrator') {
                $userid = $for_id;
                $userna = isset($for_user_name) ? $for_user_name : 'private';
                $rr = $bot->bot('getChat', ['chat_id' => $userid]);
                $invitelink = $rr->result->invite_link;
                $title = $rr->result->title;

                $db->update('users', ['step' => 'addlock2', 'data[JSON]' => ['id' => $userid, 'username' => $userna, 'link' => $invitelink,'title'=>$title]], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('addlock2'), json_encode($media->keys('auto_link')));
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock3'));
            }
        } else {
            $ex = explode('/', $text);
            $c = count($ex);
            if ($ex[$c - 3] == 'c' and $c == 6) {
                $id = '-100' . $ex[$c - 2];
                $res = $bot->checkjoin($number_id, $id);
                if ($res == 'administrator') {
                    $userid = $id;
                    $userna = 'private';
                    $rr = $bot->bot('getChat', ['chat_id' => $userid]);
                    $invitelink = $rr->result->invite_link;
                    $title = $rr->result->title;

                    $db->update('users', ['step' => 'addlock2', 'data[JSON]' => ['id' => $userid, 'username' => $userna, 'link' => $invitelink,'title'=>$title]], ['id' => $fid]);
                    $bot->sm($skz,$fid, $media->tx('addlock2'), json_encode($media->keys('auto_link')));
                } else {
                    $bot->sm($skz,$fid, $media->tx('addlock3'));
                }
            } elseif ($c == 5) {
                $res = $bot->checkjoin($number_id, $ex[$c - 2]);

                if ($res == 'administrator') {
                    $get = $bot->bot('getChat', ['chat_id' => '@' . $ex[$c - 2]]);

                    $userid     = $get->result->id;
                    $userna     = $get->result->username;
                    $invitelink = $get->result->invite_link;
                    $title = $get->result->title;

                    $db->update('users', ['step' => 'addlock2', 'data[JSON]' => ['id' => $userid, 'username' => $userna, 'link' => $invitelink,'title'=>$title]], ['id' => $fid]);
                    $bot->sm($skz,$fid, $media->tx('addlock2'), json_encode($media->keys('auto_link')));
                } else {
                    $bot->sm($skz,$fid, $media->tx('addlock3'));
                }
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock4'));
            }
        }
    } elseif ($user['step'] == 'addlock2') {
        if ($text == $key['auto_link']) {
            $decode = json_decode($user['data'], 1);
            $userid = $decode['id'];
            $userna = $decode['username'];
            $link = $decode['link'];
            $title = $decode['title'];
            $joins = json_decode($settings['joins'], 1);
            $joins[$userid] = ['id' => $userid, 'username' => $userna, 'link' => $link,'title'=>$title];
            $db->update('settings', ['joins[JSON]' => $joins], ['id' => 1]);
            $db->update('users', ['step' => 'settings', 'data' => null], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addlock5'), $settings_panel);
        } else {
            // (https:?\/\/t.me.*)\w+
            if(preg_match('/(https:?\/\/t.me.*)\w+/',$text,$m)){
            $link =  $m[0];
            $ex = explode('/', $link);
            $c = count($ex);
            if ($c == 4 or $c == 5) {
                $decode = json_decode($user['data'], 1);
                $userid = $decode['id'];
                $userna = $decode['username'];
                $title = $decode['title'];
                $joins = json_decode($settings['joins'], 1);
                $joins[$userid] = ['id' => $userid, 'username' => $userna, 'link' => $link,'title'=>$title];
                $db->update('settings', ['joins[JSON]' => $joins], ['id' => 1]);
                $db->update('users', ['step' => 'settings', 'data' => null], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('addlock5'), $settings_panel);
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock6'));
            }
            }else{
            $bot->sm($skz,$fid,"یک لینک معتبر وارد کنید");
        }
        }
        
    } elseif ($user['step'] == 'dellock1') {
        $d = json_decode($settings['joins'], 1);
        if (isset($for) and $for_type == 'channel') {
            $userid = $for_id;
            if (isset($d[$userid])) {
                unset($d[$userid]);
                $db->update('settings', ['joins[JSON]' => $d], ['id' => 1]);
                $db->update('users', ['step' => 'settings', 'data' => null], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('dellock'), $settings_panel);
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock3'));
            }
        } else {
            $ex = explode('/', $text);
            $c = count($ex);
            if ($ex[$c - 3] == 'c' and $c == 6) {
                $id = '-100' . $ex[$c - 2];
                $userid = $id;
                if (isset($d[$userid])) {
                    unset($d[$userid]);
                    $db->update('settings', ['joins[JSON]' => $d], ['id' => 1]);
                    $db->update('users', ['step' => 'settings', 'data' => null], ['id' => $fid]);
                    $bot->sm($skz,$fid, $media->tx('dellock'), $settings_panel);
                } else {
                    $bot->sm($skz,$fid, $media->tx('addlock3'));
                }
            } elseif ($c == 5) {
                $get = $bot->bot('getChat', ['chat_id' => '@' . $ex[$c - 2]]);
                $userid     = $get->result->id;
                if (isset($d[$userid])) {

                    unset($d[$userid]);
                    $db->update('settings', ['joins[JSON]' => $d], ['id' => 1]);
                    $db->update('users', ['step' => 'settings', 'data' => null], ['id' => $fid]);
                    $bot->sm($skz,$fid, $media->tx('dellock'), $settings_panel);
                } else {
                    $bot->sm($skz,$fid, $media->tx('addlock3'));
                }
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock4'));
            }
        }
    }
//========================================================

 elseif ($user['step'] == 'chMedia' or ($text == $key['back'] and in_array($user['step'], ['chMedia','addchMedia','delchMedia','addMediacaption']))) {
if ($text == $key['addchMedia']) {
            $db->update('users', ['step' => 'addchMedia'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addchMedia'), $back);
        } elseif ($text == $key['delchMedia']) {
            $db->update('users', ['step' => 'delchMedia'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addchMedia'), $back);
        }
     elseif ($user['step'] == 'addchMedia') {
        $d = json_decode($settings['lock_Media'], 1);
        if (isset($for) and $for_type == 'channel') {
            $res = $bot->checkjoin($number_id, $for_id);
            if ($res == 'administrator') {
                $userid = $for_id;
                $userna = isset($for_user_name) ? $for_user_name : 'private';
                $rr = $bot->bot('getChat', ['chat_id' => $userid]);
                $invitelink = $rr->result->invite_link;
                $title = $rr->result->title;
            $joins = json_decode($settings['lock_Media'], 1);
            $joins[$userid] = ['id' => $userid, 'username' => $userna, 'link' => $invitelink,'title'=>$title];
            $db->update('settings', ['lock_Media[JSON]' => $joins], ['id' => 1]);
            $db->update('users', ['step' => 'chMedias', 'data' => null], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('addlock5'),$back);
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock3'));
            }
        } 
    }
    elseif ($user['step'] == 'delchMedia') {
        $d = json_decode($settings['lock_Media'], 1);
        if (isset($for) and $for_type == 'channel') {
            $userid = $for_id;
            if (isset($d[$userid])) {
                unset($d[$userid]);
                $db->update('settings', ['lock_Media[JSON]' => $d], ['id' => 1]);
                $db->update('users', ['step' => 'chMedias', 'data' => null], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('dellock'), $back);
            } else {
                $bot->sm($skz,$fid, $media->tx('addlock03'));
            }
        }
    }
     elseif ($text == $key['Mediacaption']) {
            $db->update('users', ['step' => 'chMedia'], ['id' => $fid]);
            if (isset($settings['Mediacaption']) and $settings['Mediacaption'] != '[]') {
                //caption chMedia
                $arr = json_decode($settings['Mediacaption'],1);
                $bot->bot($arr['type'],['chat_id'=>$fid,'from_chat_id'=>$arr['id'],'message_id'=>$arr['msg']]);
                $bot->sm($skz,$fid,$media->tx('Mediacaption2'),json_encode($media->keys('del_baner')));
            } else {
                $bot->sm($skz,$fid,"بنر تنظیم نشده!");
                $db->update('users', ['step' => 'addMediacaption'], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('Mediacaption'), $back);
            }}
    elseif($user['step'] == 'addMediacaption'){
        $arr = ['type'=>'copyMessage','id'=>$fid,'msg'=>$message_id];
        $db->update('settings',['Mediacaption[JSON]'=>$arr],['id'=>1]);
        $bot->bot('copyMessage',['chat_id'=>$fid,'from_chat_id'=>$arr['id'],'message_id'=>$arr['msg']]);
        $db->update('users',['step'=>'chMedia'],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('Mediacaption2'),json_encode($media->keys('chMedia', 1)));
    }
 }
//========================================================
elseif ($user['step'] == 'auto_del') {
        if (is_numeric($text) and ($text == 0 or ($text >= 5 and $text <= 180))) {
            $db->update('settings', ['del_time' => $text], ['id' => 1]);
            $db->update('users', ['step' => 'settings'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('auto_delok'), $settings_panel);
        } else {
            $bot->sm($skz,$fid, $media->tx('auto_del_int'));
        }
    } elseif ($user['step'] == 'admins') {
        if ($text == $key['addadmin']) {
            $db->update('users', ['step' => 'addadmin'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addadmin1'), $back);
        } elseif ($text == $key['deladmin']) {
            $db->update('users', ['step' => 'deladmin'], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('addadmin1'), $back);
        }
    } elseif ($user['step'] == 'addadmin') {
        if (is_numeric($text)) {
            if ($db->has('users', ['id' => $text])) {
                $ar = ['file' => 0, 'settings' => 0, 'sendall' => 0, 'id' => $text];
                $db->update('users', ['step' => 'addadmin1', 'data[JSON]' => $ar], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('addadmin2', $text), json_encode($media->keys('access_admin', [$ar['id'], off($ar['file']), off($ar['settings']), off($ar['sendall'])])));
            } else {
                $bot->sm($skz,$fid, $media->tx('addadmin3'));
            }
        } else {
            $bot->sm($skz,$fid, $media->tx('addadmin4'));
        }
    } elseif ($user['step'] == 'deladmin') {
        if (is_numeric($text)) {
            $ad = json_decode($settings['admins'], 1);
            if (isset($ad[$text])) {
                unset($ad[$text]);
                $db->update('settings', ['admins[JSON]' => $ad], ['id' => 1]);
                $db->update('users', ['step' => 'settings'], ['id' => $fid]);
                $bot->sm($skz,$fid, $media->tx('deladminok'), $settings_panel);
            } else {
                $bot->sm($skz,$fid, $media->tx('addadmin3'));
            }
        } else {
            $bot->sm($skz,$fid, $media->tx('addadmin4'));
        }
    } elseif ($user['step'] == 'texts') {
        if (in_array($text, $key['text'])) {
            $str = str_replace(
                [$key['text']['start'], $key['text']['join'], $key['text']['not_found'], $key['text']['del']],
                ['start', 'join', 'not_found', 'del'],
                $text
            );
            $d = json_decode($settings['texts'], 1)[$str];
            $db->update('users', ['step' => 'texts2', 'data' => $str], ['id' => $fid]);
            $bot->sm($skz,$fid, $media->tx('edit_text2', $d), $back);
        } else {
            $bot->sm($skz,$fid, $media->tx('default'));
        }
    } elseif ($user['step'] == 'texts2') {
        $d = json_decode($settings['texts'], 1);
        if ($text == '/default') {
            $d[$user['data']] = $media->tx('default_' . $user['data']);
        } else {
            $d[$user['data']] = $text;
        }
        $db->update('settings', ['texts[JSON]' => $d], ['id' => 1]);
        $db->update('users', ['step' => 'texts', 'data' => null], ['id' => $fid]);
        $bot->sm($skz,$fid, $media->tx('edit_text3'));
        $bot->sm($skz,$fid, $media->tx('edit_text'), json_encode($media->keys('texts')));
    }elseif($user['step'] == 'addads'){

        $arr = ['type'=>'forwardmessage','bef'=>'af','id'=>$fid,'msg'=>$message_id];
        $db->update('settings',['ads[JSON]'=>$arr],['id'=>1]);
        $bot->bot('forwardmessage',['chat_id'=>$fid,'from_chat_id'=>$arr['id'],'message_id'=>$arr['msg']]);
        $db->update('users',['step'=>'ads'],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('ads2',[$arr['type'],$arr['bef']]),json_encode($media->keys('ads_panel')));
    }elseif($user['step'] == 'ads'){
        $d = json_decode($settings['ads'],1);
        if($text == $key['typeads']){
            // for copy
            $d['type'] = ($d['type'] == 'forwardmessage') ? 'copyMessage' : 'forwardmessage';
            $db->update('settings',['ads[JSON]'=>$d],['id'=>1]);
            $bot->sm($skz,$fid,$media->tx('ads3',[$d['type'],$d['bef']]),json_encode($media->keys('ads_panel')));
        }elseif($text == $key['timeads']){
            // bef af
            $d['bef'] = ($d['bef'] == 'bef') ? 'af' : 'bef';
            $db->update('settings',['ads[JSON]'=>$d],['id'=>1]);
            $bot->sm($skz,$fid,$media->tx('ads3',[$d['type'],$d['bef']]),json_encode($media->keys('ads_panel')));
        }elseif($text == $key['delads']){
            $db->update('settings',['ads'=>null],['id'=>1]);
            $db->update('users',['step'=>'settings'],['id'=>$fid]);
            $bot->sm($skz,$fid,$media->tx('del_ads'),$settings_panel);
        }
    }
    elseif($text == $key['upload_taki']){
        $db->update('users',['step'=>'upload_taki','data[JSON]'=>['number'=>0]],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('grouptaki'),$back);
    }elseif($user['step'] == 'upload_taki'){
       if(isset($message->photo) or isset($message->video) or isset($message->audio) or isset($message->voice) or isset($message->document) or isset($message->sticker)){
        if($access['file']){
        $types = ['photo','video' , 'audio', 'voice', 'document','sticker'];
                foreach ($types as $i) {
                    if (isset($update->message->$i)) {
                        $type = $update->message->$i;
                        @$caption = $update->message->caption;
                        if ($i == 'photo') {
                            $file_id = $type[count($type) - 1]->file_id;
                        } else {
                            $file_id = $type->file_id;
                        }
                        break;
                    }
                }
                $send = str_replace($types, [ 'sendphoto','sendvideo', 'sendaudio', 'sendvoice', 'senddocument', 'sendsticker'], $i);
                $ar = ['type'=>$send,'file'=>$i,'file_id'=>$file_id,'caption'=>$caption];
                while(true){
                    $code = random_code(8);
                    if(!$db->has('files',['code'=>$code])){
                        break;
                    }
                }
                $db->insert('files',['code'=>$code,'type'=>'single','data[JSON]'=>$ar,'admin'=>$fid,'date'=>time()]);
                //$bot->bot($send, ['chat_id' => $fid, $i => $file_id, 'caption' => $caption]);
                $bot->sm($skz,$fid,$media->tx('link',[$idbot,$code]),null,$message_id);
        }else{
        $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
    }}else{
            $bot->sm($skz,$fid,$media->tx('group3'));
        }}
##########################################################################
elseif($text == $key['upload_group']){
        $db->update('users',['step'=>'upload_group','data[JSON]'=>['number'=>0]],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('group1'),$back);
    }elseif($user['step'] == 'upload_group'){
        if($text == $key['end_upload_group']){
            $db->update('users',['step'=>'upload_group1'],['id'=>$fid]);
            $bot->sm($skz,$fid,$media->tx('group5'),json_encode($media->keys('caption')));
    }else{
        if(isset($message->photo) or isset($message->video) or isset($message->audio) or isset($message->voice) or isset($message->document)){
        if($access['file']){
        $types = ['photo','video' , 'audio', 'voice', 'document','not'];
                foreach ($types as $i) {
                    if (isset($update->message->$i)) {
                        $type = $update->message->$i;
                        @$caption = $update->message->caption;
                        if ($i == 'photo') {
                            $file_id = $type[count($type) - 1]->file_id;
                        } else {
                            $file_id = $type->file_id;
                        }
                        break;
                    }
                }
                $type = $i;
                if($type !== 'not'){
                $ar = json_decode($user['data'],1);
                // photo video
                // audio voice
                // document
                $ar['number'] += 1;
                if($type == 'photo' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['document'])){
                    $ar['photo'][] = ['type'=>'photo','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'video' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['document'])){
                    $ar['video'][] = ['type'=>'video','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'audio' and !isset($ar['photo']) and !isset($ar['video']) and !isset($ar['document'])){
                    $ar['audio'][] = ['type'=>'audio','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'voice' and !isset($ar['photo']) and !isset($ar['video']) and !isset($ar['document'])){
                    $ar['voice'][] = ['type'=>'voice','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'document' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['video']) and !isset($ar['photo'])){
                    $ar['document'][] = ['type'=>'document','file'=>$type,'file_id'=>$file_id];
                }else{
                    $bot->sm($skz,$fid,$media->tx('group4'));
                    exit;
                }
                $db->update('users',['data[JSON]'=>$ar],['id'=>$fid]);
                $bot->sm($skz,$fid,$media->tx('group2',$ar['number']),json_encode($media->keys('end_upload_group')),$message_id);
            }else{
                $bot->sm($skz,$fid,$media->tx('group3'));
            }
        }else{
            
            $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
        }
        }else{
            $bot->sm($skz,$fid,$media->tx('group3'));
        }
    }
}elseif($user['step'] == 'upload_group1'){
    
        $li = json_decode($user['data'],1);
        unset($li['number']);
        $i =0;
        foreach ($li as $file => $val)
        {
            foreach($val as $row){
                if(!$i and $text !== $key['no_caption']){
                $MediaGroup[] = [
                'type' => $file,
                'media' => $row['file_id'],
                'caption' => $text,
                ];
                $i++;
                }else{
                  $MediaGroup[] = [
                'type' => $file,
                'media' => $row['file_id'],
                ];     
                }
                
            }
        }
        while(true){
            $code = random_code(8);
            if(!$db->has('files',['code'=>$code])){
                break;
            }
        }
        $db->insert('files',['code'=>$code,'type'=>'group','data[JSON]'=>$MediaGroup,'admin'=>$fid,'date'=>time()]);
        $db->update('users',['step'=>'none','data'=>null],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('link',[$idbot,$code]),$home,$message_id);
}
######################################################################
elseif($text == $key['upload_coin']){
        $db->update('users',['step'=>'upload_coin','data[JSON]'=>['number'=>0]],['id'=>$fid]);
        $bot->sm($skz,$fid,$media->tx('groupcoin'),$back);
    }elseif($user['step'] == 'upload_coin'){
        if($text == $key['end_upload_group']){
            $db->update('users',['step'=>'upload_coin1'],['id'=>$fid]);
            $bot->sm($skz,$fid,$media->tx('group5'),json_encode($media->keys('caption')));
    }else{
        if(isset($message->photo) or isset($message->video) or isset($message->audio) or isset($message->voice) or isset($message->document)){
        if($access['file']){
        $types = ['photo','video' , 'audio', 'voice', 'document','not'];
                foreach ($types as $i) {
                    if (isset($update->message->$i)) {
                        $type = $update->message->$i;
                        @$caption = $update->message->caption;
                        if ($i == 'photo') {
                            $file_id = $type[count($type) - 1]->file_id;
                        } else {
                            $file_id = $type->file_id;
                        }
                        break;
                    }
                }
                $type = $i;
                if($type !== 'not'){
                $ar = json_decode($user['data'],1);
                // photo video
                // audio voice
                // document
                $ar['number'] += 1;
                if($type == 'photo' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['document'])){
                    $ar['photo'][] = ['type'=>'photo','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'video' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['document'])){
                    $ar['video'][] = ['type'=>'video','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'audio' and !isset($ar['photo']) and !isset($ar['video']) and !isset($ar['document'])){
                    $ar['audio'][] = ['type'=>'audio','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'voice' and !isset($ar['photo']) and !isset($ar['video']) and !isset($ar['document'])){
                    $ar['voice'][] = ['type'=>'voice','file'=>$type,'file_id'=>$file_id];
                }elseif($type == 'document' and !isset($ar['audio']) and !isset($ar['voice']) and !isset($ar['video']) and !isset($ar['photo'])){
                    $ar['document'][] = ['type'=>'document','file'=>$type,'file_id'=>$file_id];
                }else{
                    $bot->sm($skz,$fid,$media->tx('group4'));
                    exit;
                }
                $db->update('users',['data[JSON]'=>$ar],['id'=>$fid]);
                $bot->sm($skz,$fid,$media->tx('group2',$ar['number']),json_encode($media->keys('end_upload_group')),$message_id);
            }else{
                $bot->sm($skz,$fid,$media->tx('group3'));
            }
        }else{
            
            $bot->sm($skz,$fid,"👤 ادمین گرامی شما دسترسی به این بخش از ربات ندارید.");
        }
        }else{
            $bot->sm($skz,$fid,$media->tx('group3'));
        }
    }
}
    /////////////////////////////////////////////////////////
elseif($user['step'] == 'upload_coin1'){
$li = json_decode($user['data'],1);
unset($li['number']);
$i =0;
foreach ($li as $file => $val){
foreach($val as $row){
if(!$i and $text !== $key['no_caption']){
$MediaGroup[] = ['type' => $file,'media' => $row['file_id'],'caption' => $text];
$i++;
}else{
$MediaGroup[] = ['type' => $file,'media' => $row['file_id']];     
}}}

$db->update('users',['step'=>'setcoinfile','data[JSON]'=>$MediaGroup],['id'=>$fid]);
$bot->sm($skz,$fid,$media->tx('setcoinfile'),$back,$message_id);
    /////////////////////////////////////////////////////////
}elseif($user['step'] == 'setcoinfile'){
while(true){
$code = random_code(8);
if(!$db->has('files',['code'=>$code])){
break;}}
$li = json_decode($user['data'],1);
unset($li['number']);
$db->insert('files',['code'=>$code,'type'=>'coin','data[JSON]'=>$li,'admin'=>$fid,'date'=>"$text"]);
$db->update('users',['step'=>'none','data'=>null],['id'=>$fid]);
$bot->sm($skz,$fid,"0.
$li",$message_id);
$bot->sm($skz,$fid,$media->tx('linkcoin',[$idbot,$code,$text]),$home,$message_id);
}
    /////////////////////////////////////////////////////////
elseif($text == $key['panelupd']){
$db->update('users', ['step' => 'panelupl'], ['id' => $fid]);
$bot->sm($skz,$fid,$media->tx('panelupdm'),json_encode($media->keys('panelupds')));}
  /////////////////////////////////////////////////////////
elseif($text == $key['powerbot']){
$keyb[] = [['text'=>"👇🏻وضعیت ربات👇🏻",'callback_data'=>"null"],['text'=>"👇🏻بخش ربات👇🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt0']}",'callback_data'=>"power:txt0"],['text'=>"🤖 ربات 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt1']}",'callback_data'=>"power:txt1"],['text'=>"🤖 آپلود توسط کاربران 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt2']}",'callback_data'=>"power:txt2"],['text'=>"🤖 قفل ربات 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt3']}",'callback_data'=>"power:txt3"],['text'=>"🤖 قفل اختیاری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt4']}",'callback_data'=>"power:txt4"],['text'=>"🤖 قفل کانال 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt5']}",'callback_data'=>"power:txt5"],['text'=>"🤖 دسترسی ادمین ها 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt6']}",'callback_data'=>"power:txt6"],['text'=>"🤖 پین همگانی 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt7']}",'callback_data'=>"power:txt7"],['text'=>"🤖 حذف خودکار 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt8']}",'callback_data'=>"power:txt8"],['text'=>"🤖 محافظت از محتوا 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt9']}",'callback_data'=>"power:txt9"],['text'=>"🤖 محافظت از همگانی 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt10']}",'callback_data'=>"power:txt10"],['text'=>"🤖 سین زماندار 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt11']}",'callback_data'=>"power:txt11"],['text'=>"🤖 جوین اجباری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt12']}",'callback_data'=>"power:txt12"],['text'=>"🤖 آنتی اسپم 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt13']}",'callback_data'=>"power:txt13"],['text'=>"🤖 لایک و دیسلایک 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt14']}",'callback_data'=>"power:txt14"],['text'=>"🤖 کپشن پیشفرض 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt15']}",'callback_data'=>"power:txt15"],['text'=>"🤖 نمایش دانلود 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt16']}",'callback_data'=>"power:txt16"],['text'=>"🤖 تبلیغات 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt17']}",'callback_data'=>"power:txt17"],['text'=>"🤖 گزارش کار ادمین 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt21']}",'callback_data'=>"power:txt21"],['text'=>"🔰 جوین اجباری 👈🏻",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt22']}",'callback_data'=>"power:txt22"],['text'=>"🔰 مکان تبلیغ 👈🏻",'callback_data'=>"null"]];
//$keyb[] = [['text'=>"{$power['txt23']}",'callback_data'=>"power:txt23"],['text'=>"🔰 نوع تبلیغ 👈🏻",'callback_data'=>"null"]];
/*$keyb[] = [['text'=>"{$power['txt24']}",'callback_data'=>"power:txt24"],['text'=>"",'callback_data'=>"null"]];
$keyb[] = [['text'=>"{$power['txt25']}",'callback_data'=>"power:txt25"],['text'=>"",'callback_data'=>"null"]];*/

//$keyb[] = [['text'=>"",'callback_data'=>"null"],['text'=>"",'callback_data'=>"null"]];
$tabadol = json_encode(['inline_keyboard'=>$keyb,'resize_keyboard'=>true]);
$bot->sm($skz,$fid,$media->tx('powerbot'),$tabadol);}
///////////////////////////////////////////////////////////////////////
elseif ($text == $key['addsade']) {
$db->update('users', ['step' => 'joinsade'], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('sendlink'), $back);
} elseif ($text == $key['delsade']) {
$db->update('users', ['step' => 'delsade'], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('sendlink'), $back);
} elseif ($user['step'] == 'joinsade') {
if(preg_match('/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/',$text) ){
$joinsade = json_decode($settings['lock_optional'], 1);
$joinsade[$text] = ['id' => $text,'link' => $text];
$db->update('settings', ['lock_optional[JSON]' => $joinsade], ['id' => 1]);
$db->update('users', ['step' => 'joinsades', 'data' => null], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('addlock5'), $back);
}else{
$bot->sm($skz,$fid,"یک لینک معتبر وارد کنید");
}}
    /////////////////////////////////////////////////////////
elseif ($user['step'] == 'delsade') {
$d = json_decode($settings['lock_optional'], 1);
if (isset($d[$text])){
unset($d[$text]);
$db->update('settings', ['lock_optional[JSON]' => $d], ['id' => 1]);
$db->update('users', ['step' => 'joinsades', 'data' => null], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('addlockbot6'), $back);
} else {
$bot->sm($skz,$fid, $media->tx('default_not_sade'));
}}
    /////////////////////////////////////////////////////////
elseif ($text == $key['addrobots']) {
$db->update('users', ['step' => 'joinbot'], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('sendtoken'), $back);
} elseif ($text == $key['delrobots']) {
$db->update('users', ['step' => 'delrobots'], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('addlockbot4'), $back);
}
elseif ($user['step'] == 'joinbot') {
if(strpos ($text,'/') or strpos ($text,')') or strpos ($text,'(') or strpos ($text,'}') or strpos ($text,'{') or strpos ($text,'}') or strpos ($text,'"') or strpos ($text,'>') or strpos($text,'<') or (strlen($text) > 50) or !preg_match('|(?<token>[0-9]+\:[a-zA-Z0-9\-\_]+)|ius', $text, $matches)){
$bot->sm($skz,$fid, $media->tx('addlockbot1'));exit();}
$tokens = $matches['token'];
$result = json_decode(file_get_contents('https://api.telegram.org/bot' . $tokens . '/getMe'), true);
if($result['ok'] == true){
$joinbot = json_decode($settings['lock_robot'], 1);
$id = strtolower($result['result']['id']);
if(!isset($joinbot[$id])){
$uname = strtolower($result['result']['first_name']);
$userna = strtolower($result['result']['username']);
$link = "t.me/$userna";
$joinbot[$id] = ['id' => $id, 'username' => $userna, 'token' => $tokens,'link' => $link,'name'=>$uname];
$db->update('settings', ['lock_robot[JSON]' => $joinbot], ['id' => 1]);
$db->update('users', ['step' => 'joinbotss', 'data' => null], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('addlock5'), $back);
} else {
$bot->sm($skz,$fid, $media->tx('addlockbot5'));
}} else {
$bot->sm($skz,$fid, $media->tx('addlockbot1'));}}
    /////////////////////////////////////////////////////////
elseif ($user['step'] == 'delrobots') {
$d = json_decode($settings['lock_robot'], 1);
if (isset($forid) and isset($d[$forid])){
unset($d[$forid]);
$db->update('settings', ['lock_robot[JSON]' => $d], ['id' => 1]);
$db->update('users', ['step' => 'joinbotss', 'data' => null], ['id' => $fid]);
$bot->sm($skz,$fid, $media->tx('addlockbot3'), $back);
}else{
$bot->sm($skz,$fid, $media->tx('addlockbot2'), $back);}}
    /////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////
}
