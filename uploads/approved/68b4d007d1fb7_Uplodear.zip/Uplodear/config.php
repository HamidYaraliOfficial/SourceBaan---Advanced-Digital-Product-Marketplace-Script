<?php

error_reporting(E_ALL);

date_default_timezone_set("Asia/Tehran");



// ====== تنظیمات اصلی ربات ======

define('API_KEY', '');//توکن

define('ROOT', API_KEY);

define('SAFE', API_KEY);



// ====== لیست ادمین‌ها ======

$admin = [];//ادمین ها

$devs = [];//عددی مالک



// ====== آدرس دامنه ======

$domain = 'https://Domains/Uplodear/bots/';//دامنه خودتون



// ====== تنظیمات دیتابیس اول (رباتساز) ======

$server = 'localhost';

$username = '';//یوزر دیتا اول

$password = '';//پس دیتا اول

$db = '';//اسم دیتا اول



try {

    $connect = new mysqli($server, $username, $password, $db);

    $connect->set_charset('utf8mb4');

    if ($connect->connect_error) {

        throw new Exception("اتصال به دیتابیس اول ناموفق: " . $connect->connect_error);

    }

} catch (Exception $e) {

    die("خطا در اتصال به دیتابیس اول: " . $e->getMessage());

}



// ====== تنظیمات دیتابیس دوم (ربات‌ها) ======

$server2 = 'localhost';

$username2 = '';//یوزر دیتا دوم

$password2 = '';//پس دیتا دوم

$db2 = '';//اسم دیتا اول



try {

    $database = new mysqli($server2, $username2, $password2, $db2);

    $database->set_charset('utf8mb4');

    if ($database->connect_error) {

        throw new Exception("اتصال به دیتابیس دوم ناموفق: " . $database->connect_error);

    }

} catch (Exception $e) {

    die("خطا در اتصال به دیتابیس دوم: " . $e->getMessage());

}

?>