<?php
//---------------------------------------------
// Telegram id : @SimpSonSelf
//---------------------------------------------
error_reporting(E_ALL);
http_response_code(200);
if(is_callable('litespeed_finish_request')){
litespeed_finish_request();
}elseif(is_callable('fastcgi_finish_request')){
fastcgi_finish_request();
}
include("jdf.php");
include("config.php");
//===[امنیت دامنه]===//
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], // literally 149.154.160.0/20
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    // literally 91.108.4.0/22
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok = true;
foreach($telegram_ip_ranges as $telegram_ip_range){
if($ok){
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec){
$ok = false;
}
}
}
if($ok){
exit(header("location: https://Google.com"));
}
//===[فانکشن های لازم]===//
function bot($method,$datas = [],$token = API_KEY){
$url = "https://api.telegram.org/bot".$token."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
function Security($text){
$filters = array('root','api','key','token','update','getme','include','foreach','input','exec','json','curl','php','zip','function','#',"'",'$','"','(',')','[',']',';');
foreach($filters as $filter){
if(stripos($text,$filter) !== false){
return $filter;
}
}
return false;
}
function Number($string) {
if(isset($string)){
$persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
$arabic = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
$ChangePersian = str_replace($persian,range(0,9),$string);
$ChangeArabic = str_replace($arabic,range(0,9),$ChangePersian);
return (is_numeric($ChangeArabic) and $ChangeArabic != 0) ? abs($ChangeArabic) : $ChangeArabic;
}
}
function JoinChek($ch,$user){
foreach($ch as $links){
$chekjoin = bot('getChatMember',[
'chat_id'=>$links,
'user_id'=>$user
])->result->status ?? null;
if(in_array($chekjoin,['left','kicked','restricted'])){
return $links;
}
}
return false;
}
function Save($link,$data){
$outjson = json_encode($data,true);
file_put_contents($link,$outjson);
}
function Font($text){
$font = [["𝟎","𝟏","𝟐","𝟑","𝟒","𝟓","𝟔","𝟕","𝟖","𝟗"]];
$echo = str_replace(range(0,9),$font[array_rand($font)],$text);
return $echo;
}
function CreateUrl($path){
$realpath = realpath($path);
$urlpath = str_replace($_SERVER['DOCUMENT_ROOT'],(string) null,$realpath);
return $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$urlpath;
}
function Htmlentitie($string){
if(isset($string)){
return str_replace(['&','<','>'],['&amp;','&lt;','&gt;'],$string);
}
}
//-----------------------------------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$chat_id = $update->message->chat->id;
$text = Number($update->message->text ?? null);
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$tc = $update->message->chat->type;
$first_name = $update->message->from->first_name;
$last_name = $update->message->from->last_name ?? '𝑛𝑜𝑛𝑒';
$user_name = $update->message->from->username ?? '𝑛𝑜𝑛𝑒';
}
elseif(isset($update->callback_query)){
$chat_id = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$user_id = $update->callback_query->id;
$message_id = $update->callback_query->message->message_id;
$from_id = $update->callback_query->from->id;
$first_name = $update->callback_query->from->first_name;
$last_name = $update->callback_query->from->last_name ?? '𝑛𝑜𝑛𝑒';
$user_name = $update->callback_query->from->username ?? '𝑛𝑜𝑛𝑒';
}
elseif(isset($update->inline_query)){
$inline = $update->inline_query;
$user_id = $update->inline_query->id;
$query = $update->inline_query->query;
$from_id = $update->inline_query->from->id;
$first_name = $update->inline_query->from->first_name;
$last_name = $update->inline_query->from->last_name ?? '𝑛𝑜𝑛𝑒';
$user_name = $update->inline_query->from->username ?? '𝑛𝑜𝑛𝑒';
}
elseif(isset($update->chat_member)){
$status = $update->chat_member->new_chat_member->status;
$from_id = $update->chat_member->new_chat_member->user->id;
$channel_id = $update->chat_member->chat->username;
}else{
die("The received update isn't defined !");
}
//===[ربات]===//
$get = bot('getMe');
$botid = $get->result->id;
$botuser = $get->result->username;
$botname = $get->result->first_name;
//===[امنیت]===//
if(isset($text) and (isset($update->message->forward_from) ? ($update->message->forward_from->id != 93372553) : true) and Security($text)) exit();
//===[اطلاعات]===//
$settings = file_exists("settings.json") ? json_decode(file_get_contents("settings.json"),true) : [];
$date = jdate("Y/n/j");
$time = jdate("H:i:s");
$timer = time();
$createbot = ['📤 آپلودر'=>'uploader'];

//-----------------------------------------------------------------------------------------------
$from_id_safe = $connect->real_escape_string($from_id);
$datas = $connect->query("SELECT * FROM `user` WHERE id = '$from_id_safe' LIMIT 1")->fetch_assoc() ?? ['id'=>false,'step'=>'none','warn'=>0,'time'=>$time,'date'=>$date];
$step = $datas['step'];
$warn = $datas['warn'];
$timej = $datas['time'];
$datej = str_replace('-','/',$datas['date']);
//-----------------------------------------------------------------------------------------------
if(($step == "block" or $warn >= 3) and !in_array($from_id,$admin)) exit();
//-----------------------------------------------------------------------------------------------
/*
CREATE TABLE IF NOT EXISTS `user` (
	`id` BIGINT PRIMARY KEY,
	`warn` INT(10) DEFAULT '0',
	`step` TEXT DEFAULT NULL,
	`time` TIME DEFAULT NULL,
	`date` DATE DEFAULT NULL
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `channel` (
	`id` TEXT DEFAULT NULL,
	`admin` BIGINT DEFAULT '0'
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `bot` (
	`id` BIGINT PRIMARY KEY,
	`admin` BIGINT DEFAULT '0',
	`token` TEXT DEFAULT NULL,
	`type` TEXT DEFAULT NULL,
	`created` BIGINT DEFAULT '0',
	`minimum` BIGINT DEFAULT '1000',
	`safe` BOOLEAN DEFAULT '0',
	`deletetime` BIGINT DEFAULT '0',
	`antispamtime` BIGINT DEFAULT '0',
	`channel` LONGTEXT DEFAULT NULL,
	`channelsettings` LONGTEXT DEFAULT NULL,
	`admins` LONGTEXT DEFAULT NULL,
	`starttext` LONGTEXT DEFAULT NULL,
	`helptext` LONGTEXT DEFAULT NULL,
	`supporttext` LONGTEXT DEFAULT NULL,
	`backtext` LONGTEXT DEFAULT NULL,
	`accounttext` LONGTEXT DEFAULT NULL,
	`jointext` LONGTEXT DEFAULT NULL,
	`adstext` LONGTEXT DEFAULT NULL,
	`supportid` TEXT DEFAULT NULL
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `sendall` (
	`botid` BIGINT DEFAULT '0',
	`fromid` BIGINT DEFAULT '0',
	`messageid` BIGINT DEFAULT '0',
	`edit` BIGINT DEFAULT '0',
	`count` BIGINT DEFAULT '0',
	`time` BIGINT DEFAULT '0'
	) default charset = utf8mb4;
*/
//-----------------------------------------------------------------------------------------------
$menu = json_encode(['keyboard'=>[
[['text'=>"⚙ ساخت ربات"]],
[['text'=>"♻️ آپدیت ربات"],['text'=>"🔐 حساب کاربری"]],
[['text'=>"❌ حذف ربات"]],
[['text'=>"🆘 پشتیبانی"],['text'=>"📚 راهنما"]],
],'resize_keyboard'=>true]);

$back = json_encode(['keyboard'=>[
[['text'=>"🔙 برگشت"]],
],'resize_keyboard'=>true]);

$panel = json_encode(['keyboard'=>[
[['text'=>"📊 آمار"]],
[['text'=>"⚙ تنظیمات"],['text'=>"⚡️ ربات ها"]],
[['text'=>"♻️ آپدیت ربات ها"]],
[['text'=>"➖  کسر اخطار"],['text'=>"➕ افزایش اخطار"]],
[['text'=>"📢 کانال جوین اجباری"]],
[['text'=>"📨 پیام همگانی"],['text'=>"💭 فوروارد همگانی"]],
[['text'=>"📣 کانال های ربات ها"]],
[['text'=>"📩 پیام به کاربر"],['text'=>"🔍 اطلاعات کاربر"]],
[['text'=>"🔰 آنبلاک کردن"],['text'=>"❌ بلاک کردن"]],
[['text'=>"🔙 برگشت"]],
],'resize_keyboard'=>true]);

$backinline = json_encode(['inline_keyboard'=>[
[['text'=>"🔙 بازگشت",'callback_data'=>"back"]],
]
]);
//-----------------------------------------------------------------------------------------------
if(isset($status)){
if(in_array(mb_strtolower("@$channel_id"),$settings['channel'])){
if(in_array($status,['left','kicked','restricted'])){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ لطفاً جهت کار کردن با ربات در کانال @$channel_id عضو شوید سپس از ربات استفاده کنید
",
'parse_mode'=>'HTML'
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ عضویت شما در کانال @$channel_id با موفقیت تأیید شد
",
'parse_mode'=>'HTML'
]);
}
}
}
//-----------------------------------------------------------------------------------------------
if(isset($data)){
if(substr($data, 0, 6) === "lists-"){
$exp = explode("-",$data);
$offset = $exp[1];
$limit = $exp[2];
$key = [];
$fake = [];
$from_id_safe = $connect->real_escape_string($from_id);
$limit_safe = (int)$limit;
$offset_safe = (int)$offset;
$code = $connect->query("SELECT * FROM `bot` WHERE admin = '$from_id_safe' LIMIT $limit_safe OFFSET $offset_safe");
while($res = $code->fetch_assoc()){
$get = bot('getMe',[],$res['token']);
if($get->ok){
$botid = $get->result->id;
$botuser = $get->result->username;
$botname = $get->result->first_name;
$key[] = [['text'=>$botname,'callback_data'=>"fake"],['text'=>"@$botuser",'callback_data'=>"fake"]];
}else{
$fake[] = [['text'=>$res['id'],'callback_data'=>"fake"],['text'=>"❌",'callback_data'=>"delete-{$res['id']}"]];
}
}
if(!empty($fake)) array_unshift($fake,[['text'=>"⚠️ ربات های منقضی شده",'callback_data'=>"fake"]]);
$keyboard = [...$key,...$fake];
if($offset == 0){
$keyboard[] = [['text'=>"➡️ بعدی",'callback_data'=>"lists-".($offset + 5)."-".($limit)]];
}elseif(($offset + $limit) >= $connect->query("SELECT * FROM `bot` WHERE admin = '$from_id_safe'")->num_rows){
$keyboard[] = [['text'=>"قبلی ⬅️",'callback_data'=>"lists-".($offset - 5)."-".($limit)]];
}else{
$keyboard[] = [['text'=>"قبلی ⬅️",'callback_data'=>"lists-".($offset - 5)."-".($limit)],['text'=>"➡️ بعدی",'callback_data'=>"lists-".($offset + 5)."-".($limit)]];
}
bot('editMessageReplyMarkup',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}
elseif(substr($data, 0, 7) === "delete-"){
$botid = explode("-",$data)[1];
$botid_safe = $connect->real_escape_string($botid);
if($database->query("SHOW TABLES LIKE '%\_$botid_safe'")->num_rows){
$botid_safe = $connect->real_escape_string($botid);
$info = $connect->query("SELECT * FROM `bot` WHERE id = '$botid_safe' LIMIT 1")->fetch_assoc();
if(isset($info['admin']) and $info['admin'] == $from_id){
$connect->query("DELETE FROM `bot` WHERE id = '$botid_safe'");
$database->query("DROP TABLE `user_$botid_safe` , `upload_$botid_safe` , `like_$botid_safe` , `dislike_$botid_safe` , `view_$botid_safe`");
bot('deleteWebhook',['drop_pending_updates'=>true],$info['token']);
bot('editMessageText',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'text'=>"
🗑 ربات شما با موفقیت حذف شد
",
'parse_mode'=>'HTML'
]);
}else{
bot('editMessageText',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'text'=>"
⚠️ این ربات دیگر مطلق به شما نیست
",
'parse_mode'=>'HTML'
]);
}
}else{
bot('editMessageText',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'text'=>"
🌟 این ربات در سرور موجود نیست
",
'parse_mode'=>'HTML'
]);
}
}
elseif($data == "support"){
$data_safe = $connect->real_escape_string($data);
$from_id_safe = $connect->real_escape_string($from_id);
$connect->query("UPDATE `user` SET step = '$data_safe' WHERE id = '$from_id_safe' LIMIT 1");
bot('answercallbackquery',[
'callback_query_id'=>$user_id,
'text'=>"🎈 صبر کنید",
'show_alert'=>false
]);
bot('editMessageText',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'text'=>"
🆘 پیام , انتقاد , پیشنهادات خود را برای ما ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$backinline
]);
}
elseif($data == "back"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('deleteMessage',[
'chat_id'=>$from_id,
'message_id'=>$message_id
]);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔙 به منوی اصلی برگشتید",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
exit();
}
elseif($data == "fake"){
bot('answercallbackquery',[
'callback_query_id'=>$user_id,
'text'=>"💤 این دکمه فقط جهت نمایش اطلاعات است",
'show_alert'=>false
]);
}
}
//-----------------------------------------------------------------------------------------------
if(isset($data) and in_array($from_id,$admin)){
if($data == "addjoin"){
$from_id_safe = $connect->real_escape_string($from_id);
$connect->query("UPDATE `user` SET step = 'SetJoin' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
📢 آیدی کانال جدید را با @ ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif(substr($data, 0, 8) === "deljoin-"){
$links = explode("-",$data)[1];
$search = array_search($links,$settings['channel']);
unset($settings['channel'][$search]);
Save("settings.json",$settings);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🗑 با موفقیت کانال $links حذف شد
",
'parse_mode'=>'HTML'
]);
}
elseif($data == "addch"){
$from_id_safe = $connect->real_escape_string($from_id);
$connect->query("UPDATE `user` SET step = 'SetChannel' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
📢 آیدی کانال جدید را با @ ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif(substr($data, 0, 6) === "delch-"){
$links = explode("-",$data)[1];
$links_safe = $connect->real_escape_string($links);
$connect->query("DELETE FROM `channel` WHERE id = '$links_safe'");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🗑 با موفقیت کانال $links حذف شد
",
'parse_mode'=>'HTML'
]);
}
elseif(substr($data, 0, 6) === "onoff-"){
$type = explode("-",$data)[1];
$bot = $connect->query("SELECT * FROM `bot`")->fetch_assoc();
if($bot[$type]){
$connect->query("ALTER TABLE `bot` MODIFY $type BOOLEAN DEFAULT '0'");
$connect->query("UPDATE `bot` SET $type = '0'");
bot('answercallbackquery',[
'callback_query_id'=>$user_id,
'text'=>"❌ با موفقیت خاموش شد",
'show_alert'=>true
]);
}else{
$connect->query("ALTER TABLE `bot` MODIFY $type BOOLEAN DEFAULT '1'");
$connect->query("UPDATE `bot` SET $type = '1'");
bot('answercallbackquery',[
'callback_query_id'=>$user_id,
'text'=>"✅ با موفقیت روشن شد",
'show_alert'=>true
]);
}
}
elseif(substr($data, 0, 4) === "set-"){
$data_safe = $connect->real_escape_string($data);
$from_id_safe = $connect->real_escape_string($from_id);
$connect->query("UPDATE `user` SET step = '$data_safe' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🌟 مقدار جدید را وارد کنید تا در تنظیمات ربات ها اعمال شود",
'parse_mode'=>'HTML',
'reply_markup'=>$backinline
]);
}
elseif(substr($data, 0, 5) === "bots-"){
$exp = explode("-",$data);
$offset = $exp[1];
$limit = $exp[2];
$keyboard = [[['text'=>"📄 نام ربات",'callback_data'=>"fake"],['text'=>"💫 یوزرنیم ربات",'callback_data'=>"fake"],['text'=>"📈 آمار ربات",'callback_data'=>"fake"],['text'=>"❄️ ادمین ربات",'callback_data'=>"fake"]]];
$code = $connect->query("SELECT * FROM `bot` LIMIT $limit OFFSET $offset");
while($res = $code->fetch_assoc()){
$get = bot('getMe',[],$res['token']);
if($get->ok){
$botid = $get->result->id;
$botname = $get->result->first_name;
$keyboard[] = [['text'=>$botname,'callback_data'=>"fake"],['text'=>"@".($get->result->username),'callback_data'=>"fake"],['text'=>($database->query("SELECT id FROM `user_$botid`")->num_rows),'url'=>"https://t.me/".$botuser."?start=Status_".$botid],['text'=>(bot('getChatMember',['chat_id'=>$res['admin'],'user_id'=>$res['admin']])->result->user->first_name ?? $res['admin']),'callback_data'=>"info-{$res['admin']}"]];
}else{
$keyboard[] = [['text'=>$res['id'],'callback_data'=>"fake"],['text'=>"⚠️",'callback_data'=>"fake"],['text'=>($database->query("SELECT id FROM `user_{$res['id']}`")->num_rows),'url'=>"https://t.me/".$botuser."?start=Status_".$res['id']],['text'=>(bot('getChatMember',['chat_id'=>$res['admin'],'user_id'=>$res['admin']])->result->user->first_name ?? $res['admin']),'callback_data'=>"info-{$res['admin']}"]];
}
}
if($offset == 0){
$keyboard[] = [['text'=>"➡️ بعدی",'callback_data'=>"bots-".($offset + 5)."-".($limit)]];
}elseif(($offset + $limit) >= $connect->query("SELECT * FROM `bot`")->num_rows){
$keyboard[] = [['text'=>"قبلی ⬅️",'callback_data'=>"bots-".($offset - 5)."-".($limit)]];
}else{
$keyboard[] = [['text'=>"قبلی ⬅️",'callback_data'=>"bots-".($offset - 5)."-".($limit)],['text'=>"➡️ بعدی",'callback_data'=>"bots-".($offset + 5)."-".($limit)]];
}
bot('editMessageReplyMarkup',[
'chat_id'=>$from_id,
'message_id'=>$message_id,
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}
elseif(substr($data, 0, 5) === "info-"){
$id = explode("-",$data)[1];
$id_safe = $connect->real_escape_string($id);
if($connect->query("SELECT * FROM `user` WHERE id = '$id_safe' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$nameuser = bot('getChatMember',['chat_id'=>$id,'user_id'=>$id])->result->user->first_name;
$datas = $connect->query("SELECT * FROM `user` WHERE id = '$id_safe' LIMIT 1")->fetch_assoc();
$warn = $datas['warn'];
$timej = $datas['time'];
$datej = str_replace('-','/',$datas['date']);
$botcount = $connect->query("SELECT * FROM `bot` WHERE admin = '$id_safe'")->num_rows;
$edit = bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
👤 شناسه کاربر : <code>$id</code>

📑 نام کاربر : <a href ='tg://openmessage?user_id=$id'>".Htmlentitie($nameuser)."</a>

⚙ تعداد ربات ها : $botcount

⚠️ تعداد اخطار ها : $warn

📆 تاریخ عضویت : $datej

⏰ ساعت عضویت : $timej
",
'parse_mode'=>'HTML'
])->result->message_id;
$keyboard = [];
$code = $connect->query("SELECT * FROM `bot` WHERE admin = '$id_safe'");
$res = $code->fetch_all(MYSQLI_ASSOC);
$key = array_map(fn($data) => ['text'=>(bot('getMe',[],$data['token'])->result->first_name ?? $data['id']),'url'=>"https://t.me/$botuser?start=Status_".$data['id']],$res);
$keyboard = array_chunk($key,2);
bot('editMessageReplyMarkup',[
'chat_id'=>$from_id,
'message_id'=>$edit,
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}else{
bot('answercallbackquery',[
'callback_query_id'=>$user_id,
'text'=>"❌ کاربر $id در ربات نیست",
'show_alert'=>false
]);
}
}
}
//-----------------------------------------------------------------------------------------------
if(isset($tc) and $tc == 'private'){
if($datas['id'] == false){
$from_id_safe = $connect->real_escape_string($from_id);
$time_safe = $connect->real_escape_string($time);
$date_safe = $connect->real_escape_string($date);
$connect->query("INSERT INTO `user` (`id` , `warn` , `step` , `time` , `date`) VALUES ('$from_id_safe','0','none','$time_safe','$date_safe')");
}
if(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])$/',$text)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🌹 سلام به ربات $botname خوش آمدید !
",
'reply_markup'=>$menu
]);
}
elseif(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])\sStatus_(\d+)$/',$text,$match)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$botid = $match[2];
if($database->query("SHOW TABLES LIKE '%\_$botid'")->num_rows){
$countfile = $database->query("SELECT id FROM `upload_$botid`")->num_rows;
$countmember = $database->query("SELECT id FROM `user_$botid`")->num_rows;
$countonlines = $database->query("SELECT * FROM `user_$botid` WHERE spam != '0' AND step != 'block'")->num_rows;
$counttoday = $database->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 day"))->num_rows;
$countlastweek = $database->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 week"))->num_rows;
$countlastmonth = $database->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 month"))->num_rows;
$countblock = $database->query("SELECT * FROM `user_$botid` WHERE step = 'block'")->num_rows;
$onlines = $countmember ? '% '.floor(($countonlines / $countmember) * 100) : '% 0';
$onlinestoday = $countmember ? '% '.floor(($counttoday / $countmember) * 100) : '% 0';
$onlineslastweek = $countmember ? '% '.floor(($countlastweek / $countmember) * 100) : '% 0';
$onlineslastmonth = $countmember ? '% '.floor(($countlastmonth / $countmember) * 100) : '% 0';
$blockpercent = $countmember ? '% '.floor(($countblock / $countmember) * 100) : '% 0';
$info = $connect->query("SELECT * FROM `bot` WHERE id = '$botid' LIMIT 1")->fetch_assoc();
$get = bot('getMe',[],$info['token']);
if($get->ok){
$boturl = "<a href ='https://t.me/".($get->result->username)."'>".Htmlentitie($get->result->first_name)."</a>";
}else{
$boturl = "<a href ='tg://openmessage?user_id=$botid'>ربات</a>";
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🔎 تصدیق آمار ( $boturl ) :

📂 تعداد فایل های آپلود شده : $countfile

📉 تعداد کل کاربران ربات : $countmember

❌ تعداد کاربران بلاک شده : $countblock | $blockpercent

🌟 تعداد کاربران فعال ربات : $countonlines | $onlines

🌕 تعداد کاربران فعال امروز : $counttoday | $onlinestoday

🌖 تعداد کاربران فعال هفته پیش : $countlastweek | $onlineslastweek

🌓 تعداد کاربران فعال یک ماه گذشته : $countlastmonth | $onlineslastmonth

<a href ='https://t.me/$botuser?start=Status_{$botid}'>📊 تصدیق آمار مجدد</a>
",
'parse_mode'=>'HTML',
'disable_web_page_preview'=>true
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🌟 این ربات در سرور موجود نیست
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
}
elseif(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])\sSendall_(\d+)_(\d+)$/',$text,$match)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$botid = $match[2];
$messageid = $match[3];
if($database->query("SHOW TABLES LIKE '%\_$botid'")->num_rows){
if($sendall = $connect->query("SELECT * FROM `sendall` WHERE botid = '$botid' AND messageid = '$messageid' LIMIT 1")->fetch_assoc()){
$i = $sendall['count'];
$countmember = $database->query("SELECT id FROM `user_$botid`")->num_rows;
$percent = '% '.floor(($i / $countmember) * 100);
$x = $countmember - $i;
$hash = md5(time().$from_id.$botid.$messageid);
$info = $connect->query("SELECT * FROM `bot` WHERE id = '$botid' LIMIT 1")->fetch_assoc();
$get = bot('getMe',[],$info['token']);
if($get->ok){
$boturl = "<a href ='https://t.me/".($get->result->username)."'>".Htmlentitie($get->result->first_name)."</a>";
}else{
$boturl = "<a href ='tg://openmessage?user_id=$botid'>ربات</a>";
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🔎 تصدیق همگانی ( $boturl ) :

📉 تعداد کل کاربران ربات : $countmember
♻️ تعداد پیام های ارسال شده : $i
📨 تعداد پیام باقی مانده : $x
💯 درصد پیشرفت ارسال پیام : $percent

🔖 اگر پیام ارسال شده توسط ( $boturl ) با کد زیر تطابق دارد پیام همگانی تایید شده است

<tg-spoiler>$hash</tg-spoiler>

<a href ='https://t.me/$botuser?start=Sendall_{$botid}_{$messageid}'>📊 تصدیق همگانی مجدد</a>
",
'parse_mode'=>'HTML',
'disable_web_page_preview'=>true
]);
$reply = bot('forwardMessage',[
'chat_id'=>$from_id,
'from_chat_id'=>$sendall['fromid'],
'message_id'=>$sendall['messageid']
],$info['token'])->result->message_id;
$delete = bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ <tg-spoiler>$hash</tg-spoiler> ✅
",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$reply,
],$info['token'])->result->message_id;
sleep(10);
bot('deleteMessage',[
'chat_id'=>$from_id,
'message_id'=>$reply
],$info['token']);
bot('deleteMessage',[
'chat_id'=>$from_id,
'message_id'=>$delete
],$info['token']);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
☁️ پیام همگانی مورد نظر یافت نشد !
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🌟 این ربات در سرور موجود نیست
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
}
elseif(isset($settings['channel'])){
$JoinMe = JoinChek($settings['channel'],$from_id);
if($JoinMe){
$menu = json_encode(['inline_keyboard'=>[
[['text'=>"کانال اول",'url'=>"https://t.me/UplSaz7"]],
[['text'=>"✅ تایید عضویت و دانلود",'url'=>"https://t.me/UplSaz_1bot?start=TAK"]],
] 
]);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🔰 لطفاً جهت حمایت از ما و به دلیل رایگان بودن ربات در کانال های اسپانسری ما عضو شوید !

",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
exit();
}
}
if(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])\s([Tt][Aa][Kk])$/',$text)){
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ عضویت شما تایید شد
",
'reply_markup'=>$menu
]);
exit();
}
if($text == "🔙 برگشت"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔙 به منوی اصلی برگشتید",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
elseif($text == "🔐 حساب کاربری"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$key = [];
$fake = [];
$code = $connect->query("SELECT * FROM `bot` WHERE admin = '$from_id' LIMIT 5 OFFSET 0");
while($res = $code->fetch_assoc()){
$get = bot('getMe',[],$res['token']);
if($get->ok){
$botid = $get->result->id;
$botuser = $get->result->username;
$botname = $get->result->first_name;
$key[] = [['text'=>$botname,'callback_data'=>"fake"],['text'=>"@$botuser",'callback_data'=>"fake"]];
}else{
$fake[] = [['text'=>$res['id'],'callback_data'=>"fake"],['text'=>"❌",'callback_data'=>"delete-{$res['id']}"]];
}
}
if(!empty($fake)) array_unshift($fake,[['text'=>"⚠️ ربات های منقضی شده",'callback_data'=>"fake"]]);
$keyboard = [...$key,...$fake];
$botcount = $connect->query("SELECT * FROM `bot` WHERE admin = '$from_id'")->num_rows;
if($botcount > 5){
$keyboard[] = [['text'=>"➡️ بعدی",'callback_data'=>"lists-5-5"]];
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
👤 شناسه کاربری : $from_id
⚙ تعداد ربات ها : $botcount
⚠️ تعداد اخطار ها : $warn
📆 تاریخ عضویت : $datej
⏰ ساعت عضویت : $timej
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}
elseif($text == "❌ حذف ربات"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$key = [];
$fake = [];
$code = $connect->query("SELECT * FROM `bot` WHERE admin = '$from_id'");
while($res = $code->fetch_assoc()){
$get = bot('getMe',[],$res['token']);
if($get->ok){
$botid = $get->result->id;
$botname = $get->result->first_name;
$key[] = [['text'=>$botname,'callback_data'=>"delete-$botid"]];
}else{
$fake[] = [['text'=>$res['id'],'callback_data'=>"delete-{$res['id']}"]];
}
}
if(!empty($key) or !empty($fake)){
if(!empty($fake)) array_unshift($fake,[['text'=>"⚠️ ربات های منقضی شده",'callback_data'=>"fake"]]);
$keyboard = [...$key,...$fake,[['text'=>"🔙 بازگشت",'callback_data'=>"back"]]];
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❓کدام ربات را میخواهید حذف کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❄️ شما رباتی در رباتساز ما ندارید
",
'parse_mode'=>'HTML'
]);
}
}
elseif($text == "♻️ آپدیت ربات"){
$connect->query("UPDATE `user` SET step = 'update' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ توکن ربات خود را از <a href ='https://t.me/BotFather'>بات فادر</a> فوروارد کنید !
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "update" and isset($text)){
if(isset($update->message->forward_from)){
if($update->message->forward_from->id == 93372553){
if(preg_match_all('/((?:\d+)\:(?:[^\s]+))/ius',$text,$match)){
$token = end($match[1]);
$get = bot('getMe',[],$token);
if($get->ok){
$botid = $get->result->id;
$botuser = $get->result->username;
$botname = $get->result->first_name;
if($database->query("SHOW TABLES LIKE '%\_$botid'")->num_rows){
$info = $connect->query("SELECT * FROM `bot` WHERE id = '$botid' LIMIT 1")->fetch_assoc();
if(isset($info['admin']) and $info['admin'] == $from_id){
// تنظیم webhook به مسیر صحیح ربات
$url = $domain.$info['type'].'/Bot/'.$botuser.'/index.php';
bot('setWebhook',['url'=>$url,'secret_token'=>$botid,'drop_pending_updates'=>true,'allowed_updates'=>json_encode(['message','callback_query','inline_query','chat_member'])],$token);
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$connect->query("UPDATE `bot` SET token = '$token' WHERE id = '$botid' LIMIT 1");
bot('deleteMessage',[
'chat_id'=>$from_id,
'message_id'=>$message_id
]);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ ربات شما با موفقیت آپدیت شد !
",
'parse_mode'=>'HTML'
],$token);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ ربات ( <a href ='https://t.me/$botuser'>".Htmlentitie($botname)."</a> ) با موفقیت آپدیت شد !
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ شما ادمین ربات ( <a href ='https://t.me/$botuser'>".Htmlentitie($botname)."</a> ) نیستید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🌟 این ربات در سرور موجود نیست
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ توکن شما معتبر نمیباشد لطفاً توکن جدید را فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ پیامی که حاوی توکن ربات خودتان هست را فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً پیام را فقط از بات فادر فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً پیام را فقط فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "⚙ ساخت ربات"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$key = [];
foreach(array_keys($createbot) as $button){
$key[] = [['text'=>$button]];
}
$key[] = [['text'=>"🔙 برگشت"]];
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❓نوع رباتی که میخواهید بسازید را انتخاب کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['keyboard'=>$key,'resize_keyboard'=>true])
]);
}
elseif(in_array($text,array_keys($createbot))){
$connect->query("UPDATE `user` SET step = 'createbot-{$createbot[$text]}' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ توکن ربات خود را از <a href ='https://t.me/BotFather'>بات فادر</a> فوروارد کنید !
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif(substr($step, 0, 10) === "createbot-" and isset($text)){
$type = explode("-",$step)[1];
if(isset($update->message->forward_from)){
if($update->message->forward_from->id == 93372553){
if(preg_match_all('/((?:\d+)\:(?:[^\s]+))/ius',$text,$match)){
$token = end($match[1]);
$get = bot('getMe',[],$token);
if($get->ok){
$botid = $get->result->id;
$botuser = $get->result->username;
$botname = $get->result->first_name;
if($database->query("SHOW TABLES LIKE '%\_$botid'")->num_rows){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
⚠️ ربات ( <a href ='https://t.me/$botuser'>".Htmlentitie($botname)."</a> ) از قبل وجود دارد ابتدا آنرا حذف کنید سپس مجدد بسازید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");

// ایجاد دایرکتوری مخصوص ربات
$bot_directory = "bots/{$type}/Bot/{$botuser}";
if (!file_exists($bot_directory)) {
    if (!mkdir($bot_directory, 0755, true)) {
        bot('sendMessage',[
            'chat_id'=>$from_id,
            'text'=>"❌ خطا در ایجاد دایرکتوری ربات",
            'parse_mode'=>'HTML',
            'reply_markup'=>$back
        ]);
        exit();
    }
}

// کپی کردن فایل‌های اصلی ربات
$source_files = [
    "bots/{$type}/index.php",
    "bots/{$type}/config.php",
    "bots/{$type}/jdf.php"
];

foreach ($source_files as $source_file) {
    if (file_exists($source_file)) {
        $dest_file = $bot_directory . '/' . basename($source_file);
        if ($source_file === "bots/{$type}/config.php") {
            // تنظیم config.php مخصوص این ربات
            $config_content = file_get_contents($source_file);
            
            // جایگزینی اطلاعات مخصوص ربات
            $config_content = str_replace(
                ['define(\'ROOT\',\'8186089386:AAELAFb3QrQQfAYc0bMjR7ukoq9vS9CnzWA\');', 'define(\'SAFE\',\'8186089386:AAELAFb3QrQQfAYc0bMjR7ukoq9vS9CnzWA\');'],
                ["define('ROOT','{$token}');", "define('SAFE','{$token}');"],
                $config_content
            );
            
            // اضافه کردن اطلاعات ربات
            $config_content = str_replace(
                '$devs = [6150040591];',
                "\$devs = [{$from_id}];\n\n// اطلاعات ربات\ndefine('BOT_ID', {$botid});\ndefine('BOT_ADMIN', {$from_id});",
                $config_content
            );
            
            file_put_contents($dest_file, $config_content);
        } else {
            copy($source_file, $dest_file);
        }
    }
}

// کپی کردن پوشه vendor اگر وجود دارد
$vendor_source = "bots/{$type}/vendor";
$vendor_dest = $bot_directory . '/vendor';
if (file_exists($vendor_source) && is_dir($vendor_source)) {
    function copyDirectory($source, $dest) {
        if (!is_dir($dest)) {
            mkdir($dest, 0755, true);
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $item) {
            $destPath = $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
            if ($item->isDir()) {
                if (!is_dir($destPath)) {
                    mkdir($destPath, 0755, true);
                }
            } else {
                copy($item, $destPath);
            }
        }
    }
    
    copyDirectory($vendor_source, $vendor_dest);
}

// تنظیم webhook به مسیر صحیح
$url = $domain.$type.'/Bot/'.$botuser.'/index.php';
bot('setWebhook',['url'=>$url,'secret_token'=>$botid,'drop_pending_updates'=>true,'allowed_updates'=>json_encode(['message','callback_query','inline_query','chat_member'])],$token);

$botid_safe = $connect->real_escape_string($botid);
$from_id_safe = $connect->real_escape_string($from_id);
$token_safe = $connect->real_escape_string($token);
$type_safe = $connect->real_escape_string($type);
$timer_safe = $connect->real_escape_string($timer);
$connect->query("INSERT INTO `bot` (`id` , `admin` , `token` , `type` , `created`) VALUES ('$botid_safe','$from_id_safe','$token_safe','$type_safe','$timer_safe')");
$database->multi_query("CREATE TABLE IF NOT EXISTS `user_$botid_safe` (
	`id` BIGINT PRIMARY KEY,
	`warn` INT(10) DEFAULT '0',
	`spam` BIGINT DEFAULT '0',
	`step` TEXT DEFAULT NULL,
	`time` TIME DEFAULT NULL,
	`date` DATE DEFAULT NULL
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `upload_$botid_safe` (
	`id` BIGINT PRIMARY KEY,
	`file_id` TEXT DEFAULT NULL,
	`file_size` TEXT DEFAULT NULL,
	`type` TEXT DEFAULT NULL,
	`password` TEXT DEFAULT NULL,
	`protectcontent` TEXT DEFAULT NULL,
	`caption` LONGTEXT DEFAULT NULL,
	`multi` BIGINT DEFAULT '0',
	`time` TIME DEFAULT NULL,
	`date` DATE DEFAULT NULL
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `like_$botid_safe` (
	`id` BIGINT DEFAULT '0',
	`file_id` BIGINT DEFAULT '0'
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `dislike_$botid_safe` (
	`id` BIGINT DEFAULT '0',
	`file_id` BIGINT DEFAULT '0'
	) default charset = utf8mb4;

CREATE TABLE IF NOT EXISTS `view_$botid_safe` (
	`id` BIGINT DEFAULT '0',
	`file_id` BIGINT DEFAULT '0'
	) default charset = utf8mb4;
");
bot('deleteMessage',[
'chat_id'=>$from_id,
'message_id'=>$message_id
]);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ ربات شما با موفقیت به سرور های ما متصل شد !
",
'parse_mode'=>'HTML'
],$token);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ ربات ( <a href ='https://t.me/$botuser'>".Htmlentitie($botname)."</a> ) با موفقیت ساخته شد !
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ توکن شما معتبر نمیباشد لطفاً توکن جدید را فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ پیامی که حاوی توکن ربات خودتان هست را فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً پیام را فقط از بات فادر فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً پیام را فقط فوروارد کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "📚 راهنما"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
📚 به بخش راهنما خوش آمدید . . . 

📌 راهنما دکمه ها : 

🔐 حساب کاربری : این دکمه تمام اطلاعات مورد نیاز که برای ساخت ربات یا هر چیزی مربوط به رباتساز تسلا نیاز دارید مورد نمایش هست از جمله ربات های ساخته شده

⚙️ ساخت ربات : از این بخش میتونید ربات مد نظر خود را بسازید که راهنما ساخت انتهای همین متن قرار گرفته است

♻️ آپدیت ربات : به محض اینکه در کانال اطلاع رسانی پیام آپدیت ربات هارا گذاشتیم شما میتوانید از این بخش ربات های خود را به آخرین نسخه آپدیت ( بروز ) کنید

❌ حذف ربات : با این دکمه میتونید ربات های که نیازی به آنها ندارید رو حذف کنید 

🆘 پشتیبانی : در صورت هرگونه مشکل ، سوال ، پیشنهاد و انتقادات میتونید از بخش پشتیبانی با تیم بزرگ تسلا کریتور در ارتباط باشید

🤖 راهنما ساخت ربات : با رفتن به بخش ( ⚙️ ساخت ربات ) و فوروارد پیام توکن از ربات @BotFather میتوانید به راحتی تمام ربات خود را بسازید 

‼️ توجه کنید که فقط فوروارد پیام از بات فادر باید صورت بگیرد

و همینطور رباتساز تسلا کاملا رایگان و بدون هزینه است در صورت دیدن کپی برداری .پیگرد قانونی صورت میگردد 
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄
⏰درصورتی که ربات شما قبلا آمار داشته در سال های گذشته پس از ساخت داخل ربات خود به بخش 📂 استخراج ممبر ها رفته و سپس تمام کاربران قبلی که آمار داشتین استخراج کنید
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄

👈🏻 با ارسال پیشنهادات و انتقادات خود به ارتقای رباتساز کمک کنید 
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄
💞توجه ربات جوین امن راه در کانال های خود ادمین کنید و سپس برای ربات خود قفل تنظیم کنید یا قفل ها کار نمیکند
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄
👍 | @UplSaz2bot
📣 | @UplSaz7
🤖 | @linkdonealma5
🎇 | @Winston_Source1
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄
",
'parse_mode'=>'HTML',
'reply_markup'=>$menu
]);
}
elseif($text == "🆘 پشتیبانی"){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🆘 به بخش پشتیبانی خوشـ آمدید",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"🆘 پشتیبانی آنلاین",'callback_data'=>"support"]],
[['text'=>"•=•=•=•=•=•=•=•=•=•=•=•=•=•=•=•",'callback_data'=>"fake"]],
[['text'=>$date,'callback_data'=>"fake"],['text'=>'📆 تاریخ ◄','callback_data'=>"fake"]],
[['text'=>$time,'callback_data'=>"fake"],['text'=>'⏰ ساعت ◄','callback_data'=>"fake"]],
[['text'=>"•=•=•=•=•=•=•=•=•=•=•=•=•=•=•=•",'callback_data'=>"fake"]],
]])
]);
}
elseif($step == "support" and isset($update->message)){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ پیام شما با موفقیت برای پشتیبانی ارسال شد

🔐 اگر پیام دیگری دارید ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
foreach($admin as $me){
bot('forwardMessage',[
'chat_id'=>$me,
'from_chat_id'=>$from_id,
'message_id'=>$message_id
]);
bot('sendMessage',[
'chat_id'=>$me,
'text'=>"
ID : <code>$from_id</code>

🔰 پی وی کاربر <a href ='tg://user?id=$from_id'>".Htmlentitie($first_name)."</a> است
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"🔍 اطلاعات کاربر",'callback_data'=>"info-$from_id"]],
]])
]);
}
}
//-----------------------------------------------------------------------------------------------
elseif(in_array($from_id,$admin)){
if($text == "/panel" or $text == "/admin"){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
🌹 به پنل مدیریت خوش آمدید
",
'parse_mode'=>'HTML',
'reply_markup'=>$panel
]);
}
elseif($text == "📊 آمار"){
$botsmembers = 0; 
$tables = $database->query("SHOW TABLES LIKE 'user_%'");
while($row = $tables->fetch_array()){
$botsmembers += $database->query("SELECT id FROM `{$row[false]}`")->num_rows;
}
$countmember = $connect->query("SELECT id FROM `user`")->num_rows;
$countblock = $connect->query("SELECT * FROM `user` WHERE step = 'block'")->num_rows;
$code = $connect->query("SELECT * FROM `user` WHERE date = '$date' ORDER BY `time` DESC LIMIT 3");
$result = null;
$i = 0;
while($res = $code->fetch_assoc()){
$i++;
$id = $res['id'];
$Jointime = $res['time'];
$Joindate = str_replace('-','/',$res['date']);
$yournamer = Htmlentitie(bot('getChatMember',['chat_id'=>$id,'user_id'=>$id])->result->user->first_name);
$result .= "
🎈 $i « <a href ='tg://user?id=$id'>$yournamer</a> » 
📆 تاریخ عضویت : $Joindate
⏰ ساعت عضویت : $Jointime
┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄
";
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
📊 تعداد کل کاربران ربات ها : $botsmembers

📉 تعداد کل کاربران رباتساز : $countmember

❌ تعداد کاربران بلاک شده : $countblock

".($result ? "📈 آخرین کاربران ربات :\n\n$result" : null),
'parse_mode'=>'HTML',
'reply_markup'=>$panel
]);
}
elseif($text == "⚡️ ربات ها"){
$keyboard = [[['text'=>"📄 نام ربات",'callback_data'=>"fake"],['text'=>"💫 یوزرنیم ربات",'callback_data'=>"fake"],['text'=>"📈 آمار ربات",'callback_data'=>"fake"],['text'=>"❄️ ادمین ربات",'callback_data'=>"fake"]]];
$code = $connect->query("SELECT * FROM `bot` LIMIT 5 OFFSET 0");
while($res = $code->fetch_assoc()){
$get = bot('getMe',[],$res['token']);
if($get->ok){
$botid = $get->result->id;
$botname = $get->result->first_name;
$keyboard[] = [['text'=>$botname,'callback_data'=>"fake"],['text'=>"@".($get->result->username),'callback_data'=>"fake"],['text'=>($database->query("SELECT id FROM `user_$botid`")->num_rows),'url'=>"https://t.me/".$botuser."?start=Status_".$botid],['text'=>(bot('getChatMember',['chat_id'=>$res['admin'],'user_id'=>$res['admin']])->result->user->first_name ?? $res['admin']),'callback_data'=>"info-{$res['admin']}"]];
}else{
$keyboard[] = [['text'=>$res['id'],'callback_data'=>"fake"],['text'=>"⚠️",'callback_data'=>"fake"],['text'=>($database->query("SELECT id FROM `user_{$res['id']}`")->num_rows),'url'=>"https://t.me/".$botuser."?start=Status_".$res['id']],['text'=>(bot('getChatMember',['chat_id'=>$res['admin'],'user_id'=>$res['admin']])->result->user->first_name ?? $res['admin']),'callback_data'=>"info-{$res['admin']}"]];
}
}
$botcount = $connect->query("SELECT * FROM `bot`")->num_rows;
if($botcount > 5){
$keyboard[] = [['text'=>"➡️ بعدی",'callback_data'=>"bots-5-5"]];
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
⚙ تعداد کل ربات ها : $botcount

📉 آمار ربات ها به شرح زیر می‌باشد
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}
elseif($text == "⚙ تنظیمات"){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
⚙ چیزی را که می‌خواهید تنظیم کنید انتخاب کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"💡 تنظیمات خاموش و روشن",'callback_data'=>"fake"]],
[['text'=>"🔐 جوین امن اجباری",'callback_data'=>"onoff-safe"]],
[['text'=>"🌖 تنظیمات حذف خودکار",'callback_data'=>"fake"]],
[['text'=>"👤 حداقل ممبر جذب شده",'callback_data'=>"set-minimum"]]
]])
]);
}
elseif(substr($step, 0, 4) === "set-" and isset($text)){
$type = explode("-",$step)[1];
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
if(substr($step, -7) === "minimum"){
if(is_numeric($text)){
$connect->query("ALTER TABLE `bot` MODIFY $type BIGINT DEFAULT '$text'");
$connect->query("UPDATE `bot` SET $type = '$text'");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"👤 اطلاعات مربوط به حذف خودکار ربات های کمتر از تعداد مشخص شده ممبر تغییر یافت",
'parse_mode'=>'HTML',
'reply_markup'=>$panel
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ لطفاً بصورت عدد مقدار را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$panel
]);
}
}
}
elseif($text == "♻️ آپدیت ربات ها"){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"♻️ درحال آپدیت ربات ها ...",
'parse_mode'=>'HTML',
'reply_markup'=>$panel
]);
$bots = $connect->query("SELECT * FROM `bot`");
while($info = $bots->fetch_array()){
// دریافت نام کاربری ربات برای تنظیم مسیر صحیح
$bot_info = bot('getMe',[],$info['token']);
if($bot_info->ok){
    $bot_username = $bot_info->result->username;
    $url = $domain.$info['type'].'/Bot/'.$bot_username.'/index.php';
    bot('setWebhook',['url'=>$url,'secret_token'=>$info['id'],'drop_pending_updates'=>true,'allowed_updates'=>json_encode(['message','callback_query','inline_query','chat_member'])],$info['token']);
}
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ آپدیت ربات ها با موفقیت انجام شد !",
'parse_mode'=>'HTML'
]);
}
elseif($text == "📢 کانال جوین اجباری"){
if(isset($settings['channel'])){
foreach($settings['channel'] as $links){
$key[] = [['text'=>$links,'callback_data'=>"fake"],['text'=>"🗑 حذف",'callback_data'=>"deljoin-$links"]];
}
}
$key[] = [['text'=>"✅ افزودن جوین اجباری",'callback_data'=>"addjoin"]];
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✔️ لیست کانال های تنظیم شده :
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>$key])
]);
}
elseif($step == "SetJoin" and isset($text)){
$GetChat = bot('getChat',['chat_id'=>$text])->result->type ?? null;
if(in_array($GetChat,['channel','supergroup'])){
$chekjoin = bot('getChatMember',[
'chat_id'=>$text,
'user_id'=>$botid
])->result->status ?? null;
if($chekjoin == 'administrator'){
if(isset($settings['channel']) and in_array(mb_strtolower($text),$settings['channel'])){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ متاسفانه کانال $text از قبل تنظیم شده است
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
$settings['channel'][] = mb_strtolower($text);
Save("settings.json",$settings);
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ با موفقیت کانال $text تنظیم شد
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً ابتدا ربات را ادمین کانال $text کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً آیدی کانال معتبر ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "📣 کانال های ربات ها"){
$all = $connect->query("SELECT * FROM `channel`");
while($row = $all->fetch_array()){
$key[] = [['text'=>$row['id'],'callback_data'=>"fake"],['text'=>"🗑 حذف",'callback_data'=>"delch-{$row['id']}"]];
}
$key[] = [['text'=>"✅ افزودن جوین اجباری",'callback_data'=>"addch"]];
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✔️ لیست کانال های تنظیم شده :
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>$key])
]);
}
elseif($step == "SetChannel" and isset($text)){
$GetChat = bot('getChat',['chat_id'=>$text])->result->type ?? null;
if(in_array($GetChat,['channel','supergroup'])){
$chekjoin = bot('getChatMember',[
'chat_id'=>$text,
'user_id'=>$botid
])->result->status ?? null;
if($chekjoin == 'administrator'){
$channel = mb_strtolower($text);
if($connect->query("SELECT * FROM `channel` WHERE id = '$channel'")->num_rows){
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ متاسفانه کانال $text از قبل تنظیم شده است
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
$connect->query("INSERT INTO `channel` (`id` , `admin`) VALUES ('$channel','$from_id')");
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ با موفقیت کانال $text تنظیم شد
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً ابتدا ربات را ادمین کانال $text کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❌ لطفاً آیدی کانال معتبر ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "🔍 اطلاعات کاربر"){
$connect->query("UPDATE `user` SET step = 'info' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "info" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$nameuser = bot('getChatMember',['chat_id'=>$text,'user_id'=>$text])->result->user->first_name;
$datas = $connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc();
$warn = $datas['warn'];
$timej = $datas['time'];
$datej = str_replace('-','/',$datas['date']);
$botcount = $connect->query("SELECT * FROM `bot` WHERE admin = '$text'")->num_rows;
$edit = bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
👤 شناسه کاربر : <code>$text</code>

📑 نام کاربر : <a href ='tg://openmessage?user_id=$text'>".Htmlentitie($nameuser)."</a>

⚙ تعداد ربات ها : $botcount

⚠️ تعداد اخطار ها : $warn

📆 تاریخ عضویت : $datej

⏰ ساعت عضویت : $timej
",
'parse_mode'=>'HTML'
])->result->message_id;
$keyboard = [];
$code = $connect->query("SELECT * FROM `bot` WHERE admin = '$text'");
$res = $code->fetch_all(MYSQLI_ASSOC);
$key = array_map(fn($data) => ['text'=>(bot('getMe',[],$data['token'])->result->first_name ?? $data['id']),'url'=>"https://t.me/$botuser?start=Status_".$data['id']],$res);
$keyboard = array_chunk($key,2);
bot('editMessageReplyMarkup',[
'chat_id'=>$from_id,
'message_id'=>$edit,
'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ کاربر $text در ربات نیست",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "➕ افزایش اخطار"){
$connect->query("UPDATE `user` SET step = 'add' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "add" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'addwarn-$text' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"⚠️ تعداد اخطار مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ کاربر $text در ربات نیست",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif(substr($step, 0, 8) === "addwarn-" and isset($text) and is_numeric($text)){
$id = explode("-",$step)[1];
if(is_numeric($text)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$connect->query("UPDATE `user` SET warn = warn + '$text' WHERE id = '$id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت تعداد $text اخطار به کاربر $id داده شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"❗️تعداد $text اخطار از ادمین های ربات دریافت کردید",
'parse_mode'=>'HTML'
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ لطفاً فقط عدد ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "➖  کسر اخطار"){
$connect->query("UPDATE `user` SET step = 'low' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "low" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'lowwarn-$text' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"⚠️ تعداد اخطار مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ کاربر $text در ربات نیست",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif(substr($step, 0, 8) === "lowwarn-" and isset($text) and is_numeric($text)){
$id = explode("-",$step)[1];
if(is_numeric($text)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
$connect->query("UPDATE `user` SET warn = warn - '$text' WHERE id = '$id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت تعداد $text اخطار از کاربر $id گرفته شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"❕تعداد $text اخطار توسط ادمین های ربات از شما گرفته شد",
'parse_mode'=>'HTML'
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ لطفاً فقط عدد ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "❌ بلاک کردن"){
$connect->query("UPDATE `user` SET step = 'blockid' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "blockid" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'block' WHERE id = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت کاربر $text بلاک شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"❌ متاسفانه شما از ربات بلاک شدید",
'parse_mode'=>'HTML'
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ کاربر $text در ربات نیست",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "🔰 آنبلاک کردن"){
$connect->query("UPDATE `user` SET step = 'unblockid' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "unblockid" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت کاربر $text آنبلاک شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"♻️ شما از ربات آنبلاک شدید",
'parse_mode'=>'HTML'
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❌ کاربر $text در ربات نیست",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif($text == "📨 پیام همگانی"){
$connect->query("UPDATE `user` SET step = 'sendall' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"📨 پیام خود را ارسال کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "sendall" and isset($update->message)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"♻️ در حال ارسال . . . !",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
$all = $connect->query("SELECT * FROM `user`");
while($row = $all->fetch_array()){
bot('copyMessage',[
'chat_id'=>$row['id'],
'from_chat_id'=>$from_id,
'message_id'=>$message_id
]);
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت ارسال شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($text == "💭 فوروارد همگانی"){
$connect->query("UPDATE `user` SET step = 'forall' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"💭 پیام خود را فوروارد کنید",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "forall" and isset($update->message)){
$connect->query("UPDATE `user` SET step = 'none' WHERE id = '$from_id_safe' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"♻️ در حال ارسال . . . !",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
$all = $connect->query("SELECT * FROM `user`");
while($row = $all->fetch_array()){
bot('forwardMessage',[
'chat_id'=>$row['id'],
'from_chat_id'=>$from_id,
'message_id'=>$message_id
]);
}
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"✅ با موفقیت ارسال شد",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($text == "📩 پیام به کاربر"){
$connect->query("UPDATE `user` SET step = 'PvSId' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✔️ ای دی عددی کاربر مورد نظر را ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
elseif($step == "PvSId" and isset($text) and is_numeric($text)){
if($connect->query("SELECT * FROM `user` WHERE id = '$text' LIMIT 1")->fetch_assoc()){
$connect->query("UPDATE `user` SET step = 'PvPm-$text' WHERE id = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
💬 پیام خود را ارسال کنید
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}else{
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
❗️این کاربر در ربات نیست
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
}
}
elseif(substr($step, 0, 5) === "PvPm-" and isset($text)){
$ids = explode("-",$step)[1];
$nameuser = Htmlentitie(bot('getChatMember',['chat_id'=>$ids,'user_id'=>$ids])->result->user->first_name);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ پیام شما با موفقیت به کاربر ( <code>$nameuser</code> ) ارسال شد
",
'parse_mode'=>'HTML',
'reply_markup'=>$back
]);
bot('sendMessage',[
'chat_id'=>$ids,
'text'=>"
🌹 شما یک پیام از پشتیبانی دارید 

✔️ پیام : <code>".Htmlentitie($text)."</code>
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"🆘 پیام به پشتیبانی",'callback_data'=>"support"]],
]])
]);
}
elseif(isset($update->message->reply_to_message) and isset($update->message->reply_to_message->forward_from) and isset($text)){
$forep_id = $update->message->reply_to_message->forward_from->id;
if($connect->query("SELECT * FROM `user` WHERE id = '$forep_id' LIMIT 1")->fetch_assoc()){
$nameuser = Htmlentitie(bot('getChatMember',['chat_id'=>$forep_id,'user_id'=>$forep_id])->result->user->first_name);
bot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"
✅ پیام شما با موفقیت به کاربر ( <code>$nameuser</code> ) ارسال شد
",
'parse_mode'=>'HTML'
]);
bot('sendMessage',[
'chat_id'=>$forep_id,
'text'=>"
🌹 شما یک پیام از پشتیبانی دارید 

✔️ پیام : <code>".Htmlentitie($text)."</code>
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"🆘 پیام به پشتیبانی",'callback_data'=>"support"]],
]])
]);
}
}
}
}
$connect->close();
//--------------------------------------
// Telegram id : @SimpSonSelf
//--------------------------------------
?>