<?php

// Albums : SELECT * FROM `upload_$botid` WHERE multi IN (SELECT multi FROM `upload_$botid` GROUP BY multi HAVING COUNT(*) > 1 AND multi != '0') \\

error_reporting(E_ALL);

http_response_code(200);
if (function_exists('litespeed_finish_request')) {
    litespeed_finish_request();
} elseif (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}

include("jdf.php");

include("config.php");

//===[امنیت دامنه]===//

$telegram_ip_ranges = [

['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], // literally 149.154.160.0/20

['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    // literally 91.108.4.0/22

];

$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));

$ok = true;

foreach($telegram_ip_ranges as $telegram_ip_range){

if($ok){

$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));

$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));

if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec){

$ok = false;

}

}

}

if($ok){

exit(header("location: https://Google.com"));

}

//===[چک کردن اطلاعات]===//

$botid = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? null;

if(is_numeric($botid)){

if($connect->query("SHOW TABLES LIKE '%\_$botid'")->num_rows){

$botid_safe = $connect->real_escape_string($botid);

$settings = $connect->query("SELECT * FROM `bot` WHERE id = '$botid_safe' LIMIT 1")->fetch_assoc();

if(isset($settings) and $settings['type'] == 'uploader'){

define('API_KEY',$settings['token']);

}else{

die("Your bot type is wrong !");

}

}else{

die("Bot ID is wrong !");

}

}else{

die("Bot ID is wrong !");

}

//===[فانکشن های لازم]===//

function bot($method,$datas = [],$token = API_KEY){

$url = "https://api.telegram.org/bot".$token."/".$method;

$ch = curl_init();

curl_setopt($ch,CURLOPT_URL,$url);

curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);

$res = curl_exec($ch);

if(curl_error($ch)){

var_dump(curl_error($ch));

}else{

return json_decode($res);

}

}

function botmulti($method,$datas = []){

$url = "https://api.telegram.org/bot".API_KEY."/".$method;

$curls = [];

$results = [];

$multi = curl_multi_init();

foreach($datas as $index => $value){

if(is_array($value)){

foreach($value as $id){

$curl = curl_init();

curl_setopt($curl,CURLOPT_URL,$url);

curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);

curl_setopt($curl,CURLOPT_POSTFIELDS,array_merge($datas,[$index=>$id]));

curl_multi_add_handle($multi,$curl);

$curls[] = $curl;

}

}

}

do {

$status = curl_multi_exec($multi,$active);

if($active) curl_multi_select($multi);

} while($active and $status == CURLM_OK);

foreach($curls as $curl){

$results[] = json_decode(curl_multi_getcontent($curl));

curl_multi_remove_handle($multi,$curl);

}

curl_multi_close($multi);

return $results;

}

function Security($text){

$filters = array('root','safe','api','key','token','update','getme','include','foreach','input','exec','json','curl','php','zip','function','#',"'",'$','"','(',')','[',']',';');

foreach($filters as $filter){

if(stripos($text,$filter) !== false){

return $filter;

}

}

return false;

}

function Number($string) {

if(isset($string)){

$persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];

$arabic = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];

$ChangePersian = str_replace($persian,range(0,9),$string);

$ChangeArabic = str_replace($arabic,range(0,9),$ChangePersian);

return (is_numeric($ChangeArabic) and $ChangeArabic != 0) ? abs($ChangeArabic) : $ChangeArabic;

}

}

function JoinChek($ch,$chsettings,$settings,$user){

foreach($ch as $links){

if(isset($chsettings[$links]['timer']) ? $chsettings[$links]['timer'] > time() : true){

if(($settings['safe'] == false and in_array(bot('getChatMember',['chat_id'=>$links,'user_id'=>$user])->result->status ?? null,['left','kicked','restricted'])) or ((bot('getChatMember',['chat_id'=>$links,'user_id'=>bot('getMe',[],SAFE)->result->id],SAFE)->result->status ?? null) == 'administrator' and in_array(bot('getChatMember',['chat_id'=>$links,'user_id'=>$user],SAFE)->result->status ?? null,['member','administrator','creator']) == false)){

return (is_numeric($links) and substr($links, 0, 4) === "-100") ? (bot('getChat',['chat_id'=>$links])->result->invite_link ?? bot('getChat',['chat_id'=>$links],SAFE)->result->invite_link ?? $links) : $links;

}

}

}

return false;

}

function Font($text){

$font = [["𝟎","𝟏","𝟐","𝟑","𝟒","𝟓","𝟔","𝟕","𝟖","𝟗"]];

$echo = str_replace(range(0,9),$font[array_rand($font)],$text);

return $echo;

}

function GetSize($size,$pre){

$units = ['بایت','کیلوبایت','مگابایت','گیگابایت','ترابایت'];

$base = log($size,1024);

return round(pow(1024,$base - floor($base)),$pre).' '.$units[intval($base)];

}

function EnDecode($number){

error_reporting(E_ALL & ~E_WARNING);

return is_numeric($number) ? str_replace(['='],(string) null,base64_encode(gzdeflate($number))) : gzinflate(base64_decode($number));

}

function Album($lists){

return is_array($lists) ? str_replace(['='],(string) null,base64_encode(implode('~',array_map('EnDecode',$lists)))) : array_map('EnDecode',explode('~',base64_decode($lists)));

}

function DeleteFolder($directory){

if(is_file($directory)) return @unlink($directory);

$contents = glob($directory.'/*');

foreach($contents as $path){

if(is_file($path)){

@unlink($path);

}elseif(is_dir($path)){

DeleteFolder($path);

}

}

return @rmdir($directory);

}

function Htmlentitie($string){

if(isset($string)){

return str_replace(['&','<','>'],['&amp;','&lt;','&gt;'],$string);

}

}

//-----------------------------------------------------------------------------------------------

$update = json_decode(file_get_contents('php://input'));

if(isset($update->message)){

$chat_id = $update->message->chat->id;

$text = Number($update->message->text ?? null);

$message_id = $update->message->message_id;

$from_id = $update->message->from->id;

$tc = $update->message->chat->type;

$first_name = $update->message->from->first_name;

$last_name = $update->message->from->last_name ?? '𝑛𝑜𝑛𝑒';

$user_name = $update->message->from->username ?? '𝑛𝑜𝑛𝑒';

}

elseif(isset($update->callback_query)){

$chat_id = $update->callback_query->message->chat->id;

$data = $update->callback_query->data;

$user_id = $update->callback_query->id;

$message_id = $update->callback_query->message->message_id;

$from_id = $update->callback_query->from->id;

$first_name = $update->callback_query->from->first_name;

$last_name = $update->callback_query->from->last_name ?? '𝑛𝑜𝑛𝑒';

$user_name = $update->callback_query->from->username ?? '𝑛𝑜𝑛𝑒';

}

elseif(isset($update->inline_query)){

$inline = $update->inline_query;

$user_id = $update->inline_query->id;

$query = $update->inline_query->query;

$from_id = $update->inline_query->from->id;

$first_name = $update->inline_query->from->first_name;

$last_name = $update->inline_query->from->last_name ?? '𝑛𝑜𝑛𝑒';

$user_name = $update->inline_query->from->username ?? '𝑛𝑜𝑛𝑒';

}

elseif(isset($update->chat_member)){

$status = $update->chat_member->new_chat_member->status;

$from_id = $update->chat_member->new_chat_member->user->id;

$channel_id = isset($update->chat_member->chat->username) ? ('@'.$update->chat_member->chat->username) : $update->chat_member->chat->id;

}else{

die("The received update isn't defined !");

}

//===[ربات]===//

$get = bot('getMe');

if(is_null($get) or $get->ok == false) exit("The token is invalid !");

$botid = $get->result->id;

$botuser = $get->result->username;

$botname = $get->result->first_name;

//===[تعریف ثابت‌ها]===//

// تعریف ثابت‌های مورد نیاز
if (!defined('ROOT')) {
    define('ROOT', API_KEY);
}
if (!defined('SAFE')) {
    define('SAFE', API_KEY);
}

//===[اطلاعات]===//

$channels = isset($settings['channel']) ? json_decode($settings['channel'],true) : [];

$channelsettings = isset($settings['channelsettings']) ? json_decode($settings['channelsettings'],true) : [];

$admins = isset($settings['admins']) ? json_decode($settings['admins'],true) : [];

$dev = $settings['admin'];

// تعریف متغیر devs در صورت عدم وجود
$devs = isset($devs) ? $devs : [];

$admin = array_values(array_unique(array_merge([$dev], $devs, $admins)));

$date = jdate("Y/m/d");

$time = jdate("H:i:s");

$timer = time();

//===[امنیت]===//

if(isset($text)){

$filter = Security($text);

if($filter){

if(in_array($from_id,$admin)){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚠️ کاراکتر / کلمه ( $filter ) متاسفانه بخاطر مسائل امنیتی محدود شده است

"

]);

}

exit();

}

}

//===[دیتابیس]===//

$from_id_safe = $connect->real_escape_string($from_id);

$datas = $connect->query("SELECT * FROM `user_$botid` WHERE id = '$from_id_safe' LIMIT 1")->fetch_assoc() ?? ['id'=>false,'step'=>'none','warn'=>0,'spam'=>0,'time'=>$time,'date'=>$date];

$step = $datas['step'];

$warn = $datas['warn'];

$spam = $datas['spam'];

$timej = $datas['time'];

$datej = str_replace('-','/',$datas['date']);

//-----------------------------------------------------------------------------------------------

if(($step == "block" or $warn >= 3) and !in_array($from_id,$admin)) exit();

//-----------------------------------------------------------------------------------------------

if(in_array($from_id,$admin)){

$menu = json_encode(['keyboard'=>[

[['text'=>"🔐 حساب کاربری"]],

[['text'=>"🆘 پشتیبانی"],['text'=>"📚 راهنما"]],

[['text'=>"❄️ پنل مدیریت"]],

],'resize_keyboard'=>true]);

}else{

$menu = json_encode(['keyboard'=>[

[['text'=>"🔐 حساب کاربری"]],

[['text'=>"🆘 پشتیبانی"],['text'=>"📚 راهنما"]],

],'resize_keyboard'=>true]);

}



$back = json_encode(['keyboard'=>[

[['text'=>"🔙 برگشت"]],

],'resize_keyboard'=>true]);



$panel = json_encode(['keyboard'=>[

[['text'=>"📊 آمار"],['text'=>"📥 آپلود"]],

[['text'=>"📢 کانال جوین اجباری"]],

[['text'=>"➖  کسر اخطار"],['text'=>"➕ افزایش اخطار"]],

[['text'=>"📂 استخراج ممبر ها"]],

[['text'=>"👤 ادمین ها"],['text'=>"⚙ تنظیمات"]],

[['text'=>"📨 پیام همگانی"],['text'=>"💭 فوروارد همگانی"]],

[['text'=>"📩 پیام به کاربر"]],

[['text'=>"🔰 آنبلاک کردن"],['text'=>"❌ بلاک کردن"]],

[['text'=>"🔙 برگشت"]],

],'resize_keyboard'=>true]);



$upload = json_encode(['keyboard'=>[

[['text'=>"✔️ تبدیل به آلبوم"]],

[['text'=>"🔙 برگشت"]],

],'resize_keyboard'=>true]);



$backinline = json_encode(['inline_keyboard'=>[

[['text'=>"🔙 بازگشت",'callback_data'=>"back"]],

]

]);

//-----------------------------------------------------------------------------------------------

if(isset($status)){

if(!empty($channels) and in_array(mb_strtolower($channel_id),$channels)){

if(is_numeric($channel_id)) $channel_id = $update->chat_member->chat->title;

if(in_array($status,['left','kicked','restricted'])){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❗️ لطفاً جهت کار کردن با ربات در کانال $channel_id عضو شوید سپس از ربات استفاده کنید

",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ عضویت شما در کانال $channel_id با موفقیت تأیید شد

",

'parse_mode'=>'HTML'

]);

}

}

}

//-----------------------------------------------------------------------------------------------

if($datas['id']){

if($datas['spam'] + $settings['antispamtime'] > $timer){

if(isset($update->callback_query)){

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"🍂 لطفاً آهسته تر با ربات کار کنید",

'show_alert'=>true

]);

}elseif(isset($update->message) and $tc == 'private'){

$delete_id = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🍂 لطفاً آهسته تر با ربات کار کنید",

'parse_mode'=>'HTML'

])->result->message_id;

sleep(3);

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$message_id

]);

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$delete_id

]);

}

exit("Don't spam me !");

}else{

$timer_safe = $connect->real_escape_string($timer);

$connect->query("UPDATE `user_$botid` SET spam = '$timer_safe' WHERE id = '$from_id_safe' LIMIT 1");

}

}

//-----------------------------------------------------------------------------------------------

if(isset($data)){

if(substr($data, 0, 5) === "like-"){

$ids = explode("-",$data)[1];

if($connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids' AND id = '$from_id' LIMIT 1")->num_rows){

$connect->query("DELETE FROM `like_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe'");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👍 شما لایک خود را پس گرفتید",

'show_alert'=>true

]);

}else{

$connect->query("INSERT INTO `like_$botid` (`file_id` , `id`) VALUES ('$ids_safe','$from_id_safe')");

if($connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe' LIMIT 1")->num_rows){

$connect->query("DELETE FROM `dislike_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe'");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👍 شما این مدیا را لایک کردید و 👎 دیس لایک خود را پس گرفتید",

'show_alert'=>true

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👍 شما این مدیا را لایک کردید",

'show_alert'=>true

]);

}

}

$likes = $connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids'")->num_rows;

$dislikes = $connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids'")->num_rows;

bot('editMessageReplyMarkup',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"👍 ( $likes )",'callback_data'=>"like-$ids"],['text'=>"👎 ( $dislikes )",'callback_data'=>"dislike-$ids"]]

]])

]);

}

elseif(substr($data, 0, 8) === "dislike-"){

$ids = explode("-",$data)[1];

if($connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe' LIMIT 1")->num_rows){

$connect->query("DELETE FROM `dislike_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe'");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👎 شما دیس لایک خود را پس گرفتید",

'show_alert'=>true

]);

}else{

$connect->query("INSERT INTO `dislike_$botid` (`file_id` , `id`) VALUES ('$ids','$from_id')");

if($connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids' AND id = '$from_id' LIMIT 1")->num_rows){

$connect->query("DELETE FROM `like_$botid` WHERE file_id = '$ids_safe' AND id = '$from_id_safe'");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👎 شما این مدیا را دیس لایک کردید و 👍 لایک خود را پس گرفتید",

'show_alert'=>true

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"👎 شما این مدیا را دیس لایک کردید",

'show_alert'=>true

]);

}

}

$likes = $connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids'")->num_rows;

$dislikes = $connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids'")->num_rows;

bot('editMessageReplyMarkup',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"👍 ( $likes )",'callback_data'=>"like-$ids"],['text'=>"👎 ( $dislikes )",'callback_data'=>"dislike-$ids"]]

]])

]);

}

elseif($data == "support"){

$connect->query("UPDATE `user_$botid` SET step = '$data' WHERE id = '$from_id' LIMIT 1");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"🎈 صبر کنید",

'show_alert'=>false

]);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'text'=>"

🆘 پیام , انتقاد , پیشنهادات خود را برای ما ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$backinline

]);

}

elseif($data == "back"){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$message_id

]);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['backtext'] ? $settings['backtext'] : "🔙 به منوی اصلی برگشتید"),

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

exit();

}

elseif($data == "fake"){

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"💤 این دکمه فقط جهت نمایش اطلاعات است",

'show_alert'=>false

]);

}

}

//-----------------------------------------------------------------------------------------------

if(isset($data) and in_array($from_id,$admin)){

if($data == "addadmin"){

if($from_id == $dev or in_array($from_id,$devs)){

$connect->query("UPDATE `user_$botid` SET step = 'SetAdmins' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

🆔 آیدی عددی ادمین جدید را بصورت عدد ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"🔐 متاسفانه شما دسترسی به این دکمه را ندارید",

'show_alert'=>false

]);

}

}

elseif(substr($data, 0, 9) === "deladmin|"){

$ids = explode("|",$data)[1];

if($from_id == $dev or in_array($from_id,$devs)){

$name = bot('getChat',['chat_id'=>$ids])->result->first_name;

$admin = json_encode(array_values(array_diff($admins,[$ids])),JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET admins = '$admin' WHERE id = '$botid' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

🗑 کاربر $name از لیست ادمین ها حذف شد

",

'parse_mode'=>'HTML'

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"🔐 متاسفانه شما دسترسی به این دکمه را ندارید",

'show_alert'=>false

]);

}

}

if($data == "addjoin"){

$connect->query("UPDATE `user_$botid` SET step = 'SetChannel' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

📢 آیدی کانال جدید را با @ ارسال کنید یا برای چنل خصوصی آیدی عددی کانال را ارسال کنید و یا حتی می‌توانید یک پیام از کانال خود برای ربات فوروارد کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif(substr($data, 0, 8) === "channel|"){

$links = explode("|",$data)[1];

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

📢 پنل کانال $links باز شد

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"🗑 حذف کانال",'callback_data'=>"deljoin|$links"]],

[isset($channelsettings[$links]['timer']) ? ['text'=>"⏰ حذف زمان",'callback_data'=>"deltimejoin|$links"] : ['text'=>"⏰ تنظیم زمان",'callback_data'=>"timejoin|$links"]],

[['text'=>"👤 تعداد ممبر",'callback_data'=>"membersjoin|$links"]]

]])

]);

}

elseif(substr($data, 0, 8) === "deljoin|"){

$links = explode("|",$data)[1];

$channel = json_encode(array_values(array_diff($channels,[$links])),JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET channel = '$channel' WHERE id = '$botid' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

🗑 با موفقیت کانال $links حذف شد

",

'parse_mode'=>'HTML'

]);

}

elseif(substr($data, 0, 9) === "timejoin|"){

$links = explode("|",$data)[1];

$key = array_chunk(array_map(function($x) use ($links) { return ['text'=>$x,'callback_data'=>"settimejoin|$links|$x"]; },range(1,24)),6);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⏰ زمان جوین اجباری را انتخاب کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>$key])

]);

}

elseif(substr($data, 0, 12) === "settimejoin|"){

$exp = explode("|",$data);

$links = $exp[1];

$hour = $exp[2];

$channelsettings[$links]['timer'] = strtotime("+ $hour hour");

$channelsetting = json_encode($channelsettings,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET channelsettings = '$channelsetting' WHERE id = '$botid' LIMIT 1");

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'text'=>"

⏳ با موفقیت زمان جوین اجباری $hour ساعت برای کانال $links تنظیم شد

",

'parse_mode'=>'HTML'

]);

}

elseif(substr($data, 0, 12) === "deltimejoin|"){

$links = explode("|",$data)[1];

if(isset($channelsettings[$links]['timer'])){

unset($channelsettings[$links]['timer']);

$channelsetting = json_encode($channelsettings,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET channelsettings = '$channelsetting' WHERE id = '$botid' LIMIT 1");

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'text'=>"

❌ زمان جوین اجباری حذف شد

",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚠️ زمان جوین اجباری از قبل حذف شده بود

",

'parse_mode'=>'HTML'

]);

}

}

elseif(substr($data, 0, 6) === "files-"){

$ids = explode("-",$data)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

bot('copyMessage',[

'chat_id'=>$from_id,

'from_chat_id'=>$from_id,

'message_id'=>$message_id,

'caption'=>$file['caption'],

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>($file['protectcontent'] == 'on' ? '✅' : '❌') ."محافظت از محتوا",'callback_data'=>"protectcontent-$ids"]],

[['text'=>"🔖 تغییر کپشن",'callback_data'=>"caption-$ids"]],

[['text'=>"🔐 تنظیم پسورد",'callback_data'=>"password-$ids"]],

[['text'=>"🗑 حذف",'callback_data'=>"delete-$ids"]],

]])

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'show_alert'=>true

]);

}

}

elseif(substr($data, 0, 15) === "protectcontent-"){

$ids = explode("-",$data)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

if($file['protectcontent'] == 'on'){

$connect->query("UPDATE `upload_$botid` SET protectcontent = 'off' WHERE id = '$ids' LIMIT 1");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"❌ حالت محافظت از محتوا غیر فعال شد",

'show_alert'=>true

]);

bot('editMessageReplyMarkup',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"❌ محافظت از محتوا",'callback_data'=>"protectcontent-$ids"]],

[['text'=>"🔖 تغییر کپشن",'callback_data'=>"caption-$ids"]],

[['text'=>"🔐 تنظیم پسورد",'callback_data'=>"password-$ids"]],

[['text'=>"🗑 حذف",'callback_data'=>"delete-$ids"]],

]])

]);

}else{

$connect->query("UPDATE `upload_$botid` SET protectcontent = 'on' WHERE id = '$ids' LIMIT 1");

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"✅ حالت محافظت از محتوا فعال شد",

'show_alert'=>true

]);

bot('editMessageReplyMarkup',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"✅ محافظت از محتوا",'callback_data'=>"protectcontent-$ids"]],

[['text'=>"🔖 تغییر کپشن",'callback_data'=>"caption-$ids"]],

[['text'=>"🔐 تنظیم پسورد",'callback_data'=>"password-$ids"]],

[['text'=>"🗑 حذف",'callback_data'=>"delete-$ids"]],

]])

]);

}

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'show_alert'=>true

]);

}

}

elseif(substr($data, 0, 8) === "caption-"){

$ids = explode("-",$data)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = '$data-$message_id' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔖 کپشن جدید مدیا خود را ارسال کنید",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id,

'reply_markup'=>$back

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'show_alert'=>true

]);

}

}

elseif(substr($data, 0, 9) === "password-"){

$ids = explode("-",$data)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = '$data-$message_id' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔐 پسورد مورد نظر برای مدیای خود را ارسال کنید",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id,

'reply_markup'=>$back

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'show_alert'=>true

]);

}

}

elseif(substr($data, 0, 7) === "delete-"){

$ids = explode("-",$data)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$message_id

]);

if(substr($step, 0, 7) === "Upload-"){

$files = json_decode(explode("-",$step)[1]);

if(($key = array_search($ids,$files)) !== false){

unset($files[$key]);

$files = array_values($files);

$connect->query("UPDATE `user_$botid` SET step = 'Upload-".json_encode($files)."' WHERE id = '$from_id' LIMIT 1");

}

}

$connect->query("DELETE FROM `upload_$botid` WHERE id = '$ids'");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🗑 مدیای مورد نظر شما با موفقیت حذف شد",

'parse_mode'=>'HTML'

]);

}else{

bot('answercallbackquery',[

'callback_query_id'=>$user_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'show_alert'=>true

]);

}

}

elseif(substr($data, 0, 4) === "set-"){

$connect->query("UPDATE `user_$botid` SET step = '$data' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>(substr($data, -4) === "text") ? "📑 متن مورد نظر خود را جهت تنظیم کردن ارسال کنید" : ((substr($data, -2) === "id") ? "🆔 آیدی مورد نظر را بدون @ ارسال کنید" : "⏳ زمان مورد نظر خود را بصورت عدد ارسال کنید"),

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"❌ حذف",'callback_data'=>str_replace('set','del',$data)]],

[['text'=>"🔙 بازگشت",'callback_data'=>"back"]],

]])

]);

}

elseif(substr($data, 0, 4) === "del-"){

$type = explode("-",$data)[1];

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$connect->query("UPDATE `bot` SET $type = NULL WHERE id = '$botid' LIMIT 1");

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$message_id,

'text'=>"❌ با موفقیت حذف شد",

'parse_mode'=>'HTML'

]);

}

elseif($data == "vartext"){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✔️ متغیر هایی که میتوانید در متن های خود استفاده کنید



ID : آیدی عددی کاربر

FIRSTNAME : نام کاربر

LASTNAME : فامیلی کاربر

USERNAME : یوزرنیم کاربر

WARN : تعداد اخطار های کاربر

TIMEJOIN : ساعت عضویت

DATEJOIN : تاریخ عضویت

TIME : زمان

DATE : تاریخ

BOTUSER : یوزرنیم ربات

BOTNAME : اسم ربات



➕ متغیر های اضافه قسمت حساب کاربری



LIKES : تعداد فایل های لایک شده

DISLIKES : تعداد فایل های دیس لایک شده

VIEWS : تعداد فایل های دیده شده



➕ متغیر های اضافه قسمت جوین اجباری



CHANNEL : لینک کانال جوین اجباری

CHANNELS : لینک کانال های جوین اجباری

",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id

]);

}

}

//-----------------------------------------------------------------------------------------------

if(isset($tc) and $tc == 'private'){

if($datas['id'] == false){

$connect->query("INSERT INTO `user_$botid` (`id` , `step` , `time` , `date`) VALUES ('$from_id','none','$time','$date')");

}

if(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])$/',$text)){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['starttext'] ? str_replace(['ID','FIRSTNAME','LASTNAME','USERNAME','WARN','TIMEJOIN','DATEJOIN','TIME','DATE','BOTUSER','BOTNAME'],[$from_id,$first_name,$last_name,$user_name,$warn,$timej,$datej,$time,$date,$botuser,$botname],$settings['starttext']) : "📤 سلام به ربات آپلودر ( $botname ) خوش آمدید 📥"),

'reply_markup'=>$menu

]);

}

// elseif($channels and !in_array($from_id,$admin)){

elseif(!in_array($from_id,$admin)){

// $JoinMe = JoinChek(['@MyXHentai',...$channels],$channelsettings,$settings,$from_id);

$JoinMe = JoinChek($channels,$channelsettings,$settings,$from_id);

$all = $connect->query("SELECT * FROM `channel`");

while($row = $all->fetch_array()){

$channels[] = $row['id'];

if($JoinMe == false){

if(in_array(bot('getChatMember',['chat_id'=>$row['id'],'user_id'=>$from_id],ROOT)->result->status ?? null,['member','administrator','creator']) == false){

$JoinMe = (is_numeric($row['id']) and substr($row['id'], 0, 4) === "-100") ? (bot('getChat',['chat_id'=>$row['id']],ROOT)->result->invite_link ?? bot('getChat',['chat_id'=>$row['id']],SAFE)->result->invite_link ?? $row['id']) : $row['id'];

}

}

}

if($JoinMe){

$channel = array_map(function($links){

return (is_numeric($links) and substr($links, 0, 4) === "-100") ? (bot('getChat',['chat_id'=>$links])->result->invite_link ?? bot('getChat',['chat_id'=>$links],SAFE)->result->invite_link ?? bot('getChat',['chat_id'=>$links],ROOT)->result->invite_link ?? $links) : $links;

},$channels);

if(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt]) (.*)/',$text,$match)){

$channel_buttons = array_map(function($url) { 
    return [['text'=>'عضویت','url'=>filter_var($url,FILTER_VALIDATE_URL) ? $url : 'https://t.me/'.str_replace('@','',$url)]]; 
}, $channel);

$channel_buttons[] = [['text'=>"✅ تایید عضویت و دانلود",'url'=>"https://t.me/$botuser?start={$match[2]}"]];

$menu = json_encode(['inline_keyboard'=>$channel_buttons]);

}else{

$channel_buttons2 = array_map(function($url) { 
    return [['text'=>'عضویت','url'=>filter_var($url,FILTER_VALIDATE_URL) ? $url : 'https://t.me/'.str_replace('@','',$url)]]; 
}, $channel);

$channel_buttons2[] = [['text'=>"✅ تایید عضویت",'url'=>"https://t.me/$botuser?start=verify"]];

$menu = json_encode(['inline_keyboard'=>$channel_buttons2]);

}

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['jointext'] ? str_replace(['ID','FIRSTNAME','LASTNAME','USERNAME','WARN','TIMEJOIN','DATEJOIN','TIME','DATE','CHANNELS','CHANNEL','BOTUSER','BOTNAME'],[$from_id,$first_name,$last_name,$user_name,$warn,$timej,$datej,$date,$time,implode(PHP_EOL,$channel),$JoinMe,$botuser,$botname],$settings['jointext']) : "🔰 لطفاً جهت حمایت از ما و به دلیل رایگان بودن ربات در کانال های اسپانسری ما عضو شوید : "),

'reply_markup'=>$menu

]);

exit();

}

}

if(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt]) Album_(.*)/',$text,$match)){

$ids = EnDecode($match[2]);

if(is_numeric($ids)){

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE multi = '$ids'")->fetch_all(MYSQLI_ASSOC)){

$media = array_map(function($files){

return ['type'=>$files['type'],'media'=>$files['file_id'],'caption'=>$files['caption']];

},$file);

$send = bot('sendMediaGroup',[

'chat_id'=>$from_id,

'media'=>json_encode($media)

]);

if($settings['adstext']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>$settings['adstext']

]);

}

if($settings['deletetime']){

$delete = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🗑 آلبوم بالا تا {$settings['deletetime']} ثانیه دیگر حذف می‌شود",

'parse_mode'=>'HTML'

])->result->message_id;

sleep($settings['deletetime']);

foreach($send->result as $result){

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$result->message_id

]);

}

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$delete,

'text'=>"

<u>🗑 آلبوم حذف شد</u>

",

'parse_mode'=>'HTML'

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ آلبوم شما پیدا نشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ لینک آلبوم شما درست نمیباشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

}

}

elseif(isset($text) and preg_match('/^\/([Ss][Tt][Aa][Rr][Tt]) (.*)/',$text,$match)){

$ids = EnDecode($match[2]);

if(is_numeric($ids)){

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

if($file['password'] == 'none'){

if($connect->query("SELECT * FROM `view_$botid` WHERE file_id = '$ids' AND id = '$from_id' LIMIT 1")->num_rows == 0){

$connect->query("INSERT INTO `view_$botid` (`file_id` , `id`) VALUES ('$ids','$from_id')");

}

$likes = $connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids'")->num_rows;

$dislikes = $connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids'")->num_rows;

$views = $connect->query("SELECT * FROM `view_$botid` WHERE file_id = '$ids'")->num_rows;

$reply = bot('send'.str_replace('_',(string) null,$file['type']),[

'chat_id'=>$from_id,

$file['type']=>$file['file_id'],

'caption'=>'👁‍🗨 تعداد بازدید : '.$views.PHP_EOL.PHP_EOL.$file['caption'],

'protect_content'=>($file['protectcontent'] == 'on'),

'has_spoiler'=>($file['protectcontent'] == 'off'),

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"👍 ( $likes )",'callback_data'=>"like-$ids"],['text'=>"👎 ( $dislikes )",'callback_data'=>"dislike-$ids"]],

in_array($from_id,$admin) ? [['text'=>"✏️ ویرایش",'callback_data'=>"files-$ids"]] : []

]])

])->result->message_id;

if($settings['adstext']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>$settings['adstext'],

'reply_to_message_id'=>$reply

]);

}

if($settings['deletetime']){

$delete = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🗑 فایل بالا تا {$settings['deletetime']} ثانیه دیگر حذف می‌شود",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$reply

])->result->message_id;

sleep($settings['deletetime']);

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$reply

]);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$delete,

'text'=>"

<u>🗑 فایل حذف شد</u>

",

'parse_mode'=>'HTML'

]);

}

}else{

$connect->query("UPDATE `user_$botid` SET step = 'sendpassword-$ids' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔐 فایل مورد نظر شما دارای پسورد است لطفاً رمز آنرا ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ فایل شما پیدا نشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ لینک فایل شما درست نمیباشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

}

}

elseif(isset($text) and preg_match('/^\/([Ff][Aa][Kk][Ee]) (\d+):(\d+)/',$text,$match)){

if(in_array($from_id,$devs)){

if($match[2] > $match[3]){

$i = $match[3] + 1;

$insert = array_map(function($id) use ($i){

global $i;

if($i > 0) $i--;

return "('$id','".($i > 0 ? strtotime("- ".rand(1,60)." day") : 0)."','fakemember','00:00:00','0/0/0')";

},range(1,$match[2]));

$connect->query("INSERT IGNORE INTO `user_$botid` (`id` , `spam` , `step` , `time` , `date`) VALUES ".implode(',',$insert));

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"با موفقیت ممبر های فیک به دیتابیس اضافه شدند",

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"تعداد ممبر های فیک باید بیشتر از تعداد کاربران فعال باشد",

]);

}

}

}

elseif($text == "🔙 برگشت"){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['backtext'] ? $settings['backtext'] : "🔙 به منوی اصلی برگشتید"),

'reply_markup'=>$menu

]);

}

elseif(substr($step, 0, 13) === "sendpassword-" and isset($text)){

$ids = explode("-",$step)[1];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

if(in_array($file['password'],['none',$text])){

if($connect->query("SELECT * FROM `view_$botid` WHERE file_id = '$ids' AND id = '$from_id' LIMIT 1")->num_rows == 0){

$connect->query("INSERT INTO `view_$botid` (`file_id` , `id`) VALUES ('$ids','$from_id')");

}

$likes = $connect->query("SELECT * FROM `like_$botid` WHERE file_id = '$ids'")->num_rows;

$dislikes = $connect->query("SELECT * FROM `dislike_$botid` WHERE file_id = '$ids'")->num_rows;

$views = $connect->query("SELECT * FROM `view_$botid` WHERE file_id = '$ids'")->num_rows;

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ پسورد ارسال شده درست می‌باشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

$reply = bot('send'.str_replace('_',(string) null,$file['type']),[

'chat_id'=>$from_id,

$file['type']=>$file['file_id'],

'caption'=>'👁‍🗨 تعداد بازدید : '.$views.PHP_EOL.PHP_EOL.$file['caption'],

'protect_content'=>($file['protectcontent'] == 'on'),

'has_spoiler'=>($file['protectcontent'] == 'off'),

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"👍 ( $likes )",'callback_data'=>"like-$ids"],['text'=>"👎 ( $dislikes )",'callback_data'=>"dislike-$ids"]],

in_array($from_id,$admin) ? [['text'=>"✏️ ویرایش",'callback_data'=>"files-$ids"]] : []

]])

])->result->message_id;

if($settings['adstext']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>$settings['adstext'],

'reply_to_message_id'=>$reply

]);

}

if($settings['deletetime']){

$delete = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🗑 فایل بالا تا {$settings['deletetime']} ثانیه دیگر حذف می‌شود",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$reply

])->result->message_id;

sleep($settings['deletetime']);

bot('deleteMessage',[

'chat_id'=>$from_id,

'message_id'=>$reply

]);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$delete,

'text'=>"

<u>🗑 فایل حذف شد</u>

",

'parse_mode'=>'HTML'

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ پسورد ارسال شده صحیح نمیباشد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}else{

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ فایل شما پیدا نشد",

'parse_mode'=>'HTML',

'reply_markup'=>$menu

]);

}

}

elseif($text == "🔐 حساب کاربری"){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$likes = $connect->query("SELECT * FROM `like_$botid` WHERE id = '$from_id'")->num_rows;

$dislikes = $connect->query("SELECT * FROM `dislike_$botid` WHERE id = '$from_id'")->num_rows;

$views = $connect->query("SELECT * FROM `view_$botid` WHERE id = '$from_id'")->num_rows;

$profile = bot('getUserProfilePhotos',['user_id'=>$from_id])->result;

if($profile->total_count) $photos = reset($profile->photos);

bot('sendPhoto',[

'chat_id'=>$from_id,

'photo'=>(isset($photos) ? end($photos)->file_id : 'https://t.me/Mafia_nit/152'),

'caption'=>($settings['accounttext'] ? str_replace(['ID','FIRSTNAME','LASTNAME','USERNAME','LIKES','DISLIKES','VIEWS','WARN','TIMEJOIN','DATEJOIN','TIME','DATE','BOTUSER','BOTNAME'],[$from_id,$first_name,$last_name,$user_name,$likes,$dislikes,$views,$warn,$timej,$datej,$date,$time,$botuser,$botname],$settings['accounttext']) : "👤 شناسه کاربری : $from_id\n👍 تعداد فایل های لایک شده : $likes\n📂 تعداد فایل های دانلود شده : $views\n👎 تعداد فایل های دیس لایک شده : $dislikes\n⚠️ تعداد اخطار ها : $warn\n📆 تاریخ عضویت : $datej\n⏰ ساعت عضویت : $timej"),

'reply_markup'=>$menu

]);

}

elseif($text == "📚 راهنما"){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['helptext'] ? str_replace(['ID','FIRSTNAME','LASTNAME','USERNAME','WARN','TIMEJOIN','DATEJOIN','TIME','DATE','BOTUSER','BOTNAME'],[$from_id,$first_name,$last_name,$user_name,$warn,$timej,$datej,$date,$time,$botuser,$botname],$settings['helptext']) : "📚 متن راهنما تنظیم نشده است"),

'reply_markup'=>$menu

]);

}

elseif($text == "🆘 پشتیبانی"){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>($settings['supporttext'] ? str_replace(['ID','FIRSTNAME','LASTNAME','USERNAME','WARN','TIMEJOIN','DATEJOIN','TIME','DATE','BOTUSER','BOTNAME'],[$from_id,$first_name,$last_name,$user_name,$warn,$timej,$datej,$date,$time,$botuser,$botname],$settings['supporttext']) : "🆘 به بخش پشتیبانی خوشـ آمدید"),

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"🆘 پشتیبانی آنلاین",'callback_data'=>"support"]],

[['text'=>"🆘 پشتیبانی مستقیم",'url'=>"https://t.me/".($settings['supportid'] ? str_replace('@',(string) null,$settings['supportid']) : "username")]],

[['text'=>"•=•=•=•=•=•=•=•=•=•=•=•=•=•=•=•",'callback_data'=>"fake"]],

[['text'=>$date,'callback_data'=>"fake"],['text'=>'📆 تاریخ ◄','callback_data'=>"fake"]],

[['text'=>$time,'callback_data'=>"fake"],['text'=>'⏰ ساعت ◄','callback_data'=>"fake"]],

[['text'=>"•=•=•=•=•=•=•=•=•=•=•=•=•=•=•=•",'callback_data'=>"fake"]],

]])

]);

}

elseif($step == "support" and isset($update->message)){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ پیام شما با موفقیت برای پشتیبانی ارسال شد



🔐 اگر پیام دیگری دارید ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

foreach($admin as $me){

bot('forwardMessage',[

'chat_id'=>$me,

'from_chat_id'=>$from_id,

'message_id'=>$message_id

]);

bot('sendMessage',[

'chat_id'=>$me,

'text'=>"

ID : <code>$from_id</code>



🔰 پی وی کاربر <a href ='tg://user?id=$from_id'>".Htmlentitie($first_name)."</a> است

",

'parse_mode'=>'HTML'

]);

}

}

elseif(isset($text) and preg_match('/^\/([Cc][Rr][Ee][Aa][Tt][Oo][Rr])/',$text)){

$get = bot('getMe',[],ROOT);

if($get->ok){

$botuser = $get->result->username;

$botname = $get->result->first_name;

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚙ این ربات توسط رباتساز ( <a href ='https://t.me/$botuser'>".Htmlentitie($botname)."</a> ) ساخته شده است !

",

'parse_mode'=>'HTML'

]);

}

}

//-----------------------------------------------------------------------------------------------

elseif(in_array($from_id,$admin)){

if($text == "❄️ پنل مدیریت" or $text == "/panel" or $text == "/admin"){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

به پنل مدیریت خوش آمدید 🌷

",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

elseif($text == "📊 آمار"){

$countfile = $connect->query("SELECT id FROM `upload_$botid`")->num_rows;

$countmember = $connect->query("SELECT id FROM `user_$botid`")->num_rows;

$countonlines = $connect->query("SELECT * FROM `user_$botid` WHERE spam != '0' AND step != 'block'")->num_rows;

$counttoday = $connect->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 day"))->num_rows;

$countlastweek = $connect->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 week"))->num_rows;

$countlastmonth = $connect->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 month"))->num_rows;

$countblock = $connect->query("SELECT * FROM `user_$botid` WHERE step = 'block'")->num_rows;

$code = $connect->query("SELECT * FROM `user_$botid` WHERE date = '$date' ORDER BY `time` DESC LIMIT 3");

$result = null;

$i = 0;

while($res = $code->fetch_assoc()){

$i++;

$id = $res['id'];

$Jointime = $res['time'];

$Joindate = str_replace('-','/',$res['date']);

$yournamer = Htmlentitie(bot('getChatMember',['chat_id'=>$id,'user_id'=>$id])->result->user->first_name);

$result .= "

🎈 $i « <a href ='tg://user?id=$id'>$yournamer</a> » 

📆 تاریخ عضویت : $Joindate

⏰ ساعت عضویت : $Jointime

┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄┄┅┈┉┅┉┈┅┄

";

}

$get = bot('getMe',[],ROOT);

$onlines = '% '.floor(($countonlines / $countmember) * 100);

$onlinestoday = '% '.floor(($counttoday / $countmember) * 100);

$onlineslastweek = '% '.floor(($countlastweek / $countmember) * 100);

$onlineslastmonth = '% '.floor(($countlastmonth / $countmember) * 100);

$blockpercent = '% '.floor(($countblock / $countmember) * 100);

$updatetime = jdate("H:i:s Y/m/d",filectime(__FILE__));

$start = microtime(true);

$edit = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"♻️ در حال بارگذاری . . . !",

'parse_mode'=>'HTML'

])->result->message_id;

$finish = microtime(true);

$ping = round($finish - $start,3) * 1000;

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

⚡️ پینگ : $ping ms



♻️ آخرین تاریخ آپدیت : $updatetime



📂 تعداد فایل های آپلود شده : $countfile



📉 تعداد کل کاربران ربات : $countmember



❌ تعداد کاربران بلاک شده : $countblock | $blockpercent



🌟 تعداد کاربران فعال ربات : $countonlines | $onlines



🌕 تعداد کاربران فعال امروز : $counttoday | $onlinestoday



🌖 تعداد کاربران فعال هفته پیش : $countlastweek | $onlineslastweek



🌓 تعداد کاربران فعال یک ماه گذشته : $countlastmonth | $onlineslastmonth



".($result ? ("<b>📈 آخرین کاربران امروز ربات :</b>\n\n".$result) : null),

'parse_mode'=>'HTML',

'reply_markup'=>isset($get->result->username) ? json_encode(['inline_keyboard'=>[

[['text'=>"🔍 تصدیق آمار",'url'=>"https://t.me/".($get->result->username)."?start=Status_".$botid]],

]]) : null

]);

}

elseif($text == "📂 استخراج ممبر ها"){

if($from_id == $dev or in_array($from_id,$devs)){

$edit = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"♻️ در حال بررسی . . . !",

'parse_mode'=>'HTML'

])->result->message_id;

file_exists('Madeline') || mkdir('Madeline');

file_exists('Madeline/'.$botid) || mkdir('Madeline/'.$botid);

file_exists('Madeline/'.$botid.'/session') & DeleteFolder('Madeline/'.$botid.'/session');

file_exists('Madeline/'.$botid.'/session') || mkdir('Madeline/'.$botid.'/session');

if(file_exists('./vendor/autoload.php')){

require './vendor/autoload.php';

}else{

if(!file_exists('.madeline.php')) copy('https://phar.madelineproto.xyz/madeline.php','madeline.php');

require './madeline.php';

}

$setting = [

	'app_info'=>[

		'api_id'=>17064702,

		'api_hash'=>'f65880b9eededbee85346f874819bbc5',

	]

];

$bot = new \danog\MadelineProto\API('Madeline/'.$botid.'/session/bot.session',$setting);

$login = $bot->botLogin(API_KEY);

if(file_exists('Madeline/'.$botid.'/members.json')){

$member = json_decode(file_get_contents('Madeline/'.$botid.'/members.json'),true);

if($member['finish']){

if($member['time'] > strtotime("- 1 week") and !in_array($from_id,$devs)){

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"⚠️ شما فقط هفته ای یک بار میتوانید از این دستور استفاده کنید",

'parse_mode'=>'HTML'

]);

exit();

}else{

$pts = 1;

$qts = 0;

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"♻️ در حال بازیابی مجدد . . . !",

'parse_mode'=>'HTML'

]);

}

}else{

if($member['time'] > strtotime("- 10 minutes")){

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"⚠️ پروسه قبلی هنوز به اتمام نرسیده است ده دقیقه از پروسه قبلی باید گذشته باشد",

'parse_mode'=>'HTML'

]);

exit();

}else{

$pts = $member['pts'];

$qts = $member['qts'];

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"♻️ در حال ادامه بازیابی . . . !",

'parse_mode'=>'HTML'

]);

}

}

}else{

$pts = 1;

$qts = 0;

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"♻️ در حال شروع بازیابی . . . !",

'parse_mode'=>'HTML'

]);

}

$members = ['users'=>isset($member['users']) ? $member['users'] : []];

$lastedit = 0;

while(true){

$dialog = $bot->updates->getDifference(pts : $pts , date : time() , qts : $qts);

if($dialog['_'] == 'updates.differenceTooLong'){

while($pts <= $dialog['pts']){

$newpts = ($pts + $dialog['pts']) >> 1;

$difference = $bot->updates->getDifference(pts : $newpts , date : time() , qts : $qts);

if($difference['_'] == 'updates.differenceTooLong'){

$pts = $newpts + 1;

}else{

$dialog['pts'] = $newpts - 1;

}

}

continue;

}

if($dialog['_'] != 'updates.differenceEmpty'){

if($dialog['_'] == 'updates.difference') $result = $dialog['state'];

if($dialog['_'] == 'updates.differenceSlice') $result = $dialog['intermediate_state'];

$members['users'] = array_values(array_unique(array_merge($members['users'], array_column($dialog['users'],'id')),SORT_REGULAR));

$countmembers = count($members['users']);

$pts = $result['pts'];

$qts = $result['qts'];

$members['pts'] = $pts;

$members['qts'] = $qts;

$members['finish'] = false;

$members['time'] = time();

$members['count'] = $countmembers;

if($lastedit < time()){

$lastedit = strtotime("+ 10 second");

file_put_contents('Madeline/'.$botid.'/members.json',json_encode($members,448));

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : درحال جستجو ...

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

}

}else{

$bot->stop();

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : درحال وارد کردن اطلاعات به دیتابیس ...

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

$diff = array_diff($members['users'], [$botid]);

$insert = array_map(function($id) {
    return "('$id','none','".jdate("H:i:s")."','".jdate("Y/m/d")."')";
}, $diff);

$connect->query("INSERT IGNORE INTO `user_$botid` (`id` , `step` , `time` , `date`) VALUES ".implode(',',$insert));

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : تمامی ممبر ها بازیابی شدند !

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

$members['pts'] = 1;

$members['qts'] = 0;

$members['finish'] = true;

$members['time'] = time();

$members['count'] = $countmembers;

file_put_contents('Madeline/'.$botid.'/members.json',json_encode($members,448));

break;

}

if($timer < strtotime("- 2 hour")){

$bot->stop();

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : درحال وارد کردن اطلاعات به دیتابیس ...

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

$diff = array_diff($members['users'], [$botid]);

$insert = array_map(function($id) {
    return "('$id','none','".jdate("H:i:s")."','".jdate("Y/m/d")."')";
}, $diff);

$connect->query("INSERT IGNORE INTO `user_$botid` (`id` , `step` , `time` , `date`) VALUES ".implode(',',$insert));

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : پروسه بیشتر از دو ساعت طول کشید و متوقف شد

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

break;

}

}

/*

$dialog = $bot->getDialogs();

$members = array_column($dialog,'user_id');

$countmembers = count($members);

$insert = array_map(function($id){

return "('$id','none','".jdate("H:i:s")."','".jdate("Y/m/d")."')";

},$members);

$connect->query("INSERT IGNORE INTO `user_$botid` (`id` , `step` , `time` , `date`) VALUES ".implode(',',$insert));

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

🔰 وضعیت : تمامی ممبر ها بازیابی شدند !

👥 تعداد ممبر های بازیابی شده : $countmembers

⏳ زمان شروع پروسه : $time

",

'parse_mode'=>'HTML'

]);

*/

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

🔐 متاسفانه شما دسترسی به این دکمه را ندارید

",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}

elseif($text == "📥 آپلود"){

$connect->query("UPDATE `user_$botid` SET step = 'Upload-[]' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

📁 مدیا های خود را جهت آپلود کردن ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($text == "✔️ تبدیل به آلبوم" and substr($step, 0, 7) === "Upload-"){

$files = json_decode(explode("-",$step)[1]);

$count = count($files);

if($count >= 2 and $count <= 10){

$connect->query("UPDATE `user_$botid` SET step = 'Upload-[]' WHERE id = '$from_id' LIMIT 1");

foreach($files as $ids){

$connect->query("UPDATE `upload_$botid` SET multi = '$message_id' WHERE id = '$ids' LIMIT 1");

}

$download = EnDecode($message_id);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚠️ تنها عکس ها و فیلم ها و سند ها و آهنگ ها قابلیت ارسال بصورت آلبومی را دارند



📂 تعداد فایل های آلبوم شده : $count



🔗 لینک دانلود آلبوم : https://t.me/$botuser?start=Album_$download

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚠️ امکان تبدیل این فایل به یک آلبوم وجود ندارد

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif(substr($step, 0, 7) === "Upload-" and isset($update->message)){

$files = json_decode(explode("-",$step)[1]);

$count = count($files);

if(isset($update->message->text)){

foreach(['photo','video','photo','animation','video_note','voice','audio','sticker','document'] as $type){

$result = bot('send'.str_replace('_',(string) null,$type),[

'chat_id'=>$from_id,

$type=>$text,

'caption'=>'📂 فایل شما با موفقیت دانلود شد',

]);

if($result->ok){

$update->message = $result->result;

$message_id = $result->result->message_id;

break;

}

}

}

if(isset($update->message->animation)) [$file,$type] = [$update->message->animation,'animation'];

elseif(isset($update->message->audio)) [$file,$type] = [$update->message->audio,'audio'];

elseif(isset($update->message->voice)) [$file,$type] = [$update->message->voice,'voice'];

elseif(isset($update->message->video)) [$file,$type] = [$update->message->video,'video'];

elseif(isset($update->message->sticker)) [$file,$type] = [$update->message->sticker,'sticker'];

elseif(isset($update->message->document)) [$file,$type] = [$update->message->document,'document'];

elseif(isset($update->message->video_note)) [$file,$type] = [$update->message->video_note,'video_note'];

elseif(isset($update->message->photo)) [$file,$type] = [end($update->message->photo),'photo'];

else exit(bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚠️ لطفاً یک مدیا معتبر ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

])->ok);

$file_id = $file->file_id;

$file_size = GetSize($file->file_size,2);

$caption = $connect->real_escape_string($update->message->caption ?? '🎈 متن کپشن خالی است');

$download = EnDecode($message_id);

$connect->query("INSERT INTO `upload_$botid` (`id` , `file_id` , `file_size` , `type` , `password` , `protectcontent` , `caption` , `multi` , `time` , `date`) VALUES ('$message_id','$file_id','$file_size','$type','none','off','$caption','0','$time','$date')");

if(in_array($type,['audio','video','document','photo']) and $count < 10){

$count++;

$files[] = $message_id;

$connect->query("UPDATE `user_$botid` SET step = 'Upload-".json_encode($files)."' WHERE id = '$from_id' LIMIT 1");

}

$reply = bot('copyMessage',[

'chat_id'=>$from_id,

'from_chat_id'=>$from_id,

'message_id'=>$message_id,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"❌ محافظت از محتوا",'callback_data'=>"protectcontent-$message_id"]],

[['text'=>"🔖 تغییر کپشن",'callback_data'=>"caption-$message_id"]],

[['text'=>"🔐 تنظیم پسورد",'callback_data'=>"password-$message_id"]],

[['text'=>"🗑 حذف",'callback_data'=>"delete-$message_id"]],

]])

])->result->message_id;

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ مدیا شما با موفقیت آپلود شد



💫 اطلاعات مدیای آپلود شده :



🔗 لینک دانلود فایل : https://t.me/$botuser?start=$download



❄️ کپشن فایل : $caption



🎈 حجم فایل : $file_size



 ⏰ ساعت آپلود : $time



📆 تاریخ آپلود : $date

",

'reply_to_message_id'=>$reply,

'reply_markup'=>(($count >= 2 and $count <= 10) ? $upload : $back)

]);

}

elseif(substr($step, 0, 8) === "caption-" and isset($text)){

$exp = explode("-",$step);

$ids = $exp[1];

$reply = $exp[2];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$caption = $connect->real_escape_string($text);

$connect->query("UPDATE `upload_$botid` SET caption = '$caption' WHERE id = '$ids' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔖 کپشن مدیا‌ی شما با موفقیت تغییر پیدا کرد",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$reply,

'reply_markup'=>$panel

]);

bot('editMessageCaption',[

'chat_id'=>$from_id,

'message_id'=>$reply,

'caption'=>$caption,

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"❌ محافظت از محتوا",'callback_data'=>"protectcontent-$ids"]],

[['text'=>"🔖 تغییر کپشن",'callback_data'=>"caption-$ids"]],

[['text'=>"🔐 تنظیم پسورد",'callback_data'=>"password-$ids"]],

[['text'=>"🗑 حذف",'callback_data'=>"delete-$ids"]],

]])

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}

elseif(substr($step, 0, 9) === "password-" and isset($text)){

$exp = explode("-",$step);

$ids = $exp[1];

$reply = $exp[2];

if($file = $connect->query("SELECT * FROM `upload_$botid` WHERE id = '$ids' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$password = $connect->real_escape_string($text);

$connect->query("UPDATE `upload_$botid` SET password = '$password' WHERE id = '$ids' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

🔐 پسورد مدیای شما با موفقیت تغییر کرد



🔑 رمز : <tg-spoiler>".Htmlentitie($password)."</tg-spoiler>

",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$reply,

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"📁 فایل مورد نظر شما پیدا نشد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}

elseif($text == "⚙ تنظیمات"){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

⚙ چیزی را که می‌خواهید تنظیم کنید انتخاب کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"📄 تنظیم متن ها",'callback_data'=>"vartext"]],

[['text'=>"💫 متن استارت",'callback_data'=>"set-starttext"],['text'=>"📚 متن راهنما",'callback_data'=>"set-helptext"]],

[['text'=>"🆘 متن پشتیبانی",'callback_data'=>"set-supporttext"],['text'=>"🔙 متن برگشت",'callback_data'=>"set-backtext"]],

[['text'=>"🌟 متن تبلیغات",'callback_data'=>"set-adstext"],['text'=>"🔐 متن حساب کاربری",'callback_data'=>"set-accounttext"]],

[['text'=>"📢 متن جوین اجباری",'callback_data'=>"set-jointext"]],

[['text'=>"🆔 آیدی ها",'callback_data'=>"fake"]],

[['text'=>"🆘 آیدی پشتیبانی",'callback_data'=>"set-supportid"]],

[['text'=>"⏳ زمان ها",'callback_data'=>"fake"]],

[['text'=>"⚡️ زمان آنتی اسپم",'callback_data'=>"set-antispamtime"],['text'=>"🗑 زمان حذف فایل",'callback_data'=>"set-deletetime"]],

]])

]);

}

elseif(substr($step, 0, 4) === "set-" and isset($text)){

$type = explode("-",$step)[1];

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

if(substr($step, -4) === "text"){

$string = $connect->real_escape_string($text);

$connect->query("UPDATE `bot` SET $type = '$string' WHERE id = '$botid' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"📑 متن با موفقیت تغییر پیدا کرد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}elseif(substr($step, -2) === "id"){

if(preg_match('/^[a-z_A-Z_0-9]+$/ius',$text,$match)){

$connect->query("UPDATE `bot` SET $type = '{$match[0]}' WHERE id = '$botid' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🆔 آیدی با موفقیت تغییر پیدا کرد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ آیدی ارسالی باید فقط از حروف انگلیسی و اعداد انگلیسی و آندرلاین ( A-Z و a-z و _ و 9-0 ) باشد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}elseif(substr($step, -4) === "time"){

if(is_numeric($text)){

$connect->query("UPDATE `bot` SET $type = '$text' WHERE id = '$botid' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⏳ زمان با موفقیت تغییر پیدا کرد",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ لطفاً بصورت عدد مقدار را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}

}

elseif($text == "👤 ادمین ها"){

if($admins){

foreach($admins as $ids){

$key[] = [['text'=>bot('getChat',['chat_id'=>$ids])->result->first_name,'callback_data'=>"fake"],['text'=>"🗑 حذف",'callback_data'=>"deladmin|$ids"]];

}

}

$key[] = [['text'=>"✅ افزودن ادمین",'callback_data'=>"addadmin"]];

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✔️ لیست ادمین های ربات :

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>$key])

]);

}

elseif($step == "SetAdmins" and isset($text)){

if(is_numeric($text)){

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text' LIMIT 1")->fetch_assoc()){

if(in_array($text,$admin)){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ متاسفانه کاربر $text از قبل ادمین می‌باشد

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

$admins[] = $text;

$admin = json_encode($admins,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET admins = '$admin' WHERE id = '$botid' LIMIT 1");

$name = bot('getChat',['chat_id'=>$text])->result->first_name;

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ با موفقیت ادمین $name اضافه شد

",

'reply_markup'=>$panel

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ متاسفانه کاربر $text در ربات عضو نمیباشد

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ لطفاً آیدی عددی را بصورت عدد ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "📢 کانال جوین اجباری"){

if($channels){

foreach($channels as $links){

if(in_array($from_id,$devs) or isset($channelsettings[$links]['id']) === false or in_array($channelsettings[$links]['id'],$devs) === false){

$key[] = [['text'=>(is_numeric($links) and substr($links, 0, 4) === "-100") ? (bot('getChat',['chat_id'=>$links])->result->title ?? bot('getChat',['chat_id'=>$links],SAFE)->result->title ?? $links) : $links,'callback_data'=>"channel|$links"]];

}

}

}

$key[] = [['text'=>"✅ افزودن جوین اجباری",'callback_data'=>"addjoin"]];

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✔️ لیست کانال های تنظیم شده :

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>$key])

]);

}

elseif($step == "SetChannel" and isset($text)){

if(is_numeric($text)) $text = '-100'.$text;

if(isset($update->message->forward_from_chat)) $text = $update->message->forward_from_chat->id;

$chat = bot('getChat',['chat_id'=>$text]);

$safe = bot('getChat',['chat_id'=>$text],SAFE);

$getchat = $chat->ok ? $chat : $safe;

$id = $getchat->result->id ?? 0;

$type = $getchat->result->type ?? null;

$invitelink = $getchat->result->invite_link ?? null;

$usernames = $getchat->result->active_usernames ?? [];

if($type == 'channel' or ($update->message->forward_from_chat->type ?? null) == 'channel'){

// if(in_array('administrator',[bot('getChatMember',['chat_id'=>$text,'user_id'=>$botid])->result->status ?? null,bot('getChatMember',['chat_id'=>$text,'user_id'=>bot('getMe',[],SAFE)->result->id],SAFE)->result->status ?? null])){

if(($settings['safe'] == false and (bot('getChatMember',['chat_id'=>$text,'user_id'=>$botid])->result->status ?? null) === 'administrator') or (bot('getChatMember',['chat_id'=>$text,'user_id'=>bot('getMe',[],SAFE)->result->id],SAFE)->result->status ?? null) === 'administrator'){

if(array_filter($usernames,function($links) use ($channels) { return in_array(mb_strtolower('@'.$links),$channels); }) or in_array($id,$channels)){

if(is_numeric($text) and $invitelink) $text = $invitelink; elseif(is_numeric($text) and $usernames) $text = '@'.implode(' | @',$usernames);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ متاسفانه کانال $text از قبل تنظیم شده است

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

$channelsettings[mb_strtolower($text)]['id'] = $from_id;

$channelsetting = json_encode($channelsettings,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET channelsettings = '$channelsetting' WHERE id = '$botid' LIMIT 1");

$channels[] = mb_strtolower($text);

$channel = json_encode($channels,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$connect->query("UPDATE `bot` SET channel = '$channel' WHERE id = '$botid' LIMIT 1");

if(is_numeric($text) and $invitelink) $text = $invitelink; elseif(is_numeric($text) and $usernames) $text = '@'.implode(' | @',$usernames);

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ با موفقیت کانال $text تنظیم شد

",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}else{

if($settings['safe']){

$get = bot('getMe',[],SAFE);

$username = $get->result->username;

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ لطفاً ابتدا ربات جوین امن ( @$username ) را ادمین کانال خود کنید و سپس مجدداً برای ثبت کانال جدید اقدام کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ لطفاً ابتدا این ربات را ادمین کانال خود کنید و سپس مجدداً برای ثبت کانال جدید اقدام کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❌ لطفاً آیدی کانال معتبر ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "➕ افزایش اخطار"){

$connect->query("UPDATE `user_$botid` SET step = 'add' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "add" and isset($text) and is_numeric($text)){

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'addwarn-$text' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ تعداد اخطار مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ کاربر $text در ربات نیست",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif(substr($step, 0, 8) === "addwarn-" and isset($text) and is_numeric($text)){

$id = explode("-",$step)[1];

if(is_numeric($text)){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$connect->query("UPDATE `user_$botid` SET warn = warn + '$text' WHERE id = '$id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت تعداد $text اخطار به کاربر $id داده شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

bot('sendMessage',[

'chat_id'=>$id,

'text'=>"❗️تعداد $text اخطار از ادمین های ربات دریافت کردید",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ لطفاً فقط عدد ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "➖  کسر اخطار"){

$connect->query("UPDATE `user_$botid` SET step = 'low' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "low" and isset($text) and is_numeric($text)){

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'lowwarn-$text' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ تعداد اخطار مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ کاربر $text در ربات نیست",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif(substr($step, 0, 8) === "lowwarn-" and isset($text) and is_numeric($text)){

$id = explode("-",$step)[1];

if(is_numeric($text)){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$connect->query("UPDATE `user_$botid` SET warn = warn - '$text' WHERE id = '$id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت تعداد $text اخطار از کاربر $id گرفته شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

bot('sendMessage',[

'chat_id'=>$id,

'text'=>"❕تعداد $text اخطار توسط ادمین های ربات از شما گرفته شد",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ لطفاً فقط عدد ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "❌ بلاک کردن"){

$connect->query("UPDATE `user_$botid` SET step = 'blockid' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "blockid" and isset($text) and is_numeric($text)){

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'block' WHERE id = '$text' LIMIT 1");

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت کاربر $text بلاک شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

bot('sendMessage',[

'chat_id'=>$text,

'text'=>"❌ متاسفانه شما از ربات بلاک شدید",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ کاربر $text در ربات نیست",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "🔰 آنبلاک کردن"){

$connect->query("UPDATE `user_$botid` SET step = 'unblockid' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"🔰 ایدی کاربر مورد نظر را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "unblockid" and isset($text) and is_numeric($text)){

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text' LIMIT 1")->fetch_assoc()){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$text' LIMIT 1");

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت کاربر $text آنبلاک شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

bot('sendMessage',[

'chat_id'=>$text,

'text'=>"♻️ شما از ربات آنبلاک شدید",

'parse_mode'=>'HTML'

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"❌ کاربر $text در ربات نیست",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($text == "📨 پیام همگانی"){

if($sendall = $connect->query("SELECT * FROM `sendall` WHERE botid = '$botid' AND time != '0' LIMIT 1")->fetch_assoc()){

if($sendall['time'] >= strtotime("- 1 minutes")){

if($from_id == $sendall['fromid']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ پیام قبلی شما در صف ارسال است",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$sendall['messageid'],

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ یک پیام در ربات در صف ارسال است",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}else{

if($from_id == $sendall['fromid']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✉️ درحال تکمیل ارسال پیام قبلی شما ...",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$sendall['edit'],

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✉️ درحال تکمیل ارسال پیام قبلی ادمین ها ...",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

$get = bot('getMe',[],ROOT);

$i = $sendall['count'];

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$countmember = count($rows);

$start = microtime(true);

foreach(array_chunk(array_slice(array_column($rows,'id'),$sendall['count']),50) as $ids){

$i += count(botmulti('copyMessage',[

'chat_id'=>$ids,

'from_chat_id'=>$sendall['fromid'],

'message_id'=>$sendall['messageid']

]));

sleep(3);

$timer = time();

$connect->query("UPDATE `sendall` SET count = '$i' , time = '$timer' WHERE botid = '$botid' AND messageid = '{$sendall['messageid']}' LIMIT 1");

$percent = '% '.floor(($i / $countmember) * 100);

$x = $countmember - $i;

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$sendall['fromid'],

'message_id'=>$sendall['edit'],

'text'=>"

📉 تعداد کل کاربران ربات : $countmember

♻️ تعداد پیام های ارسال شده : $i

📨 تعداد پیام باقی مانده : $x

💯 درصد پیشرفت ارسال پیام : $percent

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML',

'reply_markup'=>isset($get->result->username) ? json_encode(['inline_keyboard'=>[

[['text'=>"🔍 تصدیق همگانی",'url'=>"https://t.me/".($get->result->username)."?start=Sendall_".$botid."_".$sendall['messageid']]],

]]) : null

]);

sleep(2);

}

$connect->query("UPDATE `sendall` SET time = '0' WHERE botid = '$botid' AND messageid = '{$sendall['messageid']}' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$sendall['fromid'],

'text'=>"✅ با موفقیت ارسال شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}else{

$connect->query("UPDATE `user_$botid` SET step = 'sendall' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"📨 پیام خود را ارسال کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($step == "sendall" and isset($update->message)){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$edit = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"♻️ در حال ارسال . . . !",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id

])->result->message_id;

$get = bot('getMe',[],ROOT);

$i = 0;

$connect->query("INSERT INTO `sendall` (`botid` , `fromid` , `messageid` , `edit` , `count` , `time`) VALUES ('$botid','$from_id','$message_id','$edit','$i','$timer')");

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$countmember = count($rows);

$start = microtime(true);

foreach(array_chunk(array_column($rows,'id'),50) as $ids){

$i += count(botmulti('copyMessage',[

'chat_id'=>$ids,

'from_chat_id'=>$from_id,

'message_id'=>$message_id

]));

sleep(3);

$timer = time();

$connect->query("UPDATE `sendall` SET count = '$i' , time = '$timer' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

$percent = '% '.floor(($i / $countmember) * 100);

$x = $countmember - $i;

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

📉 تعداد کل کاربران ربات : $countmember

♻️ تعداد پیام های ارسال شده : $i

📨 تعداد پیام باقی مانده : $x

💯 درصد پیشرفت ارسال پیام : $percent

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML',

'reply_markup'=>isset($get->result->username) ? json_encode(['inline_keyboard'=>[

[['text'=>"🔍 تصدیق همگانی",'url'=>"https://t.me/".($get->result->username)."?start=Sendall_".$botid."_".$message_id]],

]]) : null

]);

sleep(2);

}

$connect->query("UPDATE `sendall` SET time = '0' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت ارسال شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($text == "💭 فوروارد همگانی"){

if($sendall = $connect->query("SELECT * FROM `sendall` WHERE botid = '$botid' AND time != '0' LIMIT 1")->fetch_assoc()){

if($sendall['time'] >= strtotime("- 1 minutes")){

if($from_id == $sendall['fromid']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ پیام قبلی شما در صف ارسال است",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$sendall['messageid'],

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"⚠️ یک پیام در ربات در صف ارسال است",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

}else{

if($from_id == $sendall['fromid']){

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✉️ درحال تکمیل ارسال پیام قبلی شما ...",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$sendall['edit'],

'reply_markup'=>$panel

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✉️ درحال تکمیل ارسال پیام قبلی ادمین ها ...",

'parse_mode'=>'HTML',

'reply_markup'=>$panel

]);

}

$get = bot('getMe',[],ROOT);

$i = $sendall['count'];

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$countmember = count($rows);

$start = microtime(true);

foreach(array_chunk(array_slice(array_column($rows,'id'),$sendall['count']),50) as $ids){

$i += count(botmulti('forwardMessage',[

'chat_id'=>$ids,

'from_chat_id'=>$sendall['fromid'],

'message_id'=>$sendall['messageid']

]));

sleep(3);

$timer = time();

$connect->query("UPDATE `sendall` SET count = '$i' , time = '$timer' WHERE botid = '$botid' AND messageid = '{$sendall['messageid']}' LIMIT 1");

$percent = '% '.floor(($i / $countmember) * 100);

$x = $countmember - $i;

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$sendall['fromid'],

'message_id'=>$sendall['edit'],

'text'=>"

📉 تعداد کل کاربران ربات : $countmember

♻️ تعداد پیام های ارسال شده : $i

📨 تعداد پیام باقی مانده : $x

💯 درصد پیشرفت ارسال پیام : $percent

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML',

'reply_markup'=>isset($get->result->username) ? json_encode(['inline_keyboard'=>[

[['text'=>"🔍 تصدیق همگانی",'url'=>"https://t.me/".($get->result->username)."?start=Sendall_".$botid."_".$sendall['messageid']]],

]]) : null

]);

sleep(2);

}

$connect->query("UPDATE `sendall` SET time = '0' WHERE botid = '$botid' AND messageid = '{$sendall['messageid']}' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$sendall['fromid'],

'text'=>"✅ با موفقیت ارسال شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}else{

$connect->query("UPDATE `user_$botid` SET step = 'forall' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"💭 پیام خود را فوروارد کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif($step == "forall" and isset($update->message)){

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$edit = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"♻️ در حال ارسال . . . !",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id

])->result->message_id;

$get = bot('getMe',[],ROOT);

$i = 0;

$connect->query("INSERT INTO `sendall` (`botid` , `fromid` , `messageid` , `edit` , `count` , `time`) VALUES ('$botid','$from_id','$message_id','$edit','$i','$timer')");

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$countmember = count($rows);

$start = microtime(true);

foreach(array_chunk(array_column($rows,'id'),50) as $ids){

$i += count(botmulti('forwardMessage',[

'chat_id'=>$ids,

'from_chat_id'=>$from_id,

'message_id'=>$message_id

]));

sleep(3);

$timer = time();

$connect->query("UPDATE `sendall` SET count = '$i' , time = '$timer' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

$percent = '% '.floor(($i / $countmember) * 100);

$x = $countmember - $i;

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

📉 تعداد کل کاربران ربات : $countmember

♻️ تعداد پیام های ارسال شده : $i

📨 تعداد پیام باقی مانده : $x

💯 درصد پیشرفت ارسال پیام : $percent

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML',

'reply_markup'=>isset($get->result->username) ? json_encode(['inline_keyboard'=>[

[['text'=>"🔍 تصدیق همگانی",'url'=>"https://t.me/".($get->result->username)."?start=Sendall_".$botid."_".$message_id]],

]]) : null

]);

sleep(2);

}

$connect->query("UPDATE `sendall` SET time = '0' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت ارسال شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

/*

elseif($text == "💭 فوروارد همگانی ویژه"){

$connect->query("UPDATE `user_$botid` SET step = 'forallvip' WHERE id = '$from_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"💭 پیام خود را فوروارد کنید",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "forallvip" and isset($update->message)){

ini_set('memory_limit',-1);

$connect->query("UPDATE `user_$botid` SET step = 'none' WHERE id = '$from_id' LIMIT 1");

$edit = bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"♻️ در حال ارسال . . . !",

'parse_mode'=>'HTML',

'reply_to_message_id'=>$message_id

])->result->message_id;

file_exists('Madeline') || mkdir('Madeline');

file_exists('Madeline/'.$botid) || mkdir('Madeline/'.$botid);

// file_exists('Madeline/'.$botid.'/session') & DeleteFolder('Madeline/'.$botid.'/session');

file_exists('Madeline/'.$botid.'/session') || mkdir('Madeline/'.$botid.'/session');

if(file_exists('./vendor/autoload.php')){

require './vendor/autoload.php';

}else{

if(!file_exists('.madeline.php')) copy('https://phar.madelineproto.xyz/madeline.php','madeline.php');

require './madeline.php';

}

$setting = [

	'app_info'=>[

		'api_id'=>17064702,

		'api_hash'=>'f65880b9eededbee85346f874819bbc5',

	]

];

$bot = new \danog\MadelineProto\API('Madeline/'.$botid.'/session/bot.session',$setting);

$login = $bot->botLogin(API_KEY);

*/

/*

$bot->async(true);

$i = 0;

$connect->query("INSERT INTO `sendall` (`botid` , `fromid` , `messageid` , `edit` , `count` , `time`) VALUES ('$botid','$from_id','$message_id','$edit','$i','$timer')");

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$countmember = count($rows);

$start = microtime(true);

foreach(array_chunk(array_column($rows,'id'),300) as $ids){

$fileds = array_map(function($id) use ($from_id, $message_id) { return ['to_peer'=>$id,'from_peer'=>$from_id,'id'=>[$message_id]]; },$ids);

$i += count($fileds);

$bot->callFork($bot->messages->forwardMessages(['multiple'=>true,...$fileds]));

sleep(2);

$timer = time();

$connect->query("UPDATE `sendall` SET count = '$i' , time = '$timer' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

$percent = '% '.floor(($i / $countmember) * 100);

$x = $countmember - $i;

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

📉 تعداد کل کاربران ربات : $countmember

♻️ تعداد پیام های ارسال شده : $i

📨 تعداد پیام باقی مانده : $x

💯 درصد پیشرفت ارسال پیام : $percent

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML'

]);

sleep(2);

}

*/

/*

$start = microtime(true);

$all = $connect->query("SELECT * FROM `user_$botid`");

$rows = $all->fetch_all(MYSQLI_ASSOC);

$ids = array_column($rows,'id');

$fileds = array_map(function($id) use ($from_id, $message_id) { return ['to_peer'=>$id,'from_peer'=>$from_id,'id'=>[$message_id]]; },$ids);

$bot->messages->forwardMessages(['multiple'=>true,...$fileds]);

$finish = round(microtime(true) - $start,3);

bot('editMessageText',[

'chat_id'=>$from_id,

'message_id'=>$edit,

'text'=>"

⏰ مدت زمان ارسال پیام : $finish

",

'parse_mode'=>'HTML'

]);

$connect->query("UPDATE `sendall` SET time = '0' WHERE botid = '$botid' AND messageid = '$message_id' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"✅ با موفقیت ارسال شد",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

*/

elseif($text == "📩 پیام به کاربر"){

$from_id_safe = $connect->real_escape_string($from_id);

$connect->query("UPDATE `user_$botid` SET step = 'PvSId' WHERE id = '$from_id_safe' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✔️ ای دی عددی کاربر مورد نظر را ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

elseif($step == "PvSId" and isset($text) and is_numeric($text)){

$text_safe = $connect->real_escape_string($text);

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$text_safe' LIMIT 1")->fetch_assoc()){

$from_id_safe = $connect->real_escape_string($from_id);

$connect->query("UPDATE `user_$botid` SET step = 'PvPm-$text_safe' WHERE id = '$from_id_safe' LIMIT 1");

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

💬 پیام خود را ارسال کنید

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}else{

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

❗️این کاربر در ربات نیست

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

}

}

elseif(substr($step, 0, 5) === "PvPm-" and isset($text)){

$ids = explode("-",$step)[1];

$nameuser = Htmlentitie(bot('getChatMember',['chat_id'=>$ids,'user_id'=>$ids])->result->user->first_name);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ پیام شما با موفقیت به کاربر ( <code>$nameuser</code> ) ارسال شد

",

'parse_mode'=>'HTML',

'reply_markup'=>$back

]);

bot('sendMessage',[

'chat_id'=>$ids,

'text'=>"

🌹 شما یک پیام از پشتیبانی دارید 



✔️ پیام : <code>".Htmlentitie($text)."</code>

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"🆘 پیام به پشتیبانی",'callback_data'=>"support"]],

]])

]);

}

elseif(isset($update->message->reply_to_message) and isset($update->message->reply_to_message->forward_from) and isset($text)){

$forep_id = $update->message->reply_to_message->forward_from->id;

if($connect->query("SELECT * FROM `user_$botid` WHERE id = '$forep_id' LIMIT 1")->fetch_assoc()){

$nameuser = Htmlentitie(bot('getChatMember',['chat_id'=>$forep_id,'user_id'=>$forep_id])->result->user->first_name);

bot('sendMessage',[

'chat_id'=>$from_id,

'text'=>"

✅ پیام شما با موفقیت به کاربر ( <code>$nameuser</code> ) ارسال شد

",

'parse_mode'=>'HTML'

]);

bot('sendMessage',[

'chat_id'=>$forep_id,

'text'=>"

🌹 شما یک پیام از پشتیبانی دارید 



✔️ پیام : <code>".Htmlentitie($text)."</code>

",

'parse_mode'=>'HTML',

'reply_markup'=>json_encode(['inline_keyboard'=>[

[['text'=>"🆘 پیام به پشتیبانی",'callback_data'=>"support"]],

]])

]);

}

}

}

}

$connect->close();

?>