<?php

error_reporting(E_ALL);

date_default_timezone_set("Asia/Tehran");



//===[توکن]===//

define('ROOT','');//دست نزنید

define('SAFE','');//دست نزنید



//===[اطلاعات]===//

$devs = [];//دست نزنید



// ====== تنظیمات دیتابیس اول (ربات‌ها) ======

$server = 'localhost';

$username = '';//اطلاعات دیتا اول

$password = '';

$db = '';



try {

    $connect = new mysqli($server, $username, $password, $db);

    $connect->set_charset('utf8mb4');

    if ($connect->connect_error) {

        throw new Exception("اتصال به دیتابیس اول ناموفق: " . $connect->connect_error);

    }

} catch (Exception $e) {

    die("خطا در اتصال به دیتابیس اول: " . $e->getMessage());

}



// ====== تنظیمات دیتابیس دوم (رباتساز) ======

$server2 = 'localhost';

$username2 = '';//اطلاعات دیتا دوم

$password2 = '';

$db2 = '';



try {

    $database = new mysqli($server2, $username2, $password2, $db2);

    $database->set_charset('utf8mb4');

    if ($database->connect_error) {

        throw new Exception("اتصال به دیتابیس دوم ناموفق: " . $database->connect_error);

    }

} catch (Exception $e) {

    die("خطا در اتصال به دیتابیس دوم: " . $e->getMessage());

}

?>