<?php
error_reporting(E_ALL);
http_response_code(200);
if(is_callable('litespeed_finish_request')){
litespeed_finish_request();
}elseif(is_callable('fastcgi_finish_request')){
fastcgi_finish_request();
}
include("config.php");
//===[فانکشن های لازم]===//
function bot($method,$datas = [],$token = API_KEY){
$url = "https://api.telegram.org/bot".$token."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
//-----------------------------------------------------------------------------------------------
$bots = $connect->query("SELECT * FROM `bot`");
while($row = $bots->fetch_array()){
if($row['created'] < strtotime("- 1 month")){
$botid = $row['id'];
$countlastmonth = $database->query("SELECT * FROM `user_$botid` WHERE spam > ".strtotime("- 1 month"))->num_rows;
if($countlastmonth < $row['minimum']){
$botid_safe = $connect->real_escape_string($botid);
$connect->query("DELETE FROM `bot` WHERE id = '$botid_safe'");
$database->query("DROP TABLE `user_$botid_safe` , `upload_$botid_safe` , `like_$botid_safe` , `dislike_$botid_safe` , `view_$botid_safe`");
bot('sendMessage',[
'chat_id'=>$row['admin'],
'text'=>"
⚠️ تعداد کاربران <a href ='tg://openmessage?user_id=$botid'>ربات</a> شما کمتر از {$row['minimum']} نفر در یک ماه اخیر بوده است و متاسفانه از رباتساز ما حذف شد
",
'parse_mode'=>'HTML'
]);
}
}
}
?>