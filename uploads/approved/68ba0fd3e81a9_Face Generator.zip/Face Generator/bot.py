import logging
import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes


logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)


TOKEN = "BOT_TOKEN" #توکن ربات شما 


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "به ربات تولید چهره مصنوعی خوش آمدید! 🤖\n\n"
        "برای تولید یک چهره مصنوعی از دستور /generate استفاده کنید.\n\n"
        "Developer: https://info-me.netlify.app"
    )


async def generate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    
    message = await update.message.reply_text("Generating...")
    
    try:
 
        import time
        random_param = int(time.time())
        
        
        image_url = f"https://thispersondoesnotexist.com/?{random_param}"
        
        
        response = requests.get(image_url, stream=True)
        
        if response.status_code == 200:
            
            await update.message.reply_photo(
                photo=response.raw,
                caption="چهره مصنوعی تولید شده توسط ربات 🤖\n\nDeveloper: https://info-me.netlify.app"
            )
            
            await message.delete()
        else:
            await update.message.reply_text("خطا در تولید تصویر. لطفا دوباره تلاش کنید.")
            
            await message.delete()
    
    except Exception as e:
        logging.error(f"Error: {e}")
        await update.message.reply_text("خطا در تولید تصویر. لطفا دوباره تلاش کنید.")
        
        await message.delete()

def main():
    
    application = Application.builder().token(TOKEN).build()
    
  
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("generate", generate))
    
    
    application.run_polling()

if __name__ == "__main__":
    main()