
<?php
#================================================
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range)
{
 if(!$ok)
 {
  $lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
  $upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
  if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec)
  {
   $ok=true;
   }
  }
 }
if(!$ok)
{
 exit(header("location: https://google.com"));
 }
    
//-----------------------------Management--------------------------------------
$token = 'Token'; // token توکن ربات
$userbot = ' '; //userbot یوزر ربات
$admin = 5263094805; // adminsudo ایدی مالک
$dev = "siR_Multi"; // UserName Admin یوزر ادمین
$apiweb = "https://";// دامنه+پوشه 
define('API_KEY', $token);
//-------------------
?>