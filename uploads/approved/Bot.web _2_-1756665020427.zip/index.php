
<?php
//ارتقا یافته توسط @Online_suppor_t
////@Sourrce_Kade
flush();
ob_start();
set_time_limit(0);
error_reporting(0);
ob_implicit_flush(1);
$load = sys_getloadavg();
$telegram_ip_ranges = [
['lower' => '149.154.160.0', 'upper' => '149.154.175.255'], 
['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],    
];
$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf("%u", ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf("%u", ip2long($telegram_ip_range['upper']));
if($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true;
}
if(!$ok) die("کیر شدگان را تدبیری نیست :)))");
include('config.php');
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
    $from_id = $update->message->from->id;
    $chat_id = $update->message->chat->id;
    $tc = $update->message->chat->type;
    $text = $update->message->text;
    $first_name = $update->message->from->first_name;
    $message = $update->message;
    $message_id = $message->message_id;
    $photo = $update->message->photo;
	$caption = $update->message->caption;
    $reply_text = $update->message->reply_to_message->text;
    $reply_id = $update->message->reply_to_message->message_id;
    $fwd_from_id = $update->message->forward_from_chat->id;
    $fwd_from_title = $update->message->forward_from_chat->title;
    $fwd_from_tc = $update->message->forward_from_chat->type;
    $fwd_msg_id = $update->message->forward_from_message_id;
}elseif(isset($update->callback_query)){
    $chat_id    = $update->callback_query->message->chat->id;
    $data       = $update->callback_query->data;
    $query_id   = $update->callback_query->id;
    $message_id = $update->callback_query->message->message_id;
    $in_text    = $update->callback_query->message->text;
    $from_id    = $update->callback_query->from->id;
    $first_name = $update->callback_query->from->first_name;

    
}
if (isset($update->message)) {
    $message = $update->message;
    $message_id = $message->message_id;
    $text = $message->text;
    $chat_id = $message->chat->id;
    $tc = $message->chat->type;
    $first_name = $message->from->first_name;
    $from_id = $message->from->id;
    $namee = $message->from->first_name;
    if(isset($message->forward_from)){
        $FFID = $message->forward_from->id;
        $M = true;
    }
}
$kyps = ($text !="「 بازگشت  🔙 」");
$show = json_encode($update);
$to = file_get_contents("data/$from_id/to.txt");
$stats = file_get_contents("data/$from_id/stats.txt");
$da = $update->message->reply_to_message->forward_from->id;
@$onof = file_get_contents("data/onof.txt");
$type = file_get_contents("data/$from_id/type.txt");
$az = file_get_contents("data/$from_id/az.txt");
$query = $update->callback_query;
$messageid = $query->message->message_id;
$chatid = $query->message->chat->id;
$fromid = $query->message->from->id;
$callback_query_id = $query->id;
@$list = file_get_contents("data/member.txt");
//--------------------------//
function multibot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function SendPhoto($chat_id, $photo, $caption = null){
multibot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>$photo,
'caption'=>$caption
]);
}

function sendMessage($chat_id,$text,$keyboard = null) {
    multibot('sendMessage',[
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "Markdown",
        'disable_web_page_preview' => true,
        'reply_markup' => $keyboard
    ]);
}

function EditMessage($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
multibot('editMessagetext',[
'chat_id'=>$chatid,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
}

function deletemessage($chat_id,$message_id) {
    multibot('deletemessage',[
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function rand_string( $length ) {
$chars = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ*&#~$-@";
return substr(str_shuffle($chars),0,$length);
}

function SendDocument($chat_id,$document,$caption = null){
	multibot('SendDocument',[
	'chat_id'=>$chat_id,
	'document'=>$document,
	'caption'=>$caption
	]);
}

function gcmc($chat_id,$token) {
  $url = 'https://api.telegram.org/bot'.$token.'/getChatMembersCount?chat_id='.$chat_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->result;
  return $result;
}

function ForwardMessage($chatid,$from_chat,$message_id){
	multibot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	
}

function Download($link, $path){
    $file = fopen($link, 'r') or die("Can't Open Url !");
    file_put_contents($path, $file);
    fclose($file);
    return is_file($path);
  }
  
  function sa($chat_id, $action){
 multibot('sendaction',[
 'chat_id'=>$chat_id,
 'action'=>$action
 ]);
 }
 function objectToArrays($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        if (is_object($object)) {
            $object = get_object_vars($object);
        }
        return array_map("objectToArrays", $object);
    }
if(!is_dir("data")){
    mkdir("data");
    touch('data/member.txt');
}
        

$step = file_get_contents("data/$from_id/step.txt");

///////////////////////////////////////////////////////

$idgp1 = -1001637035414; // Channel Id

$ch1 = "https://t.me/ezzipaneleng"; // Channel User

$truechannel1 = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=$idgp1&user_id=$from_id"));

$tch1 = $truechannel1->result->status;

///////////////////////////////////////////////////////

$key = json_encode(['inline_keyboard'=>[
[['text'=>'💯پنل وبهوک♻️', 'callback_data'=>"a"],['text'=>'💯پنل کرون⚡','callback_data'=>"b"]],
],
'resize_keyboard'=>true]);

///////////////////////////////////////////////////////

$a = json_encode(['inline_keyboard'=>[
[['text'=>'تنظیم وبهوک♻️️', 'callback_data'=>"cvb"],['text'=>'حذف وبهوک❌','callback_data'=>"zare"]],
[['text'=>'اطلاعات توکن⁉️️️', 'callback_data'=>"touu"]],
[['text'=>'پاکسازی آپدیت های درحال انتظار ❗️️️', 'callback_data'=>"oooo"]],
],
'resize_keyboard'=>true]);

////////////////////////////////////////////////////////

$b = json_encode(['inline_keyboard'=>[
[['text'=>'1️️', 'callback_data'=>"uuuui"],['text'=>'2','callback_data'=>"zxc"]],
[['text'=>'5️️️', 'callback_data'=>"joo"],['text'=>'10','callback_data'=>"zae"]],
[['text'=>'15️️️', 'callback_data'=>"ooo"],['text'=>'30','callback_data'=>"ze"]],
],
'resize_keyboard'=>true]);

////////////////////////////////////////////////////////

$back = json_encode(['inline_keyboard'=>[
[['text'=>'「 بازگشت  🔙 」', 'callback_data'=>"a"]],
],
'resize_keyboard'=>true]);

////////////////////////////////////////////////////////

$panel = json_encode(['keyboard'=>[
    [['text'=>"「 پیام همگانی 🗳 」"],['text'=>"「 آمار 📊 」"]],
    [['text'=>"「 روشن ✅ 」"],['text'=>"「 خاموش ❎ 」"]],
    [['text'=>"「 بازگشت  🔙 」"]],
],'resize_keyboard'=>true]);
$up = json_encode(['keyboard'=>[
    [['text'=>'............']],
],'resize_keyboard'=>true]);

////////////////////////////////////////////////////////////////
$to =  file_get_contents("data/$from_id/token.txt");
$url =  file_get_contents("data/$from_id/url.txt");
////////////////////////////////////////////////////////////////
//--------------/start---------------//

if(in_array($from_id, $list['ban'])){
sm($chat_id,"
شما از این ربات مسدود شده اید ❌
",null);
exit();
}else{
function Spam($from_id){
@mkdir("data/spam");
$spam_status = json_decode(file_get_contents("data/spam/$from_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status = [1,time()+2];
}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 2){
$time = time() + 10;
$spam_status = ["time $time"];
file_put_contents("data/spam/$from_id.json",json_encode($spam_status,true));
multibot('sendMessage',[
'chat_id'=>$from_id,
'text'=>"❗️ شما به دلیل اسپم 10 ثانیه از ربات بلاک شدید."
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];
}
}else{
$spam_status = [1,time()+2];
}
}else{
$spam_status = [1,time()+2];
}
file_put_contents("data/spam/$from_id.json",json_encode($spam_status,true));
}
}
Spam($from_id);
if($onof == "off" && $from_id != $admin){
multibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ربات خاموش میباشد",
null, 
'reply_markup'=>json_encode([
'remove_keyboard'=>true,
])
]);
return false;
exit();
}

///==============///
////@Sourrce_Kade
if($text == "/start"){
    sendMessage($from_id,"*
سلام به ربات وبهوک من خوش آمدید ߷
برای استفاده از ربات از منو زیر شروع کنید 👇
🆔 - @
    *",$key);
    file_put_contents("data/$from_id/step.txt","no");
        file_put_contents("data/$from_id/token.txt","0");
        file_put_contents("data/$from_id/url.txt","0");
    
if(!is_dir("data/$from_id")){
    mkdir("data/$from_id");
    file_put_contents("data/$from_id/step.txt","no");
    file_put_contents("data/$from_id/token.txt","0");
    file_put_contents("data/$from_id/url.txt","0");
    $file = fopen("data/member.txt", "a") or die("Unable to open file!");
    fwrite($file, "$from_id\n");
    fclose($file);
}
exit();
}

elseif (strpos($text, '/start') !== false) {
$newid = str_replace("/start ", "", $text);
if (strpos($list, "$from_id") !== false){
multibot('sendMessage',[
'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
'text'=>"
‼️ شما قبلا ربات استارت کردید و ممکن نیست دوباره با لینک زیرمجموعه گیری جدید وارد ربات بشین 💎",
'reply_markup'=>$key
]);
}else{
    $newid = str_replace("/start ", "", $text);
  if($tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
 multibot('sendmessage', array('chat_id' => $from_id,
'text' => '*💡 ابتدا باید وارد کانال زیر شوید 

👇 بعد روی «عضو شدم ✅» کلیک کنید.*',
 'reply_markup' => 
 json_encode(['inline_keyboard' => [
[["text"=>"ورود به کانال","url"=>"$ch1"]],
[["text"=>"عضو شدم ✅","url"=>"https://t.me/$userbot?start=".$newid]]
]
]) , 'parse_mode' => 'MarkDown'));
exit();
}

if(!is_dir("data/$from_id")){
    mkdir("data/$from_id");
    file_put_contents("data/$from_id/step.txt","no");
    $file = fopen("data/member.txt", "a") or die("Unable to open file!");
    fwrite($file, "$from_id\n");
    fclose($file);
}
@$sho = file_get_contents("data/$newid/coin.txt");
$getsho = $sho + 1;
file_put_contents("data/$newid/coin.txt", $getsho);
@$sea = file_get_contents("data/$newid/member.txt");
$getsea = $sea + 1;
file_put_contents("data/$newid/member.txt", $getsea);
$user = file_get_contents('data/member.txt');
$members = explode("\n", $user);
if(!in_array($from_id, $members)){
$add_user = file_get_contents('data/member.txt');
$add_user .= $from_id . "\n";
@$sea = file_get_contents("data/$from_id/member.txt");
file_put_contents("data/$chat_id/membrs.txt", "0");
file_put_contents('users.txt', $add_user);
}
multibot('sendMessage',[
'chat_id'=>$newid,
 'message_id'=>$message_id + 1,
'text'=>"کاربر [$first_name](tg://openmessage?user_id=$from_id) ⭐️

یک کاربر با لینک دعوت شما به ربات اومد 🎉

و شما یک سکه هدیه گرفتید 💰
",
'disable_web_page_preview' => true,
'parse_mode'=>'Markdown',
]);
multibot('sendMessage',[
'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
'text'=>"*
سلام به ربات وبهوک من خوش آمدید ߷
برای استفاده از ربات از منو زیر شروع کنید 👇
🆔 - @
*",
'parse_mode'=>'MarkDown',  
'reply_markup'=>$key
]);
}
}
 if($tch1 != 'member' && $tch1 != 'creator' && $tch1 != 'administrator'){
 multibot('sendmessage', array('chat_id' => $from_id,
'text' => '💡 ابتدا باید وارد کانال زیر شوید 

👇 بعد روی «عضو شدم ✅» کلیک کنید.',
 'reply_markup' => 
 json_encode(['inline_keyboard' => [
[["text"=>"ورود به کانال","url"=>"$ch1"]],
[["text"=>"عضو شدم ✅","url"=>"https://t.me/$userbot?start"]],
]]), 
'parse_mode' => 'MarkDown'));
exit();
}
if($text == "「 بازگشت  🔙 」"){
    sendMessage($from_id,"به منو اصلی برگشتید 🔙

لطفاً از منوی زیر انتخاب کنید 💎⬇️",$key);
    file_put_contents("data/$from_id/step.txt","no");
exit();
}

//--------------|/start|---------------//

elseif($data == "a"){
   file_put_contents("data/$from_id/step.txt","none");
multibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
به بخش وبهوک ربات ما خوش آمدید 💎*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'=>$a
]);
}

//////////////////////////////////////////////////////

elseif($data == "b"){
   file_put_contents("data/$from_id/step.txt","none");
multibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
به بخش کرونجاب ربات ما خوش آمدید 💎*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'=>$b
]);
}
////@Sourrce_Kade
///////////////////////////////////////////////////////

elseif($data == "cvb"){
   file_put_contents("data/$from_id/step.txt","to");
multibot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
✨ لطفا جهت تنظیم وبهوک ، توکن ربات خود را از بــات فــادر 🤖 برای ما ارسال کنید . . .❕️*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'=>$setweb
]);
}
elseif($step == "to"){
$token = $text;

    $amir1 = json_decode(file_get_contents("https://api.telegram.org/bot" . $token . "/getwebhookinfo"));
    $amir2 = json_decode(file_get_contents("https://api.telegram.org/bot" . $token . "/getme"));
        //==================
    $tik2 = objectToArrays($amir1);
    $ur = $tik2["result"]["url"];
    $ok2 = $tik2["ok"];
    $tik1 = objectToArrays($amir2);
    $un = $tik1["result"]["username"];
    $fr = $tik1["result"]["first_name"];
    $id = $tik1["result"]["id"];
    $ok = $tik1["ok"];
    if ($ok != 1) {
        //Token Not True
        multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*لطفا توکن را به درستی وارد کنید ❗️*",
'parse_mode'=>'MarkDown',  
    ]);
    } else{
    file_put_contents("data/$from_id/step.txt","url");
    file_put_contents("data/$from_id/token.txt",$text);
 multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
توکن شما با موفقیت تایید شد ♻️

لطفا آدرس وبهوک خود را ارسال کنید ❗️

دقت کنید حتما با https  وارد شود ❗️*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'=>$setweb
  ]);
}
}
//////////////////////////
elseif($step == "url"){
if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$text))
  {
multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"لطفا در ارسال لینک دقت کنید ♥️",
  ]);
 }
 else {

$to =  file_get_contents("data/$from_id/token.txt");
$amir = json_decode(file_get_contents("$apiweb/webhook.php?type=getme&token=$to"), true);
$s1 = $amir["result"]["first_name"];
$s2 = $amir["result"]["username"];
file_put_contents("data/$from_id/step.txt","no");
file_put_contents("data/$from_id/url.txt",$text);

multibot('sendmessage',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"*
    اسم ربات 🔖 
🔖 - $s1
ایدی ربات 🆔 
🆔 - @$s2
توکن ربات ♻️ 
♻️ - $to
لینک برای وهوک 🗳 
🗳 - $text
برای ست کردن وبهوک بر روی دکمه زیر کلیک کنید 🌹
*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
         'reply_markup'=>json_encode([
 'resize_keyboard'=>true,
 'keyboard'=>[
 [['text'=>"「 بازگشت  🔙 」"],['text'=>"/SetWebHook"]],
 ]])
  ]);
 }
}
//////////////////////////

elseif($text == "/SetWebHook" ){
if($to != "no"){
    multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗️",
  ]);
  sleep(1);
 multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
      'text'=>"در حال ست کردن وبهوک . . .❗️",
  ]);
  $am1 = json_decode(file_get_contents("$apiweb/webhook.php?type=getme&token=$to"), true);
$botuser = $am1["result"]["username"];
  file_get_contents("https://api.telegram.org/bot$to/setwebhook?url=$url");
  file_get_contents("$apiweb/webhook.php?type=setwebhook&token=$to&url=$url");
    sleep(1);
 multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
      'text'=>"ست وبهوک با موفیقت انجام شد ❗️
🆔 - @$botuser",
  ]);
  file_put_contents("data/$from_id/step.txt","no");
 multibot('sendmessage',[
 'chat_id'=>$chat_id,
      'message_id'=>$message_id + 1,
      'text'=>"️
      برای ورود به ربات وبهوک شده کلیک کنید ♥️
🆔 - @",
        'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'inline_keyboard'=>[
[['text'=>"ورود به ربات 🤖","https://t.me/$botuser"],['text'=>"「 بازگشت  🔙 」","https://t.me//$userbot"]],
]
])
 ]);
}
}

//////////////////////////////////////////////////////// >"
elseif($data == "zare"){
file_put_contents("data/$from_id/step.txt","del");
multibot('sendMessage', [
'chat_id' =>$chat_id,
'text' => "*
✨ لطفا جهت حذف وبهوک ، توکن ربات خود را از بــات فــادر 🤖 برای ما ارسال کنید . . .❕️*",
'parse_mode'=>'MarkDown',  
'reply_markup'=>$back
]);
}

elseif($step == "del" && $text != "/start"){
  file_get_contents("https://api.telegram.org/bot$text/sendMessage?chat_id=$chat_id&text=ربات با موفقیت خاموش شد ♻️ 《 @WebHookManBot 》");
$a = json_decode(file_get_contents("$apiweb/webhook.php?type=deletewebhook&token=$text"), true);
$id = $a["description"];
if($ls['ok']== false){
if($ls['ok']== true){
}else{
sleep(1);
multibot('sendMessage', [
'chat_id' =>$chat_id,
'text' => "
کمی صبر کنید  . . . ❗",
]);
sleep(1);
 multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
      'text'=>"در حال حذف کردن وبهوک . . .❗️",
]);
sleep(1);
multibot('sendMessage', [
'chat_id' =>$chat_id,
'text' => "
دلیت وبهوک با موفیقت انجام شد ❗️
🆔 - @WebHookManBot
",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'
]);
file_put_contents("data/$from_id/step.txt","no");
exit();
}
}else{
multibot('sendMessage', [
'chat_id' =>$chat_id,
'text' => "*
*لطفا توکن را به درستی وارد کنید ❗️
*",
'parse_mode'=>'MarkDown',  
'reply_to_message_id'=>$message_id,
'reply_markup'
]);
file_put_contents("data/$from_id/step.txt","no");
exit();
}
}
////////////////////////////////////////////////////////
elseif($data == "touu"){
    file_put_contents("data/$from_id/step.txt","token");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت اطلاعات وبهوک ، توکن ربات خود را از بــات فــادر 🤖 برای ما ارسال کنید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "token"){
$token = $text;

    $amir1 = json_decode(file_get_contents("https://api.telegram.org/bot" . $token . "/getwebhookinfo"));
    $amir2 = json_decode(file_get_contents("https://api.telegram.org/bot" . $token . "/getme"));
        //==================
    $tik2 = objectToArrays($amir1);
    $ur = $tik2["result"]["url"];
    $ok2 = $tik2["ok"];
    $tik1 = objectToArrays($amir2);
    $un = $tik1["result"]["username"];
    $fr = $tik1["result"]["first_name"];
    $id = $tik1["result"]["id"];
    $ok = $tik1["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "لطفا توکن را به درستی وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"اسم ربات 🔖 
$fr
ایدی ربات 🆔 
🆔 - @$un
توکن ربات ♻️ 
♻️ - $token
لینک وبهوک شده 🗳 
🗳 - $ur
",
  ]);
}
}

/////////////////////////////////////////////////////////

elseif($data == "oooo"){
    file_put_contents("data/$from_id/step.txt","ex");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت اطلاعات وبهوک ، توکن ربات خود را از بــات فــادر 🤖 برای ما ارسال کنید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "ex"){
    
$link = json_decode(file_get_contents("$apiweb/webhook.php?type=webhookinfo&token=$text"), true);
    $up = $link["result"]["pending_update_count"];
    $ok = $link["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "لطفا توکن را به درستی وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"$up آپدیت در حال انتظار موجود میباشد ❗️
",
  ]);
}
}

//////////////////////////////////////////////////////////

elseif($text == "پاکسازی آپدیت های در حال انتظار 💎"){
    file_put_contents("data/$from_id/step.txt","delup");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت اطلاعات وبهوک ، توکن ربات خود را از بــات فــادر 🤖 برای ما ارسال کنید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "delup"){
$a = json_decode(file_get_contents("$apiweb/webhook.php?type=deleteupdate&token=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "لطفا ابتدا تنطیم وبهوک را انجام دهید 💎");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
پاکسازی آپدیت با موفقیت انجام شد ❗️",
  ]);
}
}
///////////////////////////////////////////////////////////

elseif($data == "uuuui"){
    file_put_contents("data/$from_id/step.txt","cr1");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr1"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=2&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}

elseif($data == "zxc"){
    file_put_contents("data/$from_id/step.txt","cr2");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr2"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=2&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}

elseif($data == "joo"){
    file_put_contents("data/$from_id/step.txt","cr5");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr5"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=5&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}

elseif($data == "zae"){
    file_put_contents("data/$from_id/step.txt","cr10");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr10"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=10&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}

elseif($data == "ooo"){
    file_put_contents("data/$from_id/step.txt","cr15");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr15"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=15&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}
elseif($data == "ze"){
    file_put_contents("data/$from_id/step.txt","cr30");
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
✨ لطفا جهت کرونجاب آدرس اینترنتی خود را با https وارد نمایید . . .❕️*",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$back
  ]);
}
elseif($step == "cr30"){
$a = json_decode(file_get_contents("$apiweb/cron.php?time=30&url=$text"), true);
    $ok = $a["ok"];
    $ok1 = $b["ok"];
    if ($ok != 1) {
        //Token Not True
        SendMessage($chat_id, "آدرس وارد شده را درست وارد کنید ❗️");
    } else{
    file_put_contents("data/$from_id/step.txt","no");
    
 	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"کمی صبر کنید  . . . ❗",
  ]);
  sleep(1);
	multibot('editmessagetext',[
    'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
    'text'=>"
کرونجاب با موفقیت انجام شد 💎",
  ]);
}
sleep(1);
	multibot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"*
به منوی اصلی بازگشتید قربان ❗️",
    'parse_mode'=>'MarkDown',
'reply_markup'=>$key
  ]);
}


//--------------------( panel )----------------------//
    
    if($text == "/panel" && $chat_id == $admin){
        sendMessage($from_id,'به پنل مدیریت خوش اومدین',$panel);
    }
    

if($text == "「 آمار 📊 」" && $chat_id == $admin){
        $user = file_get_contents("data/member.txt");
        $user_id = explode("\n", $user);
        $user_count = count($user_id) -1;
        sendMessage($admin,
        
        
        
        "
     امار ربات: $user_count
         "
        
        ,$panel);
    }
   
 
if($text == "「 پیام همگانی 🗳 」" && $chat_id == $admin) {
    file_put_contents("data/$from_id/step.txt", "send2all");
    multibot('sendMessage',[
        'chat_id' => $admin,
        'text' => "پیامتون رو در قالب متن بفرستید تا اون رو برای تمام ممبر ها ارسال کنم !",
        'parse_mpde' => "Markdown",
        'reply_markup' => $panel,
    ]);
    }
elseif($step == "send2all"){

    file_put_contents("data/$from_id/step.txt", "none");

    multibot('sendMessage', [
        'chat_id' => $from_id,
        'text' => "ربات درحال ارسال پیام شما به تمام اعضا میباشد
بعد از ارسال پیام همگانی ، اتمام کار رو بهت اعلام میکنم :)
لطفا تا پایان عملیات دستوری ارسال نکنید !"
    ]);

    $all_member = fopen( "data/member.txt", "r");
    while( !feof( $all_member)) {
    $user = fgets( $all_member);

    multibot('sendMessage',[
        'chat_id' => $user,
        'text' => $text,
        'parse_mode' => "Markdown"
    ]);
    }

    sleep('3.3');

    multibot('sendMessage', [
        'chat_id' => $from_id,
        'text' => "عملیات ارسال پیام همگانی با موفقیت به پایان رسید
پیام شما به تمامی اعضای ربات ارسال شد"
    ]);

    }

elseif($text == "「 روشن ✅ 」"){
file_put_contents("data/onof.txt","on");
 multibot('sendMessage',[
'chat_id'=>$admin,
'text'=>"ربات هم اکنون در دسترس قرار گرفت ✅",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"「 بازگشت  🔙 」"],
],
]
])
]);
}
elseif($text == "「 خاموش ❎ 」" && $chat_id == "$admin"){
file_put_contents("data/onof.txt","off");
 multibot('sendMessage',[
'chat_id'=>$admin,
'text'=>"ربات با موفقیت از دسترس کاربران خارج شد🚫",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[
['text'=>"「 بازگشت  🔙 」"],
],
]
])
]);
}

unlink('error_log');
?>
