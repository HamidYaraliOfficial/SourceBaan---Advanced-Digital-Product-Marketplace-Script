<?php
/////////////////////////////////////////////////////////
ob_start();
error_reporting(0);
header('Content-Type: application/json');
date_default_timezone_set('Asia/tehran');
function checktoken($token){
/////////////////////////////////////////////////////////
$amir = json_decode(file_get_contents("https://api.telegram.org/bot$token/getme"),true);
    if($amir['ok'] == 1){
        return true;
    }
}
/////////////////////////////////////////////////////////

if($_GET['type'] == "setwebhook"){
    if(checktoken($_GET['token']) == true){

        $a1 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET ['token']."/setwebhook?url=".$_GET['url'].""),true);
        $sa = $a1['description'];
        print(json_encode(array('ok'=>true,'result'=>$sa,'Dev'=>'@siR_Multi', 'Channel'=>'@Multi_Team')));
    }
else{
        print(json_encode(array('ok'=>false,'description'=>"Token Not Found!")));
    }
}
/////////////////////////////////////////////////////////

if($_GET['type'] == "deletewebhook"){
    if(checktoken($_GET['token']) == true){
        $b1 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET ['token']."/deletewebhook"),true);
        $sd = $b1['description'];
        print(json_encode(array('ok'=>true,'result'=>$sd,'Dev'=>'@siR_Multi', 'Channel'=>'@Multi_Team')));
    }
else{
        print(json_encode(array('ok'=>false,'description'=>"Token Not Found!")));
    }
}

//////////////////////////////////////////////////////////

if($_GET['type'] == "webhookinfo"){
    if(checktoken($_GET['token']) == true){
        $m1 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET['token']."/getwebhookinfo"),true);
        $qa1 = $m1['result']['url'];
        $qa2 = $m1['result']['pending_update_count'];
        $qa3 = $m1['result']['max_connections'];
        $qa4 = $m1['result']['ip_address'];
        print(json_encode(array('ok'=>true,'Dev'=>'@siR_Multi','result'=>array('url'=>$qa1,'pending_update_count'=>$qa2,'max_connections'=>$qa3,'ip_address'=>$qa4))));
    }
else{
        print(json_encode(array('ok'=>false,'description'=>"Token Not Found!")));
    }
}


//////////////////////////////////////////////////////////

if($_GET['type'] == "getme"){
    if(checktoken($_GET['token']) == true){

        $c1 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET ['token']."/getme"),true);
        $qp1 = $c1['result']['id'];
        $qp2 = $c1['result']['first_name'];
        $qp3 = $c1['result']['username'];
        $qp4 = $c1['result']['can_join_groups'];
        $qp5 = $c1['result']['supports_inline_queries'];
        
        print(json_encode(array('ok'=>true,'Dev'=>'@siR_Multi','result'=>array('id'=>$qp1,'first_name'=>$qp2,'username'=>$qp3,'can_join_groups'=>$qp4,'supports_inline_queries'=>$qp5))));
    }
else{
        print(json_encode(array('ok'=>false,'description'=>"Token Not Found!")));
    }
}

//////////////////////////////////////////////////////////

if($_GET['type'] == "deleteupdate"){
    if(checktoken($_GET['token']) == true){
        $z1 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET['token']."/getwebhookinfo"),true);
        $url = $z1['result']['url'];
        
        $z2 = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET['token']."/setwebhook?url=$url&drop_pending_updates=true"),true);
        $ds = $z2['description'];
        print(json_encode(array('ok'=>true,'result'=>$ds,'Dev'=>'@siR_Multi', 'Channel'=>'@Multi_Team')));
    }
else{
        print(json_encode(array('ok'=>false,'description'=>"Token Not Found!")));
    }
}

//////////////////////////////////////////////////////////