<?php
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
$list = json_decode(file_get_contents("data/list.json"), true);
//------------------------------------------------------------------
if(preg_match('/^[!\/#]?(stats|آمار|امار)$/i',$text) || $text == "📊 آمار"){
	$user = count($list['user']);
	$group = count($list['group']);
	$ping = pingDomain($_SERVER['HTTP_HOST']);
	SendMessage($chat_id, "■ آمار کنونی ربات :\n\n• کاربران ربات : *$user*\n• گروه های مدیریتی : *$group*\n• پینگ هاست : *$ping*\n\n", 'MarkDown', $message_id);
}
elseif(preg_match('/^[!\/#]?(var_dump|print_r)$/i',$text)){
	SendMessage($chat_id, print_r($up, true), null, $message_id);
}
//------------------------------------------------------------------
if(preg_match('/^[!\/#]?(banall|مسدود)$/i',$text) and isset($reply) and $tc != 'private'){
    if(!in_array($reply_id, $Dev)){
        if(!in_array($reply_id, $dataBase['banall'])){
		    $dataBase['banall'][] = $reply_id;
		    file_put_contents("data/data.json",json_encode($dataBase));
		    KickAll($reply_id);
		    SendMessage($chat_id, "■ کاربر [$reply_id](tg://user?id=$reply_id) مسدود همگانی شد.", 'MarkDown', $message_id);
        }else{
		    SendMessage($chat_id, "■ کاربر [$reply_id](tg://user?id=$reply_id) مسدود همگانی شده بود!", 'MarkDown', $message_id);
	    }
    }
}
elseif(preg_match('/^[!\/#]?(banall|مسدود) @(.*)$/i', $text, $match)){
	$id = getIdUserName($match[2]);
	if($id != false){
		if(!in_array($id, $Dev)){
			if(!in_array($id, $dataBase['banall'])){
				$dataBase['banall'][] = $id;
				file_put_contents("data/data.json",json_encode($dataBase));
				KickAll($id);
				SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی شد.", 'MarkDown', $message_id);
			}else{
				SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی شده بود!", 'MarkDown', $message_id);
			}
		}
	}else{
	    SendMessage($chat_id, "■ کاربری با آیدی @$match[2] نمی شناسم !\n• دلیل : آیدی اشتباه است یا کاربر آیدی خود را به تازگی تغییر داده!\n• راه حل : کاربر باید در یکی از گروه هایی که من مدیریت می کنم پیامی ارسال کند یا پیوی من را استارت کند.", 'MarkDown', $message_id);
	}
}
elseif(preg_match('/^[!\/#]?(banall|مسدود) (.*)$/i', $text) and strstr($getup, "text_mention")){
    $id = getIdMention($up);
	if(!in_array($id, $Dev)){
		if(!in_array($id, $dataBase['banall'])){
			$dataBase['banall'][] = $id;
			file_put_contents("data/data.json",json_encode($dataBase));
			KickAll($id);
			SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی شد.", 'MarkDown', $message_id);
		}else{
			SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی شده بود!", 'MarkDown', $message_id);
		}
	}
}
elseif(preg_match('/^[!\/#]?(banall|مسدود) (\d+)/i',$text,$match)){
	if(!in_array($match[2], $Dev)){
		if(!in_array($match[2], $dataBase['banall'])){
			$dataBase['banall'][] = $match[2];
			file_put_contents("data/data.json",json_encode($dataBase));
			KickAll($match[2]);
			SendMessage($chat_id, "■ کاربر [".$match[2]."](tg://user?id=$match[2]) مسدود همگانی شد.", 'MarkDown', $message_id);
		}else{
			SendMessage($chat_id, "■ کاربر [".$match[2]."](tg://user?id=$match[2]) مسدود همگانی شده بود!", 'MarkDown', $message_id);
		}
	}
}
elseif(preg_match('/^[!\/#]?(unbanall|لغو مسدود)$/i',$text) and isset($reply) and $tc != 'private'){
	if(!in_array($reply_id, $Dev)){
		if(in_array($reply_id, $dataBase['banall'])){
			$search = array_search($reply_id, $dataBase['banall']);
			unset($dataBase['banall'][$search]);
			file_put_contents("data/data.json",json_encode($dataBase));
			SendMessage($chat_id, "■ کاربر [$reply_id](tg://user?id=$reply_id) لغو مسدود همگانی شد.", 'MarkDown', $message_id);
		}else{
			SendMessage($chat_id, "■ کاربر [$reply_id](tg://user?id=$reply_id) مسدود همگانی نشده بود!", 'MarkDown', $message_id);
		}
	}
}
elseif(preg_match('/^[!\/#]?(unbanall|لغو مسدود) (\d+)/i',$text,$match)){
	if(!in_array($match[2], $Dev)){
		if(in_array($match[2], $dataBase['banall'])){
			$search = array_search($match[2], $dataBase['banall']);
			unset($dataBase['banall'][$search]);
			file_put_contents("data/data.json",json_encode($dataBase));
			SendMessage($chat_id, "■ کاربر [".$match[2]."](tg://user?id=$match[2]) لغو مسدود همگانی شد.", 'MarkDown', $message_id);
		}else{
			SendMessage($chat_id, "■ کاربر [".$match[2]."](tg://user?id=$match[2]) مسدود همگانی نشده بود!", 'MarkDown', $message_id);
		}
	}
}
elseif(preg_match('/^[!\/#]?(unbanall|لغو مسدود) (.*)$/i', $text) and strstr($getup, "text_mention")){
    $id = getIdMention($up);
	if(!in_array($id, $Dev)){
		if(in_array($id, $dataBase['banall'])){
			$search = array_search($id, $dataBase['banall']);
			unset($dataBase['banall'][$search]);
			file_put_contents("data/data.json",json_encode($dataBase));
			SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) لغو مسدود همگانی شد.", 'MarkDown', $message_id);
		}else{
			SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی نشده بود!", 'MarkDown', $message_id);
		}
	}
}
elseif(preg_match('/^[!\/#]?(unbanall|لغو مسدود) @(.*)$/i', $text, $match)){
	$id = getIdUserName($match[2]);
	if($id != false){
		if(!in_array($id, $Dev)){
			if(in_array($id, $dataBase['banall'])){
				$search = array_search($id, $dataBase['banall']);
				unset($dataBase['banall'][$search]);
				file_put_contents("data/data.json",json_encode($dataBase));
				SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) لغو مسدود همگانی شد.", 'MarkDown', $message_id);
			}else{
				SendMessage($chat_id, "■ کاربر [$id](tg://user?id=$id) مسدود همگانی نشده بود!", 'MarkDown', $message_id);
			}
		}
	}else{
	    SendMessage($chat_id, "■ کاربری با آیدی @$match[2] نمی شناسم !\n• دلیل : آیدی اشتباه است یا کاربر آیدی خود را به تازگی تغییر داده!\n• راه حل : کاربر باید در یکی از گروه هایی که من مدیریت می کنم پیامی ارسال کند یا پیوی من را استارت کند.", 'MarkDown', $message_id);
	}
}
if($text=="سرور"){
$load = sys_getloadavg();
$mem = memory_get_usage();
$ver = phpversion();
SendMessage($chat_id,"
*CPU*: $load[0]
*PHP VERSION*: $ver
*Memory USAGE*: $mem KB", 'MarkDown', $message_id);
        }

//------------------------------------------------------------------
if($tc == 'private'){
	$step = file_get_contents("step");
	$back = json_encode(['keyboard'=>[
    [['text'=>"▫️ برگشت به پنل ▫️"]]
    ],'resize_keyboard'=>true]);
	$panel = json_encode(['keyboard'=>[
	[['text'=>"🗂 بکاپ"]],
	[['text'=>"👥 وضعیت گروه ها"],['text'=>"📊 آمار"]],
	[['text'=>"📬 ارسال همگانی کاربران"],['text'=>"📮 فروارد همگانی کاربران"]],
	[['text'=>"📬 ارسال همگانی گروه ها"],['text'=>"📮 فروارد همگانی گروه ها"]],
	[['text'=>"🔘 خروج ربات"]],
	[['text'=>"▫️ برگشت ▫️"]]
	],'resize_keyboard'=>true]);
    if(preg_match('/^[!\/#]?(panel|پنل مدیریت)$/i',$text) || $text == "▫️ برگشت به پنل ▫️"){
		SendMessage($chat_id, "■ به پنل مدیریت خوش آمدید :", 'MarkDown', $message_id, $panel);
    }
	elseif($text == "🗂 بکاپ" and $from_id == $Dev[0]){
        zip("data","FUN.zip");
        SendDocument($chat_id, new CURLFile("FUN.zip"), "■ بک آپ آخرین نسخه سورس ");
        unlink("FUN.zip");
    }
	elseif($text == "👥 وضعیت گروه ها"){
		$string = null;
		$scan = scandir("data");
		$diff = array_diff($scan, ['.','..','list.json']);
		foreach($diff as $value){
			$title = GetChat($value)->result->title;
			$string .= "■ $title | $value".PHP_EOL;
		}
		$time = date('H:i');
		file_put_contents("groups.txt",$string);
		SendDocument($chat_id, new CURLFile("groups.txt"), "■ وضعیت کلی گروه ها\n\n■ فایل در ساعت $time ایجاد شده!");
		unlink("groups.txt");
	}
	
	elseif($text == "📮 فروارد همگانی کاربران"){
		file_put_contents("step","fwduser");
		SendMessage($chat_id, "■ پیام مورد نظر را فروارد کنید.", 'MarkDown', $message_id, $back);
	}
	elseif($step == "fwduser" and isset($message)){
		unlink("step");
		foreach($list['user'] as $value){
			ForwardMessage($value, $chat_id, $message_id);
		}
		SendMessage($chat_id, "■ پیام با موفقیت به تمامی کاربران فروارد شد.", 'MarkDown', $message_id, $panel);
	}
	elseif($text == "📮 فروارد همگانی گروه ها"){
		file_put_contents("step","fwdgp");
		SendMessage($chat_id, "■ پیام مورد نظر را فروارد کنید.", 'MarkDown', $message_id, $back);
	}
	elseif($step == "fwdgp" and isset($message)){
		unlink("step");
		foreach($list['group'] as $value){
			ForwardMessage($value, $chat_id, $message_id);
		}
		SendMessage($chat_id, "■ پیام با موفقیت به تمامی کاربران فروارد شد.", 'MarkDown', $message_id, $panel);
	}
	elseif($text == "📬 ارسال همگانی کاربران"){
		file_put_contents("step","senduser");
		SendMessage($chat_id, "■ پیام مورد نظر را در قالب متن ارسال کنید.", 'MarkDown', $message_id, $back);
	}
	elseif($step == "senduser" and isset($text)){
		unlink("step");
		foreach($list['user'] as $value){
			SendMessage($value, $text);
		}
		SendMessage($chat_id, "■ پیام با موفقیت به تمامی کاربران فروارد شد.", 'MarkDown', $message_id, $panel);
	}
	elseif($text == "📬 ارسال همگانی گروه ها"){
		file_put_contents("step","sendgp");
		SendMessage($chat_id, "■ پیام مورد نظر را در قالب متن ارسال کنید.", 'MarkDown', $message_id, $back);
	}
	elseif($step == "sendgp" and isset($text)){
		unlink("step");
		foreach($list['group'] as $value){
			SendMessage($value, $text);
		}
		SendMessage($chat_id, "■ پیام با موفقیت به تمامی کاربران فروارد شد.", 'MarkDown', $message_id, $panel);
	}
	elseif($text == "🔘 خروج ربات"){
		file_put_contents("step","leavegp");
		SendMessage($chat_id, "■ آیدی عددی گروه را ارسال کنید.", 'MarkDown', $message_id, $back);
	}
	elseif($step == "leavegp" and strstr($text, '-')){
		unlink("step");
		SendMessage($text, "■ ربات به دستور مدیریت این گروه را ترک می کند!", 'MarkDown');
		LeaveChat($text);
		SendMessage($chat_id, "■ ربات از گروه `$text` خارج شد.", 'MarkDown', $message_id, $panel);
	}
    elseif(isset($reply_forward)){
        $sticker_id = $update->message->sticker->file_id;
        $video_id = $update->message->video->file_id;
        $voice_id = $update->message->voice->file_id;
        $file_id = $update->message->document->file_id;
        $music_id = $update->message->audio->file_id;
        $photo0_id = $update->message->photo[0]->file_id;
        $photo1_id = $update->message->photo[1]->file_id;
        $photo2_id = $update->message->photo[2]->file_id;
        if(preg_match('/^\/(banall)$/i',$text)){
            if(!in_array($reply_forward, $dataBase['banall'])){
                $dataBase['banall'][] = $reply_forward;
		        file_put_contents("data/data.json",json_encode($dataBase));
		        KickAll($reply_forward);
		        SendMessage($chat_id, "■ کاربر مورد نظر مسدود همگانی شد.", 'MarkDown', $message_id);
		        SendMessage($reply_forward, "■ دسترسی شما به تله نوا محدود شد.", 'MarkDown');
            }
        }
        elseif(preg_match('/^\/(unbanall)$/i',$text)){
            $search = array_search($reply_forward, $dataBase['banall']);
            unset($dataBase['banall'][$search]);
            file_put_contents("data/data.json",json_encode($dataBase));
            SendMessage($chat_id, "■ کاربر مورد نظر از مسدودیت همگانی خارج شد.", 'MarkDown', $message_id);
            SendMessage($reply_forward, "■ دسترسی شما به تله نوا مجاز شد.", 'MarkDown');
        }
        elseif($text != null){
			SendMessage($reply_forward,$text);
		}
		elseif($voice_id != null){
			SendVoice($reply_forward,$voice_id,$caption);
		}
		elseif($file_id != null){
			SendDocument($reply_forward,$file_id,$caption);
		}
		elseif($music_id != null){
			SendAudio($reply_forward,$music_id,$caption);
		}
		elseif($photo2_id != null){
			SendPhoto($reply_forward,$photo2_id,$caption);
		}
		elseif($photo1_id != null){
			SendPhoto($reply_forward,$photo1_id,$caption);
		}
		elseif($photo0_id != null){
			SendPhoto($reply_forward,$photo0_id,$caption);
		}
		elseif($video_id != null){
			SendVideo($reply_forward,$video_id,$caption);
		}
		elseif($sticker_id != null){
			SendSticker($reply_forward,$sticker_id);
		}
    }
}
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
?>