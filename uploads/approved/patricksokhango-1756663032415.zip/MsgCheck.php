 <?php
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
include("jdf.php");
if(isset($up['message']['new_chat_member'])){
$menu = json_encode(['resize_keyboard' => true,
'inline_keyboard'=>[
[['text' => "👨🏻‍✈️ورود به پنل مدیریت", 'callback_data' => "panel"]],
[['text' => "📣 کانال ربات", 'url' => "$channel"]]
]]);
	    $message = $up['message'];
        $chat_id = $message['chat']['id'];
        $message_id = $message['message_id'];
        $newchatmemberid = $message['new_chat_member']['id'];
        $name = MarkDown($first_name);
	    if($newchatmemberid == $Botid){
	    	if(!is_dir("data/$chat_id")){	
	 	SendMessage($chat_id, "
	 	🙃 دوست خوبم  [$name](tg://user?id=$from_id) 
ممنونم که و منو توی جمع تون آوردی ، امیدوارم لحظات خوب و شادی رو بتونم براتون فراهم کنم !
🗣 برای مشاهده دستورات من کافیه دستورات 'راهنما'  رو ارسال کنی یا به پیوی ربات و بخش '💡 دستورات' مراجعه کنی

🤓 خوب بزار خودمو به اعضاء معرفی کنم , من ربات « $bot_name »  هستم
🤔 من مثل یک هوش مصنوعی عمل می کنم و میتونم از مدیرای گروهت یا خودت کلمه یادبگیرم بعد وقتی اون کلمه رو گفتن جواب بدم .

😲 تازه میتونی برای یک کلمه چند تا جواب یادم بدی تا من هربار تصادفی جواب بدم , یا جوابت رو به صورت ویس یا عکس بدم :)
😎 راستی من یک ربات کاملاَ رایگان هستم و هر کسی میتونه منو بدون هیچ هزینه ای منو به گروهش اضافه کنه ...

❗️ اهان ! برای این که بهتر بتونم کار کنم منو ادمین کن عزیزم
	 	", 'MarkDown', $message_id, $menu);   
mkdir("data/$chat_id");
$setting = array('status'=>'on','who-learn'=>'all','words'=>[]);
file_put_contents("data/$chat_id/settings.json",json_encode($setting));
			}else{
	SendMessage($chat_id, "
	 	🙃 دوست خوبم  [$name](tg://user?id=$from_id) ممنونم که دوباره منو توی جمع تون آوردی ، امیدوارم لحظات خوب و شادی رو بتونم براتون فراهم کنم !

🗣 برای مشاهده دستورات من کافیه دستورات 'راهنما'  رو ارسال کنی یا به پیوی ربات و بخش '💡 دستورات' مراجعه کنی

❗️ یاده نره ! برای این که بهتر بتونم کار کنم منو ادمین کن عزیزم", 'MarkDown', $message_id, $menu); 
	}	
}
}
elseif($setting['status'] == 'on'){
if($setting['words'][$text] != null and $tc != 'private'){
  $answer = $setting['words'][$text];
     SendMessage($chat_id, $answer, 'MarkDown', $message_id);
}


elseif(preg_match('/^(bot)$/i', $text) || $text == "ربات"){
    $array = ["😎 آنلاینم","🙂 هوم , دستم بنده","🤗 بگوشم"];
    $rand = array_rand($array);
    SendMessage($chat_id, $array[$rand], 'MarkDown', $message_id);
}

elseif(preg_match('/^(کیر)$/i', $text) || $text == "کسخل" || $text == "کسشعر" || $text == "مادرجنده" || $text == "دیوث"){
    $array = ["اینجا جای این حرفا نیست"];
    $rand = array_rand($array);
    SendMessage($chat_id, $array[$rand], 'MarkDown', $message_id);
}

elseif(preg_match('/^[!\/#]?(در جواب) (.*) (بگو) (.*)$/i',$text,$match)){ 
    if(isModerate($chat_id, $from_id) != true and $setting['who-learn'] == 'admins'){ exit(); }
        $word = $match[2];
        $answer = $match[4];
        SendMessage($chat_id, "😇 یاد گرفتم هر وقت ( $word ) رو دیدم در جوابش بگم ( $answer )", 'MarkDown', $message_id);
  $setting['words'][$word] = "$answer";
  file_put_contents("data/$chat_id/settings.json",json_encode($setting));       
     }
         elseif(preg_match('/^[!\/#]?(فراموش کن) (.*)$/i',$text,$match)){
		  if(isModerate($chat_id, $from_id) != true and $setting['who-learn'] == 'admins'){ exit(); }
        $word = $match[2];
        if($setting['words'][$word] != null){    
            SendMessage($chat_id, "☹️ کلمه ی ( $word ) رو فراموش کردم و دیگه بهش جواب نمیدم", 'MarkDown', $message_id);
  unset($setting['words'][$word]);
  file_put_contents("data/$chat_id/settings.json",json_encode($setting));
        }else{
      SendMessage($chat_id, "😐 بلد نبودم اینو", 'MarkDown', $message_id);
        }
 } 
} 

/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
?>