<?php
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
//------------------------------------------------------------------
if(preg_match('/^[!\/#]?(panel|پنل)$/i', $text)){
    $status = Checkstat($setting['status']);
	$who_learn = CheckWho($setting['who-learn']);
	$menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[
	[['text' => "✅ حالت سخنگو",'callback_data'=>"txt"],['text' => "$status", 'callback_data' => "status"]],
	[['text' => "📯 کیا یادبدن",'callback_data'=>"0"],['text' => "$who_learn", 'callback_data' => "wholearn"]],
	[['text' => "دستورات 💡",'callback_data'=>"funhelp"],['text' => "✉️ لیست کلمات", 'callback_data' => "words"]],
	[['text' => "📣 کانال ربات", 'url' => "$channel"],['text' => "✖️ بستن پنل", 'callback_data' => "close"]]
	]]);
	SendMessage($chat_id, "🤠 به پنل مدیریت من خوش اومدی
 
😇 خوب چی کار با من داشتی مدیر عزیز ؟ از پنل مدیریت زیر استفاده کن 👇🏻", 'MarkDown', $message_id, $menu);
}
elseif($data == "panel"){
  $status = Checkstat($setting['status']);
	$who_learn = CheckWho($setting['who-learn']);
	$menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[
	[['text' => "✅ حالت سخنگو",'callback_data'=>"txt"],['text' => "$status", 'callback_data' => "status"]],
	[['text' => "📯 کیا یادبدن",'callback_data'=>"0"],['text' => "$who_learn", 'callback_data' => "wholearn"]],
	[['text' => "دستورات 💡",'callback_data'=>"funhelp"],['text' => "✉️ لیست کلمات", 'callback_data' => "words"]],
	[['text' => "📣 کانال ربات", 'url' => "$channel"],['text' => "✖️ بستن پنل", 'callback_data' => "close"]]
	]]);
	EditMessageText($chatid, $msgid, "🤠 به پنل مدیریت من خوش اومدی
 
😇 خوب چی کار با من داشتی مدیر عزیز ؟ از پنل مدیریت زیر استفاده کن 👇🏻", 'MarkDown', $menu);
}
elseif($data == "funhelp"){
$menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[      
	    [['text' => "▫️ منوی قبل", 'callback_data' => "panel"]]
	]]);
EditMessageText($chatid, $msgid, "📒 راهنمای بخش سخنگوی ربات :

» در جواب (کلمه) بگو (جواب)
» فراموش کن (کلمه)
» چیا بلدی
» الزایمر بگیر
🔆 توجه کنید : در زمان یاد دادن به ربات پرانتر دور (کلمه) رو حذف کنید ", 'MarkDown', $menu);     
}
elseif($data == "words"){
 $words = $setting['words'];
  if($words != null){
    $str = null;
    foreach($words as $word => $answer){
      $str .= "کلمه ($word) | پاسخ ($answer)\n";    
$menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[      
	    [['text' => "▫️ منوی قبل", 'callback_data' => "panel"]]
	]]);
	EditMessageText($chatid, $msgid, "▫️فعلا اینارو بلدم : \n\n`$str`", 'MarkDown', $menu);     
}}else{
    $menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[      
	    [['text' => "▫️ منوی قبل", 'callback_data' => "panel"]]
	]]);
    	EditMessageText($chatid, $msgid, "▫️هنوز چیزی یاد نگرفتم", 'MarkDown', $menu);     
}}
elseif($data == "status"){
 if($setting['status'] == 'on'){
			$setting['status'] = 'off';
			file_put_contents("data/$chatid/settings.json",json_encode($setting));
		}else{
			$setting['status'] = 'on';
			file_put_contents("data/$chatid/settings.json",json_encode($setting));
		}
		$status = Checkstat($setting['status']);
	$who_learn = CheckWho($setting['who-learn']);
 $menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[
	[['text' => "✅ حالت سخنگو",'callback_data'=>"txt"],['text' => "$status", 'callback_data' => "status"]],
	[['text' => "📯 کیا یادبدن",'callback_data'=>"0"],['text' => "$who_learn", 'callback_data' => "wholearn"]],
	[['text' => "دستورات 💡",'callback_data'=>"funhelp"],['text' => "✉️ لیست کلمات", 'callback_data' => "words"]],
	[['text' => "📣 کانال ربات", 'url' => "$channel"],['text' => "✖️ بستن پنل", 'callback_data' => "close"]]
	]]);
		AnswerCallbackQuery($cllid, "✅ انجام شد.");
		EditKeyboard($chatid, $msgid, $menu);
}
elseif($data == "wholearn"){
 if($setting['who-learn'] == 'all'){
			$setting['who-learn'] = 'admins';
			file_put_contents("data/$chatid/settings.json",json_encode($setting));
		}else{
			$setting['who-learn'] = 'all';
			file_put_contents("data/$chatid/settings.json",json_encode($setting));
		}
		$status = Checkstat($setting['status']);
	$who_learn = CheckWho($setting['who-learn']);
 $menu = json_encode(['resize_keyboard' => true,
	'inline_keyboard'=>[
	[['text' => "✅ حالت سخنگو",'callback_data'=>"txt"],['text' => "$status", 'callback_data' => "status"]],
	[['text' => "📯 کیا یادبدن",'callback_data'=>"0"],['text' => "$who_learn", 'callback_data' => "wholearn"]],
	[['text' => "دستورات 💡",'callback_data'=>"funhelp"],['text' => "✉️ لیست کلمات", 'callback_data' => "words"]],
	[['text' => "📣 کانال ربات", 'url' => "$channel"],['text' => "✖️ بستن پنل", 'callback_data' => "close"]]
	]]);
		AnswerCallbackQuery($cllid, "✅ انجام شد.");
		EditKeyboard($chatid, $msgid, $menu);
}
elseif($data == "close"){
    AnswerCallbackQuery($cllid, "✖️ پنل با موفقیت بسته شد.", true);
    EditMessageText($chatid, $msgid, "■ پنل توسط ( [$callfirst](tg://user?id=$fromid) ) بسته شد.", 'MarkDown');
}

elseif(preg_match('/^[!\/#]?(help|راهنما)$/i',$text)){
	$helpfun = "📒 راهنمای بخش سخنگوی ربات :

» در جواب (کلمه) بگو (جواب)
» فراموش کن (کلمه)
» چیا بلدی
» الزایمر بگیر
🔆 توجه کنید : در زمان یاد دادن به ربات پرانتر دور (کلمه) رو حذف کنید 
";
    SendMessage($chat_id, $helpfun, 'MarkDown', $message_id);
}
//---------------------------------------------------------------------------- 

elseif($text == 'چیا بلدی'){
  $words = $setting['words'];
  if($words != null){
    $str = null;
    foreach($words as $word => $answer){
      $str .= "کلمه ($word) | پاسخ ($answer)\n";
    }
SendMessage($chat_id, "🎉 فعلا اینارو بلدم : \n $str", 'MarkDown', $message_id);
  }else{
    SendMessage($chat_id, "😮 هنوز چیزی یادم ندادی که", 'MarkDown', $message_id);
  }
}
  elseif($text=="الزایمر بگیر"){
            SendMessage($chat_id, "آلزایمر گرفتم :| دیگه چیزی یادم نیست", 'MarkDown', $message_id);
  unset($setting['words']);
  file_put_contents("data/$chat_id/settings.json",json_encode($setting));
        }
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
?>