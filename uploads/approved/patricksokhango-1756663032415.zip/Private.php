<?php
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
//----Buttons----//
$menu = json_encode(['resize_keyboard' => true,
'inline_keyboard'=>[
[['text' => "⏫ نصب مستقیم", 'url' => "https://t.me/$usernamebot?startgroup=add"]],
[['text' => "", 'callback_data' => "support"],['text' => "📯 دستورات", 'callback_data' => "orders"]],
[['text' => "📣 کانال ربات", 'url' => "$channel"]]
]]);
$add = json_encode(['resize_keyboard' => true,
'inline_keyboard'=>[
[['text' => "⏫ نصب مستقیم", 'url' => "https://t.me/$usernamebot?startgroup=add"]],
[['text' => "🏛 خانه", 'callback_data' => "start"],['text' => "🎥 آموزش نصب", 'callback_data' => "baaaner"]],
[['text' => "📣 کانال ربات", 'url' => "$channel"]]
]]);
$back = json_encode(['resize_keyboard' => true,
'inline_keyboard'=>[
[['text' => "🏛 خانه", 'callback_data' => "start"]],
[['text' => "📣 کانال ربات", 'url' => "$channel"]]
]]);
//------------------------------------------------------------------
if(preg_match('/^\/(start)$/i',$text)){
    $name = MarkDown($first_name);
    SendMessage($chat_id, "✋ سلام  $name
🤓 من ربات « $bot_name »  هستم
🤔 من مثل یک هوش مصنوعی عمل می کنم و میتونم از مدیرای گروهت یا خودت کلمه یادبگیرم بعد وقتی اون کلمه رو گفتن جواب بدم .

😲 تازه میتونی برای یک کلمه چند تا جواب یادم بدی تا من هربار تصادفی جواب بدم , یا جوابت رو به صورت ویس یا عکس بدم :)

🗣 استفاده از من کاملا رایگانه ! منتظر چی هستی ؟ منو همین الان ببر گروهت 👇🏻
    ", 'MarkDown', $message_id, $menu);
}
elseif($text == "❌ قطع ارتباط"){
    $remove = json_encode(['KeyboardRemove'=>[],'remove_keyboard'=>true]);
    SendMessage($chat_id, "ارتباط با پشتیبانی قطع شد.", 'MarkDown', $message_id, $remove);
    $search = array_search($from_id, $dataBase['support']);
    unset($dataBase['support'][$search]);
    file_put_contents("data/data.json",json_encode($dataBase));
    $name = MarkDown($first_name);
    SendMessage($chat_id, "✋ سلام  $name
🤓 من ربات « $bot_name »  هستم
🤔 من مثل یک هوش مصنوعی عمل می کنم و میتونم از مدیرای گروهت یا خودت کلمه یادبگیرم بعد وقتی اون کلمه رو گفتن جواب بدم .

😲 تازه میتونی برای یک کلمه چند تا جواب یادم بدی تا من هربار تصادفی جواب بدم , یا جوابت رو به صورت ویس یا عکس بدم :)

🗣 استفاده از من کاملا رایگانه ! منتظر چی هستی ؟ منو همین الان ببر گروهت 👇🏻", 'MarkDown', null, $menu);
}
elseif(in_array($from_id, $dataBase['support'])){
    if(isset($text) || isset($photo) || isset($voice) || isset($contact)){
        ForwardMessage($Dev[0], $chat_id, $message_id);
    }else{
        SendMessage($chat_id, "❗️ هشدار : تنها قادر به ارسال [متن | عکس | ویس | کانتکت] در این بخش مجاز است.", 'MarkDown', $message_id);
    }
}
elseif(isset($data)){
    switch($data){
        case "support":
        $end = json_encode(['keyboard'=>[
        [['text'=>"❌ قطع ارتباط"]]
        ],'resize_keyboard'=>true]);
        DeleteMessage($chatid, $msgid);
        SendMessage($chatid, "✅ ارتباط برقرار شد از الان هر چیزی ارسال کنی به پشتیبانی ارسال میشه.\n\n❌ مهم!\nاگر از گروه به ربات هدایت شده اید و اگر سوالی در مورد گروه دارید لطفاً فقط با مسئولین گروه در تماس باشید زیرا مشکلات گروه به ربات ربطی ندارد.", 'MarkDown', null, $end);
        $dataBase['support'][] = $fromid;
        file_put_contents("data/data.json",json_encode($dataBase));
        break;
        case "start":       
        $name = MarkDown($callfirst);   
        EditMessageText($chatid, $msgid, "✋ سلام  $name
🤓 من ربات « $bot_name »  هستم
🤔 من مثل یک هوش مصنوعی عمل می کنم و میتونم از مدیرای گروهت یا خودت کلمه یادبگیرم بعد وقتی اون کلمه رو گفتن جواب بدم .

😲 تازه میتونی برای یک کلمه چند تا جواب یادم بدی تا من هربار تصادفی جواب بدم , یا جوابت رو به صورت ویس یا عکس بدم :)

🗣 استفاده از من کاملا رایگانه ! منتظر چی هستی ؟ منو همین الان ببر گروهت 👇🏻", 'MarkDown', $menu);
        break;
        case "addd":       
        EditMessageText($chatid, $msgid, "
        😉 نصب من داخل گروهت خیلی خیلی آسونه !
😋 کافیه منو به گروهت اضافه کنی , برای اضافه کردن من به گروهت دوتا روش داری که من هر دوتاش رو میگم برات 👇🏻

1️⃣  نصب مستقیم : میتونی روی دکمه زیر که برات قرار دادم استفاده کنی و از لیست گروهات , گروه خودت رو انتخاب کنی و منو به گروهت اضافه کنی

2️⃣  نصب غیر مستقیم : با استفاده از یوزرنیم من میتونی منو به گروهت اضافه کنی . چطوری الان بهت میگم 👇🏻
📍 گروهت رو انتخاب کن
📍 برو به بخش اضافه کردن عضو
📍 روی جست و جو یا ذره بین بزن و یوزرنیم منو (@$BotID) رو بنویس
📍 روی اسم من کلیک کن و افزودن رو بزن

🤗 دیدی ؟ چقدر ساده با همین دوتا روشی که بهت گفتم میتونی منو به گروهت اضافه کنی تا حال هوای گروهت رو عوض کنم کلی کلمه بهم یاد بدی

😀🌺 من یک ربات در قالب سرگرمی برای گروه های شما هستم ، از قابلیت های من  می توان به دستورات بر پایه هوش مصنوعی و سیستم ضد فلود و ... اشاره کرد !

🤔 شما میتونی به من حرف یاد بدی و منم تو گروهت چت کنم ، تازه میتونی برای یک حرف چندین جواب یادم بدی تا هربار تصادفی یکیشونو بفرستم :)

😩 نگران نباش اگه هنوز یاد نگرفتی چطوری منو نصب کنی میتونی از دکمه زیر آموزش نصب استفاده کنی 👇🏻
        ", 'MarkDown', $add);
        break;
            case "orders":       
        EditMessageText($chatid, $msgid, "
📒 راهنمای بخش سخنگوی ربات :

» در جواب (کلمه) بگو (جواب)
» فراموش کن (کلمه)
» چیا بلدی
» الزایمر بگیر
🔆 توجه کنید : در زمان یاد دادن به ربات پرانتر دور (کلمه) رو حذف کنید
        ", 'MarkDown', $back);
        break;
        case "baaaner":       
        EditMessageText($chatid, $msgid, "
ربات را به گروه خود اضافه کنید
        ", 'MarkDown', $back);
        break;
    }
}
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
?>
