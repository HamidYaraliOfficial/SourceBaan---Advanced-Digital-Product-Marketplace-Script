<?php
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
error_reporting(0);
date_default_timezone_set('Asia/Tehran');
//----Config----//
flush();
$list = json_decode(file_get_contents("data/list.json"), true);
$listDev = isset($list['sudo']) ? $list['sudo'] : [];
$Dev = array_merge([0000000,000000000], $listDev); //آیدی عددیت
$usernamebot = "harfbzan_robot"; // آیدی ربات
$channel = "t.me/jahanbots"; //چنل پشتیبانی
$bot_name = "ُسمیه"; // اسم ربات
define('API_KEY',''); //توکن
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    return json_decode($res);
}

function SendMessage($chat_id, $text, $mode = null, $reply = null, $keyboard = null, $disable_web_page_preview = false){
return bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$text,
	'parse_mode'=>$mode,
	'reply_to_message_id'=>$reply,
	'disable_web_page_preview'=>$disable_web_page_preview,
	'reply_markup'=>$keyboard
	]);
}
function EditMessageText($chat_id, $message_id, $text, $mode = null, $keyboard = null, $disable_web_page_preview = null){
bot('EditMessageText',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$mode,
    'reply_markup'=>$keyboard,
    'disable_web_page_preview'=>$disable_web_page_preview
    ]);
}
function EditKeyboard($chat_id, $message_id, $keyboard){
bot('EditMessageReplyMarkup',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
	'reply_markup'=>$keyboard
    ]);
}
function AnswerCallbackQuery($callback_query_id, $text, $show_alert = false){
bot('AnswerCallbackQuery',[
    'callback_query_id'=>$callback_query_id,
    'text'=>$text,
	'show_alert'=>$show_alert
    ]);
}
function ForwardMessage($chat_id, $from_chat, $message_id){
bot('ForwardMessage',[
	'chat_id'=>$chat_id,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
}
function SendPhoto($chat_id, $photo, $caption, $reply = null){
bot('SendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$photo,
	'caption'=>$caption,
	'reply_to_message_id'=>$reply
	]);
}
function SendAudio($chat_id, $audio, $caption = null){
	bot('SendAudio',[
	'chat_id'=>$chat_id,
	'audio'=>$audio,
	'caption'=>$caption
	]);
}
function SendDocument($chat_id, $document, $caption = null, $reply = null){
bot('SendDocument',[
	'chat_id'=>$chat_id,
	'document'=>$document,
	'caption'=>$caption,
	'reply_to_message_id'=>$reply
	]);
}
function SendSticker($chat_id, $sticker, $reply = null){
bot('SendSticker',[
	'chat_id'=>$chat_id,
	'sticker'=>$sticker,
	'reply_to_message_id'=>$reply
	]);
}
function SendVideo($chat_id, $video, $caption = null, $reply = null){
bot('SendVideo',[
	'chat_id'=>$chat_id,
	'video'=>$video,
	'caption'=>$caption,
	'reply_to_message_id'=>$reply
	]);
}
function SendVoice($chat_id, $voice, $caption = null){
bot('SendVoice',[
	'chat_id'=>$chat_id,
	'voice'=>$voice,
	'caption'=>$caption
	]);
}
function DeleteMessage($chat_id, $msgid){
bot('DeleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$msgid
	]);
}
function LeaveChat($chat_id){
    bot('LeaveChat',[
    'chat_id'=>$chat_id
    ]);
}
function isModerate($chat_id, $user_id){
    global $Dev;
	$get = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$chat_id&user_id=".$user_id), true);
	$ranko = $get['result']['status'];
	if($ranko == 'creator' | $ranko == 'administrator' | in_array($user_id, $Dev)){
		return true;
	}
}
function GetChat($chat_id){
    return bot('GetChat',['chat_id'=>$chat_id]);
}
function GetMe(){
    return bot('GetMe',[]);
}
$BotID = Bot('GetMe',[])->result->username;
$Botid = Bot('GetMe',[])->result->id;
function DeleteFolder($path){
    if($handle=opendir($path)){
        while(false!==($file=readdir($handle))){
            if($file<>"." AND $file<>".."){
                if(is_file($path.'/'.$file)){
                    @unlink($path.'/'.$file); 
                }
            if(is_dir($path.'/'.$file)){
                deletefolder($path.'/'.$file); 
                @rmdir($path.'/'.$file); 
            }
          }
        }
    }
}
function zip($source, $destination){
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));

    if (is_dir($source) === true) {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

        foreach ($files as $file) {
            $file = str_replace('\\', '/', $file);

            // Ignore "." and ".." folders
            if (in_array(substr($file, strrpos($file, '/')+1), array('.', '..'))) {
                continue;
            }               

            $file = realpath($file);

            if (is_dir($file) === true) {
                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            } elseif (is_file($file) === true) {
                $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
            }
        }
    } elseif (is_file($source) === true) {
        $zip->addFromString(basename($source), file_get_contents($source));
    }

    return $zip->close();
}
//----------Other Function
function Download($link, $path){
    $file = fopen($link, 'r') or die("Can't Open Url !");
    file_put_contents($path, $file);
    fclose($file);
    return is_file($path);
 }
function getIdMention($update){
    $entities = $update['message']['entities'];
    foreach($entities as $key => $value){
        if($entities[$key]['type'] == 'text_mention'){
            return $entities[$key]['user']['id'];
        }
    }
}
function MarkDown($str){
    return str_replace(["_","`","*","[","]"], null, $str);
}
function ChatMembersCount($chat_id){
$get = bot('getChatMembersCount',[
'chat_id'=>$chat_id,
 ]);
$count = $get->result;
return $count;
}
function Checkstat($stat){
    $stat = str_replace("on", "✓ فعال", $stat);
    $stat = str_replace("off", "× غیرفعال", $stat);
    return $stat;
}
function CheckWho($stat){
    $stat = str_replace("all", "👥 همه", $stat);
    $stat = str_replace("admins", "👮🏻مدیران", $stat);
    return $stat;
}
function pingDomain($domain){
    $starttime = microtime(true);
    $file = fsockopen($domain, 80, $errno, $errstr, 10);
    $stoptime = microtime(true);
    $status = 0;

    if($file){
        fclose($file);
        $status = ($stoptime - $starttime) * 1000;
        $status = floor($status);
    }else{
        $status = -1;  // Site is down
    }
    return $status;
}
//----------Variables
//----Updates----//
$getup = file_get_contents('php://input');
$update = json_decode($getup);
$up = json_decode($getup, true);
//----Exit From TimeOut----//
if(isset($up['message']) and strtotime('-10 Minutes') > $up['message']['date']){
	exit();
}
//----DataBase----//
$dataBase = json_decode(file_get_contents("data/data.json"), true);
//----Message----//
if(isset($update->message)){
    $message = $update->message;
    $text = $message->text;
    $caption = $message->caption;
    $photo = $message->photo;
    $video = $message->video;
    $sticker = $message->sticker;
    $document = $message->document;
    $video_note = $message->video_note;
    $audio = $message->audio;
    $voice = $message->voice;
    $location = $message->location;
    $contact = $message->contact;
    $game = $message->game;
    $forward = $message->forward_from;
    $forward_id = $message->reply_to_message->forward_from->id;
    $forward_from = $message->forward_from_chat;
    $forward_from_id = $message->forward_from_chat->id;
    $reply = $message->reply_to_message;
    $reply_id = $message->reply_to_message->from->id;
    $reply_msgid = $message->reply_to_message->message_id;
    $reply_forward = $message->reply_to_message->forward_from->id;
    $newchatmember = $message->new_chat_members;
    $newchatmemberuser = $message->new_chat_member->username;
    $chat_id = $message->chat->id;
    $from_id = $message->from->id;
    $first_name = $message->from->first_name;
    $last_name = $message->from->last_name;
    $user_name = $message->from->username;
    $message_id = $message->message_id;
    $tc = $message->chat->type;
    $title = $message->chat->title;
    //----Json----//
    $setting = json_decode(file_get_contents("data/$chat_id/settings.json"), true);
    //----Rank----//
    $stats = isModerate($chat_id, $from_id);
}
//----CallBack----//
if(isset($update->callback_query)){
    $cllid = $update->callback_query->id;
    $data = $update->callback_query->data;
    $fromid = $update->callback_query->from->id;
    $chatid = $update->callback_query->message->chat->id;
    $msgid = $update->callback_query->message->message_id;
    $clltc = $update->callback_query->message->chat->type;
    $clltitle = $update->callback_query->message->chat->title;
    $clltext = $update->callback_query->message->text;
    $callfirst = $update->callback_query->from->first_name;
    $calluser = $update->callback_query->from->username;
    //----Json----//
    $setting = json_decode(file_get_contents("data/$chatid/settings.json"), true);
    //----Rank----//
    $stats = isModerate($chatid, $fromid);
}
//----LoadPlugins----//
$this_tc = isset($tc) ? $tc : $clltc;
if($this_tc == 'private'){
    include ('Private.php');
}
include ('MsgCheck.php');
$this_chat = isset($chat_id) ? $chat_id : $chatid;
if(file_exists ("data/$this_chat/settings.json")){
    if($stats == true){
        include ('Group.php');
    }
}
$this_id = isset($from_id) ? $from_id : $fromid;
if(in_array($this_id, $Dev)){
    include ('Developer.php');
}
//------------------------------------------------------------------
$list = json_decode(file_get_contents("data/list.json"), true);
if(!in_array($from_id, $list['user']) and $tc == 'private') {
    $list['user'] = isset($list['user']) ? $list['user'] : array();
    array_push($list['user'], $chat_id);
    file_put_contents("data/list.json",json_encode($list));
}
if(!in_array($chat_id, $list['group']) and $tc == 'supergroup') {
    $list['group'] = isset($list['group']) ? $list['group'] : array();
    array_push($list['group'], $chat_id);
    file_put_contents("data/list.json",json_encode($list));
}
//------------------------------------------------------------------
if(!is_dir('data')) mkdir('data');
/*
کپی با ذکر منبع مجاز است!
@Epic_Source
*/
?>