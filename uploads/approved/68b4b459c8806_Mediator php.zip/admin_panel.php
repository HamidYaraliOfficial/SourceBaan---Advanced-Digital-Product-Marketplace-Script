<?php
require_once 'config.php';

class AdminPanel {
    private $db;
    
    public function __construct() {
        $this->loadDatabase();
    }
    
    private function loadDatabase() {
        if (file_exists(DB_FILE)) {
            $this->db = json_decode(file_get_contents(DB_FILE), true);
        }
    }
    
    private function saveDatabase() {
        file_put_contents(DB_FILE, json_encode($this->db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    // ارسال پیام
    private function sendMessage($chatId, $text, $keyboard = null) {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $result = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($result, true);
    }
    
    // نمایش پنل ادمین اصلی
    public function showMainPanel($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $stats = $this->getStats();
        
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👥 مدیریت کاربران', 'callback_data' => 'admin_users'],
                    ['text' => '👨‍💼 مدیریت واسطه‌گرها', 'callback_data' => 'admin_mediators']
                ],
                [
                    ['text' => '📊 آمار کامل', 'callback_data' => 'admin_stats'],
                    ['text' => '📁 مدیریت گروه‌ها', 'callback_data' => 'admin_groups']
                ],
                [
                    ['text' => '⚙️ تنظیمات ربات', 'callback_data' => 'admin_settings'],
                    ['text' => '📋 گزارشات', 'callback_data' => 'admin_reports']
                ],
                [
                    ['text' => '🔄 بروزرسانی', 'callback_data' => 'admin_refresh']
                ]
            ]
        ];
        
        $text = "🎛 <b>پنل مدیریت ربات</b>\n\n" .
                "📈 <b>آمار کلی:</b>\n" .
                "👥 کاربران: {$stats['total_users']}\n" .
                "👨‍💼 واسطه‌گرها: {$stats['total_mediators']}\n" .
                "📁 گروه‌ها: {$stats['total_groups']}\n" .
                "✅ گروه‌های فعال: {$stats['active_groups']}\n" .
                "🏁 گروه‌های تمام شده: {$stats['finished_groups']}\n\n" .
                "📅 آخرین بروزرسانی: " . date('Y-m-d H:i:s');
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // مدیریت کاربران
    public function showUsersPanel($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $users = $this->db['users'];
        $regularUsers = array_filter($users, function($user) {
            return !$user['is_mediator'] && !$user['is_admin'];
        });
        
        $text = "👥 <b>مدیریت کاربران</b>\n\n";
        $text .= "📊 تعداد کاربران عادی: " . count($regularUsers) . "\n\n";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '➕ اضافه کردن واسطه‌گر', 'callback_data' => 'show_users_for_mediator']],
                [['text' => '📋 لیست کاربران', 'callback_data' => 'list_all_users']],
                [['text' => '🚫 مسدود کردن کاربر', 'callback_data' => 'block_user']],
                [['text' => '🔄 بازگشت', 'callback_data' => 'admin_main']]
            ]
        ];
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // نمایش لیست کاربران برای انتخاب واسطه‌گر
    public function showUsersForMediatorSelection($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $users = $this->db['users'];
        $regularUsers = array_filter($users, function($user) {
            return !$user['is_mediator'] && !$user['is_admin'];
        });
        
        if (empty($regularUsers)) {
            $this->sendMessage($adminId, "❌ هیچ کاربر عادی برای تبدیل به واسطه‌گر وجود ندارد!");
            return false;
        }
        
        $keyboard = ['inline_keyboard' => []];
        $text = "👥 <b>انتخاب کاربر برای واسطه‌گری</b>\n\n";
        
        $counter = 0;
        foreach ($regularUsers as $user) {
            if ($counter >= 10) break; // نمایش حداکثر 10 کاربر
            
            $name = $user['first_name'] ?: 'بدون نام';
            $username = $user['username'] ? "@{$user['username']}" : "ID: {$user['id']}";
            
            $text .= "👤 $name ($username)\n";
            
            $keyboard['inline_keyboard'][] = [
                ['text' => "✅ انتخاب $name", 'callback_data' => "add_mediator_{$user['id']}"]
            ];
            
            $counter++;
        }
        
        $keyboard['inline_keyboard'][] = [
            ['text' => '🔄 بازگشت', 'callback_data' => 'admin_users']
        ];
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // اضافه کردن واسطه‌گر
    public function addMediator($adminId, $userId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        if (!isset($this->db['users'][$userId])) {
            return 'user_not_found';
        }
        
        if ($this->db['users'][$userId]['is_mediator']) {
            return 'already_mediator';
        }
        
        $this->db['users'][$userId]['is_mediator'] = true;
        $this->db['users'][$userId]['mediator_since'] = date('Y-m-d H:i:s');
        $this->db['users'][$userId]['ratings_received'] = [];
        $this->saveDatabase();
        
        // اطلاع به کاربر
        $this->sendMessage(
            $userId, 
            "🎉 <b>تبریک!</b>\n\n" .
            "شما به عنوان واسطه‌گر ربات انتخاب شدید!\n\n" .
            "📋 وظایف شما:\n" .
            "• کمک به حل اختلافات\n" .
            "• واسطه‌گری بین کاربران\n" .
            "• حفظ بی‌طرفی\n\n" .
            "✅ اکنون می‌توانید درخواست‌های واسطه‌گری را دریافت کنید"
        );
        
        // اطلاع به ادمین
        $user = $this->db['users'][$userId];
        $this->sendMessage(
            $adminId,
            "✅ کاربر {$user['first_name']} با موفقیت به واسطه‌گران اضافه شد!"
        );
        
        return true;
    }
    
    // حذف واسطه‌گر
    public function removeMediator($adminId, $userId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        if (!isset($this->db['users'][$userId]) || !$this->db['users'][$userId]['is_mediator']) {
            return 'not_mediator';
        }
        
        $this->db['users'][$userId]['is_mediator'] = false;
        $this->db['users'][$userId]['mediator_until'] = date('Y-m-d H:i:s');
        $this->saveDatabase();
        
        // اطلاع به کاربر
        $this->sendMessage(
            $userId,
            "📢 شما دیگر واسطه‌گر ربات نیستید.\n" .
            "ممنون از همکاری‌تان!"
        );
        
        return true;
    }
    
    // مدیریت واسطه‌گرها
    public function showMediatorsPanel($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $mediators = array_filter($this->db['users'], function($user) {
            return $user['is_mediator'];
        });
        
        $text = "👨‍💼 <b>مدیریت واسطه‌گرها</b>\n\n";
        $text .= "📊 تعداد واسطه‌گرها: " . count($mediators) . "\n\n";
        
        if (!empty($mediators)) {
            foreach ($mediators as $mediator) {
                $name = $mediator['first_name'] ?: 'بدون نام';
                $ratings = $mediator['ratings_received'] ?? [];
                $avgRating = $this->calculateAverageRating($ratings);
                
                $text .= "👤 $name\n";
                $text .= "⭐ امتیاز: $avgRating (" . count($ratings) . " نظر)\n";
                $text .= "📅 واسطه‌گر از: " . date('Y-m-d', strtotime($mediator['mediator_since'] ?? $mediator['created_at'])) . "\n\n";
            }
        }
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '➕ اضافه کردن واسطه‌گر', 'callback_data' => 'show_users_for_mediator']],
                [['text' => '📊 آمار واسطه‌گرها', 'callback_data' => 'mediators_stats']],
                [['text' => '❌ حذف واسطه‌گر', 'callback_data' => 'remove_mediator']],
                [['text' => '🔄 بازگشت', 'callback_data' => 'admin_main']]
            ]
        ];
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // نمایش آمار کامل
    public function showDetailedStats($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $stats = $this->getDetailedStats();
        
        $text = "📊 <b>آمار کامل ربات</b>\n\n";
        
        $text .= "👥 <b>کاربران:</b>\n";
        $text .= "• کل کاربران: {$stats['total_users']}\n";
        $text .= "• کاربران عادی: {$stats['regular_users']}\n";
        $text .= "• واسطه‌گرها: {$stats['mediators']}\n";
        $text .= "• ادمین‌ها: {$stats['admins']}\n\n";
        
        $text .= "📁 <b>گروه‌ها:</b>\n";
        $text .= "• کل گروه‌ها: {$stats['total_groups']}\n";
        $text .= "• منتظر شرکت‌کننده: {$stats['waiting_participant']}\n";
        $text .= "• منتظر واسطه‌گر: {$stats['waiting_mediator']}\n";
        $text .= "• فعال: {$stats['active_groups']}\n";
        $text .= "• تمام شده: {$stats['finished_groups']}\n\n";
        
        $text .= "⭐ <b>امتیازدهی:</b>\n";
        $text .= "• کل امتیازها: {$stats['total_ratings']}\n";
        $text .= "• میانگین کلی: {$stats['average_rating']}\n\n";
        
        $text .= "📈 <b>فعالیت امروز:</b>\n";
        $text .= "• گروه‌های جدید: {$stats['today_groups']}\n";
        $text .= "• کاربران جدید: {$stats['today_users']}\n";
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📁 جزئیات گروه‌ها', 'callback_data' => 'admin_groups']],
                [['text' => '💾 پشتیبان‌گیری', 'callback_data' => 'backup_data']],
                [['text' => '🔄 بازگشت', 'callback_data' => 'admin_main']]
            ]
        ];
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // مدیریت گروه‌ها
    public function showGroupsPanel($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $activeGroups = array_filter($this->db['groups'], function($group) {
            return $group['status'] === 'active';
        });
        
        $waitingGroups = array_filter($this->db['groups'], function($group) {
            return in_array($group['status'], ['waiting_for_participant', 'waiting_for_mediator']);
        });
        
        $text = "📁 <b>مدیریت گروه‌ها</b>\n\n";
        $text .= "✅ گروه‌های فعال: " . count($activeGroups) . "\n";
        $text .= "⏳ گروه‌های در انتظار: " . count($waitingGroups) . "\n\n";
        
        if (!empty($activeGroups)) {
            $text .= "<b>گروه‌های فعال:</b>\n";
            foreach (array_slice($activeGroups, 0, 5) as $code => $group) {
                $creator = $this->db['users'][$group['creator_id']];
                $participant = $this->db['users'][$group['participant_id']];
                $mediator = $this->db['users'][$group['mediator_id']];
                
                $text .= "🔑 $code\n";
                $text .= "👥 {$creator['first_name']} ↔ {$participant['first_name']}\n";
                $text .= "👨‍💼 واسطه‌گر: {$mediator['first_name']}\n\n";
            }
        }
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📋 لیست کامل گروه‌ها', 'callback_data' => 'list_all_groups']],
                [['text' => '🔍 جستجوی گروه', 'callback_data' => 'search_group']],
                [['text' => '⚠️ گروه‌های مشکل‌دار', 'callback_data' => 'problematic_groups']],
                [['text' => '🔄 بازگشت', 'callback_data' => 'admin_main']]
            ]
        ];
        
        $this->sendMessage($adminId, $text, $keyboard);
        return true;
    }
    
    // بررسی ادمین بودن
    private function isAdmin($userId) {
        return isset($this->db['users'][$userId]) && $this->db['users'][$userId]['is_admin'];
    }
    
    // محاسبه میانگین امتیاز
    private function calculateAverageRating($ratings) {
        if (empty($ratings)) {
            return "بدون امتیاز";
        }
        
        $sum = array_sum(array_column($ratings, 'rating'));
        $avg = $sum / count($ratings);
        
        return number_format($avg, 1) . "/5";
    }
    
    // دریافت آمار کلی
    private function getStats() {
        $users = $this->db['users'];
        $groups = $this->db['groups'];
        
        return [
            'total_users' => count($users),
            'total_mediators' => count(array_filter($users, function($u) { return $u['is_mediator']; })),
            'total_groups' => count($groups),
            'active_groups' => count(array_filter($groups, function($g) { return $g['status'] === 'active'; })),
            'finished_groups' => count(array_filter($groups, function($g) { return $g['status'] === 'finished'; }))
        ];
    }
    
    // دریافت آمار تفصیلی
    private function getDetailedStats() {
        $users = $this->db['users'];
        $groups = $this->db['groups'];
        
        $today = date('Y-m-d');
        
        $todayGroups = count(array_filter($groups, function($g) use ($today) {
            return strpos($g['created_at'], $today) === 0;
        }));
        
        $todayUsers = count(array_filter($users, function($u) use ($today) {
            return strpos($u['created_at'], $today) === 0;
        }));
        
        $allRatings = [];
        foreach ($users as $user) {
            if (isset($user['ratings_received'])) {
                $allRatings = array_merge($allRatings, $user['ratings_received']);
            }
        }
        
        $avgRating = empty($allRatings) ? 0 : array_sum(array_column($allRatings, 'rating')) / count($allRatings);
        
        return [
            'total_users' => count($users),
            'regular_users' => count(array_filter($users, function($u) { return !$u['is_mediator'] && !$u['is_admin']; })),
            'mediators' => count(array_filter($users, function($u) { return $u['is_mediator']; })),
            'admins' => count(array_filter($users, function($u) { return $u['is_admin']; })),
            'total_groups' => count($groups),
            'waiting_participant' => count(array_filter($groups, function($g) { return $g['status'] === 'waiting_for_participant'; })),
            'waiting_mediator' => count(array_filter($groups, function($g) { return $g['status'] === 'waiting_for_mediator'; })),
            'active_groups' => count(array_filter($groups, function($g) { return $g['status'] === 'active'; })),
            'finished_groups' => count(array_filter($groups, function($g) { return $g['status'] === 'finished'; })),
            'total_ratings' => count($allRatings),
            'average_rating' => number_format($avgRating, 1) . "/5",
            'today_groups' => $todayGroups,
            'today_users' => $todayUsers
        ];
    }
    
    // پشتیبان‌گیری از دیتابیس
    public function backupDatabase($adminId) {
        if (!$this->isAdmin($adminId)) {
            return false;
        }
        
        $backupFile = 'backup_' . date('Y-m-d_H-i-s') . '.json';
        $backupPath = 'backups/' . $backupFile;
        
        // ایجاد پوشه بکاپ
        if (!is_dir('backups')) {
            mkdir('backups', 0755, true);
        }
        
        // کپی کردن فایل دیتابیس
        if (copy(DB_FILE, $backupPath)) {
            $this->sendMessage(
                $adminId,
                "✅ پشتیبان‌گیری با موفقیت انجام شد!\n\n" .
                "📁 فایل: $backupFile\n" .
                "📅 تاریخ: " . date('Y-m-d H:i:s')
            );
            return true;
        } else {
            $this->sendMessage($adminId, "❌ خطا در پشتیبان‌گیری!");
            return false;
        }
    }
}
?>
