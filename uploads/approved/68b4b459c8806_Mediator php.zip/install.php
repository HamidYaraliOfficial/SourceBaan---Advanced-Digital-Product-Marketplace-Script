<?php
// اسکریپت نصب و راه‌اندازی ربات واسطه‌گر

echo "🤖 راه‌اندازی ربات واسطه‌گر تلگرام\n\n";

// بررسی فایل کانفیگ
if (!file_exists('config.php')) {
    die("❌ فایل config.php وجود ندارد!\n");
}

require_once 'config.php';

// بررسی توکن ربات
if (BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
    die("❌ لطفاً توکن ربات را در فایل config.php وارد کنید!\n");
}

// بررسی اتصال به API تلگرام
echo "🔄 بررسی اتصال به API تلگرام...\n";
$testUrl = "https://api.telegram.org/bot" . BOT_TOKEN . "/getMe";

$context = stream_context_create([
    'http' => [
        'timeout' => 10
    ]
]);

$response = @file_get_contents($testUrl, false, $context);
if ($response === false) {
    die("❌ خطا در اتصال به API تلگرام!\n");
}

$result = json_decode($response, true);
if (!$result || !isset($result['ok']) || !$result['ok']) {
    die("❌ توکن ربات نامعتبر است!\n");
}

echo "✅ ربات تأیید شد: " . $result['result']['first_name'] . "\n";

// ایجاد دیتابیس اولیه
if (!file_exists('database.json')) {
    echo "🔄 ایجاد فایل دیتابیس...\n";
    $initialData = [
        'users' => [],
        'groups' => [],
        'mediators' => [],
        'ratings' => [],
        'settings' => [
            'bot_status' => 'active',
            'total_groups' => 0,
            'total_users' => 0,
            'installed_at' => date('Y-m-d H:i:s')
        ]
    ];
    
    file_put_contents('database.json', json_encode($initialData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    echo "✅ فایل دیتابیس ایجاد شد\n";
}

// ایجاد پوشه بکاپ
if (!is_dir('backups')) {
    echo "🔄 ایجاد پوشه بکاپ...\n";
    mkdir('backups', 0755, true);
    echo "✅ پوشه بکاپ ایجاد شد\n";
}

// ایجاد فایل لاگ
if (!file_exists('bot.log')) {
    echo "🔄 ایجاد فایل لاگ...\n";
    file_put_contents('bot.log', "Bot log started at " . date('Y-m-d H:i:s') . "\n");
    echo "✅ فایل لاگ ایجاد شد\n";
}

// تنظیم webhook (اختیاری)
if (WEBHOOK_URL !== 'https://yourdomain.com/bot.php') {
    echo "🔄 تنظیم webhook...\n";
    $webhookUrl = "https://api.telegram.org/bot" . BOT_TOKEN . "/setWebhook?url=" . urlencode(WEBHOOK_URL);
    $webhookResponse = file_get_contents($webhookUrl);
    $webhookResult = json_decode($webhookResponse, true);
    
    if ($webhookResult && $webhookResult['ok']) {
        echo "✅ Webhook تنظیم شد: " . WEBHOOK_URL . "\n";
    } else {
        echo "⚠️ خطا در تنظیم webhook. می‌توانید بعداً تنظیم کنید.\n";
    }
}

// اضافه کردن ادمین اصلی
if (ADMIN_ID !== '123456789') {
    echo "🔄 تنظیم ادمین اصلی...\n";
    
    // بارگذاری دیتابیس
    $db = json_decode(file_get_contents('database.json'), true);
    
    // اضافه کردن ادمین
    $db['users'][ADMIN_ID] = [
        'id' => ADMIN_ID,
        'username' => '',
        'first_name' => 'ادمین',
        'is_mediator' => true,
        'is_admin' => true,
        'created_at' => date('Y-m-d H:i:s'),
        'groups' => [],
        'ratings_given' => [],
        'ratings_received' => []
    ];
    
    $db['settings']['total_users'] = 1;
    
    // ذخیره دیتابیس
    file_put_contents('database.json', json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo "✅ ادمین اصلی اضافه شد (ID: " . ADMIN_ID . ")\n";
}

echo "\n🎉 نصب با موفقیت تکمیل شد!\n\n";
echo "📋 مراحل بعدی:\n";
echo "1. فایل bot.php را روی سرور آپلود کنید\n";
echo "2. webhook را در صورت نیاز تنظیم کنید\n";
echo "3. دستور /start را در ربات تایپ کنید\n";
echo "4. از دستور /admin برای ورود به پنل مدیریت استفاده کنید\n\n";
echo "✅ ربات آماده استفاده است!\n";
?>
