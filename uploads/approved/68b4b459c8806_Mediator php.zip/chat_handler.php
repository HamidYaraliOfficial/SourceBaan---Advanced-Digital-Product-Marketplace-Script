<?php
require_once 'config.php';

class ChatHandler {
    private $db;
    private $bot;
    
    public function __construct() {
        $this->loadDatabase();
    }
    
    private function loadDatabase() {
        if (file_exists(DB_FILE)) {
            $this->db = json_decode(file_get_contents(DB_FILE), true);
        }
    }
    
    private function saveDatabase() {
        file_put_contents(DB_FILE, json_encode($this->db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    // ارسال پیام
    private function sendMessage($chatId, $text, $keyboard = null) {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $result = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($result, true);
    }
    
    // شروع چت با کاربر مشخص
    public function startChatWith($mediatorId, $targetUserId, $groupCode) {
        $this->loadDatabase(); // بارگذاری مجدد دیتابیس
        
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = $this->db['groups'][$groupCode];
        
        // بررسی اجازه واسطه‌گر
        if ($group['mediator_id'] != $mediatorId) {
            return false;
        }
        
        // بررسی وجود کاربر هدف
        if (!isset($this->db['users'][$targetUserId])) {
            return false;
        }
        
        // تنظیم حالت چت
        if (!isset($this->db['users'][$mediatorId])) {
            return false;
        }
        
        $this->db['users'][$mediatorId]['chat_mode'] = [
            'active' => true,
            'target_user' => $targetUserId,
            'group_code' => $groupCode
        ];
        
        $this->saveDatabase();
        
        $targetUser = $this->db['users'][$targetUserId];
        
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '🔚 پایان چت', 'callback_data' => "end_chat_$groupCode"],
                ['text' => '🔄 بازگشت به پنل', 'callback_data' => "show_panel_$groupCode"]
            ]]
        ];
        
        $this->sendMessage(
            $mediatorId,
            "💬 چت با {$targetUser['first_name']} شروع شد\n\n" .
            "📝 پیام‌های شما به {$targetUser['first_name']} ارسال می‌شود\n" .
            "برای پایان چت از دکمه زیر استفاده کنید",
            $keyboard
        );
        
        // تنظیم حالت چت برای کاربر هدف
        $this->db['users'][$targetUserId]['chat_mode'] = [
            'active' => true,
            'target_user' => $mediatorId,
            'group_code' => $groupCode,
            'is_user' => true
        ];
        
        $this->saveDatabase();
        
        // اطلاع به کاربر هدف
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '🔚 پایان چت', 'callback_data' => "end_user_chat_$groupCode"]
            ]]
        ];
        
        $this->sendMessage(
            $targetUserId,
            MESSAGES['chat_started_user'],
            $keyboard
        );
        
        return true;
    }
    
    // پایان چت توسط واسطه‌گر
    public function endChat($mediatorId, $groupCode) {
        $this->loadDatabase();
        
        if (!isset($this->db['users'][$mediatorId]['chat_mode'])) {
            return false;
        }
        
        $chatMode = $this->db['users'][$mediatorId]['chat_mode'];
        $targetUserId = $chatMode['target_user'];
        
        // غیرفعال کردن حالت چت برای واسطه‌گر
        unset($this->db['users'][$mediatorId]['chat_mode']);
        
        // غیرفعال کردن حالت چت برای کاربر
        if (isset($this->db['users'][$targetUserId]['chat_mode'])) {
            unset($this->db['users'][$targetUserId]['chat_mode']);
        }
        
        $this->saveDatabase();
        
        // اطلاع به طرفین
        $this->sendMessage($mediatorId, "✅ چت به پایان رسید");
        $this->sendMessage($targetUserId, MESSAGES['chat_ended_user']);
        
        // بازگشت به پنل واسطه‌گر
        $this->showMediatorPanel($mediatorId, $groupCode);
        
        return true;
    }
    
    // پایان چت توسط کاربر
    public function endUserChat($userId, $groupCode) {
        $this->loadDatabase();
        
        if (!isset($this->db['users'][$userId]['chat_mode'])) {
            return false;
        }
        
        $chatMode = $this->db['users'][$userId]['chat_mode'];
        $mediatorId = $chatMode['target_user'];
        
        // غیرفعال کردن حالت چت برای کاربر
        unset($this->db['users'][$userId]['chat_mode']);
        $this->saveDatabase();
        
        // اطلاع به طرفین
        $this->sendMessage($userId, MESSAGES['chat_ended_user']);
        $this->sendMessage($mediatorId, "🔚 کاربر چت را پایان داد");
        
        return true;
    }
    
    // نمایش پنل واسطه‌گر
    public function showMediatorPanel($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = $this->db['groups'][$groupCode];
        
        if ($group['status'] !== 'active' || $group['mediator_id'] !== $mediatorId) {
            return false;
        }
        
        $creator = $this->db['users'][$group['creator_id']];
        $participant = $this->db['users'][$group['participant_id']];
        
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => "💬 چت با {$creator['first_name']}", 'callback_data' => "chat_with_{$group['creator_id']}_$groupCode"],
                    ['text' => "💬 چت با {$participant['first_name']}", 'callback_data' => "chat_with_{$group['participant_id']}_$groupCode"]
                ],
                [
                    ['text' => '📋 مشاهده تاریخچه', 'callback_data' => "show_history_$groupCode"],
                    ['text' => '📊 اطلاعات گروه', 'callback_data' => "group_info_$groupCode"]
                ],
                [
                    ['text' => '✅ اتمام واسطه‌گری', 'callback_data' => "finish_mediation_$groupCode"]
                ]
            ]
        ];
        
        $text = "🎛 <b>پنل واسطه‌گری</b>\n\n" .
                "🔑 کد گروه: <code>$groupCode</code>\n" .
                "👤 کاربر اول: {$creator['first_name']}\n" .
                "👤 کاربر دوم: {$participant['first_name']}\n\n" .
                "💡 با کدام کاربر می‌خواهید صحبت کنید؟";
        
        $this->sendMessage($mediatorId, $text, $keyboard);
        
        return true;
    }
    
    // پردازش پیام در حالت چت
    public function handleChatMessage($userId, $messageText, $messageType = 'text') {
        $this->loadDatabase();
        
        if (!isset($this->db['users'][$userId])) {
            return false;
        }
        
        $user = $this->db['users'][$userId];
        
        // بررسی حالت چت فعال
        if (isset($user['chat_mode']) && $user['chat_mode']['active']) {
            if (isset($user['chat_mode']['is_user']) && $user['chat_mode']['is_user']) {
                // کاربر عادی در حال چت با واسطه‌گر
                $this->forwardUserToMediatorMessage($userId, $messageText, $messageType);
            } else {
                // واسطه‌گر در حال چت با کاربر
                $this->forwardMediatorMessage($userId, $messageText, $messageType);
            }
            return true;
        }
        
        // بررسی کاربر عادی که در گروه فعال است (بدون چت مستقیم)
        foreach ($this->db['groups'] as $groupCode => $group) {
            if ($group['status'] === 'active' && 
                ($group['creator_id'] == $userId || $group['participant_id'] == $userId)) {
                
                $this->forwardUserMessage($userId, $groupCode, $messageText, $messageType);
                return true;
            }
        }
        
        return false;
    }
    
    // ارسال پیام کاربر به واسطه‌گر (در چت مستقیم)
    private function forwardUserToMediatorMessage($userId, $messageText, $messageType) {
        $chatMode = $this->db['users'][$userId]['chat_mode'];
        $mediatorId = $chatMode['target_user'];
        $groupCode = $chatMode['group_code'];
        
        // ذخیره پیام در تاریخچه
        $this->saveMessageToHistory($groupCode, $userId, $mediatorId, $messageText, $messageType);
        
        $user = $this->db['users'][$userId];
        $prefix = "📨 <b>پیام از {$user['first_name']}:</b>\n";
        
        // ارسال به واسطه‌گر
        $this->sendMessage($mediatorId, $prefix . $messageText);
        
        // تایید ارسال به کاربر
        $this->sendMessage($userId, "✅ پیام ارسال شد");
    }
    
    // ارسال پیام واسطه‌گر به کاربر
    private function forwardMediatorMessage($mediatorId, $messageText, $messageType) {
        $chatMode = $this->db['users'][$mediatorId]['chat_mode'];
        $targetUserId = $chatMode['target_user'];
        $groupCode = $chatMode['group_code'];
        
        // ذخیره پیام در تاریخچه
        $this->saveMessageToHistory($groupCode, $mediatorId, $targetUserId, $messageText, $messageType);
        
        // ارسال به کاربر هدف
        $mediator = $this->db['users'][$mediatorId];
        $prefix = "💬 <b>واسطه‌گر:</b>\n";
        
        $this->sendMessage($targetUserId, $prefix . $messageText);
        
        // تایید ارسال به واسطه‌گر
        $this->sendMessage($mediatorId, "✅ پیام ارسال شد");
    }
    
    // ارسال پیام کاربر به واسطه‌گر
    private function forwardUserMessage($userId, $groupCode, $messageText, $messageType) {
        $group = $this->db['groups'][$groupCode];
        $mediatorId = $group['mediator_id'];
        
        if (!$mediatorId) {
            return false;
        }
        
        // ذخیره پیام در تاریخچه
        $this->saveMessageToHistory($groupCode, $userId, $mediatorId, $messageText, $messageType);
        
        $user = $this->db['users'][$userId];
        $prefix = "📨 <b>از {$user['first_name']}:</b>\n";
        
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => "💬 پاسخ به {$user['first_name']}", 'callback_data' => "chat_with_{$userId}_{$groupCode}"],
                ['text' => '🎛 پنل واسطه‌گری', 'callback_data' => "show_panel_$groupCode"]
            ]]
        ];
        
        $this->sendMessage($mediatorId, $prefix . $messageText, $keyboard);
    }
    
    // ذخیره پیام در تاریخچه
    private function saveMessageToHistory($groupCode, $fromUserId, $toUserId, $message, $type = 'text') {
        if (!isset($this->db['groups'][$groupCode]['messages'])) {
            $this->db['groups'][$groupCode]['messages'] = [];
        }
        
        $this->db['groups'][$groupCode]['messages'][] = [
            'from' => $fromUserId,
            'to' => $toUserId,
            'message' => $message,
            'type' => $type,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        $this->saveDatabase();
    }
    
    // نمایش تاریخچه گروه
    public function showGroupHistory($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = $this->db['groups'][$groupCode];
        
        if ($group['mediator_id'] !== $mediatorId) {
            return false;
        }
        
        $messages = $group['messages'] ?? [];
        
        if (empty($messages)) {
            $this->sendMessage($mediatorId, "📋 هنوز پیامی در این گروه رد و بدل نشده است");
            return true;
        }
        
        $historyText = "📋 <b>تاریخچه گروه $groupCode</b>\n\n";
        
        foreach (array_slice($messages, -10) as $msg) { // نمایش 10 پیام آخر
            $fromUser = $this->db['users'][$msg['from']];
            $timestamp = date('H:i', strtotime($msg['timestamp']));
            
            $historyText .= "🕐 $timestamp - {$fromUser['first_name']}:\n";
            $historyText .= $msg['message'] . "\n\n";
        }
        
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '🔄 بازگشت به پنل', 'callback_data' => "show_panel_$groupCode"]
            ]]
        ];
        
        $this->sendMessage($mediatorId, $historyText, $keyboard);
        
        return true;
    }
    
    // نمایش اطلاعات گروه
    public function showGroupInfo($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = $this->db['groups'][$groupCode];
        
        if ($group['mediator_id'] !== $mediatorId) {
            return false;
        }
        
        $creator = $this->db['users'][$group['creator_id']];
        $participant = $this->db['users'][$group['participant_id']];
        $messageCount = count($group['messages'] ?? []);
        
        $infoText = "📊 <b>اطلاعات گروه</b>\n\n" .
                   "🔑 کد گروه: <code>$groupCode</code>\n" .
                   "📅 تاریخ ایجاد: {$group['created_at']}\n" .
                   "👤 کاربر اول: {$creator['first_name']}\n" .
                   "👤 کاربر دوم: {$participant['first_name']}\n" .
                   "💬 تعداد پیام‌ها: $messageCount\n" .
                   "📈 وضعیت: " . $this->getStatusText($group['status']);
        
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '🔄 بازگشت به پنل', 'callback_data' => "show_panel_$groupCode"]
            ]]
        ];
        
        $this->sendMessage($mediatorId, $infoText, $keyboard);
        
        return true;
    }
    
    private function getStatusText($status) {
        switch ($status) {
            case 'waiting_for_participant':
                return '⏳ منتظر شرکت‌کننده';
            case 'waiting_for_mediator':
                return '⏳ منتظر واسطه‌گر';
            case 'active':
                return '✅ فعال';
            case 'finished':
                return '🏁 تمام شده';
            default:
                return '❓ نامشخص';
        }
    }
}
?>
