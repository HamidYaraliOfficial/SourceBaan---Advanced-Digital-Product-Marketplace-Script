<?php
require_once 'config.php';
require_once 'chat_handler.php';
require_once 'admin_panel.php';

class MediatorBot {
    private $db;
    private $chatHandler;
    private $adminPanel;
    
    public function __construct() {
        $this->loadDatabase();
        $this->chatHandler = new ChatHandler();
        $this->adminPanel = new AdminPanel();
    }
    
    // بارگذاری دیتابیس
    private function loadDatabase() {
        if (file_exists(DB_FILE)) {
            $this->db = json_decode(file_get_contents(DB_FILE), true);
        } else {
            $this->db = [
                'users' => [],
                'groups' => [],
                'mediators' => [],
                'ratings' => [],
                'settings' => [
                    'bot_status' => 'active',
                    'total_groups' => 0,
                    'total_users' => 0
                ]
            ];
            $this->saveDatabase();
        }
    }
    
    // ذخیره دیتابیس
    private function saveDatabase() {
        file_put_contents(DB_FILE, json_encode($this->db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    // ارسال پیام
    private function sendMessage($chatId, $text, $keyboard = null) {
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];
        
        if ($keyboard) {
            $data['reply_markup'] = json_encode($keyboard);
        }
        
        $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $result = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($result, true);
    }
    
    // ثبت کاربر جدید
    private function registerUser($userId, $username = '', $firstName = '') {
        if (!isset($this->db['users'][$userId])) {
            $this->db['users'][$userId] = [
                'id' => $userId,
                'username' => $username,
                'first_name' => $firstName,
                'is_mediator' => false,
                'is_admin' => ($userId == ADMIN_ID),
                'created_at' => date('Y-m-d H:i:s'),
                'groups' => [],
                'ratings_given' => [],
                'ratings_received' => []
            ];
            $this->db['settings']['total_users']++;
            $this->saveDatabase();
        }
    }
    
    // ایجاد گروه جدید
    private function createGroup($creatorId) {
        $code = generateCode();
        
        // اطمینان از یکتا بودن کد
        while (isset($this->db['groups'][$code])) {
            $code = generateCode();
        }
        
        $this->db['groups'][$code] = [
            'code' => $code,
            'creator_id' => $creatorId,
            'participant_id' => null,
            'mediator_id' => null,
            'status' => 'waiting_for_participant', // waiting_for_participant, active, finished
            'created_at' => date('Y-m-d H:i:s'),
            'messages' => [],
            'rating_given' => false
        ];
        
        $this->db['settings']['total_groups']++;
        $this->saveDatabase();
        
        return $code;
    }
    
    // پیوستن به گروه
    private function joinGroup($userId, $code) {
        if (!isset($this->db['groups'][$code])) {
            return false;
        }
        
        $group = &$this->db['groups'][$code];
        
        if ($group['creator_id'] == $userId) {
            return 'creator_cannot_join';
        }
        
        if ($group['status'] !== 'waiting_for_participant') {
            return 'group_full';
        }
        
        $group['participant_id'] = $userId;
        $group['status'] = 'waiting_for_mediator';
        
        // اضافه کردن گروه به لیست کاربران
        $this->db['users'][$group['creator_id']]['groups'][] = $code;
        $this->db['users'][$userId]['groups'][] = $code;
        
        $this->saveDatabase();
        
        // اطلاع به سازنده گروه
        $this->sendMessage($group['creator_id'], "✅ کاربری به گروه شما پیوست!\n⏳ منتظر تخصیص واسطه‌گر باشید");
        
        // درخواست واسطه‌گری به ادمین‌ها
        $this->notifyMediatorsForNewGroup($code);
        
        return true;
    }
    
    // اطلاع‌رسانی به واسطه‌گرها
    private function notifyMediatorsForNewGroup($groupCode) {
        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '📞 پذیرش واسطه‌گری', 'callback_data' => "accept_mediation_$groupCode"]
            ]]
        ];
        
        foreach ($this->db['users'] as $user) {
            if ($user['is_mediator'] || $user['is_admin']) {
                $this->sendMessage(
                    $user['id'], 
                    "🆕 درخواست واسطه‌گری جدید!\n🔑 کد گروه: $groupCode\n\n" .
                    "آیا مایل به پذیرش این واسطه‌گری هستید؟", 
                    $keyboard
                );
            }
        }
    }
    
    // پذیرش واسطه‌گری
    private function acceptMediation($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = &$this->db['groups'][$groupCode];
        
        if ($group['status'] !== 'waiting_for_mediator') {
            return 'already_assigned';
        }
        
        $group['mediator_id'] = $mediatorId;
        $group['status'] = 'active';
        $this->saveDatabase();
        
        // اطلاع به طرفین
        $this->sendMessage($group['creator_id'], MESSAGES['mediator_assigned']);
        $this->sendMessage($group['participant_id'], MESSAGES['mediator_assigned']);
        
        // پنل واسطه‌گر
        $this->showMediatorPanel($mediatorId, $groupCode);
        
        return true;
    }
    
    // نمایش پنل واسطه‌گر
    private function showMediatorPanel($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = $this->db['groups'][$groupCode];
        
        if (!isset($this->db['users'][$group['creator_id']]) || 
            !isset($this->db['users'][$group['participant_id']])) {
            return false;
        }
        
        $creator = $this->db['users'][$group['creator_id']];
        $participant = $this->db['users'][$group['participant_id']];
        
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => "💬 چت با {$creator['first_name']}", 'callback_data' => "chat_with_{$group['creator_id']}_$groupCode"],
                    ['text' => "💬 چت با {$participant['first_name']}", 'callback_data' => "chat_with_{$group['participant_id']}_$groupCode"]
                ],
                [
                    ['text' => '📋 تاریخچه', 'callback_data' => "show_history_$groupCode"],
                    ['text' => '📊 اطلاعات', 'callback_data' => "group_info_$groupCode"]
                ],
                [
                    ['text' => '✅ اتمام واسطه‌گری', 'callback_data' => "finish_mediation_$groupCode"]
                ]
            ]
        ];
        
        $this->sendMessage(
            $mediatorId, 
            "🎛 پنل واسطه‌گری\n\n" .
            "🔑 کد گروه: <code>$groupCode</code>\n" .
            "👤 کاربر اول: {$creator['first_name']}\n" .
            "👤 کاربر دوم: {$participant['first_name']}\n\n" .
            "💡 با کدام کاربر می‌خواهید چت کنید؟", 
            $keyboard
        );
        
        return true;
    }
    
    // اتمام واسطه‌گری
    private function finishMediation($mediatorId, $groupCode) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = &$this->db['groups'][$groupCode];
        
        if ($group['mediator_id'] !== $mediatorId || $group['status'] !== 'active') {
            return false;
        }
        
        $group['status'] = 'finished';
        $group['finished_at'] = date('Y-m-d H:i:s');
        $this->saveDatabase();
        
        // اطلاع به طرفین
        $this->sendMessage($group['creator_id'], MESSAGES['group_finished']);
        $this->sendMessage($group['participant_id'], MESSAGES['group_finished']);
        
        // ارسال نظرسنجی به سازنده گروه
        $this->sendRatingRequest($group['creator_id'], $groupCode);
        
        return true;
    }
    
    // ارسال درخواست امتیازدهی
    private function sendRatingRequest($userId, $groupCode) {
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '⭐', 'callback_data' => "rate_{$groupCode}_1"],
                    ['text' => '⭐⭐', 'callback_data' => "rate_{$groupCode}_2"],
                    ['text' => '⭐⭐⭐', 'callback_data' => "rate_{$groupCode}_3"],
                    ['text' => '⭐⭐⭐⭐', 'callback_data' => "rate_{$groupCode}_4"],
                    ['text' => '⭐⭐⭐⭐⭐', 'callback_data' => "rate_{$groupCode}_5"]
                ]
            ]
        ];
        
        $this->sendMessage(
            $userId, 
            "⭐ لطفاً واسطه‌گر را از 1 تا 5 ستاره امتیاز دهید:\n\n" .
            "1⭐ = ضعیف\n" .
            "5⭐ = عالی", 
            $keyboard
        );
    }
    
    // ثبت امتیاز
    private function submitRating($userId, $groupCode, $rating) {
        if (!isset($this->db['groups'][$groupCode])) {
            return false;
        }
        
        $group = &$this->db['groups'][$groupCode];
        
        if ($group['creator_id'] !== $userId || $group['rating_given']) {
            return false;
        }
        
        $group['rating_given'] = true;
        $group['rating'] = $rating;
        
        // ثبت امتیاز در پروفایل واسطه‌گر
        $mediatorId = $group['mediator_id'];
        if (!isset($this->db['users'][$mediatorId]['ratings_received'])) {
            $this->db['users'][$mediatorId]['ratings_received'] = [];
        }
        
        $this->db['users'][$mediatorId]['ratings_received'][] = [
            'rating' => $rating,
            'group_code' => $groupCode,
            'date' => date('Y-m-d H:i:s')
        ];
        
        $this->saveDatabase();
        
        $this->sendMessage($userId, MESSAGES['rating_thanks']);
        
        return true;
    }
    
    // پردازش پیام‌ها
    public function processUpdate($update) {
        logMessage("Update received: " . json_encode($update));
        
        if (isset($update['message'])) {
            $this->handleMessage($update['message']);
        } elseif (isset($update['callback_query'])) {
            $this->handleCallbackQuery($update['callback_query']);
        }
    }
    
    // پردازش پیام‌های متنی
    private function handleMessage($message) {
        $chatId = $message['chat']['id'];
        $text = $message['text'] ?? '';
        $userId = $message['from']['id'];
        $username = $message['from']['username'] ?? '';
        $firstName = $message['from']['first_name'] ?? '';
        
        // ثبت کاربر
        $this->registerUser($userId, $username, $firstName);
        
        if ($text === '/start') {
            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '🆕 ایجاد گروه جدید', 'callback_data' => 'create_new_group'],
                        ['text' => '🔗 پیوستن به گروه', 'callback_data' => 'join_group_menu']
                    ],
                    [
                        ['text' => '❓ راهنما', 'callback_data' => 'show_help'],
                        ['text' => '📊 وضعیت من', 'callback_data' => 'my_status']
                    ]
                ]
            ];
            
            $this->sendMessage($chatId, MESSAGES['start'], $keyboard);
            
        } elseif ($text === '/help') {
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔙 بازگشت به منو اصلی', 'callback_data' => 'back_to_main']]
                ]
            ];
            $this->sendMessage($chatId, MESSAGES['help'], $keyboard);
            
        } elseif ($text === '/status') {
            $this->showUserStatus($userId, $chatId);
            
        } elseif ($text === '/creategroup') {
            $code = $this->createGroup($userId);
            $this->sendMessage($chatId, str_replace('{code}', $code, MESSAGES['group_created']));
            
        } elseif (strpos($text, '/join ') === 0) {
            $code = trim(substr($text, 6));
            $result = $this->joinGroup($userId, $code);
            
            if ($result === true) {
                $this->sendMessage($chatId, MESSAGES['joined_group']);
            } elseif ($result === 'creator_cannot_join') {
                $this->sendMessage($chatId, "❌ <b>خطا!</b>\nشما نمی‌توانید به گروه خودتان بپیوندید!");
            } elseif ($result === 'group_full') {
                $this->sendMessage($chatId, "❌ <b>گروه پر است!</b>\nاین گروه قبلاً تکمیل شده است!");
            } else {
                $this->sendMessage($chatId, MESSAGES['invalid_code']);
            }
            
        } elseif (preg_match('/^[A-Z0-9]{6}$/', $text)) {
            // کد 6 رقمی وارد شده - تلاش برای join
            $result = $this->joinGroup($userId, $text);
            
            if ($result === true) {
                $this->sendMessage($chatId, MESSAGES['joined_group']);
            } elseif ($result === 'creator_cannot_join') {
                $this->sendMessage($chatId, "❌ <b>خطا!</b>\nشما نمی‌توانید به گروه خودتان بپیوندید!");
            } elseif ($result === 'group_full') {
                $this->sendMessage($chatId, "❌ <b>گروه پر است!</b>\nاین گروه قبلاً تکمیل شده است!");
            } else {
                $this->sendMessage($chatId, MESSAGES['invalid_code']);
            }
            
        } elseif ($text === '/admin' && $this->db['users'][$userId]['is_admin']) {
            $this->adminPanel->showMainPanel($chatId);
            
        } else {
            // بررسی اینکه آیا کاربر در حال چت با واسطه‌گر است
            $this->chatHandler->handleChatMessage($userId, $text);
        }
    }
    
    // پردازش callback queryها
    private function handleCallbackQuery($callbackQuery) {
        $chatId = $callbackQuery['message']['chat']['id'];
        $data = $callbackQuery['data'];
        $userId = $callbackQuery['from']['id'];
        
        if (strpos($data, 'accept_mediation_') === 0) {
            $groupCode = substr($data, 17);
            $result = $this->acceptMediation($userId, $groupCode);
            
            if ($result === true) {
                $this->answerCallbackQuery($callbackQuery['id'], "✅ واسطه‌گری پذیرفته شد!");
            } elseif ($result === 'already_assigned') {
                $this->answerCallbackQuery($callbackQuery['id'], "❌ این گروه قبلاً واسطه‌گر دارد!");
            }
            
        } elseif (strpos($data, 'finish_mediation_') === 0) {
            $groupCode = substr($data, 17);
            $result = $this->finishMediation($userId, $groupCode);
            
            if ($result) {
                $this->answerCallbackQuery($callbackQuery['id'], "✅ واسطه‌گری به پایان رسید!");
            }
            
        } elseif (strpos($data, 'rate_') === 0) {
            $parts = explode('_', $data);
            $groupCode = $parts[1];
            $rating = intval($parts[2]);
            
            $result = $this->submitRating($userId, $groupCode, $rating);
            
            if ($result) {
                $this->answerCallbackQuery($callbackQuery['id'], "⭐ امتیاز شما ثبت شد!");
            }
            
        } elseif (strpos($data, 'add_mediator_') === 0) {
            $targetUserId = substr($data, 13);
            $result = $this->adminPanel->addMediator($userId, $targetUserId);
            if ($result === true) {
                $this->answerCallbackQuery($callbackQuery['id'], "✅ واسطه‌گر اضافه شد!");
            } else {
                $this->answerCallbackQuery($callbackQuery['id'], "❌ خطا در اضافه کردن واسطه‌گر!");
            }
            
        } elseif (strpos($data, 'chat_with_') === 0) {
            $parts = explode('_', $data);
            $targetUserId = $parts[2];
            $groupCode = $parts[3];
            $this->chatHandler->startChatWith($userId, $targetUserId, $groupCode);
            
        } elseif (strpos($data, 'show_panel_') === 0) {
            $groupCode = substr($data, 11);
            $this->chatHandler->showMediatorPanel($userId, $groupCode);
            
        } elseif (strpos($data, 'end_chat_') === 0) {
            $groupCode = substr($data, 9);
            $this->chatHandler->endChat($userId, $groupCode);
            
        } elseif (strpos($data, 'end_user_chat_') === 0) {
            $groupCode = substr($data, 14);
            $this->chatHandler->endUserChat($userId, $groupCode);
            
        } elseif (strpos($data, 'show_history_') === 0) {
            $groupCode = substr($data, 13);
            $this->chatHandler->showGroupHistory($userId, $groupCode);
            
        } elseif (strpos($data, 'group_info_') === 0) {
            $groupCode = substr($data, 11);
            $this->chatHandler->showGroupInfo($userId, $groupCode);
            
        } elseif ($data === 'show_users_for_mediator') {
            $this->adminPanel->showUsersForMediatorSelection($userId);
            
        } elseif ($data === 'admin_main') {
            $this->adminPanel->showMainPanel($userId);
            
        } elseif ($data === 'admin_users') {
            $this->adminPanel->showUsersPanel($userId);
            
        } elseif ($data === 'admin_mediators') {
            $this->adminPanel->showMediatorsPanel($userId);
            
        } elseif ($data === 'admin_stats') {
            $this->adminPanel->showDetailedStats($userId);
            
        } elseif ($data === 'admin_groups') {
            $this->adminPanel->showGroupsPanel($userId);
            
        } elseif ($data === 'backup_data') {
            $this->adminPanel->backupDatabase($userId);
            
        } elseif ($data === 'create_new_group') {
            $code = $this->createGroup($userId);
            $this->sendMessage($chatId, str_replace('{code}', $code, MESSAGES['group_created']));
            
        } elseif ($data === 'join_group_menu') {
            $this->sendMessage($chatId, "🔗 <b>پیوستن به گروه</b>\n\nلطفاً کد 6 رقمی گروه را ارسال کنید:");
            
        } elseif ($data === 'show_help') {
            $keyboard = [
                'inline_keyboard' => [
                    [['text' => '🔙 بازگشت به منو اصلی', 'callback_data' => 'back_to_main']]
                ]
            ];
            $this->sendMessage($chatId, MESSAGES['help'], $keyboard);
            
        } elseif ($data === 'my_status') {
            $this->showUserStatus($userId, $chatId);
            
        } elseif ($data === 'back_to_main') {
            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '🆕 ایجاد گروه جدید', 'callback_data' => 'create_new_group'],
                        ['text' => '🔗 پیوستن به گروه', 'callback_data' => 'join_group_menu']
                    ],
                    [
                        ['text' => '❓ راهنما', 'callback_data' => 'show_help'],
                        ['text' => '📊 وضعیت من', 'callback_data' => 'my_status']
                    ]
                ]
            ];
            $this->sendMessage($chatId, MESSAGES['start'], $keyboard);
        }
    }
    
    // نمایش وضعیت کاربر
    private function showUserStatus($userId, $chatId) {
        $user = $this->db['users'][$userId];
        $userGroups = [];
        
        // پیدا کردن گروه‌های کاربر
        foreach ($this->db['groups'] as $code => $group) {
            if ($group['creator_id'] == $userId || $group['participant_id'] == $userId) {
                $userGroups[] = [
                    'code' => $code,
                    'status' => $group['status'],
                    'role' => ($group['creator_id'] == $userId) ? 'سازنده' : 'شرکت‌کننده'
                ];
            }
        }
        
        $statusText = "📊 <b>وضعیت کاربری شما</b>\n\n";
        $statusText .= "👤 نام: {$user['first_name']}\n";
        $statusText .= "📅 عضویت از: " . date('Y/m/d', strtotime($user['created_at'])) . "\n";
        
        if ($user['is_mediator']) {
            $statusText .= "👨‍💼 <b>شما واسطه‌گر هستید</b>\n";
            $ratings = $user['ratings_received'] ?? [];
            if (!empty($ratings)) {
                $avgRating = array_sum(array_column($ratings, 'rating')) / count($ratings);
                $statusText .= "⭐ امتیاز: " . number_format($avgRating, 1) . "/5 (" . count($ratings) . " نظر)\n";
            }
        }
        
        $statusText .= "\n📁 <b>گروه‌های شما:</b>\n";
        
        if (empty($userGroups)) {
            $statusText .= "هنوز در هیچ گروهی عضو نیستید\n";
        } else {
            foreach ($userGroups as $group) {
                $statusEmoji = $this->getStatusEmoji($group['status']);
                $statusText .= "• $statusEmoji {$group['code']} - {$group['role']} - " . $this->getStatusText($group['status']) . "\n";
            }
        }
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '🔙 بازگشت به منو اصلی', 'callback_data' => 'back_to_main']]
            ]
        ];
        
        $this->sendMessage($chatId, $statusText, $keyboard);
    }
    
    // دریافت ایموجی وضعیت
    private function getStatusEmoji($status) {
        switch ($status) {
            case 'waiting_for_participant':
                return '⏳';
            case 'waiting_for_mediator':
                return '🔍';
            case 'active':
                return '✅';
            case 'finished':
                return '🏁';
            default:
                return '❓';
        }
    }
    
    // دریافت متن وضعیت
    private function getStatusText($status) {
        switch ($status) {
            case 'waiting_for_participant':
                return 'منتظر شرکت‌کننده';
            case 'waiting_for_mediator':
                return 'منتظر واسطه‌گر';
            case 'active':
                return 'فعال';
            case 'finished':
                return 'تمام شده';
            default:
                return 'نامشخص';
        }
    }
    
    // پاسخ به callback query
    private function answerCallbackQuery($callbackQueryId, $text) {
        $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/answerCallbackQuery";
        $data = [
            'callback_query_id' => $callbackQueryId,
            'text' => $text
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    }
    

}

// دریافت webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $update = json_decode($input, true);
    
    if ($update) {
        $bot = new MediatorBot();
        $bot->processUpdate($update);
    }
} else {
    echo "Mediator Bot is running!";
}
?>
