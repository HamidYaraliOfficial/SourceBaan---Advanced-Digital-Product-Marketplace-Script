<?php
/*
 * IN The Name OF God
 * 
 * Developer : @Camaeal
 * Channel   : @GrokCreator
 * Botsaz    : @GrokCreatorBot
 */

$botToken = '';//توکن

$channelUsername = '';//یوزرنیم چنل با @ برای جوین اجباری

$api = 'https://api.telegram.org/bot' . $botToken . '/';



?>