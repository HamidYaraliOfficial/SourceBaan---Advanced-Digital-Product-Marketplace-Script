<?php

/*

 * IN The Name OF God

 * 

 * Developer : @Camaeal

 * Channel   : @GrokCreator

 * Botsaz    : @GrokCreatorBot

 */



$telegram_ip_ranges = [

    ['lower' => '149.154.160.0', 'upper' => '149.154.175.255'],

    ['lower' => '91.108.4.0',    'upper' => '91.108.7.255'],

];



if (!filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {

    http_response_code(403);

    exit("کیر شدی مادر قحبه");

}



$ip_dec = (float) sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));

$ok = false;



foreach ($telegram_ip_ranges as $range) {

    $lower_dec = (float) sprintf("%u", ip2long($range['lower']));

    $upper_dec = (float) sprintf("%u", ip2long($range['upper']));

    if ($ip_dec >= $lower_dec && $ip_dec <= $upper_dec) {

        $ok = true;

        break;

    }

}



if (!$ok) {

    http_response_code(403);

    exit("کیر شدی مادر قحبه");

}
//---------------------------//

require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Tehran');

if (!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0777, true);

$update = json_decode(file_get_contents('php://input'), true);

function api($m, $p = [])

{

    global $api;

    $ch = curl_init();

    curl_setopt_array($ch, [

        CURLOPT_URL => $api . $m,

        CURLOPT_RETURNTRANSFER => true,

        CURLOPT_POST => true,

        CURLOPT_POSTFIELDS => $p

    ]);

    $r = curl_exec($ch);

    curl_close($ch);

    return json_decode($r, true);

}

function sendMessage($chat_id, $text, $reply_to = null, $kb = null)

{

    $p = ['chat_id' => $chat_id, 'text' => $text, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true];

    if ($reply_to) $p['reply_to_message_id'] = $reply_to;

    if ($kb) $p['reply_markup'] = json_encode($kb);

    return api('sendMessage', $p);

}

function editMessageText($chat_id, $message_id, $text, $kb = null)

{

    $p = ['chat_id' => $chat_id, 'message_id' => $message_id, 'text' => $text, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true];

    if ($kb) $p['reply_markup'] = json_encode($kb);

    return api('editMessageText', $p);

}

function answerCb($id, $text = '', $alert = false)

{

    return api('answerCallbackQuery', ['callback_query_id' => $id, 'text' => $text, 'show_alert' => $alert]);

}

function deleteMessage($chat_id, $message_id)

{

    return api('deleteMessage', ['chat_id' => $chat_id, 'message_id' => $message_id]);

}

function restrict($chat_id, $user_id, $until)

{

    $perms = ['can_send_messages' => false, 'can_send_media_messages' => false, 'can_send_polls' => false, 'can_send_other_messages' => false, 'can_add_web_page_previews' => false, 'can_change_info' => false, 'can_invite_users' => false, 'can_pin_messages' => false];

    return api('restrictChatMember', ['chat_id' => $chat_id, 'user_id' => $user_id, 'permissions' => json_encode($perms), 'until_date' => $until]);

}

function ban($chat_id, $user_id)

{

    return api('banChatMember', ['chat_id' => $chat_id, 'user_id' => $user_id]);

}

function unban($chat_id, $user_id)

{

    return api('unbanChatMember', ['chat_id' => $chat_id, 'user_id' => $user_id, 'only_if_banned' => true]);

}

function getMember($chat_id, $user_id)

{

    return api('getChatMember', ['chat_id' => $chat_id, 'user_id' => $user_id]);

}

function isBotAdmin($chat_id)

{

    $me = api('getMe', []);

    $id = $me['result']['id'] ?? 0;

    $m = getMember($chat_id, $id);

    $st = $m['result']['status'] ?? '';

    return in_array($st, ['administrator', 'creator']);

}

function groupFile($chat_id)

{

    return __DIR__ . '/data/group_' . $chat_id . '.json';

}

function loadGroup($chat_id)

{

    $f = groupFile($chat_id);

    if (!file_exists($f)) {

        $d = [

            'chat_id' => $chat_id,

            'owner' => 0,

            'admins' => [],

            'vips' => [],

            'bans' => [],

            'locks' => [

                'link' => false,

                'hyperlink' => false,

                'hashtag' => false,

                'username' => false,

                'fa' => false,

                'en' => false,

                'service' => false,

                'emoji' => false,

                'profanity' => false,

                'inline' => false,

                'forward' => false,

                'photo' => false,

                'gif' => false,

                'sticker' => false,

                'voice' => false,

                'lock_all' => false

            ],

            'warn_threshold' => 3,

            'flood_limit' => 10,

            'flood_window' => 7,

            'required_channel' => '@GrokCreator',

            'warnings' => [],

            'flood' => [],

            'join_prompts' => []

        ];

        saveGroup($chat_id, $d);

        return $d;

    }

    $h = fopen($f, 'r');

    flock($h, LOCK_SH);

    $c = stream_get_contents($h);

    flock($h, LOCK_UN);

    fclose($h);

    $d = json_decode($c, true);

    return $d ?: [];

}

function saveGroup($chat_id, $data)

{

    $f = groupFile($chat_id);

    $h = fopen($f, 'c+');

    flock($h, LOCK_EX);

    ftruncate($h, 0);

    fwrite($h, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    fflush($h);

    flock($h, LOCK_UN);

    fclose($h);

}

function isPrivileged($chat_id, $user_id, $g)

{

    if ($user_id == ($g['owner'] ?? 0)) return true;

    if (in_array($user_id, $g['admins'] ?? [])) return true;

    if (in_array($user_id, $g['vips'] ?? [])) return true;

    $m = getMember($chat_id, $user_id);

    $st = $m['result']['status'] ?? '';

    if (in_array($st, ['administrator', 'creator'])) return true;

    return false;

}

function isOwner($g, $user_id)

{

    return $user_id == ($g['owner'] ?? 0);

}

function isAdminRole($chat_id, $g, $user_id)

{

    if (isOwner($g, $user_id)) return true;

    if (in_array($user_id, $g['admins'] ?? [])) return true;

    $m = getMember($chat_id, $user_id);

    $st = $m['result']['status'] ?? '';

    if (in_array($st, ['administrator', 'creator'])) return true;

    return false;

}

function userJoinedChannel($user_id)

{

    global $channelUsername;

    $m = getMember($channelUsername, $user_id);

    $st = $m['result']['status'] ?? 'left';

    return in_array($st, ['member', 'administrator', 'creator']);

}

function toName($u)

{

    $f = $u['first_name'] ?? '';

    $l = $u['last_name'] ?? '';

    $n = trim($f . ' ' . $l);

    if ($n === '') $n = $u['username'] ?? ('کاربر ' . ($u['id'] ?? ''));

    return htmlspecialchars($n);

}

function containsEmoji($text)

{

    return preg_match('/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $text) === 1;

}

function containsFa($text)

{

    return preg_match('/[\x{0600}-\x{06FF}]/u', $text) === 1;

}

function containsEn($text)

{

    return preg_match('/[A-Za-z]/u', $text) === 1;

}

function containsUsername($text)

{

    return preg_match('/(^|[^A-Za-z0-9_])@[A-Za-z0-9_]{3,}/u', $text) === 1;

}

function containsLink($text)

{

    return preg_match('/https?:\/\/|www\.[^\s]+/i', $text) === 1;

}

function containsProfanity($text)

{

    $w = ['بددهن','زشت','بی‌ادب','بی ادب','لعنت','trash','ugly','stupid','idiot','shit','fuck'];

    $t = mb_strtolower($text, 'UTF-8');

    foreach ($w as $x) {

        if (mb_strpos($t, $x, 0, 'UTF-8') !== false) return true;

    }

    return false;

}

function hasEntity($msg, $types)

{

    $ens = $msg['entities'] ?? [];

    $cens = $msg['caption_entities'] ?? [];

    $all = array_merge($ens, $cens);

    foreach ($all as $e) {

        if (in_array($e['type'], $types)) return true;

    }

    return false;

}

function messageTypeFlags($msg)

{

    return [

        'service_join' => isset($msg['new_chat_members']),

        'service_left' => isset($msg['left_chat_member']),

        'service_pinned' => isset($msg['pinned_message']),

        'forward' => isset($msg['forward_date']),

        'photo' => isset($msg['photo']),

        'animation' => isset($msg['animation']),

        'sticker' => isset($msg['sticker']),

        'voice' => isset($msg['voice']),

        'via_bot' => isset($msg['via_bot']),

        'text' => isset($msg['text']),

        'caption' => isset($msg['caption'])

    ];

}

function getTextAll($msg)

{

    $t = '';

    if (isset($msg['text'])) $t .= $msg['text'] . ' ';

    if (isset($msg['caption'])) $t .= $msg['caption'];

    return trim($t);

}

function shouldDelete($g, $msg, $priv)

{

    $locks = $g['locks'] ?? [];

    $f = messageTypeFlags($msg);

    $txt = getTextAll($msg);

    if ($priv) return false;

    if (!empty($locks['lock_all'])) return true;

    if (!empty($locks['service']) && ($f['service_join'] || $f['service_left'] || $f['service_pinned'])) return true;

    if (!empty($locks['forward']) && $f['forward']) return true;

    if (!empty($locks['photo']) && $f['photo']) return true;

    if (!empty($locks['gif']) && $f['animation']) return true;

    if (!empty($locks['sticker']) && $f['sticker']) return true;

    if (!empty($locks['voice']) && $f['voice']) return true;

    if (!empty($locks['inline']) && $f['via_bot']) return true;

    if ($txt !== '') {

        if (!empty($locks['hyperlink']) && hasEntity($msg, ['text_link'])) return true;

        if (!empty($locks['hashtag']) && hasEntity($msg, ['hashtag'])) return true;

        if (!empty($locks['link']) && (hasEntity($msg, ['url', 'text_link']) || containsLink($txt))) return true;

        if (!empty($locks['username']) && (hasEntity($msg, ['mention']) || containsUsername($txt))) return true;

        if (!empty($locks['fa']) && containsFa($txt)) return true;

        if (!empty($locks['en']) && containsEn($txt)) return true;

        if (!empty($locks['emoji']) && containsEmoji($txt)) return true;

        if (!empty($locks['profanity']) && containsProfanity($txt)) return true;

    }

    return false;

}

function panelKeyboard()

{

    return ['inline_keyboard' => [

        [['text' => '🔒 قفل‌ها', 'callback_data' => 'panel:locks'], ['text' => '📜 لیست‌ها', 'callback_data' => 'panel:lists']],

        [['text' => '⚙️ تنظیمات پیشرفته', 'callback_data' => 'panel:adv']],

        [['text' => '📘 راهنما', 'callback_data' => 'panel:help']]

    ]];

}

function locksKeyboard($g)

{

    $L = $g['locks'];

    $btn = function ($k, $t) use ($L) {

        $s = !empty($L[$k]) ? '✅' : '❌';

        return ['text' => $t . ' ' . $s, 'callback_data' => 'toggle:' . $k];

    };

    return ['inline_keyboard' => [

        [$btn('link', '🔗 لینک'), $btn('hyperlink', '🧷 هایپرلینک'), $btn('hashtag', '# هشتگ')],

        [$btn('username', '👤 یوزرنیم'), $btn('fa', '📝 فارسی'), $btn('en', '🔤 انگلیسی')],

        [$btn('service', '🛎 سرویس تلگرام'), $btn('emoji', '😊 ایموجی'), $btn('profanity', '🚫 فحش')],

        [$btn('inline', '🤖 اینلاین'), $btn('forward', '📨 فوروارد')],

        [$btn('photo', '🖼 عکس'), $btn('gif', '🎞 گیف'), $btn('sticker', '🔖 استیکر'), $btn('voice', '🎙 ویس')],

        [$btn('lock_all', '🧱 قفل گروه')],

        [['text' => '⬅️ بازگشت', 'callback_data' => 'panel:root']]

    ]];

}

function listsKeyboard()

{

    return ['inline_keyboard' => [

        [['text' => '➕ افزودن ادمین', 'callback_data' => 'lists:info:add_admin']],

        [['text' => '➖ حذف ادمین', 'callback_data' => 'lists:info:del_admin']],

        [['text' => '⭐ افزودن کاربر ویژه', 'callback_data' => 'lists:info:add_vip']],

        [['text' => '🗑 حذف ویژه', 'callback_data' => 'lists:info:del_vip']],

        [['text' => '📋 لیست کلی', 'callback_data' => 'lists:show']],

        [['text' => '⬅️ بازگشت', 'callback_data' => 'panel:root']]

    ]];

}

function advKeyboard($g)

{

    return ['inline_keyboard' => [

        [['text' => '🚩 تنظیم اخطار: ' . ($g['warn_threshold'] ?? 3), 'callback_data' => 'none']],

        [['text' => '➕ افزودن', 'callback_data' => 'adv:warn:add'], ['text' => '➖ کم کردن', 'callback_data' => 'adv:warn:sub']],

        [['text' => '🛡 قفل پیام رگباری: ' . ($g['flood_limit'] ?? 10) . ' پیام/۷ث', 'callback_data' => 'none']],

        [['text' => '➕ افزودن', 'callback_data' => 'adv:flood:add'], ['text' => '➖ کم کردن', 'callback_data' => 'adv:flood:sub']],

        [['text' => '⬅️ بازگشت', 'callback_data' => 'panel:root']]

    ]];

}

function joinKeyboard()

{

    global $channelUsername;

    return ['inline_keyboard' => [

        [['text' => '📣 عضویت در کانال', 'url' => 'https://t.me/' . ltrim($channelUsername, '@')]],

        [['text' => '✅ عضو شدم', 'callback_data' => 'verify:joined']]

    ]];

}

if (isset($update['message'])) {

    $msg = $update['message'];

    $chat_id = $msg['chat']['id'];

    $type = $msg['chat']['type'] ?? '';

    if ($type === 'group' || $type === 'supergroup') {

        $from = $msg['from'] ?? [];

        $user_id = $from['id'] ?? 0;

        $name = toName($from);

        $g = loadGroup($chat_id);

        if (!isset($g['chat_id'])) $g['chat_id'] = $chat_id;

        $need_join = !userJoinedChannel($user_id);

        if ($need_join) {

            $last = $g['join_prompts'][$user_id] ?? 0;

            if (time() - $last > 30) {

                $g['join_prompts'][$user_id] = time();

                saveGroup($chat_id, $g);

                deleteMessage($chat_id, $msg['message_id']);

                $t = "سلام <b>$name</b> 🌟\n\n<b>کاربر گرامی</b>، برای حمایت از ما ابتدا عضو چنل زیر شوید و سپس روی دکمه <b>عضو شدم</b> بزنید.";

                sendMessage($chat_id, $t, null, joinKeyboard());

            } else {

                deleteMessage($chat_id, $msg['message_id']);

            }

            exit;

        }

        $text = $msg['text'] ?? '';

        $priv = isPrivileged($chat_id, $user_id, $g);

        if (shouldDelete($g, $msg, $priv)) {

            deleteMessage($chat_id, $msg['message_id']);

            exit;

        }

        $now = time();

        if (!$priv) {

            $fw = $g['flood_window'] ?? 7;

            $fl = $g['flood_limit'] ?? 10;

            if (!isset($g['flood']["$user_id"])) $g['flood']["$user_id"] = [];

            $arr = $g['flood']["$user_id"];

            $arr[] = $now;

            $arr = array_values(array_filter($arr, function ($t) use ($now, $fw) {

                return ($now - $t) <= $fw;

            }));

            $g['flood']["$user_id"] = $arr;

            saveGroup($chat_id, $g);

            if (count($arr) > $fl) {

                $g = loadGroup($chat_id);

                $w = $g['warnings']["$user_id"] ?? 0;

                $w++;

                $g['warnings']["$user_id"] = $w;

                saveGroup($chat_id, $g);

                deleteMessage($chat_id, $msg['message_id']);

                restrict($chat_id, $user_id, time() + 300);

                $cap = "⛔️ <b>پیام‌های پیاپی</b>\nبرای <b>$name</b> یک اخطار ثبت شد. کاربر به مدت <b>۵ دقیقه</b> در حالت سکوت قرار گرفت. تعداد اخطار: <b>$w</b>";

                sendMessage($chat_id, $cap);

                if ($w >= ($g['warn_threshold'] ?? 3)) {

                    ban($chat_id, $user_id);

                    sendMessage($chat_id, "🚫 <b>$name</b> به سقف اخطار رسید و از گروه بن شد.");

                }

                exit;

            }

        }

        if (mb_strtolower(trim($text), 'UTF-8') === 'نصب') {

            if (!isBotAdmin($chat_id)) {

                sendMessage($chat_id, "⚠️ برای نصب، ابتدا ربات را با دسترسی حذف پیام و محدودسازی به عنوان ادمین گروه اضافه کنید.");

                exit;

            }

            if (empty($g['owner'])) {

                $g['owner'] = $user_id;

                saveGroup($chat_id, $g);

                sendMessage($chat_id, "✅ نصب با موفقیت انجام شد.\nمالک ربات: <b>$name</b>");

            } else {

                sendMessage($chat_id, "ℹ️ این گروه قبلاً نصب شده است.\nمالک: <b>" . $g['owner'] . "</b>");

            }

            exit;

        }

        if (mb_strtolower(trim($text), 'UTF-8') === 'راهنما') {

            if (!isAdminRole($chat_id, $g, $user_id)) {

                sendMessage($chat_id, "⛔️ شما دسترسی لازم برای باز کردن پنل مدیریت را ندارید.");

                exit;

            }

            $t = "به پنل مدیریت خوش آمدید • لطفا بخش مورد نظر را انتخاب کنید:";

            sendMessage($chat_id, "👋 $t", null, panelKeyboard());

            exit;

        }

        if (!empty($msg['reply_to_message'])) {

            $rt = $msg['reply_to_message'];

            $tg = $rt['from']['id'] ?? 0;

            $tname = toName($rt['from'] ?? []);

            if (isAdminRole($chat_id, $g, $user_id)) {

                $key = mb_strtolower(trim($text), 'UTF-8');

                if ($key === 'افزودن ادمین') {

                    if (!in_array($tg, $g['admins'])) {

                        $g['admins'][] = $tg;

                        saveGroup($chat_id, $g);

                    }

                    sendMessage($chat_id, "👤 کاربر <b>$tname</b> به عنوان ادمین ثبت شد.");

                    exit;

                }

                if ($key === 'حذف ادمین') {

                    $g['admins'] = array_values(array_filter($g['admins'], fn($x) => $x != $tg));

                    saveGroup($chat_id, $g);

                    sendMessage($chat_id, "🗑 ادمین <b>$tname</b> حذف شد.");

                    exit;

                }

                if ($key === 'افزودن ویژه') {

                    if (!in_array($tg, $g['vips'])) {

                        $g['vips'][] = $tg;

                        saveGroup($chat_id, $g);

                    }

                    sendMessage($chat_id, "⭐ کاربر <b>$tname</b> به لیست ویژه اضافه شد.");

                    exit;

                }

                if ($key === 'حذف ویژه') {

                    $g['vips'] = array_values(array_filter($g['vips'], fn($x) => $x != $tg));

                    saveGroup($chat_id, $g);

                    sendMessage($chat_id, "🗑 کاربر <b>$tname</b> از لیست ویژه حذف شد.");

                    exit;

                }

                if ($key === 'بن') {

                    ban($chat_id, $tg);

                    sendMessage($chat_id, "🚫 کاربر <b>$tname</b> بن شد.");

                    exit;

                }

                if ($key === 'حذف بن') {

                    unban($chat_id, $tg);

                    sendMessage($chat_id, "✅ بن <b>$tname</b> برداشته شد.");

                    exit;

                }

                if ($key === 'افزودن اخطار') {

                    $w = $g['warnings']["$tg"] ?? 0;

                    $w++;

                    $g['warnings']["$tg"] = $w;

                    saveGroup($chat_id, $g);

                    sendMessage($chat_id, "🚩 به کاربر <b>$tname</b> یک اخطار اضافه شد. تعداد اخطار: <b>$w</b>");

                    if ($w >= ($g['warn_threshold'] ?? 3)) {

                        ban($chat_id, $tg);

                        sendMessage($chat_id, "🚫 کاربر <b>$tname</b> به سقف اخطار رسید و بن شد.");

                    }

                    exit;

                }

                if ($key === 'حذف اخطار') {

                    $w = $g['warnings']["$tg"] ?? 0;

                    if ($w > 0) $w--;

                    $g['warnings']["$tg"] = $w;

                    saveGroup($chat_id, $g);

                    sendMessage($chat_id, "♻️ یک اخطار از <b>$tname</b> کم شد. تعداد اخطار: <b>$w</b>");

                    exit;

                }

            }

        }

    }

}

if (isset($update['callback_query'])) {

    $cb = $update['callback_query'];

    $data = $cb['data'] ?? '';

    $from = $cb['from'] ?? [];

    $user_id = $from['id'] ?? 0;

    $name = toName($from);

    $msg = $cb['message'] ?? [];

    $chat_id = $msg['chat']['id'] ?? 0;

    $mid = $msg['message_id'] ?? 0;

    $g = loadGroup($chat_id);

    if (strpos($data, 'verify:') === 0) {

        if ($data === 'verify:joined') {

            if (userJoinedChannel($user_id)) {

                deleteMessage($chat_id, $mid);

                answerCb($cb['id'], 'عضویت تایید شد ✅');

                sendMessage($chat_id, "🎉 <b>$name</b> عضویت شما تایید شد، اکنون می‌توانید چت کنید.");

            } else {

                answerCb($cb['id'], 'لطفاً ابتدا عضو کانال شوید.', true);

            }

        }

        exit;

    }

    if (!isAdminRole($chat_id, $g, $user_id)) {

        answerCb($cb['id'], 'دسترسی ندارید ❌', true);

        exit;

    }

    if ($data === 'panel:root') {

        editMessageText($chat_id, $mid, "👋 به پنل مدیریت خوش آمدید • لطفا بخش مورد نظر را انتخاب کنید:", panelKeyboard());

        exit;

    }

    if ($data === 'panel:locks') {

        editMessageText($chat_id, $mid, "🔒 تنظیم قفل‌های گروه:", locksKeyboard($g));

        exit;

    }

    if (strpos($data, 'toggle:') === 0) {

        $k = explode(':', $data)[1] ?? '';

        if ($k !== '') {

            $g['locks'][$k] = !empty($g['locks'][$k]) ? false : true;

            saveGroup($chat_id, $g);

            editMessageText($chat_id, $mid, "🔒 تنظیم قفل‌های گروه:", locksKeyboard($g));

            answerCb($cb['id'], 'بروزرسانی شد ✅');

        }

        exit;

    }

    if ($data === 'panel:lists') {

        $txt = "📜 مدیریت لیست‌ها\n\nبرای افزودن/حذف با ریپلای روی پیام کاربر یکی از گزینه‌های زیر را ارسال کنید:\n• افزودن ادمین • حذف ادمین\n• افزودن ویژه • حذف ویژه\n• بن • حذف بن";

        editMessageText($chat_id, $mid, $txt, listsKeyboard());

        exit;

    }

    if ($data === 'lists:show') {

        $admins = $g['admins'] ?? [];

        $vips = $g['vips'] ?? [];

        $at = count($admins);

        $vt = count($vips);

        $tx = "📋 لیست کلی\n\n👑 مالک: <code>" . ($g['owner'] ?: 'ثبت نشده') . "</code>\n👤 تعداد ادمین‌ها: <b>$at</b>\n⭐ تعداد ویژه‌ها: <b>$vt</b>";

        editMessageText($chat_id, $mid, $tx, listsKeyboard());

        exit;

    }

    if (strpos($data, 'lists:info:') === 0) {

        $what = explode(':', $data)[2] ?? '';

        $map = [

            'add_admin' => "با ریپلای روی کاربر «افزودن ادمین» را ارسال کنید.",

            'del_admin' => "با ریپلای روی کاربر «حذف ادمین» را ارسال کنید.",

            'add_vip' => "با ریپلای روی کاربر «افزودن ویژه» را ارسال کنید.",

            'del_vip' => "با ریپلای روی کاربر «حذف ویژه» را ارسال کنید."

        ];

        $tx = "ℹ️ " . ($map[$what] ?? '');

        answerCb($cb['id'], 'راهنما نمایش داده شد');

        editMessageText($chat_id, $mid, "📜 " . $tx, listsKeyboard());

        exit;

    }

    if ($data === 'panel:adv') {

        editMessageText($chat_id, $mid, "⚙️ تنظیمات پیشرفته:", advKeyboard($g));

        exit;

    }

    if (strpos($data, 'adv:warn:') === 0) {

        $op = explode(':', $data)[2] ?? '';

        $v = $g['warn_threshold'] ?? 3;

        if ($op === 'add') $v++;

        if ($op === 'sub' && $v > 1) $v--;

        $g['warn_threshold'] = $v;

        saveGroup($chat_id, $g);

        editMessageText($chat_id, $mid, "⚙️ تنظیمات پیشرفته:", advKeyboard($g));

        answerCb($cb['id'], 'سقف اخطار بروزرسانی شد ✅');

        exit;

    }

    if (strpos($data, 'adv:flood:') === 0) {

        $op = explode(':', $data)[2] ?? '';

        $v = $g['flood_limit'] ?? 10;

        if ($op === 'add') $v++;

        if ($op === 'sub' && $v > 1) $v--;

        $g['flood_limit'] = $v;

        saveGroup($chat_id, $g);

        editMessageText($chat_id, $mid, "⚙️ تنظیمات پیشرفته:", advKeyboard($g));

        answerCb($cb['id'], 'حد مجاز پیام پیاپی بروزرسانی شد ✅');

        exit;

    }

    if ($data === 'panel:help') {

    $help = "📘 راهنمای کامل ربات مدیریت گروه\n\n1) نصب ربات:\n• ربات را ادمین گروه کنید و عبارت «نصب» را ارسال کنید تا مالک ثبت شود.\n\n2) پنل مدیریت:\n• با ارسال «راهنما» پنل باز می‌شود. دکمه‌ها:\n– 🔒 قفل‌ها: مدیریت قفل‌های لینک، هایپرلینک، هشتگ، یوزرنیم، فارسی، انگلیسی، سرویس تلگرام، ایموجی، فحش، اینلاین، فوروارد، عکس، گیف، استیکر، ویس و قفل گروه.\n– 📜 لیست‌ها: افزودن/حذف ادمین و کاربر ویژه، نمایش لیست کلی.\n– ⚙️ تنظیمات پیشرفته: تنظیم سقف اخطار و قفل پیام رگباری.\n– 📘 راهنما: همین بخش.\n\n3) قفل‌ها:\n• هنگام فعال بودن هر قفل، پیام کاربران عادی (غیرمالک/ادمین/ویژه) که حاوی مورد قفل‌شده باشد حذف می‌شود.\n• قفل گروه فعال باشد، هر پیام کاربر عادی حذف می‌شود تا قفل غیرفعال شود.\n\n4) لیست‌ها:\n• با ریپلای روی پیام کاربر یکی از این دستورات را بفرستید: «افزودن ادمین»، «حذف ادمین»، «افزودن ویژه»، «حذف ویژه»، «بن»، «حذف بن».\n\n5) اخطارها:\n• با ریپلای «افزودن اخطار» برای کاربر اخطار ثبت می‌شود؛ «حذف اخطار» اخطار را کم می‌کند.\n• اگر اخطار کاربر به سقف برسد، کاربر بن می‌شود. سقف از مسیر تنظیمات پیشرفته قابل تغییر است.\n\n6) قفل پیام رگباری:\n• اگر کاربر در بازه ۷ ثانیه بیش از حد مجاز پیام ارسال کند، یک اخطار ثبت و کاربر ۵ دقیقه در حالت سکوت قرار می‌گیرد. حد مجاز از تنظیمات پیشرفته قابل تغییر است.\n\n7) استثناها:\n• مالک، ادمین‌ها و کاربران ویژه از قفل‌ها و محدودیت‌ها مستثنی هستند.\n\n8) نکات:\n• برای عملکرد کامل، ربات باید دسترسی حذف پیام، محدودسازی کاربر و مدیریت پیام‌ها را داشته باشد.";

        editMessageText($chat_id, $mid, $help, ['inline_keyboard' => [[['text' => '⬅️ بازگشت', 'callback_data' => 'panel:root']]]]);

        exit;

    }

}



?>