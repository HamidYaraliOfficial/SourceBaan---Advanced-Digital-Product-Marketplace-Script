
CREATE TABLE `amarbot` (
  `bot` varchar(200) NOT NULL,
  `token` varchar(200) NOT NULL,
  `creatorid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


CREATE TABLE `block` (
  `id` bigint(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE `buy` (
  `key` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `time` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `channel` (
  `channel` bigint(20) NOT NULL,
  `id` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `speed` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE `daily` (
  `time` varchar(50) DEFAULT '',
  `user` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


INSERT INTO `daily` (`time`, `user`) VALUES
('', 0);


CREATE TABLE `orderlike` (
  `key` varchar(155) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `speed` varchar(155) NOT NULL,
  `like` int(11) NOT NULL,
  `link` text NOT NULL,
  `time` varchar(90) NOT NULL,
  `stats` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE `orderseen` (
  `key` varchar(155) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `speed` varchar(90) NOT NULL,
  `view` int(11) NOT NULL,
  `link` text NOT NULL,
  `time` varchar(155) NOT NULL,
  `stats` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `orderseenIran` (
  `key` varchar(155) NOT NULL,
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `speed` varchar(90) NOT NULL,
  `view` bigint(20) NOT NULL,
  `link` text NOT NULL,
  `time` varchar(155) NOT NULL,
  `stats` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE `pay` (
  `code` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `step` varchar(50) NOT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `coin` bigint(20) DEFAULT NULL,
  `paycode` varchar(500) DEFAULT NULL,
  `authority` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `pol` (
  `id` int(11) NOT NULL,
  `totalpol` int(255) NOT NULL,
  `yesterday` int(255) NOT NULL,
  `today` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



CREATE TABLE `SeenPanel` (
  `idsite` int(11) NOT NULL,
  `idseen` text NOT NULL,
  `count` int(11) NOT NULL,
  `channel_name` text NOT NULL,
  `post_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



CREATE TABLE `sendall` (
  `step` varchar(20) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `chat` varchar(100) DEFAULT NULL,
  `user` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `sendall` (`step`, `text`, `chat`, `user`) VALUES
('none', '', '', 0);



CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `step` varchar(50) DEFAULT NULL,
  `member` bigint(20) DEFAULT 0,
  `coin` int(11) NOT NULL,
  `data` text DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `com` varchar(11) DEFAULT NULL,
  `apikey` text NOT NULL,
  `pol` int(11) DEFAULT 0,
  `bot` varchar(200) NOT NULL DEFAULT '0',
  `token` varchar(200) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


ALTER TABLE `amarbot`
  ADD PRIMARY KEY (`bot`);


ALTER TABLE `buy`
  ADD PRIMARY KEY (`key`);


ALTER TABLE `channel`
  ADD PRIMARY KEY (`channel`);


ALTER TABLE `orderlike`
  ADD PRIMARY KEY (`key`);


ALTER TABLE `orderseen`
  ADD PRIMARY KEY (`key`);


ALTER TABLE `orderseenIran`
  ADD PRIMARY KEY (`key`);


ALTER TABLE `pay`
  ADD PRIMARY KEY (`code`);


ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `buy`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;
