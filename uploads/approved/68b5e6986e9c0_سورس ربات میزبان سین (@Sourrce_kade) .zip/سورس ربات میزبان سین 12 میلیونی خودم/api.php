<?php
include('config.php');
include('lib/jdf.php');
header('Content-Type: application/json');
//========================
function bot($method,$datas=[]){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    return json_decode(curl_exec($ch));
    }
function bot1($method,$datas=[]){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY1.'/'.$method );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    return json_decode(curl_exec($ch));
}
function bot2($method,$datas=[]){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY2.'/'.$method );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    return json_decode(curl_exec($ch));
}
function curl($url){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    return json_decode(curl_exec($ch));
    } 
    function RandomString($length = 8){
 $am = array_merge(range('A','Z'), range('a','z'), range(0, 9));
 for(; @$c < $length; @++$c)
  @$o .= $am[array_rand($am)];
 return $o;
}
function GetViews($channel, $post){
      $embed = file_get_contents("https://t.me/$channel/$post?embed=true");
      preg_match_all('/<span class="tgme_widget_message_views">(.*?)<\/span>/si',$embed,$match);
      $views = $match[1][0];
      return $views;
}
$apikey = $_GET['apikey'];
$usern = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `apikey` = '$apikey' LIMIT 1"));
$user = $usern['id'];
//======================== Get ==================
$coins = json_decode(file_get_contents("amount.json"),true);
$_seen = $coins['seen'];
$_like = $coins['like'];
$api = json_decode(file_get_contents("erfansantricha.json"),true);
$seenapi = "https://mesterseen.ir/seen/web.php";
$seenpass = "";
$likeapi = "https://mesterseen.ir/seen/web.php";
$likepass = "";
//================== 

$coinj = $_GET['coin'];
$type = $_GET['type'];
$count = $_GET['count'];
$speed = $_GET['speed'];
$period = $_GET['period'];
$channel = $_GET['channel'];
$row = $_GET['row'];
$id = $_GET['id'];
$column = $_GET['column']; 
$_act = 15;
$emoji =$_GET['emoji']; 
$maxorder = "120000";
//============= variable =======
$from_id1 = json_decode(file_get_contents("wtysg/$apikey.json"),true);
$from_id = $usern["id"];
$user_data = json_decode(file_get_contents("wtysg/$from_id.json"),true);
$user_coin = $usern['coin'];
$user_apikey = $usern["apikey"];
$user1 = $usern["id"];
//============ json text =========
$cointext = array("result"=>"ok","amount"=>"$user_coin");
$false_seen = array("result"=>"false","comment"=>"Order Eror");
$false_like = array("result"=>"false","comment"=>"Order Eror");
$true_info = array("result"=>"true","id"=>a,"coin"=>$user_coin);
$false_enough_coin = array("result"=>"false","comment"=>"You have'nt enough coin.");
$apikey_not_fo = array("result"=>"no","comment"=>"apikey not found");
$false_invalid_password = array("result"=>"no","comment"=>"apikey not found");
$stats = array("result"=>"ok","user"=>"$user1","amount"=>"$user_coin","like"=>"$_like","seen"=>"$_seen","maxorder"=>"$maxorder");
$stat = array("result"=>"ok","stats"=>true,"key"=>"$id","coin"=>"$user_coin");
//==================== coin ========
if($type == 'amount'){
echo json_encode($cointext);
}

//////////
elseif($type == 'cancel-v'){
if($apikey = $user_apikey){
$result = curl("$seenapi?apikey=$seenpass&type=cancel-v&id=$id");
$result1 = json_decode($result,true);
$resul1t = $result1["result"];
$order_id = "{$result->order}";
$count = "{$result->count}";
$amount = "{$result->amount}";
$time = date("H:i:s Y/m/d");
$stats = "{$result->stats}";
if($result->result == 'ok'){
$amo = $user_coin + $amount;
$user_data = $amo;
$tedad = $row['link'];
$exlink = explode('/', $tedad);
$channelorder = $exlink[count($exlink) - 2];
$id = end($exlink);
$getview= GetViews($channelorder,$id);
$connect->query("UPDATE `user` SET `coin` = '$amo' WHERE `id` = '$user1' LIMIT 1");

$true_seen = array("result"=>"ok","order"=>"$order_id","stats"=>"$stats","count"=>"$count", "amount"=>"$amount");
echo json_encode($true_seen);
bot('sendmessage',[
      'chat_id'=>$from_id,
        'text'=>"❗️ سفارش بازدید با شماره پیگیری $order_id لغو شد .

⏱ زمان :  $time
💰 هزینه سفارش : $amount تومان
👁‍🗨 تعداد بازدید درخواستی : $count",
'parse_mode'=>$pars_mode,
'disable_web_page_preview'=>true
]);
}else{
echo json_encode($false_seen);
}}}
////////


elseif($type == 'cancel-l'){
if($apikey = $user_apikey){
$result = curl("$seenapi?apikey=$seenpass&type=cancel-l&id=$id");
$result1 = json_decode($result,true);
$resul1t = $result1["result"];
$order_id = "{$result->order}";
$count = "{$result->count}";
$amount = "{$result->amount}";
$time = date("H:i:s Y/m/d");
$stats = "{$result->stats}";
if($result->result == 'ok'){
$amo = $user_coin + $amount;
$user_data = $amo;
$tedad = $row['link'];
$exlink = explode('/', $tedad);
$channelorder = $exlink[count($exlink) - 2];
$id = end($exlink);
$getview= GetViews($channelorder,$id);
$connect->query("UPDATE `user` SET `coin` = '$amo' WHERE `id` = '$user1' LIMIT 1");

$true_seen = array("result"=>"ok","order"=>"$order_id","stats"=>"$stats","count"=>"$count", "amount"=>"$amount");
echo json_encode($true_seen);
bot('sendmessage',[
      'chat_id'=>$from_id,
        'text'=>"❗️ سفارش لایک با شماره پیگیری $order_id لغو شد .

⏱ زمان :  $time
💰 هزینه سفارش : $amount تومان
تعداد لایک درخواستی : $count",
'parse_mode'=>$pars_mode,
'disable_web_page_preview'=>true
]);
}else{
echo json_encode($false_seen);
}}}










elseif($type == 'status-l'){
if($apikey = $user_apikey){
$result = curl("$seenapi?apikey=$seenpass&type=status-l&id=$id");
$result1 = json_decode($result,true);
$resul1t = $result1["result"];
$order_id = "{$result->order}";
$stats = "{$result->stats}";
if($result->result == 'ok'){
$amo = $user_coin - $coinview;
$user_data = $amo;
$tedad = $row['link'];
$exlink = explode('/', $tedad);
$channelorder = $exlink[count($exlink) - 2];
$id = end($exlink);
$getview= GetViews($channelorder,$id);
$true_seen = array("result"=>"ok","order"=>"$order_id","stats"=>"$stats");
echo json_encode($true_seen);
}else{
echo json_encode($false_seen);
}}}

/// کنسلی لایک
elseif($type == 'status-v'){
if($apikey = $user_apikey){
$result = curl("$seenapi?apikey=$seenpass&type=status-v&id=$id");
$result1 = json_decode($result,true);
$resul1t = $result1["result"];
$order_id = "{$result->order}";
$stats = "{$result->stats}";
if($result->result == 'ok'){
$amo = $user_coin - $coinview;
$user_data = $amo;
$tedad = $row['link'];
$exlink = explode('/', $tedad);
$channelorder = $exlink[count($exlink) - 2];
$id = end($exlink);
$getview= GetViews($channelorder,$id);
$true_seen = array("result"=>"ok","order"=>"$order_id","stats"=>"$stats");
echo json_encode($true_seen);
}else{
echo json_encode($false_seen);
}}}
//=========================
if($type == 'stats'){
echo json_encode($stats);
}//&type=status-v&id=bf737b6def
//=========================
elseif($type == 'view'){
$payres = RandomString(10);
$coinview = $count * $_seen;
if($coinview <= $user_coin and $apikey = $user_apikey and $count <= $maxorder){
$result = curl("$seenapi?apikey=$seenpass&type=view&count=$count&speed=$speed&period=$period&channel=$channel&id=$id");
//        $file = fopen("data2channel.txt", "a") or die("Unable to open file!");
//        fwrite($file, "\n $seenapi?apikey=$seenpass&type=view&count=$count&speed=$speed&period=$period&channel=$channel&id=$id");
$result1 = json_decode($result,true);
$resul1t = $result1["result"];
$order_id = "{$result->order}";
$seenstart= "{$result->seenstart}";
$seenend = "{$result->seenend}";
if($result->result == 'ok'){
$amo = $user_coin - $coinview;
$user_data = $amo;
$link = "t.me/$channel/$id";
$date = date("Y/m/d");
$connect->query("INSERT INTO `orderseen` (`key` , `id` , `amount` , `speed` ,`view` , `link` , `time`) VALUES ('$order_id' ,'$from_id' , '$coinview' , '$speed' , '$count' , '$link' , '$date')");
$connect->query("UPDATE `user` SET `coin` = '$amo' WHERE `id` = '$user1' LIMIT 1");
$true_seen = array("result"=>"ok","order"=>"$order_id","count"=>"$count","coin"=>"$coinview","seenstart"=>"$seenstart","seenend"=>"$seenend");
echo json_encode($true_seen);
    $value = rand(0,2);
    if ($value == 0){
bot('sendmessage',[
      'chat_id'=>$from_id,
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .

💰 هزینه سفارش : $coinview تومان
👁‍🗨 تعداد بازدید درخواستی : $count
👁 بازدید فعلی : $seenstart 
🆔 لینک : t.me/$channel/$id",
'parse_mode'=>$pars_mode,
'disable_web_page_preview'=>true
]);
    }
    if ($value == 1 ||$value == 2 ){
        bot1('sendmessage',[
            'chat_id'=>$from_id,
            'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .

💰 هزینه سفارش : $coinview تومان
👁‍🗨 تعداد بازدید درخواستی : $count
👁 بازدید فعلی : $seenstart 
🆔 لینک : t.me/$channel/$id",
            'parse_mode'=>$pars_mode,
            'disable_web_page_preview'=>true
        ]);
    }
    $coinviewcost = $count * 0.1;
    $sod = $coinview - $coinviewcost ;

//    $user = $usern['id'];
  $sod_system = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `pol` WHERE `id` = '1' LIMIT 1"));
//   $totalpol_new = $sod_system['totalpol'] + $sod ;
//   $today_new = $sod_system['today'] + $sod ;
//    $connect->query("UPDATE `pol` SET `totalpol` = '$totalpol_new' , `today`='$today_new' WHERE `id` = '1' LIMIT 1");

    $file_name = 'sod.txt'; // نام فایل

// خواندن محتوای فایل
    $content = file_get_contents($file_name);

// تبدیل محتوا به عدد
    $number = intval($content);

// کم کردن مقدار از عدد خوانده شده
// $value_to_subtract = 10; // مقداری که می‌خواهید کم کنید
//    $value_to_subtract = rand(0,8);

//    $number -= $value_to_subtract;
    $number = $number+$sod;
// ذخیره مقدار جدید در فایل
    file_put_contents($file_name, $number);
   $totalpol_new = $sod_system['totalpol'] + $sod ;


   $connect->query("UPDATE `pol` SET `totalpol` = '$totalpol_new' WHERE `id` = '1' LIMIT 1");

    bot2('sendmessage',[
        'chat_id'=>-1002143845071,
        'text'=>" پول اومد به حساب ! 
$sod تومن سود 
از seen با شناسه $order_id دریافت شد 💠

سود ربات تا اینجا $number تومن است ❇️ 
",
        'parse_mode'=>$pars_mode,
        'disable_web_page_preview'=>true
    ]);
}else{
echo json_encode($false_seen);
}
}else{
echo json_encode($false_enough_coin);
}
}
//---_-----------_----------------
elseif($type == 'status'){
if ( $apikey = $user_apikey ){
echo json_encode($stat);
}else{
echo json_encode($false_invalid_password);
}}
//=============================
if($type == 'like'){
$coinlike = $count * $_like;
if($coinlike <= $user_coin and $apikey = $user_apikey and $count <= $maxorder){
$resultl = file_get_contents("$likeapi?apikey=$likepass&type=like&count=$count&row=$row&column=$column&channel=$channel&id=$id");
$resultl1 = json_decode($resultl,true);
$resultlike = $resultl1["result"];
$order_id  = $resultl1["order"];
if($resultlike == 'ok'){
$amoli = $user_coin - $coinlike;
$user_data['coin'] = $amoli;
	$connect->query("UPDATE `user` SET `coin` = '$amoli' WHERE `id` = '$user1' LIMIT 1");
	$true_like = array("result"=>"ok","order"=>"$order_id");
echo json_encode($true_like);
$link1 = "t.me/$channel/$id";
bot('sendmessage',[
        'chat_id'=>$from_id,
          'text'=>"☑️ سفارش لایک (رأی) با شماره پیگیری $order_id ثبت شد .

💰 هزینه سفارش : $coinlike تومان
👍🏻 تعداد درخواست لایک : $count 
✅ گزینه انتخابی : ردیف $row دکمه $column 

🆔 لینک : t.me/$channel/$id",
'parse_mode'=>$pars_mode,
'disable_web_page_preview' => true
                  ]);    
}else{ 
echo json_encode($false_like);
}
}else{echo json_encode($false_enough_coin);
}
}
if($type == 'reaction'){
$coinact = $count * $_act;
if($coinact <= $user_coin and $apikey = $user_apikey and $count <= $maxorder){
$resultl = file_get_contents("$likeapi?apikey=$likepass&type=reaction&count=$count&emoji=$emoji&channel=$channel&id=$id");
$resultl1 = json_decode($resultl,true);
$resultlike = $resultl1["result"];
$order_id  = $resultl1["order"];
if($resultlike == 'ok'){
$amoli = $user_coin - $coinact;
$user_data['coin'] = $amoli;
	$connect->query("UPDATE `user` SET `coin` = '$amoli' WHERE `id` = '$user1' LIMIT 1");
	$true_like = array("result"=>"ok","order"=>"$order_id","count"=>"$count","amount"=>"$coinact","emoji"=>"$emoji");
echo json_encode($true_like);
$link1 = "t.me/$channel/$id";
bot('sendmessage',[
        'chat_id'=>$from_id,
          'text'=>"☑️ سفارش (ری اکشن) با شماره پیگیری $order_id ثبت شد .

💰 هزینه سفارش : $coinact تومان
👍🏻 تعداد درخواست  : $count 
✅ گزینه انتخابی : $emoji

🆔 لینک : t.me/$channel/$id",
'parse_mode'=>$pars_mode,
'disable_web_page_preview' => true
                  ]);    
}else{ 
echo json_encode($false_like);
}
}else{echo json_encode($false_enough_coin);
}
}

?>