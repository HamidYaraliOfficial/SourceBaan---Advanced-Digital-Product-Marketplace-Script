<?php
/*
Author { @Ziazl}
*/
$dir = dirname(__DIR__);
include "config.php";

define("MerchantID","$MerchantID");

# ------------- { start - function } ------------ #
function getChatMember($user)
{
    $name = bot("getChatMember", ["chat_id" => (int) $user, "user_id" => (int) $user])->result->user->first_name;
    $name = str_replace([">", "/", "<"], ["&gt;", NULL, "&lt;"], $name);
    return $name;
}
function domin()
{
    $exp = explode("/", $_SERVER["REQUEST_URI"]);
    $url = "";
    for ($i = 1; $i < count($exp) - 1; $i++) {
        $url .= "/" . $exp[$i];
    }
    return $_SERVER["HTTP_HOST"] . $url;
}
function getip()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    } else {
        if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
            $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } else {
            $ip = $_SERVER["REMOTE_ADDR"];
        }
    }
    return $ip;
}
function ip_info($ip)
{
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, "http://ip-api.com/csv/" . $ip . "");
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
    $exec = curl_exec($c);
    curl_close($c);
    $exp = explode(",", $exec);
    $pais = $exp[1];
    return $pais;
}
# ------------- { end - function } ------------ #

$domin = domin();
$ip = getip();
if (strtolower(ip_info($ip)) == "iran") {
    $domin = $domin;
    $domin = str_replace("", NULL, $domin);
    $domin = $domin . "";
    if (isset($_GET["code"]) && isset($_GET["get"])) {
        $code = $_GET["code"];
        $pays = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `pay` WHERE `code` = '$code' LIMIT 1"));
        $Amount = $pays["amount"];
        $fid = $pays["id"];
        $number = $pays["phone"];
        if ($pays["step"] == "pay") {
            $connect->query("UPDATE `pay` SET `ip` = '$ip' WHERE `code` = '$code' LIMIT 1");
            if (isset($Amount) && isset($number)) {

//                $url = "https://nextpay.org/nx/gateway/token";
//                $curl = curl_init();
//                curl_setopt_array($curl, array(
//                    CURLOPT_URL => $url,
//                    CURLOPT_RETURNTRANSFER => true,
//                    CURLOPT_ENCODING => '',
//                    CURLOPT_MAXREDIRS => 10,
//                    CURLOPT_TIMEOUT => 0,
//                    CURLOPT_FOLLOWLOCATION => true,
//                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//                    CURLOPT_CUSTOMREQUEST => 'POST',
//                    CURLOPT_POSTFIELDS => "api_key=" . MerchantID . "&currency=IRT&amount=" . $Amount . "&order_id=" . $code . "&customer_phone=" . $number . "&callback_uri=" . "https://" . $domin . "/nexpay.php?back",
//                ));
//                $result = curl_exec($curl);
//                $result = json_decode($result);
//                curl_close($curl);
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => 'https://api.zarinpal.com/pg/v4/payment/request.json',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>'{
  "merchant_id": "07097f0",
    "currency": "IRT",
  "amount":"'.$Amount . '",
  "callback_url": "https://'.$domin.'/nextpay.php",
  "description": "Transaction description.",
  "metadata": {
    "mobile": "'.$number.'",
     "email": "info.test@gmail.com"

  }
}',
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Accept: application/json'
                    ),
                ));
                $result1 = curl_exec($curl);
                $result = json_decode($result1);

                curl_close($curl);

                $trans_id = $result->data->authority;

                if ($result->data->message == "Success") {
//                    header("Location: https://nextpay.org/nx/gateway/payment/" . $trans_id);
                    header("Location: https://www.zarinpal.com/pg/StartPay/" . $trans_id);
                    $connect->query("UPDATE `pay` SET `authority` = '$trans_id'  WHERE `code` = '$code' LIMIT 1");

                } else {
                    bot('sendmessage', ['chat_id' => 1390918103,'text' => "مشکل در درگاه نکست پی : " . json_encode($result->code, 448),]);
                    ?>
                    <html lang="en" dir="rtl">
                    <style>
                        html {
                            background: #EAEAEA;
                            justify-content: center;
                            text-align: center;
                        }
                        .head {
                            margin-top: 10px;
                            font-family: "Vazir";
                            display: flex;
                            background: #FF2E63;
                            color: white;
                            text-align: center;
                            justify-content: center;
                            border-radius: 20px;
                            height: auto;
                            text-shadow: 4px 3px #252A34;
                        }
                        .mybtn {
                            font-family: "Vazir";
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin-right: auto;
                            margin-left: auto;
                            text-align: center;
                            background: #08D9D6;
                            color: #fff;
                            height: 40px;
                            font-size: medium;
                            text-decoration: none;
                            border-radius: 20px;
                            margin-top: 7px;
                        }
                        .mybtn:hover {
                            background-color: gold;
                        }
                        footer {
                            border-radius: 20px;
                            font-family: "Vazir";
                            text-align: center;
                            padding: 3px;
                            color: white;
                            background-color: #252A34;
                            text-align: center;
                            padding: 10px;
                            margin-top: 7px;
                        }
                        .bi{
                            text-decoration: none;
                        }
                    </style>
                    <head> <meta charset="utf-8">
                        <title>Fergal Seen</title>
                        <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
                        <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
                    </head>
                    <header class="head">
                        <h1>لینک پرداخت ساخته نشد !</h1>
                    </header>
                    <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
                    </html>
                    <?
                }
            } else {
                ?>
                <html lang="en" dir="rtl">
                <style>
                    html {
                        background: #EAEAEA;
                        justify-content: center;
                        text-align: center;
                    }
                    .head {
                        margin-top: 10px;
                        font-family: "Vazir";
                        display: flex;
                        background: #FF2E63;
                        color: white;
                        text-align: center;
                        justify-content: center;
                        border-radius: 20px;
                        height: auto;
                        text-shadow: 4px 3px #252A34;
                    }
                    .mybtn {
                        font-family: "Vazir";
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-right: auto;
                        margin-left: auto;
                        text-align: center;
                        background: #08D9D6;
                        color: #fff;
                        height: 40px;
                        font-size: medium;
                        text-decoration: none;
                        border-radius: 20px;
                        margin-top: 7px;
                    }
                    .mybtn:hover {
                        background-color: gold;
                    }
                    footer {
                        border-radius: 20px;
                        font-family: "Vazir";
                        text-align: center;
                        padding: 3px;
                        color: white;
                        background-color: #252A34;
                        text-align: center;
                        padding: 10px;
                        margin-top: 7px;
                    }
                    .bi{
                        text-decoration: none;
                    }
                </style>
                <head> <meta charset="utf-8">
                    <title>Fergal Seen</title>
                    <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
                    <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
                </head>
                <header class="head">
                    <h1>درخواست نامعتبر است !</h1>
                </header>
                <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
                </html>
                <?
            }
        } else {
            ?>
            <html lang="en" dir="rtl">
            <style>
                html {
                    background: #EAEAEA;
                    justify-content: center;
                    text-align: center;
                }
                .head {
                    margin-top: 10px;
                    font-family: "Vazir";
                    display: flex;
                    background: #FF2E63;
                    color: white;
                    text-align: center;
                    justify-content: center;
                    border-radius: 20px;
                    height: auto;
                    text-shadow: 4px 3px #252A34;
                }
                .mybtn {
                    font-family: "Vazir";
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-right: auto;
                    margin-left: auto;
                    text-align: center;
                    background: #08D9D6;
                    color: #fff;
                    height: 40px;
                    font-size: medium;
                    text-decoration: none;
                    border-radius: 20px;
                    margin-top: 7px;
                }
                .mybtn:hover {
                    background-color: gold;
                }
                /*
            Author { @Ziazl}
            */
                footer {
                    border-radius: 20px;
                    font-family: "Vazir";
                    text-align: center;
                    padding: 3px;
                    color: white;
                    background-color: #252A34;
                    text-align: center;
                    padding: 10px;
                    margin-top: 7px;
                }
                .bi{
                    text-decoration: none;
                }
            </style>
            <head> <meta charset="utf-8">
                <title>Fergal Seen</title>
                <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
                <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
            </head>
            <header class="head">
                <h1>لینک تراکنش فاقد اعتبار است دوباره تلاش کنید !</h1>
            </header>
            <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
            </html>
            <?
        }
    } else {

        if (isset($_REQUEST["Authority"])) {
            $authority = $_REQUEST["Authority"];
//            $code = $_REQUEST["order_id"];
            $pays = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `pay` WHERE `authority` = '$authority' LIMIT 1"));
            $Amount = $pays["amount"];
            $step = $pays["step"];
            $fid = $pays["id"];
            $number = $pays["phone"];
            $name = getChatMember($fid);


//            $order_id = $_REQUEST["ref_id"];
            $Status = $_REQUEST["Status"];
            $authority = $_REQUEST["Authority"];

            $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fid' LIMIT 1"));

//            $trans_id1 = $_REQUEST["ref_id"];
            $amount1 = $pays["amount"];

            if ($Status == "NOK") {
                $connect->query("UPDATE `pay` SET `step` = 'NOK' WHERE `authority` = '$authority' LIMIT 1");
                echo "<h1 style=\"text-align: center;margin-top:30px\">خطایی رخ داده است</h1>";
                bot('sendmessage', ['chat_id' => $fid,'text' => "خطایی رخ داده است"]);
                return false;
            }

            if ($Status == "OK") {

//                $url = "https://nextpay.org/nx/gateway/verify";
//                $curl = curl_init();
//                curl_setopt_array($curl, array(
//                    CURLOPT_URL => $url,
//                    CURLOPT_RETURNTRANSFER => true,
//                    CURLOPT_ENCODING => '',
//                    CURLOPT_MAXREDIRS => 10,
//                    CURLOPT_TIMEOUT => 0,
//                    CURLOPT_FOLLOWLOCATION => true,
//                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//                    CURLOPT_CUSTOMREQUEST => 'POST',
//                    CURLOPT_POSTFIELDS => 'api_key=' . MerchantID . '&amount=' . $amount1 . '&trans_id=' . $trans_id1,
//                ));
//                $result = curl_exec($curl);
//                $result = json_decode($result);
//                curl_close($curl);
                $pays = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `pay` WHERE `authority` = '$authority' LIMIT 1"));
                $Amount = $pays["amount"];

                $curl = curl_init();
                $AmountRiyal = $Amount*10 ;
                curl_setopt_array($curl, array(
                    CURLOPT_URL => 'https://api.zarinpal.com/pg/v4/payment/verify.json',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>'{
  "merchant_id": "07097f02",
  "amount":"'.$Amount . '",
  "authority": " '.$authority.' "
}',
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Accept: application/json'
                    ),
                ));

                $result1 = curl_exec($curl);
                $result = json_decode($result1);

                curl_close($curl);

//                $file = fopen("dataudhkzjvhkjvdskn.txt", "a") or die("Unable to open file!");
////      fwrite($file, "\n https://Mesterseen.ir/seen/api.php?apikey=8317bd1e2cee4e9099bf&type=view&count={$user['view']}&speed=$explode[1]&period=$explode[0]&channel=$channelorder&id=$id \n");
//                fwrite($file, "\n $result1    .........  $AmountRiyal    $Amount//////////////////  $authority  \n");


                if ($result->data->code == 100 ) {
                    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$fid' LIMIT 1"));
                    $pays = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `pay` WHERE `authority` = '$authority' LIMIT 1"));

                    echo "<h1 style=\"text-align: center\">تراکنش موفقیت آمیز بود.</h1>";
                    $pay = $result->data->ref_id;
                    $card = $result->data->card_pan;
                    $mojodiold = $user["coin"];
                    $mojpay = $pays["coin"];
                    $mojodinew = $mojodiold + $mojpay;
                    $connect->query("INSERT INTO `buy` (`id` , `amount`) VALUES ('$fid', '$Amount')");
                    $connect->query("UPDATE `user` SET `coin` = '$mojodinew' WHERE `id` = '$fid' LIMIT 1");
                    $connect->query("UPDATE `pay` SET `step` = 'OK' , `paycode` = '$pay' WHERE `authority` = '$authority' LIMIT 1");

                    $t1 = "✅ با تشکر از خرید شما، $mojpay تومان به حسابتان افزوده شد.
👈 مبلغ پرداختی: $Amount تومان
👈 شماره پیگیری: $pay
👈 زمان پرداخت: $date ساعت $time";
                    bot('sendmessage', ['chat_id' => $fid,'text' => $t1,'parse_mode' => "HTML"]);
                    bot('sendmessage', ['chat_id' => -1001897353081, 'text' => "#تراکنش جدید \n کاربر : <a href = 'tg://user?id=" . $fid . "'>" . $name . "</a> \n شناسه عددی : <code>" . $fid . "</code> \n شماره پیگیری : <code>" . $pay . "</code> \n مبلغ پرداختی : " . $amount1 . " \n موجودی کلی : " . $mojodinew . " \n شماره کاربر : <code>0" . $number . "</code>\nنمایندگی\n\nIP : " . $ip . "\ncard : " . $card,'parse_mode' => "HTML"]);
                } else {
                    $step = $result->code;
                    $connect->query("UPDATE `pay` SET `step` = '$step' WHERE `authority` = '$authority' LIMIT 1");
                    echo "<h1 style=\"text-align: center\">تراکنش انجام نشد</h1>";
                    bot('sendmessage', ['chat_id' => $fid,'text' => "تراکنش انجام نشد"]);
                }
            } else {
                $connect->query("UPDATE `pay` SET `step` = 'NOK' WHERE `authority` = '$authority' LIMIT 1");
                ?>
                <html lang="en" dir="rtl">
                <style>
                    html {
                        background: #EAEAEA;
                        justify-content: center;
                        text-align: center;
                    }
                    .head {
                        margin-top: 10px;
                        font-family: "Vazir";
                        display: flex;
                        background: #FF2E63;
                        color: white;
                        text-align: center;
                        justify-content: center;
                        border-radius: 20px;
                        height: auto;
                        text-shadow: 4px 3px #252A34;
                    }
                    .mybtn {
                        font-family: "Vazir";
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-right: auto;
                        margin-left: auto;
                        text-align: center;
                        background: #08D9D6;
                        color: #fff;
                        height: 40px;
                        font-size: medium;
                        text-decoration: none;
                        border-radius: 20px;
                        margin-top: 7px;
                    }
                    .mybtn:hover {
                        background-color: gold;
                    }
                    footer {
                        border-radius: 20px;
                        font-family: "Vazir";
                        text-align: center;
                        padding: 3px;
                        color: white;
                        background-color: #252A34;
                        text-align: center;
                        padding: 10px;
                        margin-top: 7px;
                    }
                    .bi{
                        text-decoration: none;
                    }
                </style>
                <head> <meta charset="utf-8">
                    <title>Fergal Seen</title>
                    <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
                    <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
                </head>
                <header class="head">
                    <h1>تراکنش توسط کاربر لغو شد !</h1>
                </header>
                <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
                </html>
                <?
                bot('sendmessage', ['chat_id' => $fid,'text' => "✅ تراکنش شما با موفقیت لغو شد

👇🏻جهت اطلاعات بیشتر از دکمه های زیر استفاده کنید"]);
            }
        } else {
            ?>
            <html lang="en" dir="rtl">
            <style>
                html {
                    background: #EAEAEA;
                    justify-content: center;
                    text-align: center;
                }
                .head {
                    margin-top: 10px;
                    font-family: "Vazir";
                    display: flex;
                    background: #FF2E63;
                    color: white;
                    text-align: center;
                    justify-content: center;
                    border-radius: 20px;
                    height: auto;
                    text-shadow: 4px 3px #252A34;
                }
                .mybtn {
                    font-family: "Vazir";
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-right: auto;
                    margin-left: auto;
                    text-align: center;
                    background: #08D9D6;
                    color: #fff;
                    height: 40px;
                    font-size: medium;
                    text-decoration: none;
                    border-radius: 20px;
                    margin-top: 7px;
                }
                .mybtn:hover {
                    background-color: gold;
                }
                footer {
                    border-radius: 20px;
                    font-family: "Vazir";
                    text-align: center;
                    padding: 3px;
                    color: white;
                    background-color: #252A34;
                    text-align: center;
                    padding: 10px;
                    margin-top: 7px;
                }
                .bi{
                    text-decoration: none;
                }
            </style>
            <head> <meta charset="utf-8">
                <title>Fergal Seen</title>
                <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
                <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
            </head>
            <header class="head">
                <h1>درخواست نامعتبر است !</h1>
            </header>
            <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
            </html>
            <?
        }
    }
} else {
    ?>
    <html lang="en" dir="rtl">
    <style>
        html {
            background: #EAEAEA;
            justify-content: center;
            text-align: center;
        }
        .head {
            margin-top: 10px;
            font-family: "Vazir";
            display: flex;
            background: #FF2E63;
            color: white;
            text-align: center;
            justify-content: center;
            border-radius: 20px;
            height: auto;
            text-shadow: 4px 3px #252A34;
        }
        .mybtn {
            font-family: "Vazir";
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: auto;
            margin-left: auto;
            text-align: center;
            background: #08D9D6;
            color: #fff;
            height: 40px;
            font-size: medium;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 7px;
        }
        .mybtn:hover {
            background-color: gold;
        }
        footer {
            border-radius: 20px;
            font-family: "Vazir";
            text-align: center;
            padding: 3px;
            color: white;
            background-color: #252A34;
            text-align: center;
            padding: 10px;
            margin-top: 7px;
        }
        .bi{
            text-decoration: none;
        }
    </style>
    <head> <meta charset="utf-8">
        <title>Fergal Seen</title>
        <link href='https://cdn.fontcdn.ir/Font/Persian/Yekan/Yekan.css' rel='stylesheet' type='text/css'>
        <link href='https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css' rel='stylesheet' type='text/css'>
    </head>
    <header class="head">
        <h1>لطفا فیلتر شکن خود را خاموش کنید !</h1>
    </header>
    <div class="bot"> <a href="https://t.me/<? echo $usernamebot;?>" class="mybtn bd1">ورود به ربات</a> </div>
    </html>
    <?
}
