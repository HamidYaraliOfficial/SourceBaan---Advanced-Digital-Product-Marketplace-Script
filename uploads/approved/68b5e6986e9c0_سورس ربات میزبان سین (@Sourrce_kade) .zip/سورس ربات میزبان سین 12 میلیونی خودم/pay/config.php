<?php
/*
Author { @Ziazl}
*/
define('API_KEY','1727:kwkwjnqkwowlwdnfhw');
//
$MerchantID = 'c0302c7f'; // 
//

$connect = new mysqli('localhost','name','pass','name');
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
if (mysqli_connect_errno($connect))
 {
 echo "Failed to connect  to MySQL: " . mysqli_connect_error();
   mysqli_close($connect);
 }
//
function bot($method,$datas=[]){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
return json_decode(curl_exec($ch));
}
//
if(isset($update->message)){
$message = $update->message;
$message_id = $message->message_id;
$text = $update->message->text;
$date1 = date("Y/m/d");
$time = date("H:i:s");
$dated = date("Y/m/d");
$chat_id = $message->chat->id;
$tc = $message->chat->type;
$first_name = $message->from->first_name;
$from_id = $message->from->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$from_id' LIMIT 1"));
}