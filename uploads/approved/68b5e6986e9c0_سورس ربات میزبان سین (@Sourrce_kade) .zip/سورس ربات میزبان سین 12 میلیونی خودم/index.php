<!DOCTYPE html>
<html class="no-js" lang="en"> 
    <head>
        <meta charset="utf-8">
        <title>Domain Seen</title>
        <meta name="description" content="">
        <meta name="author" content="ticlekiwi">

        <meta http-equiv="cleartype" content="on">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="css/hightlightjs-dark.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.8.0/highlight.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,500|Source+Code+Pro:300" rel="stylesheet">
        <link rel="stylesheet" href="css/style.css" media="all">
		<link rel="icon" href="images/logokk.png" type="image/png" sizes="16x16">
    </head>

    <body>
        <div class="left-menu">
            <div class="content-logo">
                <img alt="platform by Emily van den Heever from the Noun Project" title="platform by Emily van den Heever from the Noun Project" src="images/logokk.png" height="32" />
                <span>Domain Seen | api</span>
            </div>
            <div class="content-menu">
                <ul>
                    <li class="scroll-to-link active" data-target="get-started">
                        <a>GET STARTED</a>
                    </li>
                    <li class="scroll-to-link" data-target="get-characters">
                        <a>SEND REQUEST</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="content-page">
            <div class="content">
                <div class="overflow-hidden content-section" id="content-get-started">
                    <h1 id="get-started">Get Started</h1>
                    <p>
                        To use this API, you need an <strong>API key</strong>. Please contact at <a href="https://t.me/Domainseenapibot">@Domainseenapibot</a> to get your own API key and manage This. 
                    </p>
                </div>
                <div class="overflow-hidden content-section" id="content-get-characters">
                    <h2 id="get-characters">Send Request</h2>
                    <p>
                        To Send Request you need to make a Get call to the following url and use Get Method and Response format Is Json<br>
                        <code class="higlighted">https://Domainseen.ir/api/api.php</code>
                    </p>
                    <br>
                    <h4>AMOUNT Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>amount</td>
                            </tr>
                        </tbody>
                    </table>
					<p>Ex : https://Domainseen.ir/api/api.php?apikey=xxxxxxxxxx&type=amount</p>
					<br>
                    <h4>OrderSeen Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>view</td>
                            </tr>
                            <tr>
                                <td>count</td>
                                <td>integer</td>
                                <td>100 - 120000 views</td>
                            </tr>
                            <tr>
                                <td>speed</td>
                                <td>integer</td>
                                <td>0 - 200000 views (0 Max Speed)</td>
                            </tr>
                            <tr>
                                <td>period</td>
                                <td>integer</td>
                                <td>0 - 100 mins (0 Max Speed)</td>
                            </tr>
                            <tr>
                                <td>channel</td>
                                <td>string</td>
                                <td>telegram channel username without @</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>integer</td>
                                <td>the post id in channel</td>
                            </tr>
                        </tbody>
                    </table>
                    <h4>OrderLike Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>like</td>
                            </tr>
                            <tr>
                                <td>count</td>
                                <td>integer</td>
                                <td>1 - 120000 likes</td>
                            </tr>
                            <tr>
                                <td>row</td>
                                <td>integer</td>
                                <td>Optional row</td>
                            </tr>
                            <tr>
                                <td>column</td>
                                <td>integer</td>
                                <td>Optional column</td>
                            </tr>
                            <tr>
                                <td>channel</td>
                                <td>string</td>
                                <td>telegram channel username without @</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>integer</td>
                                <td>the post id in channel</td>
                            </tr>
                        </tbody>
                    </table>
					<p>* For Vote orders, set the column to '0'</p>
					<br>
					 <h4>OrderReaction Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>reaction</td>
                            </tr>
                            <tr>
                                <td>count</td>
                                <td>integer</td>
                                <td>1 - 120000 reaction</td>
                            </tr>
                            <tr>
                                <td>emoji</td>
                                <td>string</td>
                                <td>Optional reaction emoji (UTF-8)</td>
                            </tr>
                            <tr>
                                <td>channel</td>
                                <td>string</td>
                                <td>telegram channel username without @</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>integer</td>
                                <td>the post id in channel</td>
                            </tr>
                        </tbody>
                    </table>
					<h4>Status Seenorder</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>status-v</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>string</td>
                                <td>your order id</td>
                            </tr>
                        </tbody>
                    </table>
					<p>* Orders will be deleted upon completion</p>	
					<br>
								<h4>Status Likeorder</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>status-l</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>string</td>
                                <td>your order id</td>
                            </tr>
                        </tbody>
                    </table>
					<p>* Orders will be deleted upon completion</p>	
					<br>
										<h4>Cancel Seenorder</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>cancel-v</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>string</td>
                                <td>your order id</td>
                            </tr>
                        </tbody>
                    </table>
					<p>* Orders will be deleted upon completion</p>	
					<br>
								<h4>Cancel Likeorder</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>cancel-l</td>
                            </tr>
                            <tr>
                                <td>id</td>
                                <td>string</td>
                                <td>your order id</td>
                            </tr>
                        </tbody>
                    </table>
					<p>* Orders will be deleted upon completion</p>	
					<br>
                    <h4>Addfuns Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>addfuns</td>
                            </tr>
                            <tr>
                                <td>amount</td>
                                <td>integer</td>
                                <td>Base On Toman</td>
                            </tr>
                        </tbody>
                    </table>
					<p>Ex https://Domainseen.ir/api/api.php?apikey=xxxxxxxxxx&type=addfuns&amount=xxxxx</p>	
					<br>
                    <h4>Stats Parameters</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>apikey</td>
                                <td>string</td>
                                <td>Your API key</td>
                            </tr>
                            <tr>
                                <td>type</td>
                                <td>string</td>
                                <td>status</td>
                            </tr>
                        </tbody>
                    </table>	
					<p>* Show Info of Apikey and Max order ...</p>						
                </div>
            </div>
        </div>
		<!-- Scripts -->

			<script src="assets/js/jquery.min.js"></script>

			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
		
	</body>
</html>