<?php
error_reporting(0);
//========================= // ==============================
define('API_KEY','82828282937:kdlsksnwbs'); # main
define('API_KEY1','8282827272:kekwnwjakwjjdf'); #bot report 
define('API_KEY2','819183738:kwjwhdgwhjw'); # report to admin
//========================== // ==============================
$admin = array('0000','0000','000','000');
$botid = '5123519204';
$channel = '@l'; //تنظیم نشده
$botname = 'سعید سین';
$web = 'https://wtysg/api';

$usernamesup = '@';// تنظیم نشده
//========================== // ==============================
$_gift = '0';
//========================== // ==============================

$connect = new mysqli('localhost','name','pass','name');
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
$domain = "https://domain.ir/api";
$channellearn = '1390918103';
$channel_token_id = '1390918103';
$connectt = new mysqli('localhost','name-cr','pass','name-cr');#Robotsaz
$connectt->query("SET NAMES 'utf8'"); $connectt->set_charset('utf8mb4');

?>
