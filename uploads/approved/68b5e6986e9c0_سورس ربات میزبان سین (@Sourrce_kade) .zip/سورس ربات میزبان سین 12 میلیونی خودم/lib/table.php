<?php
//نکته مهم: بعد از آماده شدن دیتابیس شما یک بار صفحه اجرا شود
include '../config.php';
//========================== // table creator // ==============================
mysqli_multi_query($connect,"CREATE TABLE `user` (
    `id` int PRIMARY KEY,
	`step` varchar(50) DEFAULT NULL,
	`member` int DEFAULT '0',
	`coin` int NOT NULL,
        `data` TEXT DEFAULT NULL,
	`inviter` int DEFAULT '0',
        `phone` varchar(11) DEFAULT NULL,
        `com` varchar(11) DEFAULT NULL
            ) default charset = utf8mb4;
	CREATE TABLE `orderseen` (
	`key` varchar(155) PRIMARY KEY,
    `id` int NOT NULL,
	`amount` int NOT NULL,
	`speed` varchar(90) NOT NULL,
	`view` int NOT NULL,
	`link` TEXT NOT NULL,
	`time` varchar(155) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4;
	CREATE TABLE `orderlike` (
	`key` varchar(155) PRIMARY KEY,
    `id` int NOT NULL,
	`amount` int NOT NULL,
	`speed` varchar(155) NOT NULL,
	`like` int NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4; 
	CREATE TABLE `channel` (
	`channel` bigint PRIMARY KEY,
    `id` int NOT NULL,
	`view` int NOT NULL,
	`speed` varchar(50) NOT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `buy` (
	`key` int AUTO_INCREMENT PRIMARY KEY,
    `id` int NOT NULL,
	`amount` int NOT NULL,
	`time` varchar(155) NOT NULL
    ) default charset = utf8mb4;
	CREATE TABLE `block` (
    `id` int NOT NULL
    ) default charset = utf8mb4;   	
    CREATE TABLE `daily` (
    `time` varchar(50) DEFAULT '',
    `user` int DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `sendall` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`user` int DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `pay` (
    `code` bigint(30) NOT NULL PRIMARY KEY,
    `id` bigint(60) NOT NULL,
    `phone` varchar(20) DEFAULT NULL,
    `step` varchar(50) NOT NULL,
    `ip` varchar(100) DEFAULT NULL,
    `date` varchar(100) DEFAULT NULL,
    `amount` bigint(20) NOT NULL,
    `coin` bigint(100) DEFAULT NULL,
    `paycode` varchar(500) DEFAULT NULL
    ) default charset = utf8mb4;
    INSERT INTO `sendall` () VALUES ();
    INSERT INTO `daily` () VALUES ();");
//========================== // Check connection // ==============================
/*
Author { @Ziazl}
*/
if ($connect->connect_error) {
   die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
  echo "دیتابیس متصل و نصب شد ."

?>