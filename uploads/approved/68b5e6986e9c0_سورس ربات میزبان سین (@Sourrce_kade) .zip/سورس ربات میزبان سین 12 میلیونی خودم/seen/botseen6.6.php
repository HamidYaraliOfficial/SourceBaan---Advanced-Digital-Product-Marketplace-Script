<?php

date_default_timezone_set("Asia/Tehran");
$date = date("Y/m/d");
ob_start();
include 'config.php';
include('jdf.php');
function bot($method,$datas=[]){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
return json_decode(curl_exec($ch));
}
$update = json_decode(file_get_contents('php://input'));

if(isset($update->message)){
$data = $update->callback_query->data;
$message = $update->message;
$message_id = $message->message_id;
$text = convert($message->text);
$text1 = $update->message->text;
$date1 = jdate("Y/m/d");
$dated = date("Y/m/d");
$chat_id = $message->chat->id;
$tc = $message->chat->type;
$first_name = $message->from->first_name;
$from_id = $message->from->id;
$username =$message->from->username;

$phone_id = $update->message->contact->user_id;
$contactnum = $update->message->contact->phone_number;
$contact = $message->contact;
$contactid = $contact->user_id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$from_id' LIMIT 1"));
$useran = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$text' LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block$usernamebot` WHERE `id` = '$from_id' LIMIT 1");
$admin = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `admin$usernamebot` WHERE admin = '$from_id' LIMIT 1"));
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'web' LIMIT 1"));

$setting2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'nextmr' LIMIT 1"));
$setting3 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'choed' LIMIT 1"));
$setting4 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'setsupid' LIMIT 1"));
$setting5 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'startcoin' LIMIT 1"));
$setting6 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'membercoin' LIMIT 1"));
$setting7 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'seen' LIMIT 1"));
$setting8 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'like' LIMIT 1"));
$setting9 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'sms' LIMIT 1"));
$setting10 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'join' LIMIT 1"));
$setting11 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'linkmember' LIMIT 1"));
$setting13 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'idacc' LIMIT 1"));
$setting14 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'actcoin' LIMIT 1"));
$setting15 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'suptext' LIMIT 1"));
$setting16 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'coinprice' LIMIT 1"));

$API_K = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getme'));
$botid = $API_K->result->id;
$usernamebot = $API_K->result->username;
$linkmember = $setting11['text'];
$channel =  $setting10['text'];
$channelorder = $setting3['text'];
$channelname = $API_K->result->first_name;
$botname = $API_K->result->first_name;  
$MerchantID = $setting2['text'];
$usernamesup = $setting4['text'];
$webapi = $setting['text'];
$apikey = 'null'; 
$suptext = "🔰 تیم پشتیبانی $usernamebot با افتخار آماده پاسخگویی به شما عزیزان است:
@

⚖️ کاربر گرامی، چنانچه شما از ربات $usernamebot استفاده نمایید به منزله قبول قوانین زیر است:

👈 تنها مرجع رسمی افزایش موجودی ربات، بخش '➕ افزایش موجودی' است.
👈 خرید و فروش موجودی ربات توسط کاربران ممنوعیتی ندارد اما $usernamebot هیچ گونه تعهدی در این رابطه ندارد.
👈 درصورتی که تراکنش مشکوکی مشاهده شود $usernamebot این اختیار را دارد که از کاربر مربوطه مدارک موردنیاز را درخواست کند.
👈 در صورت استفاده نادرست از بخش های زیرمجموعه گیری و ارسال اکانت حساب شخص مسدود خواهد شد.";
$varizi= $setting3['text'];
$websmsi = $setting9['text'];
$idacc = $setting13['text'];
//========================== // variable // ==============================
$pricecoin = $setting16['text'];
$_gift = $setting5['text'];
$_member = $setting6['text'];
$maxorder = '120000';
$_porsant = '300';
$_seen = $setting7['text'];
$_like=$setting8['text'];
$actcoin = $_like;

}
if(isset($update->callback_query)){
$callback_query = $update->callback_query;
$callback_query_id = $callback_query->id;
$data = $callback_query->data;
$fromid = $callback_query->from->id;
$messageid = $callback_query->message->message_id;
$chatid = $callback_query->message->chat->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$fromid' LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block$usernamebot` WHERE `id` = '$fromid' LIMIT 1");
}
if(isset($update->channel_post)){
$channel_post = $update->channel_post;
$channel_post_message_id = $channel_post->message_id;
$channel_post_chat_id = $channel_post->chat->id;
$channel_post_chat_username = $channel_post->chat->username;
$channel_post_chat_type = $channel_post->chat->type;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `channel$usernamebot` WHERE `channel` = '$channel_post_chat_id' LIMIT 1"));
}
if(isset($data)){

$chat_id = $update->callback_query->message->chat->id;
$from_id = $update->callback_query->from->id;
$message_id = $update->callback_query->message->message_id;
}
/*
Author { @Ziazl}
*/
//=========================
$timezone =0;
$now = date("Y-m-d", time()+$timezone);
$time = date("H:i:s", time()+$timezone);
list($year, $month, $day) = explode('-', $now);
list($hour, $minute, $second) = explode(':', $time);
$timestamp = mktime($hour, $minute, $second, $month, $day, $year);
$mrnimaw = jdate(" Y/m/d",$timestamp);
$time11 = date('H:i:s');
$date = jdate("Y/m/d");
$time1 = jdate("H:i:s");
$time = str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],range(0,9),$time1);
$dateji = gregorian_to_jalali(date('Y'), date('m'), date('d'), '/');

function curl($url){
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
return json_decode(curl_exec($ch));
}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
bot('editMessagetext',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>$text,
'parse_mode'=>$parse_mode,
'disable_web_page_preview'=>$disable_web_page_preview,
'reply_markup'=>$keyboard
]);
}
function convert($string) {
$persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
$arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];
$num = range(0, 9);
$convertedPersianNums = str_replace($persian, $num, $string);
$englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
return $englishNumbersOnly;
}
// .


// ,
// ,
//***************Define Data*********
//***                             ***
//***                             ***
//***                             ***
//***                             ***

function listpays($code = NULL){
	$rand = rand(111111,999999);
	$code = $rand;
	$ls = mysqli_num_rows(mysqli_query($connect,"SELECT `code` FROM `pay$usernamebot` WHERE `code` = '$code' LIMIT 1"));
	if($ls == 0){
	    return $code;
    }
}
function isetrow($table,$row){
	global $connect;
	global $usernamebot;
	$sql = "SELECT EXISTS(SELECT * FROM `$table$usernamebot` WHERE `$row`)";
return	$result = mysqli_query($connect,$sql);
	}
	
	function isetroww($table,$row){
	global $connect;
	global $usernamebot;
	$sql = "SELECT EXISTS(SELECT * FROM `$table` WHERE `$row`)";
return	$result = mysqli_query($connect,$sql);
	}
	
function createrow($table,$after,$row,$type){
global $connect;
global $usernamebot;
$sql ="ALTER TABLE `$table$usernamebot` ADD `$row` $type after `$after`";
$result = mysqli_query($connect,$sql);
}
function createroww($table,$after,$row,$type){
global $connect;
$sql ="ALTER TABLE `$table` ADD `$row` $type after `$after`";
$result = mysqli_query($connect,$sql);
}
function isetval($table,$roow,$chatid,$row2){
	global $connect;
	global $usernamebot;
$query = "SELECT * FROM $table$usernamebot WHERE $roow='$chatid' ";
$result = mysqli_query($connect,$query);
while ($row = mysqli_fetch_array($result)) {
if(isset($row[$row2]) && !empty($row[$row2])){
	return true;
	}else{
	ToDie();
	}
}
}
function pay($Amount,$coin){
global $from_id;
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl',['encoding' => 'UTF-8']);
$result = $client->PaymentRequest([
'MerchantID' => '', 
'Amount' => $Amount,
'Description' => "ربات سین سرویس | سکه $coin عدد | قیمت $Amount تومان | کاربر $from_id",
'Email' => 'santricham@gmail.cpm',  
'Mobile' => '09164458031', 
'CallbackURL' => "santrich.ir/sen/back.php?id=".$from_id."&amount=".$Amount."&coin=".$coin]);
if($result->Status == 100){
return "https://www.zarinpal.com/pg/StartPay/".$result->Authority."/ZarinGate";
}
}
function RandomString()
{
    $characters = 'ABCDEFGHIJKLMNOPQ1239019RSTUVWXYZ';
    $order = '';
    for ($i = 0; $i < 9; $i++) {
        $order .= $characters[rand(0, strlen($characters))];
    }
    return $order;
}
$order = RandomString();
if($setting['text'] != null){
$webad = $setting['text'];
}else{
$webad = "وبسرویسی تنطیم نشده است
";
}


$API_P = curl('https://api.telegram.org/bot'.API_KEY.'/getme');
$userbot = "{$API_P->result->username}";

$setting88 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'like' LIMIT 1"));
$liks = $setting88['text'];


$home = json_encode([
'keyboard'=>[
[['text'=>'❤️ افزایش لایک'],['text'=>'👍 ری‌اکشن'],['text'=>'👁 افزایش بازدید']],
[['text'=>'🤖 بازدید کانال'],['text'=>'🔎 پیگیری'],['text'=>'👤 حساب من']],
[['text'=>'💸 انتقال سکه'],['text'=>'➕ افزایش موجودی']],
[['text'=>'🆘 پشتیبانی و قوانین']],
],
  'resize_keyboard'=>true,
]);

$home_Dev = json_encode([
'keyboard'=>[
[['text'=>'❤️ افزایش لایک'],['text'=>'👍 ری‌اکشن'],['text'=>'👁 افزایش بازدید']],
[['text'=>'🤖 بازدید کانال'],['text'=>'🔎 پیگیری'],['text'=>'👤 حساب من']],
[['text'=>'💸 انتقال سکه'],['text'=>'➕ افزایش موجودی']],
[['text'=>'🆘 پشتیبانی و قوانین'],['text'=>'']],
],
  'resize_keyboard'=>true,
]);
$enhome = json_encode([
'keyboard'=>[
[['text'=>'👁 View'],['text'=>'❤️ Like / Vote']],
[['text'=>'👤 My account'],['text'=>'🔍 Tracking'],['text'=>'🤖 Auto-view']],
[['text'=>'💳 Buy coins']],
[['text'=>'🆘 Support'],['text'=>'💸 Transfer'],['text'=>'👥 Referral']],
],
  'resize_keyboard'=>true,
]);
if(($admin['admin'] == $from_id)){
$home = $home_Dev;
}
$back = json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
],
 'resize_keyboard'=>true,
]);
$speed = json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
[['text'=>'سرعت دلخواه'],['text'=>'حداکثر سرعت']],
],
 'resize_keyboard'=>true,
]);
$speed1 = json_encode([
        'keyboard'=>[
		[['text'=>'حداکثر سرعت'],['text'=>'تنظیم سرعت']],
		[['text'=>'سریع'],['text'=>'متوسط'],['text'=>'آهسته']],
		[['text'=>'🔙 بازگشت']],
		],
         'resize_keyboard'=>true,
       		]);
$speedlike = json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
[['text'=>'حداکثر سرعت']],
],
 'resize_keyboard'=>true,
]);
$payg= json_encode([
'keyboard'=>[
[['text'=>'👁 بازدید'],['text'=>'❤لایک']],
[['text'=>'🛒خرید'],['text'=>'👍🏻 ری‌اکشن']],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
]);


$start = "سلام، به $botname خوش آمدید ✋

با $botname همراه شماییم تا به راحتی بازدید، لایک و رای پستهای تلگرامی شما را افزایش دهیم.


برای ادامه کار یک بخش را انتخاب کنید:";
$gift = "🎊 با تشکر از عضویت شما ، $_gift سکه موجودی به صورت هدیه به حسابتان افزوده شد .";
// .

// https://t.me/
// ,
//,
if(!isetrow("setting","startext")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('startext' ,'$start')";
mysqli_query($connect,$sql);
}
if(!isetrow("setting","coinprice")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('coinprice' ,'800')";
mysqli_query($connect,$sql);
}

if(!isetrow("setting","idacc")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('idacc' ,'username')";
mysqli_query($connect,$sql);
}
if(!isetrow("setting","onlike")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('onlike' ,'on')";
mysqli_query($connect,$sql);
}
if(!isetrow("setting","onseen")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('onseen' ,'on')";
mysqli_query($connect,$sql);
}
if(!isetrow("setting","onact")){
	$sql = "INSERT INTO `setting$usernamebot` (`setting`, `text`) VALUES('onact' ,'on')";
mysqli_query($connect,$sql);
}
/*
	if(!isetrow("data","txtblock")){
	createrow("data","txtback","txtblock","TEXT");
	}
	if(!isetrow("data","nameback")){
	createrow("data","zirmajcoin","nameback","TEXT");
	}
	if(!isetrow("dok","lockday")){
	createrow("dok","lockcoin","lockday","TEXT");
	}
	if(!isetrow("dok","locksade")){
	createrow("dok","lockcoin","locksade","TEXT");
	}
	if(!isetrow("dok","lockemtiaz2")){
	createrow("dok","lockcoin","lockemtiaz2","TEXT");
	}
	if(!isetrow("dok","keyback")){
	createrow("dok","lockday","keyback","TEXT");
	}
	if(!isetrow("dok","textemtiaz1")){
	createrow("dok","keyback","textemtiaz1","TEXT");
	}
	if(!isetrow("dok","textemtiaz2")){
	createrow("dok","textemtiaz1","textemtiaz2","TEXT");
	}
	if(!isetrow("dok","textemtiaz3")){
	createrow("dok","textemtiaz2","textemtiaz3","TEXT");
	}
	if(!isetrow("dok","textemtiaz4")){
	createrow("dok","textemtiaz3","textemtiaz4","TEXT");
	}
	if(!isetrow("dok","channel")){
	createrow("dok","textemtiaz4","channel","TEXT");
	}
	if(!isetrow("dok","textchannel")){
	createrow("dok","textemtiaz4","textchannel","TEXT");
	}
	if(!isetrow("dok","hidden")){
	createrow("dok","textchannel","hidden","TEXT");
	}
	if(!isetrow("dok","lockcode")){
	createrow("dok","hidden","lockcode","TEXT");
	}
	if(!isetrow("dok","textemtiaz5")){
	createrow("dok","textemtiaz4","textemtiaz5","TEXT");
	}
	if(!isetrow("dok","textemtiaz6")){
	createrow("dok","textemtiaz5","textemtiaz6","TEXT");
	}
	if(!isetrow("dok","mohtava")){
	createrow("dok","lockcode","mohtava","TEXT");
	}
	if(!isetrow("dok","emza")){
	createrow("dok","mohtava","emza","TEXT");
	}
	if(!isetrow("dok","emzatext")){
	createrow("dok","emza","emzatext","TEXT");
	}
	if(!isetrow("user","coding")){
	createrow("user","code","coding","INT");
	}
	if(!isetrow("user","ref")){
	createrow("user","code","ref","TEXT");
	}
	if(!isetrow("user","dayl")){
	createrow("user","coding","dayl","TEXT");
	}
	if(!isetrow("user","phone")){
	createrow("user","dayl","phone","TEXT");
	}
	if(!isetrow("data","forwardstart")){
	createrow("data","nameback","forwardstart","TEXT");
	}
	if(!isetrow("user","Other")){
	createrow("user","dayl","Other","TEXT");
	}
	if(!isetrow("user","Other4")){
	createrow("user","dayl","Other4","TEXT");
	}
	if(!isetrow("user","captha")){
	createrow("user","dayl","captha","TEXT");
	}
	if(!isetrow("user","Other5")){
	createrow("user","Other4","Other5","TEXT");
	}
	if(!isetrow("user","Other6")){
	createrow("user","Other5","Other6","TEXT");
	}
	if(!isetrow("user","dice")){
	createrow("user","Other6","dice","TEXT");
	}
	if(!isetrow("user","emdice")){
	createrow("user","Other6","emdice","TEXT");
	}
	if(!isetrow("dok","textlock2")){
	createrow("dok","lockcode","textlock2","TEXT");
	}
	if(!isetrow("dok","locknafar")){
	createrow("dok","textlock2","locknafar","TEXT");
	}
	if(!isetrow("dok","numnafar")){
	createrow("dok","locknafar","numnafar","TEXT");
	}
	if(!isetrow("dok","finishnafar")){
	createrow("dok","locknafar","finishnafar","TEXT");
	}
	if(!isetrow("dok","autodel")){
	createrow("dok","finishnafar","autodel","TEXT");
	}
	if(!isetrow("dok","timeautodel")){
	createrow("dok","finishnafar","timeautodel","TEXT");
	}
	if(!isetrow("dok","qoflforward")){
	createrow("dok","timeautodel","qoflforward","TEXT");
	}
	if(!isetrow("dok","qoflforwardtext")){
	createrow("dok","qoflforward","qoflforwardtext","TEXT");
	}
	if(!isetrow("data","forwardid")){
	createrow("data","forwardstart","forwardid","TEXT");
	}
	if(!isetrow("data","typing")){
	createrow("data","forwardstart","typing","TEXT");
	}
	if(!isetrow("data","webview")){
	createrow("data","typing","webview","TEXT");
	}
	if(!isetrow("data","replymessage")){
	createrow("data","webview","replymessage","TEXT");
	}
	if(!isetrow("data","lockphone")){
	createrow("data","replymessage","lockphone","TEXT");
	}
	if(!isetrow("data","phoneiran")){
	createrow("data","lockphone","phoneiran","TEXT");
	}
	if(!isetrow("data","textphiran")){
	createrow("data","phoneiran","textphiran","TEXT");
	}
	if(!isetrow("data","textphone1")){
	createrow("data","lockphone","textphone1","TEXT");
	}
Author { @Ziazl}
	if(!isetrow("data","textphone2")){
	createrow("data","textphone1","textphone2","TEXT");
	}
	if(!isetrow("data","dokphone")){
	createrow("data","textphone1","dokphone","TEXT");
	}
	if(!isetrow("data","filter")){
	createrow("data","textphone2","filter","TEXT");
	}
	if(!isetrow("data","autodel")){
	createrow("data","filter","autodel","TEXT");
	}
	if(!isetrow("data","leavegroup")){
	createrow("data","forwardid","leavegroup","TEXT");
	}
	if(!isetrow("data","textleft")){
	createrow("data","leavegroup","textleft","TEXT");
	}
	if(!isetrow("data","autoanswer")){
	createrow("data","textleft","autoanswer","TEXT");
	}
	
	if(!isetrow("data","coinstart")){
	createrow("data","zirmajcoin","coinstart","TEXT");
	}
	if(!isetrow("data","tedadcoin")){
	createrow("data","coinstart","tedadcoin","INT");
	}
	if(!isetrow("data","pmnewcoin")){
	createrow("data","coinstart","pmnewcoin","TEXT");
	}
	if(!isetrow("data","newcoin")){
	createrow("data","coinstart","newcoin","TEXT");
	}
	if(!isetrow("data","resize")){
	createrow("data","tedadcoin","resize","TEXT");
	}
	if(!isetrow("data","captha")){
	createrow("data","resize","captha","TEXT");
	}
	if(!isetrow("data","textcaptha1")){
	createrow("data","captha","textcaptha1","TEXT");
	}
	if(!isetrow("data","textcaptha2")){
	createrow("data","textcaptha1","textcaptha2","TEXT");
	}if(!isetrow("data","capstyle")){
	createrow("data","textcaptha2","capstyle","TEXT");
	}
	if(!isetrow("data","lockrobot")){
	createrow("data","textcaptha2","lockrobot","TEXT");
	}
	if(!isetrow("data","spam")){
	createrow("data","lockrobot","spam","TEXT");
	}
	if(!isetrow("data","spamsecond")){
	createrow("data","spam","spamsecond","INT");
	}
	if(!isetrow("data","spamtedad")){
	createrow("data","spamsecond","spamtedad","INT");
	}
	if(!isetrow("data","spamban")){
	createrow("data","spamtedad","spamban","INT");
	}
	if(!isetrow("data","spamtext")){
	createrow("data","spamban","spamtext","TEXT");
	}
	if(!isetrow("data","pmresanall")){
	createrow("data","spamtext","pmresanall","TEXT");
	}
	if(!isetrow("data","pmresantext")){
	createrow("data","pmresanall","pmresantext","TEXT");
	}
	if(!isetrow("data","replacetext")){
	createrow("data","pmresantext","replacetext","TEXT");
	}
	if(!isetrow("data","opencodetext")){
	createrow("data","replacetext","opencodetext","TEXT");
	}
	if(!isetrow("data","barmoh")){
	createrow("data","opencodetext","barmoh","TEXT");
	}
    if(!isetrow("data","textbarmoh")){
	createrow("data","barmoh","textbarmoh","TEXT");
	}
	if(!isetrow("data","sendlog")){
	createrow("data","barmoh","sendlog","TEXT");
	}
	if(!isetrow("data","logchannel")){
	createrow("data","sendlog","logchannel","TEXT");
	}
if(!isetrow("data","notoflike")){
	createrow("data","logchannel","notoflike","TEXT");
	}
if(!isetrow("data","notofliketext")){
	createrow("data","notoflike","notofliketext","TEXT");
	}
	if(!isetrow("data","notofdisliketext")){
	createrow("data","notofliketext","notofdisliketext","TEXT");
	}
	if(!isetrow("admin","adddokme")){
	createrow("admin","chatid","adddokme","TEXT");
	}
	if(!isetrow("admin","editdokme")){
	createrow("admin","adddokme","editdokme","TEXT");
	}
	if(!isetrow("admin","amarbot")){
	createrow("admin","editdokme","amarbot","TEXT");
	}
	if(!isetrow("admin","resetbot")){
	createrow("admin","amarbot","resetbot","TEXT");
	}
	if(!isetrow("admin","addadmin")){
	createrow("admin","resetbot","addadmin","TEXT");
	}
	if(!isetrow("admin","pasokh")){
	createrow("admin","addadmin","pasokh","TEXT");
	}
	if(!isetrow("admin","editmatn")){
	createrow("admin","pasokh","editmatn","TEXT");
	}
	if(!isetrow("admin","ersal")){
	createrow("admin","editmatn","ersal","TEXT");
	}
	if(!isetrow("admin","group")){
	createrow("admin","ersal","group","TEXT");
	}
	if(!isetrow("admin","sayersetting")){
	createrow("admin","group","sayersetting","TEXT");
	}
	if(!isetrow("moh","textget")){
	createrow("moh","link","textget","TEXT");
	}
	if(!isetrow("moh","textesh")){
	createrow("moh","textget","textesh","TEXT");
	}
	if(!isetrow("moh","audio")){
	createrow("moh","textesh","textget","TEXT");
	}
	if(!isetrow("moh","english")){
	createrow("moh","textesh","english","TEXT");
	}
	if(!isetrow("channel","other3")){
	createrow("channel","Other","other3","TEXT");
	}
	if(!isetrow("channel","other3")){
	createrow("channel","other3","other4","TEXT");
	}
	if(!isetrow("user","spam1")){
	createrow("user","dice","spam1","TEXT");
	}
	if(!isetrow("user","spam2")){
	createrow("user","spam1","spam2","TEXT");
	}
	if(!isetrow("user","stoptime")){
	createrow("user","spam2","stoptime","TEXT");
	}
	if(!isetrow("user","under")){
	createrow("user","stoptime","under","TEXT");
	}
	if(!isetrow("user","vindor")){
	createrow("user","under","vindor","TEXT");
	}
	if(!isetrow("user","phone2")){
	createrow("user","vindor","phone2","TEXT");
	}
	}
	//--------بخــــــــــش دوم دیتابیــــــــــس---------\\
	if(empty(getvalue("data","id",2,"id"))){
	$sql = "INSERT INTO `data$usernamebot`
(
`id`
) VALUES('2')";
mysqli_query($connect,$sql);
}
	if(!isetrow("dok","amardok")){
	createrow("dok","emzatext","amardok","TEXT");
	}
	$backname = getvalue("data","id",1,"nameback");
if($type=="private"){
	if(!isetrow("user","coding")){
		createrow("user","emtiaz","coding","INT");
		}
	if(empty(getvalue("user","chatid",$chatid,"chatid"))){
		if(empty(getvalue("dayamar","day",date("d"),"day"))){
			$sql ="INSERT INTO `dayamar$usernamebot`(`day`,`amar`) VALUES ('".date("d")."','1')";
		mysqli_query($connect,$sql);
			}else{
				$amar = getvalue("dayamar","day",date("d"),"amar");
		$newamar=$amar+1;
		setvalue("dayamar","day",date("d"),"amar",$newamar);
				}
		}
		if(empty(getvalue("data","id",1,"tedadcoin"))){
			$em=0;
			}else{
				$em = getvalue("data","id",1,"tedadcoin");
				}
			$firstname = str_replace("<","",$firstname);
			$firstname = str_replace(">","",$firstname);
			$firstname = str_replace("'","",$firstname);
			$firstname = str_replace('"',"",$firstname);
$insert_query = "INSERT INTO `user$usernamebot`
(
chatid,
userid,
firstname,
lastname,
username,
joindatesh,
joindatem,
jointime,
zirmaj,
emtiaz,
`coding`
)
VALUES ('$chatid','$fromid','$firstname','$lastname','$username','$datesh','$datem','$time','0','$em','1')";
mysqli_query($connect, $insert_query);*/
$timenowe = date("Y/m/d");
$expire = file_get_contents("exp.txt");
$f =date("Y/m/d" ,strtotime($expire));
if ($timenowe > $f){
return bot('sendmessage',[
'chat_id'=>$admin1,
'text'=>"اشتراک ربات شما به پایان رسیده است جهت تمدید آن اقدام کنید! \n@CleverSeenApiBot",
    ]);
}

if (mysqli_num_rows($block) > 0) exit();
if (file_exists('bot') and !in_array($from_id, $admin))  
return bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"☑️ کاربر گرامی ربات $botname جهت اپدیت خاموش شده است ، لطفا چند دقیقه بعد تلاش کنید.
• @$channel",
]);
// .


// ,
// ,

elseif(preg_match('/^(\/start) (.*)/',$text , $prameter) and $user['id'] != true and strpos($text,"$from_id") == false and is_numeric($prameter[2]) and strpos($text,"-") == false){
$connect->query("INSERT INTO `user$usernamebot` (`id` , `coin` , `inviter` , `daystart`) VALUES ('$from_id','$_gift','$prameter[2]' , '$date')");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$start,
'reply_to_message_id'=>$message_id,
'reply_markup'=>$lan
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$gift,
]);
$name = str_replace(['`','*','_','[',']','(',')'],null,$first_name);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$prameter[2]' LIMIT 1"));
$member = $user['member'] + 1;
$coin = $user['coin'] + $_member;
bot('sendmessage',[
'chat_id'=>$prameter[2],
'text'=>"🎉 تبریک، $_member سکه بابت زیرمجموعه جدید به حسابتان افزوده شد.

Congratulations, $_member coins have been added to your account for the new subscription.",
'parse_mode'=>'Markdown',
  ]);
  if ($from_id == $prameter[2]){
  $coin = $_member;}
  bot('sendmessage', ['chat_id' => "$admin1", 'text' => "#زیرمجموعه جدید

کاربر استارت کننده: [$from_id](tg://user?id=$from_id)
کاربر دعوت کننده : [$from_id]($prameter[2])
موجودی جدید دعوت کننده : $coin
درصورتی که کاربر هر دو آیدی باهم مساوی باشند کاربر جدید هست ",
'parse_mode'=>'Markdown',

]);
$connect->query("UPDATE `user$usernamebot` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$prameter[2]' LIMIT 1");
}
// .


// ,
// ,
elseif($text == 'انصراف'){
    $sql = "ALTER TABLE setting$usernamebot CHANGE setting setting VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL;";
		mysqli_query($connect,$sql);
$sql = "ALTER TABLE setting$usernamebot CHANGE text text TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL;";
		mysqli_query($connect,$sql);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید:

",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none',`com` = '' WHERE `id` = '$from_id' LIMIT 1");
}

// .
elseif ($text == 'بخش لایک روشن'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ روشن شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'on' WHERE setting = 'onlike' LIMIT 1");
}
elseif ($text == 'بخش لایک خاموش'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ خاموش شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'off' WHERE setting = 'onlike' LIMIT 1");
}
elseif ($text == 'بخش سین روشن'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ روشن شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'on' WHERE setting = 'onseen' LIMIT 1");
}
elseif ($text == 'بخش سین خاموش'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ خاموش شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'off' WHERE setting = 'onseen' LIMIT 1");
}
elseif ($text == 'بخش ری اکشن روشن'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ روشن شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'on' WHERE setting = 'onact' LIMIT 1");
}
elseif ($text == 'بخش ری اکشن خاموش'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ خاموش شد",
]);
$connect->query("UPDATE setting$usernamebot SET text = 'off' WHERE setting = 'onact' LIMIT 1");
}
// ,
// ,
elseif ($text == '😃 ربات روشن'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ ربات روشن شد",
]);
unlink('bot');  
$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
//====================================
elseif ($text == '😴 ربات خاموش'  and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"😴 ربات خاموش شد",
]);
touch('bot');    
$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
//=====================================================
elseif($text == '/help'){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 تعرفه هر 1000 سکه بر اساس مجموع خریدهای قبلی شما طبق تعرفه های زیر محاسبه خواهد شد.

• بین 0 الی 10 هزار تومان: $pricecoin تومان
• بین 10 الی 50 هزار تومان: 700 تومان
• بین 50 الی 100 هزار تومان: 600 تومان
• بین 100 الی 200 هزار تومان: 500 تومان
• بیش از 200 هزار تومان: 400 تومان",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$message_id,
]);
}
// .


// ,
// ,
elseif ($user['step'] == 'seenpost'){
if($message->audio != true){
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
if($message->forward_from_chat == true){
$id = bot('ForwardMessage',[
'chat_id'=>"@$channelorder",
'from_chat_id'=>$from_id,
'message_id'=>$message_id,
])->result->message_id;
$link = "https://t.me/$channelorder/$id";
}else{
$exlink = explode('/', $text);
$channelorder = $exlink[count($exlink) - 2];
$id = end($exlink);
$link = "https://t.me/$channelorder/$id";
}
$explode = explode('^',$user['data']);
$result = curl("$webad&type=view&count=$explode[0]&speed=0&period=0&channel=$channelorder&id=$id");
    $file = fopen("data2channel.txt", "a") or die("Unable to open file!");

    fwrite($file, "\n $webad&type=view&count=$explode[0]&speed=0&period=0&channel=$channelorder&id=$id");

if($result->result== 'ok'){
$amount = $explode[0] * $_seen;
$connect->query("UPDATE `user$usernamebot` SET `coin` = `coin` - $amount WHERE `id` = '$from_id' LIMIT 1");  
$order = "{$result->order}";
$seensta= "{$result->seenstart}";
$seebse= "{$result->seenend}";
$senpa= "$seensta + $seebse";
$startorder = ($explode[1] == 0)?'فوری':"بعد از $explode[1] دقیقه";
$speed = ($explode[2] == 0)?'حداکثر سرعت':"هر $explode[2] دقیقه $explode[3] بازدید";
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"☑️ سفارش شما با شماره پیگیری $order ثبت شد.

تعداد درخواست:$explode[0] بازدید
بازدید کنونی: {$result->seenstart} بازدید
شروع سفارش: فوری
سرعت تکمیل: $speed 
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
bot('sendmessage',[
'chat_id'=>"@$channelorder",
'text'=>"
 $order

speed  : $speed
start order: $startorder

price order: $amount سکه
seen count: $explode[0]

start: {$result->seenstart}
end:{$result->seenend}

 $link

ایدی فرد:$chat_id
مقدار مانده شارژ حساب فرد: {$user['coin']}

",
'disable_web_page_preview' => true,
]);
$connect->query("INSERT INTO `orderseen$usernamebot` (`key` , `id` , `amount` , `speed` ,`view` , `link` , `time`) VALUES ('$order' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , 'in".date('H:i:s')."')");
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ پست ارسال شده معتبر نیست، توجه نمایید که در این بخش شما میتوانید پست را به دو صورت ارسال نمایید:
$link
1️⃣ پست خود را به صورت فوروارد شده از یک کانال ارسال کنید.
2️⃣ لینک پستهای خود را ارسال کنید. (در هر سطر یک لینک و نباید فوروارد شده باشند)",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenpost' WHERE `id` = '$from_id' LIMIT 1");
}
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⚠️ پست ارسال شده معتبر نیست، توجه نمایید که در این بخش شما میتوانید پست را به دو صورت ارسال نمایید:
$link
1️⃣ پست خود را به صورت فوروارد شده از یک کانال ارسال کنید.
2️⃣ لینک پستهای خود را ارسال کنید. (در هر سطر یک لینک و نباید فوروارد شده باشند)',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
} 
// .


// ,
// ,
elseif(bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$from_id])->result->status == 'left'){
 bot('sendmessage',[
'chat_id'=>$chat_id,
"text"=>"⚠️ کاربر گرامی، برای اطلاع از آخرین بروزرسانی ها، اطلاعیه ها و قوانین نیاز است در کانال رسمی $botname به نشانی زیر عضو شوید:
@$channel",
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[['text'=>"🔗 کانال رسمی $botname",'url'=>"https://t.me/$channel"]],
	[['text'=>'✅ تایید عضویت','callback_data'=>'join']],
              ]
              ])
	       ]);	

if($user['id'] != true) {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$gift,
]);
$connect->query("INSERT INTO `user$usernamebot` (`id` , `coin` , `daystart`) VALUES ('$from_id' , '$_gift', '$date')");
}
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
// .
/*
Author { @Ziazl}
*/

// ,
// ,
elseif($text == '👁 افزایش بازدید'){
    $setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'onseen' LIMIT 1"));

if ( $setting['text'] == 'on'){
if($user['coin'] >= 10){
$max = floor($user['coin'] / $_seen);
$bazdid = $_seen * 1000;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👁‍🗨 تعداد بازدید دلخواه خود را بین 100 الی $maxorder (120k) ارسال کنید.
موجودی شما: {$user['coin']} سکه",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenamount' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
]);
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این بخش خاموش میباشد ❌.",
'reply_to_message_id'=>$message_id,
]);
}
}
//======================== order like =====================//
elseif($text == '❤️ افزایش لایک'){
        $setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'onlike' LIMIT 1"));

if ( $setting['text'] == 'on'){
if($user['coin'] >= 10){
$max = floor($user['coin'] / $_like);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❤️ تعداد لایک/رای دلخواه خود را بین 1 الی $maxorder ارسال کنید.
موجودی شما: {$user['coin']} سکه

* هزینه هر لایک معادل  $_like سکه است.
* پست لایک و رایی که نیاز به جوین شدن در کانال داشته باشد توسط ربات قابل انجام نیست و در صورت سفارش برای این موارد سکه مصرفی هدر خواهد رفت.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'likeamount' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
]);
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این بخش خاموش میباشد ❌.",
'reply_to_message_id'=>$message_id,
]);
}
}
elseif($text == '👍 ری‌اکشن'){
            $setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'onact' LIMIT 1"));
    if ($setting['text']=='on'){
if($user['coin'] >= 10){
$max = floor($user['coin'] / $_like);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 تعداد ری‌اکشن دلخواه خود را بین 1 الی $maxorder ارسال کنید.
موجودی شما: {$user['coin']} سکه

* هزینه هر ری‌اکشن معادل $actcoin سکه است.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'ramount' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
]);
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"این بخش خاموش میباشد ❌.",
'reply_to_message_id'=>$message_id,
]);
}
}

// .


// ,
// ,
elseif($text == '🤖 بازدید کانال'){

$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel$usernamebot` WHERE `id` = '$from_id'"));
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🤖 با استفاده از این بخش میتوانید ربات را به گونه ای تنظیم نمایید تا به محض انتشار پست جدید در کانال، فرایند افزایش بازدید آن به طور خودکار شروع شود.

▪️تعداد کانال های ثبت شده : $orderchannel

برای شروع '📢 ثبت کانال جدید' را انتخاب کنید.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'📢 ثبت کانال جدید'],['text'=>'📢 کانال های ثبت شده']],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
]),
]);
}
// .


// ,
// ,
elseif($text == '📢 کانال های ثبت شده'){

$order = mysqli_query($connect,"SELECT * from `channel$usernamebot` WHERE `id` = '$from_id'");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$explode = explode('^',$row['speed']);
$start = ($explode[0] == 0)?'فوری':"بعد از $explode[0] دقیقه";
$speed = ($explode[1] == 0)?'حداکثر سرعت':"هر $explode[1] دقیقه $explode[2] بازدید";
$title = bot('getchat',['chat_id'=>$row['channel']])->result->title;
$result = $result."✅ نام کانال : $title\n👁‍🗨 تعداد بازدید خودکار : {$row['view']}\n⏱ زمان شروع سفارش : $start\n⚡️ سرعت انجام سفارش : $speed\n❌ برای حذف کانال /del_".abs($row['channel'])."\n━ ━ ━\n";
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👇🏻 لیست کانالهای ثبت شده توسط شما
❗️ توجه داشته باشید جزئیات سفارشات ثبت شده در پیگیری سفارشات در دسترس است

$result",
'reply_to_message_id'=>$message_id,
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ شما تا کنون کانالی را جهت بازدید خودکار ثبت نکرده اید
👈🏻 برای شروع کافیست از دکمه "📢 ثبت کانال جدید" استفاده نمایید و مراحل را ادامه دهید .',
'reply_to_message_id'=>$message_id,
]);
}
// .


// ,
// ,
elseif($text == '📢 ثبت کانال جدید'){

if($user['coin'] >= 10){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ برای شروع بازدید خودکار ، لطفا ربات @$usernamebot را در کانال ادمین کرده و سپس یک پست از کانال را به ربات فوروارد نمایید
 
❗️ چرا باید ادمین کنید؟ ربات تنها میتواند در صورتی سفارش خودکار رو انجام دهد که در کانال ادمین باشد .",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'setchannel' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش نیاز به حداقل 10 سکه موجودی دارید .
💰 موجودی حساب شما : {$user['coin']} سکه",
'reply_to_message_id'=>$message_id,
]);
}
elseif(preg_match('/^\/del_(.*)/', $text , $match)){
if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `channel$usernamebot` WHERE `id` = '$from_id' AND `channel` = '-$match[1]' LIMIT 1")) == true){
$title = bot('getchat',['chat_id'=>-$match[1]])->result->title;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"☑️ کاناله $title با موفقیت از لیست بازدید خودکار حذف شد .",
'reply_to_message_id'=>$message_id,
]);
$connect->query("DELETE from `channel$usernamebot` WHERE `channel` = '-$match[1]' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❌ خطا ، کانال در لیست بازدید های خودکار وجود ندارد',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home,
]);
}
//========================== // order list // ==============================

// .


// ,
// ,
elseif($text == '🔎 پیگیری'){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
برای ادامه کار یک بخش را انتخاب کنید:

",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$payg
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none',`com` = '' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '👁 بازدید'){
$order = mysqli_query($connect,"SELECT * FROM `orderseen$usernamebot` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 5");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 0)?'تکمیل شده':'تکمیل شده !';
$result ="🆔 شناسه سفارش 👈🏻 {$row['key']}\n⚡️ سرعت تکمیل : {$row['speed']}\n⏱ زمان : {$row['time']}\n💰 هزینه سفارش : {$row['amount']} تومان\n👁‍🗨 تعداد بازدید درخواستی : {$row['view']}\n✅ وضعیت : $stats\n━ ━ ━\n";
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$result",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پنج سفارش اخیر شما👆",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}else
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text' => "شما تاکنون سفارش ثبت نکرده اید درصورت مشکل با پشتیبانی درارتباط باشید 📝",
 
]);
}

elseif($text == '❤لایک'){
$order = mysqli_query($connect,"SELECT * FROM `orderlike$usernamebot` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 5");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 0)?'تکمیل شده':'تکمیل شده !';
$result ="🔍 کد پیگیری سفارش : {$row['key']}\n🚀 سرعت تکمیل سفارش : {$row['speed']}\n⏱ زمان :   {$row['time']}\n💰هزینه سفارش : {$row['amount']} تومان\n❤️تعداد لایک : {$row['like']}\n✅ وضعیت سفازش : $stats";
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$result",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پنج سفارش اخیر شما👆",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}else
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text' => "شما تاکنون سفارش ثبت نکرده اید درصورت مشکل با پشتیبانی درارتباط باشید 📝",
 
]);
}

##
#
#
#
#
elseif($text == '👍🏻 ری‌اکشن'){
$order = mysqli_query($connect,"SELECT * FROM `actorder$usernamebot` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 5");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 0)?'تکمیل شده':'تکمیل شده !';
$result ="🔍 کد پیگیری سفارش : {$row['key']}\n🚀 سرعت تکمیل سفارش : {$row['speed']}\n⏱ زمان : {$row['time']}\n💰هزینه سفارش : {$row['amount']} تومان\n❤️تعداد ری اکشن : {$row['act']}\n✅ وضعیت سفازش : $stats";
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$result",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پنج سفارش اخیر شما👆",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}else
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text' => "شما تاکنون سفارش ثبت نکرده اید درصورت مشکل با پشتیبانی درارتباط باشید 📝",
 
]);
}
elseif($text == '🛒خرید'){
$order = mysqli_query($connect,"SELECT * FROM `buy$usernamebot` WHERE `id` = '$from_id' ORDER BY `id` DESC LIMIT 5");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$result ="✅تراکنش موفق
🏦 درگاه :
$usernamebot
💰 مبلغ :
{$row['amount']} تومان
🕒 زمان :
{$row['time']}";
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$result",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"پنج خرید اخیر شما👆",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
}else
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text' => "شما تاکنون خریدی  ثبت نکرده اید درصورت مشکل با پشتیبانی درارتباط باشید 📝",
 
]);
}


/*$q = mysqli_query($connect,"select * from user order by user.member asc limit 5");
while($r = mysqli_fetch_assoc($q)){
$list .= $r['member']."\n";
}
$qu = mysqli_query($connect,"select * from user order by user.member asc limit 10");
while($ru = mysqli_fetch_assoc($qu)){
$lit .= "[click](tg://user?id=".$ru['member'].") \n";
}*/
elseif($text == '➕ افزایش موجودی'){

$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy$usernamebot` WHERE `id` = '$from_id'"));
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"یک بخش را جهت افزایش موجودی انتخاب کنید:",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👥 زیرمجموعه'],['text'=>'📱ارسال اکانت'],['text'=>'💵 خرید']],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);
}

//=====================mamad=================================

elseif($text == '💵 خرید'){
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy$usernamebot` WHERE `id` = '$from_id'"));
    if($user['phone'] !==null){
$bazdid = $_seen * 1000;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❓تعداد #سکه موردنظر خود را وارد نمایید. (هر 1000 سکه $pricecoin تومان)

مجموع خرید شما: $allbuy تومان
نحوه محاسبه تعرفه: /help",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'pay' WHERE `id` = '$from_id' LIMIT 1");
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا شماره همراه خود را با استفاده از دکمه '🔒 تایید و ارسال شماره' ارسال نمایید.

📌 برای جلوگیری از سواستفاده برخی افراد نیاز است شماره خود را ارسال و تایید نمایید. شماره همراه شما در جایی استفاده نخواهد شد و اینکار تنها برای احراز هویت شماست.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🔒 تایید و ارسال شماره','request_contact'=>true]],
[['text'=>'انصراف']],

],
'resize_keyboard'=>true,
])
]);
}
}

elseif($chat_id==$phone_id and $update->message->contact->phone_number){
if(substr($contactnum,0,-10) == "98"){
$code=rand(10000,100000);
$munme=substr($contactnum,-10);
//======
/*file_get_contents("https://api.codebazan.ir/sms/api.php?type=sms&apikey=$smsky&code=$code&phone=0$munme");
*/

// file_get_contents("https://cleverseen.ir/sms/api/v1/sendsms?type=send&&".$websmsi."&&phone=0$munme&&value=$code");
    $apisms = "T9fCwbB5E4KLR3q8";
    file_get_contents("https://api.codebazan.ir/sms/api.php?type=sms&apikey=$apisms&code=$code&phone=0$munme");
//========
bot('sendmessage',[
'chat_id'=>$chat_id,
 'text'=>"کد تکمیل عضویت تا دقایقی دیگر به شماره همراه شما پیامک میشود و تا 30 دقیقه اعتبار دارد.

👈 لطفا کد دریافتی را وارد نمایید:",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = '$code',`com` = '0$munme' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
'chat_id'=>-$admin1,
 'text'=>"شماره جدید برای پرداخت 
 #u$from_id
 شماره : 0$munme
 کد برای پرداخت دستی: $code",
]);
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
 'text'=>"✅ تنها شما با شماره ایران میتوانند حساب خود را تایید کنید ، لطفا با اکانت حقیقی خود با شماره ایران اقدام به استفاده از ربات و شارژ حساب کنید.

📞 شماره شما : $contactnum",
]);
}
}

//================
elseif(strpos($user['com'],'09')!==false){
if ($text==$user['step']) {
$connect->query("UPDATE `user$usernamebot` SET `phone` = '{$user['com']}' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chat_id,
 'text'=>"✅ تبریک، عضویت شما با موفقیت تکمیل شد و میتوانید از تمامی امکانات ربات استفاده نمایید.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👥 زیرمجموعه'],['text'=>'📱ارسال اکانت'],['text'=>'💵 خرید']],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);

$connect->query("UPDATE `user$usernamebot` SET `step` = 'none',`com` = '' WHERE `id` = '$from_id' LIMIT 1");

}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
 'text'=>"⚠️ کد ارسالی اشتباه است، مجددا تلاش نمایید.",
]);
}
}
//================

// .''$code


// ,
// ,
elseif($text == '👥 زیرمجموعه'){

$dd=$_seen*1000;
$id = bot('sendphoto',[
'chat_id'=>$chat_id,
'photo' =>$linkmember,
'caption'=>"✅ ربات $botname:

👁‍🗨 افزایش تخصصی بازدید پستهای تلگرامی
❤️ افزایش لایک پستهای تلگرامی
📈 افزایش رای در نظرسنجی ها
📟 زمانبندی تکمیل سفارشها به دلخواه
👥 زیرمجموعه گیری و دریافت پورسانت
🔐 پرداخت مطمئن و امن

🔗 t.me/$usernamebot?start=$from_id",
])->result->message_id;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"با ارسال بنر بالا به مخاطبین و دوستان خود به ازای هر نفری که برای اولین بار با لینک شما عضو $botname شود $_member سکه دریافت خواهید کرد.

UserID: `$from_id`",
'reply_to_message_id'=>$id,
'parse_mode'=>'MarkDown'
]);
}

//========================== // key // ==============================
elseif($text == '👤 حساب من'){
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy$usernamebot` WHERE `id` = '$from_id'"));
$orderseen = mysqli_num_rows(mysqli_query($connect,"select `id` FROM `orderseen$usernamebot` WHERE `id` = '$from_id'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike$usernamebot` WHERE `id` = '$from_id'"));
$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel$usernamebot` WHERE `id` = '$from_id'"));
$bazdid = $_seen * 1000;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'  درحال بارگذاری...'
 ]);
sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>"👤 شناسه کاربری:  `$from_id`
👈 تاریخ عضویت: {$user['daystart']}
👈 تعداد زیرمجموعه: {$user['member']} نفر

💳 مجموع خرید شما: $allbuy  تومان
🌟 سطح کاربری: ⭐️
💰 موجودی: {$user['coin']}

⏱ این گزارش وضعیت در تاریخ $dateji ساعت $time گرفته شده است.
",
'parse_mode'=>"Markdown",  
 ]);
}
elseif($text == '🆘 پشتیبانی و قوانین'){
    $suptext = "🔰 تیم پشتیبانی $botname با افتخار آماده پاسخگویی به شما عزیزان است:
$usernamesup

⚖️ کاربر گرامی، چنانچه شما از ربات $botname استفاده نمایید به منزله قبول قوانین زیر است:

👈 تنها مرجع رسمی افزایش موجودی ربات، بخش '➕ افزایش موجودی' است.
👈 خرید و فروش موجودی ربات توسط کاربران ممنوعیتی ندارد اما $botname هیچ گونه تعهدی در این رابطه ندارد.
👈 درصورتی که تراکنش مشکوکی مشاهده شود $botname این اختیار را دارد که از کاربر مربوطه مدارک موردنیاز را درخواست کند.
👈 در صورت استفاده نادرست از بخش های زیرمجموعه گیری و ارسال اکانت حساب شخص مسدود خواهد شد.";
$tx = $suptext;
$ch1= str_replace("FIRSTNAME",$first_name,$tx);
			$ch2 = str_replace("USERNAME",$username,$ch1);
			$ch3 = str_replace("USERID",$from_id,$ch2);
			$ch4 = str_replace("TEXT",$text,$ch3);
			$ch5 = str_replace("HOUR",date('h'),$ch4);
			$ch6 = str_replace("MINUTE",date('i'),$ch5);
			$ch7 = str_replace("SECOND",date("s"),$ch6);
$ch8 = str_replace("LINK","https://t.me/$usernamebot?start=$from_id",$ch7);
$ch9= str_replace("BOTNAME",$botname,$ch8);
$ch10 = str_replace("BOTUSER",$usernamebot,$ch9);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$ch10",

    ]);
}
elseif($text == '📱ارسال اکانت'){
$name = $idacc;
$usee = str_replace("@","",$name);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"با استفاده از این بخش و ربات @$usee شما میتوانید اکانت مجازی خود را برای ربات ارسال نمایید و در ازای آن تعداد سکه مشخصی دریافت نمایید.

👈 برای شروع به ربات @$usee رفته و مراحل را انجام دهید.",
			'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[['text'=>"🔗  $idacc",'url'=>"https://t.me/$usee"]],]
	])
    ]);
}
// .


// ,
// ,
elseif($text == '💸 انتقال سکه'){
if($user['coin'] >= 99){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"💸 در این بخش میتوانید سکه های خودتان را به سایر کابران $botname انتقال دهید.
موجودی شما: {$user['coin']} سکه

 تعداد سکه موردنظر برای انتقال را وارد کنید:",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'sendcoin' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⚠️ موجودی شما کافی نیست برای انتقال باید حداقل 100 سکه داشته باشید.',
'reply_to_message_id'=>$message_id,
]);
}
// .


// ,
// ,
elseif (preg_match("~tra\:(\d+)\:(\d+)~",$text,$a)){
$b = $a[1];
$c = $a[2];
$usercoin = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE coin = '$from_id' LIMIT 1"));
$userm = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE id = '$from_id' LIMIT 1"));
$has = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$b' LIMIT 1"));
if( ($userm['coin'] < $c) or (!$has) or ($b == $from_id) or ($c < 100)){
$coinman = $user['coin'] - $c;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️درهنگام انتقال موجودی مشکلی پیش آمد
1- نداشتن موجودی کافی
2- عدم وجود کاربر گیرنده
3- کمتر بودن از سطح مجاز انتقال",
'reply_to_message_id'=>$message_id,
]);
}else{
$coinp = $userm['coin'] - $c;
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' , `coin` = '$coinp' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"`✅ تعداد $c سکه در تاریخ $date ساعت $time با موفقیت به کاربر $b انتقال داده شد.`",
'reply_to_message_id'=>$message_id,
'parse_mode'=>'markdown'
]);
$coing = $has['coin'] + $c;
bot('sendmessage',[
'chat_id'=>$b,
'text'=>"`✅ تعداد $c سکه در تاریخ $date ساعت $time با موفقیت از کاربر $from_id دریافت شد.`",
'parse_mode'=>'Markdown',
]);
$connect->query("UPDATE `user$usernamebot` SET `coin` = '$coing' WHERE `id` = '$b' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$choed,
'text'=>"#newtransfer
`$from_id` انتقال دهنده
 [click](tg://user?id=$from_id)
 موجودی جدید : $coinp
 کاربر انتقال یافته `$b`
  [click](tg://user?id=$b)
  سکه انتقال یافته : $c
  موجودی جدید : $coing",
'parse_mode'=>'Markdown',
]);
}}

//===========================// data //===========================
elseif($data == 'join'){
if(bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$fromid])->result->status != 'left'){
bot('sendmessage',[
'chat_id'=>$chatid,
'text'=>"
$start",
'reply_to_message_id'=>$messageid,
 'reply_markup'=>$home
]);
}else{
bot('answercallbackquery', [
'callback_query_id' =>$update->callback_query->id,
'text' => "❌ هنوز داخل کانال « @$channel » عضو نیستی",
'show_alert' =>true
]);
}
}

//===========================// step //===========================
elseif ($user['step'] == 'seenamount') {
$max = floor($user['coin'] / $_seen);
if(is_numeric($text) and $text >= 1){
if($user['coin'] >= $text * 1){
  $limit = ($text > $maxorder)?'💡 تمامی سفارشها تا سقف $maxorder بازدید با توجه به سرعت انتخابی شما تکمیل خواهند شد و پس از آن بدون در نظر گرفتن سرعت تکمیل میشوند .':null;  
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

بزودی لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$speed
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenspeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ تعداد بازدید سفارشی باید بین 100 الی $maxorder (120k) باشد.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'seenspeed') {
$speedpanel = ['حداکثر سرعت','سرعت دلخواه'];
if(in_array($text , $speedpanel)){
if($text == 'سرعت دلخواه'){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ افزایش بازدید بعد از چند دقیقه شروع شود
❗️ مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید 👇🏻',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeed'  WHERE `id` = '$from_id' LIMIT 1");
}else{
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 پست خود را فوروارد کنید. (توجه برای کانال های عمومی لینک پست را ارسال نمایید)

تعداد درخواست: {$user['data']} بازدید
شروع سفارش: فوری
سرعت تکمیل: $text",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenpost' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");
}
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$speed
]);
}
elseif ($user['step'] == 'configspeed') {
if(is_numeric($text) and $text >= 10 and $text <= 1440){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
❗️ مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید 👇🏻',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeedtime' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ افزایش بازدید بعد از چند دقیقه شروع شود
👇🏻 مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'configspeedtime') {
if(is_numeric($text) and $text >= 10 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⏱ چه مقدار بازدید در هر $text دقیقه ارسال شود
❗️ مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید 👇🏻",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeedseen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
👇🏻 مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'configspeedseen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 10 and $text <= $explode[0]){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید

⚡️ سرعت تکمیل : هر $explode[2] دقیقه $text بازدید
⏱ زمان شروع سفارش : بعد از $explode[1] دقیقه
👁‍🗨 تعداد بازدید درخواستی : $explode[0]",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenpost' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ چه مقدار بازدید در هر $explode[2] دقیقه ارسال شود
👇🏻 مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
//==========================like mamad========================//
elseif ($user['step'] == 'likeamount') {
$max = floor($user['coin'] / $_like);
if(is_numeric($text) and $text >= 1){
if($user['coin'] >= $text * $_like){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

بزودی لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$speedlike
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'likespeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، میزان لایک وارد شده از موجودی شما بیشتر است

👇🏻 تعداد لایک (رأی) مورد نظر را به صورت عددی بین 1 الی $maxorder وارد کنید
👍🏻 موجودی حساب شما {$user['coin']} سکه هست و میتوانید حداکثر $max لایک را سفارش دهید",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد لایک (رأی) مورد نظر را به صورت عددی بین 1 الی $maxorder وارد کنید
👍🏻 موجودی حساب شما {$user['coin']} سکه هست و میتوانید حداکثر $max لایک را سفارش دهید",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'likespeed') {
$speedpanel = ['حداکثر سرعت','هر 2 دقیقه 1 لایک','هر 5 دقیقه 1 لایک','هر 15 دقیقه 1 لایک','هر 30 دقیقه 1 لایک'];
if(in_array($text , $speedpanel)){
  $amount = $user['data'] * $_like;
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 پست لایک، رای و یا نظرسنجی خود را ارسال کنید.

تعداد درخواست:  :{$user['data']}
شروع سفارش: فوری
سرعت تکمیل:$text",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$keys = [$speedpanel[0]=>'1',$speedpanel[1]=>'2',$speedpanel[2]=>'5',$speedpanel[3]=>'15',$speedpanel[4]=>'30'];
$connect->query("UPDATE `user$usernamebot` SET `step` = 'likebutton' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$speedlike
]);
}
elseif ($user['step'] == 'likebutton') {
if($message->poll == true) { 
if($message->poll->is_closed == false) { $i = 0;
  foreach ($message->poll->options as $k => $v) {
$substrtext = (mb_strlen($v->text) <= 27)?$v->text:mb_substr($v->text,0,27).'...';  
$key[] = [['text'=>$v->text,'callback_data'=>"bu_{$i}_0_{$substrtext}"]];
$i ++;
  }
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'👇🏻 لطفا گزینه مورد نظر را که مایلید برای آن لایک سفارش دهید را انتخاب کنید
• انجام لایک و رأی برای پست هایی که نیاز به جوین شدن در کانال داشته باشد امکان پذیر نیست .',
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>$key
])
]);
 $connect->query("UPDATE `user$usernamebot` SET `step` = 'likebuttonn' WHERE `id` = '$from_id' LIMIT 1");

  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",
  'from_chat_id'=>$from_id,
  'message_id'=>$message_id,
  ])->result->message_id;
  $connect->query("UPDATE `user$usernamebot` SET `data` = CONCAT(`data`,'^$channelorder^$id') WHERE `id` = '$from_id' LIMIT 1");
} else
/*
 { @San_Trich}
*/
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'️❗️ خطا ، نظر سنجی ارسال شده به اتمام رسیده است
⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
} else {
  $forward_from_chat_username = $message->forward_from_chat->username;
  if($forward_from_chat_username == true){
  $key = file_get_contents("$web/lib/api/buttons.php?channel=@$forward_from_chat_username&id={$message->forward_from_message_id}");
  if($key == '0')
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⚠️ پست ارسالی در این بخش یا باید فوروارد شده از کانال عمومی باشد و یا یک نظرسنجی (Poll) باشد.',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
else {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'👇🏻 لطفا گزینه مورد نظر را که مایلید برای آن لایک سفارش دهید را انتخاب کنید
• انجام لایک و رأی برای پست هایی که نیاز به جوین شدن در کانال داشته باشد امکان پذیر نیست .',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$key
]);


 //$connect->query("UPDATE `user$usernamebot` SET `com` = '' WHERE `id` = '$from_id' LIMIT 1");
 $connect->query("UPDATE `user$usernamebot` SET `step` = 'likebuttonn' WHERE `id` = '$from_id' LIMIT 1");

$connect->query("UPDATE `user$usernamebot` SET `data` = CONCAT(`data`,'^$forward_from_chat_username^{$message->forward_from_message_id}') WHERE `id` = '$from_id' LIMIT 1");
}
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ پست ارسال شده معتبر نیست
⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
}
elseif(preg_match('/^bu_(.*)/', $data) and $user['step'] == 'likebuttonn' ){		
  $connect->query("UPDATE `user$userbot` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
  bot('deletemessage',['chat_id'=> $chatid,'message_id'=> $messageid ]);
  $explode = explode('^',$user['data']);
  $match = explode('_',$data,4);
  $setting0 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'web' LIMIT 1"));

  $webapi1 = $setting0['text'];

  $link = "https://t.me/$explode[2]/$explode[3]";
$result = curl("$webapi1&type=like&count=$explode[0]&row=$match[1]&column=$match[2]&channel=$explode[2]&id=$explode[3]");
$order = "{$result->order}";

  if($result->result == 'ok'){
  $amount =$explode[0] * $liks;
$hesablike=$user[coin]-$amount;
  $connect->query("UPDATE `user$userbot` SET `coin` = `coin` - $amount WHERE `id` = '$fromid' LIMIT 1");
  $speed = ($explode[1] == 1)?'حداکثر سرعت':"هر $explode[1] دقیقه 1 لایک";
  bot('sendmessage',[
	'chat_id'=>$chatid,
    'text'=>"☑️ سفارش لایک (رأی) با شماره پیگیری $order ثبت شد .

🚀 سرعت تکمیل : حداکثر سرعت
❤️ تعداد درخواست لایک : $explode[0]
👍🏻 گزینه انتخابی برای دریافت لایک رای : $match[3]",
    'reply_markup'=>$home
            ]);		
 
            $user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$userbot` WHERE `id` = '$chatid' LIMIT 1"));			 
        $coin10 = $user['coin'] - $amount;
        $coin20 = $user['coin'] + 0;
                                 bot('sendmessage', ['chat_id' => "@$channelorder", 'text' => "❤️ سفارش لایک جدید
                             
• کد پیگیری سفارش : $order 
• سرعت تکمیل : $speed
ایدی عددی فرد :$chatid
• هزینه سفارش :  $amount سکه
• تعداد درخواست لایک   : $explode[0]
•گزینه انتخابی : : $match[2]
تعداد سکه کاربر : $coin20
",
  ]);	
  $connect->query("UPDATE `user$userbot` SET `data` = 'none' WHERE `id` = '$fromid' LIMIT 1");

$connect->query("INSERT INTO `orderlike$userbot` (`key` , `id` , `amount` , `speed` ,`like` , `link` , `time`) VALUES ('$order' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , ' در ساعت ".jdate('H:i:s')."')");		
}else{
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>'❌ خطا (کد 509)
	
❗️مشکلی در ثبت سفارش پیش امده است.

👈🏻 پست مورد نظر جهت دریافت لایک / رای را فروارد کنید.',
    'reply_markup'=>$back
            ]);	
  $connect->query("UPDATE `user$userbot` SET `step` = 'likebuttonn' WHERE `id` = '$fromid' LIMIT 1");
} 
}













elseif ($user['step'] == 'ramount') {
$max = floor($user['coin'] / $actcoin);
if(is_numeric($text) and $text >= 1){
if($user['coin'] >= $text * $actcoin){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

بزودی لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$speedlike
]);
$connect->query("UPDATE `user$userbot` SET `step` = 'rspeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ تعداد ری‌اکشن سفارشی باید بین 1 الی $maxorder باشد.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'rspeed') {
$speedpanel = ['حداکثر سرعت','هر 2 دقیقه 1 لایک','هر 5 دقیقه 1 لایک','هر 15 دقیقه 1 لایک','هر 30 دقیقه 1 لایک'];
if(in_array($text , $speedpanel)){
  $amount = $user['data'] * $actcoin;
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 لطفا پست موردنظر خود را را برای افزایش ری‌اکشن فوروارد کنید.

تعداد درخواست: {$user['data']} ری‌اکشن
شروع سفارش: فوری
سرعت تکمیل: $text",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$keys = [$speedpanel[0]=>'1',$speedpanel[1]=>'2',$speedpanel[2]=>'5',$speedpanel[3]=>'15',$speedpanel[4]=>'30'];
$connect->query("UPDATE `user$userbot` SET `step` = 'rbutton' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

همواره لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$speedlike
]);
}
  
elseif ($user['step'] == 'rbutton'){
   $keykar = json_encode([
    'inline_keyboard'=>[
	[['text'=>"👍",'callback_data'=>"act_👍"],['text'=>"👎",'callback_data'=>"act_👎"],['text'=>"❤️",'callback_data'=>"act_❤"],['text'=>"🔥",'callback_data'=>"act_🔥"]],
		[['text'=>"🎉",'callback_data'=>"act_🎉"],['text'=>"🤩",'callback_data'=>"act_🤩"],['text'=>"😱",'callback_data'=>"act_😱️"],['text'=>"😁",'callback_data'=>"act_😁"]],
	[['text'=>"😢",'callback_data'=>"act_😢"],['text'=>"💩",'callback_data'=>"act_💩"],['text'=>"🤮️",'callback_data'=>"act_🤮️"],['text'=>"🥰",'callback_data'=>"act_🥰"]],
	[['text'=>"👏",'callback_data'=>"act_👏"],['text'=>"🤔",'callback_data'=>"act_🤔"],['text'=>"🤯",'callback_data'=>"act_🤯"],['text'=>"🤬",'callback_data'=>"act_🤬"]],

              ]
              ]);
      $a = $message->forward_from_message_id;
 $forward_from_chat_username = $message->forward_from_chat->username;
if($message->forward_from_chat == true){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'🎯 ری‌اکشن موردنظر را انتخاب کنید:',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$keykar
]);
 $connect->query("UPDATE `user$userbot` SET `step` = 'rbutonn' WHERE `id` = '$from_id' LIMIT 1");

  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",
  'from_chat_id'=>$from_id,
  'message_id'=>$message_id,
  ])->result->message_id;
$connect->query("UPDATE `user$userbot` SET `data` = CONCAT(`data`,'^$forward_from_chat_username^$a') WHERE `id` = '$from_id' LIMIT 1");
$link = "https://t.me/$channelorder/$id";
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
⚠️ پست ارسال شده معتبر نیست، توجه نمایید که در این بخش شما میتوانید پست را به دو صورت ارسال نمایید:

1️⃣ پست خود را به صورت فوروارد شده از یک کانال ارسال کنید.د)",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$connect->query("UPDATE `user$userbot` SET `step` = 'rbutonn' WHERE `id` = '$from_id' LIMIT 1");
}
}
elseif(preg_match('/^act_(.*)/', $data) and $user['step'] == 'rbutonn' ){		
  $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
  bot('deletemessage',['chat_id'=> $chatid,'message_id'=> $messageid ]);
$explode = explode('^',$user['data']);
  $match = explode('_',$data);
  $link = "https://t.me/$explode[2]/$explode[3]";
  $setting0 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'web' LIMIT 1"));

  $webapi1 = $setting0['text'];
$result = curl("$webapi1&type=reaction&count=$explode[0]&emoji=$match[1]&channel=$explode[2]&id=$explode[3]");
$order = "{$result->order}";
  if($result->result == 'ok'){
  $amount =$explode[0] * $liks;
$hesablike=$user[coin]-$amount;
  $connect->query("UPDATE `user$userbot` SET `coin` = `coin` - $amount WHERE `id` = '$fromid' LIMIT 1");
  $speed = ($explode[1] == 1)?'حداکثر سرعت':"هر $explode[1] دقیقه 1 لایک";
  bot('sendmessage',[
	'chat_id'=>$chatid,
    'text'=>"
    ☑️ سفارش شما با کد پیگیری $order ثبت شد.
تعداد درخواست: $explode[0] ری‌اکشن
شروع سفارش: فوری
سرعت تکمیل: $speed
ری‌اکشن درخواستی: $match[1]",
    'reply_markup'=>$home
            ]);		
 
            $user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user$userbot` WHERE `id` = '$chatid' LIMIT 1"));			 
        $coin10 = $user['coin'] - $amount;
        $coin20 = $user['coin'] + $amount;
                                 bot('sendmessage', ['chat_id' => "@$channelorder", 'text' => "✅ سفارش ری اکشن جدید
                             
• کد پیگیری سفارش : $randstring 
• سرعت تکمیل : $speed
ایدی عددی فرد :$chatid
• هزینه سفارش :  $amount سکه
• تعداد درخواست ری اکشن   : $explode[0]
•گزینه انتخابی : : $match[1]
تعداد سکه کاربر : $coin20
",
  ]);	
  $connect->query("UPDATE `user$userbot` SET `data` = 'none' WHERE `id` = '$fromid' LIMIT 1");

$connect->query("INSERT INTO `actorder$userbot` (`key` , `id` , `amount` , `speed` ,`act` , `link` , `time`) VALUES ('$order' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , ' در ساعت ".jdate('H:i:s')."')");		
}else{
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>
	"❌ خطا (کد 509)

❗️مشکلی در ثبت سفارش پیش امده است.

👈🏻 پست مورد نظر جهت دریافت لایک / رای را فروارد کنید.
",
    'reply_markup'=>$back
            ]);	
  $connect->query("UPDATE `$userbotuser` SET `step` = 'rbutton' WHERE `id` = '$fromid' LIMIT 1");
} 
}
//================================endlike======================//
elseif ($user['step'] == 'setchannel') {
$forward_from_chat_id = $message->forward_from_chat->id;
if($forward_from_chat_id == true){
$getChatMember = bot('getChatMember',['chat_id'=>$forward_from_chat_id,'user_id'=>$botid])->result;
$getchat = bot('getchat',['chat_id'=>$forward_from_chat_id])->result;
if($getchat->type == 'channel' and $getChatMember->status != 'left'){
if(mysqli_num_rows(mysqli_query($connect,"SELECT * from `channel$usernamebot` WHERE `channel` = '$forward_from_chat_id' limit 1")) <= 0){
$max = floor($user['coin'] / $_seen);
$bazdid = $_seen * 1000;
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👁‍🗨 تعداد بازدید دلخواه خود را بین 100 الی ,$maxorder (120k) ارسال کنید.
موجودی شما: {$user['coin']} سکه

💡تمامی سفارشها تا سقف $maxorder بازدید با توجه به سرعت انتخابی شما تکمیل خواهند شد و پس از آن بدون در نظر گرفتن سرعت تکمیل میشوند.سکه است",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'amountchannel' , `data` = '$forward_from_chat_id' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، قبلا بازدید خودکار برای این کانال را ثبت کردید
👈🏻 برای حذف کانال کافیست از دکمه '📢 کانال های ثبت شده' استفاده نمایید",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'📢 کانال های ثبت شده']],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true,
])
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، ربات در کانال شما ادمین نیست

✅ برای شروع ثبت بازدید خودکار , لطفا ربات @$usernamebot را در کانالتان ادمین کنید سپس یک پست از کانال را به ربات فوروارد نمایید",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، پست ارسال شده متعبر نیست
👇🏻 پستی که ارسال کرده اید، فوروارد نشده بود، برای ثبت بازدید خودکار حتما باید یک پست از کانال را فوروارد کنید .',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'amountchannel') {
$max = floor($user['coin'] / $_seen);
if(is_numeric($text) and $text >= 10){
if($user['coin'] >= $text * $_seen){
  $limit = ($text > 50)?'💡 تمامی سفارشها تا سقف $maxorder بازدید با توجه به سرعت انتخابی شما تکمیل خواهند شد و پس از آن بدون در نظر گرفتن سرعت تکمیل میشوند .':null;  
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

بزودی لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$speed1
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'seenspeedch' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، میزان بازدید وارد شده از موجودی شما بیشتر است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 10 الی 120,000 وارد نمایید
👁 موجودی حساب شما {$user['coin']} سکه هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 10 الی 120,000 وارد نمایید
👁 موجودی حساب شما {$user['coin']} سکه هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'seenspeedch') {
$speedpanel = ['حداکثر سرعت','سرعت دلخواه','سریع','متوسط','آهسته'];
if(in_array($text , $speedpanel)){
if($text == 'سرعت دلخواه'){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ افزایش بازدید بعد از چند دقیقه شروع شود
❗️ مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید 👇🏻',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeedch'  WHERE `id` = '$from_id' LIMIT 1");
}else{
  $explode = explode('^',$user['data']);
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $_seen;
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : فوری و $text
💰 هزینه سفارش هر پست : $amount سکه
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
❌ برای لغو سفارش /del_".abs($explode[0])."",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("INSERT INTO `channel$usernamebot` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '{$keys[$text]}' , '$explode[1]')");
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");
}
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$speed
]);
}
elseif ($user['step'] == 'configspeedch') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
❗️ مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید 👇🏻',
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeedtimech' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ افزایش بازدید بعد از چند دقیقه شروع شود
👇🏻 مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'configspeedtimech') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⏱ چه مقدار بازدید در هر $text دقیقه ارسال شود
❗️ مقدار مجاز را به صورت عدد بین  10 الی $explode[1] بازدید وارد کنید 👇🏻",
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$back
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'configspeedseench' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
👇🏻 مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif ($user['step'] == 'configspeedseench') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 10 and $text <= $explode[1]){
  $start = ($explode[2] == 0)?'فوری':"بعد از $explode[2] دقیقه";
  $speed = ($explode[3] == 0)?'حداکثر سرعت':"هر $explode[3] دقیقه $text بازدید";
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $_seen;
  bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : $start و $speed
💰 هزینه سفارش هر پست : $amount سکه
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
❌ برای لغو سفارش /del_".abs($explode[0])."",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("INSERT INTO `channel$usernamebot` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '$explode[2]^$explode[3]^$text' , '$explode[1]')");
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ چه مقدار بازدید در هر $explode[3] دقیقه ارسال شود
👇🏻 مقدار مجاز را به صورت عدد بین  10 الی $explode[1] بازدید وارد کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
// .


// ,
// ,
elseif($user['step'] == 'sendid'and preg_match("/^(-){0,1}([0-9]+)(,[0-9][0-9][0-9])*([.][0-9]){0,1}([0-9]*)$/",$text) == 1){
if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user$usernamebot WHERE id = '$text' LIMIT 1")) == true and $text != $from_id){
    $coin2 = $user['coin'] - $user['data'];
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' , `coin` = '$coin2' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"`✅ تعداد {$user['data']}  سکه در تاریخ $date ساعت $time با موفقیت به کاربر $text انتقال داده شد.`",
'parse_mode'=>'Markdown',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user$usernamebot` WHERE `id` = '$text' LIMIT 1"));
$coin = $userdata['coin'] + $user['data'];
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"`✅ تعداد {$user['data']}  سکه در تاریخ $date ساعت $time با موفقیت از کاربر $from_id دریافت شد.`",
'parse_mode'=>'Markdown',
]);
$connect->query("UPDATE `user$usernamebot` SET `coin` = '$coin' WHERE `id` = '$text' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$admin1,
'text'=>"#newtransfer
`$from_id` انتقال دهنده
 [click](tg://user?id=$from_id)
 موجودی جدید : $coin2
 کاربر انتقال یافته `$text`
  [click](tg://user?id=$text)
  سکه انتقال یافته : {$user['data']}
  موجودی جدید : $coin",
'parse_mode'=>'Markdown',
]);
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ شناسه کاربری مقصد نامعتبر است و یا ارسال سکه به کاربر موردنظر ممکن نیست.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif($user['step'] == 'pay' && $tc == 'private'){
if($text >= 250 and $text <= $maxorder){
 if($text < 10000 and $text >= 1){
    $amount = ($text/1000)*$pricecoin;
 }
 if($text >= 10000 and $text < $maxorder){
    $amount = ($text/1000)*$pricecoin;
 }
 if($text >= $maxorder and $text < 100000){
    $amount = ($text/1000)*$pricecoin;
 }
 if($text >= 100000 and $text < 200000){
    $amount = ($text/1000)*$pricecoin;
 }
 if($text >= 200000 and $text < 500000){
    $amount = ($text/1000)*$pricecoin;
 }
 
        $phone = $user["phone"];
        $code = listpays('p');
        $connect->query("INSERT INTO `pay$usernamebot`(`code`, `id`, `phone`, `step`, `amount`, `coin`) VALUES ($code,'$chat_id',$phone,'pay','$amount','$text')");
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"<code>فاکتور خرید $text سکه به مبلغ $amount تومان برای شما صادر گردید.

فاکتور فوق برای شماره همراه  $phone صادر شده است، در صورت تایید دکمه پرداخت را لمس نمایید.
$date - $time </code>",
			'reply_to_message_id'=>$message_id,
			'parse_mode'=>'html',
			'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[['text'=>"پرداخت",'url'=>"$linknext?code=$code&get"]],
              ]
              ])
	       ]);	
bot('sendmessage',[
'chat_id'=>$from_id,
'text'=>'🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید',
'message_id'=>$message_id,
'reply_markup' =>$home
]);
     $connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}else		 

			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>'⚠️ لطفا تعداد سکه مورد نظر خود را بین 250 الی 500,000 وارد نمایید.',
			'reply_to_message_id'=>$message_id,
	              ]);	
}
elseif($user['step'] == 'sendcoin' ){
if($user['coin'] >= $text and $text > 100 and strpos($text,'+') == false and strpos($text,'-') == false and strpos($text,'*') == false and strpos($text,'/') == false and strpos($text,'÷') == false and strpos($text,'×') == false and strpos($text,'0+') == false and strpos($text,'1+') == false and strpos($text,'2+') == false and strpos($text,'3+') == false and strpos($text,'4+') == false and strpos($text,'5+') == false and strpos($text,'6+') == false and strpos($text,'7+') == false and strpos($text,'7+') == false and strpos($text,'8+') == false and strpos($text,'9+') == false){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🛑 توجه: عملیات انتقال سکه غیرقابل بازگشت است!

👈 درصورتی که درخواست  $text  مورد تاییدتان است، شناسه کاربری  مورد نظر  را ارسال کنید.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
 $connect->query("UPDATE `user$usernamebot` SET `step` = 'sendid' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"⚠️ این انتقال قابل انجام نیست، موجودی شما کافی نیست.
برای انتقال حداقل باید ۱۰۰ سکه داشته باشید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
}
elseif($user['step'] == 'sup'){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>'✅ پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید',
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
bot('ForwardMessage',[
'chat_id'=>$admin[0],
'from_chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}

//====================================
elseif ($user['step'] == 'sendcoiinall') {
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✔️ تعداد $text سکه برای همه در صف ارسال قرار گرفت ",
 ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall$usernamebot` SET `step` = 'sendcoinall' , `text` = '$text' , `chat` = '$chat_id' LIMIT 1");
}


//===========================// panel admin //===========================
elseif($text == 'پنل' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
😃 مدیر گرامی($from_id) به پنل مدیریت ربات $botname باموفقیت وارد شدید.

👈 جهت اطلاعات بیشتر از دکمه های زیر استفاده کنید :
    $date - $time 
    ",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"📊 آمار"],['text'=>"👤 اطلاعات کاربر"]],
[['text'=>"💰افزایش سکه کاهش سکه"]],
[['text'=>"✉️ همگانی"],['text'=>"⛔️ بلاک"]],
[['text'=>"💠 تغییر وبسرویس"],['text'=>"تنظیم بخش ها🏧"]],
[['text'=>"🌐 تغییر درگاه"]],
[['text'=>"💡ربات‌ روشن ربات خاموش"],['text'=>"🗝 | تغییر ادمین"]],
[['text'=>"اشتراک"]],
[['text'=>"انصراف"]],
],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"

  ])
]);
}
// .


// ,
// ,
elseif($text == 'برگشت 🔙' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🔅 مدیر گرامی ($from_id) به منو اصلی پنل مدیریت برگشتید با موفقیت
    $date - $time 
:",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"📊 آمار"],['text'=>"👤 اطلاعات کاربر"]],
[['text'=>"💰افزایش سکه کاهش سکه"]],
[['text'=>"✉️ همگانی"],['text'=>'⛔️ بلاک']],
[['text'=>"💠 تغییر وبسرویس"],['text'=>"تنظیم بخش ها🏧"]],
[['text'=>"🌐 تغییر درگاه"]],
[['text'=>"💡ربات‌ روشن ربات خاموش"],['text'=>"🗝 | تغییر ادمین"]],
[['text'=>"اشتراک"]],
[['text'=>"انصراف"]],
],
  'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"
  ])
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
// .


// ,
// ,
elseif($text == '📊 آمار' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"انتخاب کنید
$from_id - $name",
 'reply_markup'=>json_encode([
 'keyboard'=>[
     [['text'=>"👥 امار کاربران"],['text'=>"✉️ شارژ پنل پیامک"]],
     [['text'=>"🛍 امار سفارشات"],['text'=>"💰شارژ وب سرویس"]],
     [['text'=>"بیشترین سکه ها🎉"],['text'=>"برترین زیرمجموعه ها🎉"]],
     [['text'=>'برگشت 🔙']]


],
'input_field_placeholder'=> "$from_id - $first_name",
'resize_keyboard'=>true
  ])
]);
}
// .



// ,
// ,
elseif ($text == '✉️ پیام همگانی' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"🔺 نکات مهم از ارسال پیام همگانی :

🔹 شما فقط میتوانید متن ارسال کنید.
🔸 متن نباید بیشتر از 25,000 کاراکتر باشد. ( پیام های طولانی ، ارسال نخواهد شد )
❗️ برای ارسال عکس ، فیلم و... از بخش فوروارد همگانی استفاده کنید .

✅ راهنمای استفاده از امکانات متن :

🌀 نمونه برجسته کردن متن :
<b> متن شما </b> 
🌀 نمونه کج کردن متن :
<i> متن شما </i>
🌀 نمونه کد کردن متن :
<code> متن شما </code>
- - - - - - - - - - - - - -
📩 لطفا پیام متنی را در اینجا ارسال کنید :",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"
  ])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'sendtoall' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '✉️ همگانی' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"انتخاب کنید!",
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>"✉️ پیام همگانی"],['text'=>"✉️ فوروارد همگانی"]],
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"
  ])
  ]);
}
elseif ($text == '🛍 امار سفارشات' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
$allorderseen = mysqli_num_rows(mysqli_query($connect,"select `id` FROM `orderseen$usernamebot`"));
$allorderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike$usernamebot`"));
$allorderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel$usernamebot`"));
$react = mysqli_num_rows(mysqli_query($connect,"select `id` from `actorder$usernamebot`"));
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"💢 تعداد سفارشات بازدید : $allorderseen
💢 تعداد سفارشات لایک : $allorderlike
💢 تعداد سفارشات ری اکشن : $react
💢 تعداد کانال های ثبت شده :$allorderchannel ",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"
  ])
  ]);
}
elseif ($text == '👥 امار کاربران' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
    
$alluser = mysqli_num_rows(mysqli_query($connect,"select `id` from `user$usernamebot`"));
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy$usernamebot`"));
$allblock = mysqli_num_rows(mysqli_query($connect,"select `id` from `block$usernamebot`"));
$list = array (
    array($alluser, $allbuy, $allblock),
);

$fp = fopen('file.csv', 'w');

foreach ($list as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"📊 آمار ربات $botname

✅ تعداد کاربران : $alluser
✅ تعداد خرید ها : $allbuy
✅ تعداد مسدود ها :$allblock",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"

  ])
  ]);
}
elseif ($text == '💰شارژ وب سرویس' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
$result = curl("$webad&type=amount");
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰🐼 شارژ وب سرویس ربات $botname: {$result->amount}
 ",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"

  ])
  ]); 
}

elseif ($text == '✉️ شارژ پنل پیامک' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
$rsult= curl("https://cleverseen.ir/sms/api/v1/sendsms?type=amount&&".$websmsi."");
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"💰 شارژ وب سرویس پنل پیامک کلور پیامک   : {$rsult->result}
 ",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"
  ])
  ]); 
}

elseif ($text == '💡ربات‌ روشن ربات خاموش' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"انتخاب کنید!",
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>"😴 ربات خاموش "],['text'=>"😃 ربات روشن"]],
[['text'=>"بخش سین روشن"],['text'=>"بخش سین خاموش"]],
[['text'=>"بخش لایک روشن"],['text'=>"بخش لایک خاموش"]],
[['text'=>"بخش ری اکشن روشن"],['text'=>"بخش ری اکشن خاموش"]],
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"

  ])
  ]);
}
elseif ($text == '⛔️ بلاک' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)) {
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"انتخاب کنید!",
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>"✔️ ازاد کردن کاربر"],['text'=>"⛔️ بلاک کردن کاربر"]], [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"

  ])
  ]);
}
elseif ($text == '✉️ فوروارد همگانی' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"📩 لطفا پیام را در اینجا فوروارد کنید :",
 'reply_markup'=>json_encode([
 'keyboard'=>[
 [['text'=>"برگشت 🔙"]]
],
'resize_keyboard'=>true,
  'input_field_placeholder'=> "$from_id - $first_name"

  ])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'fortoall' WHERE `id` = '$from_id' LIMIT 1");
}
// .


// ,
// ,
elseif ($text == '💸 شارژ وب سرویس' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
$result = curl("$webad&type=amount");
 bot('sendmessage',[
 'chat_id'=>$from_id,
 'text'=>"✅ موجودی وب سرویس ربات $botname در حال حاظر{$result->amount}سکه است.

💰 مبلغ مورد نظر را جهت شارژ وب سرویس خود را وارد کنید :",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"

])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'charge' WHERE `id` = '$from_id' LIMIT 1");
}
// .


// ,
// ,
elseif ($text == '👤 اطلاعات کاربر' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
  'text'=>"✅ مدیر گرامی لطفا ایدی عددی شخص مورد نظر را ارسال کنید:",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"
])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'info' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '💰افزایش سکه کاهش سکه' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ مدیر گرامی لطفا در خط اول ایدی عددی کاربر مورد نظر وارد کنید و خط دوم تعداد سکه .

⚠️ مدیر گرامی اگر میخواهید موجودی کاربر کاهش بدید علامت - کنار تعداد سکه بزارید و اگر میخواهید افزایش بدید هیج علامتی قرار ندید کنار تعداد سکه .

👈 برای نمونه :
5063082802
1000",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"
])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'sendadmin' WHERE `id` = '$from_id' LIMIT 1");
}
  elseif($text=="🗝 | تغییر ادمین" and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
	bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"❗️ به بخش تنظیم ادمین خوش آمدید.

💯 برای حذف ادمین، از بخش لیست ادمین . ادمین مورد نظر را حذف کنید .",
'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
            	[['text'=>"➕ افزودن ادمین"]],
							[['text'=>"برگشت 🔙"],['text'=>"📚 لیست ادمین ها"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
}

#---------------------
//add admin

#
   elseif($text=="➕ افزودن ادمین"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
    bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"لطفا آیدی عددی فرد موردنظر را وارد نمایید✅",
'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            	'keyboard'=>[
            	[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"

       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'addadmin' WHERE id = '$from_id' LIMIT 1");	
    }
    ///////////////////////////
     elseif($user['step'] == "addadmin" and $text != "برگشت 🔙"  and ($admin['admin'] == $from_id or $from_id == $admin1) ){
    $ad = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `admin$usernamebot` WHERE admin = '$text' LIMIT 1"));
    if($ad['admin'] == null ){
			$connect->query("INSERT INTO admin$usernamebot (admin) VALUES ('$text')");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"کاربر $text با موفقیت افزوده شد .",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
            	[['text'=>"➕ افزودن ادمین"]],
							[['text'=>"برگشت 🔙"],['text'=>"📚 لیست ادمین ها"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"

       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}else{
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"ایدی عددی کاربر <code>$text</code> در لیست ادمین ها وجود دارد",
'parse_mode'=>"HTML",
    		]);
    		    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			}
			###########################
			#####################
			#################
			#########
			#####
			###
			#
			elseif($text=="💠 تغییر وبسرویس"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"لطفا آدرس جدید را ارسال نمایید  ✅\n\nآدرس قبلی\n$webad
			        
			        برای نمونه : https://cleverseen.ir/api/api.php?apikey=xxxxxxxxxx",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'web' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "web" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'web' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد آدرس جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			//////
			//
			//
			//
			//
			
				elseif($text=="🌐 تغییر درگاه"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"مرچنت کد نکست پی خود را وارید نمایید!\n\
			        
			        
			          توجه کنید که برای فعال سازی درگاه باید به پیوی ادمین مراجعه کنید!...\n\n\n@cleverseensupport",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'nextmr' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "nextmr" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'nextmr' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد مرچند جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			
#	
#	
#	
#	
		elseif($text=="تنظیم بخش ها🏧"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"     انتخاب کنید!",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
[['text'=>"لایک/رای ❤️"],['text'=>"بازدید 👁️"],['text'=>'ری اکشن 👍']],
[['text'=>"سکه ورود ♻️"],['text'=>"زیرمجموعه 👥"]],
[['text'=>"تنظیم شناسه پیامک 📩"],['text'=>"تنظیم پشتیبان 👤"]],
[['text'=>"کانال سفارشات 🗂"],['text'=>"آیدی اکانت گیر 📱"]],
[['text'=>"کانال اصلی 🎙"],['text'=>"بنر زیرمجموعه 📝"]],
[['text'=>"قیمت سکه 💰"],['text'=>"تنظیم متن پشتیبان 👨🏻‍💻"]],


			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);

			}







			elseif($text=="بازدید 👁️"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"قیمت را اعلام کنید / قیمت های  پیشفرض 
			        لایک هر عدد 80
			        هر بازدید 1 
			        سکه ورود100
			        سکه زیرمجموعه 100",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'seen' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "seen" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'seen' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد قیمت بازدید  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}

###




































####################
##
#
#
#
#
#
#

#
#
#
#

#
#
#
	elseif($text=="ری اکشن 👍"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"تا ارتقا این بخش قیمت ری اکش برابر با قیمت لایک خواهد بود",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "actcoin" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'actcoin' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد قیمت ری اکشن  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			
			##
			#
			#
			
			#
			#
			#
			#
			#
			#
			#
	elseif($text=="آیدی اکانت گیر 📱"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"لطفا ایدی مورد نظر را بدون @ ارسال کنید!",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                
			                $connect->query("UPDATE user$usernamebot SET step = 'idacc' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "idacc" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
    $settings = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'idacc' LIMIT 1"));

			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'idacc' LIMIT 1");
				bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد ایدی  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	

			}
####

	
		elseif($text=="لایک/رای ❤️"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"قیمت را اعلام کنید / قیمت های  پیشفرض 
			        لایک هر عدد 80
			        هر بازدید 1 
			        سکه ورود100
			        سکه زیرمجموعه 100",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'like' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "like" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'like' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد قیمت لایک  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
	elseif($text=="سکه ورود ♻️"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"قیمت را اعلام کنید / قیمت های  پیشفرض 
			        لایک هر عدد 80
			        هر بازدید 1 
			        سکه ورود100
			        سکه زیرمجموعه 100",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'startcoin' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "startcoin" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'startcoin' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد سکه ورود  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
				elseif($text=="بنر زیرمجموعه 📝"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"لطفا یک پست را در کانال خود قرار داده که شامل عکس میباشد و لینک پست را ارسال کنید",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'linkmember' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "linkmember" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'linkmember' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد لینک  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
	elseif($text=="زیرمجموعه 👥"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"قیمت را اعلام کنید / قیمت های  پیشفرض 
			        لایک هر عدد 80
			        هر بازدید 1 
			        سکه ورود100
			        سکه زیرمجموعه 100",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'membercoin' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "membercoin" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'membercoin' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد سکه زیرمجموعه  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}

		elseif($text=="تنظیم شناسه پیامک 📩"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"لطفاً کد قالب و کلید اتصال خود را از ربات
@CleverSMSBot
گرفته و اینگونه ارسال کنید.
api_key=******&&template=******",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'setsms' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "setsms" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'sms' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد  شناسه  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			elseif($text=="تنظیم متن پشتیبان 👨🏻‍💻"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"متن جدید را بفرستید میتوانید از متغیر های زیر استفاده کنید:
FIRSTNAME | اسم کاربر
USERNAME | یوزرنیم 
USERID | شناسه کاربری
TEXT | اخرین متن
HOUR | ساعت
MINUTE | دقیقه
SECOND | ثانیه  
LINK | لینک زیرمجموعه گیری
BOTNAME   | اسم ربات
BOTUSER|یوزرنیم ربات

#توجه داشته باشید ک این قسمت درحال بروزرسانی است",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'sesuptext' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "setsuptext" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'suptext' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد  متن  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
	elseif($text=="تنظیم پشتیبان 👤"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"آیدی را با @ وارد کنید",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'setsupid' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "setsupid" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'setsupid' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد  شناسه  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
				elseif($text=="کانال سفارشات 🗂"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"آیدی را بدون @ وارد کنید",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'andderch' WHERE id = '$from_id' LIMIT 1");	
			    
			}
		
     elseif($user['step'] == "andderch" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'choed' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد  شناسه  جدید\n\n@$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
						
			
			
			
			
			
			
			
			
			
			
			
			
			
			elseif($text=="قیمت سکه 💰"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"قیمت جدید را وارد کنید",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'coinprice' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "coinprice" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
     if(is_numeric($text)){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'coinprice' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>" قیمت  جدید\n\n$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}else{
			 bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>" فقط عدد",
'parse_mode'=>"HTML",
]);
}
}

			
			
			
			
			
			
			
			
			
				elseif($text=="کانال اصلی 🎙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"آیدی را بدون @ وارد کنید",
			        'parse_mode'=>"HTML",
			        'reply_markup'=>json_encode([
			            'keyboard'=>[
			                [['text'=>"برگشت 🔙"]],
			                ],
			                'resize_keyboard'=>true,
			                  'input_field_placeholder'=> "$from_id - $first_name"

			                ])
			                ]);
			                $connect->query("UPDATE user$usernamebot SET step = 'join' WHERE id = '$from_id' LIMIT 1");	
			    
			}
     elseif($user['step'] == "join" && $text != "برگشت 🔙"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
			$connect->query("UPDATE setting$usernamebot SET text = '$text' WHERE setting = 'join' LIMIT 1");
			bot('sendmessage',[
	'chat_id'=>$chat_id,
'text'=>"با موفقیت تغییر کرد  شناسه  جدید\n\n@$text",
'parse_mode'=>"HTML",
       'reply_markup'=>json_encode([
            	'keyboard'=>[
							[['text'=>"برگشت 🔙"]],
 	],
            	'resize_keyboard'=>true,
            	  'input_field_placeholder'=> "$from_id - $first_name"
       		])
    		]);
    		$connect->query("UPDATE user$usernamebot SET step = 'none' WHERE id = '$from_id' LIMIT 1");	
			}
			if($text=="اشتراک"  and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)   and $text != 'برگشت 🔙'){
			    $time = file_get_contents("exp.txt");
			   $f =jdate("Y/m/d" ,strtotime($time));

			    bot('sendmessage',[
			        'chat_id'=>$chat_id,
			        'text'=>"اشتراک باقیمانده تا تاریخ : $f"			                ]);

			}
#	#		
#
#
#
#
#
#
#
#
#
##			
#	
#	
	
#	#
#	#
#	
	#
	#
	#		
elseif ($text == '📚 لیست ادمین ها' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1) ){
$chs = mysqli_query($connect,"select admin from admin$usernamebot");
$fil = mysqli_num_rows($chs);
if($fil != 0){
while($row = mysqli_fetch_assoc($chs)){
     $ar[] = $row["admin"];
}
for ($i=0; $i <= $fil; $i++){

$by = $i + 1;
$okk = $ar[$i];
$ch = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `admin$usernamebot` WHERE admin = '$okk' LIMIT 1"));
$link = $ch['admin'];
if($link != null ){
$d4[] = [['text'=>"$link",'callback_data'=>'ok'],['text'=>"❌ حذف",'callback_data'=>"delc_$okk"]];
}
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👇🏻 لیست تمام ادمین ها",
'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
           'inline_keyboard'=>$d4
              ])
    		]); 
    		}else{
    		bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❌ هیچ ادمینی  تنظیم نشده.",
'parse_mode'=>"HTML",
    		]); 
    		}
    }
    #----
    #-
    #-
elseif(strpos($data,"delc_") !== false and $fromid == $admin1){
$ok = str_replace("delc_",null,$data);
$chs = mysqli_query($connect,"select admin from admin");
$fil = mysqli_num_rows($chs);
if($fil == 1){
$connect->query("DELETE FROM `admin$usernamebot` WHERE admin = '$ok'");	
bot('editMessagetext',[
   'chat_id'=>$chatid,
   'message_id'=>$messageid,
'text'=>"👇🏻 لیست تمام ادمین های 

❌ تمام ادمین ها حذف شده است.",
'parse_mode'=>"HTML",
    		]); 
    bot('answercallbackquery', [
        'callback_query_id'=>$update->callback_query->id,
'text' => "✅ ادمین حذف شد .",
        'show_alert' => false
    ]);
}else{
$connect->query("DELETE FROM `admin$usernamebot` WHERE admin = '$ok'");	
  $chs = mysqli_query($connect,"select admin from admin");
$fil = mysqli_num_rows($chs);
while($row = mysqli_fetch_assoc($chs)){
     $ar[] = $row["admin"];
}
for ($i=0; $i <= $fil; $i++){

$by = $i + 1;
$okk = $ar[$i];
$ch = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `admin$usernamebot` WHERE admin = '$okk' LIMIT 1"));
$link = $ch['admin'];
if($link != null ){
$d4[] = [['text'=>"$link",'callback_data'=>'ior'],['text'=>"❌ حذف",'callback_data'=>"delc_".$okk.""]];
}
}
bot('editMessagetext',[
   'chat_id'=>$chat_id,
   'message_id'=>$message_id,
'text'=>"👇🏻 لیست تمام ادمین ها

❌ ادمین حذف شد .",
'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
           'inline_keyboard'=>$d4,
              ])
    		]); 
    bot('answercallbackquery', [
        'callback_query_id' => $update->callback_query->id,
'text' => "✅ ادمین حذف شد .",
        'show_alert' => false
    ]);
    }
   }
   ##########
   ################
   ########
   ####
   ##
   ##
   #
   #
   
   elseif ( $text == "بیشترین سکه ها🎉" and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
$code = $connect->query("SELECT * from `user$usernamebot` ORDER BY `coin` DESC LIMIT 15");
while($res = mysqli_fetch_assoc($code)){
$i++;
$id = $res['id'];
$member = $res['coin'];
$infoname = bot('getChatMember',['chat_id'=>"$id",'user_id'=>"$id"]);
$yournamer = $infoname->result->user->first_name;
$result = $result."
💰 نفر $i « <a href ='tg://user?id=$id'>$yournamer</a> » 
👥 <code>$id</code> سکه $member
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
";
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
👤 بیشترین ها در سکه  : 

$result

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️

@$usernamebot
",
'parse_mode'=>'HTML',
]);
}
   ###############
   ############
   ##########
   ######
   ####
   ###
   ##
   #
elseif ( $text == "برترین زیرمجموعه ها🎉" and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
$code = $connect->query("SELECT * from `user$usernamebot` ORDER BY `member` DESC LIMIT 10");
while($res = mysqli_fetch_assoc($code)){
$i++;
$id = $res['id'];
$member = $res['member'];
$infoname = bot('getChatMember',['chat_id'=>"$id",'user_id'=>"$id"]);
$yournamer = $infoname->result->user->first_name;
$result = $result."
💰 نفر $i « <a href ='tg://user?id=$id'>$yournamer</a> » 
👥 تعداد زیرمجموعه : $member  <code>$id</code>
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
";
}
bot('sendmessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
👤 برترین های زیر مجموعه گیری : 

$result

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
@$usernamebot
",
'parse_mode'=>'HTML',
]);
}
elseif ($text == '⛔️ بلاک کردن کاربر' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"⭕️ آیدی عددی شخص را ارسال کنید :",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"
])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'block' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '✔️ ازاد کردن کاربر' and $tc == 'private' and ($admin['admin'] == $from_id or $from_id == $admin1)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"⭕️ آیدی عددی شخص را ارسال کنید :",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true,
    'input_field_placeholder'=> "$from_id - $first_name"

])
  ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'unblock' WHERE `id` = '$from_id' LIMIT 1");
}

//===========================// admin step //===========================
elseif($user['step'] == 'charge') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ فاکتور افزایش موجودی شما :
 
$webapi&amount=$text&type=adfuns",
]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'info') {
$allbuy = mysqli_num_rows(mysqli_query($connect,"select id from `buy$usernamebot` WHERE id = '$text'"));
$orderseen = mysqli_num_rows(mysqli_query($connect,"select id FROM `orderseen$usernamebot` WHERE id = '$text'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select id from `orderlike$usernamebot` WHERE id = '$text'"));
$orderchannel = mysqli_num_rows(mysqli_query($connect,"select id from `channel$usernamebot` WHERE id = '$text'"));

bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
اطلاعات  فرد
<code>$text</code> 
<a href='tg://user?id=$text'>click</a>
تعدادخرید  $allbuy
سفارش سین  $orderseen
سفارش لایک  $orderlike
کانال ثبت شده $orderchannel
زیرمجموعه  {$useran['member']}
موجودی {$useran['coin']}
شماره {$useran['phone']}
",
'parse_mode'=>'html',
]);

$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

//===================== 
elseif($user['step'] == 'block' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"`$text` مسدود شد .⭕️",
'parse_mode'=>'markdown'
 ]);
$connect->query("INSERT INTO `block$usernamebot` (`id`) VALUES ('$text')");
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'unblock' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"`$text` از لیست مسدود آزاد شد.✅",
'parse_mode'=>'markdown'
 ]);
$connect->query("DELETE FROM `block$usernamebot` WHERE `id` = '$text'");
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
//========================
//========================
elseif($user['step'] == 'sendadmin') {
$all = explode("\n", $text);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
 ]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * from `user$usernamebot` WHERE `id` = '$all[0]' LIMIT 1")); 
$coin = $user['coin'] + $all[1] ;
bot('sendmessage',[
'chat_id'=>$all[0],
'text'=>"✅ $all[1] سکه موجودی از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin سکه",
]);
$connect->query("UPDATE `user$usernamebot` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
}
elseif ($user['step'] == 'sendtoall') {
$photo = $message->photo[count($message->photo)-1]->file_id;
$caption = $update->message->caption;
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📣 پیام به صف ارسال همگانی قرار گرفت !

✅ بعد از اتمام ارسال، به شما اطلاع داده میشود.
",
 ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall$usernamebot` SET step = 'send' , `text` = '$text' , `chat` = '' LIMIT 1");
}
elseif ($user['step'] == 'fortoall') {
 bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📣 پیام به صف فوروارد قرار گرفت !

✅ بعد از اتمام فوروارد، به شما اطلاع داده میشود.
",
 ]);
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall$usernamebot` SET `step` = 'forward' , `text` = '$message_id' , `chat` = '$chat_id' LIMIT 1");
}
//===========================// answer //===========================
//===========================// channel //===========================
elseif($channel_post and $user['channel'] == true){
    $setting3 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'choed' LIMIT 1"));

    $channelorder = $setting3['text'];
    $setting2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'seen' LIMIT 1"));

    $_seen = $setting2['text'];
        $setting22 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$userbot` WHERE setting = 'web' LIMIT 1"));

    $webapi = $setting22['text'];
  $amount = $user['view'] * $_seen;
  if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user$usernamebot` WHERE `id` = '{$user['id']}' LIMIT 1"))['coin'] >= $amount){
  if($channel_post->audio != true){
  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",
  'from_chat_id'=>$channel_post_chat_id,
  'message_id'=>$channel_post_message_id,
  ])->result->message_id;
  } else {
  $id = $channel_post_message_id;
  $channelorder = $channel_post_chat_username;
  }  
  $link = "https://t.me/$channelorder/$id";
  $explode = explode('^',$user['speed']);  
    $result = curl("$webapi&type=view&count={$user['view']}&start=$explode[0]&speed=$explode[1]&period=$explode[0]&channel=$channelorder&id=$id");
  if($result->result == 'ok'){
  $connect->query("UPDATE `user$usernamebot` SET `coin` = `coin` - $amount WHERE `id` = '{$user['id']}' LIMIT 1");
  $startorder = ($explode[0] == 0)?'فوری':"بعد از $explode[0] دقیقه";
  $speed = ($explode[1] == 0)?'حداکثر سرعت':"هر $explode[1] دقیقه $explode[2] بازدید";
  bot('sendmessage',[
'chat_id'=>$user['id'],
'text'=>"☑️ سفارش بازدیدخودکار با شماره پیگیری $randstring ثبت شد .

⚡️ سرعت تکمیل : $startorder و $speed 
💰 هزینه سفارش : $amount سکه
👁‍🗨 تعداد بازدید درخواستی : {$user['view']}
👁 بازدید فعلی : {$result->seenstart} بازدید",
]);
  $connect->query("INSERT INTO `orderseen$userbot` (`key` , `id` , `amount` , `speed` , `view` , `link` , `time`) VALUES ('$randstring' ,'{$user['id']}' , '$amount' , '$speed' , '{$user['view']}' , '$link' , 'در ساعت ".jdate('H:i:s')."')");
}else
bot('sendmessage',[
'chat_id'=>$user['id'],
'text'=>"
❗️ خطا ، پست شما نامعتبر است یا مشکلی در انجام سفارش ایجاد شده است

👈🏻 توجه کنید که امکان ثبت سفارش بازدید خودکار برای پست موسیقی در کانال های خصوصی امکان پذیر نیست 
👮🏻 در صورت بروز هرگونه مشکل و یا انجام نشدن سفارش کافیست با پشتیبانی در تماس باشید .",
]);
}else{
$title = bot('getchat',['chat_id'=>$channel_post_chat_id])->result->title;
bot('sendmessage',[
'chat_id'=>$user['id'],
'text'=>"❗️ سفارش بازدید خودکار برای کانال $title انجام نشد .

✅ برای انجام سفارش باید حداقل $amount سکه موجودی داشته باشید .
❌ برای حذف کانال /del_".abs($channel_post_chat_id)."",
]);
}
}
//===========================// main //===========================

elseif($text == '/start'){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$start,
'reply_to_message_id'=>$message_id,
 'reply_markup'=>$home
]);
if($user['id'] != true and $text == '/start') {
    
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$gift,
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home,
]);
$connect->query("INSERT INTO `user$usernamebot`(`id`, `coin` , `daystart`) VALUES ('$from_id', '$_gift' , '$date')");}
$connect->query("UPDATE `user$usernamebot` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
if($val !== FALSE)
{
     mysqli_multi_query($connect,"CREATE TABLE actorder$usernamebot (
   	`key` varchar(100) PRIMARY KEY,
    `id` bigint NOT NULL,
	`amount` bigint NOT NULL,
	`speed` varchar(155) NOT NULL,
	`act` bigint NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4;");

}

//=
?>