<?php
//نکته مهم: بعد از آماده شدن دیتابیس شما یک بار صفحه اجرا شود
include 'config.php';


//========================== // table creator // ==============================
mysqli_multi_query($connect,"CREATE TABLE `user$usernamebot` (
    `id` bigint PRIMARY KEY,
	`step` varchar(50) DEFAULT NULL,
	`member` bigint DEFAULT '0',
	`coin` bigint NOT NULL,
    `data` TEXT DEFAULT NULL,
	`inviter` bigint DEFAULT '0',
    `phone` varchar(50) DEFAULT NULL,
    `com` varchar(50) DEFAULT NULL,
    `daystart` varchar(50) DEFAULT NULL
    ) default charset = utf8mb4;
	CREATE TABLE `orderseen$usernamebot` (
	`key` varchar(155) PRIMARY KEY,
    `id` bigint NOT NULL,
	`amount` bigint NOT NULL,
	`speed` varchar(90) NOT NULL,
	`view` bigint NOT NULL,
	`link` TEXT NOT NULL,
	`time` varchar(155) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4;
	CREATE TABLE `orderlike$usernamebot` (
	`key` varchar(155) PRIMARY KEY,
    `id` bigint NOT NULL,
	`amount` bigint NOT NULL,
	`speed` varchar(155) NOT NULL,
	`like` bigint NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4; 
	CREATE TABLE `channel$usernamebot` (
	`channel` bigint PRIMARY KEY,
    `id` bigint NOT NULL,
	`view` bigint NOT NULL,
	`speed` varchar(50) NOT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `buy$usernamebot` (
    `id` bigint NOT NULL,
	`amount` bigint NOT NULL,
	`time` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) default charset = utf8mb4;
	CREATE TABLE `block$usernamebot` (
    `id` bigint NOT NULL
    ) default charset = utf8mb4;   	
    CREATE TABLE `daily$usernamebot` (
    `time` varchar(50) DEFAULT '',
    `user` bigint DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `sendall$usernamebot` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`user` bigint DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `pay$usernamebot` (
    `code` bigint(30) NOT NULL PRIMARY KEY,
    `id` bigint NOT NULL,
    `phone` varchar(20) DEFAULT NULL,
    `step` varchar(50) NOT NULL,
    `ip` varchar(100) DEFAULT NULL,
    `date` varchar(100) DEFAULT NULL,
    `amount` bigint(20) NOT NULL,
    `coin` bigint(100) DEFAULT NULL,
    `paycode` varchar(500) DEFAULT NULL
    ) default charset = utf8mb4;
       CREATE TABLE `admin$usernamebot` (
    `admin` bigint NOT NULL PRIMARY KEY
    ) default charset = utf8mb4;
    CREATE TABLE `setting$usernamebot` (
    `setting` varchar(200) NOT NULL PRIMARY KEY,
    `text` text DEFAULT NULL
    ) default charset = utf8mb4;
     CREATE TABLE `actorder$usernamebot` (
   	`key` varchar(100) PRIMARY KEY,
    `id` bigint NOT NULL,
	`amount` bigint NOT NULL,
	`speed` varchar(155) NOT NULL,
	`act` bigint NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4;
    
    

    
    
    ");


//========================== // Check connection // ==============================
if ($connect->connect_error) {
   die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
  echo "دیتابیس متصل و نصب شد ."

?>