<?php 
error_reporting(0);
//========================== // token // ==============================
define('API_KEY','API_T');
$smskey="";
$admin = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `admin$usernamebot` WHERE admin = '$from_id' LIMIT 1"));
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'web' LIMIT 1"));
$setting2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'nextmr' LIMIT 1"));
$setting3 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'choed' LIMIT 1"));
$setting4 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'setsupid' LIMIT 1"));
$setting5 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'startcoin' LIMIT 1"));
$setting6 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'membercoin' LIMIT 1"));
$setting7 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'seen' LIMIT 1"));
$setting8 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'like' LIMIT 1"));
$setting9 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'sms' LIMIT 1"));
$setting10 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'join' LIMIT 1"));
$setting13 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting$usernamebot` WHERE setting = 'idacc' LIMIT 1"));


//========================== // config // ==============================
$admin1 = IDADMIN;
$API_K = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getme'));
$botid = $API_K->result->id;
$usernamebot = $API_K->result->username;
$channel =  $setting10['text'];
$channelorder = $setting3['text'];
$channelname = $API_K->result->first_name;
$botname = $API_K->result->first_name;  
$MerchantID = $setting2['text'];
$usernamesup = $setting4['text'];
$webapi = $setting['text'];
$apikey = 'null'; 
$varizi= $setting3['text'];
$idacc = $setting13['text'];
//========================== // variable // ==============================
$_gift = $setting5['text'];
$_member = $setting6['text'];
$maxorder = '100000';
$_porsant = '300';
$_seen = $setting7['text'];
$_like=$setting8['text'];
////========================== // database // ==============================
$dbname = ""; //  Name db
$usernamedb = ""; // Username db
$password = ''; // Pass username db
$connect = new mysqli('localhost',$dbname,$password,$usernamedb);
mysqli_query($connect,"SET SESSION collation_connection = 'utf8_persian_ci'");
?>