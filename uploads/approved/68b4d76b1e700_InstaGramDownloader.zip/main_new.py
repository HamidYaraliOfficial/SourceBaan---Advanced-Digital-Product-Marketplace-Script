import os
import signal
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes, ConversationHandler
from instagram_downloader import download_instagram
import logging
import json
import requests
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import numpy as np
import seaborn as sns
from collections import defaultdict
import matplotlib.font_manager as fm
import arabic_reshaper
from bidi.algorithm import get_display


sns.set_style("darkgrid")
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['figure.dpi'] = 300
plt.rcParams['figure.figsize'] = [10, 6]


BOT_TOKEN = "" #توکن ربات را قرار دهید
ADMIN_IDS = []   #ایدی عددی ادمین را قرار دهید
CHANNEL_USERNAME = "" #ایدی چنل
BOT_USERNAME = "" #ایدی ربات


logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


AWAITING_BROADCAST = "AWAITING_BROADCAST"
AWAITING_USER_ID = "AWAITING_USER_ID"
AWAITING_BAN_CONFIRM = "AWAITING_BAN_CONFIRM"
AWAITING_UNBAN_CONFIRM = "AWAITING_UNBAN_CONFIRM"
AWAITING_REPLY = "AWAITING_REPLY"
AWAITING_WARN_REASON = "AWAITING_WARN_REASON"
AWAITING_NOTE = "AWAITING_NOTE"


data = {
    'stats': {
        'total_downloads': 0,
        'successful_downloads': 0,
        'failed_downloads': 0,
        'users': set(),
        'last_24h_downloads': 0,
        'last_24h_users': set(),
        'hourly_stats': {}, 
        'daily_stats': {},   
        'peak_hours': {}     
    },
    'user_stats': {},     
    'reports': [],       
    'blocked_users': set(), 
    'user_activities': {}, 
    'admin_notes': {},     
    'warnings': {},       
    'suspicious': set(),  
    'trusted': set(),     
    'spam_reports': {},   
    'errors': []         
}

def save_data():
    """ذخیره اطلاعات در فایل"""
    try:

        data_to_save = {
            'stats': {
                'total_downloads': data['stats']['total_downloads'],
                'successful_downloads': data['stats']['successful_downloads'],
                'failed_downloads': data['stats']['failed_downloads'],
                'users': list(data['stats']['users']),
                'last_24h_downloads': data['stats']['last_24h_downloads'],
                'last_24h_users': list(data['stats']['last_24h_users']),
                'hourly_stats': data['stats']['hourly_stats'],
                'daily_stats': data['stats']['daily_stats'],
                'peak_hours': data['stats']['peak_hours']
            },
            'user_stats': data['user_stats'],
            'reports': data['reports'],
            'blocked_users': list(data['blocked_users']),
            'user_activities': data['user_activities'],
            'admin_notes': data['admin_notes'],
            'warnings': data['warnings'],
            'suspicious': list(data['suspicious']),
            'trusted': list(data['trusted']),
            'spam_reports': data['spam_reports'],
            'errors': data['errors']
        }


        if os.path.exists('bot_data.json'):
            os.rename('bot_data.json', f'bot_data_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')


        with open('bot_data.json', 'w', encoding='utf-8') as f:
            json.dump(data_to_save, f, ensure_ascii=False, indent=2)

        logger.info("اطلاعات با موفقیت ذخیره شد")
        return True
    except Exception as e:
        logger.error(f"خطا در ذخیره اطلاعات: {str(e)}")
        return False

def load_data():
    """بازیابی اطلاعات از فایل"""
    try:
        with open('bot_data.json', 'r', encoding='utf-8') as f:
            loaded = json.load(f)


            stats = loaded.get('stats', {})
            data['stats']['total_downloads'] = stats.get('total_downloads', 0)
            data['stats']['successful_downloads'] = stats.get('successful_downloads', 0)
            data['stats']['failed_downloads'] = stats.get('failed_downloads', 0)
            data['stats']['users'] = set(stats.get('users', []))
            data['stats']['last_24h_downloads'] = stats.get('last_24h_downloads', 0)
            data['stats']['last_24h_users'] = set(stats.get('last_24h_users', []))
            data['stats']['hourly_stats'] = stats.get('hourly_stats', {})
            data['stats']['daily_stats'] = stats.get('daily_stats', {})
            data['stats']['peak_hours'] = stats.get('peak_hours', {})


            data['user_stats'] = loaded.get('user_stats', {})
            data['reports'] = loaded.get('reports', [])
            data['blocked_users'] = set(loaded.get('blocked_users', []))
            data['user_activities'] = loaded.get('user_activities', {})
            data['admin_notes'] = loaded.get('admin_notes', {})
            data['warnings'] = loaded.get('warnings', {})
            data['suspicious'] = set(loaded.get('suspicious', []))
            data['trusted'] = set(loaded.get('trusted', []))
            data['spam_reports'] = loaded.get('spam_reports', {})
            data['errors'] = loaded.get('errors', [])

        logger.info("اطلاعات با موفقیت بازیابی شد")
        return True
    except FileNotFoundError:
        logger.warning("فایل اطلاعات یافت نشد. از مقادیر پیش‌فرض استفاده می‌شود")
        return False
    except Exception as e:
        logger.error(f"خطا در بازیابی اطلاعات: {str(e)}")

        try:
            import shutil
            shutil.copy('bot_data.json', 'bot_data.json.bak')
            logger.info("از فایل قبلی پشتیبان گرفته شد: bot_data.json.bak")
        except:
            pass
        return False

def signal_handler(signum, frame):
    """هندلر سیگنال‌های سیستمی برای ذخیره اطلاعات قبل از خروج"""
    logger.info("در حال ذخیره اطلاعات قبل از خروج...")
    save_data()
    logger.info("اطلاعات ذخیره شد. در حال خروج...")
    os._exit(0)

async def is_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """چک کردن عضویت کاربر در کانال"""
    try:
        user = await context.bot.get_chat_member(f"@{CHANNEL_USERNAME}", update.effective_user.id)
        return user.status in ['member', 'administrator', 'creator']
    except:
        return False

async def is_admin(user_id: int) -> bool:
    """چک کردن ادمین بودن کاربر"""
    logger.info(f"Checking admin status for user {user_id}")
    logger.info(f"Admin IDs: {ADMIN_IDS}")
    is_admin = user_id in ADMIN_IDS
    logger.info(f"Is admin: {is_admin}")
    return is_admin

def get_main_keyboard():
    """دکمه‌های اصلی ربات"""
    keyboard = [
        [InlineKeyboardButton("📊 آمار ربات", callback_data="stats"),
         InlineKeyboardButton("ℹ️ راهنما", callback_data="help")],
        [InlineKeyboardButton("⚠️ گزارش مشکل", callback_data="report"),
         InlineKeyboardButton("📡 وضعیت ربات", callback_data="status")]
    ]
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """هندلر دستور /start"""
    user_id = update.effective_user.id
    first_name = update.effective_user.first_name or "کاربر"


    data['stats']['users'].add(user_id)
    if user_id not in data['user_stats']:
        data['user_stats'][user_id] = {
            'join_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_downloads': 0
        }
    save_data()

    total_users = len(data['stats']['users'])
    total_downloads = data['stats']['total_downloads']
    success_rate = (data['stats']['successful_downloads'] / total_downloads * 100) if total_downloads else 0

    welcome_text = (
        f"🌟 <b>خوش آمدی {first_name}!</b> 🌟\n\n"
        "🤖 من ربات دانلودر اینستاگرام هستم\n"
        "میتونم تو دانلود محتوای اینستاگرام کمکت کنم!\n\n"
        "📱 <b>قابلیت‌های من:</b>\n"
        "├─ دانلود پست‌های اینستاگرام\n"
        "├─ دانلود ریلز و IGTV\n"

        "└─ کاملاً رایگان و بدون تبلیغات\n\n"
        "📊 <b>آمار ربات:</b>\n"
        f"├─ کاربران: <code>{total_users:,}</code>\n"
        f"├─ دانلودها: <code>{total_downloads:,}</code>\n"
        f"└─ رضایت: <code>{success_rate:.1f}%</code>\n\n"
        "🔥 کافیه لینک پست یا ریل رو برام بفرستی!"
    )

    keyboard = [
        [
            InlineKeyboardButton("📥 دانلود از اینستاگرام", callback_data="send_link"),
            InlineKeyboardButton("ℹ️ راهنما", callback_data="help")
        ],
        [
            InlineKeyboardButton("📊 آمار من", callback_data="my_stats"),
            InlineKeyboardButton("⚡️ وضعیت ربات", callback_data="status")
        ],
        [
            InlineKeyboardButton("💎 کانال ما", url=f"https://t.me/{CHANNEL_USERNAME}"),
            InlineKeyboardButton("🤝 دعوت دوستان", callback_data="invite_friends")
        ]
    ]

    await update.message.reply_text(
        welcome_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """هندلر دستور /help"""
    await update.message.reply_text(
        "🔰 راهنمای استفاده از ربات:\n\n"
        "1️⃣ ابتدا در کانال ما عضو شوید\n"
        "2️⃣ لینک پست یا ریل اینستاگرام را ارسال کنید\n"
        "3️⃣ صبر کنید تا ربات فایل را دانلود و ارسال کند\n\n"
        "⚠️ در صورت بروز مشکل از دکمه «گزارش مشکل» استفاده کنید",
        reply_markup=get_main_keyboard()
    )

def get_admin_keyboard():
    """ساخت کیبورد پنل ادمین"""
    keyboard = [
        [
            InlineKeyboardButton("📊 آمار", callback_data="admin_stats"),
            InlineKeyboardButton("💬 پیام همگانی", callback_data="admin_broadcast")
        ],
        [
            InlineKeyboardButton("👥 مدیریت کاربران", callback_data="admin_users"),
            InlineKeyboardButton("🔒 امنیت", callback_data="admin_security")
        ],
        [
            InlineKeyboardButton("📝 گزارشات", callback_data="admin_reports"),
            InlineKeyboardButton("💾 پشتیبان‌گیری", callback_data="admin_backup")
        ],
        [
            InlineKeyboardButton("⚙️ تنظیمات", callback_data="admin_settings")
        ]
    ]
    return keyboard

def get_user_management_keyboard():
    """دکمه‌های بخش مدیریت کاربران"""
    keyboard = [
        [InlineKeyboardButton("📋 لیست کاربران", callback_data="admin_user_list:0")],
        [InlineKeyboardButton("🔒 مسدود کردن", callback_data="admin_ban_user"),
         InlineKeyboardButton("🔓 رفع مسدودیت", callback_data="admin_unban_user")],
        [InlineKeyboardButton("⚠️ اخطار", callback_data="admin_warn_user"),
         InlineKeyboardButton("📊 آمار کاربر", callback_data="admin_user_stats")],
        [InlineKeyboardButton("📝 یادداشت", callback_data="admin_add_note"),
         InlineKeyboardButton("🔍 جستجو", callback_data="admin_search_user")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_security_keyboard():
    """دکمه‌های بخش امنیت"""
    keyboard = [
        [InlineKeyboardButton("🔍 بررسی فعالیت مشکوک", callback_data="admin_check_suspicious"),
         InlineKeyboardButton("🛡 تنظیمات امنیتی", callback_data="admin_security_settings")],
        [InlineKeyboardButton("⚠️ گزارشات اسپم", callback_data="admin_spam_reports"),
         InlineKeyboardButton("🔒 محدودیت‌ها", callback_data="admin_restrictions")],
        [InlineKeyboardButton("👥 کاربران مورد اعتماد", callback_data="admin_trusted_users"),
         InlineKeyboardButton("⛔️ لیست سیاه", callback_data="admin_blacklist")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_reports_keyboard():
    """دکمه‌های بخش گزارشات"""
    keyboard = [
        [InlineKeyboardButton("📊 گزارشات اخیر", callback_data="admin_recent_reports"),
         InlineKeyboardButton("⚠️ اخطارهای فعال", callback_data="admin_active_warnings")],
        [InlineKeyboardButton("🔍 جستجو در گزارشات", callback_data="admin_search_reports"),
         InlineKeyboardButton("📝 یادداشت‌های ادمین", callback_data="admin_admin_notes")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_backup_keyboard():
    """دکمه‌های بخش پشتیبان‌گیری"""
    keyboard = [
        [InlineKeyboardButton("💾 تهیه نسخه پشتیبان", callback_data="admin_create_backup"),
         InlineKeyboardButton("📥 بازیابی از پشتیبان", callback_data="admin_restore_backup")],
        [InlineKeyboardButton("📋 لیست نسخه‌های پشتیبان", callback_data="admin_list_backups"),
         InlineKeyboardButton("🗑 حذف پشتیبان‌ها", callback_data="admin_delete_backups")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_settings_keyboard():
    """دکمه‌های بخش تنظیمات"""
    keyboard = [
        [InlineKeyboardButton("⚙️ تنظیمات عمومی", callback_data="admin_general_settings"),
         InlineKeyboardButton("🛡 تنظیمات امنیتی", callback_data="admin_security_settings")],
        [InlineKeyboardButton("📊 تنظیمات آمار", callback_data="admin_stats_settings"),
         InlineKeyboardButton("💬 تنظیمات پیام‌ها", callback_data="admin_message_settings")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """هندلر دستور /admin"""
    user_id = update.effective_user.id

    if not await is_admin(user_id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return

    keyboard = get_admin_keyboard()

    await update.message.reply_text(
        "🔰 <b>پنل مدیریت</b>\n\n"
        "به پنل مدیریت ربات خوش آمدید.\n"
        "از دکمه‌های زیر برای مدیریت ربات استفاده کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def handle_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """هندلر برای callback های پنل ادمین"""
    query = update.callback_query
    await query.answer()

    if not await is_admin(query.from_user.id):
        await query.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return

    if query.data == "admin_stats":

        total_users = len(data['stats']['users'])
        total_downloads = data['stats']['total_downloads']
        successful_downloads = data.get('stats', {}).get('successful_downloads', 0)
        failed_downloads = data.get('stats', {}).get('failed_downloads', 0)


        now = datetime.now()
        active_users = 0
        for user_id, stats in data['user_stats'].items():
            last_activity = stats.get('last_download')
            if last_activity and last_activity != 'هیچوقت':
                try:
                    last_activity_time = datetime.strptime(last_activity, '%Y-%m-%d %H:%M:%S')
                    if (now - last_activity_time).total_seconds() < 24 * 3600:
                        active_users += 1
                except:
                    continue


        success_rate = (successful_downloads / total_downloads * 100) if total_downloads > 0 else 0
        first_download = min([stats.get('join_date', now.strftime('%Y-%m-%d %H:%M:%S'))
                            for stats in data['user_stats'].values()])
        try:
            first_download_date = datetime.strptime(first_download, '%Y-%m-%d %H:%M:%S')
            days_active = max(1, (now - first_download_date).days)
            avg_daily_downloads = total_downloads / days_active
        except:
            avg_daily_downloads = 0

        stats_text = (
            "📊 <b>آمار کلی ربات:</b>\n\n"
            f"👥 <b>کاربران:</b>\n"
            f"└─ کل کاربران: <code>{total_users:,}</code>\n"
            f"└─ کاربران فعال 24h: <code>{active_users:,}</code>\n\n"
            f"📥 <b>دانلودها:</b>\n"
            f"└─ کل دانلودها: <code>{total_downloads:,}</code>\n"
            f"└─ دانلودهای موفق: <code>{successful_downloads:,}</code>\n"
            f"└─ دانلودهای ناموفق: <code>{failed_downloads:,}</code>\n"
            f"└─ نرخ موفقیت: <code>{success_rate:.1f}%</code>\n"
            f"└─ میانگین روزانه: <code>{avg_daily_downloads:.1f}</code>\n\n"
            f"📅 <b>زمان فعالیت:</b>\n"
            f"└─ روزهای فعال: <code>{days_active:,}</code> روز\n"
        )

        keyboard = [
            [InlineKeyboardButton("📈 نمودار فعالیت", callback_data="admin_stats_graph")],
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="admin_stats")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
        ]

        try:
            await query.message.edit_text(
                stats_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except Exception as e:
            logger.error(f"خطا در نمایش آمار: {str(e)}")
            await query.message.reply_text(
                "❌ خطا در نمایش آمار. لطفا دوباره تلاش کنید.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]])
            )
        return

    elif query.data == "admin_broadcast":
        guide_message = await query.message.reply_text(
            "💬 <b>ارسال پیام همگانی</b>\n\n"
            "پیام خود را ارسال کنید. این پیام برای تمام کاربران ارسال خواهد شد.\n\n"
            "برای لغو عملیات از دستور /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['broadcast_guide_message'] = guide_message
        return AWAITING_BROADCAST

    elif query.data == "admin_back":
        keyboard = get_admin_keyboard()
        await query.message.edit_text(
            "🔰 <b>پنل مدیریت</b>\n\n"
            "به پنل مدیریت ربات خوش آمدید.\n"
            "از دکمه‌های زیر برای مدیریت ربات استفاده کنید:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        return

    elif query.data == "admin_users":

        await query.message.edit_text(
            "👥 <b>مدیریت کاربران</b>\n\n"
            "از گزینه‌های زیر انتخاب کنید:",
            reply_markup=get_user_management_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_security":

        suspicious_count = len(data['suspicious'])
        blocked_count = len(data['blocked_users'])
        trusted_count = len(data['trusted'])

        security_text = (
            "🛡 <b>امنیت و محدودیت‌ها</b>\n\n"
            f"⚠️ کاربران مشکوک: <b>{suspicious_count}</b>\n"
            f"🔒 کاربران مسدود: <b>{blocked_count}</b>\n"
            f"✅ کاربران مورد اعتماد: <b>{trusted_count}</b>\n\n"
            "از گزینه‌های زیر انتخاب کنید:"
        )

        await query.message.edit_text(
            security_text,
            reply_markup=get_security_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_reports":

        recent_reports = len(data['reports'][-10:]) if data['reports'] else 0
        active_warnings = sum(len(warnings) for warnings in data['warnings'].values())

        reports_text = (
            "📋 <b>گزارشات و اخطارها</b>\n\n"
            f"📝 گزارشات اخیر: <b>{recent_reports}</b>\n"
            f"⚠️ اخطارهای فعال: <b>{active_warnings}</b>\n\n"
            "از گزینه‌های زیر انتخاب کنید:"
        )

        await query.message.edit_text(
            reports_text,
            reply_markup=get_reports_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_backup":

        await query.message.edit_text(
            "💾 <b>پشتیبان‌گیری و بازیابی</b>\n\n"
            "از گزینه‌های زیر انتخاب کنید:",
            reply_markup=get_backup_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_settings":

        await query.message.edit_text(
            "⚙️ <b>تنظیمات ربات</b>\n\n"
            "از گزینه‌های زیر انتخاب کنید:",
            reply_markup=get_settings_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_check_suspicious":

        suspicious_users = list(data['suspicious'])
        if not suspicious_users:
            text = "✅ هیچ کاربر مشکوکی یافت نشد."
        else:
            text = "⚠️ <b>لیست کاربران مشکوک:</b>\n\n"
            for user_id in suspicious_users[:10]:  # نمایش 10 کاربر اول
                downloads = data['user_stats'].get(user_id, {}).get('total_downloads', 0)
                text += f"👤 کاربر: <code>{user_id}</code>\n📥 دانلودها: {downloads}\n\n"

        await query.message.edit_text(
            text,
            reply_markup=get_security_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_spam_reports":

        if not data['spam_reports']:
            text = "✅ هیچ گزارش اسپمی ثبت نشده است."
        else:
            text = "⚠️ <b>گزارشات اسپم اخیر:</b>\n\n"
            for report in list(data['spam_reports'].values())[-5:]:  # 5 گزارش آخر
                text += f"👤 کاربر: <code>{report['user_id']}</code>\n"
                text += f"⏰ زمان: {report['time']}\n"
                text += f"📝 دلیل: {report['reason']}\n\n"

        await query.message.edit_text(
            text,
            reply_markup=get_security_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_trusted_users":

        trusted_users = list(data['trusted'])
        if not trusted_users:
            text = "❌ هیچ کاربر مورد اعتمادی ثبت نشده است."
        else:
            text = "✅ <b>لیست کاربران مورد اعتماد:</b>\n\n"
            for user_id in trusted_users[:10]:  # 10 کاربر اول
                downloads = data['user_stats'].get(user_id, {}).get('total_downloads', 0)
                text += f"👤 کاربر: <code>{user_id}</code>\n📥 دانلودها: {downloads}\n\n"

        await query.message.edit_text(
            text,
            reply_markup=get_security_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_blacklist":

        blocked_users = list(data['blocked_users'])
        if not blocked_users:
            text = "✅ هیچ کاربری در لیست سیاه نیست."
        else:
            text = "⛔️ <b>لیست کاربران مسدود شده:</b>\n\n"
            for user_id in blocked_users[:10]:  # 10 کاربر اول
                warnings = len(data['warnings'].get(user_id, []))
                text += f"👤 کاربر: <code>{user_id}</code>\n⚠️ اخطارها: {warnings}\n\n"

        await query.message.edit_text(
            text,
            reply_markup=get_security_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_create_backup":

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = f"backup_{timestamp}.json"

        try:
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            await query.message.edit_text(
                f"✅ نسخه پشتیبان با موفقیت ایجاد شد:\n<code>{backup_file}</code>",
                reply_markup=get_backup_keyboard(),
                parse_mode='HTML'
            )
        except Exception as e:
            await query.message.edit_text(
                f"❌ خطا در ایجاد نسخه پشتیبان:\n<code>{str(e)}</code>",
                reply_markup=get_backup_keyboard(),
                parse_mode='HTML'
            )

    elif query.data == "admin_list_backups":

        backup_files = [f for f in os.listdir('.') if f.startswith('backup_') and f.endswith('.json')]

        if not backup_files:
            text = "❌ هیچ نسخه پشتیبانی یافت نشد."
        else:
            text = "📋 <b>لیست نسخه‌های پشتیبان:</b>\n\n"
            for file in backup_files:
                size = os.path.getsize(file) / 1024  # KB
                created = datetime.fromtimestamp(os.path.getctime(file)).strftime("%Y-%m-%d %H:%M:%S")
                text += f"📁 <code>{file}</code>\n"
                text += f"📅 تاریخ: {created}\n"
                text += f"📊 حجم: {size:.1f} KB\n\n"

        await query.message.edit_text(
            text,
            reply_markup=get_backup_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_delete_backups":

        backup_files = [f for f in os.listdir('.') if f.startswith('backup_') and f.endswith('.json')]
        deleted = 0

        for file in backup_files:
            try:
                os.remove(file)
                deleted += 1
            except:
                continue

        await query.message.edit_text(
            f"✅ {deleted} نسخه پشتیبان با موفقیت حذف شد.",
            reply_markup=get_backup_keyboard(),
            parse_mode='HTML'
        )

    elif query.data == "admin_back":

        active_users_24h = len(data['stats']['last_24h_users'])
        total_users = len(data['stats']['users'])
        suspicious_users = len(data['suspicious'])
        blocked_users = len(data['blocked_users'])
        success_rate = (data['stats']['successful_downloads'] / data['stats']['total_downloads'] * 100) if data['stats']['total_downloads'] > 0 else 0

        await query.message.edit_text(
            f"🎛 <b>پنل مدیریت پیشرفته ربات</b>\n\n"
            f"📊 آمار لحظه‌ای:\n"
            f"👥 کاربران فعال 24h: {active_users_24h}\n"
            f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
            f"💫 کل کاربران: {total_users}\n"
            f"⚠️ کاربران مشکوک: {suspicious_users}\n"
            f"🔒 کاربران مسدود: {blocked_users}\n\n"
            "از دکمه‌های زیر استفاده کنید:",
            reply_markup=get_admin_keyboard(),
            parse_mode='HTML'
        )

    elif query.data.startswith("admin_user_list:"):
        try:
            page = int(query.data.split(":")[1])
            users_list = list(data['stats']['users'])
            per_page = 5  # کاهش تعداد کاربران در هر صفحه برای نمایش اطلاعات بیشتر
            total_pages = (len(users_list) - 1) // per_page + 1 if users_list else 1
            start_idx = page * per_page
            end_idx = start_idx + per_page

            current_users = users_list[start_idx:end_idx]


            total_users = len(users_list)
            active_24h = len(data['stats']['last_24h_users'])
            blocked_count = len(data['blocked_users'])

            text = (
                "📊 <b>آمار کلی کاربران:</b>\n"
                f"👥 کل کاربران: <b>{total_users:,}</b>\n"
                f"✅ فعال در 24h: <b>{active_24h:,}</b>\n"
                f"🔒 مسدود شده: <b>{blocked_count:,}</b>\n"
                "━━━━━━━━━━━━━━━━\n\n"
            )

            if not current_users:
                text += "❌ هیچ کاربری یافت نشد!"
            else:
                text += "👥 <b>لیست کاربران:</b>\n\n"
                for user_id in current_users:
                    user_stats = data['user_stats'].get(user_id, {})
                    downloads = user_stats.get('total_downloads', 0)
                    last_active = user_stats.get('last_download', 'نامشخص')
                    join_date = user_stats.get('join_date', 'نامشخص')
                    warnings = len(data['warnings'].get(user_id, []))
                    is_suspicious = "⚠️" if user_id in data['suspicious'] else ""
                    is_trusted = "💎" if user_id in data['trusted'] else ""


                    if user_id in data['blocked_users']:
                        status = "🔒 مسدود"
                        status_color = "red"
                    elif user_id in data['stats']['last_24h_users']:
                        status = "✅ فعال"
                        status_color = "green"
                    else:
                        status = "💤 غیرفعال"
                        status_color = "gray"


                    if last_active != 'نامشخص':
                        try:
                            last_active_date = datetime.strptime(last_active, '%Y-%m-%d %H:%M:%S')
                            now = datetime.now()
                            diff = now - last_active_date
                            if diff.days == 0:
                                if diff.seconds < 3600:
                                    last_seen = f"{diff.seconds // 60} دقیقه پیش"
                                else:
                                    last_seen = f"{diff.seconds // 3600} ساعت پیش"
                            elif diff.days == 1:
                                last_seen = "دیروز"
                            else:
                                last_seen = f"{diff.days} روز پیش"
                        except:
                            last_seen = last_active
                    else:
                        last_seen = "نامشخص"

                    text += (
                        f"🆔 <code>{user_id}</code> {is_suspicious}{is_trusted}\n"
                        f"⭐️ <b>وضعیت:</b> {status}\n"
                        f"📅 <b>تاریخ عضویت:</b> {join_date}\n"
                        f"⏰ <b>آخرین فعالیت:</b> {last_seen}\n"
                        f"📊 <b>آمار:</b>\n"
                        f"   📥 دانلودها: {downloads:,}\n"
                        f"   ⚠️ اخطارها: {warnings}\n"
                    )


                    notes = data['admin_notes'].get(user_id, [])
                    if notes:
                        last_note = notes[-1]
                        text += f"📝 <b>آخرین یادداشت:</b> {last_note['note'][:30]}...\n"

                    text += "━━━━━━━━━━━━━━━━\n\n"


            keyboard = []
            nav_row = []

            if page > 0:
                nav_row.append(InlineKeyboardButton("⬅️ قبلی", callback_data=f"admin_user_list:{page-1}"))

            page_btn = InlineKeyboardButton(f"📄 {page + 1} از {total_pages}", callback_data="ignore")
            nav_row.append(page_btn)

            if end_idx < len(users_list):
                nav_row.append(InlineKeyboardButton("بعدی ➡️", callback_data=f"admin_user_list:{page+1}"))

            if nav_row:
                keyboard.append(nav_row)


            keyboard.extend([
                [InlineKeyboardButton("🔍 جستجو", callback_data="admin_search_user"),
                 InlineKeyboardButton("⚙️ فیلتر", callback_data="admin_filter_users")],
                [InlineKeyboardButton("🔒 مسدود کردن", callback_data="admin_ban_user"),
                 InlineKeyboardButton("⚠️ اخطار", callback_data="admin_warn_user")],
                [InlineKeyboardButton("📝 یادداشت جدید", callback_data="admin_add_note"),
                 InlineKeyboardButton("📊 آمار کامل", callback_data="admin_user_stats")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
            ])

            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )

        except Exception as e:
            logger.error(f"Error in user list: {str(e)}")
            await query.message.edit_text(
                "❌ خطا در نمایش لیست کاربران!\n"
                "لطفاً دوباره تلاش کنید.",
                reply_markup=get_user_management_keyboard()
            )

    elif query.data == "admin_ban_user":
        await query.message.edit_text(
            "🔒 <b>مسدود کردن کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'ban'
        return AWAITING_USER_ID

    elif query.data == "admin_unban_user":

        blocked = list(data['blocked_users'])
        if not blocked:
            text = "✅ هیچ کاربر مسدودی وجود ندارد."
        else:
            text = "🔒 <b>کاربران مسدود شده:</b>\n\n"
            for user_id in blocked[:10]:  # نمایش 10 کاربر اول
                warnings = len(data['warnings'].get(user_id, []))
                text += f"👤 کاربر: <code>{user_id}</code>\n"
                text += f"⚠️ تعداد اخطار: {warnings}\n"
                text += "➖➖➖➖➖➖➖➖➖➖\n"

            text += "\nآیدی کاربر مورد نظر برای رفع مسدودیت را وارد کنید:"

        await query.message.edit_text(text, parse_mode='HTML')
        context.user_data['admin_action'] = 'unban'
        return AWAITING_USER_ID

    elif query.data == "admin_warn_user":
        await query.message.edit_text(
            "⚠️ <b>ثبت اخطار</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'warn'
        return AWAITING_USER_ID

    elif query.data == "admin_user_stats":
        await query.message.edit_text(
            "📊 <b>آمار کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'stats'
        return AWAITING_USER_ID

    elif query.data == "admin_add_note":
        await query.message.edit_text(
            "📝 <b>افزودن یادداشت</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'note'
        return AWAITING_USER_ID

    elif query.data == "admin_search_user":
        await query.message.edit_text(
            "🔍 <b>جستجوی کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'search'
        return AWAITING_USER_ID

    context.user_data['admin_action'] = query.data.split(":")[0]
    return "ADMIN_USER_ACTION"

def get_file_size(url: str) -> str:
    try:
        response = requests.head(url)
        size_bytes = int(response.headers.get('content-length', 0))
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
    except:
        return "نامشخص"

async def handle_instagram_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    first_name = update.effective_user.first_name or "کاربر"
    url = update.message.text

    progress_message = await update.message.reply_text(
        "╭─────────────────────────╮\n"
        "│   🔄 درحال پردازش...   │\n"
        "├─────────────────────────┤\n"
        "│ 📥 دریافت اطلاعات پست  │\n"
        "│ ⏳ لطفاً صبر کنید...   │\n"
        "╰─────────────────────────╯\n\n"
        "🔹 درحال اتصال به سرور\n"
        "🔹 بررسی نوع محتوا\n"
        "🔹 آماده‌سازی برای دانلود",
        parse_mode='HTML'
    )

    try:

        await progress_message.edit_text(
            "╭─────────────────────────╮\n"
            "│    ⬇️ درحال دانلود    │\n"
            "├─────────────────────────┤\n"
            "│ 📥 دریافت محتوا        │\n"
            "│ ⌛️ چند لحظه صبر کنید  │\n"
            "╰─────────────────────────╯\n\n"
            "🔹 اتصال برقرار شد\n"
            "🔹 درحال دریافت فایل\n"
            "🔹 لطفاً شکیبا باشید..."
        )

        result = download_instagram(url)
        if result['status'] == 'error':

            await progress_message.edit_text(
                "╭─────────────────────────╮\n"
                "│    ❌ خطا در دانلود    │\n"
                "├─────────────────────────┤\n"
                "│ 🚫 دانلود ناموفق بود   │\n"
                "╰─────────────────────────╯\n\n"
                f"📝 دلیل خطا:\n{result['message']}"
            )
            return


        data['stats']['total_downloads'] += 1
        data['stats']['successful_downloads'] += 1
        user_stats = data['user_stats'].setdefault(user_id, {})
        user_stats['total_downloads'] = user_stats.get('total_downloads', 0) + 1
        user_stats['last_download'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        save_data()

        file_type = "ویدیو 🎥" if result['media_type'] == 'video' else "عکس 🖼"
        now = datetime.now()
        download_date = now.strftime('%Y-%m-%d')
        download_time = now.strftime('%H:%M:%S')
        user_id_str = str(user_id)
        user_downloads = user_stats.get('total_downloads', 1)
        file_size = get_file_size(result['download_url'])

        caption = (
            "╭─────────────────────────╮\n"
            "│   ✅ دانلود موفق   │\n"
            "╰─────────────────────────╯\n\n"
            "📦 <b>مشخصات فایل:</b>\n"
            f"├─ نوع: {file_type}\n"
            f"├─ حجم: <code>{file_size}</code>\n"
            f"├─ تاریخ: <code>{download_date}</code>\n"
            f"└─ ساعت: <code>{download_time}</code>\n\n"
            "👤 <b>اطلاعات کاربر:</b>\n"
            f"├─ نام: <code>{first_name}</code>\n"
            f"├─ شناسه: <code>{user_id_str}</code>\n"
            f"└─ تعداد دانلود: <code>{user_downloads}</code>\n\n"
            "📱 <b>اشتراک‌گذاری:</b>\n"
            "└─ برای اشتراک‌گذاری، این پیام را فوروارد کنید\n\n"
            f"🤖 @{BOT_USERNAME}"
        )

        post_url = url
        bot_link = f"https://t.me/{BOT_USERNAME}"

        keyboard = [
            [InlineKeyboardButton("⭐️ حمایت از ما", url="https://t.me/testinstadownloaderbots")],
            [InlineKeyboardButton("🎁 دعوت دوستان", url=bot_link)]
        ]

        if result['media_type'] == 'video':
            await update.message.reply_video(
                result['download_url'],
                caption=caption,
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await update.message.reply_photo(
                result['download_url'],
                caption=caption,
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )

        await progress_message.delete()
    except Exception as e:

        await progress_message.edit_text(
            "╭─────────────────────────╮\n"
            "│    ❌ خطای سیستمی     │\n"
            "├─────────────────────────┤\n"
            "│ 🚫 دانلود ناموفق بود   │\n"
            "╰─────────────────────────╯\n\n"
            f"📝 جزئیات خطا:\n{str(e)}"
        )

async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر ارسال پیام همگانی"""
    user_id = update.effective_user.id
    if not await is_admin(user_id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    if not update.message or not update.message.text:
        await update.message.reply_text("❌ لطفا یک پیام متنی ارسال کنید.")
        return AWAITING_BROADCAST

    message = update.message.text


    guide_message = context.user_data.get('broadcast_guide_message')
    if guide_message:
        try:
            await guide_message.delete()
        except Exception as e:
            logger.error(f"خطا در حذف پیام راهنما: {str(e)}")
        context.user_data.pop('broadcast_guide_message', None)


    progress_msg = await update.message.reply_text(
        "⏳ در حال ارسال پیام همگانی...\n"
        "🔄 لطفاً صبر کنید..."
    )

    success_count = 0
    fail_count = 0
    failed_users = []

    total_users = len(data['stats']['users'])
    processed = 0

    try:

        for user_id in list(data['stats']['users']):  
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"📢 <b>پیام مهم از طرف مدیریت:</b>\n\n{message}",
                    parse_mode='HTML'
                )
                success_count += 1
            except Exception as e:
                logger.error(f"خطا در ارسال پیام به کاربر {user_id}: {str(e)}")
                fail_count += 1
                failed_users.append(user_id)

            processed += 1
            if processed % 5 == 0:  
                try:
                    await progress_msg.edit_text(
                        f"⏳ در حال ارسال پیام همگانی...\n"
                        f"📊 پیشرفت: {processed}/{total_users}\n"
                        f"✅ موفق: {success_count}\n"
                        f"❌ ناموفق: {fail_count}"
                    )
                except Exception as e:
                    logger.error(f"خطا در بروزرسانی پیام پیشرفت: {str(e)}")

    except Exception as e:
        logger.error(f"خطای کلی در ارسال پیام همگانی: {str(e)}")
        await progress_msg.edit_text(
            "❌ خطا در ارسال پیام همگانی. لطفا دوباره تلاش کنید."
        )
        return ConversationHandler.END

    success_rate = (success_count/total_users*100) if total_users > 0 else 0
    report = (
        "📊 <b>گزارش ارسال پیام همگانی:</b>\n\n"
        f"👥 کل کاربران: {total_users:,}\n"
        f"✅ ارسال موفق: {success_count:,}\n"
        f"❌ ارسال ناموفق: {fail_count:,}\n"
        f"📈 نرخ موفقیت: {success_rate:.1f}%\n\n"
    )

    if failed_users:
        report += "❌ <b>کاربران ناموفق:</b>\n"
        for user_id in failed_users[:10]: 
            report += f"• <code>{user_id}</code>\n"
        if len(failed_users) > 10:
            report += f"و {len(failed_users) - 10} کاربر دیگر..."

    keyboard = [
        [InlineKeyboardButton("🔙 بازگشت به پنل ادمین", callback_data="admin_back")]
    ]

    try:
        await progress_msg.delete()
    except:
        pass

    await update.message.reply_text(
        report,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

    return ConversationHandler.END

def create_activity_charts():
    """ایجاد نمودارهای فعالیت"""

    plt.clf()  


    daily_stats = defaultdict(int)
    hourly_stats = defaultdict(int)

    for user_id, stats in data['user_stats'].items():
        if 'last_download' in stats:
            try:
                download_time = datetime.strptime(stats['last_download'], '%Y-%m-%d %H:%M:%S')
                date_key = download_time.strftime('%Y-%m-%d')
                hour_key = download_time.hour
                daily_stats[date_key] += 1
                hourly_stats[hour_key] += 1
            except:
                continue


    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))


    dates = sorted(daily_stats.keys())[-7:]  
    values = [daily_stats[date] for date in dates]

    dates_fa = [get_display(arabic_reshaper.reshape(datetime.strptime(d, '%Y-%m-%d').strftime('%Y/%m/%d'))) for d in dates]

    ax1.bar(dates_fa, values, color='skyblue')
    ax1.set_title(get_display(arabic_reshaper.reshape('نمودار فعالیت روزانه (7 روز اخیر)')), fontsize=14, pad=10)
    ax1.set_xlabel(get_display(arabic_reshaper.reshape('تاریخ')), fontsize=12)
    ax1.set_ylabel(get_display(arabic_reshaper.reshape('تعداد دانلود')), fontsize=12)
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')

    hours = range(24)
    hour_values = [hourly_stats[hour] for hour in hours]

    ax2.bar(hours, hour_values, color='lightgreen')
    ax2.set_title(get_display(arabic_reshaper.reshape('نمودار فعالیت ساعتی')), fontsize=14, pad=10)
    ax2.set_xlabel(get_display(arabic_reshaper.reshape('ساعت')), fontsize=12)
    ax2.set_ylabel(get_display(arabic_reshaper.reshape('تعداد دانلود')), fontsize=12)
    ax2.set_xticks(hours)

    plt.tight_layout()


    img_buffer = BytesIO()
    plt.savefig(img_buffer, format='png', bbox_inches='tight', dpi=300)
    img_buffer.seek(0)

    return img_buffer

async def admin_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """نمایش آمار کامل ربات"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return


    progress_msg = await update.message.reply_text(
        "⏳ در حال آماده‌سازی آمار...\n"
        "🔄 لطفاً صبر کنید..."
    )

    try:

        total_users = len(data['stats']['users'])
        active_users_24h = len(data['stats']['last_24h_users'])
        total_downloads = data['stats']['total_downloads']
        successful_downloads = data['stats']['successful_downloads']
        failed_downloads = data['stats']['failed_downloads']


        avg_downloads_per_user = total_downloads / total_users if total_users > 0 else 0
        success_rate = (successful_downloads / total_downloads * 100) if total_downloads > 0 else 0


        blocked_users = len(data['blocked_users'])
        suspicious_users = len(data['suspicious'])
        trusted_users = len(data['trusted'])


        stats_text = (
            "📊 <b>آمار کلی ربات:</b>\n\n"

            "👥 <b>کاربران:</b>\n"
            f"├─ کل کاربران: <code>{total_users:,}</code>\n"
            f"├─ کاربران فعال 24h: <code>{active_users_24h:,}</code>\n"
            f"├─ کاربران مسدود: <code>{blocked_users:,}</code>\n"
            f"├─ کاربران مشکوک: <code>{suspicious_users:,}</code>\n"
            f"└─ کاربران مورد اعتماد: <code>{trusted_users:,}</code>\n\n"

            "📥 <b>دانلودها:</b>\n"
            f"├─ کل دانلودها: <code>{total_downloads:,}</code>\n"
            f"├─ دانلودهای موفق: <code>{successful_downloads:,}</code>\n"
            f"├─ دانلودهای ناموفق: <code>{failed_downloads:,}</code>\n"
            f"├─ نرخ موفقیت: <code>{success_rate:.1f}%</code>\n"
            f"└─ میانگین دانلود هر کاربر: <code>{avg_downloads_per_user:.1f}</code>\n\n"

            "⚡️ <b>عملکرد سیستم:</b>\n"
            f"├─ پردازش‌های موفق: <code>{successful_downloads:,}</code>\n"
            f"└─ خطاهای سیستمی: <code>{len(data['errors']):,}</code>"
        )


        charts = create_activity_charts()


        await update.message.reply_photo(
            photo=charts,
            caption=stats_text,
            parse_mode='HTML'
        )

        await progress_msg.delete()

    except Exception as e:
        logger.error(f"Error in admin_stats: {str(e)}")
        await progress_msg.edit_text(
            f"❌ خطا در تهیه آمار:\n{str(e)}"
        )

async def handle_admin_user_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر اکشن‌های مدیریت کاربران"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    action = context.user_data.get('admin_action')
    if not action:
        await update.message.reply_text("❌ عملیات نامشخص است!")
        return ConversationHandler.END

    try:
        user_id = int(update.message.text)

        # بررسی وجود کاربر
        if user_id not in data['stats']['users'] and action not in ['unban']:
            await update.message.reply_text(
                "❌ کاربر مورد نظر در دیتابیس یافت نشد!\n"
                "برای بازگشت به منو از /admin استفاده کنید."
            )
            return ConversationHandler.END

        if action == 'ban':
            if user_id in data['blocked_users']:
                keyboard = [
                    [InlineKeyboardButton("🔓 رفع مسدودیت", callback_data=f"admin_unban_{user_id}")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
                ]
                await update.message.reply_text(
                    f"❌ کاربر <code>{user_id}</code> قبلاً مسدود شده است!\n"
                    "می‌توانید از دکمه زیر برای رفع مسدودیت استفاده کنید.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            else:
                data['blocked_users'].add(user_id)
                save_data() 
                keyboard = [
                    [InlineKeyboardButton("⚠️ ثبت اخطار", callback_data=f"admin_warn_{user_id}")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
                ]
                await update.message.reply_text(
                    f"✅ کاربر <code>{user_id}</code> مسدود شد.\n"
                    "می‌توانید برای این کاربر اخطار نیز ثبت کنید.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
                try:
                    await context.bot.send_message(
                        chat_id=user_id,
                        text="⛔️ شما از استفاده از ربات محروم شده‌اید!\n"
                             "در صورت اعتراض می‌توانید با پشتیبانی تماس بگیرید."
                    )
                except:
                    await update.message.reply_text("⚠️ نتوانستم به کاربر اطلاع‌رسانی کنم.")

        elif action == 'unban':
            if user_id not in data['blocked_users']:
                await update.message.reply_text(
                    "❌ این کاربر در لیست مسدودیت نیست!\n"
                    "برای بازگشت به منو از /admin استفاده کنید."
                )
            else:
                data['blocked_users'].remove(user_id)
                save_data() 
                keyboard = [
                    [InlineKeyboardButton("📝 افزودن یادداشت", callback_data=f"admin_note_{user_id}")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
                ]
                await update.message.reply_text(
                    f"✅ محدودیت کاربر <code>{user_id}</code> برداشته شد.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
                try:
                    await context.bot.send_message(
                        chat_id=user_id,
                        text="✅ محدودیت شما از ربات برداشته شد!\n"
                             "می‌توانید دوباره از ربات استفاده کنید."
                    )
                except:
                    await update.message.reply_text("⚠️ نتوانستم به کاربر اطلاع‌رسانی کنم.")

        elif action == 'warn':
            context.user_data['warn_user_id'] = user_id
            keyboard = [[InlineKeyboardButton("🔙 انصراف", callback_data="admin_back")]]
            await update.message.reply_text(
                "📝 لطفاً دلیل اخطار را وارد کنید:\n"
                "می‌توانید از دکمه انصراف برای لغو استفاده کنید.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return AWAITING_WARN_REASON

        elif action == 'stats':
            user_stats = data['user_stats'].get(user_id, {})
            warnings = data['warnings'].get(user_id, [])
            is_blocked = "🔒 بله" if user_id in data['blocked_users'] else "✅ خیر"
            is_suspicious = "⚠️ بله" if user_id in data['suspicious'] else "✅ خیر"
            is_trusted = "💎 بله" if user_id in data['trusted'] else "❌ خیر"


            total_downloads = user_stats.get('total_downloads', 0)
            last_download = user_stats.get('last_download', 'هیچوقت')
            join_date = user_stats.get('join_date', 'نامشخص')


            if last_download != 'هیچوقت':
                try:
                    last_download_date = datetime.strptime(last_download, '%Y-%m-%d %H:%M:%S')
                    now = datetime.now()
                    diff = now - last_download_date
                    if diff.days == 0:
                        if diff.seconds < 3600:
                            last_seen = f"{diff.seconds // 60} دقیقه پیش"
                        else:
                            last_seen = f"{diff.seconds // 3600} ساعت پیش"
                    elif diff.days == 1:
                        last_seen = "دیروز"
                    else:
                        last_seen = f"{diff.days} روز پیش"
                except:
                    last_seen = last_download
            else:
                last_seen = "هیچوقت"

            stats_text = (
                f"📊 <b>آمار کاربر</b> <code>{user_id}</code>\n\n"
                "👤 <b>اطلاعات کلی:</b>\n"
                f"├─ تاریخ عضویت: {join_date}\n"
                f"├─ آخرین فعالیت: {last_seen}\n"
                f"└─ وضعیت: {'🟢 فعال' if user_id in data['stats']['last_24h_users'] else '⚫️ غیرفعال'}\n\n"
                "📥 <b>آمار دانلود:</b>\n"
                f"├─ کل دانلودها: {total_downloads}\n"
                f"└─ میانگین روزانه: {total_downloads // max(1, (datetime.now() - datetime.strptime(join_date, '%Y-%m-%d %H:%M:%S')).days) if join_date != 'نامشخص' else 0}\n\n"
                "⚠️ <b>وضعیت امنیتی:</b>\n"
                f"├─ تعداد اخطار: {len(warnings)}\n"
                f"├─ وضعیت مسدودیت: {is_blocked}\n"
                f"├─ وضعیت مشکوک: {is_suspicious}\n"
                f"└─ کاربر مورد اعتماد: {is_trusted}\n\n"
            )


            if warnings:
                stats_text += "🚫 <b>لیست اخطارها:</b>\n"
                for i, warning in enumerate(warnings[-3:], 1):  # نمایش 3 اخطار آخر
                    stats_text += f"{i}. {warning['reason']} ({warning['time']})\n"
                if len(warnings) > 3:
                    stats_text += f"... و {len(warnings) - 3} اخطار دیگر\n"
                stats_text += "\n"


            notes = data['admin_notes'].get(user_id, [])
            if notes:
                stats_text += "📝 <b>یادداشت‌های اخیر:</b>\n"
                for note in notes[-2:]:  # نمایش 2 یادداشت آخر
                    stats_text += f"• {note['note']} ({note['time']})\n"
                if len(notes) > 2:
                    stats_text += f"... و {len(notes) - 2} یادداشت دیگر\n"

            keyboard = [
                [InlineKeyboardButton("⚠️ ثبت اخطار", callback_data=f"admin_warn_{user_id}"),
                 InlineKeyboardButton("📝 یادداشت جدید", callback_data=f"admin_note_{user_id}")],
                [InlineKeyboardButton("🔒 مسدود کردن" if user_id not in data['blocked_users'] else "🔓 رفع مسدودیت",
                                    callback_data=f"admin_{'ban' if user_id not in data['blocked_users'] else 'unban'}_{user_id}")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
            ]

            await update.message.reply_text(
                stats_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )

        elif action == 'note':
            context.user_data['note_user_id'] = user_id
            keyboard = [[InlineKeyboardButton("🔙 انصراف", callback_data="admin_back")]]
            await update.message.reply_text(
                "📝 لطفاً یادداشت خود را وارد کنید:\n"
                "می‌توانید از دکمه انصراف برای لغو استفاده کنید.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return AWAITING_NOTE

        elif action == 'search':

            user_stats = data['user_stats'].get(user_id, {})
            warnings = data['warnings'].get(user_id, [])
            notes = data['admin_notes'].get(user_id, [])
            is_blocked = user_id in data['blocked_users']
            is_suspicious = user_id in data['suspicious']
            is_trusted = user_id in data['trusted']

            search_text = (
                f"🔍 <b>نتیجه جستجو برای کاربر</b> <code>{user_id}</code>\n\n"
                "👤 <b>وضعیت کاربر:</b>\n"
                f"├─ وضعیت: {'🟢 فعال' if user_id in data['stats']['last_24h_users'] else '⚫️ غیرفعال'}\n"
                f"├─ مسدودیت: {'🔒 مسدود' if is_blocked else '✅ آزاد'}\n"
                f"├─ اعتماد: {'💎 مورد اعتماد' if is_trusted else '❌ عادی'}\n"
                f"└─ امنیت: {'⚠️ مشکوک' if is_suspicious else '✅ عادی'}\n\n"
                "📊 <b>آمار فعالیت:</b>\n"
                f"├─ تعداد دانلود: {user_stats.get('total_downloads', 0)}\n"
                f"├─ تاریخ عضویت: {user_stats.get('join_date', 'نامشخص')}\n"
                f"└─ آخرین فعالیت: {user_stats.get('last_download', 'نامشخص')}\n\n"
            )

            if warnings:
                search_text += "⚠️ <b>اخطارها:</b>\n"
                for warning in warnings[-3:]:  # نمایش 3 اخطار آخر
                    search_text += f"• {warning['reason']} ({warning['time']})\n"
                if len(warnings) > 3:
                    search_text += f"... و {len(warnings) - 3} اخطار دیگر\n"
                search_text += "\n"

            if notes:
                search_text += "📝 <b>یادداشت‌های ادمین:</b>\n"
                for note in notes[-2:]:  # نمایش 2 یادداشت آخر
                    search_text += f"• {note['note']} ({note['time']})\n"
                if len(notes) > 2:
                    search_text += f"... و {len(notes) - 2} یادداشت دیگر\n"

            keyboard = [
                [InlineKeyboardButton("📊 آمار کامل", callback_data=f"admin_stats_{user_id}")],
                [InlineKeyboardButton("⚠️ ثبت اخطار", callback_data=f"admin_warn_{user_id}"),
                 InlineKeyboardButton("📝 یادداشت جدید", callback_data=f"admin_note_{user_id}")],
                [InlineKeyboardButton("🔒 مسدود کردن" if not is_blocked else "🔓 رفع مسدودیت",
                                    callback_data=f"admin_{'ban' if not is_blocked else 'unban'}_{user_id}")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
            ]

            await update.message.reply_text(
                search_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )

    except ValueError:
        await update.message.reply_text(
            "❌ لطفاً یک عدد معتبر وارد کنید!\n"
            "برای بازگشت به منو از /admin استفاده کنید."
        )
        return ConversationHandler.END

    return ConversationHandler.END

async def handle_admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر پاسخ ادمین به کاربر"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    user_id = context.user_data.get('reply_to')
    if not user_id:
        await update.message.reply_text("❌ خطا در ارسال پیام!")
        return ConversationHandler.END

    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"📨 پیام از طرف ادمین:\n\n{update.message.text}"
        )
        await update.message.reply_text("✅ پیام با موفقیت ارسال شد!")
    except Exception as e:
        await update.message.reply_text(f"❌ خطا در ارسال پیام: {str(e)}")

    return ConversationHandler.END

async def handle_warn_reason(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر ثبت دلیل اخطار"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    user_id = context.user_data.get('warn_user_id')
    if not user_id:
        await update.message.reply_text("❌ خطا در ثبت اخطار!")
        return ConversationHandler.END

    reason = update.message.text
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    if user_id not in data['warnings']:
        data['warnings'][user_id] = []

    data['warnings'][user_id].append({
        'reason': reason,
        'time': timestamp,
        'by_admin': update.effective_user.id
    })

    save_data()  


    warning_count = len(data['warnings'][user_id])
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"⚠️ شما یک اخطار جدید دریافت کردید!\n\n"
                 f"📝 دلیل: {reason}\n"
                 f"⏰ زمان: {timestamp}\n"
                 f"🔢 تعداد اخطار: {warning_count}/3\n\n"
                 "⚠️ دریافت 3 اخطار منجر به مسدودیت خودکار خواهد شد."
        )
    except:
        pass

    keyboard = [
        [InlineKeyboardButton("📊 مشاهده آمار کاربر", callback_data=f"admin_stats_{user_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]

    await update.message.reply_text(
        f"✅ اخطار با موفقیت ثبت شد!\n\n"
        f"👤 کاربر: <code>{user_id}</code>\n"
        f"⚠️ تعداد اخطارها: {warning_count}/3\n"
        f"📝 آخرین دلیل: {reason}",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )


    if warning_count >= 3 and user_id not in data['blocked_users']:
        data['blocked_users'].add(user_id)
        save_data()

        await update.message.reply_text(
            f"🔒 کاربر {user_id} به دلیل دریافت {warning_count} اخطار، "
            "به طور خودکار مسدود شد!"
        )

        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="⛔️ به دلیل دریافت بیش از حد مجاز اخطار (3 اخطار)، "
                     "دسترسی شما به ربات مسدود شد.\n\n"
                     "برای درخواست رفع مسدودیت با پشتیبانی تماس بگیرید."
            )
        except:
            pass

    return ConversationHandler.END

async def handle_admin_note(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر ثبت یادداشت ادمین"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    user_id = context.user_data.get('note_user_id')
    if not user_id:
        await update.message.reply_text("❌ خطا در ثبت یادداشت!")
        return ConversationHandler.END

    note = update.message.text
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    if user_id not in data['admin_notes']:
        data['admin_notes'][user_id] = []

    data['admin_notes'][user_id].append({
        'note': note,
        'time': timestamp,
        'by_admin': update.effective_user.id
    })

    save_data() 

    keyboard = [
        [InlineKeyboardButton("📊 مشاهده آمار کاربر", callback_data=f"admin_stats_{user_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
    ]

    await update.message.reply_text(
        f"✅ یادداشت با موفقیت ثبت شد!\n\n"
        f"👤 کاربر: <code>{user_id}</code>\n"
        f"📝 یادداشت: {note}\n"
        f"⏰ زمان: {timestamp}",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """هندلر لغو عملیات"""
    await update.message.reply_text(
        "❌ عملیات لغو شد!",
        reply_markup=get_admin_keyboard()
    )
    return ConversationHandler.END

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """هندلر دکمه‌های اینلاین عمومی"""
    query = update.callback_query
    await query.answer()

    if query.data == "send_link":
        await query.message.edit_text(
            "🔗 لینک پست یا ریل اینستاگرام رو برام بفرست\n"
            "مثال:\n"
            "https://www.instagram.com/p/xxx\n"
            "https://www.instagram.com/reel/xxx",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")
            ]]),
            parse_mode='HTML'
        )

    elif query.data == "help":
        help_text = (
            "🔰 <b>راهنمای استفاده از ربات:</b>\n\n"
            "1️⃣ لینک پست یا ریل رو کپی کنید\n"
            "2️⃣ لینک رو برای ربات بفرستید\n"
            "3️⃣ صبر کنید تا فایل دانلود و ارسال بشه\n\n"
            "🔗 <b>لینک‌های پشتیبانی شده:</b>\n"
            "├─ پست‌های عکس و ویدیو\n"
            "├─ ریلز و IGTV\n"
            "├─ استوری و هایلایت\n"
            "└─ عکس پروفایل\n\n"
            "⚠️ در صورت بروز مشکل از دکمه «گزارش مشکل» استفاده کنید"
        )
        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
        await query.message.edit_text(
            help_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    elif query.data == "my_stats":
        user_id = query.from_user.id
        user_stats = data['user_stats'].get(user_id, {})
        total_downloads = user_stats.get('total_downloads', 0)
        join_date = user_stats.get('join_date', 'نامشخص')
        last_download = user_stats.get('last_download', 'هیچوقت')

        # محاسبه زمان عضویت
        if join_date != 'نامشخص':
            join_datetime = datetime.strptime(join_date, '%Y-%m-%d %H:%M:%S')
            membership_days = (datetime.now() - join_datetime).days
        else:
            membership_days = 0


        if last_download != 'هیچوقت':
            last_download_datetime = datetime.strptime(last_download, '%Y-%m-%d %H:%M:%S')
            time_diff = datetime.now() - last_download_datetime
            if time_diff.days == 0:
                if time_diff.seconds < 3600:
                    last_seen = f"{time_diff.seconds // 60} دقیقه پیش"
                else:
                    last_seen = f"{time_diff.seconds // 3600} ساعت پیش"
            elif time_diff.days == 1:
                last_seen = "دیروز"
            else:
                last_seen = f"{time_diff.days} روز پیش"
        else:
            last_seen = "هیچوقت"

        stats_text = (
            "📊 <b>آمار شخصی شما:</b>\n\n"
            f"📅 تاریخ عضویت: <code>{join_date}</code>\n"
            f"⏰ مدت عضویت: <code>{membership_days}</code> روز\n"
            f"📥 تعداد دانلود: <code>{total_downloads:,}</code>\n"
            f"🕒 آخرین دانلود: <code>{last_seen}</code>\n\n"
            "📈 <b>وضعیت شما:</b>\n"
            f"├─ رتبه: {'🥇 VIP' if total_downloads > 1000 else '🥈 حرفه‌ای' if total_downloads > 100 else '🥉 معمولی'}\n"
            f"└─ وضعیت: {'✅ فعال' if user_id in data['stats'].get('last_24h_users', set()) else '💤 غیرفعال'}"
        )

        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
        await query.message.edit_text(
            stats_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    elif query.data == "status":
        now = datetime.now()
        uptime = now - datetime.strptime(data['user_stats'].get(BOT_USERNAME, {}).get('join_date', now.strftime('%Y-%m-%d %H:%M:%S')), '%Y-%m-%d %H:%M:%S')

        status_text = (
            "📡 <b>وضعیت ربات:</b>\n\n"
            "⚡️ <b>سرویس‌ها:</b>\n"
            "├─ دانلودر: ✅ فعال\n"
            "├─ آپلودر: ✅ فعال\n"
            "└─ API: ✅ فعال\n\n"
            "🔄 <b>عملکرد:</b>\n"
            f"├─ آپتایم: {uptime.days} روز و {uptime.seconds//3600} ساعت\n"
            f"├─ سرعت پردازش: ⚡️ عالی\n"
            f"└─ وضعیت سرور: 🟢 آنلاین\n\n"
            "📊 <b>امروز:</b>\n"
            f"├─ دانلود موفق: {len(data['stats'].get('last_24h_users', set())):,}\n"
            f"└─ کاربران فعال: {len(data['stats'].get('last_24h_users', set())):,}"
        )

        keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
        await query.message.edit_text(
            status_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    elif query.data == "invite_friends":
        share_text = (
            "🌟 ربات دانلودر اینستاگرام\n\n"
            "📥 دانلود استوری، پست، ریل و IGTV\n"
            "⚡️ سریع و بدون محدودیت\n"
            "✨ کاملاً رایگان\n\n"
            f"🤖 @{BOT_USERNAME}"
        )
        keyboard = [
            [InlineKeyboardButton("📤 اشتراک‌گذاری", switch_inline_query=share_text)],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
        ]
        await query.message.edit_text(
            "🤝 برای دعوت از دوستان، این پیام را برایشان فوروارد کنید:\n\n" + share_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    elif query.data == "main_menu":

        keyboard = [
            [
                InlineKeyboardButton("📥 دانلود از اینستاگرام", callback_data="send_link"),
                InlineKeyboardButton("ℹ️ راهنما", callback_data="help")
            ],
            [
                InlineKeyboardButton("📊 آمار من", callback_data="my_stats"),
                InlineKeyboardButton("⚡️ وضعیت ربات", callback_data="status")
            ],
            [
                InlineKeyboardButton("💎 کانال ما", url=f"https://t.me/{CHANNEL_USERNAME}"),
                InlineKeyboardButton("🤝 دعوت دوستان", callback_data="invite_friends")
            ]
        ]
        await query.message.edit_text(
            "🤖 به ربات دانلودر اینستاگرام خوش آمدید!\n"
            "از دکمه‌های زیر استفاده کنید:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )

    elif query.data == "admin_broadcast_retry":
        await query.message.edit_text(
            "💬 <b>ارسال پیام همگانی</b>\n\n"
            "پیام خود را ارسال کنید. این پیام برای تمام کاربران ارسال خواهد شد.\n\n"
            "برای لغو عملیات از دستور /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        return AWAITING_BROADCAST

    elif query.data == "admin_back":

        active_users_24h = len(data['stats']['last_24h_users'])
        total_users = len(data['stats']['users'])
        suspicious_users = len(data['suspicious'])
        blocked_users = len(data['blocked_users'])
        success_rate = (data['stats']['successful_downloads'] / data['stats']['total_downloads'] * 100) if data['stats']['total_downloads'] > 0 else 0

        await query.message.edit_text(
            f"🎛 <b>پنل مدیریت پیشرفته ربات</b>\n\n"
            f"📊 آمار لحظه‌ای:\n"
            f"👥 کاربران فعال 24h: {active_users_24h}\n"
            f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
            f"💫 کل کاربران: {total_users}\n"
            f"⚠️ کاربران مشکوک: {suspicious_users}\n"
            f"🔒 کاربران مسدود: {blocked_users}\n\n"
            "از دکمه‌های زیر استفاده کنید:",
            reply_markup=get_admin_keyboard(),
            parse_mode='HTML'
        )

    elif query.data.startswith("admin_user_list:"):
        try:
            page = int(query.data.split(":")[1])
            users_list = list(data['stats']['users'])
            per_page = 5 
            total_pages = (len(users_list) - 1) // per_page + 1 if users_list else 1
            start_idx = page * per_page
            end_idx = start_idx + per_page

            current_users = users_list[start_idx:end_idx]


            total_users = len(users_list)
            active_24h = len(data['stats']['last_24h_users'])
            blocked_count = len(data['blocked_users'])

            text = (
                "📊 <b>آمار کلی کاربران:</b>\n"
                f"👥 کل کاربران: <b>{total_users:,}</b>\n"
                f"✅ فعال در 24h: <b>{active_24h:,}</b>\n"
                f"🔒 مسدود شده: <b>{blocked_count:,}</b>\n"
                "━━━━━━━━━━━━━━━━\n\n"
            )

            if not current_users:
                text += "❌ هیچ کاربری یافت نشد!"
            else:
                text += "👥 <b>لیست کاربران:</b>\n\n"
                for user_id in current_users:
                    user_stats = data['user_stats'].get(user_id, {})
                    downloads = user_stats.get('total_downloads', 0)
                    last_active = user_stats.get('last_download', 'نامشخص')
                    join_date = user_stats.get('join_date', 'نامشخص')
                    warnings = len(data['warnings'].get(user_id, []))
                    is_suspicious = "⚠️" if user_id in data['suspicious'] else ""
                    is_trusted = "💎" if user_id in data['trusted'] else ""

                    if user_id in data['blocked_users']:
                        status = "🔒 مسدود"
                        status_color = "red"
                    elif user_id in data['stats']['last_24h_users']:
                        status = "✅ فعال"
                        status_color = "green"
                    else:
                        status = "💤 غیرفعال"
                        status_color = "gray"

                    if last_active != 'نامشخص':
                        try:
                            last_active_date = datetime.strptime(last_active, '%Y-%m-%d %H:%M:%S')
                            now = datetime.now()
                            diff = now - last_active_date
                            if diff.days == 0:
                                if diff.seconds < 3600:
                                    last_seen = f"{diff.seconds // 60} دقیقه پیش"
                                else:
                                    last_seen = f"{diff.seconds // 3600} ساعت پیش"
                            elif diff.days == 1:
                                last_seen = "دیروز"
                            else:
                                last_seen = f"{diff.days} روز پیش"
                        except:
                            last_seen = last_active
                    else:
                        last_seen = "نامشخص"

                    text += (
                        f"🆔 <code>{user_id}</code> {is_suspicious}{is_trusted}\n"
                        f"⭐️ <b>وضعیت:</b> {status}\n"
                        f"📅 <b>تاریخ عضویت:</b> {join_date}\n"
                        f"⏰ <b>آخرین فعالیت:</b> {last_seen}\n"
                        f"📊 <b>آمار:</b>\n"
                        f"   📥 دانلودها: {downloads:,}\n"
                        f"   ⚠️ اخطارها: {warnings}\n"
                    )

                    notes = data['admin_notes'].get(user_id, [])
                    if notes:
                        last_note = notes[-1]
                        text += f"📝 <b>آخرین یادداشت:</b> {last_note['note'][:30]}...\n"

                    text += "━━━━━━━━━━━━━━━━\n\n"


            keyboard = []
            nav_row = []

            if page > 0:
                nav_row.append(InlineKeyboardButton("⬅️ قبلی", callback_data=f"admin_user_list:{page-1}"))

            page_btn = InlineKeyboardButton(f"📄 {page + 1} از {total_pages}", callback_data="ignore")
            nav_row.append(page_btn)

            if end_idx < len(users_list):
                nav_row.append(InlineKeyboardButton("بعدی ➡️", callback_data=f"admin_user_list:{page+1}"))

            if nav_row:
                keyboard.append(nav_row)


            keyboard.extend([
                [InlineKeyboardButton("🔍 جستجو", callback_data="admin_search_user"),
                 InlineKeyboardButton("⚙️ فیلتر", callback_data="admin_filter_users")],
                [InlineKeyboardButton("🔒 مسدود کردن", callback_data="admin_ban_user"),
                 InlineKeyboardButton("⚠️ اخطار", callback_data="admin_warn_user")],
                [InlineKeyboardButton("📝 یادداشت جدید", callback_data="admin_add_note"),
                 InlineKeyboardButton("📊 آمار کامل", callback_data="admin_user_stats")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
            ])

            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )

        except Exception as e:
            logger.error(f"Error in user list: {str(e)}")
            await query.message.edit_text(
                "❌ خطا در نمایش لیست کاربران!\n"
                "لطفاً دوباره تلاش کنید.",
                reply_markup=get_user_management_keyboard()
            )

    elif query.data == "admin_ban_user":
        await query.message.edit_text(
            "🔒 <b>مسدود کردن کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'ban'
        return AWAITING_USER_ID

    elif query.data == "admin_unban_user":

        blocked = list(data['blocked_users'])
        if not blocked:
            text = "✅ هیچ کاربر مسدودی وجود ندارد."
        else:
            text = "🔒 <b>کاربران مسدود شده:</b>\n\n"
            for user_id in blocked[:10]:  # نمایش 10 کاربر اول
                warnings = len(data['warnings'].get(user_id, []))
                text += f"👤 کاربر: <code>{user_id}</code>\n"
                text += f"⚠️ تعداد اخطار: {warnings}\n"
                text += "➖➖➖➖➖➖➖➖➖➖\n"

            text += "\nآیدی کاربر مورد نظر برای رفع مسدودیت را وارد کنید:"

        await query.message.edit_text(text, parse_mode='HTML')
        context.user_data['admin_action'] = 'unban'
        return AWAITING_USER_ID

    elif query.data == "admin_warn_user":
        await query.message.edit_text(
            "⚠️ <b>ثبت اخطار</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'warn'
        return AWAITING_USER_ID

    elif query.data == "admin_user_stats":
        await query.message.edit_text(
            "📊 <b>آمار کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'stats'
        return AWAITING_USER_ID

    elif query.data == "admin_add_note":
        await query.message.edit_text(
            "📝 <b>افزودن یادداشت</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'note'
        return AWAITING_USER_ID

    elif query.data == "admin_search_user":
        await query.message.edit_text(
            "🔍 <b>جستجوی کاربر</b>\n\n"
            "آیدی عددی کاربر را وارد کنید:\n"
            "برای لغو از /cancel استفاده کنید.",
            parse_mode='HTML'
        )
        context.user_data['admin_action'] = 'search'
        return AWAITING_USER_ID

    context.user_data['admin_action'] = query.data.split(":")[0]
    return "ADMIN_USER_ACTION"

async def handle_ban_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handler for confirming user ban"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    try:
        confirm = update.message.text.lower()
        user_id = context.user_data.get('ban_user_id')

        if not user_id:
            await update.message.reply_text("❌ خطا در عملیات مسدودسازی!")
            return ConversationHandler.END

        if confirm in ['yes', 'بله', 'تایید']:
            if user_id not in data['blocked_users']:
                data['blocked_users'].add(user_id)
                save_data()

                keyboard = [
                    [InlineKeyboardButton("⚠️ ثبت اخطار", callback_data=f"admin_warn_{user_id}")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
                ]

                await update.message.reply_text(
                    f"✅ کاربر <code>{user_id}</code> با موفقیت مسدود شد.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )

                try:
                    await context.bot.send_message(
                        chat_id=user_id,
                        text="⛔️ شما از استفاده از ربات محروم شده‌اید!\n"
                             "در صورت اعتراض می‌توانید با پشتیبانی تماس بگیرید."
                    )
                except:
                    await update.message.reply_text("⚠️ نتوانستم به کاربر اطلاع‌رسانی کنم.")
            else:
                await update.message.reply_text("❌ این کاربر قبلاً مسدود شده است!")
        else:
            await update.message.reply_text("❌ عملیات مسدودسازی لغو شد.")

    except Exception as e:
        await update.message.reply_text(f"❌ خطا در عملیات: {str(e)}")

    return ConversationHandler.END

async def handle_unban_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handler for confirming user unban"""
    if not await is_admin(update.effective_user.id):
        await update.message.reply_text("⛔️ شما دسترسی به این بخش ندارید!")
        return ConversationHandler.END

    try:
        confirm = update.message.text.lower()
        user_id = context.user_data.get('unban_user_id')

        if not user_id:
            await update.message.reply_text("❌ خطا در عملیات رفع مسدودیت!")
            return ConversationHandler.END

        if confirm in ['yes', 'بله', 'تایید']:
            if user_id in data['blocked_users']:
                data['blocked_users'].remove(user_id)
                save_data()

                keyboard = [
                    [InlineKeyboardButton("📝 افزودن یادداشت", callback_data=f"admin_note_{user_id}")],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_back")]
                ]

                await update.message.reply_text(
                    f"✅ محدودیت کاربر <code>{user_id}</code> برداشته شد.",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )

                try:
                    await context.bot.send_message(
                        chat_id=user_id,
                        text="✅ محدودیت شما از ربات برداشته شد!\n"
                             "می‌توانید دوباره از ربات استفاده کنید."
                    )
                except:
                    await update.message.reply_text("⚠️ نتوانستم به کاربر اطلاع‌رسانی کنم.")
            else:
                await update.message.reply_text("❌ این کاربر در لیست مسدودیت نیست!")
        else:
            await update.message.reply_text("❌ عملیات رفع مسدودیت لغو شد.")

    except Exception as e:
        await update.message.reply_text(f"❌ خطا در عملیات: {str(e)}")

    return ConversationHandler.END

def main() -> None:
    """راه اندازی ربات"""
    print('Bot is Running ...')
    logger.info("Starting bot...")


    load_data()


    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    application = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('admin', admin_command),
            CallbackQueryHandler(handle_admin_callback, pattern='^admin_')
        ],
        states={
            AWAITING_BROADCAST: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_broadcast)],
            AWAITING_USER_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_user_action)],
            AWAITING_REPLY: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_reply)],
            AWAITING_WARN_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_warn_reason)],
            AWAITING_NOTE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_note)]
        },
        fallbacks=[
            CommandHandler('cancel', cancel),
            CallbackQueryHandler(handle_admin_callback, pattern='^admin_')
        ],
        per_message=False,
        name='admin_conversation'
    )

    # اضافه کردن هندلرها
    application.add_handler(conv_handler)
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("stats", admin_stats_command))

 
    application.add_handler(CallbackQueryHandler(handle_callback))


    application.add_handler(MessageHandler(
        filters.Regex(r"instagram\.com/(?:p|reel)/"), handle_instagram_url
    ))


    application.run_polling()

if __name__ == '__main__':
    main()