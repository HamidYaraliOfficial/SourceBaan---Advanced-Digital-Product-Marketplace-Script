from medoo import Medoo

db = Medoo(dbtype='sqlite', database='database.db')

db.query('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        ban TEXT NOT NULL,
        step TEXT NOT NULL
    )
''')

db.query('''
    CREATE TABLE IF NOT EXISTS settings (
        id VARCHAR(2) PRIMARY KEY,
        bot TEXT NOT NULL
    )
''')

if db.has('settings',where={'id': 1}):
    pass
else:
    db.insert('settings','id,bot',(1,'on'))