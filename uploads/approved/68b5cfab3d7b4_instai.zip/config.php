<?php

date_default_timezone_set('Asia/Tehran');

/* -------------------------------------------------- */
define('API_KEY', '6395222301:AAFHZmmPMaicUnxC9upBu-3C0dbwe02xmck');  /* توکن ربات باید بزاری */
define('BOT_USERNAME', 'downloaderinstaomegabot'); /* یوزرنیم ربات بدون @ */
define('INSTA_KEY', '6652480168:1VSzX45svga@CodeSazan_APIManager_Bot'); /* کلید وبسرویس اینستاگرام کد بازان را قرار دهید دریافت از طریق: https://t.me/CodeSazan_APIManager_Bot */
$admins = [ # ایدی عددی ادمین ها ( مطابق الگو بزارید *)
    6555947551,
    6555947551,
    6555947551,
]; 
$database = [
    'database' => 'citytea1_rezaomeg', /* اسم دیتابیس */
    'username' => 'citytea1_rezaomeg', /* یوزرنیم دیتابیس */
    'password' => 'parhamabasi.12' /* پسورد دیتابیس */
];
/* -------------------------------------------------- */

$keyboard = [
    'panel' => [
        ['📈 آمار لحظه ای ربات'],
        ['🔐 قفل چنل ها', '📮 ارسال همگانی'],
        ['🏠']
    ],
    'back' => [
        ['🏠']
    ],
    'back_panel' => [
        ['🔙 بازگشت به پنل']
    ],
    'back_channels' => [
        ['🔙 بازگشت به مدیریت چنل']
    ], 
    'locks' => [
        ['🔧 مدیریت چنل ها','➕ افزودن چنل'],
        ['🔙 بازگشت به پنل']
    ]
];

$BPTSettings = [
    'handler' => [
        'token' => API_KEY,
        /**
                    " نکته مهم "
            * بدلیل محدودیت های وبسرویس تلگرام
            * امکان آپلود ویدیو هایی که حجم بالان فراهم نیست
            * برای رفع این مشکل شما باید یک سرور مجازی داشته باشید و 
            * لوکال وبسرویس تلگرام رو روش نصب کنید
            * سپس بجای api.telegra.org آیپی سرورتون که روش نصب کردید رو بزارید
            * برای نصب کردن لوکال وبسرویس این داکیومنت رو از گیتهاب مطالعه کنید :
            * https://github.com/tdlib/telegram-bot-api
         */
        'base_url' => 'https://api.telegram.org/bot', 
        'multi' => false,
        'allowed_updates' => [
            'update_id', 
            'message', 
            'callback_query', 
            'inline_query', 
            'my_chat_member', 
            'chat_member',
        ],
        'secure_folder' => false,
        'debug' => false,
    ],
    'public' => [
        'token' => API_KEY,
        'receive' => 'none',
        'handler' => false,
        'secure_folder' => false
    ],
];
$time =         time();
$connect =      new MySQLi('localhost', $database['username'], $database['password'], $database['database']);
$connect->set_charset('utf8mb4');