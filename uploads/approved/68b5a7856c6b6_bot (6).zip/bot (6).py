# -*- coding: utf-8 -*-
import os
import ast
import operator as op
import telebot
from telebot import types

# ---------- توکن تنظیمات ----------
# ---------- telegram id : @Cod_ASHI ----------
TOKEN = os.getenv("BOT_TOKEN", "PUT YOUR TELEGRAM BOT TOKEN HERE")
bot = telebot.TeleBot(TOKEN, parse_mode="HTML")

# حالت هر چت را نگه می‌داریم (عبارت فعلی)
STATE = {}  # chat_id -> {"expr": str, "msg_id": int}

# ---------- محاسبه‌ی امن ----------
ALLOWED_OPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
    # اگر توان یا باقیمانده خواستی اینجا اضافه کن
}
ALLOWED_NODES = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant, ast.Expr, ast.Load, ast.Subscript)

def safe_eval(expr: str) -> float:
    """
    عبارت ریاضی را به صورت امن محاسبه می‌کند.
    فقط + - * / و یوناری‌ها مجازند.
    """
    # جایگزینی ضرب/تقسیم یونیکدی با معادل پایتون
    expr = expr.replace("×", "*").replace("÷", "/")
    node = ast.parse(expr, mode="eval")

    def _eval(n):
        if isinstance(n, ast.Expression):
            return _eval(n.body)
        if isinstance(n, ast.Num):  # Py<3.8
            return n.n
        if isinstance(n, ast.Constant):
            if isinstance(n.value, (int, float)):
                return n.value
            raise ValueError("Invalid constant")
        if isinstance(n, ast.BinOp):
            left = _eval(n.left)
            right = _eval(n.right)
            op_type = type(n.op)
            if op_type not in ALLOWED_OPS:
                raise ValueError("Operator not allowed")
            if op_type is ast.Div and right == 0:
                raise ZeroDivisionError("Division by zero")
            return ALLOWED_OPS[op_type](left, right)
        if isinstance(n, ast.UnaryOp):
            operand = _eval(n.operand)
            op_type = type(n.op)
            if op_type not in ALLOWED_OPS:
                raise ValueError("Unary operator not allowed")
            return ALLOWED_OPS[op_type](operand)
        raise ValueError("Bad expression")

    return _eval(node)

# ---------- ابزارهای کمکی ----------
DIGITS = set("0123456789")
OPS = set("+-×÷")
PARENS = set("()")

def pretty(expr: str):
    """
    متن نمایش: سطر اول عبارت، سطر دوم نتیجه (اگر قابل محاسبه باشد).
    """
    if not expr:
        return "0"
    view = expr
    try:
        # فقط وقتی نتیجه را نشان بده که عبارت کامل باشد
        if is_expression_complete(expr):
            result = safe_eval(expr)
            if result is not None:
                # حذف .0 اضافه
                if abs(result - int(result)) < 1e-12:
                    result = int(result)
                return f"{view}\n<b>= {result}</b>"
    except Exception:
        pass
    return view

def is_expression_complete(expr: str) -> bool:
    """بررسی تعادل پرانتز و پایان نیافتن به عملگر/نقطه."""
    if not expr:
        return False
    # پرانتزها
    bal = 0
    for ch in expr:
        if ch == "(":
            bal += 1
        elif ch == ")":
            bal -= 1
            if bal < 0:
                return False
    if bal != 0:
        return False
    # پایان معتبر
    if expr[-1] in OPS or expr[-1] == "." or expr[-1] == "(":
        return False
    return True

def can_append(expr: str, token: str) -> bool:
    """قوانین جلوگیری از باگ‌های رایج."""
    if token in DIGITS:
        # جلوگیری از صفرهای ابتدایی بی‌مورد مثل 0002
        if expr.endswith("0") and (len(expr) == 1 or expr[-2] in OPS + {"("}) and token != ".":
            # اجازه 0 بعد از 0 فقط اگر اعشاری شود
            return True
        return True
    if token in OPS:
        if not expr:
            # شروع با + یا - مجاز، با × یا ÷ مجاز نیست
            return token in "+-"
        if expr[-1] in OPS or expr[-1] == "(" or expr[-1] == ".":
            return False
        return True
    if token == ".":
        # یک اعشار در هر عدد
        i = len(expr) - 1
        while i >= 0 and expr[i] not in OPS and expr[i] not in PARENS:
            if expr[i] == ".":
                return False
            i -= 1
        if not expr or expr[-1] in OPS + {"("}:
            # شروع عدد اعشاری با 0.
            return True
        return True
    if token == "(":
        if not expr:
            return True
        # قبل از "(" فقط عملگر یا "(" بیاید
        return (expr[-1] in OPS) or (expr[-1] == "(")
    if token == ")":
        # باید تعداد "(" بیشتر باشد و قبلش چیزی معنادار بیاید
        if not expr:
            return False
        bal = 0
        for ch in expr:
            if ch == "(":
                bal += 1
            elif ch == ")":
                bal -= 1
        if bal <= 0:
            return False
        if expr[-1] in OPS or expr[-1] == "(" or expr[-1] == ".":
            return False
        return True
    if token == "=":
        return is_expression_complete(expr)
    return True

def apply_token(expr: str, token: str) -> str:
    if token == "C":
        return ""
    if token == "⌫":
        return expr[:-1]
    if token in {"=", "Close"}:
        return expr
    if can_append(expr, token):
        # تبدیل × ÷ به نسخه نمایشی خودش بماند؛ محاسبه تبدیل می‌کند
        if token == "." and (not expr or expr[-1] in OPS or expr[-1] == "("):
            return expr + "0."
        return expr + token
    return expr

# ---------- کیبورد ----------
def make_kb():
    kb = types.InlineKeyboardMarkup(row_width=4)
    rows = [
        ["7", "8", "9", "÷"],
        ["4", "5", "6", "×"],
        ["1", "2", "3", "−"],   # نمایش «−» قشنگ‌تره ولی در داده callback از "-" استفاده می‌کنیم
        ["0", ".", "=", "+"],
        ["(", ")", "⌫", "C"],
    ]
    # چون منفی خوش‌نویس «−» با یونیکد جداست، روی دکمه نشان می‌دهیم ولی callback را "-" می‌گذاریم
    btns = []
    mapping = {"−": "-"}
    for row in rows:
        kb.row(*[
            types.InlineKeyboardButton(text=txt, callback_data=mapping.get(txt, txt))
            for txt in row
        ])
    kb.add(types.InlineKeyboardButton("Close", callback_data="Close"))
    return kb

# ---------- روت‌ها ----------
@bot.message_handler(commands=["start"])
def start(m: types.Message):
    chat_id = m.chat.id
    STATE[chat_id] = {"expr": ""}
    text = "🧮 <b>Calculator Menu Ready</b>\n" + pretty("")
    msg = bot.send_message(chat_id, text, reply_markup=make_kb())
    STATE[chat_id]["msg_id"] = msg.message_id

@bot.callback_query_handler(func=lambda c: True)
def on_press(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    if chat_id not in STATE:
        STATE[chat_id] = {"expr": "", "msg_id": call.message.message_id}

    token = call.data
    expr = STATE[chat_id]["expr"]

    if token == "Close":
        try:
            bot.edit_message_reply_markup(chat_id, STATE[chat_id]["msg_id"], reply_markup=None)
        except Exception:
            pass
        bot.answer_callback_query(call.id, "Closed")
        return

    if token == "=":
        if is_expression_complete(expr):
            try:
                result = safe_eval(expr)
                if abs(result - int(result)) < 1e-12:
                    result = int(result)
                bot.answer_callback_query(call.id, "Done")
                # پیام جداگانه شبیه نمونه: «x = y»
                bot.send_message(chat_id, f"{expr}\n<b>= {result}</b>")
            except ZeroDivisionError:
                bot.answer_callback_query(call.id, "❌ Division by zero", show_alert=True)
            except Exception:
                bot.answer_callback_query(call.id, "❌ Invalid expression", show_alert=True)
        else:
            bot.answer_callback_query(call.id, "❌ Incomplete expression", show_alert=True)
        return

    # اعمال توکن و رفرش UI
    new_expr = apply_token(expr, token)
    STATE[chat_id]["expr"] = new_expr
    new_text = "🧮 <b>Calculator Menu Ready</b>\n" + pretty(new_expr)

    try:
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=STATE[chat_id]["msg_id"],
            text=new_text,
            reply_markup=make_kb(),
            parse_mode="HTML"
        )
    except Exception:
        # اگر کاربر پیام را دستکاری/پاک کرد، یک پیام جدید می‌سازیم
        msg = bot.send_message(chat_id, new_text, reply_markup=make_kb())
        STATE[chat_id]["msg_id"] = msg.message_id

    # پاسخ کوتاه برای حس کلیک
    if token in {"+", "-", "×", "÷", "(", ")", ".", "⌫"} or token in DIGITS:
        bot.answer_callback_query(call.id, token)
    else:
        bot.answer_callback_query(call.id)

# ---------- اجرا ----------
if __name__ == "__main__":
    print("Bot is running ...")
    bot.infinity_polling(skip_pending=True, timeout=30)