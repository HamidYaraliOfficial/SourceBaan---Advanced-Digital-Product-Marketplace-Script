<?php
/*
نویسنده  : @devbc
کانال  : سورس کده
*/
#-----------------------------#
date_default_timezone_set('Asia/Tehran');
error_reporting(0);
#-----------------------------#
$token = "e34P9i8"; //توکن
$channel = "@Sourrce_Kade"; //ایدی کانال که گزارشات ارسال بشه با @
//ربات حتما ادمین کانال باید باشه
#-----------------------------#
define('API_KEY', $token);
#-----------------------------#
$update = json_decode(file_get_contents("php://input"));
if(isset($update->message)){
    $from_id    = $update->message->from->id;
    $chat_id    = $update->message->chat->id;
    $tc         = $update->message->chat->type;
    $text       = $update->message->text;
    $first_name = $update->message->from->first_name;
    $message_id = $update->message->message_id;
}elseif(isset($update->callback_query)){
    $chat_id    = $update->callback_query->message->chat->id;
    $data       = $update->callback_query->data;
    $query_id   = $update->callback_query->id;
    $message_id = $update->callback_query->message->message_id;
    $in_text    = $update->callback_query->message->text;
    $from_id    = $update->callback_query->from->id;
}
#-----------------------------#
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
#-----------------------------#
function sendmessage($chat_id,$text,$keyboard = null) {
    bot('sendMessage',[
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "HTML",
        'disable_web_page_preview' => true,
        'reply_markup' => $keyboard
    ]);
}
#-----------------------------#
if($text == "/start"){
sendmessage ($chat_id , "
ربات فعال سازی شد . لطفا مرا در کانال یا گروه تنظیم شده ادمین کنید .

توجه کنید که اگر میخواهید قیمت ارز ها را در کانال ارسال کنم ایدی کانال را همراه با @ تنظیم کنید اگر میخواهید در گروه ارسال کنم ایدی گروه را تنظیم کنید .
");
}
#-----------------------------#
/*
نویسنده  : @devbc
کانال  : سورس کده
*/
?>