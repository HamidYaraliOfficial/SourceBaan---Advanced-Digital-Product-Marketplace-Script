<?php
///  @Sourrce_Kade
include ("bot.php");
$web = file_get_contents ("http://api.codebazan.ir/arz/?type=arz");
$w = json_decode ($web,true);
$dolar = $w["Result"]["0"]["price"];
$euro = $w["Result"]["1"]["price"];
$derham = $w["Result"]["2"]["price"];
$pond = $w["Result"]["3"]["price"];
$lir = $w["Result"]["4"]["price"];
$dolar1 = str_replace(',', '', $dolar);
$web = file_get_contents ("http://haji-api.ir/arzDigital");
$a = json_decode ($web,true);
$ttr = $a["result"]["tether"];
$tron = $a["result"]["tron"];
$a2 = $ttr * $dolar1;
$a3 = $tron * $dolar1;
$bc = round($a3);
$key1 = json_encode(['inline_keyboard' => [
[['text'=>"زمان :",'callback_data'=>"A"],['text'=>"قیمت ارز :",'callback_data'=>"A"],['text'=>"نام ارز :",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$dolar ریال",'callback_data'=>"A"],['text'=>"دلار",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$euro ریال",'callback_data'=>"A"],['text'=>"یورو",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$derham ریال",'callback_data'=>"A"],['text'=>"درهم",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$pond ریال",'callback_data'=>"A"],['text'=>"پوند",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$lir ریال",'callback_data'=>"A"],['text'=>"لیر",'callback_data'=>"A"]],
[['text'=>"----------------------------------------------",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$bc ریال",'callback_data'=>"A"],['text'=>"ترون",'callback_data'=>"A"]],
[['text'=>"اکنون",'callback_data'=>"A"],['text'=>"$a2 ریال",'callback_data'=>"A"],['text'=>"تتر",'callback_data'=>"A"]],
]]);
bot('sendmessage',[
'chat_id'=>$channel,
'text'=>"💥 - قیمت ارز های مجازی و واقعی به واحد ریال :",
'reply_markup'=>$key1,
]);