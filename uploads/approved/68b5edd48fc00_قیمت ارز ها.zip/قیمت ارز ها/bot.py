import requests
from bs4 import BeautifulSoup
import time
from datetime import datetime
import asyncio
import logging

TELEGRAM_BOT_TOKEN = "BOT_TOKEN"#توکن ربات 
AUTHORIZED_CHAT_ID = "CHAT_ID"#آیدی عددی شما 

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

last_prices = {
    'dollar': None,
    'euro': None,
    'pound': None,
    'lira': None,
    'dirham': None
}

currency_urls = {
    'dollar': "https://www.tgju.org/profile/price_dollar_rl",
    'euro': "https://www.tgju.org/profile/price_eur",
    'pound': "https://www.tgju.org/profile/price_gbp",
    'lira': "https://www.tgju.org/profile/price_try",
    'dirham': "https://www.tgju.org/profile/price_aed"
}

currency_names = {
    'dollar': 'دلار',
    'euro': 'یورو',
    'pound': 'پوند',
    'lira': 'لیر',
    'dirham': 'درهم'
}

async def get_currency_price(currency):
    url = currency_urls[currency]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        price_element = soup.find('span', {'data-col': 'info.last_trade.PDrCotVal'})
        if price_element:
            price = price_element.text.strip()
            return price
        else:
            price_element = soup.find('td', {'class': 'text-left'})
            if price_element:
                return price_element.find_next('td').text.strip()
            return None
    except Exception as e:
        logger.error(f"خطا در دریافت قیمت {currency}: {e}")
        return None

async def send_telegram_message(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            'chat_id': AUTHORIZED_CHAT_ID,
            'text': message,
            'parse_mode': 'HTML'
        }
        response = requests.post(url, data=payload, timeout=10)
        return response.status_code == 200
    except Exception as e:
        logger.error(f"خطا در ارسال پیام تلگرام: {e}")
        return False

async def check_price_changes():
    global last_prices
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for currency in last_prices.keys():
        current_price = await get_currency_price(currency)
        if not current_price:
            continue
            
        if last_prices[currency] is None:
            last_prices[currency] = current_price
            if all(price is not None for price in last_prices.values()):
                message = "✅ ربات شروع به کار کرد\n\n"
                for curr, price in last_prices.items():
                    message += f"💰 قیمت اولیه {currency_names[curr]}: <b>{price}</b> تومان\n"
                message += f"⏰ زمان: {current_time}"
                await send_telegram_message(message)
            continue
            
        if current_price != last_prices[currency]:
            try:
                current_num = float(current_price.replace(',', ''))
                last_num = float(last_prices[currency].replace(',', ''))
                change_direction = "📈 افزایش" if current_num > last_num else "📉 کاهش"
                change_amount = abs(current_num - last_num)
                message = (
                    f"🔄 تغییر قیمت {currency_names[currency]}\n"
                    f"💰 قیمت قبلی: <b>{last_prices[currency]}</b> تومان\n"
                    f"💰 قیمت جدید: <b>{current_price}</b> تومان\n"
                    f"📊 جهت تغییر: {change_direction}\n"
                    f"📈 مقدار تغییر: <b>{change_amount:,.0f}</b> تومان\n"
                    f"⏰ زمان: {current_time}"
                )
                await send_telegram_message(message)
                last_prices[currency] = current_price
            except ValueError:
                message = (
                    f"🔄 تغییر قیمت {currency_names[currency]}\n"
                    f"💰 قیمت قبلی: <b>{last_prices[currency]}</b> تومان\n"
                    f"💰 قیمت جدید: <b>{current_price}</b> تومان\n"
                    f"⏰ زمان: {current_time}"
                )
                await send_telegram_message(message)
                last_prices[currency] = current_price

async def send_current_prices():
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    message = "💰 قیمت ارزها از TGJU.org\n\n"
    
    for currency in last_prices.keys():
        price = await get_currency_price(currency)
        if price:
            message += f"💵 {currency_names[currency]}: <b>{price}</b> تومان\n"
        else:
            message += f"❌ {currency_names[currency]}: خطا در دریافت قیمت\n"
    
    message += f"\n⏰ زمان: {current_time}"
    await send_telegram_message(message)

async def main():
    await send_telegram_message("🤖 ربات قیمت ارزها فعال شد!")
    await check_price_changes()
    print("🤖 ربات قیمت ارزها شروع به کار کرد...")
    print("⏰ در حال رصد قیمت هر 1 دقیقه...")
    print("⛔ برای توقف ربات Ctrl+C را فشار دهید")
    try:
        while True:
            await check_price_changes()
            await asyncio.sleep(60)
    except KeyboardInterrupt:
        print("⛔ ربات متوقف شد")
        await send_telegram_message("⛔ ربات متوقف شد")

if __name__ == "__main__":
    if TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or AUTHORIZED_CHAT_ID == "YOUR_CHAT_ID_HERE":
        print("❌ لطفاً توکن ربات و چت آیدی خود را در کد تنظیم کنید")
        print("1. توکن ربات را از @BotFather دریافت کنید")
        print("2. چت آیدی خود را از @userinfobot دریافت کنید")
        print("3. مقادیر را در کد جایگزین کنید")
    else:
        asyncio.run(main())