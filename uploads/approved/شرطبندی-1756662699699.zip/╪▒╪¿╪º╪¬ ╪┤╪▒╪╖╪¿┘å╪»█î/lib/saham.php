<?php
 

# یک بار این صفحه اجرا کنید
## INCLUDE
include '../config.php';
## TIME ZONE
date_default_timezone_set('Asia/Tehran'); 
## KEY
$codeabolm = "123698745852456";
## GET
$key = $_GET['key'];
if($_GET['key']) {
}else{
echo"join channel » @IRA_Team";
exit();
}
## IF KEY
if($_GET['key'] == $codeabolm) {
}else{
echo"join channel » @IRA_Team";
exit();
}
## function
function IranTime2(){
date_default_timezone_set("Asia/Tehran");
return date('H:i:s');
}
function MrMasih($method,$datas=[]){
                    $ch = curl_init();
                    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
                    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
return json_decode(curl_exec($ch));
}
$time2    = iranTime2();
## SQL
$sahmabolm   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `saham` LIMIT 1"));
## RAND
$MTn = [
"1",
"2",
"2",
"1",
"1",
"1",
"2",
"2",
"1",
"2",
"3",
"2",
"2",
"4",
"1",
"1",
"1",
"20",
];
$MTn2 = $MTn[rand(0,count($MTn)-1)];
## RAND 2
$MTn3 = [
"+",
"-",
"-",
"+",
"-",
"+",
"-",
];
$MTn23 = $MTn3[rand(0,count($MTn3)-1)];
## SAHAM
$a = mysqli_query($connect,"SELECT * FROM user");
while($sd = mysqli_fetch_array($a)){
$users[] = $sd['id'];
}
foreach($users as $chat){
$userb      = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$chat' LIMIT 1"));
$saham      = $userb['saham'];
$lolsaham   = $sahmabolm['darsad'];
$x          = $lolsaham ;
$y          = $saham;
$res        = ($x*100)/$y;
if($MTn23 == "+"){
$kon        = $saham + $res;
}
if($MTn23 == "-"){
$kon        = $saham - $res;
}
$connect->query("UPDATE user SET saham = '$kon' WHERE id = '$chat' LIMIT 1");
}
$lolsaham   =$sahmabolm['darsad'];
$master     =$sahmabolm['channel'];
if($MTn23 == "+"){
$abolmchera    ="مثبت";
}
if($MTn23 == "-"){
$abolmchera    ="منفی";
}
if($master!=null){
$master     =$sahmabolm['channel'];
}else{
$master     =$admin[0];
}
MrMasih('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"
📍سهام امروز شرکت شما

📍 وضعیت امروز بازار = $MTn23
📍 درصد امروز بازار = $lolsaham
📍 درصد پیشبینی شده برای فردا = $MTn2
📍 زمان اخرین سهام = $time2

📍 اگر میخواهید میتوانید اطلاعات بالارا برای کاربران ارسال کنید تا از بازار امروز خبردار بشند.
📍 نشر دادن این سورس و منبع نزدن در ان نشانه فروش مادر خود میباشد.
📍 برترین سورس شرطبندی اوتوماتیک و بدون باگ @IRA_Team
",
]);
MrMasih('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"
📍 تمام تغیرات (مثبت و منفی) سهام روی تمامیه سهام های کاربران قرار گرفت
@IRA_Team
",
]);
MrMasih('sendmessage',[
'chat_id'=>$master,
'text'=>"
📍وضعیت سهام امروز »

📍 وضعیت امروز بازار = $abolmchera
📍 درصد امروز بازار = $lolsaham%
📍 زمان اخرین اخبار = $time2
",
]);
$connect->query("UPDATE saham SET darsad = '$MTn2'");
$connect->query("UPDATE saham SET uptime = '$time2'");
$connect->query("UPDATE saham SET ondarsad = '$lolsaham'");
$connect->query("UPDATE saham SET onvaz = '$abolmchera'");
$connect->query("UPDATE saham SET kk = '$abolmchera'");
$connect->query("UPDATE saham SET abolmteam = '$abolmchera^$lolsaham^$time2^abolmteam^$abolmchera^ok^$key'");
echo"saham is runned successful..! @IRA_Team";
exit;
 
?> 