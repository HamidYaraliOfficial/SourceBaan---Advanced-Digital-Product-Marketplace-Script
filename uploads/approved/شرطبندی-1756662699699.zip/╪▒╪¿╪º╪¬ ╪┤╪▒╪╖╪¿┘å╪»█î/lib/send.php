<?php
## کرون 1 مین بزنید روش
/*
سورس ربات شرطبندی ایکس دی !

اوپن شد در کانال آیرا تیم توسط مسیح !

ذکر منبع اجباری میباشد !

@IRA_Team | @ImDevAbolfazl
*/
include '../config.php';

$send = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `sendall` LIMIT 1"));

function MrMasih($method,$datas=[]){
                    $ch = curl_init();
                    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
                    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
return json_decode(curl_exec($ch));
}
if($send['step'] == 'send'){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from `user`"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 100 OFFSET {$send['user']}");
if($send['abcd'] == "1"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendphoto',[
'chat_id'=>$row['id'],
'photo'=>$send['chat'],
'caption'=>$send['text'],
]);
}
if($send['abcd'] == "2"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendmessage',[
'chat_id'=>$row['id'],        
'text'=>$send['text'],
]);	
}
if($send['abcd'] == "3"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendvideo',[
'chat_id'=>$row['id'],
'video'=>$send['chat'],
'caption'=>$send['text'],
]);
}
if($send['abcd'] == "4"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendDocument',[
'chat_id'=>$row['id'],
'document'=>$send['chat'],
'caption'=>$send['text'],
]);
}
if($send['abcd'] == "5"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendaudio',[
'chat_id'=>$row['id'],
'audio'=>$send['chat'],
'caption'=>$send['text'],
]);
}
if($send['abcd'] == "6"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendvoice',[
'chat_id'=>$row['id'],
'voice'=>$send['chat'],
'caption'=>$send['text'],
]);
}
if($send['abcd'] == "7"){
while($row = mysqli_fetch_assoc($users))
MrMasih('sendsticker',[
'chat_id'=>$row['id'],
'sticker'=>$send['chat'],
'caption'=>$send['text'],
]);
}
$connect->query("UPDATE `sendall` SET `user` = `user` + 100 LIMIT 1");
if($send['user'] + 100 >= $alluser){
MrMasih('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"✅ پیام برای همه کابران ارسال شد",
]);
$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");	
}
}
## forward
elseif($send['step'] == 'forward'){
$alluser = mysqli_num_rows(mysqli_query($connect,"select id from `user`"));
$users = mysqli_query($connect,"SELECT id FROM `user` LIMIT 100 OFFSET {$send['user']}");
while($row = mysqli_fetch_assoc($users))
MrMasih('ForwardMessage',[
'chat_id'=>$row['id'],   
'from_chat_id'=>$send['chat'],
'message_id'=>$send['text'],
]);	
$connect->query("UPDATE `sendall` SET `user` = `user` + 100 LIMIT 1");
if($send['user'] + 100 >= $alluser){
  MrMasih('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"✅ پیام برای همه کابران فوروارد شد",
 ]);
$connect->query("UPDATE `sendall` SET `step` = 'none' , `text` = '' , `user` = '0' , `chat` = '' LIMIT 1");		
}
}
/*
سورس ربات شرطبندی ایکس دی !

اوپن شد در کانال آیرا تیم توسط مسیح !

ذکر منبع اجباری میباشد !

@IRA_Team | @ImDevAbolfazl
*/