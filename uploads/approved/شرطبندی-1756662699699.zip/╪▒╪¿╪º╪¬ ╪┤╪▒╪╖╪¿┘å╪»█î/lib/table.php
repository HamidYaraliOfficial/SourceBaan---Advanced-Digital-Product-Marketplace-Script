<?php
 
# -- include
include '../config.php';
# -- table
$connect->multi_query("CREATE TABLE `user` (
    `id` bigint PRIMARY KEY,
	`step` varchar(150) DEFAULT NULL,
	`step2` varchar(150) DEFAULT NULL,
    `more` varchar(150) DEFAULT NULL,
    `phone` varchar(150) DEFAULT NULL,
    `nitroseen` bigint DEFAULT '0',
    `bardashtha` bigint DEFAULT '0',
    `tedad` bigint DEFAULT '0',
    `bord` bigint DEFAULT '0',
    `bakht` bigint DEFAULT '0',
    `member` bigint DEFAULT '0',
    `odercoin` varchar(150) DEFAULT NULL,
    `coin` varchar(150) DEFAULT '0',
    `saham` bigint DEFAULT '0',
    `zarib` varchar(150) DEFAULT NULL,
    `roz` varchar(150) DEFAULT NULL,
    `abol` bigint DEFAULT '0',
    `master` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `abolm` (
	`data` text DEFAULT NULL
    ) default charset = utf8mb4; 
	CREATE TABLE `block` (
    `id` bigint NOT NULL,
    `time` text DEFAULT NULL,
    `abolm` bigint DEFAULT '0'
    ) default charset = utf8mb4; 	
    CREATE TABLE `matn` (
    `mtnoff` text DEFAULT NULL,
    `mtnjoinchannel` text DEFAULT NULL,
    `mtnnewzir` text DEFAULT NULL,
    `mtnback` text DEFAULT NULL,
    `mtnstart` text DEFAULT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `saham` (
    `darsad` text DEFAULT '2',
    `ondarsad` text DEFAULT NULL,
    `onvaz` text DEFAULT NULL,
    `kk` text DEFAULT NULL,
    `coin` text DEFAULT '2',
    `user` text DEFAULT '0',
    `channel` text DEFAULT NULL,
    `abolmteam` text DEFAULT NULL,
    `off` text DEFAULT 'off',
    `uptime` text DEFAULT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `channelsender` (
    `channel1` text DEFAULT NULL,
    `channel2` text DEFAULT NULL,
    `channel3` text DEFAULT NULL,
    `channel4` text DEFAULT NULL,
    `channel5` text DEFAULT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `settings` (
    `name` varchar(150) DEFAULT 'abolm',
    `abolmoff` varchar(150) DEFAULT 'on',
    `phone` varchar(150) DEFAULT 'on',
    `kharid` varchar(150) DEFAULT 'on',
    `zircoin` varchar(150) DEFAULT '5',
    `kasezir` varchar(150) DEFAULT '7',
    `bardasht` varchar(150) DEFAULT '100',
    `rozcoin` varchar(150) DEFAULT '5',
    `adminnitroseen` varchar(150) DEFAULT '759869599',
    `namebot` varchar(150) DEFAULT 'شرطبندی',
    `channel` varchar(150) DEFAULT NULL,
    `nitrbot` varchar(150) DEFAULT '3000',
    `kutbot` varchar(150) DEFAULT '2000',
    `harpbot` varchar(150) DEFAULT '1000',
    `avidbot` varchar(150) DEFAULT '3000',
    `allbot` varchar(150) DEFAULT 'runed'
    ) default charset = utf8mb4; 	
    CREATE TABLE `phone` (
    `id` varchar(150) DEFAULT NULL,
    `phone` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4; 
    CREATE TABLE `settingbardasht` (
    `b1` varchar(150) DEFAULT 'off',
    `b2` varchar(150) DEFAULT 'off',
    `b3` varchar(150) DEFAULT 'off',
    `b4` varchar(150) DEFAULT 'off',
    `b5` varchar(150) DEFAULT 'off'
    ) default charset = utf8mb4; 
    CREATE TABLE `game` (
    `name` varchar(150) DEFAULT 'gmabolm',
    `game1off` varchar(150) DEFAULT 'on',
    `game1coin` varchar(150) DEFAULT '100',
    `game2off` varchar(150) DEFAULT 'on',
    `game2coin` varchar(150) DEFAULT '100',
    `game3off` varchar(150) DEFAULT 'on',
    `game3coin` varchar(150) DEFAULT '100',
    `game4off` varchar(150) DEFAULT 'on',
    `game4coin` varchar(150) DEFAULT '100',
    `game5off` varchar(150) DEFAULT 'on',
    `game5coin` varchar(150) DEFAULT '100',
    `game6off` varchar(150) DEFAULT 'on',
    `game6coin` varchar(150) DEFAULT '100',
    `game7off` varchar(150) DEFAULT 'on',
    `game7coin` varchar(150) DEFAULT '100',
    `game8off` varchar(150) DEFAULT 'on',
    `game8coin` varchar(150) DEFAULT '100',
    `game9off` varchar(150) DEFAULT 'on',
    `game9coin` varchar(150) DEFAULT '100',
    `game10off` varchar(150) DEFAULT 'on',
    `game10coin` varchar(150) DEFAULT '100',
    `game11off` varchar(150) DEFAULT 'on',
    `game11coin` varchar(150) DEFAULT '100',
    `allgame` varchar(150) DEFAULT 'on',
    `shart` varchar(150) DEFAULT 'on',
    `channelshart` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `button` (
    `allsaham` text DEFAULT 'on',
    `kharid` text DEFAULT 'off',
    `bardasht` text DEFAULT 'off',
    `mnd` text DEFAULT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `member` (
    `id` varchar(150) DEFAULT NULL,
    `master` varchar(150) DEFAULT NULL,
    `masteris` bigint NOT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `pay` (
    `id` varchar(150) DEFAULT NULL,
    `order_id` varchar(150) DEFAULT NULL,
    `amount` varchar(150) DEFAULT NULL,
    `track_idpay` varchar(150) DEFAULT NULL,
    `track_id` varchar(150) DEFAULT NULL,
    `amount_payment` varchar(150) DEFAULT NULL,
    `date` varchar(150) DEFAULT NULL,
    `hashed_card` varchar(150) DEFAULT NULL,
    `card_number` varchar(150) DEFAULT NULL,
    `hojjat` varchar(150) DEFAULT NULL,
    `difine` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `allpay` (
    `id` varchar(150) DEFAULT NULL,
    `amount` varchar(150) DEFAULT NULL,
    `date` varchar(150) DEFAULT NULL,
    `time` varchar(150) DEFAULT NULL,
    `hashed` varchar(150) DEFAULT NULL,
    `creator` varchar(150) DEFAULT 'yeh_abolm',
    `abolm` bigint NOT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `allbardasht` (
    `id` varchar(150) DEFAULT NULL,
    `noo` varchar(150) DEFAULT NULL,
    `amount` varchar(150) DEFAULT NULL,
    `date` varchar(150) DEFAULT NULL,
    `time` varchar(150) DEFAULT NULL,
    `admintime` varchar(150) DEFAULT NULL,
    `hashed_id` varchar(150) DEFAULT NULL
    ) default charset = utf8mb4;
    CREATE TABLE `sendall` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`abcd` varchar(100) DEFAULT 'tx',
    `allsend` varchar(100) DEFAULT 'yeh_abolm',
	`user` bigint DEFAULT '0'
    ) default charset = utf8mb4;
    INSERT INTO `sendall` () VALUES ();
    INSERT INTO `button` () VALUES ();
    INSERT INTO `matn` () VALUES ();
    INSERT INTO `settings` () VALUES ();
    INSERT INTO `game` () VALUES ();
    INSERT INTO `saham` () VALUES ();
    INSERT INTO `channelsender` () VALUES ();
    INSERT INTO `settingbardasht` () VALUES ();
	INSERT INTO `abolm` () VALUES ();");
//========================== // Check connection // ==============================
if ($connect->connect_error) {
                        die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
                        echo "دیتابیس متصل و نصب شد . @IRA_Team"
 
?>