<?php
//
## =-=-=-=-=-=-=-=-=-=// include //=-=-=-=-=-=-=-=-=-= ##
include 'config.php';
include ("jdf.php"); 
## =-=-=-=-=-=-=-=-=-=// time //=-=-=-=-=-=-=-=-=-= ##
date_default_timezone_set('Asia/Tehran'); 
## =-=-=-=-=-=-=-=-=-=// BOT //=-=-=-=-=-=-=-=-=-= ##
function MrMasih($method,$datas=[]){
                    $ch = curl_init();
                    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
                    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
                    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
                    return json_decode(curl_exec($ch));
}
## =-=-=-=-=-=-=-=-=-=// function //=-=-=-=-=-=-=-=-=-= ##
function IranTime(){
                    date_default_timezone_set("Asia/Tehran");
                    return date('H:i:s');
}
function IranDate(){
                    date_default_timezone_set("Asia/Tehran");
                    return date('Y/m/d');
}
## =-=-=-=-=-=-=-=-=-=// update //=-=-=-=-=-=-=-=-=-= ##
$update             = json_decode(file_get_contents('php://input'));
$inline             = $update->inline_query;
$inline_id          = $update->inline_query->id;
$inline_text        = $update->inline_query->query;
$inline_from        = $update->inline_query->from->id;
$inline_name        = $update->inline_query->from->first_name;
$inlinequery        = $update->inline_query->query;
$inlinequeryid      = $update->inline_query->id;
$contact            = $message->contact;
$contactid          = $contact->user_id;
$contactnum         = $contact->phone_number;
$co_num             = $contact->phone_number;
if(isset($update->message)){
$message            = $update->message;
$message_id         = $message->message_id;
$text               = $message->text;
$chat_id            = $message->chat->id;
$tc                 = $message->chat->type;
$first_name         = $message->from->first_name;
$from_id            = $message->from->id;
$document           = $message->document;
$photo              = $message->photo;
$username           = $message->from->username;
$inline             = $update->inline_query;
$inline_id          = $update->inline_query->id;
$inline_text        = $update->inline_query->query;
$inline_from        = $update->inline_query->from->id;
$inline_name        = $update->inline_query->from->first_name;
$inlinequery        = $update->inline_query->query;
$inlinequeryid      = $update->inline_query->id;
$contact            = $message->contact;
$contactid          = $contact->user_id;
$contactnum         = $contact->phone_number;
$co_num             = $contact->phone_number;
$load               = sys_getloadavg();
$time               = iranTime();
$date               = iranDate();
$user               = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$from_id' LIMIT 1"));
$block              = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$from_id' LIMIT 1");
}
if(isset($update->callback_query)){
$callback_query     = $update->callback_query;
$callback_query_id  = $callback_query->id;
$data               = $callback_query->data;
$fromid             = $callback_query->from->id;
$messageid          = $callback_query->message->message_id;
$chatid             = $callback_query->message->chat->id;
$inline             = $update->inline_query;
$inline_id          = $update->inline_query->id;
$inline_text        = $update->inline_query->query;
$inline_from        = $update->inline_query->from->id;
$inline_name        = $update->inline_query->from->first_name;
$inlinequery        = $update->inline_query->query;
$inlinequeryid      = $update->inline_query->id;
$contact            = $message->contact;
$contactid          = $contact->user_id;
$contactnum         = $contact->phone_number;
$co_num             = $contact->phone_number;
$user               = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
$block              = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1");
}
## =-=-=-=-=-=-=-=-=-=// MKDIR //=-=-=-=-=-=-=-=-=-= ##
mkdir("spam");
## =-=-=-=-=-=-=-=-=-=// function2 //=-=-=-=-=-=-=-=-=-= ##
function convert($string) {
                    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
                    $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];
                    $num = range(0, 9);
                    $convertedPersianNums = str_replace($persian, $num, $string);
                    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
                    return $englishNumbersOnly;
}
function objectToArrays($object)
{
                    if (!is_object($object) && !is_array($object))
{
                    return $object;
}
                    if (is_object($object))
{
                    $object = get_object_vars($object);
}
                    return array_map("objectToArrays", $object);
}
function save($filename, $TXTdata)
{
                    $myfile = fopen($filename, "w") or die("Unable to open file!");
                    fwrite($myfile, "$TXTdata");
                    fclose($myfile);
}
function Zip($fzip, $zips){
                    $rootPath = realpath($fzip);
                    $zip = new ZipArchive();
                    $zip->open($zips, ZipArchive::CREATE | ZipArchive::OVERWRITE);
                    $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($rootPath),
                    RecursiveIteratorIterator::LEAVES_ONLY);
                    foreach($files as $name => $file){
                    if(!$file->isDir()){
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($rootPath) + 1);
                    $zip->addFile($filePath, $relativePath);}}
                    $zip->close();
}
function sendphoto($chat_id, $photo, $caption){
                    MrMasih('sendphoto',[
                    'chat_id'=>$chat_id,
                    'photo'=>$photo,
                    'caption'=>$caption,
]);
}
function SendDocument($chat_id, $document, $caption = null){
                    MrMasih('sendDocument',[
                    'chat_id'=>$chat_id,
                    'document'=>$document,
                    'caption'=>$caption
]);
}
function memUsage($units = false){
                    $status = file_get_contents('/proc/' . getmypid() . '/status');
                    $matchArr = array();
                    preg_match_all('~^(VmRSS|VmSwap):\s*([0-9]+).*$~im', $status, $matchArr);
                    if(!isset($matchArr[2][0]) || !isset($matchArr[2][1])){
                    return false;
}
                    $size = intval($matchArr[2][0]) + intval($matchArr[2][1]);
                    $unit = array('KB','MB','GB','TB','PB');
                    if($units){
                    return @round($size/pow(1024,($i=floor(log($size,1024)))),0).' '.$unit[$i];
}else{
                    return @round($size/pow(1024,($i=floor(log($size,1024)))),0);
}
}
function getMUsage(){
                    $mem = memory_get_usage();
                    $kb = $mem / 1024;
                    return substr($kb, 0, -5).' KB';
}
function GetProfile($from_id){
                    $get            = file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getUserProfilePhotos?user_id='.$from_id);
                    $decode         = json_decode($get,true);
                    $result         = $decode['result'];
                    $profile        = $result['photos'][0][0]['file_id'];
                    return $profile;
}
## =-=-=-=-=-=-=-=-=-=// SEND JOIN //=-=-=-=-=-=-=-=-=-= ##
function is_join($id)
{
                    global $Channels;
                    $in_ch = [];
                    foreach ($Channels as $ch_id)
{
                    $type = MrMasih("getChatMember" , ["chat_id" => "@$ch_id" , "user_id" => $id]);
                    $type = (is_object($type)) ? $type->result->status : $type['result']['status'];
                    if($type == 'creator' || $type ==  'administrator' || $type ==  'member')
{
                    $in_ch[$ch_id] = $type;
}
else
{
                    $keyboard = [];
                    foreach ($Channels as $ch_id)
{
                    $ch_info = MrMasih("getChat", ["chat_id"=>"@$ch_id"]);//get channel
                    $ch_name = (is_object($ch_info)) ? $ch_info->result->title : $ch_info['result']['title'];//channel name
                    $keyboard[] = [['text' => $ch_name, 'url' => "https://t.me/$ch_id"]];
}
$keyboard[]     = [['text'=>'✅ تایید عضویت','callback_data'=>'join']];
$text           = "📍 برای استفاده عضو کانالمون شو";
MrMasih('sendmessage',[
'chat_id'=>$id,
'text'=>"$text" ,'parse_mode' => 'MarkDown', 'reply_markup' => 
json_encode(['inline_keyboard' => $keyboard])]);
break;
}
}
return true;
}
## =-=-=-=-=-=-=-=-=-=// JOIN //=-=-=-=-=-=-=-=-=-= ##
function check_join($id)
{
                    global $Channels;
                    $in_ch = [];
                    foreach ($Channels as $ch_id)
{
                    $type = MrMasih("getChatMember" , ["chat_id" => "@$ch_id" , "user_id" => $id]);
                    $type = (is_object($type)) ? $type->result->status : $type['result']['status'];
                    if($type == 'creator' || $type ==  'administrator' || $type ==  'member')
{
                    $in_ch[$ch_id] = $type;
}
else
{
return false;
break;
}
}
return true;
}
 
## =-=-=-=-=-=-=-=-=-=// GET BOT //=-=-=-=-=-=-=-=-=-= ##
function GetMe(){
    return MrMasih('getMe');
}
$botname        = getMe() -> result -> first_name; 
$botusername    = getMe() -> result -> username;
## =-=-=-=-=-=-=-=-=-=// SPAM //=-=-=-=-=-=-=-=-=-= ##
function Spam($from_id){
@mkdir("spam");
$spam_status = json_decode(file_get_contents("spam/$from_id.json"),true);
if($spam_status != null){
if(mb_strpos($spam_status[0],"time") !== false){
if(str_replace("time ",null,$spam_status[0]) >= time())
exit(false);
else
$spam_status    = [1,time()+2];}
elseif(time() < $spam_status[1]){
if($spam_status[0]+1 > 3){
$time           = time() + 600;
$spam_status    = ["time $time"];
file_put_contents("spam/$from_id.json",json_encode($spam_status,true));
$abol22           = date('H'); 
$abol122          = date('i'); 
$abol222          = date('s'); 
$hojjattrube    = $abol122 + 10;
bot ('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ اکانت شما بدلیل #اسپم ربات به مدت 10 دقیقه مسدود شد

⌚️ $abol22:$abol122:$abol222
",
]);
exit(false);
}else{
$spam_status = [$spam_status[0]+1,$spam_status[1]];}
}else{
$spam_status = [1,time()+2];}
}else{
$spam_status = [1,time()+2];}
file_put_contents("spam/$from_id.json",json_encode($spam_status,true));}
Spam($from_id);
## =-=-=-=-=-=-=-=-=-=// SC //=-=-=-=-=-=-=-=-=-= ##
if(strpos($text,"'") !== false or strpos($text,'"') !== false or strpos($text,"}") !== false or strpos($text,"{") !== false  or strpos($text,",") !== false){ 
exit;
}
## =-=-=-=-=-=-=-=-=-=// SPAM //=-=-=-=-=-=-=-=-=-= ##
if(file_exists("spam/$from_id/$from_id.json")){
unlink("spam/$from_id/$from_id.json");
}
## =-=-=-=-=-=-=-=-=-=// SQL map //=-=-=-=-=-=-=-=-=-= ##
$settingsdb = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `settings` WHERE `name` = 'abolm' LIMIT 1"));
$gamedb     = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `game` WHERE `name` = 'gmabolm' LIMIT 1"));
$matnedb    = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `matn`"));
$phonesdb   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `phone`"));
$sahamdb    = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `saham`"));
$bardashdb  = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `settingbardasht`"));
## =-=-=-=-=-=-=-=-=-=// ONLINE BOT //=-=-=-=-=-=-=-=-=-= ##
if (mysqli_num_rows($block) > 0) exit();
if ($settingsdb['abolmoff'] == "off" and !in_array($from_id, $admin)){
if ($matnedb['mtnoff'] != NULL){
$offtext = $matnedb['mtnoff'];
$offtext = str_replace('NAME',$first_name,$offtext);
$offtext = str_replace('KARBARID',$from_id,$offtext);
$offtext = str_replace('USERNME',$username,$offtext);
$offtext = str_replace('TX',$text,$offtext);
$offtext = str_replace('TIMEIRAN',$time,$offtext);
}else{
$offtext = "
📍 ربات جهت بروزرسانی خاموش است ! لطفا پیام مجدد ارسال نکنید.
";
}
MrMasih('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
$offtext
",
]);
exit;
}
 
## =-=-=-=-=-=-=-=-=-=// PANEL //=-=-=-=-=-=-=-=-=-= ##
if (in_array($from_id, $admin)) {
$home = json_encode(['keyboard'=>[
                [['text'=>"🎮 شروع بازی 🎮"]],
                [['text'=>"➕ افزایش موجودی"],['text'=>'➖ برداشت موجودی']],
                [['text'=>"🏦 انتقال سکه"],['text'=>'🛒 خرید سهام']],
                [['text'=>'👤 حساب من']],
                [['text'=>"⚙️ مدیریت ⚙️"]],
], 'resize_keyboard' => true
]);
}else{
$home = json_encode(['keyboard'=>[
        [['text'=>"🎮 شروع بازی 🎮"]],
        [['text'=>"➕ افزایش موجودی"],['text'=>'➖ برداشت موجودی']],
        [['text'=>"🏦 انتقال سکه"],['text'=>'🛒 خرید سهام']],
        [['text'=>'👤 حساب من']],
], 'resize_keyboard' => true
]);
}
$back = json_encode([
'keyboard'=>[
        [['text'=>'🔙 بازگشت']],
],
'resize_keyboard'=>true,
]);	
$game_panel = json_encode([
'keyboard'=>[
        [['text'=>'💣 انفجار']],
        [['text'=>"🏀 بسکتبال"],['text'=>'🎳 بولینگ'],['text'=>'⚽️ فوتبال']],
        [['text'=>"✊ گل یا پوچ"],['text'=>'🎯 دارت'],['text'=>'👊🏻 سنگ کاغذ قیچی']],
        [['text'=>"🎲 تاس"],['text'=>'💩 پوپ'],['text'=>'🎱 رولت']],
        [['text'=>'🔙 بازگشت'],['text'=>'🎰 ماشین اسکات']],
],
'resize_keyboard'=>true,
]);	
$sahamm_panel = json_encode([
'keyboard'=>[
        [['text'=>'🏦 استعلام سهام']],
        [['text'=>"🛍 خرید سهام"],['text'=>'💲 برداشت سهام']],
        [['text'=>'🔙 بازگشت']],
],
'resize_keyboard'=>true,
]);	
$mjabolm_panel = json_encode([
'keyboard'=>[
        [['text'=>'🎁 سکه روزانه']],
        [['text'=>"👥 زیرمجموعه گیری"],['text'=>'💰 خرید سکه']],
        [['text'=>'🔙 بازگشت']],
],
'resize_keyboard'=>true,
]);	
$bardashtabolmteam = json_encode([
'keyboard'=>[
        [['text'=>'💳 برداشت نقدی']],
        [['text'=>"🤖 کیوت سین"],['text'=>'🤖 نیتروسین']],
        [['text'=>"🤖 آوید سین"],['text'=>'🤖 هارپ سین']],
        [['text'=>'🔙 بازگشت']],
],
'resize_keyboard'=>true,
]);	
## =-=-=-=-=-=-=-=-=-=// BLOCK //=-=-=-=-=-=-=-=-=-= ##
if (mysqli_num_rows($block) > 0) exit();
elseif(strpos($text,"'") or strpos($text,"#") or strpos($text,";") and !in_array($from_id, $admin)){
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 20");
}
## =-=-=-=-=-=-=-=-=-=// JOIN //=-=-=-=-=-=-=-=-=-= ##
if($data == 'join'){
if(check_join("$fromid")=='true'){
MrMasih('sendmessage',[
'chat_id'=>$chatid,
'text'=>"
✅ عضویت شما تایید شما و همکنون میتوانید از ربات استفاده کنید
",
'reply_to_message_id'=>$messageid,
'reply_markup'=>$home
]);
}elseif(check_join("$fromid")!='true'){
MrMasih('answercallbackquery', [
'callback_query_id' =>$callback_query_id,
'text' => "📍 هنوز داخل کانال های ما عضو نشدید",
'show_alert' =>true
]);
}
}	
## =-=-=-=-=-=-=-=-=-=// START //=-=-=-=-=-=-=-=-=-= ##
elseif(preg_match('/^(\/start) (.*)/', $text , $match) and $user['id'] != true and $match[2] > 0){

if ($matnedb['mtnstart'] != NULL){
$mtnstart = $matnedb['mtnstart'];
$mtnstart = str_replace('NAME',$first_name,$mtnstart);
$mtnstart = str_replace('KARBARID',$from_id,$mtnstart);
$mtnstart = str_replace('USERNME',$username,$mtnstart);
$mtnstart = str_replace('TX',$text,$mtnstart);
$mtnstart = str_replace('TIMEIRAN',$time,$mtnstart);
}else{
$mtnstart = "
📍 سلام به پیشرفته ترین ربات شرطبندی بدون باگ در تلگرام خوش امدید
📍 اوپن شده در کانال تلگرامی »» @IRA_Team
";
}

if(check_join("$from_id")=='true'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
$mtnstart
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");
$zircoin = $settingsdb['zircoin'];
$user    = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$match[2]' LIMIT 1"));
$member  = $user['member'] + 1;
$coin    = $user['coin'] + $zircoin;
if ($matnedb['mtnnewzir'] != NULL){
$mtnnewzir = $matnedb['mtnnewzir'];
$mtnnewzir = str_replace('NEWZIRID',$from_id,$mtnnewzir);
$mtnnewzir = str_replace('COIN',$coin,$mtnnewzir);
$mtnnewzir = str_replace('MEMBER',$member,$mtnnewzir);
}else{
$mtnnewzir = "
📍 متن زیرمجموعه گیری جدید ست نشده.
";
}
MrMasih('sendmessage',[
'chat_id'=>$match[2],
'text'=>"
$mtnnewzir
",
'parse_mode'=>'Markdown',
]);
$connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[2]' LIMIT 1");
$connect->query("UPDATE `user` SET `master` = '$match[2]' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("INSERT INTO `member` (`id` , `master`) VALUES ('$from_id' , '$match[2]')");
}else{
$connect->query("INSERT INTO `user` (`id` , `step`) VALUES ('$from_id' , 'send $match[2]')");
is_join("$from_id");
exit;
}
}   
## =-=-=-=-=-=-=-=-=-=// START2 //=-=-=-=-=-=-=-=-=-= ##
if($text == "/start"){

if($user['id'] != true){
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");    
}
if ($matnedb['mtnstart'] != NULL){
$mtnstart = $matnedb['mtnstart'];
$mtnstart = str_replace('NAME',$first_name,$mtnstart);
$mtnstart = str_replace('KARBARID',$from_id,$mtnstart);
$mtnstart = str_replace('USERNME',$username,$mtnstart);
$mtnstart = str_replace('TX',$text,$mtnstart);
$mtnstart = str_replace('TIMEIRAN',$time,$mtnstart);
}else{
$mtnstart = "
📍 سلام به پیشرفته ترین ربات شرطبندی بدون باگ در تلگرام خوش امدید
📍 اوپن شده در کانال تلگرامی »» @IRA_Team
";
}

if(check_join("$from_id")=='true'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
$mtnstart
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}}
## =-=-=-=-=-=-=-=-=-=// ZIR //=-=-=-=-=-=-=-=-=-= ##
if(preg_match('/^send (.*)/', $user['step'] , $match)){
$usqid=$user['id'];
if(check_join("$usqid")=='true'){
$zircoin = $settingsdb['zircoin'];
$data = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$match[1]' LIMIT 1"));
$member = $data['member'] + 1;
$coin = $data['coin'] + $zircoin;
$from_id = $user['id'];
if ($matnedb['mtnnewzir'] != NULL){
$mtnnewzir = $matnedb['mtnnewzir'];
$mtnnewzir = str_replace('NEWZIRID',$from_id,$mtnnewzir);
$mtnnewzir = str_replace('COIN',$coin,$mtnnewzir);
$mtnnewzir = str_replace('MEMBER',$member,$mtnnewzir);
}else{
$mtnnewzir = "
📍 متن زیرمجموعه گیری جدید ست نشده.
";
}
MrMasih('sendmessage',[
'chat_id'=>$match[1],
'text'=>"
$mtnnewzir
",
'parse_mode'=>'Markdown',
]);
$connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$match[1]' LIMIT 1");
$connect->query("UPDATE `user` SET `master` = '$match[1]' WHERE `id` = '$usqid' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '{$user['id']}' LIMIT 1");
$connect->query("INSERT INTO `member` (`id` , `master`) VALUES ('$usqid' , '$match[1]')");
}
}
## =-=-=-=-=-=-=-=-=-=// DATA //=-=-=-=-=-=-=-=-=-= ##
elseif(strpos($data,"harp|" ) !== false ){
$exit    = explode("|",$data);
$id      = $exit[1];
$con     = $exit[2];
$abol22    = date('H'); 
$abol122   = date('i'); 
$abol222   = date('s'); 
$sench   = $settingsdb['channel'];
if($sench !=null){
$sench   = $settingsdb['channel'];
}else{
$sench   = $admin[0];
}
$userc   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$id' LIMIT 1"));
$userccb = $userc['coin'];
$agycoin = $userccb - $con;
$kos1    = $userc['bardashtha'];
$kos2    = $kos1 + 1;
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ پرداختی در دیتابیس ثبت شد
",
]);
MrMasih('sendmessage',[
'chat_id'=>$id,
'text'=>"
✅ #واریزی به حساب هارپ سین انجام شد
",
]);
$connect->query("UPDATE user SET bardashtha = '$kos2' WHERE id = '$id' LIMIT 1");
$connect->query("INSERT INTO `allbardasht` (`id`,`noo`,`amount`,`date`,`time`,`admintime`,`hashed_id`) VALUES ('$id','آوید سین','$con','$abol22','$abol22:$abol122','IRA_Team','$id')");
}

elseif(strpos($data,"avidsexy|" ) !== false ){
$exit    = explode("|",$data);
$id      = $exit[1];
$con     = $exit[2];
$abol22    = date('H'); 
$abol122   = date('i'); 
$abol222   = date('s'); 
$sench   = $settingsdb['channel'];
if($sench !=null){
$sench   = $settingsdb['channel'];
}else{
$sench   = $admin[0];
}
$userc   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$id' LIMIT 1"));
$userccb = $userc['coin'];
$agycoin = $userccb - $con;
$kos1    = $userc['bardashtha'];
$kos2    = $kos1 + 1;
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ پرداختی در دیتابیس ثبت شد
",
]);
MrMasih('sendmessage',[
'chat_id'=>$id,
'text'=>"
✅ #واریزی به حساب آویدسین انجام شد
",
]);
$connect->query("UPDATE user SET bardashtha = '$kos2' WHERE id = '$id' LIMIT 1");
$connect->query("INSERT INTO `allbardasht` (`id`,`noo`,`amount`,`date`,`time`,`admintime`,`hashed_id`) VALUES ('$id','آوید سین','$con','$abol22','$abol22:$abol122','IRA_Team','$id')");
}

elseif(strpos($data,"nitroseen|" ) !== false ){
$exit    = explode("|",$data);
$id      = $exit[1];
$con     = $exit[2];
$abol22    = date('H'); 
$abol122   = date('i'); 
$abol222   = date('s'); 
$sench   = $settingsdb['channel'];
if($sench !=null){
$sench   = $settingsdb['channel'];
}else{
$sench   = $admin[0];
}
$userc   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$id' LIMIT 1"));
$userccb = $userc['coin'];
$agycoin = $userccb - $con;
$kos1    = $userc['bardashtha'];
$kos2    = $kos1 + 1;
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ پرداختی در دیتابیس ثبت شد
",
]);
MrMasih('sendmessage',[
'chat_id'=>$id,
'text'=>"
✅ #واریزی به حساب نیتروسین انجام شد
",
]);
$connect->query("UPDATE user SET bardashtha = '$kos2' WHERE id = '$id' LIMIT 1");
$connect->query("INSERT INTO `allbardasht` (`id`,`noo`,`amount`,`date`,`time`,`admintime`,`hashed_id`) VALUES ('$id','نیتروسین','$con','$abol22','$abol22:$abol122','IRA_Team','$id')");
}
 
elseif(strpos($data,"kuteseen|" ) !== false ){
$exit    = explode("|",$data);
$id      = $exit[1];
$con     = $exit[2];
$abol22    = date('H'); 
$abol122   = date('i'); 
$abol222   = date('s'); 
$sench   = $settingsdb['channel'];
if($sench !=null){
$sench   = $settingsdb['channel'];
}else{
$sench   = $admin[0];
}
$userc   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$id' LIMIT 1"));
$userccb = $userc['coin'];
$agycoin = $userccb - $con;
$kos1    = $userc['bardashtha'];
$kos2    = $kos1 + 1;
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ پرداختی در دیتابیس ثبت شد
",
]);
MrMasih('sendmessage',[
'chat_id'=>$id,
'text'=>"
✅ #واریزی به حساب کیوت سین شما انجام شد
",
]);
$connect->query("UPDATE user SET bardashtha = '$kos2' WHERE id = '$id' LIMIT 1");
$connect->query("INSERT INTO `allbardasht` (`id`,`noo`,`amount`,`date`,`time`,`admintime`,`hashed_id`) VALUES ('$id','کیوت سین','$con','$abol22','$abol22:$abol122','IRA_Team','$id')");
}

elseif(strpos($data,"bardasht|" ) !== false ){
$exit    = explode("|",$data);
$key     = $exit[1];
$key2    = $exit[2];
$key3    = $exit[3];
$abol22    = date('H'); 
$abol122   = date('i'); 
$abol222   = date('s'); 
$sench   = $settingsdb['channel'];
if($sench !=null){
$sench   = $settingsdb['channel'];
}else{
$sench   = $admin[0];
}
$userc   = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$key3' LIMIT 1"));
$userccb = $userc['coin'];
$agycoin = $userccb - $key;
$kos1    = $userc['bardashtha'];
$kos2    = $kos1 + 1;
if($userc['coin'] >= "$key"){
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ برداشت شما درصف انتظار قرار گرفت
❕ پس از تایید ادمین گزارش برای شما ارسال میشود
",
]);
MrMasih('sendmessage',[
'chat_id'=>$sench,
'text'=>"
🔸 #درخواست #نقدی برداشت

💸 مقدار پول برداشتی : $key
💳 شماره کارت : $key2
👤 ایدی کاربر : $key3

@IRA_Team
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ پرداخت کردیم",'callback_data'=>"abolmteamok|$key3|$key2|$key"]],
]
])
]);
$connect->query("UPDATE user SET bardashtha = '$kos2' WHERE id = '$key3' LIMIT 1");
$connect->query("UPDATE user SET coin = '$agycoin' WHERE id = '$key3' LIMIT 1");
$connect->query("INSERT INTO `allbardasht` (`id`,`noo`,`amount`,`date`,`time`,`admintime`,`hashed_id`) VALUES ('$key3','پول','$key','$abol22','$abol22:$abol122','IRA_Team','$key2')");
}else{
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
〽️ برداشت به هر دلیلی امکان پذیر نیس مجددا اقدام به برداشت کنید
",
]);
exit;
}
}
 
elseif(strpos($data,"abolmteamok|" ) !== false ){
$exit    = explode("|",$data);
$key     = $exit[1];
$key2    = $exit[2];
$key3    = $exit[3];
MrMasih('EditMessageText',[
'chat_id'=>$chatid,
'message_id'=>$messageid,
'text'=>"
✅ گزارش پرداختی برای کاربر درخواست دهنده ارسال شد!
",
]);
MrMasih('sendmessage',[
'chat_id'=>$key,
'text'=>"
✅ #گزارش موفق 

🔸 برداشت شما موفقیت امیز بود، مبلغ ($key3) به شماره کارت ($key2) انتقال داده شد

〽️ سازنده : @IRA_Team
",
]);
}

elseif($data == 'namaish'){
MrMasih('answercallbackquery', [
'callback_query_id' =>$callback_query_id,
'text' => '
❌ این دکمه نمایشی است
',
'show_alert' =>true
]);
}
## =-=-=-=-=-=-=-=-=-=// membership //=-=-=-=-=-=-=-=-=-= ##
if($update->chat_member->new_chat_member->status == 'left'){ 
$limitseke = $settingsdb['kasezir'];
$lfid=$update->chat_member->from->id;
$lfchan=$update->chat_member->chat->username;
$array = [];
foreach($Channels as $chy){
$tt=str_replace("@","",$chy);
$tt1=strtolower($tt);
$array[] =$tt1;
}
$lfchan1=strtolower($lfchan);
if(in_array($lfchan1,$array)) {

$data = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$lfid' LIMIT 1"));

$master=$data['master'];

if($master!=null){

$data1 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$master' LIMIT 1"));

$ncooin = $data1['coin'] - $limitseke;

$connect->query("UPDATE `user` SET `coin` = '$ncooin' WHERE `id` = '$master' LIMIT 1");
$connect->query("UPDATE `user` SET `master` = null WHERE `id` = '$lfid' LIMIT 1");

MrMasih('sendmessage',[
'chat_id'=>$lfid,
'text'=>"
❗️ شما از کانال های اصلی ما لفت دادید
",
]); 
MrMasih('sendmessage',[
'chat_id'=>$master,
'text'=>"
❗️ #هشدار_سیستم_زیرمجموعه_گیری

📍 بدلیل اوردن زییرمجموعه فیک تعداد ($limitseke) سکه از حساب شما کم شد.
",
]); 
MrMasih('sendmessage',[
'chat_id'=>$admin[0],
'text'=>"
📍 کاربری زیرمجموعه فیک اورد

🔸 زیرمجموعه کاربر: $lfid
🔹 اکانت اصلی کاربر : $master

〽️ تعداد $limitseke سکه از کاربر کم شد
",
]); 
}
}
}
## =-=-=-=-=-=-=-=-=-=// JOIN //=-=-=-=-=-=-=-=-=-= ##
elseif(check_join("$from_id")!='true'){
if($user['id'] != true)
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");    
is_join("$from_id");
exit;
}
## =-=-=-=-=-=-=-=-=-=// USER //=-=-=-=-=-=-=-=-=-= ##
if($user['id'] != true){
$connect->query("INSERT INTO `user` (`id`) VALUES ('$from_id')");}
## =-=-=-=-=-=-=-=-=-=// BACK //=-=-=-=-=-=-=-=-=-= ##
elseif($text == '🔙 بازگشت'){
if ($matnedb['mtnback'] != NULL){
$mtnback = $matnedb['mtnback'];
$mtnback = str_replace('NAME',$first_name,$mtnback);
$mtnback = str_replace('KARBARID',$from_id,$mtnback);
$mtnback = str_replace('USERNME',$username,$mtnback);
$mtnback = str_replace('TX',$text,$mtnback);
$mtnback = str_replace('TIMEIRAN',$time,$mtnback);
}else{
$mtnback = "
📍 به خانه برگشتیم
📍 اوپن شده در کانال تلگرامی »» @IRA_Team
";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
$mtnback
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}
## =-=-=-=-=-=-=-=-=-=// PHONE //=-=-=-=-=-=-=-=-=-= ##
elseif($user['step'] == 'phoneabolm' && $tc == 'private'){
if($contactid == $from_id){
$offset = strpos($contactnum,"98");
if ($offset !== false){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ عضویت شما تایید..

📍 همکنون میتوانید از ربات استفاده کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `phone` = '$contactnum' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("INSERT INTO `phone` (`id` , `phone`) VALUES ('$from_id' , '$contactnum')");
exit;
}else{
MrMasih('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"❗️فقط شماره های ایرانی قبول است",
]);	
exit;
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"جهت ارسال شماره از دکمه زیر استفاده کن",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'☎️ تایید شماره','request_contact' => true]],
],
'resize_keyboard'=>true,
])
]);		
exit;			
}
}
if($settingsdb['phone'] == "on"){
$masterphone    = $user['phone'];
if($masterphone==null){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔐 جهت استفاده از ربات باید شماره خود را تایید کنید

❗️ شماره شما نزد ما محفوظ میگردد و هیچکس دسترسی به ان را ندارد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'☎️ تایید شماره','request_contact' => true]],
],
'resize_keyboard'=>true,
])
]);
$connect->query("UPDATE `user` SET `step` = 'phoneabolm' WHERE `id` = '$from_id' LIMIT 1");		
exit;		
}	
}
## =-=-=-=-=-=-=-=-=-=// DOKE //=-=-=-=-=-=-=-=-=-= ##
if($text == '🎮 شروع بازی 🎮'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎮 یک دسته از بازی هارا انتخاب کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 بخش بازی های درحال حاضر قابل دسترسی نمیباشد.
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;	
}
}
## GAME
if($text == '🎮 برگشت 🎮'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎮 یک دسته از بازی هارا انتخاب کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}
 
## GAME
if($text == '💣 انفجار'){ 
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game11off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game11coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game11' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game11' && $tc == 'private'){
$limitcoin = $gamedb['game11coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار ضریب خودرا بین 1 تا 5 ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game11more' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `more` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game11more' && $tc == 'private'){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game11coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
$rand = rand(0,5);
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text > 0 and $text <= 5){
if($rand == 1){
$coin8  = $user['more'];
$sexcoi = $coin8 * $text;
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $sexcoi;
$allsx  = $hj - $sexcoi;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/386",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
💣 #انفجار

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار برد $sexcoi
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$irach   = $gamedb['channelshart'];
$coin8  = $user['more'];
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$sexcoi = $coin8 * $text;
$allabolm  = $hj + $sexcoi;
$allsx  = $hj - $sexcoi;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
if($irach !=null){
$irach   = $gamedb['channelshart'];
}else{
$irach   = $from_id;
} 
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/386",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
💣 #انفجار

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار باخت $sexcoi
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بین 1 تا 5 باید باشد ضریب
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍داش فقط عدد
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '🎰 ماشین اسکات'){ 
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game10off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game10coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game10' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game10' && $tc == 'private'){
$limitcoin = $gamedb['game10coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '🎰']);
$value = $dice->result->dice->value;
if($value == 64){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎰 #اسکات

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎰 #اسکات

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}

## GAME
if($text == '🎱 رولت'){ 
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game9off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game8coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game9' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game9' && $tc == 'private'){
$limitcoin = $gamedb['game8coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎱  از بین عدد 1 تا 8 یک عددرا انتخاب کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game9more' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `more` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game9more' && $tc == 'private'){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game9coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
$rand = rand(0,12);
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text > 0 and $text <= 8){
if($rand == 10 or $rand == 1 or $rand == 1){
$coin8  = $user['more'];
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $coin8;
$allsx  = $hj - $coin8;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/382",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎱 #رولت

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار برد $coin8
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$irach   = $gamedb['channelshart'];
$coin8  = $user['more'];
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $coin8;
$allsx  = $hj - $coin8;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
if($irach !=null){
$irach   = $gamedb['channelshart'];
}else{
$irach   = $from_id;
} 
 
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/382",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎱 #رولت

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار باخت $coin8
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
بین 1 تا 8 میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍داش فقط عدد
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '💩 پوپ'){ 
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game8off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game8coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game8' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game8' && $tc == 'private'){
$limitcoin = $gamedb['game8coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📦 از باکس های زیر یکیشونو انتخاب کن و عددشو برام بفرست

1  📦    2📦     3📦    4📦    5📦
6  📦    7📦     8📦    9📦  10📦
11📦  12📦  13📦  14📦  15📦
16📦  17📦  18📦  19📦  20📦
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game8more' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `more` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game8more' && $tc == 'private'){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game8coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
$rand = rand(0,20);
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text > 0 and $text <= 20){
if($rand == 11 or $rand == 20 or $rand == 1){
$coin8  = $user['more'];
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $coin8;
$allsx  = $hj - $coin8;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/385",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
💩 #پوپ

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار برد $coin8
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$irach   = $gamedb['channelshart'];
$coin8  = $user['more'];
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $coin8;
$allsx  = $hj - $coin8;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
if($irach !=null){
$irach   = $gamedb['channelshart'];
}else{
$irach   = $from_id;
} 
MrMasih('Sendsticker',['chat_id'=>$irach,'sticker'=>"https://t.me/tttosu/385",]);
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
💩 #پوپ

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $coin8
⭐️ مقدار باخت $coin8
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 تعداد جعبه هارو درست بشمار!
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍داش فقط عدد
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '🎲 تاس'){ 
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game7off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game7coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game7' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
 
## GAME
elseif($user['step'] == 'game7' && $tc == 'private'){
$limitcoin = $gamedb['game7coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '🎲']);
$value = $dice->result->dice->value;
if($value == 6){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎲 #تاس

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎲 #تاس

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}

## GAME
if($text == '👊🏻 سنگ کاغذ قیچی'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game6off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game6coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
} 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game6' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game6' && $tc == 'private'){
$limitcoin = $gamedb['game6coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
$rand = rand(0,5);
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
if($rand == 5 or $rand == 1){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
👊🏻 #سنگ_کاغذ_قیچی

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
👊🏻 #سنگ_کاغذ_قیچی

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}

 
## GAME
if($text == '🎯 دارت'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game5off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game5coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game5' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game5' && $tc == 'private'){
$limitcoin = $gamedb['game5coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '🎯']);
$value = $dice->result->dice->value;
if($value==6){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎯 #دارت

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎯 #دارت

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '✊ گل یا پوچ'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game4off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game4coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game4' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game4' && $tc == 'private'){
$limitcoin = $gamedb['game4coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
$rand = rand(0,5);
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
if($rand == 1 or $rand == 2){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
✊ #گل_یا_پوچ

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
✊ #گل_یا_پوچ

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '⚽️ فوتبال'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game3off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game3coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game3' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game3' && $tc == 'private'){
$limitcoin = $gamedb['game3coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '⚽️']);
$value = $dice->result->dice->value;
if($value == 3 or $value == 4 or $value == 5 or $value == 6 ){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
⚽️ #فوتبال

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
⚽️ #فوتبال

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
if($text == '🎳 بولینگ'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game2off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game2coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game2' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
 
## GAME
elseif($user['step'] == 'game2' && $tc == 'private'){
$limitcoin = $gamedb['game2coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '🎳']);
$value = $dice->result->dice->value;
if($value==6){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎳 #بولینگ

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🎳 #بولینگ

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}
 
## GAME
if($text == '🏀 بسکتبال'){
if ($gamedb['allgame'] == "on" or in_array($from_id,$admin)){
if ($gamedb['game1off'] == "on" or in_array($from_id,$admin)){
$irach = $gamedb['channelshart'];
$limitcoin = $gamedb['game1coin'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید شرط ببندید را بفرستید
🔸 حداقل مقدار شرط : $limitcoin
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🎮 برگشت 🎮"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'game1' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این دکمه خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍کلیه بازی ها خاموش میباشند
",
'reply_to_message_id'=>$message_id,
]);
}
}
## GAME
elseif($user['step'] == 'game1' && $tc == 'private'){
$limitcoin = $gamedb['game1coin'];
$irach = $gamedb['channelshart'];
if($irach !=null){
$irach = $gamedb['channelshart'];
}else{
$irach = $from_id;
}
if(preg_match("/^[0-10-9]+$/", $text)) {
if($text >= $limitcoin){
if($user['coin'] >= $text){
$dice = MrMasih('sendDice',['chat_id' => $irach,'emoji'=> '🏀']);
$value = $dice->result->dice->value;
if($value == 4 or $value == 5 or $value == 6){
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🏀 #بسکتبال

🔖 وضعیت : برد

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار برد $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه پرداخت خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bord` = '$allbo' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allabolm' WHERE `id` = '$from_id' LIMIT 1");	
}else{
$bo     = $user['bord'];
$bk     = $user['bakht'];
$hj     = $user['coin'];
$allabolm  = $hj + $text;
$allsx  = $hj - $text;
$allbo  = $bo + 1;
$allbk  = $bk + 1;
MrMasih('sendmessage',[
'chat_id'=>$irach,
'text'=>"
🏀 #بسکتبال

🔖 وضعیت : باخت 

👤 کاربر » $from_id
💸 مقدار شرط » $text
⭐️ مقدار باخت $text
",
]);
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نتیجه شرط خودرا میتوانید در کانال ما ببینید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$game_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `bakht` = '$allbk' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `coin` = '$allsx' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار شرط بسته شده با موجودی شما هماهنگ نیست
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت $limitcoin سکه است
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد میتوانید ارسال کنید
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🏦 انتقال سکه'){
if ($settingsdb['kharid'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= "1000"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔸 ایدی عددی کاربر را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
]);
$connect->query("UPDATE `user` SET `step` = 'sendmembercoin' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 برای انتقال باید حتما 1000 سکه داشته باشید
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 انتقال موجودی توسط ادمین خاموش شده
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($user['step'] == 'sendmembercoin' && $tc == 'private'){
$carbar = $text;
$user2  = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$carbar' LIMIT 1"));
if($user2['id'] != true){
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 این کاربر در ربات وجود ندارد
",
'reply_to_message_id'=>$message_id,
]);
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
💲 مقدار سکه ای که میخواهید انتقال دهید را وارد کنید
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'sendmembercoin2' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `user` SET `more` = '$text' WHERE `id` = '$from_id' LIMIT 1");	
}
}

elseif($user['step'] == 'sendmembercoin2' && $tc == 'private'){
$carbar = $user['more'];
$cosh   = $text;
if(is_numeric($cosh)){
$torbo = time();
$abol22  = date('H'); 
$abol222 = date('i'); 
$abol2222 = date('s');
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
$userdes = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$carbar' LIMIT 1"));
if($user['coin']>=$cosh+300){
$coindes = $userdes['coin'] + $cosh ;
$coinuser = $user['coin'] - $cosh; 
MrMasih('sendmessage',[       
'chat_id'=>$carbar,
'text'=>"
✅ مقدار ($cosh) سکه از کاربر ($from_id) دریافت کردید
",
]);
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
✅ #انتقال موجودی موفقیت امیزبود

🔸 شما تعداد $cosh  سکه را به کاربر $carbar انتقال دادید
",
'reply_markup'=>$home
]);
MrMasih('sendmessage', [
'chat_id'=>$admin[0],
'text'=>"
⭕️ #گزارش_انتقال (سکه)

👤 کاربر $from_id تعداد ($cosh) سکه رابه کاربر $carbar انتقال داد!
",
]);	
$connect->query("UPDATE `user` SET `coin` = '$coindes' WHERE `id` = '$carbar' LIMIT 1");
$connect->query("UPDATE `user` SET `coin` = '$coinuser' WHERE `id` = '$from_id' LIMIT 1");   
$connect->query("INSERT INTO `pay` (`id` , `order_id` , `amount` , `track_idpay` , `track_id` , `amount_payment` , `date` , `hashed_card` , `card_number` , `hojjat`) VALUES ('$from_id' , '$carbar' , '$text' , '$from_id^abolm' , '1234' , '300' , '$abol22:$abol222:$abol2222' , '$text^12' , '$from_id' , 'creator')");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `more` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"❌ #خطا
شما باید حتما 300 سکه در حساب خود باقی بگذارید",
'reply_markup'=>$home
]);   
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
}else{
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"❗️#ورودی_نادرست",'reply_markup'=>$home
]);         
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");        
}}

elseif($text == '🛒 خرید سهام'){
if ($sahamdb['off'] == "on" or in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🏪 به بخش سهام مرکزی خوش امدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$sahamm_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 بخش سهام فعلا در دسترسی نمیباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;	
}
}

elseif($text == '👤 حساب من'){
if(GetProfile($from_id)){
$profile            = json_decode(file_get_contents("https://api.telegram.org/bot$Token/getUserProfilePhotos?user_id=$from_id"));
$photo1             = $profile->result->photos[0][0]->file_id;
$hojjat1            = jdate('Y'); 
$hojjat2            = jdate('m'); 
$hojjat3            = jdate('d'); 
$roz                = jdate('l'); 
MrMasih('sendphoto',[
'chat_id'=>$from_id,
'photo'=>"$photo1",
'caption'=>"
📋 اطلاعات حساب شما در ربات »
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
    [['text'=>"$first_name",'callback_data'=>"namaish"],['text'=>"🗣 نام:",'callback_data'=>"namaish"]],
    [['text'=>"$from_id",'callback_data'=>"namaish"],['text'=>"👤 ایدی عددی:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['coin']} سکه",'callback_data'=>"namaish"],['text'=>"💰 موجودی:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['saham']}",'callback_data'=>"namaish"],['text'=>"💸 سهام:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['member']} نفر",'callback_data'=>"namaish"],['text'=>"👥 تعداد زیرمجموعه:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['bardashtha']}",'callback_data'=>"namaish"],['text'=>"💳 برداشت ها:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['bord']}",'callback_data'=>"namaish"],['text'=>"🏆 برد ها:",'callback_data'=>"namaish"]],
    [['text'=>"{$user['bakht']}",'callback_data'=>"namaish"],['text'=>"😖 باخت ها:",'callback_data'=>"namaish"]],
    [['text'=>"$hojjat1/$hojjat2/$hojjat3",'callback_data'=>"namaish"],['text'=>"$time",'callback_data'=>"namaish"]],
]
])
]);
}
else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ شما دسترسی به این بخش را ندارید!

📍 جهت دسترسی به این بخش پروفایل خود را ازاد کنید!
📍 مطمعن شوید که اکانت شما دارای پروفایل است!
",
]);
}
}

elseif($text == '❌ منصرف شدم ❌'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 به قسمت برداشت موجودی خوش آمدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}

elseif($text == '➖ برداشت موجودی'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 به قسمت برداشت موجودی خوش آمدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}

elseif($text == '🤖 هارپ سین'){
$limitcoin = $settingsdb['harpbot'];
if($bardashdb['b5'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= $limitcoin){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید برداشت کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"❌ منصرف شدم ❌"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtpool5' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت هارپ سین $limitcoin میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 برداشت هارپ سین خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
}

elseif($user['step'] == 'bardashtpool5' && $tc == 'private'){
$limitcoin  = $text;
$limitcoin2 = $settingsdb['harpbot'];
$channelser = $settingsdb['channel'];
if($channelser!=null){
$channelser = $settingsdb['channel'];
}else{
$channelser = $admin[0];
}
if($limitcoin >= $limitcoin2){
if($user['coin'] >= $limitcoin){
$cos = $user['coin'];
$cos2 = $cos - $text;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ درخواست شما باموفقیت ارسال شد..
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
MrMasih('sendmessage',[
'chat_id'=>$channelser,
'text'=>"
📍 #درخواست #هارپ_سین

👤 ایدی کاربر : $from_id
💸 مبلغ برداشتی : $text

🔸 تیم برنامه نویسی آیرا تیم
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ پرداخت شد",'callback_data'=>"harp|$from_id|$limitcoin"]],
]
])
]);
$connect->query("UPDATE user SET coin = '$cos2' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ موجودی شما برابری با درخواستتان نمیکند
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🥸 رفیق حداقل برداشتو دقت کن بعد درخواست بده
حداقل برداشت $limitcoin2
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🤖 آوید سین'){
$limitcoin = $settingsdb['avidbot'];
if($bardashdb['b4'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= $limitcoin){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید برداشت کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"❌ منصرف شدم ❌"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtpool3' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت آوید سین $limitcoin میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 برداشت آوید سین خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
}

elseif($user['step'] == 'bardashtpool3' && $tc == 'private'){
$limitcoin  = $text;
$limitcoin2 = $settingsdb['avidbot'];
$channelser = $settingsdb['channel'];
if($channelser!=null){
$channelser = $settingsdb['channel'];
}else{
$channelser = $admin[0];
}
if($limitcoin >= $limitcoin2){
if($user['coin'] >= $limitcoin){
$cos = $user['coin'];
$cos2 = $cos - $text;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ درخواست شما باموفقیت ارسال شد..
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
MrMasih('sendmessage',[
'chat_id'=>$channelser,
'text'=>"
📍 #درخواست #آوید_سین

👤 ایدی کاربر : $from_id
💸 مبلغ برداشتی : $text

🔸 تیم برنامه نویسی آیرا تیم
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ پرداخت شد",'callback_data'=>"avidsexy|$from_id|$limitcoin"]],
]
])
]);
$connect->query("UPDATE user SET coin = '$cos2' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ موجودی شما برابری با درخواستتان نمیکند
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🥸 رفیق حداقل برداشتو دقت کن بعد درخواست بده
حداقل برداشت $limitcoin2
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🤖 نیتروسین'){
$limitcoin = $settingsdb['nitrbot'];
if($bardashdb['b3'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= $limitcoin){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید برداشت کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"❌ منصرف شدم ❌"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtpool2' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت نیترو سین $limitcoin میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 برداشت نیترو سین خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
}

elseif($user['step'] == 'bardashtpool2' && $tc == 'private'){
$limitcoin  = $text;
$limitcoin2 = $settingsdb['nitrbot'];
$channelser = $settingsdb['channel'];
if($channelser!=null){
$channelser = $settingsdb['channel'];
}else{
$channelser = $admin[0];
}
if($limitcoin >= $limitcoin2){
if($user['coin'] >= $limitcoin){
$cos = $user['coin'];
$cos2 = $cos - $text;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ درخواست شما باموفقیت ارسال شد..
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
MrMasih('sendmessage',[
'chat_id'=>$channelser,
'text'=>"
📍 #درخواست #نیترو_سین

👤 ایدی کاربر : $from_id
💸 مبلغ برداشتی : $text

🔸 تیم برنامه نویسی آیرا تیم
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ پرداخت شد",'callback_data'=>"nitroseen|$from_id|$limitcoin"]],
]
])
]);
$connect->query("UPDATE user SET coin = '$cos2' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ موجودی شما برابری با درخواستتان نمیکند
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🥸 رفیق حداقل برداشتو دقت کن بعد درخواست بده
حداقل برداشت $limitcoin2
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🤖 کیوت سین'){
$limitcoin = $settingsdb['kutbot'];
if($bardashdb['b2'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= $limitcoin){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه ای که میخواهید برداشت کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"❌ منصرف شدم ❌"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtpool1' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت کیوت سین $limitcoin میباشد
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 برداشت کیوت سین خاموش میباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
}

elseif($user['step'] == 'bardashtpool1' && $tc == 'private'){
$limitcoin  = $text;
$limitcoin2 = $settingsdb['kutbot'];
$channelser = $settingsdb['channel'];
if($channelser!=null){
$channelser = $settingsdb['channel'];
}else{
$channelser = $admin[0];
}
if($limitcoin >= $limitcoin2){
if($user['coin'] >= $limitcoin){
$cos = $user['coin'];
$cos2 = $cos - $text;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ درخواست شما باموفقیت ارسال شد..
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
]);
MrMasih('sendmessage',[
'chat_id'=>$channelser,
'text'=>"
📍 #درخواست #کیوت_سین

👤 ایدی کاربر : $from_id
💸 مبلغ برداشتی : $text

🔸 تیم برنامه نویسی آیرا تیم
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ پرداخت شد",'callback_data'=>"kuteseen|$from_id|$limitcoin"]],
]
])
]);
$connect->query("UPDATE user SET coin = '$cos2' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ موجودی شما برابری با درخواستتان نمیکند
",
'reply_to_message_id'=>$message_id,
]);
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🥸 رفیق حداقل برداشتو دقت کن بعد درخواست بده
حداقل برداشت $limitcoin2
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '💳 برداشت نقدی'){
if($bardashdb['b1'] == "on" or in_array($from_id,$admin)){
if($user['coin'] >= "50000"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 لطفا شماره کارت خودرا برای ما ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"❌ منصرف شدم ❌"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtpool' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل میزان برداشت 50000 تومان میباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 برداشت نقدی در دسرس نمیباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}
}

elseif($user['step'] == 'bardashtpool' && $tc == 'private'){
$cardif         = $text;
$bardashcoins   = $user['coin'];
$abol_card        = file_get_contents("https://okaliptoos-api.ir/cardbank/index.php?card=$cardif");
$abolpr           = json_decode($abol_card,true);
$bank1          = $abolpr["Result"]["bankname"];
if ($abolpr["ok"] == true){
$id = MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🏦 کارت شما متعلق به $bank1 است

❗️ ایا جهت برداشت اماده اید؟
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bardashtabolmteam
])->result->message_id;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔹 آیا میخواهید مبلغ $bardashcoins تومان را به حساب <code>$cardif</code> واریز کنید؟

⌚️ برداشت ها تا 12 ساعت اینده انجام میشود

⁉️ آیا برداشت را تایید میکنید؟
",
'parse_mode'=>'html',
'reply_to_message_id'=>$id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ تایید میکنم",'callback_data'=>"bardasht|$bardashcoins|$cardif|$from_id"]],
]
])
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ شماره کارت درست وارد نشده
",
'reply_to_message_id'=>$message_id,
]);
}
}

if($text == '➕ افزایش موجودی'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 یکی از روش های زیر را جهت افزایش موجودی انتخاب کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$mjabolm_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}

elseif($text == '💲 برداشت سهام'){
if ($sahamdb['off'] == "on" or in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سهام برداشتی را وارد کنید...
❗️ به یاد داشته باشید هر یک سهام معادل ({$sahamdb['coin']}) سکه میباشد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
        [['text'=>"🛒 خرید سهام"]],
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'bardashtsahamabolm' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 بخش سهام فعلا در دسترسی نمیباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;	
}
}

elseif($user['step'] == 'bardashtsahamabolm' && $tc == 'private'){
$sahamamut = $sahamdb['coin'];
if(!$text == "0"){
if(preg_match("/^[0-10-9]+$/", $text)) {
$amount = $text * $sahamamut;
if($user['saham'] >= $amount){
MrMasih('sendmessage',[       
'chat_id'=>$from_id,
'text'=>'
⏳ کمی صبرکنید..
',
'reply_to_message_id'=>$message_id,
]);
$moscoin        = $user['coin'] + $text;
$kasrsahamns    = $user['saham'] - $amount;
$connect->query("UPDATE `user` SET `coin` = '$moscoin' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `saham` = '$kasrsahamns' WHERE `id` = '$from_id' LIMIT 1");
MrMasih('sendmessage',[       
'chat_id'=>$from_id,
'text'=>"
✅ #تراکنش_موفق
📍 تعداد ($text) سکه از سهام بدست آوردید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$sahamm_panel
]); 
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else
MrMasih('sendmessage',[       
'chat_id'=>$from_id,
'text'=>'
📍 با این تعداد سهام نمیتوانید برداشتی انجام دهید
',
'reply_to_message_id'=>$message_id,
]);  
}else
MrMasih('sendmessage',[       
'chat_id'=>$from_id,
'text'=>'
📍 فقط عدد وارد کنید
',
'reply_to_message_id'=>$message_id,
]);  
}
}
 
elseif($text == '🏦 استعلام سهام'){
if ($sahamdb['off'] == "on" or in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🧮 وضعیت امروز سهام:

💰 مقدار سهام شما : {$user['saham']}
💸 درصد امروز سهام : {$sahamdb['ondarsad']}
🔗 وضعیت امروز سهام : {$sahamdb['kk']}
🔖 آخرین تایم آپدیت : {$sahamdb['uptime']}

🪅 هر یک سهام معادل ({$sahamdb['coin']}) سکه میباشد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$sahamm_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 بخش سهام فعلا در دسترسی نمیباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;	
}
}

elseif($text == '👥 زیرمجموعه گیری'){
$nemidkasr = $settingsdb['kasezir'];
$id = MrMasih('sendphoto',[
'chat_id'=>$from_id,
'photo'=>$baner,
'caption'=>"
💸 به برترین ربات شرطبندی ایران خوش امدید

💰 دوس داری بدون هزینه پول دار بشی؟
😉 بشین پس بگم درمورد این ربات

⭐️ کسب درامد بدون هزینه
⭐️ پرداخت های اینترنتی و با سرعت بالا
⭐️ کسب درامد انواع ارز های مجازی
⭐️ دارای بیش از 12 گیم مختلف
⭐️ دارای بیش از 20 راه برای کسب پول
⭐️ دارای خرید سهام ربات و سود ان
⭐️ کاملا قانونی و رایگان

🔰 حلال میباشد

🔗 t.me/$botusername?start=$from_id
",
])->result->message_id;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👆🏻 بنر بالا را به دوستان و اشنایان خود بفرستید تا بتوانید کسب درآمد ملیونی خودرا شروع کنید

⚜️ به یاد داشته باشید اوردن هر زیرمجموعه فیک باعث کسر ($nemidkasr) سکه میشود
⚜️ نیازی نیست زیرمجموعه های شما تایید شماره را انجام دهند

😉 بامعرفی ربات به دوستات بازی کن و ملیونر شو..

@$botusername
",
'reply_to_message_id'=>$id,
]);
}

elseif($text == '💰 خرید سکه'){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🙃 جهت خرید سکه به پیوی مراجعه کنید
@hojjat_jh
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🎁 سکه روزانه'){
$TimeLast = $user['roz'];
$TimeNew  = time() +86400 ;
if($TimeLast !=NULL){
$TimeLast = $user['roz'];
}else{
$TimeLast = "0";
}
$sadasd = time();
if($sadasd < $TimeLast){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🙃 هر 24 ساعت میتونی سکه دریافت کنی..
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
$rozcoin    = $settingsdb['rozcoin'];
$allcoin    = $user['coin'];
$TimeNew    = time()+86400 ;
$hojjatcoin = $allcoin + $rozcoin;
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎰 برای امروز ($rozcoin) سکه گرفتی.

😄 فردا منتظرتم رفیق..
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `roz` = '$TimeNew' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `coin` = '$hojjatcoin' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");		
}
}

elseif($text == '🛍 خرید سهام'){
if ($sahamdb['off'] == "on" or in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🪅 هر یک سهام معادل ({$sahamdb['coin']}) سکه میباشد
🔖 جهت خرید سهام به پیوی مراجعه کنید

@hojjat_jh
@kingm40
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$sahamm_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
exit;
}else{
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 بخش سهام فعلا در دسترسی نمیباشد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;	
}
}

elseif($text == '/prices'){
MrMasih('sendmessage',[  
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت نیتروسین : {$settingsdb['nitrbot']}
📍 حداقل برداشت کیوت سین : {$settingsdb['kutbot']}
📍 حداقل برداشت هارپسین : {$settingsdb['harpbot']}
📍 حداقل برداشت آویدسین : {$settingsdb['avidbot']}
",
'reply_to_message_id'=>$message_id,
]);
}
## =-=-=-=-=-=-=-=-=-=// PANEL ADMIN //=-=-=-=-=-=-=-=-=-= ##
$base_panel = json_encode([
'keyboard'=>[
        [['text'=>'📈 اطلاعات ربات']],
        [['text'=>"🏦 مدیریت سهام"],['text'=>'🤖 مدیریت ربات']],
        [['text'=>"📝 مدیریت متن ها"],['text'=>'👤 مدیریت کاربران']],
        [['text'=>'🎮 مدیریت بازی ها'],['text'=>'🔐 مدیریت قفل ها']],
        [['text'=>"📥 مدیریت دیتا"],['text'=>'⚙️ سایر تنظیمات']],
        [['text'=>"📨 فوروارد همگانی"],['text'=>'📨 پیام همگانی']],
        [['text'=>"🔸 پنل کاربران"],['text'=>'🔹 سازنده ربات']],
],
'resize_keyboard'=>true,
]);
$bot_pnadmin = json_encode([
'keyboard'=>[
        [['text'=>'📈 اطلاعات ربات']],
        [['text'=>"🌚 خاموش کردن"],['text'=>'🌞 روشن کردن']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$saham_adpanel = json_encode([
'keyboard'=>[
        [['text'=>'📋 استعلام وضعیت']],
        [['text'=>"⭕️ تنظیم ارزش سهام"],['text'=>'⭕️ تغیر سود فردا']],
        [['text'=>"🔸 تنظیم کانال سهام"],['text'=>'🔸 خاموش / روشن سهام']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$memberirateam = json_encode([
'keyboard'=>[
        [['text'=>"📨 پیام رسان"],['text'=>'🔍 اطلاعات کاربر']],
        [['text'=>"🏦 کسر سهام"],['text'=>'🏦 افزایش سهام']],
        [['text'=>"💰 کسر سکه"],['text'=>'💰 افزایش سکه']],
        [['text'=>"🔴 بلاک"],['text'=>'🟢 انبلاک']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$mtsadaira = json_encode([
'keyboard'=>[
        [['text'=>"📝 متن زیرمجموعه گیری"]],
        [['text'=>"📝 متن خاموشی"],['text'=>'📝 متن استارت']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$ghoflpanelira = json_encode([
'keyboard'=>[
        [['text'=>"🔑 انتقال سکه"]],
        [['text'=>"🔑 برداشت نقدی"],['text'=>'🔑 سهام']],
        [['text'=>"🔑 نیتروسین"],['text'=>'🔑 کیوت سین']],
        [['text'=>"🔑 اوید سین"],['text'=>'🔑 هارپ سین']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$gameiraabol = json_encode([
'keyboard'=>[
        [['text'=>"🎮"]],
        [['text'=>"📳 تمام باری ها"],['text'=>'📣 تنظیم کانال']],
        [['text'=>"🏀 حداقل"],['text'=>'🏀 وضعیت']],
        [['text'=>"🎳 حداقل"],['text'=>'🎳 وضعیت']],
        [['text'=>"⚽️ حداقل"],['text'=>'⚽️ وضعیت']],
        [['text'=>"🤜 حداقل"],['text'=>'🤜 وضعیت']],
        [['text'=>"🎯 حداقل"],['text'=>'🎯 وضعیت']],
        [['text'=>"🤞 حداقل"],['text'=>'🤞 وضعیت']],
        [['text'=>"🎲 حداقل"],['text'=>'🎲 وضعیت']],
        [['text'=>"💩 حداقل"],['text'=>'💩 وضعیت']],
        [['text'=>"🎱 حداقل"],['text'=>'🎱 وضعیت']],
        [['text'=>"🎰 حداقل"],['text'=>'🎰 وضعیت']],
        [['text'=>"💣 حداقل"],['text'=>'💣 وضعیت']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$saiertanzimirateam = json_encode([
'keyboard'=>[
        [['text'=>"📍 اطلاعات مادر"],['text'=>'🤘 کانال ادمین ها']],
        [['text'=>"☎️ تایید شماره"],['text'=>'💰 سکه روزانه']],
        [['text'=>"💬 ثبت ادمین"],['text'=>'🤖 نام ربات']],
        [['text'=>"➕ سکه زیرمجموعه جدید"],['text'=>'➖ سکه زیرمجموعه فیک']],
        [['text'=>'💲 حداقل برداشت نیتروسین']],
        [['text'=>'💲 حداقل برداشت کیوت سین']],
        [['text'=>'💲 حداقل برداشت هارپ سین']],
        [['text'=>'💲 حداقل برداشت آوید سین']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
$abolmodiraitedata = json_encode([
'keyboard'=>[
        [['text'=>"📥 بکاپ از سورس مادر"],['text'=>'📥 بکاپ از اطلاعات'],['text'=>'📥 بکاپ از سهام']],
        [['text'=>'👨🏼‍💼 پنل مدیریت 👨🏼‍💼']],
],
'resize_keyboard'=>true,
]);
## =-=-=-=-=-=-=-=-=-=// ADMIN //=-=-=-=-=-=-=-=-=-= ##
if($text == '🔸 پنل کاربران' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حالت ممبر فعال شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

if($text == '⚙️ مدیریت ⚙️' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👨🏼‍💼 سلام ادمین عزیز به پنل مدیریتی ربات خوش اومدی
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$base_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

if($text == '👨🏼‍💼 پنل مدیریت 👨🏼‍💼' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 اوکی برگشتیم...
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$base_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}
 
elseif($text == '📍 اطلاعات مادر' and $tc == 'private' and in_array($from_id,$admin)){
$starttime      = microtime(true);
$alluser        = mysqli_num_rows(mysqli_query($connect,"select `id` from `user`"));
$allban         = mysqli_num_rows(mysqli_query($connect,"select `id` from `block`"));
$allpay         = mysqli_num_rows(mysqli_query($connect,"select `id` from `pay`"));
$allbardasht    = mysqli_num_rows(mysqli_query($connect,"select `id` from `allbardasht`"));
$member         = mysqli_num_rows(mysqli_query($connect,"select `id` from `member`"));
$endtime        = (microtime(true) - $starttime);
$telegram_ping  = substr($endtime, 0, -11);
$memUsage       = memUsage(true);
$domain         = $_SERVER['SERVER_NAME'];
$load           = sys_getloadavg();
$mem            = getMUsage();
$ver            = phpversion(); 
$off            = $settingsdb['abolmoff'];
if($off == "on"){
$abol             = "روشن";
}else{
$abol             = "خاموش";
}
if($settingsdb['phone'] == "on"){
$jjj = "روشن است";
}else{
$jjj = "خاموش است";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📈 آمار ربات شما بدین شرح میباشد:
        
🤖 وضعیت ربات : <code>$abol</code>
☎️ تایید شماره » <code>$jjj</code>

👤 تعداد کاربران ربات: <code>$alluser</code>
❌ تعداد افراد مسدود: <code>$allban</code>

💳 تعدا انتقال ها : <code>$allpay</code>
🏦 تعداد برداشت ها : <code>$allbardasht</code>
👤 تعداد زیرمجموعه ها : <code>$member</code>

---------------------------------------
🔳 حداقل برداشت ها »»

⚪️ نیتروسین » <code>{$settingsdb['nitrbot']}</code>
🟢 کیوت سین » <code>{$settingsdb['kutbot']}</code>
🔵 هارپ سین » <code>{$settingsdb['harpbot']}</code>
🟡 آوید سین » <code>{$settingsdb['avidbot']}</code>

---------------------------------------
🚀 Telegram ping : $telegram_ping ms
🗂 Memory Usage : $memUsage
📉 Load avg : $load[0]
",
'reply_to_message_id'=>$message_id,
'parse_mode'=>'html',
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '📈 اطلاعات ربات' and $tc == 'private' and in_array($from_id,$admin)){
$starttime      = microtime(true);
$alluser        = mysqli_num_rows(mysqli_query($connect,"select `id` from `user`"));
$allban         = mysqli_num_rows(mysqli_query($connect,"select `id` from `block`"));
$allpay         = mysqli_num_rows(mysqli_query($connect,"select `id` from `pay`"));
$allbardasht    = mysqli_num_rows(mysqli_query($connect,"select `id` from `allbardasht`"));
$member         = mysqli_num_rows(mysqli_query($connect,"select `id` from `member`"));
$endtime        = (microtime(true) - $starttime);
$telegram_ping  = substr($endtime, 0, -11);
$memUsage       = memUsage(true);
$domain         = $_SERVER['SERVER_NAME'];
$load           = sys_getloadavg();
$mem            = getMUsage();
$ver            = phpversion(); 
$off            = $settingsdb['abolmoff'];
if($off == "on"){
$abol             = "روشن";
}else{
$abol             = "خاموش";
}
if($settingsdb['phone'] == "on"){
$jjj = "روشن است";
}else{
$jjj = "خاموش است";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📈 آمار ربات شما بدین شرح میباشد:
        
🤖 وضعیت ربات : $abol
☎️ تایید شماره » $jjj

👤 تعداد کاربران ربات: $alluser
❌ تعداد افراد مسدود: $allban

💳 تعدا انتقال ها : $allpay
🏦 تعداد برداشت ها : $allbardasht
👤 تعداد زیرمجموعه ها : $member

---------------------------------------

🚀 Telegram ping : $telegram_ping ms
🗂 Memory Usage : $memUsage
📉 Load avg : $load[0]
📌 PHP Version : $ver
📁 Usage : $mem

",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

if($text == '🔹 سازنده ربات' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 این ربات توسط تیم (آیرا تیم) ساخته شده است!
📍 کانال تلگرامی ما » @IRA_Team

📍 منبع نزدن شما باعث از دست دادن مادر خود میشود...
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$base_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🤖 مدیریت ربات' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🤖 به پنل مدیریت ربات خوش اومدی
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bot_pnadmin
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🌞 روشن کردن' and $tc == 'private' and in_array($from_id,$admin)){
$what = $settingsdb['abolmoff'];
if($what == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🌞 ربات باموفقیت روشن شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bot_pnadmin
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settings` SET `abolmoff` = 'on' WHERE `name` = 'abolm' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ ربات از قبل روشن بوده
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bot_pnadmin
]);
}
}

elseif($text == '🌚 خاموش کردن' and $tc == 'private' and in_array($from_id,$admin)){
$what = $settingsdb['abolmoff'];
if($what == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💤 ربات باموفقیت برای کاربران خاموش شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bot_pnadmin
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settings` SET `abolmoff` = 'off' WHERE `name` = 'abolm' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ ربات از قبل خاموش بوده
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$bot_pnadmin
]);
}
}

elseif ($text == '📨 پیام همگانی' and $tc == 'private' and in_array($from_id,$admin)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"🔆 لطفا متن یا رسانی خود را ارسال کنید نمیتواند شامل دکمه شیشه ای باشد!",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"⚙️ مدیریت ⚙️"]]
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'sendtoall' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($user['step'] == 'sendtoall') {
$caption = $update->message->caption;
if(isset($message->photo)){
$photo = $message->photo[count($message->photo)-1]->file_id;
$abol = "1";
$abol1 = "تصویر";
}
if(isset($message->text)){
$abol = "2";
$abol1 = "متن";
}
if(isset($message->video)){
$photo = $message->video->file_id;
$abol = "3";
$abol1 = "فیلم";
}
if(isset($message->document)){
$photo = $message->document->file_id;
$abol = "4";
$abol1 = "فایل";
}
if(isset($message->audio)) {
$photo = $message->audio->file_id;
$abol = "5";
$abol1 = "صدا";
}
if(isset($message->voice)) {
$photo = $message->voice->file_id;
$abol = "6";
$abol1 = "ویس";
}
if(isset($message->sticker)) {
$photo = $message->sticker->file_id;
$abol = "7";
$abol1 = "استیکر";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ $abol1 شما برای ارسال همگانی تنظیم شد
",
'reply_markup'=>$base_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall` SET step = 'send' , `text` = '$text$caption' , `chat` = '$photo' , `abcd` = '$abol' LIMIT 1");			
}

elseif ($text == '📨 فوروارد همگانی' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"🔆 لطفا پیام خود را فوروارد کنید",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"⚙️ مدیریت ⚙️"]]
],
'resize_keyboard'=>true
])
]);
$connect->query("UPDATE `user` SET `step` = 'fortoall' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($user['step'] == 'fortoall') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",
'reply_markup'=>$base_panel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `sendall` SET `step` = 'forward' , `text` = '$message_id' , `chat` = '$from_id' LIMIT 1");		
}

elseif($text == '📥 بکاپ از سهام' and $tc == 'private' and in_array($from_id,$admin)) {
MrMasih('sendDocument',[
'chat_id'=>$from_id,
'caption'=>"✅ بکاپ از سهام باموفقیت گرفته شد",
'document'=>new CURLFILE('lib/saham.php')
]);
}

elseif($text == '📥 بکاپ از اطلاعات' and $tc == 'private' and in_array($from_id,$admin)) {
MrMasih('sendDocument',[
'chat_id'=>$from_id,
'caption'=>"✅ بکاپ از کانفینگ باموفقیت گرفته شد",
'document'=>new CURLFILE('config.php')
]);
}

elseif($text == '📥 بکاپ از سورس مادر' and $tc == 'private' and in_array($from_id,$admin)) {
MrMasih('sendDocument',[
'chat_id'=>$from_id,
'caption'=>"✅ بکاپ از سورس مادر باموفقیت گرفته شد",
'document'=>new CURLFILE('bot.php')
]);
}

elseif($text == '📥 مدیریت دیتا' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📥 به بخش مدیریت دیتای ربات آیرا تیم خوش اومدی
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$abolmodiraitedata
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}
 
elseif($text == '⚙️ سایر تنظیمات' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
⚙️ به بخش سایر تنظیمات خوش اومدی
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '💲 حداقل برداشت آوید سین' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['avidbot'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت آویدسین را وارد کنید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz5' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz5') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `avidbot` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '💲 حداقل برداشت هارپ سین' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['harpbot'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت هارپسین را وارد کنید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz4' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz4') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `harpbot` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '💲 حداقل برداشت کیوت سین' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['kutbot'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت کیوتسین را وارد کنید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz3' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz3') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `kutbot` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '💲 حداقل برداشت نیتروسین' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['nitrbot'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 حداقل برداشت نیتروسین را وارد کنید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz2' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz2') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `nitrbot` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '➕ سکه زیرمجموعه جدید' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['zircoin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 تعداد سکه ای که با اوردن هر زیرمجموعه کاربر بتواند بدست بیارد را بفرستید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz1' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz1') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `zircoin` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}
 
elseif($text == '➖ سکه زیرمجموعه فیک' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['kasezir'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 تعداد سکه ای که میخواهید با اوردن زیرمجموعه فیک از کاربر کم شود را بفرستید

⭐️ سکه فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'irateamaboltsz' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'irateamaboltsz') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `kasezir` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '🤘 کانال ادمین ها' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['channel'];
if($IRA_Team != null){
$IRA_Team = $settingsdb['channel'];
}else{
$IRA_Team = "کانالی ثبت نشده";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ ایدی عددی کانال ادمین هارا بفرستید

🔸 کانال فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'turbosettin1111' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'turbosettin1111') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `channel` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '💬 ثبت ادمین' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['adminnitroseen'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💬 ایدی عددی ادمین اصلی را وارد کنید

🔸 ادمین فعلی » $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'turbosettin1' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'turbosettin1') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ تایید شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `adminnitroseen` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}
}

elseif($text == '🤖 نام ربات' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['rozcoin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 نام ربات جهت نمایش در دیتابیس را ارسال کنید

❗️ این نام برای کاربران قابل نمایش نمیباشد!
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'turbosettingira1' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'turbosettingira1') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `namebot` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '💰 سکه روزانه' and $tc == 'private' and in_array($from_id,$admin)){
$IRA_Team = $settingsdb['rozcoin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 مقدار سکه روزانه جدید را وارد کنید

⚜️ سکه روزانه فعلی : $IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'⚙️ سایر تنظیمات']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'turbosettingira' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'turbosettingira') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ از امروز هر کاربر میتواند ($text) سکه روزانه دریافت کند
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saiertanzimirateam
]);  
$connect->query("UPDATE `settings` SET `rozcoin` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد
",
'reply_to_message_id'=>$message_id,
]);  
}}
 
elseif($text == '☎️ تایید شماره' and $tc == 'private' and in_array($from_id,$admin)){
if($settingsdb['phone'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `settings` SET `phone` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `settings` SET `phone` = 'on'");
}}

elseif($text == '🎮 مدیریت بازی ها' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎮
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '💣 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game11off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی انفجار خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game11off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی انفجار روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game11off` = 'on'");
}
}

elseif($text == '💣 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game11coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol11' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol11') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game11coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🎰 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game10off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی اسکات خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game10off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی اسکات روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game10off` = 'on'");
}
}

elseif($text == '🎰 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game10coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol10' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol10') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game10coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🎱 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game9off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی رولت خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game9off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی رولت روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game9off` = 'on'");
}
}

elseif($text == '🎱 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game9coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol9' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol9') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game9coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '💩 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game8off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی پوپ خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game8off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی پوپ روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game8off` = 'on'");
}
}

elseif($text == '💩 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game8coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol8' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol8') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game8coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🎲 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game7off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی تاس خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game7off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی تاس روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game7off` = 'on'");
}
}

elseif($text == '🎲 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game7coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol7' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol7') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game7coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🤞 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game6off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی سنگکاغذ خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game6off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی سنگکاغذ روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game6off` = 'on'");
}
}

elseif($text == '🎯 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game5off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی دارت خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game5off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی دارت روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game5off` = 'on'");
}
}
 
elseif($text == '🤞 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game6coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol6' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol6') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game6coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🎯 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game5coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol5' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol5') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game5coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🤜 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game4off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی سنگ کاغذ خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game4off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی سنگ کاغذ روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game4off` = 'on'");
}
}

elseif($text == '🤜 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game4coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol4' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol4') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game4coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}
 
elseif($text == '⚽️ حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game3coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol3' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol3') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game3coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '🎳 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game2coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol2' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol2') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game2coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}

elseif($text == '⚽️ وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game3off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی فوتبال خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game3off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی فوتبال روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game3off` = 'on'");
}
}

elseif($text == '🎳 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game2off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی بولینگ خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game2off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی بولینگ روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game2off` = 'on'");
}
}

elseif($text == '🏀 حداقل' and $tc == 'private' and in_array($from_id,$admin)){
$b1 = $gamedb['game1coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
💰 حداقل شرط فعلی » $b1

📍 شرط جدید را ارسال کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'gamessabol1' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'gamessabol1') {
if(preg_match("/^[0-10-9]+$/", $text)) {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👍 ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `game1coin` = '$text'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 فقط عدد ارسال کن!
",
'reply_to_message_id'=>$message_id,
]);
}
}
 
elseif($text == '🏀 وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['game1off'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی بسکت خاموش شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game1off` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 بازی بسکت روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `game1off` = 'on'");
}
}

elseif($text == '📳 تمام باری ها' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['allgame'] == "on"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ دسترسی به تمام بازی ها قطع شد!!
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `allgame` = 'off'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ دسترسی به تمامی بازی ها روشن شد
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `game` SET `allgame` = 'on'");
}
}

elseif($text == '📣 تنظیم کانال' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['channelshart'] != null){
$b1002 = $gamedb['channelshart'];
}else{
$b1002 = "کانالی ثبت نشده";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📣 لطفا ایدی عددی کانال یا یوزرنیم کانال را برایمان ارسال کنید
🔺 کانال فعلی » $b1002

🔻 مثال » 
ایدی عددی : -1001214564    یوزرنیم : @IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🎮 مدیریت بازی ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'setchannelgogoly' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'setchannelgogoly') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ #کانال شما ثبت شد لطفا ربات را ادمین کانال خود کنید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `game` SET `channelshart` = '$text'");
}

elseif($text == '🎮' and $tc == 'private' and in_array($from_id,$admin)){
if($gamedb['name'] != null){
$b              = $gamedb['name'];
}else{
$b              = "عدم وجود نام پذیرنده";
}
if($gamedb['channelshart'] != null){
$b1002          = $gamedb['channelshart'];
}else{
$b1002          = "چنلی ثبت نشده";
}
 
if($gamedb['allgame'] == "on"){
$b100           = "روشن";
}else{
$b100           = "خاموش";
}
if($gamedb['shart'] == "on"){
$b1001          = "روشن";
}else{
$b1001          = "خاموش";
}
if($gamedb['game1off'] == "on"){
$b1             = "روشن";
}else{
$b1             = "خاموش";
}
if($gamedb['game2off'] == "on"){
$b2             = "روشن";
}else{
$b2             = "خاموش";
}
if($gamedb['game3off'] == "on"){
$b3             = "روشن";
}else{
$b3             = "خاموش";
}
if($gamedb['game4off'] == "on"){
$b4             = "روشن";
}else{
$b4             = "خاموش";
}
if($gamedb['game5off'] == "on"){
$b5             = "روشن";
}else{
$b5             = "خاموش";
}
if($gamedb['game6off'] == "on"){
$b6             = "روشن";
}else{
$b6             = "خاموش";
}
if($gamedb['game7off'] == "on"){
$b7             = "روشن";
}else{
$b7             = "خاموش";
}
if($gamedb['game8off'] == "on"){
$b8             = "روشن";
}else{
$b8             = "خاموش";
}
if($gamedb['game9off'] == "on"){
$b9             = "روشن";
}else{
$b9             = "خاموش";
}
if($gamedb['game10off'] == "on"){
$b10            = "روشن";
}else{
$b10            = "خاموش";
}
if($gamedb['game11off'] == "on"){
$b11            = "روشن";
}else{
$b11            = "خاموش";
}
 
$b1coin         = $gamedb['game1coin'];
$b2coin         = $gamedb['game2coin'];
$b3coin         = $gamedb['game3coin'];
$b4coin         = $gamedb['game4coin'];
$b5coin         = $gamedb['game5coin'];
$b6coin         = $gamedb['game6coin'];
$b7coin         = $gamedb['game7coin'];
$b8coin         = $gamedb['game8coin'];
$b9coin         = $gamedb['game9coin'];
$b10coin        = $gamedb['game10coin'];
$b11coin        = $gamedb['game11coin'];
 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🎮 اطلاعات فعلی بخش بازی های ربات شرطبندی آیرا تیم »

📍 نام بخش » <code>$b</code>
📣 کانال شرط ها » <code>$b1002</code>
🧮 وضعیت دسترسی » <code>$b1001</code>

📳 وضعیت کل بازی ها » <code>$b100</code>
 
🏀 وضعیت بسکت » <code>$b1</code>
🏀 حداقل شرط بسکت » <code>$b1coin</code>

🎳 وضعیت بولینگ » <code>$b2</code>
🎳  حداقل شرط بولینگ » <code>$b2coin</code>

⚽️ وضعیت فوتبال » <code>$b3</code>
⚽️ حداقل شرط فوتبال » <code>$b3coin</code>

🤜 وضعیت گل یا پوچ » <code>$b4</code>
🤜 حداقل شرط گل یا پوچ » <code>$b4coin</code>

🎯 وضعیت دارت » <code>$b5</code>
🎯 حداقل شرط دارت » <code>$b5coin</code>

🤞 وضعیت سنگ کاغذ » <code>$b6</code>
🤞 حداقل شرط سنگ کاغذ » <code>$b6coin</code>

🎲 وضعیت تاس » <code>$b7</code>
🎲 حداقل شرط تاس » <code>$b7coin</code>

💩 وضعیت پوپ » <code>$b8</code>
💩 حداقل شرط پوپ » <code>$b8coin</code>

🎱 وضعیت رولت » <code>$b9</code>
🎱 حداقل شرط رولت » <code>$b9coin</code>

🎰 وضعیت اسکات » <code>$b10</code>
🎰 حداقل شرط اسکات » <code>$b10coin</code>

💣 وضعیت انفجار » <code>$b11</code>
💣 حداقل شرط انفجار » <code>$b11coin</code>

🆔 @IRA_Team
",
'reply_to_message_id'=>$message_id,
'parse_mode'=>'html',
'reply_markup'=>$gameiraabol
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🔐 مدیریت قفل ها' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔐 به بخش مدیریت قفل ها خوش اومدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$ghoflpanelira
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🔑 اوید سین' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $bardashdb['b4'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ اوید سین روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b4` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ اوید سین خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b4` = 'off'");
}
}

elseif($text == '🔑 هارپ سین' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $bardashdb['b5'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ هارپ سین روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b5` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ هارپ سین خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b5` = 'off'");
}
}

elseif($text == '🔑 نیتروسین' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $bardashdb['b3'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ نیترو سین روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b3` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ نیترو سین خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b3` = 'off'");
}
}

elseif($text == '🔑 کیوت سین' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $bardashdb['b2'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ کیوت سین روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b2` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ کیوت سین خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b2` = 'off'");
}
}

elseif($text == '🔑 برداشت نقدی' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $bardashdb['b1'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ نقدی روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b1` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ نقدی خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settingbardasht` SET `b1` = 'off'");
}
}

elseif($text == '🔑 سهام' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $sahamdb['off'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ سهام روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `off` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ سهام خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `off` = 'off'");
}
}
 
elseif($text == '🔑 انتقال سکه' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $settingsdb['kharid'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ انتقال سکه روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settings` SET `kharid` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ انتقال سکه خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `settings` SET `kharid` = 'off'");
}
}

elseif($text == '📝 مدیریت متن ها' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔖 به بخش مدیریت متن ها خوش آمدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$mtsadaira
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '📝 متن زیرمجموعه گیری' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📝 متن جدید را ارسال کنید

📍 راهنمای استارت »

ایدی عددی زیرمجموعه » NEWZIRID
تعداد سکه » COIN
تعداد زیرمجموعه ها » MEMBER
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'📝 مدیریت متن ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newmtntext3' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'newmtntext3') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"✅ متن زیرمجموعه جدید جدید قرار گرفت",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `matn` SET `mtnnewzir` = '$text'");
}

elseif($text == '📝 متن خاموشی' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📝 متن جدید را ارسال کنید

📍 راهنمای استارت »

نام کاربر : NAME
ایدی عددی کاربر : KARBARID
یوزرنیم کاربر : USERNME
اخرین متن کاربر : TX
نمایش تایم : TIMEIRAN
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'📝 مدیریت متن ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newmtntext2' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'newmtntext2') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"✅ متن خاموشی جدید قرار گرفت",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `matn` SET `mtnoff` = '$text'");
}

elseif($text == '📝 متن استارت' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📝 متن جدید را ارسال کنید

📍 راهنمای استارت »

نام کاربر : NAME
ایدی عددی کاربر : KARBARID
یوزرنیم کاربر : USERNME
اخرین متن کاربر : TX
نمایش تایم : TIMEIRAN
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'📝 مدیریت متن ها']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newmtntext' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'newmtntext') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"✅ متن استارت جدید قرار گرفت",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `matn` SET `mtnstart` = '$text'");
}

elseif($text == '👤 مدیریت کاربران' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👋🏻 به پنل مدیریت کاربران خوش امدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '🔴 بلاک' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"❌ لطفا ایدی عددی فرد مورد نظر را ارسال کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'bladmin1' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'bladmin1') {
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
❌ فرد مسدود شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$connect->query("INSERT INTO `block` (`id`) VALUES ('$text')");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '🟢 انبلاک' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"🟢 لطفا ایدی عددی فرد مورد نظر را ارسال کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'bladmin2' WHERE `id` = '$from_id' LIMIT 1");
}
 
elseif($user['step'] == 'bladmin2') {
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
🟢 فرد آزاد شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$connect->query("DELETE FROM `block` WHERE `id` = '{$text}' LIMIT 1 ");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$userid' LIMIT 1");
}

elseif($text == '🏦 افزایش سهام' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 در خط اول ایدی عددی کاربر
📍 در خط دوم تعداد سهام
999999999
20
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'sendercoinadmin' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '💰 افزایش سکه' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 در خط اول ایدی عددی کاربر
📍 در خط دوم تعداد سکه
999999999
20
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'sendercoinadmin3' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '💰 کسر سکه' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 در خط اول ایدی عددی کاربر
📍 در خط دوم تعداد سکه
999999999
20
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'sendercoinadmin4' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'sendercoinadmin3') {
$all = explode("\n", $text);	
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
🔋 انجام شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['coin'] + $all[1] ;
MrMasih('sendmessage',[       
'chat_id'=>$all[0],
'text'=>"
💰 تعداد $all[1] سکه به حساب شما انتقال داده شد
",
]);	
$connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'sendercoinadmin4') {
$all = explode("\n", $text);	
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
🔋 انجام شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['coin'] - $all[1] ;
MrMasih('sendmessage',[       
'chat_id'=>$all[0],
'text'=>"
💰 تعداد $all[1] سکه از شما کسرگردید
",
]);	
$connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '🏦 کسر سهام' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 در خط اول ایدی عددی کاربر
📍 در خط دوم تعداد سهام
999999999
20
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'sendercoinadmin2' WHERE `id` = '$from_id' LIMIT 1");
}
 
elseif($user['step'] == 'sendercoinadmin2') {
$all = explode("\n", $text);	
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
🔋 انجام شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['saham'] - $all[1] ;
MrMasih('sendmessage',[       
'chat_id'=>$all[0],
'text'=>"
💰 تعداد $all[1] سهام از حساب شما کم شد
",
]);	
$connect->query("UPDATE `user` SET `saham` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($user['step'] == 'sendercoinadmin') {
$all = explode("\n", $text);	
MrMasih('sendmessage',[       
'chat_id'=>$chat_id,
'text'=>"
🔋 انتقال موجودی باموفقیت انجام شد!
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['saham'] + $all[1] ;
MrMasih('sendmessage',[       
'chat_id'=>$all[0],
'text'=>"
💰 تعداد $all[1] سهام به حساب شما از طرف ادمین افزوده شد
😉 موجودی جدید شما $coin 
",
]);	
$connect->query("UPDATE `user` SET `saham` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '📨 پیام رسان' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🔖 ایدی عددی اکانتی که میخواهید پیامی برای آن ارسال کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'sendpmmira' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($user['step'] == 'sendpmmira') {
$user2  = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$text' LIMIT 1"));
if($user2['id'] != true){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❗️ این کاربر در دیتابیس ربات وجود ندارد
",
'reply_to_message_id'=>$message_id,
]);
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📝 متنی که میخواهید به کاربر ارسال کنید را بفرستید
",
'reply_to_message_id'=>$message_id,
]);
$connect->query("UPDATE `user` SET `step` = 'sendpmmira2' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step2` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}
}

elseif($user['step'] == 'sendpmmira2'){
$beky = $user['step2'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ پیام برای کاربر ارسال شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$memberirateam
]);
MrMasih('sendmessage',[
'chat_id'=>$beky,
'text'=>"
👨🏼‍💼 پیام مدیریت برای شما :

$text
",
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step2` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '🏦 مدیریت سهام' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
⚙️ به بخش مدیریت سهام خوش آمدید
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saham_adpanel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($text == '📋 استعلام وضعیت' and $tc == 'private' and in_array($from_id,$admin)){
$farda = $sahamdb['darsad'];
$amroz = $sahamdb['ondarsad'];
$onvaz = $sahamdb['onvaz'];
$kar   = $sahamdb['user'];
$irach  = $sahamdb['channel'];
$txmd  = $sahamdb['uptime'];
$irach2 = $sahamdb['off'];
if($irach != null){
$irach  = $sahamdb['channel'];
}else{
$irach  = "کانالی ثبت نشده";
}
if($irach2 == "off"){
$irach2  = "خاموش است";
}else{
$irach2  = "روشن است";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🗿 وضعیت سهام » $irach2


💲 مقدار سهام امروز » $amroz
💲 مقدار سهام فردا » $farda
🏦 وضعیت امروز بازار » $onvaz

👤 کاربران درحال انتظار » $kar
📣 کانال سهام »  $irach

⏰ این گزارش در ساعت $txmd گرفته شده است
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saham_adpanel
]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
exit;
}
 
elseif($text == '🔍 اطلاعات کاربر' and $tc == 'private' and in_array($from_id,$admin)){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✈️ ارز سهام را بفرستید

🔹 ارزش سهام فعلی » $faal
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'👤 مدیریت کاربران']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'infoUser' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($user['step'] == 'infoUser') {
$user2  = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$text' LIMIT 1"));
if($user2['id'] != true){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ این کاربر ربات را استارت نکرده است
",
'reply_to_message_id'=>$message_id,
]);
}else{
$use = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$text' LIMIT 1"));
$getch1 = mysqli_query($connect,"SELECT * FROM `member` WHERE `master` = '$text'");
$getch2 = mysqli_query($connect,"SELECT * FROM `pay` WHERE `id` = '$text'");
while($row1 = mysqli_fetch_assoc($getch1)){
$Channels1=$row1['id'];
$kobs1 .="`$Channels1`\n";
}
while($row1 = mysqli_fetch_assoc($getch2)){
$Channels2=$row1['amount'];
$Channels3=$row1['order_id'];
$kobs3 .="
💰 مقدار : $Channels2 
👤 کاربر : $Channels3\n";
}
$phome = $use['phone'];
if($phome != null){
$phome = $use['phone'];
}else{
$phome = "شماره ثبت نشده";
}
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
👤 اطلاعات کاربر $text به صورت زیر است:

📌 ایدی عددی $text
☎️ شماره : $phome
💰 موجودی : {$use['coin']} سکه
♣️ زیرمجموعه ها : {$use['member']}
💸  مقدار سهام : {$use['saham']}
💵 برداشت ها : {$use['bardashtha']}
➕ برد ها : {$use['bord']}
➖ باخت ها : {$use['bakht']}
💬 دعوت کننده : {$use['master']}

🫂 زیرمجموعه های کاربر : 
$kobs1
",
'reply_to_message_id'=>$message_id,
]); 
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📍 انتقال هاش » 
$kobs3
",
'reply_to_message_id'=>$message_id,
]); 
}
}

elseif($text == '⭕️ تنظیم ارزش سهام' and $tc == 'private' and in_array($from_id,$admin)){
$faal = $sahamdb['coin'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✈️ ارز سهام را بفرستید

🔹 ارزش سهام فعلی » $faal
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🏦 مدیریت سهام']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newcoinsaham' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($user['step'] == 'newcoinsaham') {
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🪝 ارز سهام به ($text) تغیر کرد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saham_adpanel
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `coin` = '$text'");
}

elseif($text == '⭕️ تغیر سود فردا' and $tc == 'private' and in_array($from_id,$admin)){
$farda = $sahamdb['darsad'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✈️ مقدار سهام فردا را بفرستید

🛩 سهام فردا » $farda
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🏦 مدیریت سهام']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newsaham' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($user['step'] == 'newsaham') {
$farda = $sahamdb['darsad'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
🪝سهام فردا به $text تغیر کرد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saham_adpanel
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `darsad` = '$text'");
}

elseif($text == '🔸 تنظیم کانال سهام' and $tc == 'private' and in_array($from_id,$admin)){
$farda = $sahamdb['darsad'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📣 کانال سهامی جدید را بفرستید

📍 آیدی عددی یا یوزرنیم کانال را برای ما بفرستید
📍 مثال » عددی : -100114524  یوزرنیم : @IRA_Team
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>'🏦 مدیریت سهام']],
],
'resize_keyboard'=>true,
])
]);  
$connect->query("UPDATE `user` SET `step` = 'newchannelsaham' WHERE `id` = '$from_id' LIMIT 1");
exit;
}

elseif($user['step'] == 'newchannelsaham') {
$farda = $sahamdb['darsad'];
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
📣 کانال ($text) ثبت شد
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$saham_adpanel
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `channel` = '$text'");
}

elseif($text == '🔸 خاموش / روشن سهام' and $tc == 'private' and in_array($from_id,$admin)){
$irach2 = $sahamdb['off'];
if($irach2 == "off"){
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
✅ سهام روشن شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `off` = 'on'");
}else{
MrMasih('sendmessage',[
'chat_id'=>$from_id,
'text'=>"
❌ سهام خاموش شد
",
'reply_to_message_id'=>$message_id,
]);  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `saham` SET `off` = 'off'");
}
}

 