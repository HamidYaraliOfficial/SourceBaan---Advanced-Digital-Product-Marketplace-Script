<?php
## =============// info //============= ##
error_reporting(0);
## =============// token //============= ##
$Token   = "5976798230:AAFnaKaWEqBGX9BBn8arYkYdgHw5UI1DvI4";
define('API_KEY',"$Token");
## =============// config //============= ##
$admin      = ['1323247682','00','00'];
$Channels   = ['IRA_Team','IRA_Team'];
$baner      = "https://img9.irna.ir/d/r2/2020/06/13/4/157171146.jpg";
## =============// database //============= ##
$connect = new mysqli('localhost','irateami_API','5zx!?_NcPD*y','irateami_API');
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');س
?>